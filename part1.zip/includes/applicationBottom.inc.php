<?php
 /**
  $Id: applicationBottom.inc.php,v 3.03 Saturday, September 18, 2010 5:30:42 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Generic
  * @since  Saturday, September 18, 2010 5:29:29 PM>
  */

if (!$_HIDE_HTTP_HEADER) {
	require_once _MYROOT.'footer.inc.php';
}

if ($_SHOW_GUEST_HTTP_HEADER) {
	require_once _MYROOT.'footer_guest.inc.php';
}
ob_end_flush();
