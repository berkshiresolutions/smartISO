<?php
define('_VENDOR_SMARTY',_MYVENDORS."smarty/");
?>
