<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_PARSE);
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class BluecontributorsAlert {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    protected $dbHand;
    protected $otype;
    protected $oactype;
    protected $module;
    protected $days;
    protected $emaildata;
    protected $email_subject;
    protected $action_url;
    protected $domain_url;

    public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
        //$this->module_name = $p_module;
        //$this->domain_url = $domain;
        //$p_module = str_replace(' ', '', $p_module);
        //$this->module = $p_module;
        $this->days = $this->get_days();
        //echo $this->module;
       // $classname = $this->module;
        // echo $classname;
       // $this->oactype = new $classname($this->days);
        // echo $this->oactype;
       // $this->action_url = "/action_tracker/contributors.php";
        // echo $this->oactype;

       // return $this->oactype;
    }

    public function get_days() {

        $curYear = date('Y');

        $partObj = SetupGeneric::useModule('Participant');
        $optionObj = new Option();
        $check = $optionObj->getOption('_SU_blue_c');


        if ($check == 'a') {
            $alert_mail_days = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $reviewdate = date('Y-m-d', strtotime("+ " . $alert_mail_days . " days"));


           $sql1 = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0 and
							contribDueDate = '%s' ORDER BY contributorID ASC", _DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();


            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['authParticipantID'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


                    $sql3 = sprintf("SELECT fileReference,title FROM %s.cms_documents
							WHERE cmsdocID =%d ", _DB_OBJ_FULL, $row['cmsdocID']);

                    $pStatement = $this->dbHand->prepare($sql3);

                    $pStatement->execute();

                    $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);



                    $sentence = array('sentence' => array("You have an action to carry out the following Contributor Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $row['comments'],
                            'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/contributor_listing.php?id='.$row["contributorID"].'">CLICK</a> Here to View Contributor Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $res["fileReference"]
                            ),
                            'assignedto' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $res["title"]
                            ),
                            'authorizing' => array(
                                'left' => '<strong>Assigned To:</strong>',
                                'right' => $name
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['contribDueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);


                    $emailObj->sendEmail('smart-ISO Green Alert: Contributor action pending.', $who, array(), array(), 'me_completed', '', 'blue');
                }
            }
        }
//end green        
//yellow
        $check = $optionObj->getOption('_SU_yellow_c');

        if ($check == 'a') {
            $alert_mail_days = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $reviewdate = date('Y-m-d', strtotime("+ " . $alert_mail_days . " days"));


            $sql1 = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0 and
							contribDueDate = '%s' ORDER BY contributorID ASC", _DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['authParticipantID'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


                    $sql3 = sprintf("SELECT fileReference,title FROM %s.cms_documents
							WHERE cmsdocID =%d ", _DB_OBJ_FULL, $row['cmsdocID']);

                    $pStatement = $this->dbHand->prepare($sql3);

                    $pStatement->execute();

                    $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);



                    $sentence = array('sentence' => array("You have an action to carry out the following Contributor Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $row['comments'],
                            'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/contributor_listing.php?id='.$row["contributorID"].'">CLICK</a> Here to View Contributor Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $res["fileReference"]
                            ),
                            'assignedto' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $res["title"]
                            ),
                            'authorizing' => array(
                                'left' => '<strong>Assigned To:</strong>',
                                'right' => $name
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['contribDueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);


                    $emailObj->sendEmail('smart-ISO Yellow Alert: Contributor action pending.', $who, array(), array(), 'me_completed', '', 'yellow');
                }
            }
        }
//end yellow
//red
        $check = $optionObj->getOption('_SU_red_c');

        if ($check == 'a') {
            $alert_mail_days = $optionObj->getOption('_SU_EMAIL_REDMAIL');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $reviewdate = date('Y-m-d', strtotime("+ " . $alert_mail_days . " days"));


            $sql1 = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0 and
							contribDueDate = '%s' ORDER BY contributorID ASC", _DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['authParticipantID'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


                    $sql3 = sprintf("SELECT fileReference,title FROM %s.cms_documents
							WHERE cmsdocID =%d ", _DB_OBJ_FULL, $row['cmsdocID']);

                    $pStatement = $this->dbHand->prepare($sql3);

                    $pStatement->execute();

                    $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);



                    $sentence = array('sentence' => array("You have an action to carry out the following Contributor Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $row['comments'],
                            'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/contributor_listing.php?id='.$row["contributorID"].'">CLICK</a> Here to View Contributor Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $res["fileReference"]
                            ),
                            'assignedto' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $res["title"]
                            ),
                            'authorizing' => array(
                                'left' => '<strong>Assigned To:</strong>',
                                'right' => $name
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['contribDueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);


                    $emailObj->sendEmail('smart-ISO Red Alert: Contributor action pending.', $who, array(), array(), 'me_completed', '', 'red');
                }
            }
        }

//end red
 //Magangement escalation

        $check = $optionObj->getOption('_SU_mgmt_c');
        if ($check == 'a') {
            $alert_mail_days_mg = $optionObj->getOption('_SU_EMAIL_MGTESC');
            //tries for 7 days
            for ($daysdue = 1; $daysdue < 8; $daysdue++) {
                list($year, $month, $day) = (explode("-", $date));
                $alert_day = $alert_mail_days_mg + $daysdue;
                $reviewdateredMgnext = date('Y-m-d', strtotime("-" . $alert_day . " days"));

                $sql1 = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0 and
							contribDueDate = '%s' ORDER BY contributorID ASC", _DB_OBJ_FULL, $reviewdateredMgnext);
                $pStatement = $this->dbHand->prepare($sql1);
                $pStatement->execute();

                $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
                //echo $no_rows ;

                if ($row_all) {

                    foreach ($row_all as $row) {

                        $wholink = $row['authParticipantID'];
						$sql2 = sprintf("SELECT gender,surname,forename FROM %s.participant_database WHERE participantID = " . $row['authParticipantID'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();
					$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $texth =  $result_1['gender'] == 'F' ? " her " : " him ";
					
                        $checkadmin = 0;
                        for ($xd = 0; $xd < $daysdue; $xd++) {
                            $whomaster = $partObj->getEscManagerDetails($wholink);
                            $wholink = $whomaster["participantID"];
                            if ($wholink == 0)
                                $checkadmin++;
                        }

                        if ($checkadmin > 1)
                            continue;
                        else if ($checkadmin == 1) {
                            $details = $partObj->getAdminDetails();

                            $who = array(
                                'displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
                                'email' => $details['emailAddress'],
                                'id' => $details["participantID"]);
                        } else
                            $who = array(
                                'displayname' => ucwords($whomaster['forename'] . ' ' . $whomaster['surname']),
                                'email' => $whomaster['emailAddress'],
                                'id' => $wholink);


                        $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


                        $sql3 = sprintf("SELECT fileReference,title FROM %s.cms_documents
							WHERE cmsdocID =%d ", _DB_OBJ_FULL, $row['cmsdocID']);

                        $pStatement = $this->dbHand->prepare($sql3);

                        $pStatement->execute();

                        $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                        $emailObj = new actionEmailHelper($row['ID']);

                        $sentence = array('sentence' => array("You have an action to carry out the following Contributor Action"));
                        $emailObj->appendInfo($sentence);

                        $data = array(
                            'singleColData' => array(
                                'summary' => '<p><strong>Summary</strong><br>' . $row['comments'].'</P>',
                            'summary2' => '<p>You are receiving this email because one of your team has not completed a task allocated to '.$texth.' in time</P>',
                                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/contributor_listing.php?id='.$row["contributorID"].'">CLICK</a> Here to View Contributor Action'
                            ),
                            'twoColData' => array(
                                'actionid' => array(
                                    'left' => '<strong>Reference:</strong>',
                                    'right' => $res["fileReference"]
                                ),
                                'assignedto' => array(
                                    'left' => '<strong>Title:</strong>',
                                    'right' => $res["title"]
                                ),
                                'authorizing' => array(
                                    'left' => '<strong>Assigned To:</strong>',
                                    'right' => $name
                                ),
                                'due' => array(
                                    'left' => '<strong>Due Date:</strong>',
                                    'right' => format_date($row['contribDueDate'])
                                )
                            )
                        );


                        $emailObj->appendInfo($data);

                        $emailObj->sendEmail('smart-ISO Management Escalation: Contributor action pending.', $who, array(), array(), 'me_completed', '', 'mgmt');
                    }
                }
            }
        }


        //end of magament esc
//daily
        $check = $optionObj->getOption('_SU_Daily_c');


        if ($check == 'a') {
            $alert_mail_days_red = $optionObj->getOption('_SU_Daily_Date');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $days = ($day + $alert_mail_days_red);

           $reviewdatered = date('Y-m-d', strtotime("- " . $alert_mail_days_red . " days"));
            //$reviewdatered		= '2010-01-01';					
            $sql1 = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0 and
							contribDueDate <= '%s' ORDER BY contributorID ASC", _DB_OBJ_FULL, $reviewdatered);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['authParticipantID'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


                    $sql3 = sprintf("SELECT fileReference,title FROM %s.cms_documents
							WHERE cmsdocID =%d ", _DB_OBJ_FULL, $row['cmsdocID']);

                    $pStatement = $this->dbHand->prepare($sql3);

                    $pStatement->execute();

                    $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);



                    $sentence = array('sentence' => array("You have an action to carry out the following Contributor Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $row['comments'],
                            'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/contributor_listing.php?id='.$row["contributorID"].'">CLICK</a> Here to View Contributor Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $res["fileReference"]
                            ),
                            'assignedto' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $res["title"]
                            ),
                            'authorizing' => array(
                                'left' => '<strong>Assigned To:</strong>',
                                'right' => $name
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['contribDueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);

                    $emailObj->sendEmail('smart-ISO Daily Alert: Contributor action pending.', $who, array(), array(), 'me_completed', '', 'green');
                }
            }
        }
    }

}

?>