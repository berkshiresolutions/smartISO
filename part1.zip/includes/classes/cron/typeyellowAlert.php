<?php
class YellowAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
//		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= $this->oactype->action_url;
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {

		$optionObj	 		= new Option();
	$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj 			= null;
       // echo $alert_mail_days;
	$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days);
$reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days." days"));
										
		$sql = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL,$reviewdate);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set[$k]['ref'] 		= $row['reference'];
				
				$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set[$k]['ID'] 	= $row['contractManagerID'];
				$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				if($this->result_set[$k]['select'] == 1){
					$this->result_set[$k]['type'] = 'Tender';
				}else{
					$this->result_set[$k]['type'] = 'Short Term';
				}
			
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set[$k++]['reviewDueDate']			= $row['reviewDueDate'];
			}
		}
	//	dump_array($this->result_set);
		
		return $this->result_set;
	
		//return $alert_mail_days;
	}

	public function save_action_alert() {}
	
	public function data() {
	
		$sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID",_DB_OBJ_FULL,_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
	
	      // echo $alert_mail_days;
	
	}
	public function generate_email() {
	//echo $alert_mail_days
	//echo  $this->p_alert_mail_days =  $p_alert_mail_days;
	//$this->oactype 		= new $classname($alert_mail_days);

		 $cnt = count($this->result_set);
          //echo "sdfasfds";
		/*if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
             echo "sdfdsf";
			$document_specs = array();

			for ($i=0;$i<$cnt;$i++) {

				$document_specs[$i]['Document Uploaded From'] 	= $this->oactype->result_set[$i]['dep_code'];
				$document_specs[$i]['Uploaded File'] 			= $this->oactype->result_set[$i]['usr_filename'];
				$document_specs[$i]['File Reference'] 			= $this->oactype->result_set[$i]['file_reference'];
				$document_specs[$i]['Document Name'] 			= ucfirst($this->oactype->result_set[$i]['title']);
				$document_specs[$i]['Document Description'] 	= ucfirst($this->oactype->result_set[$i]['desc']);

				switch ($this->oactype->result_set[$i]['dtype']) {
					case 'D': $document_specs[$i]['Document Type'] = 'Document'; break;
					case 'P': $document_specs[$i]['Document Type'] = 'Presentation'; break;
					case 'F': $document_specs[$i]['Document Type'] = 'Form'; break;
					case 'E': $document_specs[$i]['Document Type'] = 'Excel Spreadsheet'; break;
					default: $document_specs[$i]['Document Type'] = 'Document'; break;
				}

				$document_specs[$i]['Date Initiated'] 			= $this->oactype->result_set[$i]['date_initiated'];
				$document_specs[$i]['Initiated By'] 			= $this->oactype->result_set[$i]['initiated_by'];
				$document_specs[$i]['Summary of Action Taken'] 	= ucfirst($this->oactype->result_set[$i]['action_desc']);
				$document_specs[$i]['No. of Pages'] 			= $this->oactype->result_set[$i]['pages'];

			}
		}*/


 		$this->email_subject = "Smart-iso Yellow Alert: ".ucfirst($this->module)." review pending.";

		for ($i=0;$i<$cnt;$i++) {

			if ( $this->html_mail ) {
			//echo "sfadsfds";
			
		$sql = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['ID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);

				$action_html = "<html><head><link href='http://".$_SERVER['HTTP_HOST']."/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='http://".$_SERVER['HTTP_HOST']."/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
				$action_html .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set[$i]['title']."<br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set[$i]['ref']."<br/>";
					$action_html .= "<span class='normaltextbold'>Type</span> : ".$this->result_set[$i]['type']."<br/>";
					$action_html .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set[$i]['reviewDueDate']."<br/><br/>";
				}
				


				$action_html .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2011 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			} else {
			
			
				$action_html = "Hi ".ucwords($this->oactype->result_set[$i]['action_who']).",\n\n";
				$action_html .= ucfirst($this->module_name)." action allocated to you is pending.\n\nHere are the details :\n\n";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_plain;
				} else {

					$action_html .= "Action Description: ".$this->oactype->result_set[$i]['action_desc']."\n";
					$action_html .= "Due Date : ".$this->oactype->result_set[$i]['action_when']."\n\n";
				}
				$action_html .= "Please click <a href='".$this->domain_url.$this->action_url."'>here</a> to view action.<br/><br/>";

				$action_html .= "You are receiving this email because you are or have been a user of Smart-ISO�. <br/>
Copyright � 2011 Smart-ISO�. All rights reserved.</span></div></body></html>";
			}
			

			$this->result_set[$i]['email_body'] = $action_html;
		}
	}

	public function send_email() {

		$emails_cnt = count($this->result_set);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
             $sql = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['ID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/plain; charset=UTF-8\r\n";
					}

				foreach($result as $value){
				
				
				
			  // echo  $value;
				
					$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";

					@mail($value,$this->email_subject,$this->result_set[$i]['email_body'],$header);
					@mail('smartiso.ehsindia@gmail.com',$this->email_subject,$this->result_set[$i]['email_body'],$header);
					
					@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set[$i]['email_body'],$header);
		
					@mail('gurveer_2k1@hotmail.com',$this->email_subject,$this->result_set[$i]['email_body'],$header);
					
					$this->log_cron_record($this->oactype->result_set[$i]['action_who_id'],$this->module_name);
					
			
				
				
				
				}

					
					//echo $this->result_set[$i]['email_body'];
					
				
			} // end for
		} // end if
	}

	private function log_cron_record($pid,$mod_name) {

		$miscObj = new Misc();
		$CURRENT_DATE = $miscObj->getCurDate();
		$miscObj = null;

		$sql_query = sprintf("SELECT * FROM %s.cron_log
								WHERE moTduleName = '%s'
								AND cardype = 'yellow'
								AND sentOnDate = '%s'
								AND participantID = %d",_DB_OBJ_FULL,$mod_name,$CURRENT_DATE,$pid);

		$pStatement = $this->dbHand->prepare($sql_query);
		$pStatement->execute();

		$result =  $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( !empty($result['participantID']) ) {

			$blue_card_val = (int) $result['cardCount'];

			$sql_ins_upd = sprintf("UPDATE cron_log SET cardCount = %d
						WHERE moduleName = '%s'
						AND participantID = %d
						AND cardType = 'yellow'
						AND sendOnDate = '%s'",_DB_OBJ_FULL,($blue_card_val+1),$result['moduleName'],$result['participantID'],$result['sentOnDate']);

		} else {

			$sql_ins_upd = sprintf("INSERT INTO %s.cron_log (participantID,cardType,cardCount,moduleName,sentOnDate)
						VALUES (%d,'%s',1,'%s','%s')",_DB_OBJ_FULL,$pid,'yellow',$mod_name,$CURRENT_DATE);

		}

		$pStatement = $this->dbHand->prepare($sql_ins_upd);
		$pStatement->execute();
	}
}
?>