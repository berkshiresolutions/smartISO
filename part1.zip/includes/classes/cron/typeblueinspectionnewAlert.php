
<?php
class BlueinspectionnewAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

	 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {

		$optionObj	 		= new Option();
		$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
		$optionObj 			= null;

		
		

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days." days"));
					
	 	$sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();

		 $no_rows = $pStatement->rowCount();
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			
			
				$locObj 			= SetupGeneric::useModule('Locationgram');

	$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set[$k]['locID'] 		= $row['locID'];
				$this->result_set[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		//dump_array($this->result_set);

		echo $cnt = count($this->result_set);
		

 		$this->email_subject = "smart-ISO Blue Alert: Inspection Due.";

		for ($i=0;$i<$cnt;$i++) {
		
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result_1 as $val){
	
		
		  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_2['forename'].' '.$result_2['surname']);
			dump_array($result_2);
			
				$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "Inspection due allocated to you is pending.<br/>Here are the details :<br/>";

					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html .= "<span class='normaltextbold'>Location</span>: ".$this->result_set[$i]['nameLoc']."<br/>";
					$action_html .= "<span class='normaltextbold'>Description</span>: ".$this->result_set[$i]['desc']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set[$i]['dateLoc'])."<br/><br/>";
			
				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
					  if($result_2['emailAddress']){
					  echo	$this->result_set[$i]['email_body'] = $action_html;
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					 
				$recipients =$result_2['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set[$i]['email_body'],$header);

				
					  }
			}
		}
		

		$optionObj	 		= new Option();
		$alert_mail_days_yellow 	= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj 			= null;

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_yellow);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days_yellow." days"));
	
	
		$sql12 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql12);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$locObj 			= SetupGeneric::useModule('Locationgram');

	$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_yellow[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_yellow[$k]['locID'] 		= $row['locID'];
				$this->result_set_yellow[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_yellow[$k]['desc'] 	= $row['actionDescription'];
				
				
			}
		}
	//dump_array($this->result_set_yellow);
	

		$cnt = count($this->result_set_yellow);
		$this->email_subject = "smart-ISO Yellow Alert: Inspection Due.";

		for ($i=0;$i<$cnt;$i++) {
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_yellow[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result_1 as $val){
		$sql13 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		$action_html_yellow = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_yellow .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_yellow .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_yellow .= "Inspection due allocated to you is pending.<br/>Here are the details :<br/>";

					$action_html_yellow .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_yellow[$i]['nameLoc']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_yellow[$i]['desc']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_yellow[$i]['dateLoc'])."<br/>";
		$action_html_yellow .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_yellow .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_yellow[$i]['email_body'] = $action_html_yellow;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_yellow[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_yellow[$i]['email_body'],$header);

				
				}
		}

		}
		


		$optionObj	 		= new Option();
		$alert_mail_days_red 	= $optionObj->getOption('_SU_EMAIL_REDMAIL');
		$optionObj 			= null;
     
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_red);

echo $reviewdatered=date('Y-m-d',strtotime("+ ".$alert_mail_days_red." days"));
			
		$sql23 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdatered);
		$pStatement = $this->dbHand->prepare($sql23);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
	if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				$locObj 			= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_red[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_red[$k]['locID'] 		= $row['locID'];
				$this->result_set_red[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_red[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		
		$cnt = count($this->result_set_red);

 		$this->email_subject = "smart-ISO Red Alert: Inspection Due";

			for ($i=0;$i<$cnt;$i++) {
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_red[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result_1 as $val){
		$sql13 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		$action_html_red = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_red .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_red .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_red .= "Inspection due allocated to you is pending.<br/>Here are the details :<br/>";

					$action_html_red .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_red .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_red[$i]['nameLoc']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_red[$i]['desc']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_red[$i]['dateLoc'])."<br/>";
		$action_html_red .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_red .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_red[$i]['email_body'] = $action_html_red;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_red[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_red[$i]['email_body'],$header);

				
				}
		}
		
		}
		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day - $alert_mail_days_mg);
 $reviewdateredMg=date('Y-m-d',strtotime("-".$alert_mail_days_mg." days"));
	$sql23 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg);
		$pStatement = $this->dbHand->prepare($sql23);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
	if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				$locObj 			= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_mgr[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_mgr[$k]['locID'] 		= $row['locID'];
				$this->result_set_mgr[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_mgr[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		
		$cnt = count($this->result_set_mgr);

 		$this->email_subject = "smart-ISO Management Escalation Inspection due action pending.";

			for ($i=0;$i<$cnt;$i++) {
			
			
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_red[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		foreach($result_1 as $val){
		
		
		$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql13 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql37 =sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."'  AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
		
		$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Inspection due action is pending. You are getting this email because you are manager of the business unit <br/><br/>The details are below :<br/>";

					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_mgr[$i]['nameLoc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_mgr[$i]['desc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr[$i]['dateLoc'])."<br/>";
		$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_mgr[$i]['email_body'] = $action_html_mgr;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);
		
		
		
		}
		

				
				}
		}
		
		}
				$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;


$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 1;
$days = ($day - $alert_day);

 $reviewdateredMg1=date('Y-m-d',strtotime("-".$alert_day." days"));
	$sql233 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg1);
		$pStatement = $this->dbHand->prepare($sql233);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
	if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				$locObj 			= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_mgr_1[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_mgr_1[$k]['locID'] 		= $row['locID'];
				$this->result_set_mgr_1[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_mgr_1[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		
		$cnt = count($this->result_set_mgr_1);

 		$this->email_subject = "smart-ISO Management Escalation Inspection due action pending.";

			for ($i=0;$i<$cnt;$i++) {
			
			
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_red[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		foreach($result_1 as $val){
		
		
		$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql13 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
		
		 $sql37 =sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu['parentBuID']."'  AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
		
		$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Inspection due action is pending. You are getting this email because you are manager of the business unit <br/><br/>The details are below :<br/>";

					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_mgr_1[$i]['nameLoc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_mgr_1[$i]['desc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr_1[$i]['dateLoc'])."<br/>";
		$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_mgr_1[$i]['email_body'] = $action_html_mgr;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_mgr_1[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);
		
		
		
		}
		

				
				}
		}
		
		}
		
		$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;


$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 2;
$days = ($day - $alert_day);

 $reviewdateredMg2=date('Y-m-d',strtotime("-".$alert_day." days"));
	$sql234 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg2);
		$pStatement = $this->dbHand->prepare($sql234);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
	if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				$locObj 			= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_mgr_2[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_mgr_2[$k]['locID'] 		= $row['locID'];
				$this->result_set_mgr_2[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_mgr_2[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		
		$cnt = count($this->result_set_mgr_2);

 		$this->email_subject = "smart-ISO Management Escalation Inspection due action pending.";

			for ($i=0;$i<$cnt;$i++) {
			
			
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_red[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		foreach($result_1 as $val){
		
		
		$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql13 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
		
		 $sql37 =sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_2['parentBuID']."'  AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
		
		$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Inspection due action is pending. You are getting this email because you are manager of the business unit <br/><br/>The details are below :<br/>";

					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_mgr_2[$i]['nameLoc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_mgr_2[$i]['desc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr_2[$i]['dateLoc'])."<br/>";
		$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_mgr_2[$i]['email_body'] = $action_html_mgr;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_mgr_2[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);
		
		
		
		}
		

				
				}
		}
		
		}
		
		$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 3;
$days = ($day - $alert_day);

 $reviewdateredMg3=date('Y-m-d',strtotime("-".$alert_day." days"));
	$sql235 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg3);
		$pStatement = $this->dbHand->prepare($sql235);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
	if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				$locObj 			= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_mgr_3[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_mgr_3[$k]['locID'] 		= $row['locID'];
				$this->result_set_mgr_3[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_mgr_3[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		
		$cnt = count($this->result_set_mgr_3);

 		$this->email_subject = "smart-ISO Management Escalation Inspection due action pending.";

			for ($i=0;$i<$cnt;$i++) {
			
			
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_red[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		foreach($result_1 as $val){
		
		
		$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql13 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
		
		 $sql37 =sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_3['parentBuID']."'  AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
		
		$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Inspection due action is pending. You are getting this email because you are manager of the business unit <br/><br/>The details are below :<br/>";

					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_mgr_3[$i]['nameLoc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_mgr_3[$i]['desc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr_3[$i]['dateLoc'])."<br/>";
		$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_mgr_3[$i]['email_body'] = $action_html_mgr;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_mgr_3[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);
		
		
		
		}
		

				
				}
		}
		
		}
		
		$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 4;
$days = ($day - $alert_day);

 $reviewdateredMg4=date('Y-m-d',strtotime("-".$alert_day." days"));
	$sql236 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg4);
		$pStatement = $this->dbHand->prepare($sql236);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
	if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				$locObj 			= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$row['locID']));
	$loc = $locObj->displaylocationByPid();
				$this->result_set_mgr_4[$k]['nameLoc'] 		= $loc['name'];
				$this->result_set_mgr_4[$k]['locID'] 		= $row['locID'];
				$this->result_set_mgr_4[$k]['dateLoc'] 	= $row['dueDate'];
				$this->result_set_mgr_4[$k]['desc'] 	= $row['actionDescription'];
			
			}
		}

		
		$cnt = count($this->result_set_mgr_4);

 		$this->email_subject = "smart-ISO Management Escalation Inspection due action pending.";

			for ($i=0;$i<$cnt;$i++) {
			
			
		$sql2 = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE sectionName = 'inspection' AND sectionActive = 1 AND  locationID = ".$this->result_set_red[$i]['locID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		foreach($result_1 as $val){
		
		
		$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql13 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql139 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_3['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql139);

		$pStatement->execute();

		$rest_bu_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
		
		 $sql37 =sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_4['parentBuID']."'  AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
		
		$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Inspection due action is pending. You are getting this email because you are manager of the business unit <br/><br/>The details are below :<br/>";

					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url." <br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Location</span>: ".$this->result_set_mgr_4[$i]['nameLoc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Description</span>: ".$this->result_set_mgr_4[$i]['desc']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr_4[$i]['dateLoc'])."<br/>";
		$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";

		
	
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
	
				if($result['emailAddress']){
				echo	$this->result_set_mgr_4[$i]['email_body'] = $action_html_mgr;
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'];
				@mail('gurpardeep.dhaliwal@gmail.com',$this->email_subject,$this->result_set_mgr_4[$i]['email_body'],$header);
				//@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);
		
		
		
		}
		

				
				}
		}
		
		}


		
	}
	
}
?>
