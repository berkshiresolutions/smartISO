<?php
class FleetmonthlyAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {

		$optionObj	 		= new Option();
		$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
		$optionObj 			= null;
       //echo $alert_mail_days;
	   //exit;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days." days"));
	//$reviewdate		= '2010-01-01';					
	echo	$sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'vehicleMonthly' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				//exit;
				$this->result_set[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set[$k]['who'] 	= $row['who'];
				$this->result_set[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Blue Alert: Smart Fleet Monthly inspection action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);
		
		echo $sql3 = sprintf("SELECT * FROM %s.perform_vehicle_monthly
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql3);

		$pStatement->execute();

		$res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//echo $this->result_set[$i]['ref_id'];
		foreach($res_1 as $value_ref){
		
		if($value_ref['type'] == '0'){
		$type = 'Custom';
		}
		if($value_ref['type'] == '1'){
		$type = 'External';
		}
		if($value_ref['type'] == '2'){
		$type = 'Fluids';
		}
		if($value_ref['type'] == '3'){
		$type = 'Internal';
		}
		if($value_ref['type'] == '4'){
		$type = 'Functional';
		}
		if($value_ref['type'] == '5'){
		$type = 'Equipment';
		}
		
		//dump_array($value_ref);
		if($value_ref['actionID'] == $this->result_set[$i]['ref_id']){
         
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value_ref['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($d_1);
		//exit;				
		$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "Smart Fleet Monthly inspection action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					$action_html .= "<span class='normaltextbold'>Frequency</span>: Monthly<br/>";
					$action_html .= "<span class='normaltextbold'>Type</span>: ".$type."<br/>";
					$action_html .= "<span class='normaltextbold'>Inspection Name</span>: ".$value_ref['name']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set[$i]['actionDescription']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set[$i]['dueDate']."<br/><br/>";
					
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set[$i]['email_body'] = $action_html;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = '';//'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set[$i]['email_body'],$header);
						
		}
		
		}
		}
		
		
		}
	
		$optionObj	 		= new Option();
		$alert_mail_days_yellow 	= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj 			= null;
        //echo $alert_mail_days_yellow;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_yellow);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days_yellow." days"));
	//$reviewdate		= '2010-01-01';					
	echo	$sql12 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'vehicleMonthly' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql12);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_yellow[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_yellow[$k]['who'] 	= $row['who'];
				$this->result_set_yellow[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_yellow[$k++]['dueDate']			= $row['dueDate'];
			}
		}
	//dump_array($this->result_set_yellow);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set_yellow);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Yellow Alert: Smart Fleet Monthly inspection action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql13 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql14 =  sprintf("SELECT * FROM %s.perform_vehicle_monthly
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql14);

		$pStatement->execute();

		$res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res_1 as $value_ref){
		
		if($value_ref['type'] == '0'){
		$type = 'Custom';
		}
		if($value_ref['type'] == '1'){
		$type = 'External';
		}
		if($value_ref['type'] == '2'){
		$type = 'Fluids';
		}
		if($value_ref['type'] == '3'){
		$type = 'Internal';
		}
		if($value_ref['type'] == '4'){
		$type = 'Functional';
		}
		if($value_ref['type'] == '5'){
		$type = 'Equipment';
		}
		
		//dump_array($value_ref);
		if($value_ref['actionID'] == $this->result_set_yellow[$i]['ref_id']){
         
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value_ref['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($d_1);
		//exit;				
		$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "Smart Fleet Monthly inspection action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					$action_html .= "<span class='normaltextbold'>Frequency</span>: Monthly<br/>";
					$action_html .= "<span class='normaltextbold'>Type</span>: ".$type."<br/>";
					$action_html .= "<span class='normaltextbold'>Inspection Name</span>: ".$value_ref['name']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_yellow[$i]['actionDescription']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_yellow[$i]['dueDate']."<br/><br/>";
					
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_yellow[$i]['email_body'] = $action_html;
		$sql15 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql15);

		$pStatement->execute();

		$result_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		 dump_array($result_4);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			    echo  $result_4['emailAddress']."------";
				//foreach($result as $value){
				//echo $value;
				if($result_4['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_4['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_yellow[$i]['email_body'],$header);

				}
						
		}
		
		}
		}
		
		
		

		$optionObj	 		= new Option();
		$alert_mail_days_red 	= $optionObj->getOption('_SU_EMAIL_REDMAIL');
		$optionObj 			= null;
       // echo $alert_mail_days;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_red);

echo $reviewdatered=date('Y-m-d',strtotime("+ ".$alert_mail_days_red." days"));
	//$reviewdatered		= '2010-01-01';					
		$sql23 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'vehicleMonthly' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdatered);
		$pStatement = $this->dbHand->prepare($sql23);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_red[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_red[$k]['who'] 	= $row['who'];
				$this->result_set_red[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_red[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set_red);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set_red);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Red Alert: Smart Fleet Monthly inspection action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql24 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql24);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		 	 $sql25 = sprintf("SELECT * FROM %s.perform_vehicle_monthly
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql25);

		$pStatement->execute();

		$res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res_1 as $value_ref){
		
		if($value_ref['type'] == '0'){
		$type = 'Custom';
		}
		if($value_ref['type'] == '1'){
		$type = 'External';
		}
		if($value_ref['type'] == '2'){
		$type = 'Fluids';
		}
		if($value_ref['type'] == '3'){
		$type = 'Internal';
		}
		if($value_ref['type'] == '4'){
		$type = 'Functional';
		}
		if($value_ref['type'] == '5'){
		$type = 'Equipment';
		}
		
		//dump_array($value_ref);
		if($value_ref['actionID'] == $this->result_set_red[$i]['ref_id']){
         
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value_ref['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($d_1);
		//exit;				
		$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "Smart Fleet Monthly inspection action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					$action_html .= "<span class='normaltextbold'>Frequency</span>: Monthly<br/>";
					$action_html .= "<span class='normaltextbold'>Type</span>: ".$type."<br/>";
					$action_html .= "<span class='normaltextbold'>Inspection Name</span>: ".$value_ref['name']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_red[$i]['actionDescription']."<br/>";
					
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_red[$i]['dueDate']."<br/><br/>";
					
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_red[$i]['email_body'] = $action_html;
		$sql26 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql26);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			   echo  $result['emailAddress']."------";
				//..foreach($result as $value){
				//echo $value;
				if( $result['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_red[$i]['email_body'],$header);

				}
						
		}
		
		
		
		}
		
				
		}
		
	$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day - $alert_mail_days_mg);
 $reviewdateredMg=date('Y-m-d',strtotime("-".$alert_mail_days_mg." days"));


										
		echo	$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'vehicleMonthly' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr[$k]['who'] 	= $row['who'];
				$this->result_set_mgr[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		dump_array($this->result_set_mgr);
		//exit;
		$cnt = count($this->result_set_mgr);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation Smart Fleet Monthly Inspection action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res['reportToBuID']);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal);
		//exit;
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT * FROM %s.perform_vehicle_monthly
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		
		if($value_ref['type'] == '0'){
		$type = 'Custom';
		}
		if($value_ref['type'] == '1'){
		$type = 'External';
		}
		if($value_ref['type'] == '2'){
		$type = 'Fluids';
		}
		if($value_ref['type'] == '3'){
		$type = 'Internal';
		}
		if($value_ref['type'] == '4'){
		$type = 'Functional';
		}
		if($value_ref['type'] == '5'){
		$type = 'Equipment';
		}
		
		//dump_array($value_ref);
		if($value_ref['actionID'] == $this->result_set_mgr[$i]['ref_id']){
         echo "gsdfgdfgdfgfdgsd";
		 $sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value_ref['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($d_1);
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$res['reportToBuID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
		//exit;	
			//dump_array($business_unit_arr);
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Smart Fleet Monthly Inspection action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Frequency</span>: Monthly<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Type</span>: ".$type."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Inspection Name</span>: ".$value_ref['name']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr[$i]['dueDate'])."<br/><br/>";
					
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->action_html_mgr[$i]['email_body'] = $action_html_mgr;
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($result as $value){
				//dump_array($value);
				if($value){
				 echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$value.", ".$cc;
				@mail($recipients,$this->email_subject,$this->action_html_mgr[$i]['email_body'],$header);

				
					
				}
			
		}
						
		}
		
		
		
		}
				
		
			
		
		}

		}
		
	$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 1;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));
	
echo	$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'vehicleMonthly' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_1[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_1[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_1[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_1[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		dump_array($this->result_set_mgr_1);
		//exit;
		$cnt = count($this->result_set_mgr_1);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation Smart Fleet Inspection action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_1[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
			$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();

		$rest_bu_name_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_1[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res['reportToBuID']);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_name_3['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal);
		//exit;
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT * FROM %s.perform_vehicle_monthly
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		
		if($value_ref['type'] == '0'){
		$type = 'Custom';
		}
		if($value_ref['type'] == '1'){
		$type = 'External';
		}
		if($value_ref['type'] == '2'){
		$type = 'Fluids';
		}
		if($value_ref['type'] == '3'){
		$type = 'Internal';
		}
		if($value_ref['type'] == '4'){
		$type = 'Functional';
		}
		if($value_ref['type'] == '5'){
		$type = 'Equipment';
		}
		
		//dump_array($value_ref);
		if($value_ref['actionID'] == $this->result_set_mgr_1[$i]['ref_id']){
         echo "gsdfgdfgdfgfdgsd";
		 $sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value_ref['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($d_1);
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$res['reportToBuID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
		//exit;	
			//dump_array($business_unit_arr);
		$result_set_mgr_1 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Smart Fleet Monthly Inspection action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Frequency</span>: Monthly<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Type</span>: ".$type."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Inspection Name</span>: ".$value_ref['name']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr_1[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr_1[$i]['dueDate'])."<br/><br/>";
					
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->action_html_mgr[$i]['email_body'] = $action_html_mgr;
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($result as $value){
				//dump_array($value);
				if($value){
				 echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$value.", ".$cc;
				@mail($recipients,$this->email_subject,$this->action_html_mgr[$i]['email_body'],$header);

				
					
				}
			
		}
						
		}
		
		
		
		}
				
		
			
		
		}
	}

		
		

		
	}



		
}
?>