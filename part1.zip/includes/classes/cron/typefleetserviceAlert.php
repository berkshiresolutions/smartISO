<?php
class FleetserviceAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {

		$optionObj	 		= new Option();
		$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
		$optionObj 			= null;
       //echo $alert_mail_days;
	   //exit;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days." days"));
	//$reviewdate		= '2010-01-01';					
	echo	$sql1 = sprintf("SELECT * FROM %s.vehicle_service WHERE done is NULL AND  dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				//exit;
				$this->result_set[$k]['actionDescription'] 		= $row['descp'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set[$k]['who'] 	= $row['whoN'];
				$this->result_set[$k]['ref_id'] 	= $row['vID'];
				$this->result_set[$k]['title'] 	= $row['servicingRequired'];
				$this->result_set[$k]['mileage'] 	= $row['services'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Blue Alert: Smart Fleet service action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);
		
		
         
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$this->result_set[$i]['ref_id'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
					
		$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "Smart Fleet service action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html .= "<span class='normaltextbold'>Service Name</span>: ".$this->result_set[$i]['title']."<br/>";
					$action_html .= "<span class='normaltextbold'>Mileage</span>: ".$this->result_set[$i]['mileage']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set[$i]['actionDescription']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set[$i]['dueDate'])."<br/><br/>";
					
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set[$i]['email_body'] = $action_html;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = '';//gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set[$i]['email_body'],$header);
						
		}
		

		
		
		
		}
		
	echo	$sql633 = sprintf("SELECT * FROM %s.perform_vehicle_service
							WHERE sDate='".$reviewdate."'",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql633);

		$pStatement->execute();

		$d_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		foreach ($d_data as $key1 => $value1){
					foreach ($d_data as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($d_data[$key1]['service'] == $d_data[$key2]['service'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($d_data[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
$d_data =		array_values($d_data);

foreach($d_data as $value){
//dump_array($value);

$sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$value['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);

$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
			$this->email_subject = "smart-ISO Blue Alert: Smart Fleet service action pending.";		
		$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "Smart Fleet service action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html .= "<span class='normaltextbold'>Service Name</span>: ".$value['service']."<br/>";
					$action_html .= "<span class='normaltextbold'>Mileage</span>: ".$value['cMileage']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$value['descp']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".format_date($value['sDate'])."<br/><br/>";
					
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set['email_body'] = $action_html;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$value['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set['email_body'],$header);
						
		}
}

	
		$optionObj	 		= new Option();
		$alert_mail_days_yellow 	= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj 			= null;
        //echo $alert_mail_days_yellow;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_yellow);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days_yellow." days"));
	//$reviewdate		= '2010-01-01';					
	echo	$sql1 = sprintf("SELECT * FROM %s.vehicle_service WHERE done is NULL AND  dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				//exit;
				$this->result_set_y[$k]['actionDescription'] 		= $row['descp'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_y[$k]['who'] 	= $row['whoN'];
				$this->result_set_y[$k]['ref_id'] 	= $row['vID'];
				$this->result_set_y[$k]['title'] 	= $row['servicingRequired'];
				$this->result_set_y[$k]['mileage'] 	= $row['services'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_y[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set_y);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Yellow Alert: Smart Fleet service action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_y[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);
		
		
         
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$this->result_set_y[$i]['ref_id'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
					
		$action_html_y = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_y .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_y .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_y .= "Smart Fleet service action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_y .= $document_html;
				} else {
					$action_html_y .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_y .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html_y .= "<span class='normaltextbold'>Service Name</span>: ".$this->result_set_y[$i]['title']."<br/>";
					$action_html_y .= "<span class='normaltextbold'>Mileage</span>: ".$this->result_set_y[$i]['mileage']."<br/>";
					$action_html_y .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_y[$i]['actionDescription']."<br/>";
					$action_html_y .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_y[$i]['dueDate'])."<br/><br/>";
					
					
				}
				


				$action_html_y .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_y .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_y[$i]['email_body'] = $action_html_y;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_y[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_y[$i]['email_body'],$header);
						
		}
		

		
		
		
		}
		
	echo	$sql633 = sprintf("SELECT * FROM %s.perform_vehicle_service
							WHERE sDate='".$reviewdate."'",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql633);

		$pStatement->execute();

		$d_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		foreach ($d_data as $key1 => $value1){
					foreach ($d_data as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($d_data[$key1]['service'] == $d_data[$key2]['service'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($d_data[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
$d_data =		array_values($d_data);

foreach($d_data as $value){
//dump_array($value);

$sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$value['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);

$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
			$this->email_subject = "smart-ISO Yellow Alert: Smart Fleet service action pending.";		
		$action_html_y = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_y .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_y .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_y .= "Smart Fleet service action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_y .= $document_html;
				} else {
					$action_html_y .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_y .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html_y .= "<span class='normaltextbold'>Service Name</span>: ".$value['service']."<br/>";
					$action_html_y .= "<span class='normaltextbold'>Mileage</span>: ".$value['cMileage']."<br/>";
					$action_html_y .= "<span class='normaltextbold'>Summary of Action</span>: ".$value['descp']."<br/>";
					$action_html_y .= "<span class='normaltextbold'>Due Date</span>: ".format_date($value['sDate'])."<br/><br/>";
					
					
				}
				


				$action_html_y .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_y .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_y['email_body'] = $action_html_y;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$value['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_y['email_body'],$header);
						
		}
}


	$optionObj	 		= new Option();
		$alert_mail_days_red 	= $optionObj->getOption('_SU_EMAIL_REDMAIL');
		
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_red);

echo $reviewdatered=date('Y-m-d',strtotime("+ ".$alert_mail_days_red." days"));
//exit;
	echo	$sql1 = sprintf("SELECT * FROM %s.vehicle_service WHERE done is NULL AND  dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdatered);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				//exit;
				$this->result_set_r[$k]['actionDescription'] 		= $row['descp'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_r[$k]['who'] 	= $row['whoN'];
				$this->result_set_r[$k]['ref_id'] 	= $row['vID'];
				$this->result_set_r[$k]['title'] 	= $row['servicingRequired'];
				$this->result_set_r[$k]['mileage'] 	= $row['services'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_r[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set_r);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Red Alert: Smart Fleet service action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_r[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);
		
		
         
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$this->result_set_r[$i]['ref_id'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
					
		$action_html_r = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_r .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_r .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_r .= "Smart Fleet service action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_r .= $document_html;
				} else {
					$action_html_r .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_r .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html_r .= "<span class='normaltextbold'>Service Name</span>: ".$this->result_set_r[$i]['title']."<br/>";
					$action_html_r .= "<span class='normaltextbold'>Mileage</span>: ".$this->result_set_r[$i]['mileage']."<br/>";
					$action_html_r .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_r[$i]['actionDescription']."<br/>";
					$action_html_r .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_r[$i]['dueDate'])."<br/><br/>";
					
					
				}
				


				$action_html_r .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_r .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_r[$i]['email_body'] = $action_html_r;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_y[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_r[$i]['email_body'],$header);
						
		}
		

		
		
		
		}
		
	echo	$sql633 = sprintf("SELECT * FROM %s.perform_vehicle_service
							WHERE sDate='".$reviewdatered."'",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql633);

		$pStatement->execute();

		$d_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		foreach ($d_data as $key1 => $value1){
					foreach ($d_data as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($d_data[$key1]['service'] == $d_data[$key2]['service'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($d_data[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
$d_data =		array_values($d_data);

foreach($d_data as $value){
//dump_array($value);

$sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$value['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);

$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$value['vID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
			$this->email_subject = "smart-ISO Red Alert: Smart Fleet service action pending.";		
		$action_html_r = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_r .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_r .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_r .= "Smart Fleet service action allocated to you is pending.<br/><br/>Here are the details :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_r .= $document_html;
				} else {
					$action_html_r .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_r .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html_r .= "<span class='normaltextbold'>Service Name</span>: ".$value['service']."<br/>";
					$action_html_r .= "<span class='normaltextbold'>Mileage</span>: ".$value['cMileage']."<br/>";
					$action_html_r .= "<span class='normaltextbold'>Summary of Action</span>: ".$value['descp']."<br/>";
					$action_html_r .= "<span class='normaltextbold'>Due Date</span>: ".format_date($value['sDate'])."<br/><br/>";
					
					
				}
				


				$action_html_r .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_r .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_r['email_body'] = $action_html_r;
		  echo  $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$value['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result_2);
		//exit;
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          echo $result_2['emailAddress']."--------";
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					   $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_r['email_body'],$header);
						
		}
}



		$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));
	
echo $sql1 = sprintf("SELECT * FROM %s.vehicle_service WHERE done is NULL AND  dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				//exit;
				$this->result_set_mgr[$k]['actionDescription'] 		= $row['descp'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr[$k]['who'] 	= $row['whoN'];
				$this->result_set_mgr[$k]['ref_id'] 	= $row['vID'];
				$this->result_set_mgr[$k]['title'] 	= $row['servicingRequired'];
				$this->result_set_mgr[$k]['mileage'] 	= $row['services'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		
		$cnt = count($this->result_set_mgr);
	
	


 		$this->email_subject = "smart-ISO Management Escalation Smart Fleet Service action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res['reportToBuID']);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT * FROM %s.perform_vehicle_monthly
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		 $sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		$sql63 = sprintf("SELECT * FROM %s.vehicle
							WHERE ID=".$this->result_set_mgr[$i]['ref_id'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql63);

		$pStatement->execute();

		$d_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$res['reportToBuID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
					
		$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following Smart Fleet Service action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$d_1['uniqueReference']."<br/>";
					
					$action_html_mgr .= "<span class='normaltextbold'>Service Name</span>: ".$this->result_set_mgr[$i]['title']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Mileage</span>: ".$this->result_set_mgr[$i]['mileage']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".format_date($this->result_set_mgr[$i]['dueDate'])."<br/><br/>";
					
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		echo	$this->result_set_mgr[$i]['email_body'] = $action_html_mgr;
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($result as $value){
				//dump_array($value);
				if($value){
				 echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$value.", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);

				
					
				}
			
		}
						
	

		}
	}

		
		

		
	}



		
}
?>