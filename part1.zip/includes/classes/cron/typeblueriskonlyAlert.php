<?php
 error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_PARSE);
 require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';
class BlueriskAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {

		$optionObj	 		= new Option();
		$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
		$optionObj 			= null;
       // echo $alert_mail_days;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days." days"));
	//$reviewdate		= '2010-01-01';					
		$sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set[$k]['who'] 	= $row['who'];
				$this->result_set[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Blue Alert: ".ucfirst($this->module)." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);
		
		 $sql3 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql3);

		$pStatement->execute();

		$res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_blue_c');
		
if($check == 'a'){

		
		foreach($res_1 as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set[$i]['ref_id'];
		if($action['0'] == $this->result_set[$i]['ref_id']){
		  $emailObj = new actionEmailHelper($this->result_set[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Blue Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'blue');
						
		}
		if($action['1'] == $this->result_set[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Blue Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'blue');
						
		}
		}
		}
		}
		
		$emails_cnt = count($this->result_set);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
             $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			 //  echo  $result['emailAddress']."------";
				//foreach($result as $value){
			          //echo $result_2['emailAddress']."--------";
					  if($this->result_set[$i]['email_body']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					  $cc = 'gurveer_2k1@hotmail.com';
				
				$recipients = $result_2['emailAddress'];
				//@mail($recipients,$this->email_subject,$this->result_set[$i]['email_body'],$header);

			
					  }
					

			} // end for
		}
		//exit;
		
		$cnt = count($this->result_set);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Blue Alert: ".ucfirst($this->module)." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql5 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql5);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		 $sql6 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql6);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal);
		
		foreach($resFinal as $val){
		$sql7 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql7);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql8 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql8);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set[$i]['ref_id'];
		if($action['0'] == $this->result_set[$i]['ref_id']){
		// echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		//echo	$email = $result['emailAddress'];
				$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html .= "<span class='normaltextbold'>Who</span>: ".$na."<br/>";
					$action_html .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['hazardSummary']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set[$i]['actionDescription']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set[$i]['email_body'] = $action_html;
		}
		if($action['1'] == $this->result_set[$i]['ref_id']){
		// echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		//echo	$email = $result['emailAddress'];
				$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html .= $document_html;
				} else {
					$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['problemDescription']."<br/>";
					$action_html .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set[$i]['actionDescription']."<br/>";
					$action_html .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set[$i]['dueDate']."<br/><br/>";
				
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html .= "Support smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set[$i]['email_body'] = $action_html;
		}
		}
		
		 $sql11 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql11);

		$pStatement->execute();

		$result_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($result_3 as $value){
				//dump_array($value);
				if($this->result_set[$i]['email_body']){
				 //echo  $value."--------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = 'gurveer_2k1@hotmail.com';
				
				$recipients = $value;
				//@mail($recipients,$this->email_subject,$this->result_set[$i]['email_body'],$header);

				
					
				}
				
		
		}
			
		}
		
		} // end if
		
		

	




	
		$optionObj	 		= new Option();
		$alert_mail_days_yellow 	= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj 			= null;
        //echo $alert_mail_days_yellow;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_yellow);

echo $reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days_yellow." days"));
	//$reviewdate		= '2010-01-01';					
		$sql12 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql12);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_yellow[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_yellow[$k]['who'] 	= $row['who'];
				$this->result_set_yellow[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_yellow[$k++]['dueDate']			= $row['dueDate'];
			}
		}
	//dump_array($this->result_set_yellow);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set_yellow);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Yellow Alert: ".ucfirst($this->module)." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql13 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql14 =  sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);


		        $pStatement = $this->dbHand->prepare($sql14);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_yellow_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_yellow[$i]['ref_id']){
		  $emailObj = new actionEmailHelper($this->result_set_yellow[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Yellow Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'yellow');
						
		}
		if($action['1'] == $this->result_set_yellow[$i]['ref_id']){
		$emailObj = new actionEmailHelper($this->result_set_yellow[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Yellow Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'yellow');
						
		}
		}
		}
		}
		
		$emails_cnt = count($this->result_set_yellow);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
            $sql15 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql15);

		$pStatement->execute();

		$result_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result_4);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			   // echo  $result_4['emailAddress']."------";
				//foreach($result as $value){
				//echo $value;
				if($this->result_set_yellow[$i]['email_body']){
				
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = 'gurveer_2k1@hotmail.com';
				
				$recipients = $result_4['emailAddress'];
				//@mail($recipients,$this->email_subject,$this->result_set_yellow[$i]['email_body'],$header);

				
				}
					

			} // end for
		} 
		

			$cnt = count($this->result_set_yellow);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Yellow Alert: ".ucfirst($this->module)." action pending.";

		for ($i=0;$i<$cnt;$i++) {

		$sql16 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql16);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res['reportToBuID']);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		$sql17 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql17);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal);
		foreach($resFinal as $val){
				$sql18 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql18);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql19 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
		        $pStatement = $this->dbHand->prepare($sql19);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_yellow[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		//echo	$email = $result['emailAddress'];
				$action_html_yellow = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_yellow .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_yellow .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_yellow .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_yellow .= $document_html;
				} else {
				
					$action_html_yellow .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Who</span>: ".$na."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['hazardSummary']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_yellow[$i]['actionDescription']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_yellow[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html_yellow .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_yellow .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set_yellow[$i]['email_body'] = $action_html_yellow;
		}
		if($action['1'] == $this->result_set_yellow[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		//echo	$email = $result['emailAddress'];
				$action_html_yellow = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_yellow .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_yellow .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_yellow .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_yellow .= $document_html;
				} else {
					$action_html_yellow .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['problemDescription']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_yellow[$i]['actionDescription']."<br/>";
					$action_html_yellow .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_yellow[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html_yellow .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_yellow .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set_yellow[$i]['email_body'] = $action_html_yellow;
		}
		}
		
		$sql22 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql22);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($result as $value){
				//dump_array($value);
				if($this->result_set_yellow[$i]['email_body']){
				 echo  $value."--------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = 'gurveer_2k1@hotmail.com';
				
				$recipients = $value;
				//@mail($recipients,$this->email_subject,$this->result_set_yellow[$i]['email_body'],$header);

				
					
				}
		
		}
	
		}

		} 
		
		
		
		$optionObj	 		= new Option();
		$alert_mail_days_red 	= $optionObj->getOption('_SU_EMAIL_REDMAIL');
		$optionObj 			= null;
       // echo $alert_mail_days;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_red);

echo $reviewdatered=date('Y-m-d',strtotime("+ ".$alert_mail_days_red." days"));
	//$reviewdatered		= '2010-01-01';					
		$sql23 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdatered);
		$pStatement = $this->dbHand->prepare($sql23);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_red[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_red[$k]['who'] 	= $row['who'];
				$this->result_set_red[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_red[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		//dump_array($this->result_set_red);
		
		//return $this->result_set;
		
		$cnt = count($this->result_set_red);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Red Alert: ".ucfirst($this->module)." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql24 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql24);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		 	 $sql25 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
		        $pStatement = $this->dbHand->prepare($sql25);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_red_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_red[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_red[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Red Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'red');
						
		}
		if($action['1'] == $this->result_set_red[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_red[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Red Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'red');
						
		}
		}
		}
				
			//echo "sfadsfds";
				//echo	$email = $result['emailAddress'];
				
		}
		
		$emails_cnt = count($this->result_set_red);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
             $sql26 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql26);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

			   //echo  $result['emailAddress']."------";
				//..foreach($result as $value){
				//echo $value;
				if($this->result_set_red[$i]['email_body']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = 'gurveer_2k1@hotmail.com';
				
				$recipients =$result['emailAddress'];
				//@mail($recipients,$this->email_subject,$this->result_set_red[$i]['email_body'],$header);

				
				}
					
			} // end for
		}

					$cnt = count($this->result_set_red);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Red Alert: ".ucfirst($this->module)." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql27 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql27);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		$sql28 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql28);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		foreach($resFinal as $val){
			//dump_array($resFinal['participantID']);
			$sql29 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql29);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql30 =sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql30);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_red[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		//echo	$email = $result['emailAddress'];
				$action_html_red = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_red .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_red .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_red .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_red .= $document_html;
				} else {
					$action_html_red .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Who</span>: ".$na."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['hazardSummary']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_red[$i]['actionDescription']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_red[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html_red .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_red .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set_red[$i]['email_body'] = $action_html_red;
		}
		if($action['1'] == $this->result_set_red[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		//echo	$email = $result['emailAddress'];
				$action_html_red = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_red .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_red .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_red .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_red .= $document_html;
				} else {
					$action_html_red .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_red .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['problemDescription']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_red[$i]['actionDescription']."<br/>";
					$action_html_red .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_red[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html_red .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_red .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set_red[$i]['email_body'] = $action_html_red;
		}
		}
		//dump_array($res);
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		$sql33 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql33);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($result as $value){
				//dump_array($value);
				if($this->result_set_red[$i]['email_body']){
				 echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				$cc = 'gurveer_2k1@hotmail.com';
				
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->result_set_red[$i]['email_body'],$header);

				
					
				}
			
		
		}
	
		}

		}

			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day - $alert_mail_days_mg);
echo $reviewdateredMg=date('Y-m-d',strtotime("-".$alert_mail_days_mg." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMg);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr[$k]['who'] 	= $row['who'];
				$this->result_set_mgr[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr);
		$cnt = count($this->result_set_mgr);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		//dump_array($res['reportToBuID']);
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$res['reportToBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal['participantID']);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);


		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_mgmt_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr[$i]['ref_id']){
		$emailObj = new actionEmailHelper($this->result_set_mgr[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		if($action['1'] == $this->result_set_mgr[$i]['ref_id']){
		$emailObj = new actionEmailHelper($this->result_set_mgr[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		
		}
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr[$i]['email_body']){
				 //echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
			    $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr[$i]['email_body'],$header);
				}
				

			
		}
		
		}

		}
		
	
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 1;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_1[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_1[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_1[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_1[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr);
		$cnt = count($this->result_set_mgr_1);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_1[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_1[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
			$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();

		$rest_bu_name_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name_3['buName']);
		//dump_array($rest_bu);
		  $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu['parentBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal['participantID']);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_mgmt_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_1[$i]['ref_id']){
		$emailObj = new actionEmailHelper($this->result_set_mgr_1[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager1($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		if($action['1'] == $this->result_set_mgr_1[$i]['ref_id']){
		$emailObj = new actionEmailHelper($this->result_set_mgr_1[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager1($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		
		}
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_1[$i]['email_body']){
				 //echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_1[$i]['email_body'],$header);
				}
				

			
		}
		
		}

		}
		//exit;
		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 2;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_2[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_2[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_2[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_2[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr);
		$cnt = count($this->result_set_mgr_2);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_2[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_2[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
			$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();

		$rest_bu_name_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name_1['buName']);
		//dump_array($rest_bu_2);
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_2['parentBuID']."'AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal['participantID']);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_mgmt_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_2[$i]['ref_id']){
 $emailObj = new actionEmailHelper($this->result_set_mgr_2[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager2($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		if($action['1'] == $this->result_set_mgr_2[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_mgr_2[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager2($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		
		}
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_2[$i]['email_body']){
				 //echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_2[$i]['email_body'],$header);

				}
				

			
		}
		
		}

		}
		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 3;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_3[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_3[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_3[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_3[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr);
		$cnt = count($this->result_set_mgr_3);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_3[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_3[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_3['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();

		$rest_bu_name_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name_1['buName']);
		//dump_array($rest_bu_3);
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_3['parentBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal['participantID']);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_mgmt_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_3[$i]['ref_id']){
		  $emailObj = new actionEmailHelper($this->result_set_mgr_3[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager3($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		if($action['1'] == $this->result_set_mgr_3[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_mgr_3[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager3($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		
		}
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_3[$i]['email_body']){
				 //echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_3[$i]['email_body'],$header);

					
				}
				

			
		}
		
		}

		}
		

		
					$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 4;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_5[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_5[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_5[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_5[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr);
		$cnt = count($this->result_set_mgr_5);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_5[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_5[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql139 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_3['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql139);

		$pStatement->execute();

		$rest_bu_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_4['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();

		$rest_bu_name = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name['buName']);
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_4['parentBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal['participantID']);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_mgmt_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_5[$i]['ref_id']){
		  $emailObj = new actionEmailHelper($this->result_set_mgr_5[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager4($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		if($action['1'] == $this->result_set_mgr_5[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_mgr_5[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager4($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		
		}
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_5[$i]['email_body']){
				// echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_5[$i]['email_body'],$header);

				
					
				}
				

			
		}
		
		}

		}
		
		$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 5;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_6[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_6[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_6[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_6[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr);
		$cnt = count($this->result_set_mgr_6);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_6[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_6[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql139 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_3['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql139);

		$pStatement->execute();

		$rest_bu_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql149 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_4['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql149);

		$pStatement->execute();

		$rest_bu_5 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_5['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();
		


		$rest_bu_name = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name['buName']);
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_5['parentBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal['participantID']);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 =sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_mgmt_c');
		
if($check == 'a'){
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_6[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_mgr_6[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager5($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		if($action['1'] == $this->result_set_mgr_6[$i]['ref_id']){
		 $emailObj = new actionEmailHelper($this->result_set_mgr_6[$i]['ref_id']);
			$who = $emailObj->getwhoDetails();
			
			//dump_array($who);
			 $ogrObj = SetupGeneric::useModule('Organigram');
					$ogrObj->setItemInfo(array('id'=> $who['ID']));
				$whomaster=$ogrObj->getManager5($who['ID']);
				$pid=$whomaster["participantID"];
				
				$partObj = SetupGeneric::useModule('Participant');
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
					dump_array($details);
					$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				//exit;

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $value_ref["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Management Escalation: Risk action pending.', $who1, array(), array(), 'me_completed', '', 'mgmt');
		}
		
		}
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_6[$i]['email_body']){
				 //echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_6[$i]['email_body'],$header);

					
				}
				

			
		}
		
		}

		}
		
		
		$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 6;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_7[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_7[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_7[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_7[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr_7);
		$cnt = count($this->result_set_mgr_7);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_7[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_7[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql139 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_3['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql139);

		$pStatement->execute();

		$rest_bu_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql149 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_4['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql149);

		$pStatement->execute();

		$rest_bu_5 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql159 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_5['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql159);

		$pStatement->execute();

		$rest_bu_6 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_6['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();
		


		$rest_bu_name = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name['buName']);
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_6['parentBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_7[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$rest_bu_name['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['hazardSummary']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr_7[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_mgr_7[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->action_html_mgr_7[$i]['email_body'] = $action_html_mgr;
		}
		if($action['1'] == $this->result_set_mgr_7[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$rest_bu_name['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['problemDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr_7[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_mgr_7[$i]['dueDate']."<br/><br/>";
					
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->action_html_mgr_7[$i]['email_body'] = $action_html_mgr;
		}
		
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_7[$i]['email_body']){
				// echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_7[$i]['email_body'],$header);

					
				}
				

			
		}
		
		}

		}
		
		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 7;
$days = ($day - $alert_day);
echo $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


										
			$sql34 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdateredMgnext);
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		
		if ($no_rows) {
			$k = 0;
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
				//dump_array($row);
				$this->result_set_mgr_8[$k]['actionDescription'] 		= $row['actionDescription'];
				
			//	$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_8[$k]['who'] 	= $row['who'];
				$this->result_set_mgr_8[$k]['ref_id'] 	= $row['ID'];
			//	$this->result_set[$k]['title'] 	= $row['contractName'];
	     
		
				//$this->result_set[$k]['action_email'] 		= $val['emailAddress'];
				$this->result_set_mgr_8[$k++]['dueDate']			= $row['dueDate'];
			}
		}
		
		//dump_array($this->result_set_mgr_7);
		$cnt = count($this->result_set_mgr_8);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "smart-ISO Management Escalation ".$this->module_name." action pending.";

		for ($i=0;$i<$cnt;$i++) {

			$sql35 = sprintf("SELECT * FROM %s.participant_meta_data WHERE participantID = ".$this->result_set_mgr_8[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql35);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
			$sql36 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$this->result_set_mgr_8[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$rest = $pStatement->fetch(PDO::FETCH_ASSOC);
		$na_who		= ucwords($rest['forename'].' '.$rest['surname']);
		
		//$this->result_set[$k]['ID'] 	= $res['reportToBuID'];
		$sql136 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$res['reportToBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql136);

		$pStatement->execute();

		$rest_bu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql137 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql137);

		$pStatement->execute();

		$rest_bu_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql138 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_2['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql138);

		$pStatement->execute();

		$rest_bu_3 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql139 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_3['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql139);

		$pStatement->execute();

		$rest_bu_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql149 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_4['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql149);

		$pStatement->execute();

		$rest_bu_5 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql159 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_5['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql159);

		$pStatement->execute();

		$rest_bu_6 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql169 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_6['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql169);

		$pStatement->execute();

		$rest_bu_7 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql140 = sprintf("SELECT * FROM %s.business_units WHERE buID = ".$rest_bu_7['parentBuID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql140);

		$pStatement->execute();
		


		$rest_bu_name = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($rest_bu_name['buName']);
		 $sql37 = sprintf("SELECT * FROM %s.organisation_positions WHERE buID = '".$rest_bu_7['parentBuID']."' AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql37);

		$pStatement->execute();

		$resFinal = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resFinal);
		foreach($resFinal as $val){
			$sql38 = sprintf("SELECT * FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql38);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		
		 $sql39 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql39);

		$pStatement->execute();

		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($res as $value_ref){
		//dump_array($value_ref);
		
	    $action = explode(",",$value_ref['improvements']);
        //dump_array($action);
		//echo $action['0'];
		//echo $this->result_set_mgr[$i]['ref_id'];
		if($action['0'] == $this->result_set_mgr_8[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$rest_bu_name['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['hazardSummary']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr_8[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_mgr_8[$i]['dueDate']."<br/><br/>";
					
					//$action_html .= "Please click <a href='http://smart-test.smart-iso.net/action_tracker/non_conf_inc.php'>here</a> to view action.<br/><br/>";
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->action_html_mgr_8[$i]['email_body'] = $action_html_mgr;
		}
		if($action['1'] == $this->result_set_mgr_8[$i]['ref_id']){
		 //echo $action[0]."-----";
		//echo $value_ref['reference'];
		//echo $value_ref['buID'];
		//echo $value_ref['problemDescription'];
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$value_ref['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Dear ".ucwords($name).",<br/><br/>";
				$action_html_mgr .= "The following ".ucfirst($this->module_name)." action is pending. You are getting this email because you are manager of the business unit ".$rest_bu_name['buName']."<br/><br/>The details are below :<br/>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				if ( $this->module == 'ContributorDuedate' || $this->module == 'contributor' ) {
					$action_html_mgr .= $document_html;
				} else {
					$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$value_ref['reference']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Who</span>: ".$na_who."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Problem Description</span>: ".$value_ref['problemDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Summary of Action</span>: ".$this->result_set_mgr_8[$i]['actionDescription']."<br/>";
					$action_html_mgr .= "<span class='normaltextbold'>Due Date</span>: ".$this->result_set_mgr_8[$i]['dueDate']."<br/><br/>";
					
					
				}
				


				$action_html_mgr .= "Support smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of smart-ISO&trade;. <br/>
Copyright � 2012 smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->action_html_mgr_8[$i]['email_body'] = $action_html_mgr;
		}
		
		}
				
			//echo "sfadsfds";
					//echo 'gurveer_2k1@hotmail.com';
		//	echo	$email = $result['emailAddress'];
		$sql42 = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = ".$val['participantID'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql42);

		$pStatement->execute();

		$resu = $pStatement->fetch(PDO::FETCH_ASSOC);
		
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

				foreach($resu as $value){
				//dump_array($value);
				if($this->action_html_mgr_8[$i]['email_body']){
				// echo  $value."------";
				$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				 $cc = 'gurveer_2k1@hotmail.com';
				$recipients =$value;
				//@mail($recipients,$this->email_subject,$this->action_html_mgr_8[$i]['email_body'],$header);

				}
				

			
		}
		
		}

		}
			$optionObj	 		= new Option();
		$alert_mail_days_red 	= $optionObj->getOption('_SU_Daily_Date');
		$check 	= $optionObj->getOption('_SU_Daily_Alert');
		$optionObj 			= null;
       // echo $alert_mail_days;
//dump_array(GetDate());

$optionObj	 		= new Option();
$check 	= $optionObj->getOption('_SU_daily_c');
		
if($check == 'a'){

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = ($day + $alert_mail_days_red);

echo $reviewdatered=date('Y-m-d',strtotime("- ".$alert_mail_days_red." days"));
	//$reviewdatered		= '2010-01-01';					
		 $sql23 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'risk' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate <= '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdatered);
		$pStatement = $this->dbHand->prepare($sql23);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		
		$row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//echo $no_rows ;
		
		if ($row_all) {
		
			foreach($row_all as $row) {
			
			$sql25 = sprintf("SELECT R.hazardSummary,R.improvements,S.reference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements LIKE '".$row['ID']."'
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
			
			


		        $pStatement = $this->dbHand->prepare($sql25);

		$pStatement->execute();

		$res = $pStatement->fetch(PDO::FETCH_ASSOC);
			//dump_array($row);
			
			
		//dump_array($res);
		
				$emailObj = new actionEmailHelper($row['ID']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?filter_date=">CLICK</a> Here to View Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $res["reference"]
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('smart-ISO Daily Alert: Risk action pending.', $who, array(), array(), 'me_completed', '', 'green');
				
				
			}
		}
		
		

}
		
		
		
		
		
	
	
		
	
		
		
	
		//return $alert_mail_days;
	}



		
}
?>