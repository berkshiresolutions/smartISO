
<?php
///error_reporting(0);
class BlueinspectionduemAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {

		$optionObj	 		= new Option();
		$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
		$optionObj 			= null;

		
		

 $date = date("Y-m-d");
list($year,$month,$day) = (explode("-",$date));

$days = 1;

echo $reviewdate=date('Y-m-d',strtotime("+".$days." months"));

					
	 	$sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE 'inspectionDue' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC",_DB_OBJ_FULL,
								 $reviewdate);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();

		 $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resultSet);
		if($resultSet){
			
				foreach ($resultSet as $key1 => $value1){
					foreach ($resultSet as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($resultSet[$key1]['who'] == $resultSet[$key2]['who'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($resultSet[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
		   
	dump_array($resultSet);
	//exit;
	foreach($resultSet as $val){
	$orgObj 		= SetupGeneric::useModule('Organigram');
	$orgObj->mailFire($val['ID'],$val['locID']);
	
	}
		//exit;
		
		
		}
		

	
}
?>
