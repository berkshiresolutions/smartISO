<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_PARSE);
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class BluetrainconfirmAlert {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    protected $dbHand;
    protected $otype;
    protected $oactype;
    protected $module;
    protected $days;
    protected $emaildata;
    protected $email_subject;
    protected $action_url;
    protected $domain_url;

    public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);

        $this->days = $this->get_days();


       // return $this->oactype;
    }

    public function get_days() {

        $curYear = date('Y');

        $partObj = SetupGeneric::useModule('Participant');
        $optionObj = new Option();
        $check = $optionObj->getOption('_SU_blue_c');


        if ($check == 'a') {
            $alert_mail_days = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $reviewdate = date('Y-m-d', strtotime("+ " . $alert_mail_days . " days"));

 $sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'trainconfirm' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC", _DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();


            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['who'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


$trainrefarray=explode(":|:",$row["actionDescription"]);
$trainrefarray1=explode(" - ",$trainrefarray[1]);
                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);


                    $sentence = array('sentence' => array("You have an action to carry out the following Training Confirm Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $trainrefarray1[0],
                            'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/actiontracker/train/confirm">CLICK</a> Here to View Training Confirm Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $trainrefarray1[1]
                            ),
                            'title' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $trainrefarray[0]
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['dueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);

                    $emailObj->sendEmail('smart-ISO Green Alert: Training Confirm action pending.', $who, array(), array(), 'me_completed', '', 'blue');
                }
            }
        }
//end green  

//yellow
        $check = $optionObj->getOption('_SU_yellow_c');

        if ($check == 'a') {
            $alert_mail_days = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $reviewdate = date('Y-m-d', strtotime("+ " . $alert_mail_days . " days"));


       $sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'trainconfirm' AND outstanding != '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC", _DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['who'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);

$trainrefarray=explode(":|:",$row["actionDescription"]);
$trainrefarray1=explode(" - ",$trainrefarray[1]);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);


                    $sentence = array('sentence' => array("You have an action to carry out the following Training Confirm Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $trainrefarray1[0],
                            'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/actiontracker/train/confirm">CLICK</a> Here to View Training Confirm Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $trainrefarray1[1]
                            ),
                            'title' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $trainrefarray[0]
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['dueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);


                    $emailObj->sendEmail('smart-ISO Yellow Alert: Training Confirm action pending.', $who, array(), array(), 'me_completed', '', 'yellow');
                }
            }
        }
//end yellow
   
//red
        $check = $optionObj->getOption('_SU_red_c');

        if ($check == 'a') {
            $alert_mail_days = $optionObj->getOption('_SU_EMAIL_REDMAIL');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $reviewdate = date('Y-m-d', strtotime("+ " . $alert_mail_days . " days"));


            $sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'trainconfirm' AND outstanding != '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate = '%s' ORDER BY ID ASC", _DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['who'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


 $trainrefarray=explode(":|:",$row["actionDescription"]);
$trainrefarray1=explode(" - ",$trainrefarray[1]);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);


                    $sentence = array('sentence' => array("You have an action to carry out the following Training Confirm Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $trainrefarray1[0],
                            'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/actiontracker/train/confirm">CLICK</a> Here to View Training Confirm Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $trainrefarray1[1]
                            ),
                            'title' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $trainrefarray[0]
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['dueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);


                    $emailObj->sendEmail('smart-ISO Red Alert: Training Confirm action pending.', $who, array(), array(), 'me_completed', '', 'red');
                }
            }
        }

//end red

 //Magangement escalation

        $check = $optionObj->getOption('_SU_mgmt_c');
        if ($check == 'a') {
            $alert_mail_days_mg = $optionObj->getOption('_SU_EMAIL_MGTESC');
            //tries for 7 days
            for ($daysdue = 1; $daysdue < 8; $daysdue++) {
                list($year, $month, $day) = (explode("-", $date));
                $alert_day = $alert_mail_days_mg + $daysdue;
               $reviewdateredMgnext = date('Y-m-d', strtotime("-" . $alert_day . " days"));

                $sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'trainconfirm' AND outstanding != '1' AND approveAU = '0'
							  AND (doneDate IS NULL OR doneDate = '1900-01-01')  AND dueDate = '%s' ORDER BY ID ASC", _DB_OBJ_FULL, $reviewdateredMgnext);
                $pStatement = $this->dbHand->prepare($sql1);
                $pStatement->execute();

                $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
                //echo $no_rows ;

                if ($row_all) {

                    foreach ($row_all as $row) {

                        $wholink = $row['who'];
						$sql2 = sprintf("SELECT gender,surname,forename FROM %s.participant_database WHERE participantID = " . $row['who'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();
					$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $texth =  $result_1['gender'] == 'F' ? " her " : " him ";
                        $checkadmin = 0;
                        for ($xd = 0; $xd < $daysdue; $xd++) {
                            $whomaster = $partObj->getEscManagerDetails($wholink);
                            $wholink = $whomaster["participantID"];
                            if ($wholink == 0)
                                $checkadmin++;
                        }

                        if ($checkadmin > 1)
                            continue;
                        else if ($checkadmin == 1) {
                            $details = $partObj->getAdminDetails();

                            $who = array(
                                'displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
                                'email' => $details['emailAddress'],
                                'id' => $details["participantID"]);
                        } else
                            $who = array(
                                'displayname' => ucwords($whomaster['forename'] . ' ' . $whomaster['surname']),
                                'email' => $whomaster['emailAddress'],
                                'id' => $wholink);


                        $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


$trainrefarray=explode(":|:",$row["actionDescription"]);
$trainrefarray1=explode(" - ",$trainrefarray[1]);


                    $emailObj = new actionEmailHelper($row['ID']);



                    $sentence = array('sentence' => array("You have an action to carry out the following Training Confirm Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $trainrefarray1[0].'</P>',
                            'summary2' => '<p>You are receiving this email because one of your team has not completed a task allocated to '.$texth.' in time</P>',
                            'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/actiontracker/train/confirm">CLICK</a> Here to View Training Confirm Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $trainrefarray1[1]
                            ),
                            'title' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $trainrefarray[0]
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['dueDate'])
                            )
                        )
                    );


                    $emailObj->appendInfo($data);

                        $emailObj->sendEmail('smart-ISO Management Escalation: Training Confirm action pending.', $who, array(), array(), 'me_completed', '', 'mgmt');
                    }
                }
            }
        }


        //end of magament esc

//daily
        $check = $optionObj->getOption('_SU_Daily_c');
        $checkManager = $optionObj->getOption('_SU_Daily_Date_Manager');

        if ($check == 'a') {
            $alert_mail_days_red = $optionObj->getOption('_SU_Daily_Date');
            $date = date("y-m-d");
            list($year, $month, $day) = (explode("-", $date));

            $days = ($day + $alert_mail_days_red);

           $reviewdatered = date('Y-m-d', strtotime("- " . $alert_mail_days_red . " days"));
            //$reviewdatered		= '2010-01-01';	
           
           if ($checkManager == 'n') {
           $sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'trainconfirm' AND outstanding != '1'  AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') AND dueDate <= '%s' ORDER BY ID ASC", _DB_OBJ_FULL, $reviewdatered);
           }else {
     $sql1 = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'trainconfirm' AND outstanding != '1'  AND approveAU = '0'
							 AND dueDate <= '%s' ORDER BY ID ASC", _DB_OBJ_FULL, $reviewdatered);
 }
          
            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $row_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            //echo $no_rows ;

            if ($row_all) {

                foreach ($row_all as $row) {

                    $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $row['who'], _DB_OBJ_FULL);

                    $pStatement = $this->dbHand->prepare($sql2);

                    $pStatement->execute();

                    $result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
                    $name = ucwords($result_1['forename'] . ' ' . $result_1['surname']);


$trainrefarray=explode(":|:",$row["actionDescription"]);
$trainrefarray1=explode(" - ",$trainrefarray[1]);


                    $emailObj = new actionEmailHelper($row['ID']);
                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $result_1['emailAddress'],
                        'id' => $row['who']);


                    $sentence = array('sentence' => array("You have an action to carry out the following Training Confirm Action"));
                    $emailObj->appendInfo($sentence);

                    $data = array(
                        'singleColData' => array(
                            'summary' => '<p><strong>Summary</strong><br>' . $trainrefarray1[0],
                            'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/actiontracker/train/confirm">CLICK</a> Here to View Training Confirm Action'
                        ),
                        'twoColData' => array(
                            'actionid' => array(
                                'left' => '<strong>Reference:</strong>',
                                'right' => $trainrefarray1[1]
                            ),
                            'title' => array(
                                'left' => '<strong>Title:</strong>',
                                'right' => $trainrefarray[0]
                            ),
                            'due' => array(
                                'left' => '<strong>Due Date:</strong>',
                                'right' => format_date($row['dueDate'])
                            )
                        )
                    );


                     if($row["doneDescription"] != ''){
                        
                     $data['singleColData']['manager'] = '<p>The action is awaiting your manager Approval</p>';
                       
  
                    }

                    $emailObj->appendInfo($data);

                    $emailObj->sendEmail('smart-ISO Daily Alert: Training Confirm action pending.', $who, array(), array(), 'me_completed', '', 'green');
                }
            }
        }
    }

}

?>