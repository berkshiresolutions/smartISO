<?php
class BluecontractreviewAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         // echo $classname;
		//include_once "moduleContract.php";
        // echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {
//Blue email
		$optionObj	 		= new Option();
		$alert_mail_days 	= $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
		$optionObj 			= null;
       // echo $alert_mail_days;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$contractObj = new Contract();
$offset_quarter=$contractObj->getQuarter($year,$month,$day);
if ($offset_quarter["quarter"] ==4)
$offset_day=7*$contractObj->getDetailedContractReviewOffset();
else
$offset_day=7*$contractObj->getStandardContractReviewOffset();

if ($alert_mail_days>$offset_day){
	$days = ($alert_mail_days-$offset_day);
	$reviewdate=date('Y-m-d',strtotime("+ ".$days." days"));
}
else{
	$days = ($offset_day-$alert_mail_days);
	$reviewdate=date('Y-m-d',strtotime("- ".$days." days"));
}




//$days = ($alert_mail_days-$offset_day);

// $reviewdate=date('Y-m-d',strtotime("+ ".$days." days"));

	//$reviewdate		= '2010-01-01';					

		$sql1 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL,$reviewdate);
	echo $sql1;						 
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();



		$no_rows = $pStatement->rowCount();
//		echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set[$k]['buID'] 	= $row['buID'];
				$this->result_set[$k]['ref_id'] 	= $row['ID'];
				$this->result_set[$k]['dueDate']			= $row['dueDate'];
				$this->result_set[$k]['ref'] 		= $row['reference'];
				$this->result_set[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set[$k]['select'] == 2){
					$this->result_set[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set[$k]['select'] == 1){
					$this->result_set[$k]['type'] = 'Tender';
				}else{
					$this->result_set[$k]['type'] = 'Quote';
				}
			
				$this->result_set[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
//			dump_array($this->result_set);
		//return $this->result_set;
		
		$cnt = count($this->result_set);
		 
         // echo "sdfasfds";
	


 		$this->email_subject = "Smart-ISO Blue Alert: Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result_1['forename'].' '.$result_1['surname']);
		

		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			
		$action_html = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: blue; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
				$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				$action_html .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set[$i]['title']."<br/>";
				$action_html .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set[$i]['ref']."<br/>";				
				$action_html .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html .= "<span class='normaltextbold'>Type</span> : ".$this->result_set[$i]['type']."<br/>";
				$action_html .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

			$this->result_set[$i]['email_body'] = $action_html;
						
	
		
		}
		
		$emails_cnt = count($this->result_set);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
             $sql4 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql4);

		$pStatement->execute();

		$result_2 = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}


			           
					  if($result_2['emailAddress']){
					  $header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
					 // // $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_2['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set[$i]['email_body'],$header);

				
					  }
					 
					

			} // end for
		}
	


//start yellow bob

	
		$optionObj	 		= new Option();
		$alert_mail_days_yellow 	= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj 			= null;

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

if ($alert_mail_days_yellow>$offset_day){
	$days = ($alert_mail_days_yellow-$offset_day);
	$reviewdate=date('Y-m-d',strtotime("+ ".$days." days"));
}
else{
	$days = ($offset_day-$alert_mail_days_yellow);
	$reviewdate=date('Y-m-d',strtotime("- ".$days." days"));
}

//$days = ($alert_mail_days_yellow+$offset_day);

 //$reviewdate=date('Y-m-d',strtotime("+ ".$days." days"));
	//$reviewdate		= '2010-01-01';					
		$sql12 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL,$reviewdate);

		$pStatement = $this->dbHand->prepare($sql12);
		$pStatement->execute();
//echo $sql;
		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ($no_rows) {
			$k = 0;
			//while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				//dump_array($row);
				$this->result_set_yellow[$k]['buID'] 	= $row['buID'];
				$this->result_set_yellow[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_yellow[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_yellow[$k]['ref'] 		= $row['reference'];
				$this->result_set_yellow[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_yellow[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_yellow[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_yellow[$k]['select'] == 2){
					$this->result_set_yellow[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_yellow[$k]['select'] == 1){
					$this->result_set_yellow[$k]['type'] = 'Tender';
				}else{
					$this->result_set_yellow[$k]['type'] = 'Quote';
				}
			
				$this->result_set_yellow[$k++]['reviewDueDate']			= $row['reviewDueDate'];
		
			}
		}

		
		$cnt = count($this->result_set_yellow);
		 
         
 		$this->email_subject = "Smart-ISO Yellow Alert: Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql13 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql13);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
		

		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_yellow[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			//dump_array($business_unit_arr);
						
		$action_html_yellow = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_yellow .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_yellow .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: yellow; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Yellow Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";

				$action_html_yellow .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				$action_html_yellow .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_yellow .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_yellow[$i]['title']."<br/>";
				$action_html_yellow .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_yellow[$i]['ref']."<br/>";				
				$action_html_yellow .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_yellow .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_yellow[$i]['type']."<br/>";
				$action_html_yellow .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_yellow[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_yellow .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_yellow .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
			

	$this->result_set_yellow[$i]['email_body'] = $action_html_yellow;
						
		
		
		}
		
		$emails_cnt = count($this->result_set_yellow);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
            $sql15 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_yellow[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql15);

		$pStatement->execute();

		$result_4 = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result_4);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}


				if($result_4['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result_4['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_yellow[$i]['email_body'],$header);

				
				}
					

			} // end for
		} 
		


//start red		
		
	
		$optionObj	 		= new Option();
		$alert_mail_days_red 	= $optionObj->getOption('_SU_EMAIL_REDMAIL');
		$optionObj 			= null;
       // echo $alert_mail_days;
//dump_array(GetDate());
$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

if ($alert_mail_days_red>$offset_day){
	$days = ($alert_mail_days_red-$offset_day);
	$reviewdate=date('Y-m-d',strtotime("+ ".$days." days"));
}
else{
	$days = ($offset_day-$alert_mail_days_red);
	$reviewdate=date('Y-m-d',strtotime("- ".$days." days"));
}

//$days = ($alert_mail_days_red+$offset_day);

 //$reviewdate=date('Y-m-d',strtotime("+ ".$days." days"));
					
		$sql23 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL,$reviewdate);
		
		$pStatement = $this->dbHand->prepare($sql23);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
			//while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_red[$k]['buID'] 	= $row['buID'];
				$this->result_set_red[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_red[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_red[$k]['ref'] 		= $row['reference'];
				$this->result_set_red[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_red[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_red[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_red[$k]['select'] == 2){
					$this->result_set_red[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_red[$k]['select'] == 1){
					$this->result_set_red[$k]['type'] = 'Tender';
				}else{
					$this->result_set_red[$k]['type'] = 'Quote';
				}
			
				$this->result_set_red[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
			
	
		
		$cnt = count($this->result_set_red);
		 
      
	


 		$this->email_subject = "Smart-ISO Red Alert: Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {

			//if ( $this->html_mail ) {
			
			  $sql24 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql24);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name		= ucwords($result['forename'].' '.$result['surname']);
	
		
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_red[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
						
		$action_html_red = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_red .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_red .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: red; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Red Alert</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";

				$action_html_red .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";

				$action_html_red .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_red .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_red[$i]['title']."<br/>";
				$action_html_red .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_red[$i]['ref']."<br/>";				
				$action_html_red .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_red .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_red[$i]['type']."<br/>";
				$action_html_red .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_red[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_red .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_red .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
			//} 
			

		$this->result_set_red[$i]['email_body'] = $action_html_red;
						
		
		
				
		
		}
		
		$emails_cnt = count($this->result_set_red);

		if ($emails_cnt) {
		
			for($i=0;$i<$emails_cnt;$i++) {
             $sql26 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = ".$this->result_set_red[$i]['who'],_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql26);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		 //dump_array($result);
			if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}


				if( $result['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$result['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_red[$i]['email_body'],$header);

				

				}
					
			} // end for
		}
//manager escalation bob
//manager escalation bob	
//manager escalation bob day 1
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));

	$days = ($alert_mail_days_mg+$offset_day);
	$reviewdateredMg=date('Y-m-d',strtotime("-".$days." days"));

										
			$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMg);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr[$k]['select'] == 2){
					$this->result_set_mgr[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr[$k]['select'] == 1){
					$this->result_set_mgr[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	
$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);

	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr[$i]['title']."<br/>";
				$action_html_mgr .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr[$i]['ref']."<br/>";				
				$action_html_mgr .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr[$i]['type']."<br/>";
				$action_html_mgr .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			
		$this->result_set_mgr[$i]['email_body'] = $action_html_mgr;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;


				@mail($recipients,$this->email_subject,$this->result_set_mgr[$i]['email_body'],$header);

				

			
					
		
		}
				

		
							

		
		

		}
		
//end of escalation 1 bob


//start escalation 2 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 1;
//$days = ($day - $alert_day+$offset_day);
 //$reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));




	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));



		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
	
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_1[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_1[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_1[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_1[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_1[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_1[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_1[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_1[$k]['select'] == 2){
					$this->result_set_mgr_1[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_1[$k]['select'] == 1){
					$this->result_set_mgr_1[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_1[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_1[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_1);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_1[$i]['who']);



		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
	
$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_1[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_1 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_1 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_1 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_1 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_1 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_1 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_1[$i]['title']."<br/>";
				$action_html_mgr_1 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_1[$i]['ref']."<br/>";				
				$action_html_mgr_1 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_1 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_1[$i]['type']."<br/>";
				$action_html_mgr_1 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_1[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_1 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_1 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_1[$i]['email_body'] = $action_html_mgr_1;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr_1[$i]['email_body'],$header);

				

			
					
		
		}
				

		
		
		
		

		}	
		//end of escalation 2 bob


//start escalation 3 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 2;
//ays = ($day - $alert_day+$offset_day);
 //eviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));

	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));

		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_2[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_2[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_2[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_2[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_2[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_2[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_2[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_2[$k]['select'] == 2){
					$this->result_set_mgr_2[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_2[$k]['select'] == 1){
					$this->result_set_mgr_2[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_2[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_2[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_2);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_2[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_2[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_2 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_2 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_2 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_2 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_2 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_2 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_2[$i]['title']."<br/>";
				$action_html_mgr_2 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_2[$i]['ref']."<br/>";				
				$action_html_mgr_2 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_2 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_2[$i]['type']."<br/>";
				$action_html_mgr_2 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_2[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_2 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_2 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_2[$i]['email_body'] = $action_html_mgr_2;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr_2[$i]['email_body'],$header);

				

			
					
		
		}
				

		
				

		
		

		}	

		//end of escalation 3 bob


//start escalation 4 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 3;
//ays = ($day - $alert_day+$offset_day);
//reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));



	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));


		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_3[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_3[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_3[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_3[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_3[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_3[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_3[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_3[$k]['select'] == 2){
					$this->result_set_mgr_3[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_3[$k]['select'] == 1){
					$this->result_set_mgr_3[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_3[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_3[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_3);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_3[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_3[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_3 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_3 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_3 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_3 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_3 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_3 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_3[$i]['title']."<br/>";
				$action_html_mgr_3 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_3[$i]['ref']."<br/>";				
				$action_html_mgr_3 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_3 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_3[$i]['type']."<br/>";
				$action_html_mgr_3 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_3[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_3 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_3 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_3[$i]['email_body'] = $action_html_mgr_3;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr_3[$i]['email_body'],$header);

				

			
					
		
		}
				


				

		
		

		}
				//end of escalation 4 bob


//start escalation 5 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 4;
//$days = ($day - $alert_day+$offset_day);
// $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));



	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));


		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_4[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_4[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_4[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_4[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_4[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_4[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_4[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_4[$k]['select'] == 2){
					$this->result_set_mgr_4[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_4[$k]['select'] == 1){
					$this->result_set_mgr_4[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_4[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_4[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_4);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_4[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();	
			$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_4[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_4 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_4 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_4 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_4 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_4 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_4 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_4[$i]['title']."<br/>";
				$action_html_mgr_4 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_4[$i]['ref']."<br/>";				
				$action_html_mgr_4 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_4 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_4[$i]['type']."<br/>";
				$action_html_mgr_4 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_4[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_4 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_4 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_4[$i]['email_body'] = $action_html_mgr_4;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
								
				@mail($recipients,$this->email_subject,$this->result_set_mgr_4[$i]['email_body'],$header);

		}
				
	}
	
					//end of escalation 5 bob


//start escalation 6 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 5;
//$days = ($day - $alert_day+$offset_day);
// $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));

	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));

		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_5[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_5[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_5[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_5[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_5[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_5[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_5[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_5[$k]['select'] == 2){
					$this->result_set_mgr_5[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_5[$k]['select'] == 1){
					$this->result_set_mgr_5[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_5[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_5[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_5);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_5[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_5[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_5 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_5 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_5 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_5 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_5 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_5 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_5[$i]['title']."<br/>";
				$action_html_mgr_5 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_5[$i]['ref']."<br/>";				
				$action_html_mgr_5 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_5 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_5[$i]['type']."<br/>";
				$action_html_mgr_5 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_5[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_5 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_5 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_5[$i]['email_body'] = $action_html_mgr_5;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr_5[$i]['email_body'],$header);

		}
				
	}

					//end of escalation 6 bob


//start escalation 7 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 6;
//$days = ($day - $alert_day+$offset_day);
// $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));

	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));

		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_6[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_6[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_6[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_6[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_6[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_6[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_6[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_6[$k]['select'] == 2){
					$this->result_set_mgr_6[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_6[$k]['select'] == 1){
					$this->result_set_mgr_6[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_6[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_6[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_6);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_6[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_6[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_6 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_6 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_6 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_6 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_6 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_6 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_6[$i]['title']."<br/>";
				$action_html_mgr_6 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_6[$i]['ref']."<br/>";				
				$action_html_mgr_6 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_6 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_6[$i]['type']."<br/>";
				$action_html_mgr_6 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_6[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_6 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_6 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_6[$i]['email_body'] = $action_html_mgr_6;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr_6[$i]['email_body'],$header);

		}
				
	}
	
						//end of escalation 7 bob


//start escalation 8 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 6;
//$days = ($day - $alert_day+$offset_day);
// $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));

	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));

		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_7[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_7[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_7[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_7[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_7[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_7[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_7[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_7[$k]['select'] == 2){
					$this->result_set_mgr_7[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_7[$k]['select'] == 1){
					$this->result_set_mgr_7[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_7[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_7[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_7);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_7[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
				$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();
		
		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_7[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_7 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_7 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_7 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_7 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_7 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_7 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_7[$i]['title']."<br/>";
				$action_html_mgr_7 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_7[$i]['ref']."<br/>";				
				$action_html_mgr_7 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_7 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_7[$i]['type']."<br/>";
				$action_html_mgr_7 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_7[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_7 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_7 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->result_set_mgr_7[$i]['email_body'] = $action_html_mgr_7;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;

				@mail($recipients,$this->email_subject,$this->result_set_mgr_7[$i]['email_body'],$header);

		}
				
	}
	
							//end of escalation 8 bob


//start escalation 9 bob		
			$optionObj	 		= new Option();	
		 $alert_mail_days_mg 	= $optionObj->getOption('_SU_EMAIL_MGTESC');
		$optionObj 			= null;
       // echo $alert_mail_days;
	
	$date = date("y-m-d");
	//$date = '2012-10-02';
list($year,$month,$day) = (explode("-",$date));

$date = date("y-m-d");
list($year,$month,$day) = (explode("-",$date));
$alert_day = $alert_mail_days_mg + 7;
//$days = ($day - $alert_day+$offset_day);
// $reviewdateredMgnext=date('Y-m-d',strtotime("-".$alert_day." days"));


	$days = ($alert_day+$offset_day);
	$reviewdateredMgnext=date('Y-m-d',strtotime("-".$days." days"));

		$sql34 = sprintf("SELECT contractName,shortTermOrTender,reference,reviewDueDate,contractManagerID,buID FROM %s.contract WHERE enddate>getdate() and reviewDueDate = '%s'",_DB_OBJ_FULL, $reviewdateredMgnext);
			
		$pStatement = $this->dbHand->prepare($sql34);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		//echo $no_rows ;
		$row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if ($no_rows) {
			$k = 0;
		//	while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
			foreach($row1 as $row){
				$this->result_set_mgr_8[$k]['buID'] 	= $row['buID'];
				$this->result_set_mgr_8[$k]['ref_id'] 	= $row['ID'];
				$this->result_set_mgr_8[$k]['dueDate']			= $row['dueDate'];
				$this->result_set_mgr_8[$k]['ref'] 		= $row['reference'];
				$this->result_set_mgr_8[$k]['select'] 		= $row['shortTermOrTender'];
				$this->result_set_mgr_8[$k]['who'] 	= $row['contractManagerID'];
				$this->result_set_mgr_8[$k]['title'] 	= $row['contractName'];
	     
				if($this->result_set_mgr_8[$k]['select'] == 2){
					$this->result_set_mgr_8[$k]['type'] = 'OJEU Notices';
				}elseif($this->result_set_mgr_8[$k]['select'] == 1){
					$this->result_set_mgr_8[$k]['type'] = 'Tender';
				}else{
					$this->result_set_mgr_8[$k]['type'] = 'Quote';
				}
			
				$this->result_set_mgr_8[$k++]['reviewDueDate']			= $row['reviewDueDate'];
				
			}
		}
		
	
		$cnt = count($this->result_set_mgr_8);
		 

	


 		$this->email_subject = "Smart-ISO Management Escalation Contract Review pending.";

		for ($i=0;$i<$cnt;$i++) {
	
	$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->result_set_mgr_8[$i]['who']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);
			
		$sql36 =sprintf("select P.participantID,P.forename,P.surname,P.emailAddress from %s.participant_database P inner join %s.organisation_positions O on P.participantID = O.participantID inner join %s.participant_meta_data M on O.buID=M.reportToBuID where  M.participantID=%d AND (positionName='Manager' OR positionName='CEO')",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$val['participantID']);


		$pStatement = $this->dbHand->prepare($sql36);

		$pStatement->execute();

		$val = $pStatement->fetch(PDO::FETCH_ASSOC);

		$name		= ucwords($val['forename'].' '.$val['surname']);
	
	
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->result_set_mgr_8[$i]['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();
			$action_html_mgr_8 = "<html><head><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html_mgr_8 .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html_mgr_8 .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='border: 1px solid #ccc;background-color: #330000; padding: 0.5em; width: 100%;height:20px; color: white; font-weight:bold'>Management Escalation</div><br/><span class='normaltext'>Hi ".ucwords($name).",<br/><br/>";
								$action_html_mgr_8 .= "In Review following Contracts is overdue upon the date shown below. You are getting this email because you are manager of the business unit ".$business_unit_arr['buName']."<br/><br/>The details are below :<br/>";

				$action_html_mgr_8 .= "<br/><span class='normaltextbold'>Domain</span>: ".$this->domain_url."<br/><br/>";
				$action_html_mgr_8 .= "<br/><span class='normaltextbold'>Contract Title</span>: ".$this->result_set_mgr_8[$i]['title']."<br/>";
				$action_html_mgr_8 .= "<span class='normaltextbold'>Reference</span>: ".$this->result_set_mgr_8[$i]['ref']."<br/>";				
				$action_html_mgr_8 .= "<span class='normaltextbold'>Business unit</span>: ".$business_unit_arr['buName']."<br/>";
				$action_html_mgr_8 .= "<span class='normaltextbold'>Type</span> : ".$this->result_set_mgr_8[$i]['type']."<br/>";
				$action_html_mgr_8 .= "<span class='normaltextbold'>Review Due Date</span> : ".$this->result_set_mgr_8[$i]['reviewDueDate']."<br/><br/>";					
				
				


				$action_html_mgr_8 .= "Support Smart-ISO&trade;<br/><br/>";
				$action_html_mgr_8 .= "You are receiving this email because you are or have been a user of Smart-ISO&trade;. <br/>
Copyright � 2012 Smart-ISO&trade;. All rights reserved.</span></div></body></html>";
				
		
			

		$this->action_html_mgr_8[$i]['email_body'] = $action_html_mgr_8;
	

		
		if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					}

		

				if( $val['emailAddress']){
				$header .= "From: smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">";
				// $cc = ''; // 'gurveer_2k1@hotmail.com';
				$recipients =$val['emailAddress'].", ".$cc;
				@mail($recipients,$this->email_subject,$this->result_set_mgr_8[$i]['email_body'],$header);

		}
				
	}
	
	}



		
}
?>