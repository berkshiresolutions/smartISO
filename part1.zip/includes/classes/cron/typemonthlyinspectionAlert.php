<?php
///error_reporting(0);
class MonthlyinspectionAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         //echo $classname;
		// exit;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {
	
	$this->smarty = new Smarty;
		$this->smarty->template_dir = _THEME_FOLDERPATH._THEME.'/templates';
		$this->smarty->compile_dir = _THEME_FOLDERPATH._THEME.'/templates_c';
		//$smarty->cache_dir = _THEME_FOLDER._THEME.'/cache';
		$this->smarty->config_dir = _MYINCLUDES.'/smarty_configs';

	$today = date('Y-m-d');
	$piec = explode("-",$today);
	
	if($piec[1] == '1'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	if($piec[1] == '2'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'28'; 
	$today_duedate  = $piec[1].'/'.'28'.'/'.'2013'; 
	}
	if($piec[1] == '3'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	if($piec[1] == '4'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'30'; 
	$today_duedate  = $piec[1].'/'.'30'.'/'.'2013'; 
	}
	if($piec[1] == '5'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	if($piec[1] == '6'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'30'; 
	$today_duedate  = $piec[1].'/'.'30'.'/'.'2013'; 
	}
	if($piec[1] == '7'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	if($piec[1] == '8'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	if($piec[1] == '9'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'30'; 
	$today_duedate  = $piec[1].'/'.'30'.'/'.'2013'; 
	}
	if($piec[1] == '10'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	if($piec[1] == '11'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'30'; 
	$today_duedate  = $piec[1].'/'.'30'.'/'.'2013'; 
	}
	if($piec[1] == '12'){
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_duedate  = $piec[1].'/'.'31'.'/'.'2013'; 
	}
	
	$today_s  = '2013'.'-'.$piec[1].'-'.'01'; 
	
	
	
$vehicleObj = new Vehicle();
$vehicleObj->setVehicleInfo($cid,"");
$fleet = $vehicleObj->displayFleet();
//dump_array($fleet);
//exit;
	//exit;
	 $sql = sprintf("SELECT * FROM %s.perform_vehicle_monthly ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//dump_array($resultSet);
		//if($resultSet){
		
			//foreach ($resultSet as $key1 => $value1){
					//foreach ($resultSet as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
						//if($resultSet[$key1]['vID'] == $resultSet[$key2]['vID'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								//unset($resultSet[$key1]);
								
						//}
					//}
					//dump_array($child_arr);
				//}
		
		//}else{
		
		$sql1 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2' ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql1);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($resultSet);
		//exit;
		foreach ($resultSet as $key1 => $value1){
					foreach ($resultSet as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
						if($resultSet[$key1]['vID'] == $resultSet[$key2]['vID'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($resultSet[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
		
		//}
		
		
		
		
		
	
		
	
$resultSet =		array_values($resultSet);
//dump_array($resultSet);
		
		foreach($resultSet as $val){
		
		$vehicleObj = new Vehicle();
		
		$vehicleObj->setVehicleInfo($val['vID'],'');
	  
	  $data = $vehicleObj->viewVehicle();
	 
			$ac = $vehicleObj->viewVehicleactionIDhjhjgfg();

		
		$sql = sprintf("SELECT * FROM %s.vehicle WHERE ID = ".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$data = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		if($data['vehicleMake'] == '0'){
	
	$data['vehicleMake'] = '-';
	
	}
	if($data['vehicleModel'] == '0'){
	
	$data['vehicleModel'] = '-';
	
	}
	
		//dump_array($data);
		$pieces = explode(" ",$data['temporaryOwnerName']);
			$whoAU = explode(" ",$data['permanentOwnerName']);
			
			$this->f = $pieces[0];
			$this->l = $pieces[1];
			
			$this->ft = $whoAU[0];
			$this->lt = $whoAU[1];
			
			$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE forename = '".$this->f."' AND surname = '".$this->l."'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$data_1 = $stmt->fetch(PDO::FETCH_ASSOC);
		//dump_array($data_1);
		//exit;
		$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE forename = '".$this->ft."' AND surname = '".$this->lt."'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$data_2 = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$sql5 = sprintf("SELECT * FROM %s.perform_vehicle_monthly  type = '1' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		if($reslist){
		$reslist = $reslist;
		}else{
			$sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2'   AND type = '1' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		}
		foreach($reslist as $value_w){
		 
		if($data_1['participantID']){
		//echo "dfggfd";
		//exit;
		 $sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','test',".$data_1['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
			//$lastId = $this->dbHand->lastInsertId();

			
		
		}else{
		
				$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_2['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
		}
		
		}
		//dump_array($reslist);
		//exit;
		$sql6 = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE  type = '2' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql6);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		if($reslist1){
		$reslist1 = $reslist1;
		}else{
			$sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2' AND type = '2' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		}
		
		foreach($reslist1 as $value_w){
		 
		if($data_1['participantID']){
		//echo "dfggfd";
		//exit;
		$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_1['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
			//$lastId = $this->dbHand->lastInsertId();

			
		
		}else{
		
				$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_2['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
		}
		
		}
		
		
		$sql7 = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE  type = '3' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql7);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist2 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if($reslist2){
		$reslist2 = $reslist2;
		}else{
			$sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2'  AND type = '3' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist2 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		}
		foreach($reslist2 as $value_w){
		 
		if($data_1['participantID']){
		//echo "dfggfd";
		//exit;
		$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_1['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
			//$lastId = $this->dbHand->lastInsertId();

			
		
		}else{
		
				$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_2['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
		}
		
		}
	
		
		$sql8 = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE  type = '4' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql8);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist3 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if($reslist3){
		$reslist3 = $reslist3;
		}else{
			$sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2'  AND type = '4' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist3 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		}
		foreach($reslist3 as $value_w){
		 
		if($data_1['participantID']){
		//echo "dfggfd";
		//exit;
		$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_1['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
			//$lastId = $this->dbHand->lastInsertId();

			
		
		}else{
		
				$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_2['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
		}
		
		}
		
		$sql9 = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE  type = '5' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql9);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist4 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		if($reslist4){
		$reslist4 = $reslist4;
		}else{
			$sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2'  AND type = '5' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist4 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		}
		foreach($reslist4 as $value_w){
		 
		if($data_1['participantID']){
		//echo "dfggfd";
		//exit;
		$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_1['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

			$lastId = customLastInsertId( $this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
			//$lastId = $this->dbHand->lastInsertId();

			
		
		}else{
		
				$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_2['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
		}
		
		}
		$sql10 = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE  type = '0' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql10);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist5 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		if($reslist5){
		$reslist5 = $reslist5;
		}else{
			$sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = '2'   AND type = '0' AND vID =".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist5 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		}
		foreach($reslist5 as $value_w){
		 
		if($data_1['participantID']){
		//echo "dfggfd";
		//exit;
		$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_1['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
			//$lastId = $this->dbHand->lastInsertId();

			
		
		}else{
		
				$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('vehicleMonthly','". $value_w['name']."',".$data_2['participantID'].",".$fleet['participantID'].",'".$today_e."',0,0,0,0)",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		

			$lastId = customLastInsertId( $this->dbHand,'actions','ID');
		
		$sql14 = sprintf("UPDATE %s.vehicle_daily_inspection SET actionId = ".$lastId."  WHERE ID = ".$value_w['ID']
						,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql14);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
		
		
		}
		
		}
		
		$this->smarty->assign('emailTitle','smart-ISO&trade; Mail');				// E-mail HTML title
		$this->smarty->assign('emailColour','#808080');			// E-mail Background heading Colour
		$this->smarty->assign('emailTxtColour','#FFFFFF');		// E-mail Text heading Colour
		$this->smarty->assign('heading','smart-ISO&trade; Mail');					// Heading
		$this->smarty->assign('twoColData',$reslist);
		$this->smarty->assign('twoColData1',$reslist1);
		$this->smarty->assign('twoColData2',$reslist2);
		$this->smarty->assign('twoColData3',$reslist3);
		$this->smarty->assign('twoColData4',$reslist4);
		$this->smarty->assign('twoColData5',$reslist5);
		
		$this->smarty->assign('singleColData',$this->singleColData);		// Single column data
		$this->smarty->assign('rawData',$this->rawData);					// Raw Data
		$this->smarty->assign('contact',$this->contact);					// Contact E-mail / phone (if e-mail needs to be mailto: link)
		$this->smarty->assign('textcss','table { max-width: 800px; } table tbody { min-height: 200px; } table td[colspan="7"] { width: 50%; }');
		$this->smarty->assign('make',$data['vehicleMake']);
		$this->smarty->assign('name',$this->name);
		$this->smarty->assign('fre','Monthly');
		$this->smarty->assign('type','External');
		$this->smarty->assign('model',$data['vehicleModel']);
		$this->smarty->assign('comment',$this->comment);
		$this->smarty->assign('ref',$data['uniqueReference']);// Text/CSS
		$this->smarty->assign('date',$today_duedate);	
        //$this->smarty->assign('date',date($this->datefmt));			// Date
		$this->smarty->assign('year',date('Y'));							// Automatic
		$this->smarty->assign('domain','smart-test.smart-iso.net');				// Automatic
		
		echo $email_body = $this->smarty->fetch('emailCronMonthly.tpl');
		  $subject = "smart-ISO action for Smart Fleet Inspection";
		  $header = "Content-Type: text/html; charset=UTF-8\r\n";
			$header .= "From:<no-reply@".$_SERVER['HTTP_HOST'].">";
			echo $data_1['emailAddress'];
			echo $data_2['emailAddress'];
			echo $fleet['emailAddress'];
			
			if($data_1['emailAddress']){
				@mail($data_1['emailAddress'],$subject,$email_body,$header);
			}else{
				@mail($data_2['emailAddress'],$subject,$email_body,$header);
			}
		
		
		
		//@mail($fleet['emailAddress'],$subject,$email_body,$header);
		//exit;
		//dump_array($reslist2);
		
		 /*$subject = "smart-ISO action for Smart Fleet Inspection";
				$action_html = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>";
				$action_html .= "<html  xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'><head><title>Smart-iso - Mail</title><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";
				$action_html .= "<div style='width:760px;border: 2px solid #808080; padding:0em; margin:0em;'>";
				$action_html .= "<body style='font-family: arial,sans-serif,verdana; font-size:12px; color: #000; padding:1em'><br/><br/><div style='width:80%; margin:0 auto'><div style='padding: 0.4em; background-color:#808080 ; font-size:2em;color: #fff; font-weight: bold; margin: 1p'>smart-ISO&trade; Mail</div><br/><span class='normaltext'>Dear <b>".ucwords($data['temporaryOwnerName'])."</b>,<br/><br/>";
				$action_html .= "<p>Smart Fleet inspection action is pending for you. The Details are below:</p>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";
					$action_html .= "<table style='margin: 1.2em 0em'>";
					$action_html .= "<tr>";
					$action_html .= "<th style='padding:0.4em' align='left' >Domain</th> <td  style='width: 58%;padding:0.4em'>".$_SERVER['SERVER_NAME']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Reference</th> <td  style='width: 58%;padding:0.4em'>".$data['uniqueReference']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Vehicle Make</th> <td  style='width: 58%;padding:0.4em'>".$data['vehicleMake']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Vehicle Model</th> <td  style='width: 58%;padding:0.4em'>".$data['vehicleModel']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Frequency</th> <td  style='width: 58%;padding:0.4em'>Daily</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >External</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Fluids</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist1 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Internal</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist2 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Functional</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist3 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Equipment</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist4 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Custom</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist5 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					
					
			
					
					
					$action_html .= "<tr><td colspan='2'>&nbsp;</td></tr>";
					$action_html .= "<tr>";
					$action_html .= "<td colspan='2'>";
					$action_html .= "Regards<br/>";
					$action_html .= "<b>Smart-ISO&trade; Support</b>";
					$action_html .= "</td>";
				    $action_html .= "</tr>";
					$action_html .= "</table>";
					
					//$action_html .= "Regards,<br/><b>smart-ISO� Support</b><br/><br/>";
					$action_html .= "<div style='width:100%; margin:0 auto'><div style='background-color: #eee; font-size:11px; padding:1em; height:25px;'>You are receiving this email because you are or have been a user of smart-ISO&trade;.
Copyright&copy; 2013 smart-ISO&trade;. All rights reserved.</div></span></div></body></html>";
					$action_html .= "</div>";
echo $email['email_body'] = $action_html;
			$header = "Content-Type: text/html; charset=UTF-8\r\n";
			$header .= "From:<no-reply@".$_SERVER['HTTP_HOST'].">";
			
		
		@mail($data_1['emailAddress'],$subject,$email['email_body'],$header);
			
			
			 $subject = "smart-ISO action for Smart Fleet Inspection";
				$action_html = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>";
				$action_html .= "<html  xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'><head><title>Smart-iso - Mail</title><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";
				$action_html .= "<div style='width:760px;border: 2px solid #808080; padding:0em; margin:0em;'>";
				$action_html .= "<body style='font-family: arial,sans-serif,verdana; font-size:12px; color: #000; padding:1em'><br/><br/><div style='width:80%; margin:0 auto'><div style='padding: 0.4em; background-color:#808080 ; font-size:2em;color: #fff; font-weight: bold; margin: 1p'>smart-ISO&trade; Mail</div><br/><span class='normaltext'>Dear <b>".ucwords($data['temporaryOwnerName'])."</b>,<br/><br/>";
				$action_html .= "<p>Smart Fleet inspection action is pending for you. The Details are below:</p>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";
					$action_html .= "<table style='margin: 1.2em 0em'>";
					$action_html .= "<tr>";
					$action_html .= "<th style='padding:0.4em' align='left' >Domain</th> <td  style='width: 58%;padding:0.4em'>".$_SERVER['SERVER_NAME']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Reference</th> <td  style='width: 58%;padding:0.4em'>".$data['uniqueReference']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Vehicle Make</th> <td  style='width: 58%;padding:0.4em'>".$data['vehicleMake']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Vehicle Model</th> <td  style='width: 58%;padding:0.4em'>".$data['vehicleModel']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Frequency</th> <td  style='width: 58%;padding:0.4em'>Daily</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >External</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Fluids</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist1 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Internal</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist2 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Functional</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist3 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Equipment</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist4 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Custom</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist5 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					
					
			
					
					
					$action_html .= "<tr><td colspan='2'>&nbsp;</td></tr>";
					$action_html .= "<tr>";
					$action_html .= "<td colspan='2'>";
					$action_html .= "Regards<br/>";
					$action_html .= "<b>Smart-ISO&trade; Support</b>";
					$action_html .= "</td>";
				    $action_html .= "</tr>";
					$action_html .= "</table>";
					
					//$action_html .= "Regards,<br/><b>smart-ISO� Support</b><br/><br/>";
					$action_html .= "<div style='width:100%; margin:0 auto'><div style='background-color: #eee; font-size:11px; padding:1em; height:25px;'>You are receiving this email because you are or have been a user of smart-ISO&trade;.
Copyright&copy; 2013 smart-ISO&trade;. All rights reserved.</div></span></div></body></html>";
					$action_html .= "</div>";
$email['email_body'] = $action_html;
			$header = "Content-Type: text/html; charset=UTF-8\r\n";
			$header .= "From:<no-reply@".$_SERVER['HTTP_HOST'].">";
			
		
		@mail($data_2['emailAddress'],$subject,$email['email_body'],$header);
			
			//foreach($fleet as $value){
			
			$subject = "smart-ISO action for Smart Fleet Inspection";
				$action_html = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>";
				$action_html .= "<html  xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'><head><title>Smart-iso - Mail</title><link href='smart-test.smart-iso.net/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='smart-test.smart-iso.net/scripts/nextGenStyle.css' rel='stylesheet' /></head>";
				$action_html .= "<div style='width:760px;border: 2px solid #808080; padding:0em; margin:0em;'>";
				$action_html .= "<body style='font-family: arial,sans-serif,verdana; font-size:12px; color: #000; padding:1em'><br/><br/><div style='width:80%; margin:0 auto'><div style='padding: 0.4em; background-color:#808080 ; font-size:2em;color: #fff; font-weight: bold; margin: 1p'>smart-ISO&trade; Mail</div><br/><span class='normaltext'>Dear <b>".ucwords($fleet['forename'])."</b>,<br/><br/>";
				$action_html .= "<p>Smart Fleet inspection action is pending for you. You are an AU responsible for this action.  The Details are below:</p>";

			//	$action_html .= "In Review following Contracts is due upon the date shown below <br/><br/>Here are the details :<br/>";
					$action_html .= "<table style='margin: 1.2em 0em'>";
					$action_html .= "<tr>";
					$action_html .= "<th style='padding:0.4em' align='left' >Domain</th> <td  style='width: 58%;padding:0.4em'>".$_SERVER['SERVER_NAME']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Reference</th> <td  style='width: 58%;padding:0.4em'>".$data['uniqueReference']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Vehicle Make</th> <td  style='width: 58%;padding:0.4em'>".$data['vehicleMake']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Vehicle Model</th> <td  style='width: 58%;padding:0.4em'>".$data['vehicleModel']."</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					$action_html .= "<th  style='padding:0.4em' align='left' >Frequency</th> <td  style='width: 58%;padding:0.4em'>Daily</td>";
					$action_html .= "</tr>";
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >External</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Fluids</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist1 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Internal</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist2 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Functional</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist3 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Equipment</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist4 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					$action_html .= "<tr>";
					
					$action_html .= "<td  colspan='2'  style='padding:0.4em;background-color:#808080;border:1px solid #808080;' align='left' >Custom</td> ";
					$action_html .= "</tr>";
					//dump_array($reslist);
					foreach($reslist5 as $list_val){
					
					
					$action_html .= "<tr style='border:1px solid #808080;'>";
					$action_html .= "<td  style='padding:0.4em;border:1px solid #808080;width: 70%;'  align='left' >".$list_val['name']."</td> <td  style='width: 20%;border:1px solid grey;padding:0.4em'>".format_date($today)."</td>";
					$action_html .= "</tr>";
					
					}
					
					
					
			
					
					
					$action_html .= "<tr><td colspan='2'>&nbsp;</td></tr>";
					$action_html .= "<tr>";
					$action_html .= "<td colspan='2'>";
					$action_html .= "Regards<br/>";
					$action_html .= "<b>Smart-ISO&trade; Support</b>";
					$action_html .= "</td>";
				    $action_html .= "</tr>";
					$action_html .= "</table>";
					
					//$action_html .= "Regards,<br/><b>smart-ISO� Support</b><br/><br/>";
					$action_html .= "<div style='width:100%; margin:0 auto'><div style='background-color: #eee; font-size:11px; padding:1em; height:25px;'>You are receiving this email because you are or have been a user of smart-ISO&trade;.
Copyright&copy; 2013 smart-ISO&trade;. All rights reserved.</div></span></div></body></html>";
					$action_html .= "</div>";
$email['email_body'] = $action_html;
			$header = "Content-Type: text/html; charset=UTF-8\r\n";
			$header .= "From:<no-reply@".$_SERVER['HTTP_HOST'].">";
			
		
		@mail($fleet['emailAddress'],$subject,$email['email_body'],$header);*/
		
		
		
		
			
		
		}
		
	}



		
}
?>