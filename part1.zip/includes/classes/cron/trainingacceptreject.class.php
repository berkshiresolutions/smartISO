<?php
 /**
  $Id: dseModEmail.class.php,v 3.12 Thursday, January 27, 2011 5:51:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Client
  * @subpackage Report
  * @since  Monday, August 16, 2010 1:45:34 PM>
  */


require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

class TrainingAcceptReject
{
	private $dbHand;

	public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}



	public function updateTrainees() {


	$mbox = imap_open("{imap.europe.secureserver.net:143}", "info@smart-iso.com", "RSAfebI4");

//	$headers = imap_headers($mbox);

	$partObj 	= SetupGeneric::useModule('Participant');

$n_msgs = imap_num_msg($mbox);
      for ($i=1; $i<=$n_msgs; $i++) {
          $header = imap_header($mbox, $i);
	    $body = imap_body($mbox, $i);
//var_dump( $body );

//rsa emails have 64 bit encryption bob
$datacal=explode("Content-Transfer-Encoding: base64",$body);
//echo $datacal[1];
if ($datacal[1])
$refData=( base64_decode($datacal[1],false));
else
$refData=$body;
          $subject= $header->subject;
          $from = $header->from;
          $host=$from[0]->host;
          $mail=$from[0]->mailbox;
          $email=$mail."@".$host;
          $func=explode(":",$subject);
          
         echo $func[0];
         
         if ($func[0]=='Accepted')
             $state=128;
         elseif ($func[0]=='Rejected') 
               $state=32;
		elseif ($func[0]=='Declined') 
               $state=32;
           else
                 $state=1;
             
          $uid=explode("UID:",$refData);

          $ids=explode("f",$uid[1]);

          $sql=sprintf("update %s.course_assignment_participant_link set status=status | %d where participant_id =%d and course_assignment_id=%d",_DB_OBJ_FULL,$state,$ids[0],$ids[1]);

          $pStatement = $this->dbHand->prepare($sql);

          $pStatement->execute();

           $this->sendResponseEmail($ids[0],$ids[1],$func[0]);
 
 }



for ($i=1; $i<=$n_msgs; $i++)
imap_delete($mbox, 1);

	imap_expunge($mbox);
	imap_close($mbox);
	}
        
        public function updateConfirm() {
        $date=date("Y-m-d")  ;  
        $sql=sprintf("update %s.trng_assign_course set completeDate='%s' , progress_status = (progress_status | 24) where date_start <'%s' and progress_status between 4 and 7",_DB_OBJ_FULL,$date,$date);
        
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
		echo $sql;
     }


        public function reminderEmails() {
			$option=new Option;
			$dateinterval=$option->getOption('_SU_TRAINING_EMAIL_TRAINEE_INT');
			$days=$option->getOption('_SU_TRAINING_EMAIL_TRAINEE')*-1;

			$date=date("Y-m-d")  ;  
//$sql=sprintf("select C.ID,L.participant_id from %s.course_assignment_participant_link L inner join %s.trng_assign_course C on L.course_assignment_id=C.ID where dateadd(%s,%d,date_start) ='%s' and progress_status between 4 and 7",_DB_OBJ_FULL,_DB_OBJ_FULL,$dateinterval,$days,$date);
			$sql=sprintf("select C.ID from %s.trng_assign_course C  where dateadd(%s,%d,date_start) ='%s' and progress_status between 4 and 7",_DB_OBJ_FULL,$dateinterval,$days,$date);

			$pStatement = $this->dbHand->prepare($sql);
			$pStatement->execute();
			$result = $pStatement->fetchAll(PDO::FETCH_ASSOC); 
			
			foreach($result as $row){
				$sqlP=sprintf("select participant_id,course_assignment_id from %s.course_assignment_participant_link  where course_assignment_id=%d and (status & 32) != 32",_DB_OBJ_FULL,$row["ID"]);
				$pStatementP = $this->dbHand->prepare($sqlP);
				$pStatementP->execute();
				$resultP = $pStatementP->fetchAll(PDO::FETCH_ASSOC); 
	
				foreach($resultP as $rowP){
				
					$this->sendResponseEmail($rowP["participant_id"],$rowP["course_assignment_id"],'Reminder') ;
					}
				}  
			}
     
      public function sendResponseEmail($participant_id,$course_id,$responseType=0) {
         //$trainingMgrObj = DataProxy::getModelData('core/newparticipant',$this->getTrainingManager());
        $sql=sprintf("select * from %s.trng_assign_course where ID= '%d'",_DB_OBJ_FULL,$course_id);
        //var_dump($trainingMgrObj);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);   

		$tm=$result["train_manager"];

        $participantObj = SetupGeneric::useModule('Participant');
		$participantObj->setItemInfo(array('id'=>$tm));
	
		$details = $participantObj->displayItemById();
		$detailsTD = array(
			'displayname' => ucwords($details['forename'].' '.$details['surname']),
			'email' => $details['emailAddress']
		);
		$participantObj->setItemInfo(array('id'=>$participant_id));
	
		$details = $participantObj->displayItemById();
                        
		$detailsP = array(
				'displayname' => ucwords($details['forename'].' '.$details['surname']),
				'email' => $details['emailAddress']
		);
			
			
			

           // $participantObj = Dataproxy::getModelData('core/newparticipant',$participant_id);
            if ($responseType == "Accepted"){
			     $title='Course Assignment Response';
                 $description= $detailsP['displayname']. " has accepted this course attendance request";
				 $emailTo=$detailsTD['email'];
				 $emailName=$detailsTD['displayname'];
            }
      
            elseif ($responseType == "Declined"){
				 $title='Course Assignment Response';
                 $description= $detailsP['displayname']. " has rejected this course attendance request";
				 $emailTo=$detailsTD['email'];
				 $emailName=$detailsTD['displayname'];
            }
			
            elseif ($responseType == "Reminder"){
				 $title='Course Reminder';
                 $description= "This is a reminder for the above course";
				 $emailTo=$detailsP['email'];
				 $emailName=$detailsP['displayname'];
            }

   
            else{
               $title='Course Assignment Response';
               $description= " Problem"; 
			   $emailTo="bobabery@btinternet.com";
			 $emailName="Bob";
            }

            $data = array(
                'fromName' => 'System Email',
                'from' => 'system@smart-iso.com',
                'toName' => $emailName,
                'to' => $emailTo,
                'subject' => 'smart-TRAIN - '.$title,//.' - '.$this->reference,
                'description' => $description,//$this->description, // could add description
                'location' => 'Room. '.$this->roomNo
            );

				$colourBg = '#808080';
				$colourTxt = '#FFFFFF';
	

		$emailContent = new newEmail(); // JUST THE CONTENT BUILDER
		$emailer = new eMailer('',5); // SET TO RETRY 5 TIMES TO SEND NOLOGO, NO DEBUG
		$twoColData = array(
			'actionid'=>array('left'=>'<strong>Reference:</strong>','right'=>$result['reference']),
			'assignedto'=>array('left'=>'<strong>Title:</strong>','right'=>$result['title']),
			'authorizing1'=>array('left'=>'<strong>Start Date:</strong>','right'=>$result['date_start']),
			'due'=>array('left'=>'<strong>Instructor:</strong>','right'=>$result['instructor']), 
            'roomNo'=> array('left' => '<strong>Room Name:</strong>','right' => $result['roomNo']),
			'traingmanager'=> array('left' => '<strong>Training Manager:</strong>','right' => $detailsTD['displayname'])
	);




                $stdData = array(
                    'emailColour'=>$colourBg,
                    'emailTxtColour'=>$colourTxt,
                    'emailTitle'=>'Training',
					'sentence'=>'',
                    'singleColData'=>array(
                            'summary'=>'<p><strong>Summary</strong><br>'.$description.'</p>',
                            'emailtext'=>'<p>'.$emailtext.'</p>'
                    ),
                    'twoColData'=>$twoColData
                );

                foreach($this->decorate as $field=>$values) {
                    if(is_array($stdData[$field])) { // add to lists of data
                        $stdData[$field] = array_merge($stdData[$field],$values);
                    } 
					
					else { // overwrite named values
                        $field = $values;
                    }
                }
				
                $thecontent = $emailContent->display($stdData );

          //  echo   $thecontent ;
            
           
           
            require_once($_SERVER['DOCUMENT_ROOT'].'/../includes/vendors/PHPMailer/class.phpmailer.php');
            require_once($_SERVER['DOCUMENT_ROOT'].'/../includes/vendors/PHPMailer/extras/EasyPeasyICS.php');

            $mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch
            $mail->IsSMTP(); // telling the class to use SMTP
            try {
                $mail->SMTPAuth   = true;									// enable SMTP authentication
                //$mail->Host       = "smtpout.europe.secureserver.net";		// sets the SMTP server
                //$mail->Port       = 80;										// set the SMTP port for the server
                //$mail->Username   = "rsa@smart-iso.com";					// username
                //$mail->Password   = "RSAfebI4";							// password

                                	$mail->Host       = "smtp.hs20.net";		// sets the SMTP server			
                        $mail->Port       = 587;
                        $mail->Username   = "info@smart-iso.com";					// username
			$mail->Password   = "x[61)r]1Ni";							// password
                //set from
                $mail->SetFrom('info@smart-iso.com', 'smart-ISO System Mailer');
                $mail->AddAddress($data['to'], $data['toName']);



                $mail->Body = '<p>Dear '.$tmMgrName.',</p>';
                $mail->Body = '<p>'.$thecontent.'</p>';
                $mail->Body .= '<p>Best Regards,</p>';

                $mail->Body .= '';
                $mail->AltBody .= 'This Message should be opened with a HTML compatible Email Client...';
                $mail->Subject .= $data['subject'];
                $mail->IsHTML(true);
                $mail->Send();
			
            } catch (phpmailerException $e) {
		echo $e->errorMessage(); //Pretty error messages from PHPMailer
            } catch (Exception $e) {
		echo $e->getMessage(); //Boring error messages from anything else!
            }
                
                 
        }
		
		function getTrainingManager() {
		$authObj = SetupGeneric::useModule('AuthorizedUser');
		return $authObj->getIssuerPermission('perm_mgr_train');
		}
}