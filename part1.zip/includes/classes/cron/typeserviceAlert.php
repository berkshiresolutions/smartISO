<?php
class ServiceAlert {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $emaildata;
	protected $email_subject;
	protected $action_url;
	protected $domain_url;

	public function __construct($p_module,$domain) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->module_name 	= $p_module;
		$this->domain_url 	= $domain;
		$p_module 			= str_replace(' ','',$p_module);
		$this->module 		= $p_module;
		$this->days 		= $this->get_days();
        //echo $this->module;
		$classname 			= $this->module;
         //echo $classname;
		// exit;
		include_once "moduleContract.php";
         //echo "module".$this->module.'.php';
		$this->oactype 		= new $classname($this->days);
            // echo $this->oactype;
		$this->action_url	= "/action_tracker/non_conf_inc.php";
		// echo $this->oactype;
		
		return $this->oactype;
	}

	public function get_days() {
	
	$this->smarty = new Smarty;
		$this->smarty->template_dir = _THEME_FOLDERPATH._THEME.'/templates';
		$this->smarty->compile_dir = _THEME_FOLDERPATH._THEME.'/templates_c';
		//$smarty->cache_dir = _THEME_FOLDER._THEME.'/cache';
		$this->smarty->config_dir = _MYINCLUDES.'/smarty_configs';

	echo $today = date('Y-m-d');
	$sql = sprintf("SELECT * FROM %s.perform_vehicle_service",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		
		foreach ($resultSet as $key1 => $value1){
					foreach ($resultSet as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($resultSet[$key1]['service'] == $resultSet[$key2]['service'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($resultSet[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
$resultSet =		array_values($resultSet);
//dump_array($resultSet);
		//exit;
		foreach($resultSet as $val){
		//dump_array($val);
		$pieces = explode("-",$val['sDate']);
 
if($val['fTime'] == '3'){

$year = $val['checkFrequency'] + $pieces[0];
//echo $pieces[0]; 
//echo $pieces[1];
//echo $pieces[2]; 
$date  = $year.'-'.$pieces[1].'-'.$pieces[2];
}
if($val['fTime'] == '2'){

$month = $val['checkFrequency'] + $pieces[1];
if($month > 12){

$month = $month - 12;
$pieces[0] = $pieces[0] + 1;

}
//echo $pieces[0]; 
//echo $pieces[1];
//echo $pieces[2]; 
$date  = $pieces[0].'-'.$month.'-'.$pieces[2];
}
if($val['fTime'] == '1'){

$day = $val['checkFrequency'] + $pieces[2];
if($day > 30){

$day = $day - 30;
$pieces[1] = $pieces[1] + 1;

}
if($pieces[1] > 12){

$pieces[1] = $pieces[1] - 12;
$pieces[0] = $pieces[0] + 1;

}
//echo $pieces[0]; 
//echo $pieces[1];
//echo $pieces[2]; 
$date
  = $pieces[0].'-'.$pieces[1].'-'.$day;
}

		if($date == $today){
		
		
		
		dump_array($fleet);
		
		$sql = sprintf("SELECT * FROM %s.vehicle WHERE ID = ".$val['vID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$data = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		//dump_array($data);
		
		if($data['vehicleMake'] == '0'){
	
	$data['vehicleMake'] = '-';
	
	}
	if($data['vehicleModel'] == '0'){
	
	$data['vehicleModel'] = '-';
	
	}
	
		//dump_array($data);
		$pieces = explode(" ",$data['temporaryOwnerName']);
			$whoAU = explode(" ",$data['permanentOwnerName']);
			
			$this->f = $pieces[0];
			$this->l = $pieces[1];
			
			$this->ft = $whoAU[0];
			$this->lt = $whoAU[1];
			
			$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE forename = '".$this->f."' AND surname = '".$this->l."'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$data_1 = $stmt->fetch(PDO::FETCH_ASSOC);
		//dump_array($data_1);
		
		$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE forename = '".$this->ft."' AND surname = '".$this->lt."'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$data_2 = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$sql99 = sprintf("SELECT * FROM %s.vehicle_service
				
					WHERE mileageServices = '".$val['service']."' AND vID = ".$val['vID'],_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql99);
		$stmt->execute();

		$data_who_s = $stmt->fetch(PDO::FETCH_ASSOC);
		
	
			
			if($data_who_s){
				$data_email_f = $data_who_s['who'];
				
				
			}else{
			$data_email_f = $fleet['forename'];
			}
		
		$this->smarty->assign('emailTitle','smart-ISO&trade; Mail');				// E-mail HTML title
		$this->smarty->assign('emailColour','#808080');			// E-mail Background heading Colour
		$this->smarty->assign('emailTxtColour','#FFFFFF');		// E-mail Text heading Colour
		$this->smarty->assign('heading','smart-ISO&trade; Mail');		// Heading
		$this->smarty->assign('twoColData',$this->twoColData);				// Two column data
		$this->smarty->assign('singleColData',$this->singleColData);		// Single column data
		$this->smarty->assign('rawData',$this->rawData);					// Raw Data
		$this->smarty->assign('contact',$this->contact);					// Contact E-mail / phone (if e-mail needs to be mailto: link)
		$this->smarty->assign('textcss','table { max-width: 800px; } table tbody { min-height: 200px; } table td[colspan="7"] { width: 50%; }');
		$this->smarty->assign('make',$data['vehicleMake']);
		$this->smarty->assign('p',$data['permanentOwnerName']);
		$this->smarty->assign('t',$data['temporaryOwnerName']);
		$this->smarty->assign('f',$data_email_f);
		$this->smarty->assign('name',$val['service']);
		$this->smarty->assign('descp',$val['descp']);
		$this->smarty->assign('mileage',$val['cMileage']);
		$this->smarty->assign('model',$data['vehicleModel']);
		$this->smarty->assign('ref',$data['uniqueReference']);// Text/CSS
		$this->smarty->assign('date',date('d/m/Y'));		
        //$this->smarty->assign('date',date($this->datefmt));			// Date
		$this->smarty->assign('year',date('Y'));							// Automatic
		$this->smarty->assign('domain','smart-test.smart-iso.net');				// Automatic
		
		echo $email_body = $this->smarty->fetch('email.tpl');
		
		  $subject = "smart-ISO action for Smart Fleet Service";
		  $header = "Content-Type: text/html; charset=UTF-8\r\n";
			$header .= "From:<no-reply@".$_SERVER['HTTP_HOST'].">";
			
		
		@mail($data_1['emailAddress'],$subject,$email_body,$header);
		@mail($data_2['emailAddress'],$subject,$email_body,$header);
			
			$this->smarty->assign('emailTitle','smart-ISO&trade; Mail');				// E-mail HTML title
		$this->smarty->assign('emailColour','#808080');			// E-mail Background heading Colour
		$this->smarty->assign('emailTxtColour','#FFFFFF');		// E-mail Text heading Colour
		$this->smarty->assign('heading','smart-ISO&trade; Mail');		// Heading
		$this->smarty->assign('twoColData',$this->twoColData);				// Two column data
		$this->smarty->assign('singleColData',$this->singleColData);		// Single column data
		$this->smarty->assign('rawData',$this->rawData);					// Raw Data
		$this->smarty->assign('contact',$this->contact);					// Contact E-mail / phone (if e-mail needs to be mailto: link)
		$this->smarty->assign('textcss','table { max-width: 800px; } table tbody { min-height: 200px; } table td[colspan="7"] { width: 50%; }');
		$this->smarty->assign('make',$data['vehicleMake']);
		$this->smarty->assign('p',$data['permanentOwnerName']);
		$this->smarty->assign('t',$data['temporaryOwnerName']);
		$this->smarty->assign('f',$data_email_f);
		$this->smarty->assign('name',$val['service']);
		$this->smarty->assign('descp',$val['descp']);
		$this->smarty->assign('mileage',$val['cMileage']);
		$this->smarty->assign('model',$data['vehicleModel']);
		$this->smarty->assign('ref',$data['uniqueReference']);// Text/CSS
		$this->smarty->assign('date',date('d/m/Y'));		
        //$this->smarty->assign('date',date($this->datefmt));			// Date
		$this->smarty->assign('year',date('Y'));							// Automatic
		$this->smarty->assign('domain','smart-test.smart-iso.net');				// Automatic
		
		echo $email_body_a = $this->smarty->fetch('emailAU.tpl');
		
		  $subject = "smart-ISO action for Smart Fleet Service";
		  $header = "Content-Type: text/html; charset=UTF-8\r\n";
			$header .= "From:<no-reply@".$_SERVER['HTTP_HOST'].">";
			
		
		$p_t = explode(" ",$data_who_s['who']);
		$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE forename = '".$p_t[0]."' AND surname = '".$p_t[1]."'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$p_e_t = $stmt->fetch(PDO::FETCH_ASSOC);
		if($p_e_t){
		@mail($p_e_t['emailAddress'],$subject,$email_body_a,$header);
		}else{
		@mail($fleet['emailAddress'],$subject,$email_body_a,$header);
		
		}
		
		
		
		
		}	
		
		}
		
	}



		
}
?>

	