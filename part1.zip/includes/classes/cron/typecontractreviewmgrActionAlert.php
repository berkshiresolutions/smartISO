<?php
// BOB
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/contractreviewEmail.php';

// more control
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/cron/typemgrActionAlert.php';

class contractreviewMgrActionAlert extends MgrActionAlert {

  public function send($extraInfoFunc=null) {
     	
		
          	$i = 0;
			
            foreach($this->actions as $action) {
			
			   //echo count($action).'--------';
				//dump_array($action);
				for ($x=0;$x<=count($action);$x++)
                {
				if($action[$x]['reviewDueDate']){
				$this->currentwho=$action[$x]['contractManagerID'];
				$duedate=new DateTime($action[$x]['reviewDueDate']);
				//dump_array($this->currentwho);
				
				 $this->diff=$duedate->diff(new DateTime())->format("%d");  //add 1 to start today
	
				$this->generate_email($action[$x]['ID'],$extraInfoFunc,$i);
				}
				
			}
			$i++;
            }
	
            echo sprintf("<span style='margin-left: 6em'>%d email(s) generated...</span><br>",count($this->actions));
        
        }
		
		
public function generate_email($id,$extraInfoFunc=null,$y) {
                $mergeData = array();
 		    if(($extraInfoFunc != null) && is_callable($extraInfoFunc)) {
                    $mergeData = call_user_func( $extraInfoFunc, $id );
                }

              //  if(($extraInfoFunc != null) && is_array($extraInfoFunc)) {
              //      $mergeData = call_user_func_array( $extraInfoFunc, $id );
              //  }
			 echo $y;
                $emailObj = new reviewEmailHelper($id);
                
                // Who
                $who = $emailObj->getWhoDetails();
				
			
			//$pid=$this->getCurrentWho();
				dump_array($who);
					$pid = $who['id'];
                $ogrObj = SetupGeneric::useModule('Organigram');
		    $partObj = SetupGeneric::useModule('Participant');
             $diff=$this->diff;   
				//$diff = 1;
			//if($pid){
                for ($x=0;$x<$diff;$x++)
                {
                
				
				}
				if($y == '0'){
					$ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager($pid);
				$pid=$whomaster["participantID"];
				
				}
				if($y == '1'){
					$ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager1($pid);
				$pid=$whomaster["participantID"];
				
				}
				if($y == '2'){
					$ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager2($pid);
				$pid=$whomaster["participantID"];
				
				}
				if($y == '3'){
					$ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager3($pid);
				$pid=$whomaster["participantID"];
				
				}
				if($y == '4'){
					$ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager4($pid);
				$pid=$whomaster["participantID"];
				
				}
				if($y == '5'){
					$ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager5($pid);
				$pid=$whomaster["participantID"];
				
				}
				
				if($y == '6'){
				$details=$partObj->getAdminDetails();
				
				}else{
				$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
				
				}
			
				
				//dump_array($pid);
				//if ($pid) {
					
			//	}
			//	else
				//	$details=$partObj->getAdminDetails(); //if management chain fails or short send emails to admin
				//}
				//else
					//$details=$partObj->getAdminDetails(); //straight  to admin
				
				//dump_array($details);
				
				$who1 = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				dump_array($who1);
				if($who1 != array('displayname'=>' ','email'=>'') ) {
                        // DEAL WITH EXISTING WHO
                } else {
                        // DEAL WITH PERSON NOT EXISTING...
                    $who1['displayname'] = 'Non-Existant Person';
                    $who1['email'] = 'lpc@smart-iso.net';
                }
 		    		$emailObj->appendInfo($mergeData);

                    $emailObj->sendEmail('[Managers Alert] Contract Review To Be Completed',$who1,array(),array(),'me_completed','','mgmt');

	}
	

	public function get_offset_days() {
  		$contractObj = new Contract();
		$date = date("y-m-d");
		list($year,$month,$day) = (explode("-",$date));
		
		$offset_quarter=$contractObj->getQuarter($year,$month,$day);
		
		if ($offset_quarter["quarter"] ==4)
			$offset_day=7*$contractObj->getDetailedContractReviewOffset();
		else
			$offset_day=7*$contractObj->getStandardContractReviewOffset();
		$contractObj = null;	
		return $offset_day;
}


	
	public function pending_actions() {
	
	
	$pieces = explode("-",date('Y-m-d'));
	//dump_array($pieces);
	//echo $pieces[2];
	for ($x=0;$x<=6;$x++)
                {
				
		if($x == 6 && ($pieces[2] =='01' || $pieces[2] =='14' || $pieces[2] =='28')){
		$d = $this->days + $x;
	$reviewdateredMg=date('Y-m-d',strtotime("-".$d." days"));

		$sqlTmpl = "SELECT * FROM %s.contract WHERE enddate>getdate() and (archive is null or archive=0) and reviewDueDate < '".$reviewdateredMg."'";
		$query = sprintf( $sqlTmpl, _DB_OBJ_FULL);
 
$dbHand 			= DB::connect(_DB_TYPE);
		$stmt = $dbHand->prepare($query);
		echo "<span style='margin-left: 6em;'>Query: ".$query."</span><br>";
		$stmt->execute();
		$redult[] =  $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		}else{
		$d = $this->days + $x;
	$reviewdateredMg=date('Y-m-d',strtotime("-".$d." days"));

		$sqlTmpl = "SELECT * FROM %s.contract WHERE enddate>getdate() and (archive is null or archive=0) and reviewDueDate = '".$reviewdateredMg."'";
		$query = sprintf( $sqlTmpl, _DB_OBJ_FULL);
 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$stmt = $dbHand->prepare($query);
		echo "<span style='margin-left: 6em;'>Query: ".$query."</span><br>";
		$stmt->execute();
		$redult[] =  $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		}
	
		
		
	}
		//dump_array($redult);
		return $redult;
		
	}
	public function get_days() {
		$optionObj = new Option();
		$alert_mail_days = $optionObj->getOption('_SU_EMAIL_MGTESC') + $this->get_offset_days(); //starts 1 day earlier to get todays results
		$optionObj = null;
		return $alert_mail_days;	
	}


}
