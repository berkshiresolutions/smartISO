<?php
 /**
  $Id: PHP-1.php,v 3.01 Monday, August 16, 2010 7:43:22 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Cron
  * @since  Monday, August 16, 2010 7:43:22 PM>
  */


class Cron
{
	private function addCronShell() {}
	private function deleteCronShell() {}
	private function listCronShell() {}

	public function addCronJob() {}
	public function deleteCronJob() {}
	public function listCronJob() {}

}