<?
class SmartLaw {
	
	protected $alert_mail_days;
	public $result_set;
	
	public function __construct($p_alert_mail_days) {
		
		$this->alert_mail_days = $p_alert_mail_days;
		$this->result_set = array();
			
		$sql = "SELECT sla_action,sla_who,sla_when,sla_donedate FROM `smartlaw_actions`
			WHERE sla_approved = '0'
			AND DATE_ADD(sla_when,INTERVAL -".$this->alert_mail_days." DAY) = CURDATE()
			AND ( sla_donedate = '0000-00-00' OR sla_donedate IS NULL )
			ORDER BY sla_who DESC";
			
		$query = mysql_query($sql) or die(mysql_error().' '.$sql);
		$num = @mysql_num_rows($query);
		
		if ($num) {
			$k = 0;
			while ( $rec = mysql_fetch_assoc($query) ) {
				$this->result_set[$k]['action_desc'] 		= $rec['sla_action'];
				
				$this->result_set[$k]['action_when'] 		= $rec['sla_when'];
				$this->result_set[$k]['action_donedate'] 	= $rec['sla_donedate'];
				
				list($victim_forename,$victim_email) = @mysql_fetch_row(mysql_query("SELECT victim_forename,victim_email FROM personal_db WHERE id = ".$rec['sla_who']));
				
				$this->result_set[$k]['action_who'] 		= $victim_forename;
				$this->result_set[$k++]['action_email'] 		= $victim_email;
			}
		}
		
		return $this->result_set;
	}
	
}

class BlueAlert {
	
	protected $otype;
	protected $oactype;
	protected $module;
	protected $days;
	protected $company_id;
	protected $emaildata;
	protected $email_subject;
	
	public function __construct($p_module,$p_company_id) {
		$this->module 		= $p_module;
		$this->company_id  	= $p_company_id;
		$this->days 		= $this->get_days();
		
		$classname 			= $this->module;
		$this->oactype 		= new $classname($this->days);
		return $this->oactype;
	}
	
	public function get_days() {
		list($alert_mail_days) = @mysql_fetch_row(mysql_query("SELECT value FROM admin_option WHERE `name` = 'alert_mails' AND company_id = '".$this->company_id."' "));
		return $alert_mail_days;
	}
	
	public function save_action_alert() {}	
	public function generate_email() {		
		
		/*echo "<pre>";
		print_r($this->oactype);
		echo "</pre>";*/
		
		$cnt = count($this->oactype->result_set);
		
		$this->email_subject = "Smart-iso Blue Alert: ".ucfirst($this->module)." action pending.";
		
		for ($i=0;$i<$cnt;$i++) {
			
			if ( $this->html_mail ) {
				$action_html = "<html><head><link href='http://".$_SERVER['HTTP_HOST']."/scripts/common.css' rel='stylesheet' />";
				$action_html .= "<link href='http://".$_SERVER['HTTP_HOST']."/scripts/nextGenStyle.css' rel='stylesheet' /></head>";

				$action_html .= "<body><br/><br/><div style='width:80%; margin:0 auto'><div style='background-color: blue; padding: 0.5em; width: 100%;height:20px; color:white; font-weight:bold'>Blue Alert</div><br/><span class='normaltext'>Hi ".$this->oactype->result_set[$i]['action_who'].",<br/><br/>";					
				$action_html .= ucfirst($this->module)." action allocated to you is pending.<br/>Here are the details :<br/>";
				$action_html .= "<span class='normaltextbold'>Action Description</span>: ".$this->oactype->result_set[$i]['action_desc']."<br/>";
				$action_html .= "<span class='normaltextbold'>Due Date</span> : ".$this->oactype->result_set[$i]['action_when']."<br/><br/>";
				$action_html .= "Warm Regards<br/>Smart-iso</span></div></body></html>";
			} else {
				$action_html = "Hi ".$this->oactype->result_set[$i]['action_who'].",\n\n";					
				$action_html .= ucfirst($this->module)." action allocated to you is pending.\nHere are the details :\n\n";
				$action_html .= "Action Description: ".$this->oactype->result_set[$i]['action_desc']."\n";
				$action_html .= "Due Date : ".$this->oactype->result_set[$i]['action_when']."\n\n";
				$action_html .= "Warm Regards\nSmart-iso";					
			}
			
			$this->oactype->result_set[$i]['email_body'] = $action_html;
		}
	}
	
	public function send_email() {		
		
		$emails_cnt = count($this->oactype->result_set);
		
		if ($emails_cnt) {
			for($i=0;$i<$emails_cnt;$i++) {
				
				if ( $this->live_server ) {
					
					if ($this->html_mail) {
						$header = "Content-Type: text/html; charset=UTF-8\r\n";
					} else {
						$header = "Content-Type: text/plain; charset=UTF-8\r\n";
					}
					
					$header .= "From: Smart-ISO Alert <no-reply@".$_SERVER['HTTP_HOST'].">\r\n";
					$header .= "Bcc: John Moffat <jrm@smart-iso.com>\r\n";
					
					mail($this->oactype->result_set[$i]['action_email'],$this->email_subject,$this->oactype->result_set[$i]['email_body'],$header);
				} else {
					echo "<br/>send to ".$this->oactype->result_set[$i]['action_email']."<br/>";
					echo "subject ".$this->email_subject;
					echo $this->oactype->result_set[$i]['email_body'];
				}
			} // end for
		} // end if 
	}
}

class Alert {
	
	private $live_server;
	private $html_mail;
	
	public function __construct($p_type,$p_module,$p_company_id) {
		$classname = $p_type.'Alert';
		$this->otype = new $classname($p_module,$p_company_id);
		
		$this->otype->live_server = true;
		$this->otype->html_mail = true;
		
		return $this->otype;
	}
	
	public function generate_email() {
		$this->otype->generate_email();		
	}
	
	public function send_email() {
		$this->otype->send_email();		
	}
}
?>