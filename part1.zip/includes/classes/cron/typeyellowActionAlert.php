<?php
// CODESIGN2 ADD-ONS
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';

// more control
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

class YellowActionAlert {

	protected $actions;
	protected $module;
	protected $days;

	public function __construct($module='',$domain='') {
		$this->module = $module;
		$this->days = $this->get_days();
		$this->actions = $this->pending_actions();
	}
        public function send($extraInfoFunc=null) {
            foreach($this->actions as $action) {
                $this->generate_email($action['ID'],$extraInfoFunc);
            }
            echo sprintf("<span style='margin-left: 6em'>%d email(s) generated...</span><br>",count($this->actions));
        }
	public function generate_email($id,$extraInfoFunc=null) {
                $mergeData = array();
                if(($extraInfoFunc != null) && is_callable($extraInfoFunc)) {
                    $mergeData = call_user_func( $extraInfoFunc, $id );
                }
		echo "<span style='margin-left: 6em'>email generated for action $id...</span><br>";
                $emailObj = new actionEmailHelper($id);
                // Who
                $who = $emailObj->getWhoDetails();
                var_dump($who);echo "\r\n<br>";
                if($who != array('displayname'=>' ','email'=>'') ) {
                        // DEAL WITH EXISTING WHO
                } else {
                    // DEAL WITH PERSON NOT EXISTING...
                    $who['displayname'] = 'Non-Existant Person';
                    $who['email'] = 'lpc@smart-iso.com';
                }
                $emailObj->appendInfo($mergeData);
                $emailObj->sendEmail('[Yellow Alert] Action To Be Completed',$who,array(),array(),'me_completed','','yellow');
	}
        
	public function send_email($data) {
		echo "<span style='margin-left: 6em'>email sent...</span><br>";	
	}
	public function pending_actions() {
		/*
                 * removed due to incorrect logic
                $dueDate = new DateTime(); // start with today
		$dueDate->add( new DateInterval('P'.$this->days.'D') ); // add nesecarry days
                */
		$sqlTmpl = "SELECT * FROM %s.actions WHERE moduleName = '%s' AND (doneDate IS NULL OR doneDate < '1980-01-01') AND DATEADD(d,%s,dueDate) = '%s'";
		$query = sprintf( $sqlTmpl, _DB_OBJ_FULL, $this->module,($this->days*-1),date('Y-m-d') );
		 
		$dbHand = DB::connect(_DB_TYPE);
		$stmt = $dbHand->prepare($query);
		echo "<span style='margin-left: 6em;'>Query: ".$query."</span><br>";
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	public function get_days() {
		$optionObj = new Option();
		$alert_mail_days= $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
		$optionObj = null;
		return $alert_mail_days;	
	}

}