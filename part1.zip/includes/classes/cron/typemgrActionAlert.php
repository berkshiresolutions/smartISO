<?php
// CODESIGN2 ADD-ONS
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';

// more control
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

//include "../includes/manager_participant_hierarchy.inc.php";

class MgrActionAlert {

	protected $actions;
	protected $module;
	protected $days;
	protected $currentwho;
	protected $diff;

		
		
	public function __construct($module='',$domain='') {
		$this->module = $module;
		$this->days = $this->get_days();
		$this->actions = $this->pending_actions(); 
	}
        public function send($extraInfoFunc=null) {
     	
          	
            foreach($this->actions as $action) {

				$this->currentwho=$action['who'];
				$duedate=new DateTime($action['dueDate']);
				$this->diff=$duedate->diff(new DateTime())->format("%d");  //add 1 to start today
	
				$this->generate_email($action['ID'],$extraInfoFunc);
            }
            echo sprintf("<span style='margin-left: 6em'>%d email(s) generated...</span><br>",count($this->actions));
        
        }
	public function generate_email($id,$extraInfoFunc=null) {
                $mergeData = array();
 		    if(($extraInfoFunc != null) && is_callable($extraInfoFunc)) {
                    $mergeData = call_user_func( $extraInfoFunc, $id );
                }

              //  if(($extraInfoFunc != null) && is_array($extraInfoFunc)) {
              //      $mergeData = call_user_func_array( $extraInfoFunc, $id );
              //  }
                $emailObj = new actionEmailHelper($id);
                
                // Who
                //$who = $emailObj->getWhoDetails();
				$pid=$this->currentwho;

                $ogrObj = SetupGeneric::useModule('Organigram');
		    $partObj = SetupGeneric::useModule('Participant');
                
			if($this->diff<9){
                for ($x=0;$x<$this->diff;$x++)
                {
                $ogrObj->setItemInfo(array('id'=> $pid));
				$whomaster=$ogrObj->getManager($pid);
				$pid=$whomaster["participantID"];
				}

				
				if ($pid) {
					$partObj ->setItemInfo(array('id'=>$pid));
					$details = $partObj ->displayItemById();
				}
				else
					$details=$partObj->getAdminDetails(); //if management chain fails or short send emails to admin
				}
				else
					$details=$partObj->getAdminDetails(); //straight  to admin
					
				$who = array('displayname' => ucwords($details['forename'].' '.$details['surname']),'email' => $details['emailAddress']	);
				
				if($who != array('displayname'=>' ','email'=>'') ) {
                        // DEAL WITH EXISTING WHO
                } else {
                        // DEAL WITH PERSON NOT EXISTING...
                    $who['displayname'] = 'Non-Existant Person';
                    $who['email'] = 'lpc@smart-iso.net';
                }
 		    $emailObj->appendInfo($mergeData);
                $emailObj->sendEmail('[Managers Alert] Action To Be Completed',$who,array(),array(),'me_completed','','mgmt');

	}
	public function send_email($data) {
		echo "<span style='margin-left: 6em'>email sent...</span><br>";	
	}
	public function pending_actions() {
		/*
                 * removed due to incorrect logic
                $dueDate = new DateTime(); // start with today
		$dueDate->add( new DateInterval('P'.$this->days.'D') ); // add nesecarry days
                */
        
		$sqlTmpl = "SELECT * FROM %s.actions WHERE moduleName = '%s' AND (doneDate IS NULL OR doneDate < '1980-01-01') AND DATEADD(d,%s,dueDate) < '%s'";
		
		$query = sprintf( $sqlTmpl, _DB_OBJ_FULL, $this->module,$this->days,date('Y-m-d') );
 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$stmt =$this->dbHand->prepare($query);
		echo "<span style='margin-left: 6em;'>Query: ".$query."</span><br>";
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function get_days() {
		$optionObj = new Option();
//		$alert_mail_days = $optionObj->getOption('_SU_EMAIL_REDMAIL');
//		$alert_mail_days += $optionObj->getOption('_SU_EMAIL_MGTESC'); BOB believe incorrect
		$alert_mail_days = $optionObj->getOption('_SU_EMAIL_MGTESC')-1; //starts 1 day earlier to get todays results
		$optionObj = null;
		return $alert_mail_days;
	}
	
	public function getDiff() {
		return $this->diff;	
	}
	public function getCurrentWho() {
		return $this->currentwho;	
	}
}