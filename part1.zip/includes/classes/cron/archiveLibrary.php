<?php

/**
  $Id: dseModEmail.class.php,v 3.12 Thursday, January 27, 2011 5:51:39 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Client
 * @subpackage Report
 * @since  Monday, August 16, 2010 1:45:34 PM>
 */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

class LibArchive
{
private $dbHand;

public function __construct() {
 
$this->dbHand = DB::connect(_DB_TYPE);
}



public function UpdateArchives() {
$optionObj = new Option();
$delay = $optionObj->getOption('_SU_COMMS_ARCHIVE_DELAY');
if ($delay ==0) exit();
$reviewdate = date('Y-m-d', strtotime("+ " . $delay. " days"));
 $sql = sprintf("update %s.comms_mangement set archive=1 where isnull(archive,0)=0 and archive_date <= '%s'",_DB_OBJ_FULL, $reviewdate);
            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
		}
}