<?php
// BOB
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/contractreviewEmail.php';

// more control
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
// require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/cron/typeblueActionAlert.php';

class contractreviewBlueActionAlert extends BlueActionAlert {

	public function generate_email($id,$extraInfoFunc=null) {
                $mergeData = array();
                if(($extraInfoFunc != null) && is_callable($extraInfoFunc)) {
                    $mergeData = call_user_func( $extraInfoFunc, $id );
                }
		echo "<span style='margin-left: 6em'>email generated for action $id...</span><br>";
                $emailObj = new reviewEmailHelper($id);
                // Who
                $who = $emailObj->getWhoDetails();
                var_dump($who);echo "\r\n<br>";
                if($who != array('displayname'=>' ','email'=>'') ) {
                        // DEAL WITH EXISTING WHO
                } else {
                    // DEAL WITH PERSON NOT EXISTING...
                    $who['displayname'] = 'Non-Existant Person';
                    $who['email'] = 'lpc@smart-iso.com';
                }
                $emailObj->appendInfo($mergeData);
                $emailObj->sendEmail('[Blue Alert] Contract Review To Be Completed',$who,array(),array(),'me_completed','','blue');
	}
  
	public function get_offset_days() {
  		$contractObj = new Contract();
		$date = date("y-m-d");
		list($year,$month,$day) = (explode("-",$date));
		
		$offset_quarter=$contractObj->getQuarter($year,$month,$day);
		
		if ($offset_quarter["quarter"] ==4)
			$offset_day=7*$contractObj->getDetailedContractReviewOffset();
		else
			$offset_day=7*$contractObj->getStandardContractReviewOffset();
		$contractObj = null;	
		return $offset_day;
}


	
	public function pending_actions() {
		
		$d = $this->days;
	 $reviewdateredMg=date('Y-m-d',strtotime("+".$d." days"));
		$sqlTmpl = "SELECT * FROM %s.actions WHERE moduleNames = '%s' AND (doneDate IS NULL OR doneDate < '1980-01-01') AND dueDate = '".$reviewdateredMg."'";
		$sqlTmpl = "SELECT * FROM %s.contract WHERE enddate>getdate() and (archive is null or archive=0) and reviewDueDate = '".$reviewdateredMg."'";
		$query = sprintf( $sqlTmpl,_DB_OBJ_FULL);
 
$dbHand 			= DB::connect(_DB_TYPE);
		$stmt = $dbHand->prepare($query);
		echo "<span style='margin-left: 6em;'>Query: ".$query."</span><br>";
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		
		
	}
	public function get_days() {
		$optionObj = new Option();
		$alert_mail_days= $optionObj->getOption('_SU_EMAIL_BLUEMAIL')-$this->get_offset_days();
		$optionObj = null;
		return $alert_mail_days;	
	}


}
