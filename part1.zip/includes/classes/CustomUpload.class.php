<?php
 /**
  $Id: CustomUpload.class.php,v 3.03 Monday, January 03, 2011 7:40:06 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Tuesday, October 26, 2010 2:13:34 PM>
  */

class CustomUpload
{

	private $filename;
	private $filePath;
	private $destinationFilename;
	private $moduleName;
	private $fileId;
	private $dbHand;
	private $rootFolder;
	private $userFileName;

	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	public function setFileInfo($p_module_name,$file_details) {

		global $document_formats;
		$this->name				= $file_details['name'];
		$this->userFileName		= $file_details['user_file_name'];
		$this->sysName			= '';
		$this->fileId			= 0;
		$this->filePath			= $file_details['path'];
		$this->formats			= $document_formats;
		$this->moduleName		= $p_module_name;
		$this->rootFolder		= $file_details['destination'];
		$this->type = "gdf";

	}

	public function add_file() {

		//if( $this->move_uploaded_file_to_destination() ) {
			try {
				$this->add_file_db();
				$this->get_system_filename();
				$this->move_uploaded_file_to_destination();
				$this->edit_file_db();

			} catch ( ErrorException $e ) {
				if ( $e->getCode() == 15 ) {
					$this->delete_file_db();
				}
			}
		//}
	}

	private function get_system_filename() {

		$extension 	= explode('.',$this->userFileName);
		$ext 		= $extension[count($extension)-1];

		$this->sysName = 'sys_'.$this->moduleName.'_'.$this->fileId.'.'.$ext;
	}

	private function add_file_db() {

		$sql = sprintf("INSERT INTO %s.uploaded_files (fileID,usrFilename,sysFilename,module,addedOn,mimeType)
				VALUES (?, ?, ?, ?, NOW(), ?)",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->fileId,PDO::PARAM_INT);
		$stmt->bindParam(2,$this->userFileName,PDO::PARAM_STR,150);
		$stmt->bindParam(3,$this->sysName,PDO::PARAM_STR,150);
		$stmt->bindParam(4,$this->moduleName,PDO::PARAM_STR,150);
		$stmt->bindParam(5,$this->type,PDO::PARAM_STR,100);

		if ( $stmt->execute() ) {
			$this->fileId = $this->dbHand->lastInsertId();
			return true;
		} else {
			return false;
		}
	}

	private function move_uploaded_file_to_destination(){

		if ( $this->rootFolder == "" ) {
			$destination = _PATH_PUB.$this->sysName;
		} else {

			$direcotry_present = is_dir(_PATH_PUB.$this->rootFolder);

			if (!$direcotry_present) {
				mkdir(_PATH_PUB.$this->rootFolder,0755);
			}

			$destination = _PATH_PUB.$this->rootFolder.'/'.$this->sysName;
			//echo (int) $direcotry_present;
			//exit;
		}

		if ( move_uploaded_file($this->filePath.$this->name,$destination) ) {

			chown($destination,'ehswebuser');
			chmod($destination,0755);
			return true;
		} else {
			throw new ErrorException();
		}
	}

	private function edit_file_db() {

		$sql = sprintf("UPDATE %s.uploaded_files SET sysFilename = ? WHERE fileID = ?",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->sysName,PDO::PARAM_STR,150);
		$stmt->bindParam(2,$this->fileId,PDO::PARAM_INT);

		return $stmt->execute();
	}
}

?>