<?php
 /**
  $Id: HazardClassificationSetup.class.php,v 3.24 Thursday, January 13, 2011 12:53:02 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This object is used to manage CRUD operations related to Hazard classification Setup Object
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:28:40 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class AssetModelSetup extends SetupOperation {

	private $dbHand;

	public function __construct() {
		 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	/**
	 * This method is used to add record
	 *
	 * Array variables : id,name,pid
	 *
	 * @access public
	 *
	 */
	
public function addItem() {

			$sql = "INSERT INTO %s.asset_model (model, manID) VALUES ('%s', %d)";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['man']);
			$stmt = $this->dbHand->prepare($psql);


			$stmt->execute();

			return true;
		
	}


	/**
	 * This method is used to delete record
	 *
	 * Array variables : id
	 * @access public
	 *
	*/

    public function deleteItem() {
	
	$sql = "UPDATE %s.asset_model SET archive = 1 WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;

		

	}


	public function editItem() {

			$sql = "UPDATE %s.asset_model SET model = '%s',manID = '%d' WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['man'],$this->id);
			$stmt = $this->dbHand->prepare($psql);

			$stmt->execute();

			return true;
		

	}


	


	/***
	 * This method is used to list single record
	 * Array variables : id
	 */



	public function displayItemById() {

		$sql = "SELECT * FROM %s.asset_model WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	


	
		public function displayItems() {
		
		//$sql = "SELECT * FROM asset_model WHERE aID = %d ";
		$sql = "SELECT * FROM %s.asset_model WHERE manID = %d  AND ( archive is NULL OR archive = 0) order by cast(model as varchar(100))";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}
		public function displayItems1() {
		
		//$sql = "SELECT * FROM asset_model WHERE aID = %d ";
		$sql = "SELECT * FROM %s.asset_model WHERE manID = %d  AND archive = 1  order by cast(model as varchar(100))";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}
	
	public function archiveAsset($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.asset_model SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	
			public function getListingforExport() {

		 $type = $_GET['type'];

		if ( $type  =='full') {

			return $this->getAllExportDataFull();

		} else {

			return $this->getExportData();
		}
	}
	public function getAllExportDataFull() {

		$heading = array(array(0=>'Company Name',1=>'Model'));

		$data_records = $this->displayItemsforAllCSV();


		if (is_array($data_records) ) {

			foreach( $data_records as $key => $value) {

				$control_id = $value['ID'];

				$result1[$control_id] 	  =  array($value['companyName'],$value['model']);
			}

		}
                if(is_array($result1)){
                $result_new = array_merge($heading,$result1);
                }else {
                $result_new = $heading;    
                }
		

		return $result_new;

	}
	public function getExportData() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
		$parent_id = (int) $_GET['pid'];
if ($parent_id == 0)
    $parent_id =1;
	
		$heading = array(array(0=>'Asset'));

		$this->setItemInfo(array(
							'id'=>$parent_id
							));
                if ($archive ==1)
		$data_records = $this->displayItems1();
                else
                $data_records = $this->displayItems();


		if (is_array($data_records) ) {

			foreach( $data_records as $key => $value) {

				$control_id = $value['ID'];

				$result1[$control_id] 	  =  array($value['model']);
			}

		}
                if (is_array($result1)){
                $result_new = array_merge($heading,$result1);
        }else{
    $result_new = $heading;
}
		

		return $result_new;

	}
       	public function displayItemsforAllCSV() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
  $sql = "select A.ID,companyName,model from %s.asset_manufacturer M inner join %s.asset_model A on M.ID=A.manID where isnull(M.archive,0)=%d and isnull(A.archive,0)=%d order by A.ID";
		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,archive,archive);
		$stmt = $this->dbHand->prepare($psql);
                exit();
		$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
            public function getdropdown($p_ref, $p_item) {

       $sql = sprintf("SELECT * FROM %s.asset_model where isnull(archive,0)=0 and manID=%d", _DB_OBJ_FULL, $p_ref);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $retString = "<OPTION value=0>-- Select --</OPTION>";
        foreach ($result as $data) {
            $retString.="<OPTION value=" . $data["ID"];
            if ($data["ID"] == $p_item)
                $retString.=" selected";
            $retString.=" >" . $data["model"] . "</OPTION>";
        }
        return $retString;
    }
	

}
