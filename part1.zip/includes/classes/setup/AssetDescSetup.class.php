<?php
 /**
  $Id: HazardClassificationSetup.class.php,v 3.24 Thursday, January 13, 2011 12:53:02 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This object is used to manage CRUD operations related to Hazard classification Setup Object
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:28:40 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class AssetDescSetup extends SetupOperation {

	private $dbHand;

	public function __construct() {
		 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	/**
	 * This method is used to add record
	 *
	 * Array variables : id,name,pid
	 *
	 * @access public
	 *
	 */
	
public function addItem() {

		

			$sql = "INSERT INTO %s.asset_description (name, manID,modelID) VALUES ('%s', %d, %d)";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['man'],$this->vars['model']);
			$stmt = $this->dbHand->prepare($psql);

			$stmt->execute();

			return true;
		
	}


	/**
	 * This method is used to delete record
	 *
	 * Array variables : id
	 * @access public
	 *
	*/

    public function deleteItem() {
	
	$sql = "UPDATE %s.asset_description SET archive = 1 WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;

		

	}


	public function editItem() {


			$sql = "UPDATE %s.asset_description SET name = '%s',manId=%d,modelID=%d WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['man'],$this->vars['model'], $this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;
	
	}


	


	/***
	 * This method is used to list single record
	 * Array variables : id
	 */



	public function displayItemById() {

		$sql = "SELECT * FROM %s.asset_description WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	


	
		public function displayItems() {
		

if ($this->vars["cid"] >0){
    $sql = "SELECT * FROM %s.asset_description WHERE manID = %d and modelid =%d  AND ( archive is NULL OR archive = 0) order by cast(name as varchar(100))";
    $psql = sprintf($sql,_DB_OBJ_FULL,$this->id,$this->vars["cid"]);
}
    else
    {
		$sql = "SELECT * FROM %s.asset_description WHERE manID = %d  AND ( archive is NULL OR archive = 0)  order by cast(name as varchar(100))";
               $psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
    }
		
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}
		public function displayItems1() {

                    if ($this->vars["cid"] >0){
    $sql = "SELECT * FROM %s.asset_description WHERE manID = %d and modelid =%d  AND archive = 1  order by cast(name as varchar(100))";
    $psql = sprintf($sql,_DB_OBJ_FULL,$this->id,$this->vars["cid"]);
}
    else
    {
		$sql = "SELECT * FROM %s.asset_description WHERE manID = %d  AND archive = 1  order by cast(name as varchar(100))";
                $psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
    }

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}
	
	public function archiveAsset($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.asset_description SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

        
   

		public function displayModelItems() {

		$sql = "SELECT * FROM %s.asset_model WHERE manID = %d  AND isnull(archive,0) = 0 ";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $result;
	}
	
public function displayDescItems() {

		$sql = "SELECT * FROM %s.asset_description WHERE modelID = %d  AND isnull(archive,0) = 0 ";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $result;
	}
	
				public function getListingforExport() {

		 $type = $_GET['type'];

		if ( $type  =='full') {

			return $this->getAllExportDataFull();

		} else {

			return $this->getExportData();
		}
	}
	public function getAllExportDataFull() {

		$heading = array(array(0=>'Company Name',1=>'Model',2=>'Description'));

		$data_records = $this->displayItemsforAllCSV();


		if ( count($data_records) ) {

			foreach( $data_records as $key => $value) {

				$control_id = $value['ID'];

				$result1[$control_id] 	  =  array($value['companyName'],$value['model'],$value['name']);
			}

		}

		$result_new = array_merge($heading,$result1);

		return $result_new;

	}
	public function getExportData() {

		$parent_id = (int) $_GET['pid'];
if ($parent_id == 0)
    $parent_id =1;
	$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');



		$heading = array(array(0=>'Asset'));

		$this->setItemInfo(array(
							'id'=>$parent_id
							));
                if ($archive_session == '0')
		$data_records = $this->displayItems();
                else
            $data_records = $this->displayItems1();

		if ( count($data_records)>0 ) {

			foreach( $data_records as $key => $value) {

				$control_id = $value['ID'];

				$result1[$control_id] 	  =  array($value['name']);
			}
$result_new = array_merge($heading,$result1);
		}
else
		$result_new = $heading;

		return $result_new;

	}
       	public function displayItemsforAllCSV() {

 $sql = "select A.ID,companyName,model,name from %s.asset_manufacturer M inner join %s.asset_model A on M.ID=A.manID inner join %s.asset_description D on A.ID=D.modelID  order by A.ID";
		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
        
                    public function getdropdown($p_ref, $p_item) {

      $sql = sprintf("SELECT D.ID,D.name FROM %s.asset_model M inner join %s.asset_description D on M.ID=D.modelid where isnull(M.archive,0)=0 and isnull(D.archive,0)=0 and D.modelID=%d", _DB_OBJ_FULL , _DB_OBJ_FULL, $p_ref);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $retString = "<OPTION value=0>-- Select --</OPTION>";
        foreach ($result as $data) {
            $retString.="<OPTION value=" . $data["ID"];
            if ($data["ID"] == $p_item)
                $retString.=" selected";
            $retString.=" >" . $data["name"] . "</OPTION>";
        }
        return $retString;
    }
}
