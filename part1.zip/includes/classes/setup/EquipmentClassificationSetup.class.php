<?php
 /**
  $Id: EquipmentClassificationSetup.class.php,v 3.16 Tuesday, January 18, 2011 12:57:56 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Object for Equipment Classification Setup
  *
  * This object is used to manage operations of Equipment Classification Setup
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:48:00 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class EquipmentClassificationSetup extends SetupOperation {

	/**
	 * This property will act as container for database object.
	 *
	 * @access private
	 */
	private $dbHand;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}

	/**
	 * This method is used to add an equipment classification.
	 *
	 * Array variables : id,description
	 *
	 * @access public
	 *
	 */
	public function addItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equip_classification WHERE description LIKE '".$this->vars['description']."' AND equipTypeId = ".$this->vars['pid'],_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		} else {

		$sql = "INSERT INTO %s.equip_classification (description, equipCode,equipTypeId) VALUES ( '%s', '%s','%d')";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['description'],$this->vars['equipment_code'],$this->vars['pid']);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->id);
			$stmt->bindParam(2,$this->vars['description']);
			$stmt->bindParam(3,$this->vars['equipment_code']);*/

			return $stmt->execute();

		}

	}

	/**
	 * This method is used to delete an equipment classification.
	 *
	 * array variables : id
	 *
	 * @access public
	 *
	 */
	 
	 
    public function deleteItem() {

		
		$sql = "UPDATE %s.equip_classification SET archive = 1  WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['description']);
			$stmt->bindParam(2,$this->vars['equipment_code']);
			$stmt->bindParam(3,$this->id);*/

			 $stmt->execute();

	}

	/**
	 * This method is used to edit an equipment classification.
	 *
	 * array variables : id,description
	 *
	 * @access public
	 */
	public function editItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equip_classification WHERE description LIKE '".$this->vars['description']."' AND equipTypeId = ".$this->vars['pid']." AND ID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		} else {

			$sql = "UPDATE %s.equip_classification SET description = '%s', equipCode = '%s' WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['description'],$this->vars['equipment_code'],$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['description']);
			$stmt->bindParam(2,$this->vars['equipment_code']);
			$stmt->bindParam(3,$this->id);*/

			return $stmt->execute();
			exit;
		}
	}

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = "SELECT * FROM %s.equip_classification WHERE ID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;

	}

	/**
	 * This method is used to list all equipment classification.
	 *
	 * @access public
	 */
	public function displayItems() {

		//$sql = "SELECT * FROM hazard_classification WHERE hpcID = %d ORDER BY secondaryHazard ASC";
		$sql = "SELECT * FROM %s.equip_classification WHERE equipTypeId = %d AND (archive  is NULL OR archive = 0) ORDER BY ID DESC";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayItemsa() {

		//$sql = "SELECT * FROM hazard_classification WHERE hpcID = %d ORDER BY secondaryHazard ASC";
		$sql = "SELECT * FROM %s.equip_classification WHERE equipTypeId = %d AND  archive = 1 ORDER BY ID DESC";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	/**
	 * This method is used to list all equipment classification.
	 *
	 * @access public
	 */
	public function displayAllItems() {

		//$sql = "SELECT * FROM hazard_classification WHERE hpcID = %d ORDER BY secondaryHazard ASC";
		$sql = "SELECT * FROM %s.equip_classification ORDER BY ID DESC";

		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}


	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {
	
	 $parent_id = (int) $_GET['pid'];

		$heading = array(array('description'=>'Classification','equipCode'=>'Classification Code'));

		$sql = sprintf("SELECT * FROM %s.equip_classification WHERE equipTypeId = ".$parent_id." ORDER BY ID DESC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if (count ($result)) {
			foreach ($result as $value) {
				$doc_id = $value['ID'];
				$result1[$doc_id] 	  =  array($value['description'],$value['equipCode']);
			}

		}

		$result = array_merge($heading,$result1);
		return $result;

	}
        
        	public function archiveEquipClass($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.equip_classification SET archive = 0 WHERE ID = %d";

	echo	$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

}
