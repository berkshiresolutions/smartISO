<?php
 /**
  $Id: EmploymentTypeSetup.class.php,v 3.20 Saturday, January 15, 2011 10:23:04 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @since  Saturday, August 14, 2010 5:48:25 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class EmploymentTypeSetup extends SetupOperation
{

	private $dbHand;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}

	/***
	 * This method is used to insert record
	 * Array variables : id,name
	 */
	public function addItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.employment_type WHERE name LIKE '".$this->vars['name']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sort = 0;

			$sql = "INSERT INTO %s.employment_type (name, sort) VALUES ('%s', %d)";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$sort);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$sort);*/

			$stmt->execute();

			$lastInsertID 	= customLastInsertId($this->dbHand,'employment_type','etypeID');
			$sort			= $lastInsertID*100;

			$stmt = null;

			$sql2 = "UPDATE %s.employment_type SET sort = %d WHERE eTypeID = %d";
			$psql2 = sprintf($sql2,_DB_OBJ_FULL,$sort,$lastInsertID);
			$stmt = $this->dbHand->prepare($psql2);
			/*$stmt->bindParam(1,$sort);
			$stmt->bindParam(2,$lastInsertID);*/

			$stmt->execute();

			return true;
		}
	}
	  public function deleteItem() {

		$sql = "UPDATE %s.employment_type SET archive = 1 WHERE etypeID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id);

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}
	

	
	  public function deleteAllItem() {

		$sql = "UPDATE %s.vehicleDetail SET archive =1 WHERE aID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id);

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}
	 public function deleteAllModel() {

		$sql = "UPDATE %s.vehicleModel SET archive = 1 WHERE aID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id);

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}
	

	/***
	 * This method is used to delete record
	 * Array variables : id
	 */
    public function deleteType() {

		$sql = "DELETE FROM %s.employment_type WHERE eTypeID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id);

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}
	
	
	
	
	/***
	 * This method is used to edit record
	 * Array variables : id,name,pid
	 */
	public function editItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.employment_type WHERE name LIKE '".$this->vars['name']."' AND etypeID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sql = "UPDATE %s.employment_type SET name = '%s' WHERE eTypeID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;
		}

	}

	

	
	public function addVehicle12() {

		$sql = "INSERT INTO %s.addVarient (vari)VALUES('%s')";
		echo $psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name']);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id);

		if ( $stmt->execute() ) {
		
		
		$this->incidenceId = customLastInsertId($this->dbHand,'addVarient','vari');
			return $this->incidenceId;
		} else {
			return false;
		}

	}
	
	public function addVehicle3($fre,$time) {
	
		$this->fre = $fre;
		$this->time1 = $time;
		$sql = "INSERT INTO %s.addFre (fre,time)VALUES('%s','%s')";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->fre,$this->time1);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id);

		if ( $stmt->execute() ) {
		
		
		$this->incidenceId = customLastInsertId( $this->dbHand,'addFre','ID');
			return $this->incidenceId;
		} else {
			return false;
		}

	}
	

	

	public function getLastInsertID() {
		return $this->incidenceId;
	}
	
	

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = "SELECT * FROM %s.employment_type WHERE eTypeID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	

	/***
	 * This method is used to list record
	 */
	public function displayItems() {

		$sql = sprintf("SELECT * FROM %s.employment_type WHERE archive is NULL OR archive =0 ORDER BY sort DESC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	public function displayItemsa() {

		$sql = sprintf("SELECT * FROM %s.employment_type WHERE archive = 1 ORDER BY sort DESC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayVehicles() {

		$sql = sprintf("SELECT * FROM %s.addVehicle WHERE archive is NULL OR archive = '0'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	public function displayVehicles3($id) {
			$this->id = $id;
		$sql = sprintf("SELECT * FROM %s.addVehicle WHERE ID=".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayVehicles4($id) {
			$this->id = $id;
		$sql = sprintf("SELECT * FROM %s.addService WHERE ID=".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayVehicles1() {

		$sql = sprintf("SELECT * FROM %s.new_vehicle WHERE archive is NULL OR archive = 0",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayVehicles12() {

		$sql = sprintf("SELECT * FROM %s.new_vehicle WHERE archive = 1",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
		public function displayVehiclesTT() {

		$sql = sprintf("SELECT * FROM %s.addVehicle WHERE archive = '1'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	
	

	

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$heading = array(array('name'=>'Title'));

		 $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

 if($archive_session == '0'){
	 $sql = sprintf("SELECT name FROM %s.employment_type WHERE archive is NULL OR archive =0 ORDER BY sort DESC",_DB_OBJ_FULL);
 }
		else{
			$sql = sprintf("SELECT name FROM %s.employment_type WHERE archive = 1 ORDER BY sort DESC",_DB_OBJ_FULL);
		}


		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$result = array_merge($heading,$result);
		return $result;

	}
        	public function archiveEmployType($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.employment_type SET archive = 0 WHERE etypeID = %d";

	echo	$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

}
