<?php

/**
  $Id: IncidenceDetailSetup.class.php,v 3.19 Saturday, January 29, 2011 10:21:24 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Setup
 * @subpackage Classes
 * @since  Saturday, August 14, 2010 5:27:06 PM>
 */
require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class BCPDetailSetup extends SetupOperation {

    private $dbHand;

    public function __construct() {
        
$this->dbHand 			= DB::connect(_DB_TYPE);
    }

    /**
     * This method is used to add record
     * Array variables :
     * id ,name, pid
     */
    public function addItem() {
        
    }

    public function editItem() {
        
    }

    public function deleteItem() {
        
    }

    public function displayItems() {
        
    }

    public function addItemRatXX() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*)
					   FROM %s.smart_rat
					   WHERE name LIKE '" . $this->vars['name'] . "'
					  ", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "INSERT INTO %s.smart_rat (name) VALUES ('%s')";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name']);
            $stmt = $this->dbHand->prepare($psql);
            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['pid']);
              $stmt->bindParam(3,$this->vars['torso']); */

            $stmt->execute();
            /* dump_array($stmt->errorInfo());
              exit; */

            return true;
        }
    }

    public function addItemDesi() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*)
					   FROM %s.smart_desi
					   WHERE name LIKE '" . $this->vars['name'] . "'
					  ", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "INSERT INTO %s.smart_desi (name) VALUES ('%s')";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name']);
            $stmt = $this->dbHand->prepare($psql);
            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['pid']);
              $stmt->bindParam(3,$this->vars['torso']); */

            $stmt->execute();
            /* dump_array($stmt->errorInfo());
              exit; */

            return true;
        }
    }

    public function addItemRXX() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*)
					   FROM %s.smart_rec
					   WHERE name LIKE '" . $this->vars['name'] . "'
					  ", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "INSERT INTO %s.smart_rec (name) VALUES ('%s')";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name']);
            $stmt = $this->dbHand->prepare($psql);
            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['pid']);
              $stmt->bindParam(3,$this->vars['torso']); */

            $stmt->execute();
            /* dump_array($stmt->errorInfo());
              exit; */

            return true;
        }
    }

    public function addItemC() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*)
					   FROM %s.smart_cric
					   WHERE name LIKE '" . $this->vars['name'] . "'
					  ", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "INSERT INTO %s.smart_cric (name) VALUES ('%s')";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name']);
            $stmt = $this->dbHand->prepare($psql);
            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['pid']);
              $stmt->bindParam(3,$this->vars['torso']); */

            $stmt->execute();
            /* dump_array($stmt->errorInfo());
              exit; */

            return true;
        }
    }

    public function addItemNature() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*)
					   FROM %s.smart_nature
					   WHERE name LIKE '" . $this->vars['name'] . "'
					  ", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "INSERT INTO %s.smart_nature (name) VALUES ('%s')";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name']);
            $stmt = $this->dbHand->prepare($psql);
            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['pid']);
              $stmt->bindParam(3,$this->vars['torso']); */

            $stmt->execute();
            /* dump_array($stmt->errorInfo());
              exit; */

            return true;
        }
    }

    public function editItemRXX() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*) FROM %s.smart_rec
				WHERE name LIKE '" . $this->vars['name'] . "'
				AND ID != " . $this->id . "
				", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "UPDATE %s.smart_rec SET name = '%s'  WHERE ID = %d";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name'], $this->id);
            $stmt = $this->dbHand->prepare($psql);

            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['torso']);
              $stmt->bindParam(3,$this->id); */

            $stmt->execute();

            return true;
        }
    }

    public function editItemC() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*) FROM %s.smart_cric
				WHERE name LIKE '" . $this->vars['name'] . "'
				AND ID != " . $this->id . "
				", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "UPDATE %s.smart_cric SET name = '%s'  WHERE ID = %d";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name'], $this->id);
            $stmt = $this->dbHand->prepare($psql);

            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['torso']);
              $stmt->bindParam(3,$this->id); */

            $stmt->execute();

            return true;
        }
    }

    public function editItemNature() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*) FROM %s.smart_nature
				WHERE name LIKE '" . $this->vars['name'] . "'
				AND ID != " . $this->id . "
				", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "UPDATE %s.smart_nature SET name = '%s'  WHERE ID = %d";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name'], $this->id);
            $stmt = $this->dbHand->prepare($psql);

            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['torso']);
              $stmt->bindParam(3,$this->id); */

            $stmt->execute();

            return true;
        }
    }

    public function editItemRatXX() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*) FROM %s.smart_rat
				WHERE name LIKE '" . $this->vars['name'] . "'
				AND ID != " . $this->id . "
				", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "UPDATE %s.smart_rat SET name = '%s'  WHERE ID = %d";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name'], $this->id);
            $stmt = $this->dbHand->prepare($psql);

            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['torso']);
              $stmt->bindParam(3,$this->id); */

            $stmt->execute();

            return true;
        }
    }

    public function editItemDesi() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*) FROM %s.smart_desi
				WHERE name LIKE '" . $this->vars['name'] . "'
				AND ID != " . $this->id . "
				", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sql = "UPDATE %s.smart_desi SET name = '%s'  WHERE ID = %d";

            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name'], $this->id);
            $stmt = $this->dbHand->prepare($psql);

            /* $stmt->bindParam(1,$this->vars['name']);
              $stmt->bindParam(2,$this->vars['torso']);
              $stmt->bindParam(3,$this->id); */

            $stmt->execute();

            return true;
        }
    }

    /*     * *
     * This method is used to list single record
     * Array variables : id
     */

    public function displayItemByIdDesi() {

        $sql = "SELECT * FROM %s.smart_desi WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemByIdRatXX() {

        $sql = "SELECT * FROM %s.smart_rat WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemByIdNature() {

        $sql = "SELECT * FROM %s.smart_nature WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemByIdC() {

        $sql = "SELECT * FROM %s.smart_cric WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemByIdRXX() {

        $sql = "SELECT * FROM %s.smart_rec WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemById1XXX() {

        $sql = "SELECT * FROM %s.hazard_parent_classification WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsDesi() {

        $sql = sprintf("SELECT * FROM %s.smart_desi WHERE archive is NULL OR archive  = 0  ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsRatXX() {

        $sql = sprintf("SELECT * FROM %s.smart_rat WHERE archive is NULL OR archive = 0   ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsRat1XX() {

        $sql = sprintf("SELECT * FROM %s.smart_rat WHERE archive = 1   ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsDesi1() {

        $sql = sprintf("SELECT * FROM %s.smart_desi WHERE archive = 1  ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsNature() {

        $sql = sprintf("SELECT * FROM %s.smart_nature WHERE archive is NULL OR archive = 0  ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsNature1() {

        $sql = sprintf("SELECT * FROM %s.smart_nature WHERE archive = 1  ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsC1() {

        $sql = sprintf("SELECT * FROM %s.smart_cric WHERE archive = 1  ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsC() {

        $sql = sprintf("SELECT * FROM %s.smart_cric WHERE isnull(archive,0) = 0 ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsRXX() {

        $sql = sprintf("SELECT * FROM %s.smart_rec  ORDER BY ID ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemsaXX() {

        $sql = sprintf("SELECT * FROM %s.incidence_classification WHERE archive = 1 ORDER BY name ASC", _DB_OBJ_FULL);
        //$sql = "SELECT * FROM incidence_classification";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function archiveDesi($flag) {
        $this->flag = $flag;
        $sql = "UPDATE %s.smart_desi SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $flag, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

	public function archiveNative($flag) {
      $this->flag = $flag;
        $sql = "UPDATE %s.smart_nature SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $flag, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }
	
    public function archiveCric($flag) {
        $this->flag = $flag;
        $sql = "UPDATE %s.smart_cric SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $flag, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function archiveRat($flag) {
        $this->flag = $flag;
        $sql = "UPDATE %s.smart_rat SET archive = 0 WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->flag);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function archiveNature($flag) {
      $this->flag = $flag;
        $sql = "UPDATE %s.smart_nature SET archive = %d WHERE ID = %d";

      $psql = sprintf($sql, _DB_OBJ_FULL, $flag, $this->id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function deleteBCP() {

        $sql = "UPDATE %s.smart_desi SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);


        $stmt->execute();
    }

    public function deletenature() {

        $sql = "UPDATE %s.smart_nature SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);


        $stmt->execute();
    }

    public function deleterat() {

        $sql = "UPDATE %s.smart_rat SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);


        $stmt->execute();
    }


    public function equipmentTyperat() {

        $sql = "SELECT * FROM %s.smart_rat  WHERE archive is NULL OR archive = 0 order by ID ASC";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }



   public function getbcp() {

        $sql = "SELECT * FROM %s.smart_bcp";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpbir1($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_bcp WHERE ID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpbrp1($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_bir WHERE ID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpbir() {

        $sql = "SELECT * FROM %s.smart_bir";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpbrp() {

        $sql = "SELECT * FROM %s.smart_brp";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getEmailNew() {

        $objOption = new Option();
        $type = $objOption->getOption('_SU_EMAIL_NEW');
        $objOption = null;
        return $type;
    }

    public function editEmailNew() {

        $objOption = new Option();
        $objOption->updateOption('_SU_EMAIL_NEW', $this->vars['value']);
        $objOption = null;
    }

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'desi') {
            return $this->getExportDataDesi();
        } else if ($type == 'rat') {
            return $this->geteExportDataRat();
        } else if ($type == 'nature') {
            return $this->getExportDataNature();
        } else if ($type == 'cric') {
            return $this->getExportDataCrit();
        } else if ($type == 'rec') {
            return $this->getExportDataRec();
        } else if ($type == 'bia') {
            return $this->getExportDataBIA();
        } else if ($type == 'bia1') {
            return $this->getExportDataBIA1();
        } else if ($type == 'bir') {
            return $this->getExportDataBIR();
        } else if ($type == 'bir1') {
            return $this->getExportDataBIR1();
        } else if ($type == 'brp') {
            return $this->getExportBRP();
        } else if ($type == 'brp1') {
            return $this->getExportDataBRP1();
        }
    }
    
    public function getExportDataCrit() {
$heading = array(array(0=>'Criticality'));
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
if ($archive == 1)
		$export_data = $this->displayItemsC1();
else
$export_data = $this->displayItemsC();
		//dump_array($equipment_data);exit;

		if ( count($export_data) ) {

			foreach( $export_data as $key => $value) {


				$result1[$key] 	  =  array($value['name']);

			}
                    $result_new = array_merge($heading,$result1);
                    return $result_new;
		}
                else
                   return $heading;  


	}
        
 public function getExportDataDesi() {

		$heading = array(array(0=>'Event'));
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
if ($archive == 1)
		$export_data = $this->displayItemsDesi1();
                else
                $export_data = $this->displayItemsDesi();
		//dump_array($equipment_data);exit;

		if ( count($export_data) ) {

			foreach( $export_data as $key => $value) {


				$result1[$key] 	  =  array($value['name']);

			}
			//dump_array($bu_name);exit;
                    $result_new = array_merge($heading,$result1);
                    return $result_new;
		}
                else
                   return $heading;     
                        
	}
        
        public function getExportDataNature() {

		$heading = array(array(0=>'Resource Requirements'));
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
if ($archive == 1)
		$export_data = $this->displayItemsNature1();
            else 
                $export_data = $this->displayItemsNature();
		//dump_array($equipment_data);exit;

		if ( count($export_data) ) {

			foreach( $export_data as $key => $value) {


				$result1[$key] 	  =  array($value['name']);

			}
			//dump_array($bu_name);exit;

  $result_new = array_merge($heading,$result1);
                    return $result_new;
		}
                else
                   return $heading;     


	}
        
                                	public function archiveBCPCric($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.smart_cric SET archive = %d WHERE ID = %d";

	echo	$psql = sprintf($sql,_DB_OBJ_FULL,$this->flag,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

}
