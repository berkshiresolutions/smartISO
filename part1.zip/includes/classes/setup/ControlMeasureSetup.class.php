<?php
 /**
  $Id: ControlMeasureSetup.class.php,v 3.13 Friday, January 07, 2011 10:21:04 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:57:24 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class ControlMeasureSetup extends SetupOperation
{

	private $dbHand;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}

	/***
	 * This method is used to insert record
	 * Array variables : id,name,pid
	 */
	public function addItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.control_measures_hazard WHERE hazardName LIKE '".$this->vars['name']."' AND pID = ".$this->vars['pid'],_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sql = "INSERT INTO %s.control_measures_hazard (hazardName, pID) VALUES ('%s', %d)";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['pid']);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->vars['pid']);*/

			$stmt->execute();

			return true;
		}
	}

	/***
	 * This method is used to delete record
	 * array variables : id
	 */
    public function deleteItem() {

		
		
			$sql = "UPDATE %s.control_measures_hazard SET archive = 1 WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			return $stmt->execute();
	}

	/***
	 * This method is used to edit record
	 * Array variables : id,name
	 */
	public function editItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.control_measures_hazard WHERE hazardName LIKE '".$this->vars['name']."' AND ID != ".$this->id." AND pID = ".$this->vars['pid'],_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sql = "UPDATE %s.control_measures_hazard SET hazardName = '%s' WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			return $stmt->execute();
		}

	}

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = "SELECT * FROM %s.control_measures_hazard WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	public function displayThreatsById() {

		$sql = "SELECT * FROM %s.risk27kReport WHERE recordID = %d AND name='threats'";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}


	/***
	 * This method is used to list records
	 */
	public function displayItems() {

		$sql = "SELECT * FROM %s.control_measures_hazard WHERE pID = %d AND (archive is NULL OR archive = 0) ORDER BY ID DESC";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	public function displayItemsa() {

		$sql = "SELECT * FROM %s.control_measures_hazard WHERE pID = %d AND archive = 1 ORDER BY ID DESC";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	/***
	 * This method is used to list Parent records
	 */
	public function displayCategories() {

		$sql = sprintf("SELECT * FROM %s.control_measures_hazard WHERE pID = 0 ORDER BY ID ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
        	public function displayAllControls() {

		$sql = sprintf("SELECT * FROM %s.control_measures_hazard ",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
        
	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {
		
		$parent_id = (int) $_GET['pid'];
		
		$list = SetupGeneric::useModule('ControlMeasure');
		
		$archive_session 	= (int) Session::getSessionField('ARCHIVE_RECORDS');
		$list->setItemInfo(array(
							'id'=>$parent_id
							));
                if($archive_session  == 1)
		$data_records = $list->displayItemsa();
                else
                $data_records = $list->displayItems();
		
               
		$result1[0] 	  = array('Control Measures');		
		if ( is_array($data_records) ) {
			
			foreach( $data_records as $key => $value) {
			
				$control_id = $value['ID'];
				
				$result1[$control_id] 	  =  array($value['hazardName']);
				
			}

		}
		
		//$result_new = array_merge($heading,$result1);
		
		return $result1;
		
	}
        public function archiveCM($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.control_measures_hazard SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
}
