<?php
 /**
  $Id: ComplaintCategorySetup.class.php,v 3.15 Saturday, January 08, 2011 7:01:59 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:57:47 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * ComplaintSetup Class
 *
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class ComplaintCategorySetup extends SetupOperation {

	private $dbHand;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}


	/***
	 * This method is used to insert record
	 * Array variables : id,category_of_complaint
	 */

	public function addItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.complaint_category
				WHERE name LIKE '".$this->vars['category_of_complaint']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Category of complaint already exist.");
		} else {


			$sql = sprintf("INSERT INTO %s.complaint_category
							(name,sort)
							VALUES ('%s', %d)",_DB_OBJ_FULL,$this->vars['category_of_complaint'],$this->vars['sort_id']);

			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
			$stmt->bindParam(2,$this->vars['category_of_complaint'],PDO::PARAM_STR,50);
			$stmt->bindParam(3,$this->vars['sort_id'],PDO::PARAM_INT);*/

			$stmt->execute();

			//$lastInsertID 	= $this->dbHand->lastInsertId();
			$lastInsertID		= customLastInsertId( $this->dbHand,'complaint_category','compCatID');
			$sort				= $lastInsertID*100;

			$stmt = null;

			$sql = sprintf("UPDATE %s.complaint_category SET sort = %d WHERE compCatID = %d",_DB_OBJ_FULL,$sort,$lastInsertID);

			$stmt = $this->dbHand->prepare($sql);
			/*$stmt->bindParam(1,$sort,PDO::PARAM_INT);
			$stmt->bindParam(2,$lastInsertID,PDO::PARAM_INT);*/

			return $stmt->execute();
		}
	}

	/***
	 * This method is used to delete record
	 * array variables : id
	 */

    public function deleteItem() {

		$sql = sprintf("DELETE FROM %s.complaint_category WHERE compCatID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->id,PDO::PARAM_INT);*/

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}

	/***
	 * This method is used to edit record
	 * Array variables : id,category_of_complaint
	 */

	public function editItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.complaint_category
				WHERE name LIKE '".$this->vars['category_of_complaint']."'
				AND compCatID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("category of complaint already exist.");
		} else {

			$sql = sprintf("UPDATE %s.complaint_category
					SET
						name = '%s'
					WHERE
						compCatID = %d",_DB_OBJ_FULL,$this->vars['category_of_complaint'],$this->id);

			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,$this->vars['category_of_complaint'],PDO::PARAM_STR,50);
			$stmt->bindParam(2,$this->id,PDO::PARAM_INT);*/

			return $stmt->execute();
		}

	}

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = sprintf("SELECT * FROM %s.complaint_category WHERE compCatID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->id,PDO::PARAM_INT);*/
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	/***
	 * This method is used to list records
	 */

	public function displayItems() {

		$sql = sprintf("SELECT * FROM %s.complaint_category ORDER BY sort ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
}