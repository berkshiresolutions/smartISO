<?php
 /**
  $Id: EquipmentSetup.class_backup_20101217.php,v 3.61 Wednesday, January 05, 2011 11:58:07 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Object for Equipment Setup
  *
  * This object is used to manage operations of Equipment Setup
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:29:39 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing Equipment setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" subpackage
 */
class EquipmentSetup extends SetupOperation {

	/**
	 * This property will act as container for database object.
	 *
	 * @access private
	 */

	private $dbHand;

	/**
	 * Property to hold Equipment Id
	 *
	 * @access private
	 */
	private $equipmentId;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}


	/**
	 * This method is used to add an equipment.
	 *
	 * Array variable : id,location,company_name,reference,
	 * unique_reference,title,description,business_unit,
	 * who,maintenance_period,maintenance_period_type,calibration_period,
	 * calibration_period_type,document,
	 * contact_number,contact_email,is_training,equipment_class
	 *
	 * @access public
	 */

	public function addItem() {

		$already_exists 	= false;

		$sql = "SELECT COUNT(*) FROM equipments
				WHERE `equipTitle` LIKE '".$this->vars['title']."'
				AND `reference` LIKE '".$this->vars['reference']."' ";

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Equipment already exist.",20);
		} else {

			$stmt = $this->dbHand->prepare("INSERT INTO equipments
										   (equipID,locationID,companyName,reference,uniqueReference,equipTitle,equipmentDesc,
										   businessUnit,who,maintenancePeriod,maintenancePeriodType,calibrationPeriod,calibrationPeriodType,
										   documentID,contactNumber,contactEmail,flagIsTraining,equipClassID)
										   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

			$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
			$stmt->bindParam(2,$this->vars['location'],PDO::PARAM_INT);
			$stmt->bindParam(3,$this->vars['company_name'],PDO::PARAM_STR,150);
			$stmt->bindParam(4,$this->vars['reference'],PDO::PARAM_STR,50);
			$stmt->bindParam(5,$this->vars['unique_reference'],PDO::PARAM_STR,50);
			$stmt->bindParam(6,$this->vars['title'],PDO::PARAM_STR,100);
			$stmt->bindParam(7,$this->vars['description'],PDO::PARAM_STR);
			$stmt->bindParam(8,$this->vars['business_unit'],PDO::PARAM_INT);
			$stmt->bindParam(9,$this->vars['who'],PDO::PARAM_INT);
			$stmt->bindParam(10,$this->vars['maintenance_period'],PDO::PARAM_INT);
			$stmt->bindParam(11,$this->vars['maintenance_period_type'],PDO::PARAM_STR,1);
			$stmt->bindParam(12,$this->vars['calibration_period'],PDO::PARAM_INT);
			$stmt->bindParam(13,$this->vars['calibration_period_type'],PDO::PARAM_STR,1);
			$stmt->bindParam(14,$this->vars['document'],PDO::PARAM_INT);
			$stmt->bindParam(15,$this->vars['contact_number'],PDO::PARAM_STR,50);
			$stmt->bindParam(16,$this->vars['contact_email'],PDO::PARAM_STR,150);
			$stmt->bindParam(17,$this->vars['is_training'],PDO::PARAM_STR,3);
			$stmt->bindParam(18,$this->vars['equipment_class'],PDO::PARAM_INT);

			$queryExecute = $stmt->execute();

			$this->equipmentId = $this->dbHand->lastInsertId();
			$this->addEquipmentModuleData();

			//return $queryExecute;
		}
	}

	/**
	 * This method is used to delete an equipment.
	 * Array variables : id
	 * @access public
	 */
    public function deleteItem() {

		$sql = "DELETE FROM %s.equipments WHERE equipID = ?";
		$psql = sprintf($sql,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->bindParam(1,$this->id);

		$sql2 = "DELETE FROM %s.equipment_metadata WHERE equipmentsEquipID = ?";
		$psql2 = sprintf($sql2,_DB_OBJ_FULL);

		$stmt_2 = $this->dbHand->prepare($psql2);
		$stmt_2->bindParam(1,$this->id);

		if ( $stmt_2->execute() && $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * This method is used to edit an equipment.
	 *
	 * Array variables : id,location,company_name,reference,
	 * unique_reference,title,description,business_unit,
	 * who,maintenance_period,maintenance_period_type,calibration_period,
	 * calibration_period_type,document,
	 * contact_number,contact_email,is_training,equipment_class
	 *
	 * @access public
	 *
	 */
	public function editItem() {

		$already_exists 	= false;

		$sql = "SELECT COUNT(*) FROM equipments
				WHERE `equipTitle` LIKE '".$this->vars['title']."'
				AND `reference` LIKE '".$this->vars['reference']."'
				AND equipID != ".$this->id;

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Equipment already exist.");
		} else {

			$stmt = $this->dbHand->prepare("UPDATE equipments
											SET
												locationID = ?,
												companyName = ?,
												equipTitle = ?,
												equipmentDesc = ?,
												businessUnit = ?,
												who = ?,
												maintenancePeriod = ?,
												maintenancePeriodType = ?,
												calibrationPeriod = ?,
												calibrationPeriodType = ?,
												documentID = ?,
												contactNumber = ?,
												contactEmail = ?,
												flagIsTraining = ?,
												equipClassID = ?
											WHERE
												equipID = ?");

			$stmt->bindParam(1,$this->vars['location'],PDO::PARAM_INT);
			$stmt->bindParam(2,$this->vars['company_name'],PDO::PARAM_STR);
			$stmt->bindParam(3,$this->vars['title'],PDO::PARAM_STR);
			$stmt->bindParam(4,$this->vars['description'],PDO::PARAM_STR);
			$stmt->bindParam(5,$this->vars['business_unit'],PDO::PARAM_INT);
			$stmt->bindParam(6,$this->vars['who'],PDO::PARAM_INT);
			$stmt->bindParam(7,$this->vars['maintenance_period'],PDO::PARAM_INT);
			$stmt->bindParam(8,$this->vars['maintenance_period_type'],PDO::PARAM_STR);
			$stmt->bindParam(9,$this->vars['calibration_period'],PDO::PARAM_INT);
			$stmt->bindParam(10,$this->vars['calibration_period_type'],PDO::PARAM_STR);
			$stmt->bindParam(11,$this->vars['document'],PDO::PARAM_INT);
			$stmt->bindParam(12,$this->vars['contact_number'],PDO::PARAM_STR);
			$stmt->bindParam(13,$this->vars['contact_email'],PDO::PARAM_STR);
			$stmt->bindParam(14,$this->vars['is_training'],PDO::PARAM_STR);
			$stmt->bindParam(15,$this->vars['equipment_class'],PDO::PARAM_INT);
			$stmt->bindParam(16,$this->id,PDO::PARAM_INT);

			return $stmt->execute();
		}

	}

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = "SELECT * FROM equipments WHERE equipID = ?";

		$stmt = $this->dbHand->prepare($sql);
		$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	/**
	 * This method is used to list all equipments.
	 *
	 * @access public
	 */
	public function displayItems() {

		$sql = "SELECT * FROM equipments ORDER BY equipID DESC";

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	/**
	 * This method is to add dummy data in module's equipment supplier and damage tab
	 *
	 * @access private
	 */
	private function addEquipmentModuleData() {
		$sql = "INSERT INTO equipment_supplier_damage (equipID) VALUES (?) ";

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);
		$pStatement->execute();

	}

	/**
	 * This method lists equipment data relative to equipment class
	 * Array variables: id
	 *
	 * @access public
	*/
	public function displayItemsByClassification() {

		$sql = "SELECT equipID,reference,equipTitle FROM equipments WHERE equipClassID = ?";
		$stmt = $this->dbHand->prepare($sql);

		$objEquipClass	 = SetupGeneric::useModule('EquipmentClassification');
		$dataEquipClass = $objEquipClass->displayItems();

		$equipments = array();

		foreach ($dataEquipClass as $value) {

			$class_id = $value['ID'];
			$classification_name = $value['description'];

			$stmt->bindParam(1,$class_id,PDO::PARAM_INT);
			$stmt->execute();

			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$simpleresult = array();

			foreach ( $result as $result_ele ) {
				$simpleresult[$result_ele['equipID']] = $result_ele['reference'].' - '.$result_ele['equipTitle'];
			}

			if ( count($result) > 0 ) {
				$equipments[$classification_name] = $simpleresult;
			}
		}

		$objEquipClass = null;

		return $equipments;
	}

	/***
	 * This method lists equipments by equip class Id
	 * Array variables : id
	 */

	public function displayItemsByClassId($p_class_id) {

		$sql = "SELECT equipID,reference,equipTitle FROM equipments WHERE equipClassID = ?";

		$stmt = $this->dbHand->prepare($sql);
		$stmt->bindParam(1,$p_class_id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$simpleresult = array();

		foreach ( $result as $result_ele ) {
			$simpleresult[$result_ele['equipID']] = $result_ele['reference'];//.' - '.$result_ele['equipTitle'];
		}

		return $simpleresult;
	}

	public function getNextId() {
		$sql = " SHOW TABLE STATUS LIKE 'equipments' ";
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$result_set = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $result_set['Auto_increment'];
	}

	/**
	 * This method is used to add an equipment files
	 * equip id, identifier
	 */
	public function getEquipmentFile() {

		$sql =" SELECT * FROM equipment_files WHERE equipID = ? AND section = ?";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->id,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->vars['identifier'],PDO::PARAM_STR);

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($resultSet);

		return $resultSet;
	}

	/**
	 * This method is used to add an equipment files
	 * equip id, identifier
	 */
	public function deleteEquipmentFiles() {

		$sql =" DELETE FROM equipment_files WHERE equipID = ? AND section = ?";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->id,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->vars['identifier'],PDO::PARAM_STR);

		$pStatement->execute();
	}

	/**
	 * This method is used to list all equipments.
	 *
	 * @access public
	 */
	public function displayItemsByIS() {

		$sql = "SELECT * FROM equipments WHERE flagIsTraining LIKE '%IS%' ORDER BY equipID DESC";

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	/*
	 * This method is used to add manufacturer data
	 *
	 * @access public
	*/
	public function addManufacturer() {

		$sql = "INSERT INTO equipments (companyName, address, contactName, contactNumber, contactEmail, contactFax) VALUES (?, ?, ?, ?, ?, ?)";
		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->vars['company_name'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['address'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['contact_name'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['contact_number'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['contact_email'], PDO::PARAM_STR);
		$stmt->bindParam(6,$this->vars['contact_fax'], PDO::PARAM_STR);

		$stmt->execute();

		$this->equipmentId = $this->dbHand->lastInsertId();
	}

	/*
	 * This method is used to edit manufacturer data
	 *
	 * @access public
	*/
	public function editManufacturer() {

		$sql = "UPDATE equipments SET companyName = ?, address = ?, contactName = ?, contactNumber = ?, contactEmail = ?, contactFax = ? WHERE equipID = ?";
		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->vars['company_name'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['address'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['contact_name'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['contact_number'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['contact_email'], PDO::PARAM_STR);
		$stmt->bindParam(6,$this->vars['contact_fax'], PDO::PARAM_STR);
		$stmt->bindParam(7,$this->id, PDO::PARAM_INT);

		$stmt->execute();
	}

	public function getLastInsertId() {

		return $this->equipmentId;
	}

	/*
	 * This method manages equipment data
	 *
	 * @access public
	*/
	public function manageEquipment() {

		$sql = "UPDATE equipments SET reference = ?, uniqueReference = ?, equipTitle = ?, equipClassID = ?, equipmentDesc = ?, businessUnit = ?, datePurchased = ?, purchaseValue = ?, dateManufacture = ?, additionalInfo = ?, flagIsTraining = ? WHERE equipID = ?";

		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->vars['reference'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['unique_reference'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['equip_title'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['equip_class'], PDO::PARAM_INT);
		$stmt->bindParam(5,$this->vars['description'], PDO::PARAM_STR);
		$stmt->bindParam(6,$this->vars['business_unit'], PDO::PARAM_INT);
		$stmt->bindParam(7,format_date_for_mysql( $this->vars['purchase_date'] ));
		$stmt->bindParam(8,$this->vars['purchase_value'], PDO::PARAM_INT);
		$stmt->bindParam(9,format_date_for_mysql( $this->vars['manufacture_date'] ));
		$stmt->bindParam(10,$this->vars['additional_info'], PDO::PARAM_STR);
		$stmt->bindParam(11,$this->vars['flag'], PDO::PARAM_STR);
		$stmt->bindParam(12,$this->id, PDO::PARAM_INT);

		$stmt->execute();

	}

	/*
	 * This method manages maintenance data
	 *
	 * @access public
	*/
	public function manageMaintenance() {

		$sql = "UPDATE equipments SET maintenanceType = ?, maintenanceNature = ?, maintenanceCompetence = ?, maintenanceNotes = ?, maintenancePeriod = ?, maintenancePeriodType = ?, maintenanceDueDate = ? WHERE equipID = ?";
		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->vars['maintenence_type'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['maintenance_nature'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['competence'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['notes'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['maintenance_period'], PDO::PARAM_INT);
		$stmt->bindParam(6,$this->vars['maintenance_period_type'], PDO::PARAM_STR, 1);
		$stmt->bindParam(7,format_date_for_mysql( $this->vars['due_date'] ));
		$stmt->bindParam(8,$this->id, PDO::PARAM_INT);

		$stmt->execute();
	}

	/*
	 * This method manages calibration data
	 *
	 * @access public
	*/
	public function manageCalibration() {

		$sql = "UPDATE equipments SET calibrationType = ?, calibrationNature = ?, calibrationCompetence = ?, calibrationNotes = ?, calibrationPeriod = ?, calibrationPeriodType = ?, calibrationDueDate = ? WHERE equipID = ?";
		$stmt = $this->dbHand->prepare($sql);

		$stmt->bindParam(1,$this->vars['calibration_type'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['calibration_nature'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['competence'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['notes'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['calibration_period'], PDO::PARAM_INT);
		$stmt->bindParam(6,$this->vars['calibration_period_type'], PDO::PARAM_STR, 1);
		$stmt->bindParam(7,format_date_for_mysql( $this->vars['due_date'] ));
		$stmt->bindParam(8,$this->id, PDO::PARAM_INT);

		$stmt->execute();
	}

}
