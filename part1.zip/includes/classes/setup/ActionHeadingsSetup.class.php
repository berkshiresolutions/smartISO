<?php
 /**
  $Id: NetImpactSetup.class.php,v 3.11 Tuesday, January 18, 2011 5:51:54 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * Object used to manage net impact object
  *
  * This method is used to define various operations required to manage net impact object
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:05:48 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing net impact setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" subpackage
 */
class ActionHeadingsSetup extends SetupOperation {

	/**
	 * This property acts as continaer object for database class.
	 *
	 * @access private
	 */
	private $dbHand;

	/**
	 * This method is a public constructor
	 *
	 * @access public
	 */
	public function __construct() {

	
 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	/**
	 * This method is used to add net impact option
	 *
	 * Array Variables:
	 * 					id,description
	 *
	 * @access public
	 */
	public function addItem() {


	}

	/**
	 * This method is used to delete net impact option
	 *
	 * Array Variables:
	 * 					id
	 *
	 * @access public
	 */
    public function deleteItem() {


	}

	/**
	 * This method is used to edit net impact option
	 *
	 * Array Variables:
	 * 					id,description
	 *
	 * @access public
	 */
	public function editItem() {

		
			$sql = "UPDATE %s.action_headings SET title = '%s' WHERE id = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['title'],$this->id);
			$stmt = $this->dbHand->prepare($psql);

			return $stmt->execute();
		
	}
	

	/**
	 * This method is used to list NHP option by id.
	 *
	 * @access public
	 */
	public function displayItembyId() {

		$sql = sprintf("SELECT * FROM %s.action_headings
				WHERE id = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;

	}
	
	/**
	 * This method is used to list all NHP options
	 *
	 * @access public
	 */
	public function displayItems($group=5) {

		$sql = sprintf("SELECT * FROM %s.action_headings where grouptype=%d ORDER BY ID ASC",_DB_OBJ_FULL,$group);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}
	
	public function getGroupText($value=4,$group=5) {

		$sql = sprintf("SELECT title FROM %s.action_headings where grouptype=%d and value=%d ",_DB_OBJ_FULL,$group,$value);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result["title"];

	}

		public function getGroupData($value=4,$group=5) {

		$sql = sprintf("SELECT * FROM %s.action_headings where grouptype=%d and value=%d ",_DB_OBJ_FULL,$group,$value);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;

	}
	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport($group) {

		$heading = array(array('title'=>'Conformity Headings'));

		$result = $this->displayItems($group);
		
		//dump_array($result);

		if ( count($result) ) {

			foreach( $result as $key => $value) {
			
	
				$result1[] = $value['title'];
				
				

			}

		}


		$result_new = array_merge($heading,$result);

		return $result_new;

	}
}
