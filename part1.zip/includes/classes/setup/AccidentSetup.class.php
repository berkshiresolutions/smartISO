<?php
 /**
  $Id: AccidentSetup.class.php,v 3.55 Thursday, February 03, 2011 1:07:54 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * Authorized User setup object
  *
  * This object defines the set of operation for Authorized User Setup
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:59:52 PM>
  */


/**
 * SetupOperations Abstract class.
 *
 * Importing SetupOperations abstract class.
 * Test Script used is test18.php
 */
require_once "SetupOperation.abs.php";

/**
 * AuthorizedUserSetup Class
 *
 * Class is pending
 *
 * A setup class for managing authorised user setup permissions, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes"
 */
class AccidentSetup extends SetupOperation {

	/**
	 * Constructor for AuthorizedUser Setup Object
	 *
	 * This method is used to declare constructor for an AuthorizedUser Setup Object.
	 *
	 * @access public
	 */

	/* Database handler object container */
	private $dbHand;

	public function __construct() {

		$this->dbHand 	= DB::connect(_DB_TYPE);
	}

	public function addItem() {
		// do nothing
	}

    public function deleteItem() {
		// do nothing
	}

	private function flushParticipantList() {

		$p_sql = "DELETE FROM %s.accident_authorization_stats ";

		$psql = sprintf($p_sql,_DB_OBJ_FULL);
		$stmt 	= $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	public function editItem() {

			/*
			* Flush Participant records from authorization list for fresh entries
			*
			*/
		    $this->flushParticipantList();

			$authorization_cnt 		= count($this->vars['authorization']);

			$p_sql 	= "INSERT INTO %s.accident_authorization_stats(participantID) VALUES (%d)";


			if ( $authorization_cnt ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {

					$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->vars['authorization'][$k]);
					$stmt = $this->dbHand->prepare($psql);
					$stmt->execute();
				}
			}

			return true;
		//exit;
	}

	public function displayItems() {

		$sql = sprintf("SELECT * FROM %s.accident_authorization_stats ",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
}