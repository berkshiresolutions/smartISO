<?php
 /**
  $Id: DocClassificationSetup.class.php,v 3.08 Monday, January 17, 2011 11:33:05 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:55:30 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class DocClassificationSetup extends SetupOperation {

	private $optionObj;
	private $dbHand;

	public function __construct() {

		$this->optionObj 	= new Option();
		$this->dbHand 		= DB::connect(_DB_TYPE);
	}

	public function addItem() {
		// do nothing
	}

    public function deleteItem() {
		// do nothing
	}

	/***
	 * This method is used to update record
	 * Array variables : key,label
	 */
	public function editItem() {

		switch ($this->vars['key']) {

			case 'T' : $this->optionObj->updateOption('_SU_DOC_CLASS_TOPSECRET',$this->vars['label']); break;
			case 'S' : $this->optionObj->updateOption('_SU_DOC_CLASS_SECRET',$this->vars['label']); break;
			case 'D' : $this->optionObj->updateOption('_SU_DOC_CLASS_CONFIDENTIAL',$this->vars['label']); break;
			case 'R' : $this->optionObj->updateOption('_SU_DOC_CLASS_RESTRICTED',$this->vars['label']); break;
			case 'U' : $this->optionObj->updateOption('_SU_DOC_CLASS_UNCLASSIFIED',$this->vars['label']); break;

		}
	}

	/***
	 * This method is used to list record
	 */
	public function displayItems() {

		$arr['T'] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_TOPSECRET'),0);
		$arr['S'] 			= substr($this->optionObj->getOption('_SU_DOC_CLASS_SECRET'),0);
		//$arr['D'] 	= substr($this->optionObj->getOption('_SU_DOC_CLASS_CONFIDENTIAL'),0);
		$arr['C'] 	= substr($this->optionObj->getOption('_SU_DOC_CLASS_CONFIDENTIAL'),0);
		$arr['R'] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_RESTRICTED'),0);
		$arr['U'] 	= substr($this->optionObj->getOption('_SU_DOC_CLASS_UNCLASSIFIED'),0);

		return $arr;
	}
	
	public function displayItems1() {
		$arr['UNCLASSIFIED'] 	= $this->optionObj->getOption1('_SU_DOC_CLASS_UNCLASSIFIED');
		$arr['RESTRICTED'] 		= $this->optionObj->getOption1('_SU_DOC_CLASS_RESTRICTED');
		$arr['CONFIDENTIAL'] 	= $this->optionObj->getOption1('_SU_DOC_CLASS_CONFIDENTIAL');
		$arr['SECRET'] 			= $this->optionObj->getOption1('_SU_DOC_CLASS_SECRET');
		$arr['TOP_SECRET'] 		= $this->optionObj->getOption1('_SU_DOC_CLASS_TOPSECRET');
		
		
		
		

		return $arr;
	}
        	public function displayItems2() {
		$arr['U'] 	= $this->optionObj->getOption1('_SU_DOC_CLASS_UNCLASSIFIED');
		$arr['R'] 		= $this->optionObj->getOption1('_SU_DOC_CLASS_RESTRICTED');
		$arr['C'] 	= $this->optionObj->getOption1('_SU_DOC_CLASS_CONFIDENTIAL');
		$arr['S'] 			= $this->optionObj->getOption1('_SU_DOC_CLASS_SECRET');
		$arr['T'] 		= $this->optionObj->getOption1('_SU_DOC_CLASS_TOPSECRET');
		
		
		
		

		return $arr;
	}
	
			public function displayItemsNew() {

		$arr['T'] 		= $this->optionObj->getOption('_SU_DOC_CLASS_TOPSECRET');
		$arr['S'] 			= $this->optionObj->getOption('_SU_DOC_CLASS_SECRET');
		$arr['D'] 	= $this->optionObj->getOption('_SU_DOC_CLASS_CONFIDENTIAL');
		$arr['C'] 	= $this->optionObj->getOption('_SU_DOC_CLASS_CONFIDENTIAL');
		$arr['R'] 		= $this->optionObj->getOption('_SU_DOC_CLASS_RESTRICTED');
		$arr['U'] 	= $this->optionObj->getOption('_SU_DOC_CLASS_UNCLASSIFIED');

		return $arr;
	}
	
	public function updateOption($val) {
			$this->val = $val;
		$sql = sprintf("UPDATE %s.options SET 
										action = 'Active'
									WHERE opName ='".$this->val."'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionInfo['location']);
		$pStatement->bindParam(2,$this->InspectionInfo['participant']);
		$pStatement->bindParam(3,format_date_for_mysql($this->InspectionInfo['when_date']));
		$pStatement->bindParam(4,$this->InspectionId);*/

		//dump_array($this);

		$pStatement->execute();
	}
	public function updateOption1($val) {
			$this->val = $val;
		$sql = sprintf("UPDATE %s.options SET 
										action = 'Deactive'
									WHERE opName ='".$this->val."'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionInfo['location']);
		$pStatement->bindParam(2,$this->InspectionInfo['participant']);
		$pStatement->bindParam(3,format_date_for_mysql($this->InspectionInfo['when_date']));
		$pStatement->bindParam(4,$this->InspectionId);*/

		//dump_array($this);

		$pStatement->execute();
	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$heading = array(array('Classification'));

		$arr[1][0] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_TOPSECRET'),2);
		$arr[2][0] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_SECRET'),2);
		$arr[3][0] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_CONFIDENTIAL'),2);
		$arr[4][0] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_RESTRICTED'),2);
		$arr[5][0] 		= substr($this->optionObj->getOption('_SU_DOC_CLASS_UNCLASSIFIED'),2);

		//$arr = array($arr);

		$arr  = array_merge($heading,$arr);
		return $arr;

	}
		public function displayAction($p_name) {

		$sql = sprintf("SELECT * FROM %s.options WHERE opValue = '".$p_name."' ",_DB_OBJ_FULL);
		//echo $sql;
		$res = $this->dbHand->prepare($sql);
		$res->execute();

		$result = $res->fetchAll();

		return $result[0]['action'];
	}
	
	public function displayAction3($p_name) {

		$sql = sprintf("SELECT * FROM %s.options WHERE opValue = '".$p_name."' AND opName ='_SU_CONTRACT_DAEMAIL' ",_DB_OBJ_FULL);
		//echo $sql;
		$res = $this->dbHand->prepare($sql);
		$res->execute();

		$result = $res->fetchAll();

		return $result[0];
	}
	


	
}
