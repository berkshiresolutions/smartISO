<?php
 /**
  $Id: HazardClassificationSetup.class.php,v 3.24 Thursday, January 13, 2011 12:53:02 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This object is used to manage CRUD operations related to Hazard classification Setup Object
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:28:40 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class AssetTypeSetup extends SetupOperation {

	private $dbHand;

	public function __construct() {
		 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	/**
	 * This method is used to add record
	 *
	 * Array variables : id,name,pid
	 *
	 * @access public
	 *
	 */
	
public function addItem() {

		

			$sql = "INSERT INTO %s.asset_type (name, aID,cID) VALUES ('%s', %d, %d)";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['category'],$this->vars['class']);
			$stmt = $this->dbHand->prepare($psql);

			$stmt->execute();

			return true;
		
	}


	/**
	 * This method is used to delete record
	 *
	 * Array variables : id
	 * @access public
	 *
	*/

    public function deleteItem() {
	
	$sql = "UPDATE %s.asset_type SET archive = 1 WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;

		

	}


	public function editItem() {


			$sql = "UPDATE %s.asset_type SET name = '%s',aID=%d,cID=%d WHERE ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['category'],$this->vars['class'],$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;
	
	}


	


	/***
	 * This method is used to list single record
	 * Array variables : id
	 */



	public function displayItemById() {

		$sql = "SELECT * FROM %s.asset_type WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	


	
		public function displayItems() {
		

if ($this->vars["cid"] >0){
    $sql = "SELECT * FROM %s.asset_type WHERE aID = %d and cid =%d  AND ( archive is NULL OR archive = 0) order by cast(name as varchar(100))";
    $psql = sprintf($sql,_DB_OBJ_FULL,$this->id,$this->vars["cid"]);
}
    else
    {
		$sql = "SELECT * FROM %s.asset_type WHERE aID = %d  AND ( archive is NULL OR archive = 0) order by cast(name as varchar(100))";
                $psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
    }
		
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}
		public function displayItems1() {

                    if ($this->vars["cid"] >0){
    $sql = "SELECT * FROM %s.asset_type WHERE aID = %d and cid =%d  AND archive = 1 order by cast(name as varchar(100))";
    $psql = sprintf($sql,_DB_OBJ_FULL,$this->id,$this->vars["cid"]);
}
    else
    {
		$sql = "SELECT * FROM %s.asset_type WHERE aID = %d  AND archive = 1 order by cast(name as varchar(100))";
                $psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
    }

		//$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}
	
	public function archiveAsset($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.asset_type SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}


	
        public function displayTypeItems() {

		$sql = "SELECT * FROM %s.asset_type WHERE cID = %d  AND isnull(archive,0) = 0 ";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $result;
	}

        
public function getListingforExport() {

		 $type = $_GET['type'];

		if ( $type  =='full') {

			return $this->getAllExportDataFull();

		} else {

			return $this->getExportData();
		}
	}
	public function getAllExportDataFull() {

		$heading = array(array(0=>'Group',1=>'Category',2=>'Type'));

		$data_records = $this->displayItemsforAllCSV();


		if ( count($data_records) ) {

			foreach( $data_records as $key => $value) {

				$control_id = $value['ID'];

				$result1[$control_id] 	  =  array($value['primaryAssest'],$value['secondaryAssest'],$value['name']);
			}

		}

		$result_new = array_merge($heading,$result1);

		return $result_new;

	}
	public function getExportData() {
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
		$parent_id = (int) $_GET['pid'];

	
		$heading = array(array(0=>'Asset'));

		$this->setItemInfo(array(
							'id'=>$parent_id
							));
                if ($archive_session == 1)
                    $data_records = $this->displayItems1();
                else
		$data_records = $this->displayItems();


		if (is_array($data_records) ) {

			foreach( $data_records as $key => $value) {

				$control_id = $value['ID'];

				$result1[$control_id] 	  =  array($value['name']);
			}

		}

		$result_new = array_merge($heading,$result1);

		return $result_new;

	}
       	public function displayItemsforAllCSV() {
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
 $sql = "select C.ID,P.primaryAssest,C.secondaryAssest,T.name from %s.assest_primary_classification P inner join %s.assest_classification C on P.ID=C.aID inner join %s.asset_type T on C.ID=T.cID where isnull(T.archive,0)=%d order by P.ID";
		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$archive_session);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
        
            public function getdropdown($p_ref, $p_item) {

       $sql = sprintf("SELECT T.ID,T.name FROM %s.assest_classification C inner join %s.asset_type T on C.ID=T.cid where isnull(C.archive,0)=0 and isnull(T.archive,0)=0 and T.cID=%d", _DB_OBJ_FULL , _DB_OBJ_FULL, $p_ref);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $retString = "<OPTION value=0>-- Select --</OPTION>";
        foreach ($result as $data) {
            $retString.="<OPTION value=" . $data["ID"];
            if ($data["ID"] == $p_item)
                $retString.=" selected";
            $retString.=" >" . $data["name"] . "</OPTION>";
        }
        return $retString;
    }
}
