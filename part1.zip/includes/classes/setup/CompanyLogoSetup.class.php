<?php
 /**
  $Id: CompanyLogoSetup.class.php,v 3.08 Friday, January 07, 2011 9:57:14 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * Object for company logo.
  *
  * Object for performing various operations related to company logo upload and setup.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 6:01:58 PM>
  */

/**
 * Include SetupOperations abstract class
 *
 */
require_once "SetupOperation.abs.php";

/**
 * CompanyLogoSetup Class
 *
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class CompanyLogoSetup extends SetupOperation
{

	/* Database Handler Object container */
	private $dbHand;

	/**
	 * Constructor for CompanyLogoSetup class
	 *
	 * This method is used to initialize properties of the object and to
	 * establish a connection with the database.
	 *
	 * @access public
	 */
	public function __construct() {

		$this->optionObj 	= new Option();
		$this->dbHand 		= DB::connect(_DB_TYPE);
	}

	/**
	 * Stub
	 *
	 * This method does not perform any operation.
	 * This is just a place holder.
	 *
	 * @access public
	 */
	public function addItem() {
		// do nothing
	}

	/**
	 * Stub
	 *
	 * This method does not perform any operation.
	 * This is just a place holder.
	 *
	 * @access public
	 */
    public function deleteItem() {
		// do nothing
	}


	/**
	 * Upload a logo
	 *
	 * This method is used to upload company logo.
	 * Array variables : value
	 * @access public
	 */
	public function editItem() {
		$this->optionObj->updateOption('_SU_COMPANY_LOGO',$this->vars['value']);
	}

	/**
	 * Return company logo
	 *
	 * This method returns a company logo filename.
	 *
	 * @access public
	 */
	public function displayItems() {
		return $this->optionObj->getOption('_SU_COMPANY_LOGO');
	}
}