<?php
 /**
  $Id: DefaultPageSetup.class.php,v 3.03 Friday, January 07, 2011 10:05:49 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:56:24 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class DefaultPageSetup extends SetupOperation {

	private $optionObj;
	private $dbHand;

	public function __construct() {

		$this->optionObj 	= new Option();
		$this->dbHand 		= DB::connect(_DB_TYPE);
	}

	public function addItem() {
		// do nothing
	}

    public function deleteItem() {
		// do nothing
	}

	/***
	 * This method is used to update default screen
	 * Array variables : value
	 */
	public function editItem() {
		$this->optionObj->updateOption('_SU_DEFAULT_PAGE',$this->vars['value']);
	}

	/***
	 * This method is used to display default screen
	 */
	public function displayItems() {
		return $this->optionObj->getOption('_SU_DEFAULT_PAGE');
	}
}
?>