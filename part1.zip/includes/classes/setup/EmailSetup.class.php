<?php
 /**
  $Id: EmailSetup.class.php,v 3.05 Friday, January 07, 2011 9:57:24 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, October 08, 2010 12:36:30 PM>
  */

require_once "SetupOperation.abs.php";

class EmailSetup extends SetupOperation
{

	private $optionObj;
	private $dbHand;

	public function __construct() {

		$this->optionObj 	= new Option();
		$this->dbHand 		= DB::connect(_DB_TYPE);
	}

	public function addItem() {
		// do nothing
	}

    public function deleteItem() {
		// do nothing
	}

	/***
	 * This method is used to update record
	 * Array variables : id,blue_value,yellow_value,red_value,brown_value
	 */
	public function editItem() {
		$this->optionObj->updateOption('_SU_EMAIL_BLUEMAIL',$this->vars['blue_value']);
		$this->optionObj->updateOption('_SU_EMAIL_YELLOWMAIL',$this->vars['yellow_value']);
		$this->optionObj->updateOption('_SU_EMAIL_REDMAIL',$this->vars['red_value']);
		$this->optionObj->updateOption('_SU_EMAIL_MGTESC',$this->vars['brown_value']);
		$this->optionObj->updateOption('_SU_blue_c',$this->vars['blue_c']);
		$this->optionObj->updateOption('_SU_yellow_c',$this->vars['yellow_c']);
		$this->optionObj->updateOption('_SU_red_c',$this->vars['red_c']);
		$this->optionObj->updateOption('_SU_mgmt_c',$this->vars['mgmt_c']);
		$this->optionObj->updateOption('_SU_daily_c',$this->vars['daily_c']);
		$this->optionObj->updateOption('_SU_Daily_Date',$this->vars['daily_alert']);
		$this->optionObj->updateOption('_SU_Daily_Date_Manager',$this->vars['daily_alert_manager']);
                $this->optionObj->updateOption('_SU_ADMIN_CLOSE',$this->vars['allow_admin_closure']);
	}
	
	public function editItem1() {
            $this->optionObj->updateOption('_SU_EMAIL_MAIN_VALUE',$this->vars['maintenance_value']);
	    $this->optionObj->updateOption('_SU_EMAIL_CALIB_VALUE',$this->vars['calibration_value']);
	    $this->optionObj->updateOption('_SU_main_c',$this->vars['main_c']);
	    $this->optionObj->updateOption('_SU_cali_c',$this->vars['cali_c']);
		
	}
	
	public function editItem2($switch) {
	$this->switch = $switch;

		$this->optionObj->updateOption('_SU_Switch',$this->switch);
	
		
	}


	/***
	 * This method is used to display record
	 * Array variables : id
	 */
	public function displayItems() {
		$arr = array(
					 'blue_value'			=> $this->optionObj->getOption('_SU_EMAIL_BLUEMAIL'),
					 'yellow_value'			=> $this->optionObj->getOption('_SU_EMAIL_YELLOWMAIL'),
					 'red_value' 			=> $this->optionObj->getOption('_SU_EMAIL_REDMAIL'),
					 'brown_value' 			=> $this->optionObj->getOption('_SU_EMAIL_MGTESC'),
					
					 'blue_c' 	=> $this->optionObj->getOption('_SU_blue_c'),
					 'yellow_c' 	=> $this->optionObj->getOption('_SU_yellow_c'),
					 'red_c' 	=> $this->optionObj->getOption('_SU_red_c'),
					 'mgmt_c' 	=> $this->optionObj->getOption('_SU_mgmt_c'),
					 'main_c' 	=> $this->optionObj->getOption('_SU_main_c'),
					 'cali_c' 	=> $this->optionObj->getOption('_SU_cali_c'),
					 'daily_c' 	=> $this->optionObj->getOption('_SU_daily_c'),
					 'daily_alert' 	=> $this->optionObj->getOption('_SU_Daily_Date'),
					 'daily_alert_manager' 	=> $this->optionObj->getOption('_SU_Daily_Date_Manager'),
                                         'allow_admin_closure' 	=> $this->optionObj->getOption('_SU_ADMIN_CLOSE'),
					);

		return $arr;
	}
	
		public function displayItems1() {
		$arr = array(
                                        'maintenance_value'  => $this->optionObj->getOption('_SU_EMAIL_MAIN_VALUE'),
					 'calibration_value' => $this->optionObj->getOption('_SU_EMAIL_CALIB_VALUE'),
					 'main_c'            => $this->optionObj->getOption('_SU_main_c'),
					 'cali_c'            => $this->optionObj->getOption('_SU_cali_c')
					 
					);

		return $arr;
	}
	
			public function displayItems2() {
		$arr = array(
					 'switch'			=> $this->optionObj->getOption('_SU_Switch')
					
					 
					);

		return $arr;
	}
}
