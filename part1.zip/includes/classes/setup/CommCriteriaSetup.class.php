<?php

/**
  $Id: IncidenceDetailSetup.class.php,v 3.19 Saturday, January 29, 2011 10:21:24 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Setup
 * @subpackage Classes
 * @since  Saturday, August 14, 2010 5:27:06 PM>
 */
require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class CommCriteriaSetup extends SetupOperation {

    private $dbHand;

    public function __construct() {
        $this->dbHand = DB::connect(_DB_TYPE);
    }

    /**
     * This method is used to add record
     * Array variables :
     * id ,name, pid
     */
    public function addItem() {
        
    }

    public function editItem() {
        
    }

    public function deleteItem() {
        
    }

    public function displayItems() {
        
    }

    public function addItem_criteria() {

        $already_exists = false;

        $sql = sprintf("SELECT COUNT(*) FROM %s.comms_criteria WHERE criteria LIKE '" . $this->vars['name'] . "'", _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            /* Check the number of rows that match the SELECT statement */
            if ($res->fetchColumn() > 0) {
                $already_exists = true;
            }
        }

        $res = null;

        if ($already_exists) {
            return false;
        } else {

            $sort = 0;

            $sql = "INSERT INTO %s.comms_criteria (criteria) VALUES ('%s')";
            $psql = sprintf($sql, _DB_OBJ_FULL, $this->vars['name']);
            $stmt = $this->dbHand->prepare($psql);


            $stmt->execute();
        }
    }
		public function editItem_criteria() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.comms_critetia WHERE criteria LIKE '".$this->vars['name']."' AND ID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sql = "UPDATE %s.comms_criteria SET criteria = '%s' WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->id);
			$stmt = $this->dbHand->prepare($psql);

			$stmt->execute();

			return true;
		}

	}
	
    public function displayItemsa_criteria() {

        $sql = sprintf("SELECT * FROM %s.comms_criteria where archive=1 ORDER BY ID DESC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItems_criteria() {

        $sql = sprintf("SELECT * FROM %s.comms_criteria where isnull(archive,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayItemById_criteria() {

        $sql = "SELECT * FROM %s.comms_criteria WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);

        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

   

    public function getListingforExport() {

        $heading = array(array(0 => 'Criteria'));

        $result = $this->displayItems_criteria();
        
        //dump_array($result);exit;
        if (count($result)) {

            foreach ($result as $key => $value) {


                $sl_id = $value['ID'];

                $resulta[$sl_id][0] = str_replace(',', ' ', $value['criteria']);
 
            }

            $result_new = array_merge($heading, $resulta);
        } else {

            $result_new = $heading;
        }

        //dump_array($result_new);exit;
        return $result_new;
    }

        public function updateCriteria($id) {
        $sql = "UPDATE %s.comms_criteria SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function restoreCriteria($id) {
        $sql = "UPDATE %s.comms_criteria SET archive = 0 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }
    
        
       
}
