<?php
 /**
  $Id: StandardSetup.class.php,v 3.24 Thursday, January 20, 2011 4:56:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Quality Standards Setup operations
  *
  * This object will manage various quality standard setup operations.
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, October 08, 2010 12:38:42 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing quality standards setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" subpackage
 */
class DocScopeSetup extends SetupOperation {

	/**
	 * This property is used to store object of Options class.
	 *
	 * @access private
	 */
	private $optionObj;

	/**
	 * This property acts as continaer object for database class.
	 *
	 * @access private
	 */
	private $dbHand;

	/**
	 * This method is a public constructor
	 *
	 * @access public
	 */
	public function __construct() {

		$this->optionObj 	= new Option();
		$this->dbHand 		= DB::connect(_DB_TYPE);

	}

	/**
	 * This method is a stub
	 *
	 * @access public
	 */
	public function addItem() {
		// do nothing
	}

	/**
	 * This method is a stub
	 *
	 * @access public
	 */
    public function deleteItem() {
		// do nothing
	}

	/**
	 * This method is used to add,edit standards choosen by user
	 *
	 * standards(array)
	 * @access public
	 */
	public function editItem() {

// do nothing
	}


	/**
	 * This method is used to list all the choosen standards.
	 *
	 * @access public
	 */
	public function displayItems() {
		$sql = sprintf("SELECT * FROM %s.cms_document_scope
								ORDER BY
					ID ASC",_DB_OBJ_FULL);
                $stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}


public function getCode($id) {
		$sql = sprintf("SELECT * FROM %s.cms_document_scope where ID=%d",_DB_OBJ_FULL,$id);
                $stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
	
		return $result['code'];
}
	
}
