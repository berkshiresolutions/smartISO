<?php
 /**
  $Id: IncidenceDetailSetup.class.php,v 3.19 Saturday, January 29, 2011 10:21:24 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:27:06 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class CommManSetup extends SetupOperation
{

	private $dbHand;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}

	/**
	 *This method is used to add record
	 * Array variables :
	 * id ,name, pid
	 */
	
        public function addItem() {
            
        }
        public function editItem() {
            
        }
                public function deleteItem() {
            
        }
        
                        public function displayItems() {
            
        }
        

        public function displayItems_core() {

		 $sql = sprintf("SELECT * FROM %s.cor_type where isnull(archive,0)=0 ORDER BY ID DESC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
        
                public function displayItemsa_core() {

		 $sql = sprintf("SELECT * FROM %s.cor_type where archive=1 ORDER BY ID DESC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

public function displayItemById_cor() {

		$sql = "SELECT * FROM %s.cor_type WHERE ID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	

	
public function addItem_cor() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.cor_type WHERE name LIKE '".$this->vars['name']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sort = 0;

			$sql = "INSERT INTO %s.cor_type (name) VALUES ('%s')";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$sort);
			$stmt = $this->dbHand->prepare($psql);

			$stmt->execute();

		}
	}
	
        		public function editItem_cor() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.cor_type WHERE name LIKE '".$this->vars['name']."' AND ID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			return false;
		} else {

			$sql = "UPDATE %s.cor_type SET name = '%s' WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->id);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->vars['name']);
			$stmt->bindParam(2,$this->id);*/

			$stmt->execute();

			return true;
		}

	}
  
        public function getListingforExport() { 
        $type = $_GET['type'];
         if ($type="corr"){
            $this->getListingforExportCore ();  
         }
         else{
            $this->getListingforExportClient(); 
         }
                 
        }
        
        public function getListingforExportCore() {

		$heading = array(array(0=>'Name'));

		$result = $this->displayItems_core();

		//dump_array($result);exit;
		if ( count($result) ) {

			foreach( $result as $key => $value) {


				$sl_id = $value['ID'];
				
				$resulta[$sl_id][0] =  str_replace(',',' ',$value['name']);
				
				
			}
                       		
                        $result_new = array_merge($heading,$resulta);

		}
 else {
                    
                 $result_new = $heading;

 }
		
		//dump_array($result_new);exit;
		return $result_new;

	}
   public function updateCore($id) {      
        $sql = "UPDATE %s.cor_type SET archive = 1 WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$id);
			$stmt = $this->dbHand->prepare($psql);
			$stmt->execute();
                        return 1;
	}
           public function restoreCorr($id) {      
        $sql = "UPDATE %s.cor_type SET archive = 0 WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$id);
			$stmt = $this->dbHand->prepare($psql);
			$stmt->execute();
                        return 1;
	}
        
                	public function getCorrTypeNames($ctId) {

		$sql = sprintf("SELECT name FROM %s.cor_type WHERE ID in (%s)",_DB_OBJ_FULL, $ctId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
            
                foreach($records as $key =>$value){
                    $recStr.=$value["name"].",";
                } 
		return trim($recStr,",");
	} 
}
