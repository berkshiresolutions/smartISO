<?php
 /**
  $Id: EquipmentSetup.class.php,v 4.34 Friday, January 14, 2011 6:36:48 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Object for Equipment Setup
  *
  * This object is used to manage operations of Equipment Setup
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:29:39 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * A setup class for managing Equipment setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" subpackage
 */
class EquipmentSetup extends SetupOperation {

	/**
	 * This property will act as container for database object.
	 *
	 * @access private
	 */

	private $dbHand;

	/**
	 * Property to hold Equipment Id
	 *
	 * @access private
	 */
	private $equipmentId;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}


	/**
	 * This method is used to add an equipment.
	 *
	 * Array variable : id,location,company_name,reference,
	 * unique_reference,title,description,business_unit,
	 * who,maintenance_period,maintenance_period_type,calibration_period,
	 * calibration_period_type,document,
	 * contact_number,contact_email,is_training,equipment_class
	 *
	 * @access public
	 */

	public function addItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipments
				WHERE equipTitle LIKE '".$this->vars['title']."'
				AND reference LIKE '".$this->vars['reference']."' ",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Equipment already exist.",20);
		} else {

			$sql = "INSERT INTO %s.equipments
										(locationID,companyName,reference,uniqueReference,equipTitle,equipmentDesc,
										businessUnit,who,maintenancePeriod,maintenancePeriodType,calibrationPeriod,calibrationPeriodType,
										documentID,contactNumber,contactEmail,flagIsTraining,equipClassID)
										VALUES ( %d, '%s', '%s', '%s', '%s', '%s', %d, %d, %d, '%s', %d, '%s', %d, '%s', '%s', '%s', %d)";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['location'],$this->vars['company_name'],$this->vars['reference'],$this->vars['unique_reference'],
							$this->vars['title'],$this->vars['description'],$this->vars['business_unit'],$this->vars['who'],$this->vars['maintenance_period'],
							$this->vars['maintenance_period_type'],$this->vars['calibration_period'],$this->vars['calibration_period_type'],
							$this->vars['document'],$this->vars['contact_number'],
							$this->vars['contact_email'],$this->vars['is_training'],$this->vars['equipment_class']);

			$stmt = $this->dbHand->prepare($psql);

			/*$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
			$stmt->bindParam(2,$this->vars['location'],PDO::PARAM_INT);
			$stmt->bindParam(3,$this->vars['company_name'],PDO::PARAM_STR,150);
			$stmt->bindParam(4,$this->vars['reference'],PDO::PARAM_STR,50);
			$stmt->bindParam(5,$this->vars['unique_reference'],PDO::PARAM_STR,50);
			$stmt->bindParam(6,$this->vars['title'],PDO::PARAM_STR,100);
			$stmt->bindParam(7,$this->vars['description'],PDO::PARAM_STR);
			$stmt->bindParam(8,$this->vars['business_unit'],PDO::PARAM_INT);
			$stmt->bindParam(9,$this->vars['who'],PDO::PARAM_INT);
			$stmt->bindParam(10,$this->vars['maintenance_period'],PDO::PARAM_INT);
			$stmt->bindParam(11,$this->vars['maintenance_period_type'],PDO::PARAM_STR,1);
			$stmt->bindParam(12,$this->vars['calibration_period'],PDO::PARAM_INT);
			$stmt->bindParam(13,$this->vars['calibration_period_type'],PDO::PARAM_STR,1);
			$stmt->bindParam(14,$this->vars['document'],PDO::PARAM_INT);
			$stmt->bindParam(15,$this->vars['contact_number'],PDO::PARAM_STR,50);
			$stmt->bindParam(16,$this->vars['contact_email'],PDO::PARAM_STR,150);
			$stmt->bindParam(17,$this->vars['is_training'],PDO::PARAM_STR,3);
			$stmt->bindParam(18,$this->vars['equipment_class'],PDO::PARAM_INT);*/

			$queryExecute = $stmt->execute();

			$this->equipmentId = customLastInsertId($this->dbHand,'equipments','equipID');
			$this->addEquipmentModuleData();

			//return $queryExecute;
		}
	}
	
	
	
	public function editAssestDeprecated() {
	
	$sql = "UPDATE %s.assestMangement
								SET
									assest_c = '%s',
									assest_t = '%s',
									descp = '%s',
									loc = %d,
									bu = '%s',
									flag_v = '%s',
									ref = '%s'
									
								WHERE
									ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['equip_class'],$this->vars['equipment_type'],$this->vars['description'],$this->vars['location'],
							$this->vars['business_unit'],$this->vars['flag'],$this->vars['ref'],$this->id);

			$stmt = $this->dbHand->prepare($psql);

	

			return $stmt->execute();
	}
	
	public function editOrgi($buID) {
		$this->buid = $buID;
	$sql = "UPDATE %s.organigramDetail
								SET
									lead_a = '%s',
									audit_t = '%s',
									person_i = '%s',
									plan_d = '%s',
									summary = '%s',
									who_a = '%s',
									who_p = '%s'
									
									
								WHERE
									buID =".$this->buid;

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['l_aud'],$this->vars['audit_t'],$this->vars['person_i'],$this->vars['plan'],
							$this->vars['summary'],$this->vars['who_a'],$this->vars['who_p']);

			$stmt = $this->dbHand->prepare($psql);

	

			return $stmt->execute();
	}
	
	public function editMaterial() {

	$sql = "UPDATE %s.material
								SET
									reference = '%s',
									name = '%s',
									descp = '%s',
									manufacture = '%s',
									nature = '%s',
									cas = '%s',
									type = '%s',
									cost = '%s',
									unit = '%s',
									detail = '%s',
									qty = '%s',
									flag = '%s'
									
								WHERE
									ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['ref'],$this->vars['nam'],$this->vars['description'],$this->vars['manu'],
							$this->vars['nature'],$this->vars['cas'],$this->vars['type'],$this->vars['cost'],$this->vars['unit'],$this->vars['detail'],$this->vars['siz'],$this->vars['flag'],$this->id);

			$stmt = $this->dbHand->prepare($psql);

	

			return $stmt->execute();
	}
	
	public function addAssestDeprecated() {

	

			$sql = "INSERT INTO %s.assestMangement
										(assest_c,assest_t,descp,loc,bu,flag_v,ref)
										VALUES ('%s', '%s', '%s',%d, %d,'%s', '%s')";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['equip_class'],$this->vars['equipment_type'],$this->vars['description'],$this->vars['location'],
							$this->vars['business_unit'],$this->vars['flag'],$this->vars['ref']);

			$stmt = $this->dbHand->prepare($psql);



			$queryExecute = $stmt->execute();

			$this->equipmentId = customLastInsertId($this->dbHand,'equipments','equipID');
			$this->addEquipmentModuleData();

			//return $queryExecute;
		
	}
	
	public function addOrganigramDetail() {

	

			$sql = "INSERT INTO %s.organigramDetail
										(lead_a,audit_t,person_i,plan_d,summary,who_a,who_p,buID)
										VALUES ('%s', '%s', '%s','%s', '%s','%s', '%s',%d)";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['l_aud'],$this->vars['audit_t'],$this->vars['person_i'],$this->vars['plan'],
							$this->vars['summary'],$this->vars['who_a'],$this->vars['who_p'],$this->vars['buid']);

			$stmt = $this->dbHand->prepare($psql);



			$queryExecute = $stmt->execute();

			$idd = customLastInsertId($this->dbHand,'organigramDetail','ID');
			//$this->addEquipmentModuleData();

			return $idd;
		
	}
	
	public function addOrganigramPerson() {

	

			$sql = "INSERT INTO %s.organigramPerson
										(buID,audit_t,person)
										VALUES (%d, '%s', '%s')";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['buid'],$this->vars['who_a'],$this->vars['who_p']
							);

			$stmt = $this->dbHand->prepare($psql);



			$queryExecute = $stmt->execute();

			//$idd = customLastInsertId(& $this->dbHand,'organigramDetail','ID');
			//$this->addEquipmentModuleData();

			//return $idd;
		
	}
	
	public function addOrganigramPerson1() {

	

			$sql = "INSERT INTO %s.organigramPerson
										(buID,audit_t,person)
										VALUES (%d, '%s', '%s')";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['buid'],$this->vars['who_a'],$this->vars['who_p']
							);

			$stmt = $this->dbHand->prepare($psql);



			$queryExecute = $stmt->execute();

			//$idd = customLastInsertId(& $this->dbHand,'organigramDetail','ID');
			//$this->addEquipmentModuleData();

			//return $idd;
		
	}
	
		public function addMaterial() {

	

			$sql = "INSERT INTO %s.material
										(reference,name,descp,manufacture,nature,cas,type,cost,unit,detail,qty,flag)
										VALUES ('%s', '%s', '%s','%s', '%s', '%s','%s', '%s', '%s','%s', '%s', '%s')";

		echo	$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['ref'],$this->vars['nam'],$this->vars['description'],$this->vars['manu'],
							$this->vars['nature'],$this->vars['cas'],$this->vars['type'],$this->vars['cost'],$this->vars['unit'],$this->vars['detail'],$this->vars['siz'],$this->vars['flag']);

			$stmt = $this->dbHand->prepare($psql);



			$queryExecute = $stmt->execute();

			//$this->equipmentId = customLastInsertId(& $this->dbHand,'equipments','equipID');
			//$this->addEquipmentModuleData();

			//return $queryExecute;
		
	}

	/**
	 * This method is used to delete an equipment.
	 * Array variables : id
	 * @access public
	 */
    public function deleteItem() {

		

		$sql = "UPDATE %s.equipment_consumables
								SET
									archive = 1
								WHERE
									ID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

			$stmt = $this->dbHand->prepare($psql);

	

			return $stmt->execute();

	
	}

	/**
	 * This method is used to edit an equipment.
	 *
	 * Array variables : id,location,company_name,reference,
	 * unique_reference,title,description,business_unit,
	 * who,maintenance_period,maintenance_period_type,calibration_period,
	 * calibration_period_type,document,
	 * contact_number,contact_email,is_training,equipment_class
	 *
	 * @access public
	 *
	 */
	public function editItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipments
				WHERE equipTitle LIKE '".$this->vars['title']."'
				AND reference LIKE '".$this->vars['reference']."'
				AND equipID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Equipment already exist.");
		} else {

			$sql = "UPDATE %s.equipments
								SET
									locationID = %d,
									companyName = '%s',
									equipTitle = '%s',
									equipmentDesc = '%s',
									businessUnit = %d,
									who = %d,
									maintenancePeriod = %d,
									maintenancePeriodType = '%s',
									calibrationPeriod = %d,
									calibrationPeriodType = '%s',
									documentID = %d,
									contactNumber = '%s',
									contactEmail = '%s',
									flagIsTraining = '%s',
									equipClassID = %d
								WHERE
									equipID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['location'],$this->vars['company_name'],
							$this->vars['title'],$this->vars['description'],$this->vars['business_unit'],$this->vars['who'],$this->vars['maintenance_period'],
							$this->vars['maintenance_period_type'],$this->vars['calibration_period'],$this->vars['calibration_period_type'],
							$this->vars['document'],$this->vars['contact_number'],
							$this->vars['contact_email'],$this->vars['is_training'],$this->vars['equipment_class'],$this->id);

			$stmt = $this->dbHand->prepare($psql);

	

			return $stmt->execute();
		}

	}

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = "SELECT * FROM %s.equipments WHERE equipID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayItemById_rdepreacated() {

		$sql = "SELECT * FROM %s.assestMangement WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayItemById_m() {

		$sql = "SELECT * FROM %s.material WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	
	public function displayItemById_c() {

		$sql = "SELECT * FROM %s.[assest_primary_classification] WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	

	/**
	 * This method is used to list all equipments.
	 *
	 * @access public
	 */
	public function displayItems() {

		if ($this->vars['archive']) {
			$sql = sprintf("SELECT * FROM %s.equipments WHERE archive = '%s' ORDER BY equipID DESC",_DB_OBJ_FULL,$this->vars['archive']);
		} else {
			$sql = sprintf("SELECT * FROM %s.equipments WHERE archive IS NULL OR archive = 0 ORDER BY equipID DESC",_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $result;
	}
	
	public function displayItems1depreacated() {

		if ($this->vars['archive']) {
			$sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive = '%s' ORDER BY assest_c ASC",_DB_OBJ_FULL,$this->vars['archive']);
		} else {
			$sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive IS NULL OR archive = 0 ORDER BY assest_c ASC",_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
		public function displayItemsIndex($sort='ORDER BY equipID DESC',$search='') {

		if ($this->vars['archive']) {
			$sql = sprintf("SELECT E.reference,E.equipID,E.equipmentDesc,E.maintenanceRequired,E.calibrationRequired,L.name,P.forename+' '+P.srname as famname,E.calibrationDueDate,E.maintenanceDueDate FROM %s.equipments E left join %s.locationgram L on E.equipDetailLocID=L.locID inner join %s.participant_database P on E.whoID=P.participantID WHERE archive = '%s' %s %s",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->vars['archive'],$search,$sort);
		} else {
			$sql = sprintf("SELECT E.reference,E.equipID,E.equipmentDesc,E.maintenanceRequired,E.calibrationRequired,L.name,P.forename+' '+P.surname as famname,E.calibrationDueDate,E.maintenanceDueDate FROM %s.equipments E left join %s.locationgram L on E.equipDetailLocID=L.locID inner join %s.participant_database P on E.whoID=P.participantID WHERE (archive IS NULL OR archive = 0) %s %s",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$search,$sort);
		}
		
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
			public function getCalibrationDataIndex() {


		$sql = sprintf("select equipID,max(calibrationDueDate) as cdd  from %s.maintenance_calibration_records where calibrationDueDate>'1970-1-1' group by equipID",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach($data as $row){
		$result[$row["equipID"]]=$row["cdd"];
		}

		return $result;
	}

			public function getMaintenanceDataIndex() {

			$sql = sprintf("select  equipID,max(maintenanceDueDate) as mdd  from %s.maintenance_calibration_records where maintenanceDueDate>'1970-1-1'  group by equipID",_DB_OBJ_FULL);


		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();


		$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		foreach($data as $row){
		$result[$row["equipID"]]=$row["mdd"];
		}

		return $result;
		
	}
	
	public function displayItems_assestdepreacated() {

		if ($this->vars['archive']) {
			$sql = sprintf("SELECT * FROM %s.assestMangement  WHERE archive = '%s' ORDER BY ID DESC ",_DB_OBJ_FULL,$this->vars['archive']);
		} else {
			$sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive IS NULL OR archive = 0 ORDER BY ID DESC",_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
	public function displayItems_assest1() {

$this->vars['archive'] = (int) Session::getSessionField('ARCHIVE_RECORDS');

		if ($this->vars['archive']) {
			$sql = sprintf("SELECT * FROM %s.material  WHERE archive = '%s' ORDER BY ID DESC ",_DB_OBJ_FULL,$this->vars['archive']);
		} else {
			$sql = sprintf("SELECT * FROM %s.material WHERE archive IS NULL OR archive = 0 ORDER BY ID DESC",_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}

	/**
	 * This method lists equipment data relative to equipment class
	 * Array variables: id
	 *
	 * @access public
	*/
	public function displayItemsByClassification() {

		$sql = "SELECT equipID,reference,equipTitle FROM %s.equipments WHERE equipClassID = %d";


		$objEquipClass	 = SetupGeneric::useModule('EquipmentClassification');
		$dataEquipClass = $objEquipClass->displayItems();

		$equipments = array();

		foreach ($dataEquipClass as $value) {

			$class_id = $value['ID'];
			$classification_name = $value['description'];

			//$stmt->bindParam(1,$class_id,PDO::PARAM_INT);
			$psql = sprintf($sql,_DB_OBJ_FULL,$class_id);
			$stmt = $this->dbHand->prepare($psql);
			$stmt->execute();

			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$simpleresult = array();

			foreach ( $result as $result_ele ) {
				$simpleresult[$result_ele['equipID']] = $result_ele['reference'].' - '.$result_ele['equipTitle'];
			}

			if ( count($result) > 0 ) {
				$equipments[$classification_name] = $simpleresult;
			}
		}

		$objEquipClass = null;

		return $equipments;
	}

	/***
	 * This method lists equipments by equip class Id
	 * Array variables : id
	 */

	public function displayItemsForDse($p_class_id,$p_type='TRG') {

		$sql = "SELECT * FROM %s.equipments  ";

		$psql = sprintf($sql,_DB_OBJ_FULL,$p_class_id);

		$psql = $psql."  WHERE reference LIKE '".$p_class_id."%'";

		$psql = $psql."  AND flagIsTraining LIKE '%".$p_type."%'";

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$p_class_id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$simpleresult = array();

		foreach ( $result as $result_ele ) {
				//dump_array($result_ele);
			if ( $result_ele['reference'] != '' ) {
				
				$simpleresult[$result_ele['equipID']] = $result_ele['reference'];
				//$title = $result_ele['equipTitle'];
				//if ( strlen($title) > 20 ) {
				//	$title = substr($title,0,20).'..';
			//	}
				//$simpleresult[$result_ele['equipID']] = $result_ele['reference'].' - '.$title;//.' - '.$result_ele['equipTitle'];
			}
		}

		return $simpleresult;
	}

	/*public function getNextId() {
		$sql = " SHOW TABLE STATUS LIKE equipments";
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$result_set = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $result_set['Auto_increment'];
	}*/

	/**
	 * This method is used to add an equipment files
	 * equip id, identifier
	 */
	/*public function getEquipmentFile() {

		$sql =" SELECT * FROM equipment_files WHERE equipID = ? AND section = ?";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->id,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->vars['identifier'],PDO::PARAM_STR);

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($resultSet);

		return $resultSet;
	}*/

	/**
	 * This method is used to add an equipment files
	 * equip id, identifier
	 */
	/*public function deleteEquipmentFiles() {

		$sql =" DELETE FROM equipment_files WHERE equipID = ? AND section = ?";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->id,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->vars['identifier'],PDO::PARAM_STR);

		$pStatement->execute();
	}*/

	/**
	 * This method is used to list all equipments.
	 *
	 * @access public
	 */
	public function displayItemsByIS() {

		$tablename = sprintf("%s.equipments",_DB_OBJ_FULL);

		$sql = "SELECT * FROM ".$tablename." WHERE flagIsTraining LIKE '%IS%' ORDER BY equipID DESC";

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	/*
	 * This method is used to add manufacturer data
	 *
	 * @access public
	*/
	public function addManufacturer() {

		/*$already_exists = false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipments WHERE manufacturerReference = '".$this->vars['manufacturer_reference']."'",_DB_OBJ_FULL);

		if ( $res = $this->dbHand->query($sql) ) {

			if ( $res->fetchColumn() > 0 ) {

				$already_exists = true;
			}
		}

		$res = NULL;

		if ( $already_exists ) {

			throw new ErrorException("This reference number already exists.");

		} else {*/
			$USER_ID  = getLoggedInUserId();

			$sql2 = "INSERT INTO %s.equipments (companyName, address, contactName, contactNumber, contactEmail, contactFax, whoID, reference, uniqueReference,
												maintenanceRequired,calibrationRequired)
			VALUES ('%s', '%s', '%s', '%s', '%s', '%s' , %d, '%s', '%s', '%s', '%s')";

			$psql = sprintf($sql2,_DB_OBJ_FULL,$this->vars['company_name'],
							$this->vars['address'],$this->vars['contact_name'],$this->vars['contact_number'],$this->vars['contact_email'],
							$this->vars['contact_fax'],$USER_ID, $this->vars['equip_ref'], $this->vars['equip_ref'], $this->vars['maintenance_req'],
							$this->vars['calib_req']);

			$stmt = $this->dbHand->prepare($psql);

			/*$stmt->bindParam(1,$this->vars['manufacturer_reference'], PDO::PARAM_STR);
			$stmt->bindParam(2,$this->vars['company_name'], PDO::PARAM_STR);
			$stmt->bindParam(3,$this->vars['address'], PDO::PARAM_STR);
			$stmt->bindParam(4,$this->vars['contact_name'], PDO::PARAM_STR);
			$stmt->bindParam(5,$this->vars['contact_number'], PDO::PARAM_STR);
			$stmt->bindParam(6,$this->vars['contact_email'], PDO::PARAM_STR);
			$stmt->bindParam(7,$this->vars['contact_fax'], PDO::PARAM_STR);*/

			$stmt->execute();
			//dump_array($stmt->errorInfo());
			//exit;

			$this->equipmentId = customLastInsertId($this->dbHand,'equipments','equipID');
			$this->addEquipmentModuleData();

		//}
	}

	/*
	 * This method is used to edit manufacturer data
	 *
	 * @access public
	*/
	public function editManufacturer() {

		$sql = "UPDATE %s.equipments SET companyName = '%s', address = '%s', contactName = '%s', contactNumber = '%s', contactEmail = '%s',
										contactFax = '%s',maintenanceRequired = '%s',calibrationRequired = '%s' WHERE equipID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['company_name'],
							$this->vars['address'],$this->vars['contact_name'],$this->vars['contact_number'],$this->vars['contact_email'],
							$this->vars['contact_fax'],$this->vars['maintenance_req'],$this->vars['calib_req'],$this->id);

		$stmt = $this->dbHand->prepare($psql);

		/*$stmt->bindParam(1,$this->vars['company_name'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['address'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['contact_name'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['contact_number'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['contact_email'], PDO::PARAM_STR);
		$stmt->bindParam(6,$this->vars['contact_fax'], PDO::PARAM_STR);
		$stmt->bindParam(7,$this->id, PDO::PARAM_INT);*/

		$stmt->execute();

	}

	public function getLastInsertId() {

		return $this->equipmentId;
	}

	/**
	 * This method is to add dummy data in 'equipment_client_details' and 'equipment_contacts' tables.
	 *
	 * @access private
	 */
	private function addEquipmentModuleData() {

		$sql = "INSERT INTO %s.equipment_client_details (equipID) VALUES (%d) ";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentId);

		$pStatement = $this->dbHand->prepare($psql);
		$pStatement->execute();

		$sql2 = "INSERT INTO %s.equipment_contacts (equipID,jobType) VALUES (%d,'%s')";

		$psql2 = sprintf($sql2,_DB_OBJ_FULL,$this->equipmentId,'M');
		$pStatement = $this->dbHand->prepare($psql2);
		$pStatement->execute();

		$psql2 = sprintf($sql2,_DB_OBJ_FULL,$this->equipmentId,'C');
		$pStatement = $this->dbHand->prepare($psql2);
		$pStatement->execute();


		//$contact_type = 'E';		//'E' - external contact
		//$psql2 = sprintf($sql2,_DB_OBJ_FULL,$this->equipmentId,$contact_type);
		//$pStatement = $this->dbHand->prepare($psql2);


		//$pStatement->bindParam(2,$contact_type, PDO::PARAM_STR, 1);
		//$pStatement->execute();

		//dump_array($pStatement->errorInfo());
	}

	/*
	 * This method manages equipment data
	 *
	 * @access public
	*/
	public function manageEquipment() {

		$already_exists = false;
if($this->vars['reference']){
		$sql = sprintf("SELECT COUNT(*) FROM %s.equipments WHERE reference = '".$this->vars['reference']."'",_DB_OBJ_FULL);

		if ( $res = $this->dbHand->query($sql) ) {

			if ( $res->fetchColumn() > 1 ) {

				$already_exists = true;
			}
		}
}
		$res = NULL;

		if ( $already_exists ) {

			throw new ErrorException("This reference number already exists.");

		} else {

			$reference_filter	= "";

			if ( $this->vars['task'] == 'add' ) {

				$reference_filter	= " reference = '".$this->vars['reference']."', manufacturerReference = '".$this->vars['manufacturer_reference']."',";
				//$reference_filter	= " manufacturerReference = '".$this->vars['manufacturer_reference']."',";
			}

			$purchase_date = $this->vars['purchase_date'] == '' ? ''  : format_date_time_for_mysql($this->vars['purchase_date']);
			$manufacture_date = $this->vars['manufacture_date'] == '' ? ''  : format_date_for_mysql($this->vars['manufacture_date']);

			$sql = "UPDATE %s.equipments SET".$reference_filter." equipTitle = '%s', equipClassID = %d, equipmentDesc = '%s',
					businessUnit = %d, datePurchased = '%s', purchaseValue = %f, dateManufacture = '%s', additionalInfo = '%s', flagIsTraining = '%s',
					equipDetailLocID = %d,equipmentType ='%s'
					WHERE equipID = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,
							$this->vars['equip_title'],$this->vars['equip_class'],$this->vars['description'],$this->vars['business_unit'],
							$purchase_date,$this->vars['purchase_value'],
							$manufacture_date,$this->vars['additional_info'],$this->vars['flag'],$this->vars['location'],$this->vars['equipment_type'],
							$this->id);

			$stmt = $this->dbHand->prepare($psql);

			/*$stmt->bindParam(1,$this->vars['unique_reference'], PDO::PARAM_STR);
			$stmt->bindParam(2,$this->vars['equip_title'], PDO::PARAM_STR);
			$stmt->bindParam(3,$this->vars['equip_class'], PDO::PARAM_INT);
			$stmt->bindParam(4,$this->vars['description'], PDO::PARAM_STR);
			$stmt->bindParam(5,$this->vars['business_unit'], PDO::PARAM_INT);
			$stmt->bindParam(6,format_date_time_for_mysql($this->vars['purchase_date']));
			$stmt->bindParam(7,$this->vars['purchase_value'], PDO::PARAM_INT);
			$stmt->bindParam(8,format_date_for_mysql($this->vars['manufacture_date']));
			$stmt->bindParam(9,$this->vars['additional_info'], PDO::PARAM_STR);
			$stmt->bindParam(10,$this->vars['flag'], PDO::PARAM_STR);
			$stmt->bindParam(11,$this->id, PDO::PARAM_INT);*/

			$stmt->execute();

		}

	}

	/*
	 * This method manages maintenance data
	 *
	 * @access public
	*/
	public function manageMaintenance() {

		$due_date = $this->vars['due_date'] == '' ? '1900-01-01' : format_date_for_mysql($this->vars['due_date']);

		//echo $this->id;
		$sql = "UPDATE %s.equipments SET maintenanceType = '%s', maintenanceNature = '%s', maintenanceCompetence = '%s',
					maintenanceNotes = '%s', maintenancePeriod = %d, maintenancePeriodType = '%s', maintenanceDueDate = '%s' WHERE equipID = %d";
					// ,maintenanceRequired='%s'

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['maintenence_type'],
							$this->vars['maintenance_nature'],$this->vars['competence'],$this->vars['notes'],$this->vars['maintenance_period'],
							$this->vars['maintenance_period_type'],
							$due_date,$this->id);
		// ,$this->vars['maintenance_req']

		$stmt = $this->dbHand->prepare($psql);

		/*$stmt->bindParam(1,$this->vars['maintenence_type'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['maintenance_nature'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['competence'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['notes'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['maintenance_period'], PDO::PARAM_INT);
		$stmt->bindParam(6,$this->vars['maintenance_period_type'], PDO::PARAM_STR, 1);
		$stmt->bindParam(7,format_date_for_mysql( $this->vars['due_date'] ));
		$stmt->bindParam(8,$this->id, PDO::PARAM_INT);*/

		$stmt->execute();
		/*dump_array($stmt->errorInfo());
		exit;*/

		$this->moveMaintenanceCalibrationFile($this->id,'MAIN');
	}

	private function moveMaintenanceCalibrationFile($p_equipId,$p_tabType='MAIN') {

		$rec_details = $this->displayItemById();

		$rec_id = $p_equipId;
		$module = 'equipment';

		$path = $_SERVER['DOCUMENT_ROOT'].'/tmp/'.$module;

		$log_file = $path.'/script'.$rec_id.'.log';

		if ( file_exists($log_file) ) {

			$log = fopen($log_file, 'r');
			$contents = fread($log, filesize($log_file));
			fclose($log);

			$file_records = explode("\n",$contents);

			$objFile = new Upload();

			if ( $p_tabType == 'MAIN' ) {
				$file_id = $rec_details['maintDocumentID'];
			} else {
				$file_id = $rec_details['calDocumentID'];
			}

			if ($file_id) {

				$objFile->setFileInfo('equipment',array('id'=>$file_id));
				$single_files_data = $objFile->getFileDetails();

				$objFile->setFileInfo('equipment',array('id'=>$single_files_data['fileID'],'destination'=>'equipment'));
				$objFile->delete_file();

				$this->vars['file_id'] = $file_id;
				$this->deleteEquipmentFile($p_tabType);
			}

			//$incidenceObj		= new IncidenceMain();

			if ( count($file_records) ) {
				foreach ( $file_records as $value ) {
					if ( $value != '' ) {

						$file_details_arr = explode('~#~',$value);
						$file_path = $path.'/'.$file_details_arr[1];

						if ( file_exists($file_path)) {

							$file_type = mime_content_type($file_path);

							$file_details = array('user_file_name'=>$file_details_arr[2],'file_type'=>$file_type);
							$objFile->setFileInfo($module,$file_details);
							$objFile->setBogusDetails($file_details);
							$objFile->uploadifyAddFileDb();
							$sys_file_name = $objFile->uploadifySysFileName();

							$new_file_path = _PATH_PUB.$module.'/'.$sys_file_name;
						//	echo "<br/>";

							if ( copy($file_path,$new_file_path )) {

								$objFile->updateUploadifyFileName();
								$file_id = $objFile->getLastFileId();

								if ($file_id ) {
									$this->saveMaintenanceCalibrationUploadInformation($p_equipId,$p_tabType,$file_id);
								}

								unlink($file_path);
							}
						}
					}
				}
			}

			unlink($log_file);

		}
	}

	private function saveMaintenanceCalibrationUploadInformation($p_equipId,$p_tabType,$p_fileId) {

		if ( $p_tabType == 'MAIN' ) {
			$fieldname = 'maintDocumentID';
		} else if ( $p_tabType == 'CAL' ) {
			$fieldname = 'calDocumentID';
		}

		$sql = sprintf("UPDATE %s.equipments SET %s = %d WHERE equipID = %d",_DB_OBJ_FULL,$fieldname,$p_fileId,$p_equipId);
		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
	}


	/*
	 * This method manages calibration data
	 *
	 * @access public
	*/
	public function manageCalibration() {

		$due_date = $this->vars['due_date'] == '' ? '1900-01-01' : format_date_for_mysql($this->vars['due_date']);

		 $sql = "UPDATE %s.equipments SET calibrationType = '%s', calibrationNature = '%s', calibrationCompetence = '%s',
						calibrationNotes = '%s', calibrationPeriod = %d, calibrationPeriodType = '%s',
						calibrationDueDate = '%s' WHERE equipID = %d";
						// , calibrationRequired='%s'

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['calibration_type'],
			$this->vars['calibration_nature'],$this->vars['competence'],$this->vars['notes'],$this->vars['calibration_period'],
			$this->vars['calibration_period_type'],
			$due_date,$this->id);
		// ,$this->vars['calib_req']

		$stmt = $this->dbHand->prepare($psql);

		/*$stmt->bindParam(1,$this->vars['calibration_type'], PDO::PARAM_STR);
		$stmt->bindParam(2,$this->vars['calibration_nature'], PDO::PARAM_STR);
		$stmt->bindParam(3,$this->vars['competence'], PDO::PARAM_STR);
		$stmt->bindParam(4,$this->vars['notes'], PDO::PARAM_STR);
		$stmt->bindParam(5,$this->vars['calibration_period'], PDO::PARAM_INT);
		$stmt->bindParam(6,$this->vars['calibration_period_type'], PDO::PARAM_STR, 1);
		$stmt->bindParam(7,format_date_for_mysql( $this->vars['due_date'] ));
		$stmt->bindParam(8,$this->id, PDO::PARAM_INT);
*/
		$stmt->execute();
		//dump_array_and_exit($stmt->errorInfo());

		$this->moveMaintenanceCalibrationFile($this->id,'CAL');
	}

	/**
	 * This method is used to add an equipment files
	 * id, uploadfilesid
	 */
	/*public function addEquipmentFile() {

		$files_arr = $this->getEquipmentFile();
		$files = implode(',',$files_arr);

		$new_files = $files.','.$this->vars['file_id'];

		$sql = "UPDATE equipments SET maintDocumentID = ? WHERE equipID = ?";
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->bindParam(1,$new_files,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->id,PDO::PARAM_INT);

		$pStatement->execute();
	}*/

	/**
	 * This method is used to get an equipment file
	 * id, identifier
	 */
	public function getEquipmentFile() {

		/*if ( $p_tabType == 'MAIN' ) {
			$fieldname = 'maintDocumentID';
		} else if ( $p_tabType == 'CAL' ) {
			$fieldname = 'calDocumentID';
		}*/

		$sql = "SELECT docID FROM %s.maintenance_calibration_data WHERE id = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$pStatement = $this->dbHand->prepare($psql);

		$pStatement->execute();
		$result = $pStatement->fetchColumn();

		//$files_list = explode(',',$resultSet);
		return $result;
	}

	/**
	 * This method is used to delete an equipment files
	 * id
	 */
	public function deleteEquipmentFile($newStr) {

		/*if ( $p_tabType == 'MAIN' ) {
			$fieldname = 'maintDocumentID';
		} else if ( $p_tabType == 'CAL' ) {
			$fieldname = 'calDocumentID';
		}*/

		$sql = "UPDATE %s.maintenance_calibration_data SET docID = '%s' WHERE id = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$newStr,$this->id);
		$pStatement = $this->dbHand->prepare($psql);

		$pStatement->execute();
	}
	
			public function getListingforExport() {

		 $type = $_GET['type'];

		if ( $type  =='full') {

			return $this->getIncidenceExportDataFull();

		}else if($type  =='full1'){
		return $this->getIncidenceExportDataFull1();
		
		}else if($type  =='full2'){
		return $this->getIncidenceExportDataFull2();
		
		}else if($type  =='full3'){
		return $this->getIncidenceExportDataFull3();
		
		}else if($type  =='full4'){
		return $this->getIncidenceExportDataFull4();
		
		}else if($type  =='full5'){
		return $this->getIncidenceExportDataFull5();
		
		}else if($type  =='full6'){
		return $this->getIncidenceExportDataFull6();
		
		}else if($type  =='full7'){
		return $this->getIncidenceExportDataFull7();
		
		}else if($type  =='last'){
		return $this->getIncidenceExportDataFull8();
		
		} else {

			return $this->getIncidenceExportData();
		}
	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	 
	  public function getIncidenceExportDataFull8() {
			$parent_id = (int) $_GET['pid'];
		$heading = array(array(0=>'Name',1=>'Frequency'));

		$objDocClass = SetupGeneric::useModule('DocClassification');
$dataDocClass = $objDocClass->displayItemsNew7();
//dump_array($dataDocClass);



$dataDocClass1 = $objDocClass->displayAction($dataDocClass['A']);
$dataDocClass2 = $objDocClass->displayAction($dataDocClass['D']);
$dataDocClass3 = $objDocClass->displayAction($dataDocClass['W']);
$dataDocClass4 = $objDocClass->displayAction($dataDocClass['M']);
$dataDocClass5 = $objDocClass->displayAction($dataDocClass['Q']);


$displayFre1 = $objDocClass->displayFre($dataDocClass['A']);
$displayFre2 = $objDocClass->displayFre($dataDocClass['D']);
$displayFre3 = $objDocClass->displayFre($dataDocClass['W']);
$displayFre4 = $objDocClass->displayFre($dataDocClass['M']);
$displayFre5 = $objDocClass->displayFre($dataDocClass['Q']);

	

		

			


				$result1[0] 	  =  array('0'=>$displayFre1);
				$result1[1] 	  =  array('1'=>$displayFre2);
				$result1[2] 	  =  array('2'=>$displayFre3);
				$result1[3] 	  =  array('3'=>$displayFre4);
				$result1[4] 	  =  array('4'=>$displayFre5);
				

			
			//dump_array($bu_name);exit;

		
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 
	  public function getIncidenceExportDataFull7() {
			$parent_id = (int) $_GET['pid'];
		$heading = array(array(0=>'Inspection Requirement'));

		$equipment_data = $this->getaddVehicle3($parent_id);
	

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['inspectionName']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	
	 public function getIncidenceExportDataFull131() {
			
		$heading = array(array(0=>'Reference',1=>'Location',2=>'Resource Requirements',3=>'Criticality',4=>'Business Affected',5=>'Process Affected',6=>'Disturbance',7=>'Description of Disruption',8=>'Criticality Description',9=>'Can Action be taken to reduce Risk ?',10=>'Likelihood',11=>'Impact',12=>'Risk Rating',13=>'Is BIR Required?',14=>'Along the path',15=>'At the worker',16=>'Control Measures Summary ',17=>'At the source',18=>'Along the path',19=>'At the worker',20=>'Improved Control Measures ',21=>'Likelihood',22=>'Impact',23=>'Risk Rating'));

		$equipment_data = $this->getbcp();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {
$bcp		=		new IncidenceMain();
				
				$de = explode(",", $value['critical']);
			$i = 0;
				foreach($de as $val){
				$na = $bcp->getBCPAll877cric($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$cric = implode(",", $de);
				
				$na1 = explode(",", $value['nature']);
			$i = 0;
				foreach($na1 as $val){
				$nah = $bcp->getBCPAll877nat($val);
				
				$dedd[$i] = $nah['name'];
				$i++;
				}
				$nat = implode(",", $dedd);
					$d = explode(",",$value['desi']);
				$de = array();
				$i = 0;
				foreach($d as $val){
				$na = $bcp->getBCPAll877desi($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$desi = implode(",", $de);
				$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$value['loc']));
				$location_data = "";
				$location = $locObj->displaylocationByPid();
				$result1[$key] 	  =  array($value['uniqueReference'],$location['name'],$nat,$cric,$value['bu'],$value['process'],$desi,$value['descp'],$value['cDescp'],$value['r_check'],$value['like_a'],$value['impact'],$value['risk'],$value['is_bir'],$value['along_path'],$value['at_worker'],$value['summary'],$value['source'],$value['path'],$value['worker'],$value['improvement'],$value['like2'],$value['impact2'],$value['risk2']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	
	 public function getIncidenceExportDataFull13() {
			
		$heading = array(array(0=>'Reference',1=>'Location',2=>'Resource Requirements',3=>'Criticality'));

		$equipment_data = $this->getbcp();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {
$bcp		=		new IncidenceMain();
				
				$de = explode(",", $value['critical']);
			$i = 0;
				foreach($de as $val){
				$na = $bcp->getBCPAll877cric($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$cric = implode(",", $de);
				
				$na1 = explode(",", $value['nature']);
			$i = 0;
				foreach($na1 as $val){
				$nah = $bcp->getBCPAll877nat($val);
				
				$dedd[$i] = $nah['name'];
				$i++;
				}
				$nat = implode(",", $dedd);
				$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$value['loc']));
				$location_data = "";
				$location = $locObj->displaylocationByPid();
				$result1[$key] 	  =  array($value['uniqueReference'],$location['name'],$nat,$cric);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 public function getIncidenceExportDataFull141() {
			
		$heading = array(array(0=>'Reference',1=>'Location',2=>'Resource Requirements',3=>'Criticality',4=>'Is a BRP Required ?',5=>'Recovery Priority'));

		$equipment_data = $this->getbcpbir();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {
$bcp		=		new IncidenceMain();
				$data = $this->getbcpbir1($value['bia_id']);
				$de = explode(",", $data['critical']);
			$i = 0;
				foreach($de as $val){
				$na = $bcp->getBCPAll877cric($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$cric = implode(",", $de);
				$na1 = explode(",", $value['nature']);
			$i = 0;
				foreach($na1 as $val){
				$nah = $bcp->getBCPAll877nat($val);
				
				$dedd[$i] = $nah['name'];
				$i++;
				}
				$nat = implode(",", $dedd);
				$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$data['loc']));
				$location_data = "";
				$location = $locObj->displaylocationByPid();
				$result1[$key] 	  =  array($value['uniqueReference'],$location['name'],$nat,$cric,$value['is_rec'],$value['recovery']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	
	 public function getIncidenceExportDataFull14() {
			
		$heading = array(array(0=>'Reference',1=>'Location',2=>'Resource Requirements',3=>'Criticality'));

		$equipment_data = $this->getbcpbir();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {
$bcp		=		new IncidenceMain();
				$data = $this->getbcpbir1($value['bia_id']);
				$de = explode(",", $data['critical']);
			$i = 0;
				foreach($de as $val){
				$na = $bcp->getBCPAll877cric($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$cric = implode(",", $de);
				$na1 = explode(",", $value['nature']);
			$i = 0;
				foreach($na1 as $val){
				$nah = $bcp->getBCPAll877nat($val);
				
				$dedd[$i] = $nah['name'];
				$i++;
				}
				$nat = implode(",", $dedd);
				$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$data['loc']));
				$location_data = "";
				$location = $locObj->displaylocationByPid();
				$result1[$key] 	  =  array($value['uniqueReference'],$location['name'],$nat,$cric);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 public function getIncidenceExportDataFull151() {
			
		$heading = array(array(0=>'Reference',1=>'Location',2=>'Resource Requirements',3=>'Criticality'));

		$equipment_data = $this->getbcpbrp();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {
$bcp		=		new IncidenceMain();
$data1 = $this->getbcpbrp1($value['bia_id']);
				$data = $this->getbcpbir1($data1['bia_id']);
				$de = explode(",", $data['critical']);
			$i = 0;
				foreach($de as $val){
				$na = $bcp->getBCPAll877cric($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$cric = implode(",", $de);
				$na1 = explode(",", $value['nature']);
			$i = 0;
				foreach($na1 as $val){
				$nah = $bcp->getBCPAll877nat($val);
				
				$dedd[$i] = $nah['name'];
				$i++;
				}
				$nat = implode(",", $dedd);
				$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$data['loc']));
				$location_data = "";
				$location = $locObj->displaylocationByPid();
				$result1[$key] 	  =  array($value['uniqueReference'],$location['name'],$nat,$cric);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 public function getIncidenceExportDataFull15() {
			
		$heading = array(array(0=>'Reference',1=>'Location',2=>'Resource Requirements',3=>'Criticality'));

		$equipment_data = $this->getbcpbrp();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {
$bcp		=		new IncidenceMain();
$data1 = $this->getbcpbrp1($value['bia_id']);
				$data = $this->getbcpbir1($data1['bia_id']);
				$de = explode(",", $data['critical']);
			$i = 0;
				foreach($de as $val){
				$na = $bcp->getBCPAll877cric($val);
				
				$de[$i] = $na['name'];
				$i++;
				}
				$cric = implode(",", $de);
				$na1 = explode(",", $value['nature']);
			$i = 0;
				foreach($na1 as $val){
				$nah = $bcp->getBCPAll877nat($val);
				
				$dedd[$i] = $nah['name'];
				$i++;
				}
				$nat = implode(",", $dedd);
				$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$data['loc']));
				$location_data = "";
				$location = $locObj->displaylocationByPid();
				$result1[$key] 	  =  array($value['uniqueReference'],$location['name'],$nat,$cric);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 
	 public function getIncidenceExportDataFull6() {
			
		$heading = array(array(0=>'Service Name',1=>'Description',2=>'Mileage',3=>'Frequency'));

		$equipment_data = $this->getaddVehicle2();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {

$n = $this->getConsumablesByType114455($value['serviceName']);
				$result1[$key] 	  =  array($n['name'],$value['descp'],$value['mileage'],$value['frequency']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 
	  public function getIncidenceExportDataFull5() {
			
		$heading = array(array(0=>'Name',1=>'Year'));

		$equipment_data = $this->getaddVehicle1();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['name'],$value['year']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 
	  public function getIncidenceExportDataFull4() {
			
		$heading = array(array(0=>'Type',1=>'Make',2=>'Model',3=>'Varient'));

		$equipment_data = $this->getaddVehicle();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {

$n = $this->getConsumablesByType1144($value['type']);
				$result1[$key] 	  =  array($n['name'],$value['make'],$value['model'],$value['vari']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 
	 public function getIncidenceExportDataFull1() {
			$parent_id = (int) $_GET['pid'];
		$heading = array(array(0=>'Detail',1=>'Unit'));

		$equipment_data = $this->getConsumablesByType11($parent_id);
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['detail'],$value['unit']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	public function getIncidenceExportDataFull977() {

		$heading = array(array(0=>'Rating'));

		$equipment_data = $this->equipmentTyperat();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['name']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	
	
	public function getIncidenceExportDataFull10() {

		$heading = array(array(0=>'Nature of Disturbance'));

		$equipment_data = $this->equipmentTypenature();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['name']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	
	public function getIncidenceExportDataFull12() {

		$heading = array(array(0=>'Recovery Priority'));

		$equipment_data = $this->equipmentTyperec();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['name']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	public function getIncidenceExportDataFull2() {

		$heading = array(array(0=>'Equipment Type'));

		$equipment_data = $this->equipmentType();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['equipment_type']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	
	public function getIncidenceExportDataFull3() {

		$heading = array(array(0=>'Title'));

		$equipment_data = $this->getPartList();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value['positionTitle']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	 
	public function getIncidenceExportDataFull() {

		$heading = array(array(0=>'Material Type'));

		$equipment_data = $this->getAllConsumablesTypes();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {


				$result1[$key] 	  =  array($value);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}
	public function getIncidenceExportData() {

		$heading = array(array(0=>'EQ#',1=>'Bussiness Unit',2=>'Who',3=>'EQ Class',4=>'Description',5=>'Due Date'));

		$equipment_data = $this->displayItems();
		//dump_array($equipment_data);exit;

		if ( count($equipment_data) ) {

			foreach( $equipment_data as $key => $value) {

				$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
				$objOrg				= SetupGeneric::useModule('Organigram');
				$participantObj	 	= SetupGeneric::useModule('Participant');

				$equip_id			= (int) $value['equipID'];

				$equip_class_id	= (int) $value['equipClassID'];
				$objEquipClass->setItemInfo( array('id'=>$equip_class_id) );
				$equip_class_data = $objEquipClass->displayItemById();

				$equip_class_code = $equip_class_data['equipCode'];

				$bu_id	= (int) $value['businessUnit'];
				$objOrg->setItemInfo( array('id'=>$bu_id) );
				$business_unit_data = $objOrg->displayItemById();

				$bu_name = $business_unit_data['buName'];

				$participant_id = $value['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$result1[$equip_id] 	  =  array($value['reference'],$bu_name,$participant_name,$equip_class_code,$value['equipmentDesc'],$value['maintenanceDueDate']);

			}
			//dump_array($bu_name);exit;

		}
		//dump_array($result1);exit;
		$result_new = array_merge($heading,$result1);

		//dump_array($result_new);exit;
		return $result_new;


	}

	public function getConsumables() {

		$sql = "SELECT * FROM %s.equipment_consumables";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function getPartList() {

		$sql = "SELECT * FROM %s.participant_titles";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getConsumablesById() {

		$sql = "SELECT * FROM %s.equipment_consumables WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getConsumablesByType() {

		$sql = "SELECT * FROM %s.equipment_consumables WHERE typeID = %d AND (archive is NULL OR archive = 0)";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['type_id']);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
		public function getConsumablesByType11($id) {
			$this->id = $id;
		$sql = "SELECT * FROM %s.equipment_consumables WHERE typeID = %d AND (archive is NULL OR archive = 0)";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	
	public function getConsumablesByTypea() {

		$sql = "SELECT * FROM %s.equipment_consumables WHERE typeID = %d AND  archive =1";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['type_id']);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getConsumableTypeByDetailID() {

		$sql = "SELECT * FROM %s.equipment_consumables_type
				WHERE ID = (SELECT typeID FROM %s.equipment_consumables WHERE ID = %d)";

		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,$this->vars['cdetail_id']);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function editConsumables() {

		$sql = "UPDATE %s.equipment_consumables SET typeID =%d,unit = '%s',detail = '%s' WHERE ID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['unit'],$this->vars['detail'],$this->id);
		$stmt = $this->dbHand->prepare($psql);
		/*$stmt->bindParam(1,$this->vars['description']);
		$stmt->bindParam(2,$this->vars['equipment_code']);
		$stmt->bindParam(3,$this->id);*/

		return $stmt->execute();

	}

	public function addConsumables() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipment_consumables WHERE name,unit,detail LIKE '".$this->vars['name']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		}
		else {

			$sql = "INSERT INTO %s.equipment_consumables (typeID,unit,detail) VALUES ( '%d','%s','%s')";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->vars['unit'],$this->vars['detail']);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->id);
			$stmt->bindParam(2,$this->vars['description']);
			$stmt->bindParam(3,$this->vars['equipment_code']);*/
			return $stmt->execute();
		}

	}

	public function deleteConsumables() {



		$sql = "DELETE FROM %s.equipment_consumables WHERE ID = %d";
    	$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();


	}

	public function displayItemsByLastName() {

		$tablename = sprintf("%s.equipments",_DB_OBJ_FULL);

		$sql = "SELECT * FROM ".$tablename."
				WHERE contactName LIKE '".$this->vars['contactName']."%' ";

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($result);

		if ( count($result) ) {
			return $result;
		} else {
			return "";
		}

	}
	public function getConsumablesName() {

		$sql = "SELECT name FROM %s.equipment_consumables";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}

	public function getAllConsumables() {

		$sql = "SELECT ID,unit,detail FROM %s.equipment_consumables";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $result_ele ) {
			$records[$result_ele['ID']]['unit'] = $result_ele['unit'];
			$records[$result_ele['ID']]['detail'] = $result_ele['detail'];
		}

		return $records;

	}

	public function consumablesType() {

		$sql = "SELECT name FROM %s.equipment_consumables where consumables = %s
				ORDER BY name ASC";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['consumables']);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getAllConsumablesTypes() {

		$sql = "SELECT DISTINCT * FROM %s.equipment_consumables_type
				ORDER BY name ASC";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);

		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		if ($result) {
			foreach ( $result as $result_ele ) {
				$types[strtolower($result_ele['ID'])] = ucfirst($result_ele['name']);
			}
		}

		return $types;
	}

	public function getEquipmentType() {

		$sql = "SELECT * FROM %s.equipment_type WHERE archive is NULL OR archive = 0";
		$psql = sprintf($sql,_DB_OBJ_FULL);
                
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}
	
	



	
	public function getEquipmentTypea() {

		$sql = "SELECT * FROM %s.equipment_type WHERE archive = 1";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}
	public function getEquipmentType1() {

		$sql = "SELECT * FROM %s.equipment_consumables_type";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}
	public function getConsumablesType() {

		$sql = "SELECT * FROM %s.equipment_consumables_type WHERE archive is NULL OR archive = 0";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		
                $stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$records = array();

		if ( count($result) ) {
			foreach ( $result as $result_ele ) {
				$records[$result_ele['ID']] = $result_ele;
			}
		}

		return $records;

	}
	
	public function getConsumablesTypea() {

		$sql = "SELECT * FROM %s.equipment_consumables_type WHERE archive = 1";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$records = array();

		if ( count($result) ) {
			foreach ( $result as $result_ele ) {
				$records[$result_ele['ID']] = $result_ele;
			}
		}

		return $records;

	}
	

	public function addEquipmentType() {

		$already_exists 	= false;

   	$sql = sprintf("SELECT COUNT(*) FROM %s.equipment_type WHERE equipment_type LIKE '".$this->vars['type']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		}
		else {

			$sql = "INSERT INTO %s.equipment_type (equipment_type) VALUES ( '%s')";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['type']);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->id);
			$stmt->bindParam(2,$this->vars['description']);
			$stmt->bindParam(3,$this->vars['equipment_code']);*/
			return $stmt->execute();

		}

	}
	public function getEquipmentTypeById() {

		$sql = "SELECT * FROM %s.equipment_type WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function editEquipmentType() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipment_type WHERE equipment_type LIKE '".$this->vars['type']."' AND ID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		} else {

			$sql = "UPDATE %s.equipment_type SET equipment_type = '%s' WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['type'],$this->id);
			$stmt = $this->dbHand->prepare($psql);


			return $stmt->execute();

		}
	}
	public function deleteType() {
	
	$sql = "UPDATE %s.equipment_type SET archive = 1 WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);


			 $stmt->execute();

				
	}
	


	public function addConsumablesType() {

		$already_exists 	= false;

   	$sql = sprintf("SELECT COUNT(*) FROM %s.equipment_consumables_type WHERE name LIKE '".$this->vars['name']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		}
		else {

			$sql = "INSERT INTO %s.equipment_consumables_type (name) VALUES ( '%s')";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name']);
			$stmt = $this->dbHand->prepare($psql);
			/*$stmt->bindParam(1,$this->id);
			$stmt->bindParam(2,$this->vars['description']);
			$stmt->bindParam(3,$this->vars['equipment_code']);*/
			return $stmt->execute();

		}

	}


	public function editConsumablesType() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipment_consumables_type WHERE name LIKE '".$this->vars['name']."' AND ID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Option already exist.");
		} else {

			$sql = "UPDATE %s.equipment_consumables_type SET name = '%s' WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->vars['name'],$this->id);
			$stmt = $this->dbHand->prepare($psql);


			return $stmt->execute();

		}
	}

	public function getConsumablesTypeById() {

		$sql = "SELECT * FROM %s.equipment_consumables_type WHERE ID = %d";

  	  $psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function deleteConsumablesType() {
	
	$sql = "UPDATE %s.equipment_consumables_type SET archive = 1 WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
			$stmt = $this->dbHand->prepare($psql);


			 $stmt->execute();


	}

	public function displayDetails() {

		//$sql = "SELECT * FROM hazard_classification WHERE hpcID = %d ORDER BY secondaryHazard ASC";
		$sql = "SELECT * FROM %s.equipment_consumables  WHERE typeID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getConsumablesNameById() {

		$sql = "SELECT * FROM %s.equipment_consumables_type WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function equipmentTypePO() {

		$sql = "SELECT equipmentType FROM %s.equipments WHERE flagIsTraining = 'TRG'";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function equipmentType() {

		$sql = "SELECT * FROM %s.equipment_type order by ID ASC";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	

public function equipmentType3($id) {
			$this->id = $id;
		$sql = "SELECT * FROM %s.equipment_type WHERE ID =".$this->id;
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function getEquipmentDetailById($equip_class_id) {

		$this->equip_class_id = $equip_class_id;
		$sql = "SELECT * FROM %s.equip_classification WHERE equipTypeId = %d";

   $psql = sprintf($sql,_DB_OBJ_FULL,$this->equip_class_id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
		public function getEquipmentDetailById22($equip_class_id) {

		$this->equip_class_id = $equip_class_id;
		$sql = "SELECT * FROM %s.assest_classification WHERE ID = %d";

   $psql = sprintf($sql,_DB_OBJ_FULL,$this->equip_class_id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function displayItemsByISLoc($location) {

		$locObj		= SetupGeneric::useModule('Locationgram');
		$locstr= $locObj->locationBuStr($location)	;
	
		$sql = sprintf("SELECT * FROM %s.equipments WHERE flagIsTraining LIKE '%%IS%%' and equipdetaillocID in (%s) ORDER BY equipID DESC",_DB_OBJ_FULL,$locstr);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

	foreach ($result as $data)	{
		$id=$data["equipmentType"];
	
		$retArray[$id][]=$data;
		
	}

		return $retArray;
	}
	
        public function archiveEquipConsumType($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.equipment_consumables_type SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function archiveEquipConsum($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.equipment_consumables SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function archiveEquipType($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.equipment_type SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->id);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	

	public function getMileage() {

		$objOption = new Option();
		$type = $objOption->getOption('_SU_MILEAGE_TYPE');
		$objOption = null;
		return $type;

	}
        
        	public function addMileage() {

		$objOption = new Option();
		$objOption->addOption('_SU_MILEAGE_TYPE',$this->vars['value']);
		$objOption = null;

	}
        	public function editMileage() {

		$objOption = new Option();
		$objOption->updateOption('_SU_MILEAGE_TYPE',$this->vars['value']);
		$objOption = null;
	}

}
