<?php
 /**
  $Id: ComplaintNatureSetup.class.php,v 3.11 Saturday, January 08, 2011 6:45:33 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:57:47 PM>
  */

require_once "SetupOperation.abs.php";

/**
 * ComplaintSetup Class
 *
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class ComplaintNatureSetup extends SetupOperation {

	private $dbHand;

	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
	}


	/***
	 * This method is used to insert record
	 * Array variables : id,nature_of_complaint
	 */

	public function addItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.complaint_nature
				WHERE name LIKE '".$this->vars['nature_of_complaint']."'",_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Nature of complaint already exist.");
		} else {

			$sql = sprintf("INSERT INTO %s.complaint_nature
										   (name,sort)
										   VALUES ('%s', %d)",_DB_OBJ_FULL,$this->vars['nature_of_complaint'],$this->vars['sort_id']);


			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,$this->id);
			$stmt->bindParam(2,$this->vars['nature_of_complaint']);
			$stmt->bindParam(3,$this->vars['sort_id']);*/

			$stmt->execute();

			$lastInsertID 	= customLastInsertId( $this->dbHand,'complaint_nature','compNatureID');
			$sort			= $lastInsertID*100;

			$stmt = null;

			$upd = sprintf("UPDATE %s.complaint_nature SET sort = %d WHERE compNatureID = %d",_DB_OBJ_FULL,$sort,$lastInsertID);

			$stmt = $this->dbHand->prepare($upd);

			return $stmt->execute();
		}
	}

	/***
	 * This method is used to delete record
	 * array variables : id
	 */
    public function deleteItem() {

		$sql = sprintf("DELETE FROM %s.complaint_nature WHERE compNatureID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}

	}

	/***
	 * This method is used to edit record
	 * Array variables : id,nature_of_complaint
	 */
	public function editItem() {

		$already_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.complaint_nature
				WHERE name LIKE '".$this->vars['nature_of_complaint']."'
				AND compNatureID != ".$this->id,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		$res 				= null;

		if ($already_exists) {
			throw new ErrorException("Nature of complaint already exist.");
		} else {

			$upd = sprintf("UPDATE %s.complaint_nature
					SET
						name = '%s'
					WHERE
						compNatureID = %d",_DB_OBJ_FULL,$this->vars['nature_of_complaint'],$this->id);

			$stmt = $this->dbHand->prepare($upd);

			return $stmt->execute();
		}

	}

	/***
	 * This method is used to list single record
	 * Array variables : id
	 */

	public function displayItemById() {

		$sql = sprintf("SELECT * FROM %s.complaint_nature WHERE compNatureID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	/***
	 * This method is used to list records
	 */
	public function displayItems() {

		$sql = sprintf("SELECT * FROM %s.complaint_nature ORDER BY sort ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
}