<?php
 /**
  $Id: SmartLawSetup.class.php,v 3.24 Thursday, February 03, 2011 4:21:35 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * MSR Setup operations
  *
  * This object will manage various setup operations
  * for msr module.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 4:42:13 PM>
  */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';
require_once "SetupOperation.abs.php";

/**
 * A setup class for managing msr setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 *
 */
class GOVSetup extends SetupOperation {

	/**
	 * This property acts as continaer object for database class.
	 *
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 * This method is a public constructor
	 *
	 * @access public
	 */
	public function __construct() {
		$this->dbHand = DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();

	}

 
	public function addItem() {

 $sql = sprintf("insert into %s.goveview_setup (title,bu,startdate,freq_period,freq_type )VALUES ('%s','%s','%s',%d,'%s')",_DB_OBJ_FULL,
						   $this->vars['title'],$this->vars['bu'],$this->vars['startdate'],$this->vars['fperiod'],$this->vars['ftime']);


			$stmt = $this->dbHand->prepare($sql);


			return $stmt->execute();	
return false;
	}

	/**
	 * This method is used to delete .
	 *
	 * Array Variables:  id
	 *
	 * @access public
	 */
    public function deleteItem() {

//never delete question

		return false;
	}

	/**
	 * This method is used to edit module.
	 *
	 * Array Variables:
	 * id, title,instrument_label,instrument_url,
	 * title_legislation,enforcement,summary
	 * ammended(array), revoked (array)
	 *
	 * Ammended and Revoked array variables:
	 * reference, url
	 *
	 * @access public
	 */
	public function editItem() {
		
$sql = sprintf("UPDATE %s.iareview_setup SET bu = '%s',startdate='%s',freq_period ='%d',freq_type ='%s' WHERE ID = %d",_DB_OBJ_FULL,
						   $this->vars['bu'],$this->vars['startdate'],$this->vars['fperiod'],$this->vars['ftime'],$this->id);


			$stmt = $this->dbHand->prepare($sql);


			return $stmt->execute();
		

	}

	
	/**
	 * This method is used to list all in module.
	 *
	 * @access public
	 */
	public function displayItems() {

		$sql = "SELECT * FROM %s.govreview_setup where archive=%d order by id desc";

     $psql = sprintf($sql,_DB_OBJ_FULL,$this->archive );
		$stmt = $this->dbHand->prepare($psql);
		
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	
	

	}

	

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
			 	public function getListingforExport() {

		$type = $_GET['type'];
      
		if($type=='full'){
			return $this->getISAExportDataFull();
		} else {

			return $this->getISAExportData();
		}
	}
	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getISAExportData() {


		$heading = array(array(0=>'Title',1=>'StartDate',2=>'Period'));


		$archive_data 		= array('id'=>0,'archive'=>0);
		$this->setItemInfo($archive_data);

		$result = $this->displayItems();

	//	dump_array($result);exit;
		if ( count($result) ) {

			foreach( $result as $key => $value) {

$id = $value['ID'];
				$resulta[$id][0] =  $value['title'];
				$resulta[$id][1] =  format_date($value['startdate']);
				$resulta[$id][2] =  $value['freq_period']." ".$value['freq_type'];
			
			}

		}






		$result_new = array_merge($heading,$resulta);

		return $result_new;

	}
	
	public function getISAExportDataFull() {

$orgObj = SetupGeneric::useModule('Organigram');
		$heading = array(array(0=>'Title',1=>'Business Unit',2=>'Start Date',
                    3=>'Period'));


		$archive_data 		= array('id'=>0,'archive'=>0);
		$this->setItemInfo($archive_data);

		$result = $this->displayItems();


		if ( count($result) ) {

			foreach( $result as $key => $value) {

$id = $value['ID'];
				$resulta[$id][0] =  $value['title'];
				$resulta[$id][1] =  $orgObj->getLawCoNames($value['bu']);
				$resulta[$id][2] =  format_date($value['startdate']);
				$resulta[$id][3] =  $value['freq_period']." ".$value['freq_type'];
			
			}

		}






		$result_new = array_merge($heading,$resulta);

		return $result_new;

	}
	

	/**
	 * This method is used to list single record.
	 *
	 * @access public
	 */
	public function displayItemById($p_id=0) {

		$sql = "SELECT * FROM %s.iareview_setup WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$p_id);
		$stmt = $this->dbHand->prepare($psql);

		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;

	}
	
	

}