<?php
 /**
  $Id: AuthorizedUserSetup.class.php,v 3.55 Thursday, February 03, 2011 1:07:54 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * Authorized User setup object
  *
  * This object defines the set of operation for Authorized User Setup
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:59:52 PM>
  */


/**
 * SetupOperations Abstract class.
 *
 * Importing SetupOperations abstract class.
 * Test Script used is test18.php
 */
require_once "SetupOperation.abs.php";

/**
 * AuthorizedUserSetup Class
 *
 * Class is pending
 *
 * A setup class for managing authorised user setup permissions, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes"
 */
class AuthorizedUserSetup extends SetupOperation {

	/**
	 * Constructor for AuthorizedUser Setup Object
	 *
	 * This method is used to declare constructor for an AuthorizedUser Setup Object.
	 *
	 * @access public
	 */

	/* Database handler object container */
	private $dbHand;

	/* Available section to the authorized user */
	private $availableSections;

	public function __construct() {

		global $available_authorization_sections;
 
		$this->dbHand 	=DB::connect(_DB_TYPE);

		$this->available_authorization_sections		= $available_authorization_sections;
                    
		/*$this->available_authorization_sections[] = 'perm_audit_msr';
		$this->available_authorization_sections[] = 'perm_audit_isr';*/
		$this->available_authorization_sections[] = 'perm_msr';
		$this->available_authorization_sections[] = 'perm_isr';
		$this->available_authorization_sections[] = 'perm_nc_inc';
		$this->available_authorization_sections[] = 'perm_nc_nhp';
		$this->available_authorization_sections[] = 'perm_ing_inc';
		$this->available_authorization_sections[] = 'perm_ing_nhp';
		$this->available_authorization_sections[] = 'perm_du';
		$this->available_authorization_sections[] = 'perm_fleet';
		$this->available_authorization_sections[] = 'perm_pAction';
		$this->available_authorization_sections[] = 'perm_smart';
		$this->available_authorization_sections[] = 'perm_da_train';
		$this->available_authorization_sections[] = 'perm_fa_train';
        $this->available_authorization_sections[] = 'perm_person';
		$this->available_authorization_sections[] = 'perm_bcp';
        $this->available_authorization_sections[] = 'perm_bcpi';
        $this->available_authorization_sections[] = 'perm_bco';
        
        $this->available_authorization_sections[] = 'perm_le';
        $this->available_authorization_sections[] = 'perm_hoc';
        $this->available_authorization_sections[] = 'perm_te';
        $this->available_authorization_sections[] = 'perm_ie';

        $this->available_authorization_sections[] = 'perm_com';

        
        $this->available_authorization_sections[] = 'perm_gov';
        $this->available_authorization_sections[] = 'perm_pci-dss';
        $this->available_authorization_sections[] = 'perm_law';
        $this->available_authorization_sections[] = 'perm_lib';
        $this->available_authorization_sections[] = 'perm_lv';
        $this->available_authorization_sections[] = 'perm_acc_rep';
		//dump_array($this->available_authorization_sections);
	}

	public function addItem() {
		// do nothing
	}

    public function deleteItem() {
		// do nothing
	}

	private function flushParticipantList() {

		$authorization_cnt 		= count($this->vars['section']);

			$p_sql = "DELETE FROM %s.participant_authorization_stats WHERE participantID = %d AND sectionName = '%s'";

			$section_array = array();


			if ( $authorization_cnt ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {

					//if ( !in_array($this->vars['section'][$k],$section_array) ) {
						$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['section'][$k]);
						$stmt 	= $this->dbHand->prepare($psql);
						$stmt->execute();
					//}


	//				$section_array[] = $this->vars['authorization'][$k]['section_name'];
//$section_array[] = $this->vars['authorization'][$k]['section_name'];
					/*$stmt->bindParam(1,$this->id);
					$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
					$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
					$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/



				}
			}

                        }
	
	private function flushLocationList() {

		$authorization_cnt 		= count($this->vars['section']);

			$p_sql = "DELETE FROM %s.participant_locationgram WHERE participantID = %d AND sectionName = '%s'";

			$section_array = array();


			if ( $authorization_cnt ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {

					if ( !in_array($this->vars['section'][$k],$section_array) ) {
						$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['section'][$k]);
						$stmt 	= $this->dbHand->prepare($psql);
						$stmt->execute();
					}


					$section_array[] = $this->vars['authorization'][$k]['section_name'];

					/*$stmt->bindParam(1,$this->id);
					$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
					$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
					$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/



				}
			}
	}


	/*
	 *	business_unit,section_name,is_section_active
	 *
	 * 'authorization' => array(
	 *							array('business_unit' => '11','section_name' => 'perm_audit','is_section_active' => 1),
	 *							array('business_unit' => '11','section_name' => 'perm_audit','is_section_active' => 1),
	 *							array('business_unit' => '12','section_name' => 'perm_asasasdoc','is_section_active' => 1),
	 *							array('business_unit' => '12','section_name' => 'perm_doc','is_section_active' => 1),
	 *							array('business_unit' => '11','section_name' => 'perm_audit','is_section_active' => 1),
	 *						)
	 *					)
	 *
	 */
	public function editItem() {

		global $available_authorization_sections;
        // dump_array($available_authorization_sections);
		$participant_exists 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.participant_database WHERE isnull(archive,0)=0 and  participantID = %d",_DB_OBJ_FULL,$this->id);

		if ($res = $this->dbHand->query($sql)) {

			if ($res->fetchColumn() > 0) {
				$participant_exists 	= true;
			}
		}

		if ($participant_exists) {

			/*
			* Flush Participant records from authorization list for fresh entries
			*
			*/
		    $this->flushParticipantList();
if (is_array($this->vars['authorization'])){
    			$authorization_cnt 		= count($this->vars['authorization']);
}else{
$authorization_cnt 		= 0;
    }

			$p_sql 	= "INSERT INTO %s.participant_authorization_stats(participantID, businessUnit, sectionName, sectionActive) VALUES (%d, %d, '%s', %d)";


			if ( $authorization_cnt>0 ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {

					// if the array $available_authorization_sections is defined in config.inc.php
					if ( count($available_authorization_sections) ) {

						if ( in_array($this->vars['authorization'][$k]['section_name'], $this->available_authorization_sections ) ) {

							$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['authorization'][$k]['business_unit'],$this->vars['authorization'][$k]['section_name'],
											$this->vars['authorization'][$k]['is_section_active']);
							//echo "<br/>";
							$stmt 	= $this->dbHand->prepare($psql);

							/*$stmt->bindParam(1,$this->id);
							$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
							$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
							$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/

							$stmt->execute();
						}
					} else {

						$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['authorization'][$k]['business_unit'],$this->vars['authorization'][$k]['section_name'],
											$this->vars['authorization'][$k]['is_section_active']);
						$stmt 	= $this->dbHand->prepare($psql);

						/*$stmt->bindParam(1,$this->id);
						$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
						$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
						$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/

						$stmt->execute();
					}
				}
			}

			//dump_array($this);

			return true;
		} else {

		}
		//exit;
	}
	
	public function editLocation() {


			/*
			* Flush Participant records from authorization list for fresh entries
			*
			*/
            if (is_array($this->vars['section'])){
    			$authorization_cnt 		= count($this->vars['section']);
}else{
$authorization_cnt 		= 0;
    }
		  

			$p_sql = "DELETE FROM %s.participant_locationgram WHERE participantID = %d AND (sectionName = 'risk27k' OR sectionName = 'SOA' OR sectionName = 'inspection' OR sectionName = 'PCI-DSS')";

			$section_array = array();


			if ( $authorization_cnt ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {

					if ( !in_array($this->vars['section'][$k],$section_array) ) {
						$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['section'][$k]);
						$stmt 	= $this->dbHand->prepare($psql);
						$stmt->execute();
					}


					$section_array[] = $this->vars['authorization'][$k]['section_name'];

					/*$stmt->bindParam(1,$this->id);
					$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
					$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
					$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/



				}
			}
			//exit;

            if (is_array($this->vars['authorization'])){
    			$authorization_cnt 		= count($this->vars['authorization']);
}else{
$authorization_cnt 		= 0;
    }
			$p_sql 	= "INSERT INTO %s.participant_locationgram(participantID, locationID, sectionName, sectionActive) VALUES (%d, %d, '%s', %d)";


			if ( $authorization_cnt ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {

					// if the array $available_authorization_sections is defined in config.inc.php
					if ( is_array($available_authorization_sections) ) {

						if ( in_array($this->vars['authorization'][$k]['section_name'], $this->available_authorization_sections ) ) {

							$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['authorization'][$k]['business_unit'],$this->vars['authorization'][$k]['section_name'],
											$this->vars['authorization'][$k]['is_section_active']);
							//echo "<br/>";
							$stmt 	= $this->dbHand->prepare($psql);

							/*$stmt->bindParam(1,$this->id);
							$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
							$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
							$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/

							$stmt->execute();
						}
					} else {

						$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['authorization'][$k]['business_unit'],$this->vars['authorization'][$k]['section_name'],
											$this->vars['authorization'][$k]['is_section_active']);
						$stmt 	= $this->dbHand->prepare($psql);

						/*$stmt->bindParam(1,$this->id);
						$stmt->bindParam(2,$this->vars['authorization'][$k]['business_unit'],PDO::PARAM_INT);
						$stmt->bindParam(3,$this->vars['authorization'][$k]['section_name'],PDO::PARAM_STR,50);
						$stmt->bindParam(4,$this->vars['authorization'][$k]['is_section_active'],PDO::PARAM_INT);*/

						$stmt->execute();
					}
				}
			}

			//dump_array($this);

			return true;
		
	//exit;
	}

	public function displayItems() {

		$sql = sprintf("SELECT * FROM %s.participant_authorization_stats WHERE participantID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayItemsLocations() {

		$sql = sprintf("SELECT * FROM %s.participant_locationgram WHERE participantID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	public function displayLocations() {

		$sql = sprintf("SELECT * FROM %s.participant_locationgram WHERE participantID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displayLawStds() {

		$sql = sprintf("SELECT * FROM %s.participant_law_std WHERE participantID = %d",_DB_OBJ_FULL,$this->id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

    public function displayItemsByBUSection() {

		$sql = sprintf("SELECT DISTINCT participantID FROM %s.participant_authorization_stats WHERE businessUnit = %d AND sectionName = '%s'",_DB_OBJ_FULL,$this->id,$this->vars['section_name']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$heading = array(array(0=>'AccountName',1=>'LoginName',2=>'Full Access'));

		$eqObj = SetupGeneric::useModule('Participant');


		$data = $eqObj->displayItemsyyy();

		if ( is_array($data) ) {

			foreach( $data as $key => $value) {

				$part_id = $value['participantID'];

				if ( $value['accessLevel'] ==1 ) {
								$access	=	'Yes';
						} else {
							$access	=	'No';
						}
				$name = $value['forename'].$value['surname'];
				$result1[$part_id] 	  =  array($name,$value['username'],$access);

			}

		}

		$result_new = array_merge($heading,$result1);

		return $result_new;

	}

	public function getIssuerPermission($p_module,$all_records=false) {
		$sql = sprintf("SELECT participantID FROM %s.participant_authorization_stats WHERE isnull(archive,0)=0 and  sectionName = '%s' AND sectionActive = '1' GROUP BY participantID ",
					   _DB_OBJ_FULL,$p_module);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		if ( $all_records ) {
			$participant_id = $stmt->fetchAll(PDO::FETCH_ASSOC);
		} else {
			$participant_id = $stmt->fetchColumn();
		}

		return $participant_id;
	}
	public function getInspection($p_module,$all_records=false) {
		$sql = sprintf("SELECT participantID FROM %s.participant_locationgram WHERE isnull(archive,0)=0 and  sectionName = '%s' AND sectionActive = '1' GROUP BY participantID ",
					   _DB_OBJ_FULL,$p_module);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		if ( $all_records ) {
			$participant_id = $stmt->fetchAll(PDO::FETCH_ASSOC);
		} else {
			$participant_id = $stmt->fetchColumn();
		}

		return $participant_id;
	}


	public function getIssuerPermissionBu($p_module,$bu_id,$all_records=false) {
		$sql = sprintf("SELECT participantID FROM %s.participant_authorization_stats WHERE sectionName = '%s' AND businessUnit = %d AND sectionActive = '1' GROUP BY participantID ",
					   _DB_OBJ_FULL,$p_module,$bu_id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		if ( $all_records ) {
			$participant_id = $stmt->fetchAll(PDO::FETCH_ASSOC);
		} else {
			$participant_id = $stmt->fetchColumn();
		}

		return $participant_id;
	}

		public function getParticpantPermissionList($p_module) {
		$sql = sprintf("SELECT distinct D.participantID,D.surname,D.forename,D.worksNumber,M.accessLevel FROM %s.participant_database D
				INNER JOIN %s.participant_meta_data M
				ON D.participantID = M.participantID
				INNER JOIN %s.participant_authorization_stats N
				ON
					D.participantID = N.participantID
				WHERE  isnull(archive,0)=0 and sectionName = '%s' AND sectionActive=1  ORDER BY forename",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$p_module);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();

		$participants = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $participants;
	}
	
	
	public function editLaw() {


			/*
			* Flush Participant records from authorization list for fresh entries
			*
			*/
		  
			$p_sql = "DELETE FROM %s.participant_law_std WHERE participantID = %d ";

			$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id);
			$stmt 	= $this->dbHand->prepare($psql);
			$stmt->execute();
					


	
			
            if (is_array($this->vars['authorization'])){
    			$authorization_cnt 		= count($this->vars['authorization']);
}else{
$authorization_cnt 		= 0;
    }
			$p_sql 	= "INSERT INTO %s.participant_law_std(participantID, lawStdID,sectionName) VALUES (%d, %d,'%s')";


			if ( $authorization_cnt ) {
				for ( $k=0; $k<$authorization_cnt;$k++ ) {



						$psql = sprintf($p_sql,_DB_OBJ_FULL,$this->id,$this->vars['authorization'][$k]['standards'],$this->vars['authorization'][$k]['section_name']);
						$stmt 	= $this->dbHand->prepare($psql);



						$stmt->execute();
					
				}
			}

			//dump_array($this);

			return true;
		
		//exit;
	}
        
 
        	public function getInspectionList($p_module) {

                                
		$sql = sprintf("SELECT distinct D.participantID,D.surname,D.forename FROM %s.participant_database D
				INNER JOIN %s.participant_locationgram L
                                ON D.participantID = L.participantID
				WHERE isnull(archive,0)=0 and  sectionName = '%s' AND sectionActive = '1'  ",
					   _DB_OBJ_FULL,_DB_OBJ_FULL,$p_module);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$participants = $stmt->fetchAll(PDO::FETCH_ASSOC);
		if(is_array($participants)){
                foreach ($participants as $parts)
                {
                 $data[$parts['participantID']] =  $parts["surname"]." ".$parts["forename"];
                }
                }
		return $data;
	}
        
        
        public function getAuthorizedList($p_module,$p_BU=0) {
            if ($p_BU==0){
                $bustr="";
            } else {
     $bustr=" and businessUnit=".$p_BU;
}
		$sql = sprintf("SELECT distinct D.participantID,D.surname,D.forename FROM %s.participant_database D
				INNER JOIN %s.participant_authorization_stats N
				ON D.participantID = N.participantID
				WHERE  isnull(archive,0)=0 and sectionName = '%s' AND sectionActive=1 %s ORDER BY forename",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_module,$bustr);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();

		$participants = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
                foreach ($participants as $parts)
                {
                 $data[$parts['participantID']] =  $parts["surname"]." ".$parts["forename"];
                }
		return $data;
	}
	
        public function getAuthorizedListbyforename($p_module,$p_str) {
            if ($p_BU==0){
                $bustr="";
            } else {
     $bustr=" and businessUnit=".$p_BU;
}
		$sql = sprintf("SELECT distinct D.participantID,D.surname,D.forename FROM %s.participant_database D
				INNER JOIN %s.participant_authorization_stats N
				ON D.participantID = N.participantID
				WHERE  isnull(archive,0)=0 and sectionName = '%s' AND sectionActive=1 %s ORDER BY forename",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_module,$bustr);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();

		$participants = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
                foreach ($participants as $parts)
                {
                 $data[$parts['participantID']] =  $parts["surname"]." ".$parts["forename"];
                }
		return $data;
	}
   
	    public function getLawApprover($id) {

        $sql = sprintf("SELECT count(*) as counter FROM %s.participant_law_std WHERE sectionName='perm_law_app'and participantID = %d", _DB_OBJ_FULL, $id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result['counter'];
    }   
}