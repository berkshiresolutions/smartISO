<?php
/**
 $Id: Authentication.class.php,v 3.20 Saturday, January 08, 2011 7:11:10 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * This object define various methods used for authentication of an user.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Authentication
 * @since  Saturday, August 14, 2010 5:04:24 PM>
 */

/**
 * A setup class for managing authentication operations, this is grouped with
 * other classes in the "Smartiso" package
 * and "Authentication" subpackage
 */

class Authentication
{
	/*
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/*
	 * Object container for Option object
	 * @access private
	 */
	private $optionHand;

	/*
	 * This property stores username
	 * @access private
	 */
	private $username;

	/*
	 * This property stores password
	 * @access private
	 */
	private $password;

	/*
	 * This property stores new password
	 * @access private
	 */
	private $newPassword;

	/*
	 * This property stores confirm password
	 * @access private
	 */
	private $confirmPassword;

	/*
	 * This property stores participant id
	 * @access private
	 */
	private $participantId;

	/*
	 * This property stores whether user is an active user or not
	 * @access private
	 */
	private $active;

	/*
	 * This property true if user is an Admin
	 * @access private
	 */
	private $levelAdmin;

	/*
	 * This property true if user is a Participant
	 * @access private
	 */
	private $levelParticipant;

	/*
	 * This property true if user is an Authorized User
	 * @access private
	 */
	private $levelAuthorized;

	/*
	 * This property sets minimum username length
	 * @access private
	 */
	private $minUsernameLength;

	/*
	 * This property sets minimum password length
	 * @access private
	 */
	private $minPasswordLength;

	/*
	 * This property sets default page URL based on various constaints
	 * @access private
	 */
	private $defaultPageUrl;

	/*
	 * This property is set to true if the user logged out himself
	 * and false if he was logged out by the software
	 * @access private
	 */
	private $implicitLogout;

	/*
	 * This property sets the url of the page accessed by the user
	 * @access private
	 */
	private $lastVisitedUrl;

	/*
	 * Constructor for initializing Authentication object
	 * @access public
	 */
	public function __construct() {
		 
		$this->minUsernameLength 	= 6;
		$this->minPasswordLength 	= 6;

		$this->active				= false;
		$this->levelAdmin			= false;
		$this->levelParticipant		= false;
		$this->levelAuthorized		= false;
		$this->defaultPageUrl		= '';
		$this->implicitLogout		= false;
		$this->lastVisitedUrl		= '';

		$this->optionHand 		= new Option();
		$this->dbHand 			= DB::connect(_DB_TYPE);

	}


	/*
	 * Set loginname and password information for an object to use
	 *
	 * @access public
	 *
	 * @param string $p_username 	Username of the user trying to log in
	 * @param string $p_password	Password of the user trying to log in
	 * @param string $p_confirmPassword		Password of the user trying to log in
	 * @param integer $p_emailAddress	Email address of the user trying to log in
	 *
	 * @return boolean this will return true in all cases
	 */
	public function setLoginInfo($p_userName,$p_password=null,$p_new_password='',$p_confirmPassword='',$p_emailAddress='') {

		if ( defined('__USER_ID') ) {
			$this->participantId		= __USER_ID;
		} else {
			$this->participantId		= 0;
		}

		$this->username 			= $p_userName;
		$this->password 			= $p_password;
		$this->newPassword 			= $p_new_password;
		$this->confirmPassword 		= $p_confirmPassword;
		$this->emailAddress 		= $p_emailAddress;

	}

	/*
	 * Check whether username and password provided by the object implementor
	 *
	 * @access public
	 *
	 * @param string $username 	Username of the user trying to log in
	 * @param string $password	Password of the user trying to log in
	 *
	 * @return boolean 	Returns true if information is provided, return false otherwise
	 */
	public function isInfoProvided() {

		if ( empty($this->username) ) {
			return false;
		}

		if ( empty($this->password) ) {
			return false;
		}

		return true;

	}

	/*
	 * Check whether user is logged in or not
	 *
	 * @access public
	 *
	 * @return boolean 	Returns true if user is logged, return false otherwise
	 */
	private function isUserLoggedIn() {

		if ( __USER_ID ) {
			return true;
		}

		return false;
	}

	/*
	 * Authenticate User for login	 *
	 *
	 */
	public function authenticateUser() {

		$sql = "SELECT * FROM %s.participant_database
				WHERE isnull(archive,0)=0 and username = '%s' AND passwd = '%s'";

       $psql = sprintf($sql,_DB_OBJ_FULL,$this->username,generate_password_string($this->password));

		$stmt = $this->dbHand->prepare($psql);

		//$password = generate_password_string($this->password);

		//$stmt->bindParam(1,$this->username,PDO::PARAM_STR,40);
		//$stmt->bindParam(2,$password,PDO::PARAM_STR,40);

		$stmt->execute();

		$res = $stmt->fetch(PDO::FETCH_ASSOC);

		/* Check the number of rows that match the SELECT statement */
		if ( $res > 0) {
			//return true;
			return $res['participantID'];
		}

	}


	/*
	 * Check whether user is an active user
	 *
	 * @access public
	 *
	 * @return boolean 	Returns true if user is an active user, return false otherwise
	 */
	private function isAccountActive() {
		return $this->active;
	}

	private function isOldPasswordOk() {
 
		if ( !empty($this->password) ) {

			$this->participantId = Session::getSessionField('SESS_USER_REC_ID');

			$sql = sprintf("SELECT COUNT(*) FROM %s.participant_database
					WHERE
						passwd = '%s'
					AND
						participantID = %d",_DB_OBJ_FULL,generate_password_string($this->password),$this->participantId);


			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,generate_password_string($this->password));
			$stmt->bindParam(2,$this->participantId);*/

			$stmt->execute();
			$stmt->setFetchMode(PDO::FETCH_ASSOC);

			/* Check the number of rows that match the SELECT statement */
			if ($stmt->fetchColumn() > 0) {

				return true;
			}

			throw new ErrorException('Incorrect Password');
			return false;

		}

	}

	public function changePassword() {
 
		$this->participantId = Session::getSessionField('SESS_USER_REC_ID');

		if ( $this->isOldPasswordOk() && $this->isPasswordLengthOk(true) && $this->isNewConfirmPasswordSame() ) {

			$sql = sprintf("UPDATE %s.participant_database
							SET
								passwd = '%s'
							WHERE
								participantID = %d",_DB_OBJ_FULL,generate_password_string($this->newPassword),$this->participantId);

			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,generate_password_string($this->newPassword));
			$stmt->bindParam(2,$this->participantId);*/

			return $stmt->execute();
		} else {
			return false;
		}
	}

	public function getEmailAddress() {
 
		$this->participantId = Session::getSessionField('SESS_USER_REC_ID');

		$sql = sprintf("SELECT emailAddress FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$this->participantId);
		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->participantId,PDO::PARAM_INT);*/

		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function getLang() {
 
		$this->participantId = Session::getSessionField('SESS_USER_REC_ID');

		$sql = sprintf("SELECT lang FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$this->participantId);
		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->participantId,PDO::PARAM_INT);*/

		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function changeEmailAddress() {
 
		$this->participantId = Session::getSessionField('SESS_USER_REC_ID');

		$sql = sprintf("UPDATE %s.participant_database SET emailAddress = '%s' WHERE participantID = %d",_DB_OBJ_FULL,$this->emailAddress,$this->participantId);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->emailAddress);
		$stmt->bindParam(2,$this->participantId);*/

		return $stmt->execute();
	}
	
	public function changeLang($name){
		 
		$this->name=$name;
		$this->participantId = Session::getSessionField('SESS_USER_REC_ID');

		$sql = sprintf("UPDATE %s.participant_database SET lang = '%s' WHERE participantID = %d",_DB_OBJ_FULL,$this->name,$this->participantId);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->emailAddress);
		$stmt->bindParam(2,$this->participantId);*/

		return $stmt->execute();
	}

	private function isNewConfirmPasswordSame() {

		if ( $this->newPassword == $this->confirmPassword ) {
			return true;
		}

		throw new ErrorException('Passwords do not match!');
		return false;
	}

	private function isUsernameLengthOk() {

		if ( strlen($this->username) >= $this->minUsernameLength ) {
			return true;
		}

		return false;
	}

	private function isPasswordLengthOk($p_changePasswordFlag=false) {


		if ( $p_changePasswordFlag ) {
			if ( strlen($this->newPassword) > $this->minPasswordLength ) {

				return true;
			}
		} else {
			if ( strlen($this->password) > $this->minPasswordLength ) {
				return true;
			}
		}

		throw new ErrorException('Password must be of at least 6 characters');
		return false;
	}

	private function setSessionInfo($p_sessionArr) {

		if ( is_array($p_sessionArr) ) {

			$session_arr_count = count($p_sessionArr);

			if ($session_arr_count) {

				foreach ( $p_sessionArr as $session_ele_key=>$session_ele_value ) {

					$_SESSION['SMARTISO_'.strtoupper($session_ele_key)] = $session_ele_value;
				} // end foreach
			} // end if
		} // end if

	}

	private function getSessionInfobyVar($p_varName) {

		$p_varName = 'SMARTISO_'.strtoupper($p_varName);

		if ( count($p_varName) && in_array($p_varName,$_SESSION) ) {
			return $_SESSION[$p_varName];
		} else {
			return false;
		}
	}

	private function setAccountLevel($p_level) {

		$p_level = (int) $p_level;

		switch ($p_level) {
			case 1: $this->levelAdmin		= true;
					$this->levelAuthorized	= false;
					$this->levelParticipant	= false;
						break;

			case 2: $this->levelAdmin		= false;
					$this->levelAuthorized	= true;
					$this->levelParticipant	= false;
						break;

			case 3: $this->levelAdmin		= false;
					$this->levelAuthorized	= false;
					$this->levelParticipant	= true;
						break;
		}

	}

	private function isAdminUser() {
		return $this->levelAdmin;
	}

	private function isAuthorizedUser() {
		return $this->levelAuthorized;
	}

	private function isParticipantUser() {
		return $this->levelParticipant;
	}

	private function getDefaultPageSettings() {

		switch ($this->optionHand->getOption('_SU_DEFAULT_PAGE')) {
			case 'D':	$this->defaultPageUrl = '';
						// header("Location: /company/sdms2.php");
						break;

			case 'A':	$this->defaultPageUrl = '';
						// header("Location: /company/personal_action_tracker/");
						break;

			default:	$this->defaultPageUrl = '';
						// header("Location: /company/");
						break;
		}
	}

	public function getDefaultPage() {

		return $this->setDefaultPage();
	}

	private function setDefaultPage() {

		if ( $this->implicitLogout ) {

			$this->defaultPageUrl = $this->lastVisitedUrl;

		} else {

			if ( $this->isAdminUser() ) {

				$this->getDefaultPageSettings();

			} else if ( $this->isAuthorizedUser() ) {

				// header("Location: /company/");
				$this->defaultPageUrl = '';

			} else if ( $this->isParticipantUser() ) {

				// old code = '/company/welcome_user.php';
				$this->defaultPageUrl = '';

			}
		}

		return $this->defaultPageUrl;
	}

	public function __destruct() {

		$this->optionHand 			= NULL;
		$this->dbHand 				= NULL;
	}
}
