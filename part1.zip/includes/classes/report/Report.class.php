<?php
 /**
  $Id: Report.class.php,v 3.18 Tuesday, January 25, 2011 1:20:55 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @since  Monday, August 16, 2010 11:35:41 AM>
  */

require_once "ReportBase.abs.php";
require_once "ReportTemplate.abs.php";

class Report extends ReportBase
{
	private $compiled_output;
	private $data_filters;

	public function __construct($p_type='pdf') {

		$this->reportType = $p_type;
$ReportTemplate =new ReportTemplate();
		$classname = 'Report'.ucfirst($this->reportType);
		$this->reportObj = $ReportTemplate->loadTemplateClass($this->reportType);
	}

	/*public function setFilter() {
		$this->setFilter();
	}*/

	private function setTemplate($p_uid) {
		$this->reportUid = $p_uid;
	}

	private function getTemplate() {
$ReportTemplate =new ReportTemplate();
		$rep_template_arr 		= $ReportTemplate->loadTemplate($this->reportType,$this->reportUid);
		$this->reportTemplate 	= $rep_template_arr['template'];
		$this->reportModule 	= $rep_template_arr['module'];
	}

	public function getReportData() {

		require_once "ReportData.class.php";
		$dataObj 			= new ReportData($this->reportModule,$this->data_filters);
		$this->reportData 	= $dataObj->getData();

		$dataObj 			= null;

	}

	public function setFilters($p_filters) {
		$this->data_filters = $p_filters;
	}

	public function callTemplate($p_uid) {
		$this->setTemplate($p_uid);
		$this->getTemplate();
	}

	public function generateReport($p_uid) {
		$this->callTemplate($p_uid);
		$this->getReportData();
		$this->mergeTemplateAndData();
	}

	public function mergeTemplateAndData() {
		$this->compiled_output = $this->reportObj->getReport($this->reportTemplate,$this->reportData);
	}

	public function saveReport() {
		$this->saveReport();
	}

	public function displayReport() {
		echo $this->compiled_output;
	}

	public function searchReport() {
		$this->searchReport();
	}
}
