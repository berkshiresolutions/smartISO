<?php
 /**
  $Id: ReportHtml.class.php,v 3.17 Monday, January 24, 2011 9:49:34 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 6:50:42 PM>
  */


/**
  * ReportHtml Class
  *
  *
  * class description here
  *
  * @static
  * @todo	Description
  */


class ReportHtml
{
    public function getReport($p_template,$p_data) {


		$report_smarty = new Smarty();

		$report_smarty->template_dir = _THEME_FOLDERPATH._THEME.'/templates';
		$report_smarty->compile_dir = _THEME_FOLDERPATH._THEME.'/templates_c';
		//$smarty->cache_dir = _THEME_FOLDER._THEME.'/cache';
		$report_smarty->config_dir = _MYINCLUDES.'/smarty_configs';
		$report_smarty->assign('data_array',$p_data);
		$report_smarty->assign('employee_participant',_EMPLOYEE_PARTICIPANT);
		//$report_smarty->debugging = true;
		$report_smarty->display('report_templates/'.$p_template);



		/*$template = file_get_contents(_MYINCLUDES.'report_templates/'.$p_template);

		foreach ( $p_data as $p_elek=>$p_elev ) {
			$search_string = '['.$p_elek.']';
			$template = str_replace($search_string,$p_elev,$template);
		}

		return $template;*/
		$report_smarty = null;
	}
}
?>