<?php
 /**
  $Id: ReportBase.abs.php,v 3.25 Wednesday, November 17, 2010 4:37:49 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 6:04:36 PM>
  */

/**
  * ReportBase Class
  *
  * class description here
  *
  * @abstract
  */

abstract class ReportBase
{
    protected $reportType;
	protected $reportObj;
    protected $reportUid;
    protected $reportTemplate;
    protected $reportModule;
    protected $reportData;

    public function setFilter() {

	}

	private function setTemplate() {

	}

	private function getTemplate() {

	}

	public function generateReport($uid) {

	}

	public function saveReport() {

	}

	public function displayReport() {

	}

	public function searchReport() {

	}

}
