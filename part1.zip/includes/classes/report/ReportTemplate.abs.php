<?php
 /**
  $Id: ReportTemplate.abs.php,v 3.19 Wednesday, November 17, 2010 4:37:56 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 6:50:42 PM>
  */


/**
  * ReportHtml Class
  *
  *
  * class description here
  *
  * @static
  * @todo	Description
  */


class ReportTemplate
{
    public function loadTemplateClass($p_type) {

		$classname = 'Report'.ucfirst($p_type);

		require_once $classname.'.class.php';
		return new $classname();
	}

	public function loadTemplate($p_type,$p_uid) {

		$xmlUrl = _MYPRIVATECLASSES."report/template.identifiers.xml"; // XML feed file/URL
		$xmlStr = file_get_contents($xmlUrl);
		$xmlObj = simplexml_load_string($xmlStr);

		foreach ( $xmlObj->template as $xmlElement ) {
			$arrXml = objectsIntoArray($xmlElement);

			$sel_template = array();

			if ( $arrXml['uid'] == $p_uid ) {
				$sel_template = $arrXml;
				break;
			}
		}

		$template_name = $p_type.'_template';

		$return_arr['template'] = $sel_template[$template_name];
		$return_arr['module'] = $sel_template['module'];

		return $return_arr;
	}
}
?>