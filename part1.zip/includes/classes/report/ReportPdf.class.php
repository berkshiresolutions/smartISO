<?php
 /**
  $Id: ReportPdf.class.php,v 3.06 Tuesday, January 25, 2011 1:25:41 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @since  Monday, August 16, 2010 11:33:31 AM>
  */


class ReportPdf
{
	public function getReport($p_template,$p_data) {


		$report_smarty = new Smarty();

		$report_smarty->template_dir = _THEME_FOLDERPATH._THEME.'/templates';
		$report_smarty->compile_dir = _THEME_FOLDERPATH._THEME.'/templates_c';
		
		$report_smarty->config_dir = _MYINCLUDES.'/smarty_configs';

		$report_smarty->assign('data_array',$p_data);
		$report_smarty->display('report_templates/'.$p_template);
	}

}
?>