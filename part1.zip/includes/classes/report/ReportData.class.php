<?php
 /**
  $Id: ReportData.class.php,v 3.11 Saturday, January 22, 2011 12:51:34 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @since  Monday, August 16, 2010 11:36:38 AM>
  */

class ReportData
{

	private $moduleObj;

	public function __construct($p_module,$p_filters='') {

		// riskModReport.class.php
		$classname = $p_module.'ModReport';
		require_once _MYCLASSES.'report/'.$classname.".class.php";

		$this->moduleObj = new $classname($p_filters);
	}

	public function getData() {

		$data =  $this->moduleObj->getData();
		$this->moduleObj = null;

		return $data;
	}
}
?>
