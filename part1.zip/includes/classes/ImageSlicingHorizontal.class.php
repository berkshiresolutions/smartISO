<?php
 /**
  $Id: ImageSlicingHorizontal.class.php,v 3.09 Monday, January 03, 2011 6:19:00 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage
  * @since  Friday, December 10, 2010 12:13:55 PM>
  */
class ImageSlicingHorizontal {

	private $filename;
	private $swimlaneid;
	private $src_img;
	private $dest_img;
	private $slices;
	private $height;
	private $width;
	private $vertical_slices;
	private $horizontal_slices;
	private $slicelist;
	private $blockheight;
	private $blockwidth;
	private $buwidth;
	private $headerHeight;


	public function __construct($p_filename) {
//	public function __construct($p_filename) {
		//echo $p_filename; exit;

		$this->swimlaneid = $p_swimlaneid;
		$this->vertical_slices = 1;
		$this->horizontal_slices = 1;
		$this->filename = $p_filename;
		$this->blockWidth = 300;
		$this->blockHeight = 200;
		$this->buwidth = 380;
		$this->headerHeight = 149;
		$this->get_dimensions();

		ini_set('memory_limit','256M');

		$this->src_img = imagecreatefrompng($p_filename);

		$this->do_calculations();
	}

	public function slice_list() {
		return $this->slicelist;
	}

	public function slice_width() {
		return $this->vertical_slices;
	}
	
	private function get_dimensions() {

		$fileinfo 		= getimagesize($this->filename);
		//dump_array_and_exit($fileinfo); exit;
		$size_info 		= explode('=',$fileinfo[3]);
		$size_info[1] 	= explode(' ',$size_info[1]);

		$this->width 	= trim($size_info[1][0],'"');
		$this->height 	= trim($size_info[2],'"');
	}

	private function do_calculations() {
/*
	$warr[0]=0;
	$harr[0]=0;
	if ($this->width> ($this->blockwidth*4) * $buwidth);
	$warr[1]=($this->blockwidth*4) * $buwidth;
	else
	$warr[1]=$this->width;
	
	if ($this->height> ($this->blockwidth*4) * $buwidth);
	$harr[1]=($this->blockheight*5) * $headerheight;
	else
	$harr[1]=$this->height;
	
*/	
	
		if ( $this->width > 1505 ) {
			$this->vertical_slices = ceil($this->width/1500);
		}

		if ( $this->height > 1033 ) {
			$this->horizontal_slices = ceil($this->height/1030);
		}

		$total_slices = $this->vertical_slices * $this->horizontal_slices;

		//echo $total_slices; exit;

		if ($total_slices) {
					
			$slice_list = array();

			$z = 0;

			for ($k=0;$k<$this->horizontal_slices;$k++) {
				for ($i=0;$i<$this->vertical_slices;$i++) {
if ($i==0)
$src_x = $i*1500 +1 ;
else
$src_x = $i*1500 -220 ;

				
					$src_y = $k*1030 + 1;
					$des_w = 1500; // dest width
					$des_h = 1030; // dest height

					if ( ($src_x+$des_w) > $this->width ) {
						$des_w = $this->width - $src_x + 1;
					}

					if ( ($src_y+$des_h) > $this->height ) {
						$des_h = $this->height - $src_y + 1;
					}

					//echo $z." - ".$src_x.":".$src_y."\n";



$dyn_res = imagecreatetruecolor(1500,1030);
					$bgcolor = imagecolorallocate($dyn_res,255,255,255);
					imagefilledrectangle($dyn_res,0,0,1500,1030,$bgcolor);

					//header('Content-Type: image/png');
					if ($i==0)
					{
					imagecopy($dyn_res,$this->src_img,110,0,$src_x,$src_y,$des_w-210,$des_h);
				
					}
					else
					imagecopy($dyn_res,$this->src_img,0,0,$src_x,$src_y,$des_w,$des_h);


					$filename_arr = explode('.',basename($this->filename));
					$filename_wo_ext = $filename_arr[0];

					$dyn_name = $filename_wo_ext.'_'.chr($z+97).'.png';
					imagepng($dyn_res,"../private_files/process_flow/".$dyn_name);

					$slice_list[] = "../private_files/process_flow/".$dyn_name;

					$z++;
				}
			}
		} // end if

		$this->slicelist = $slice_list;
		//dump_array($this->slicelist);
	}
}

?>