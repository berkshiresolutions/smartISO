<?php
 /**
  $Id: Misc.class.php,v 3.50 Monday, January 31, 2011 4:05:50 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, November 01, 2010 2:04:21 PM>
  */

class Misc
{
	/**
	 * This property is used to handle the db object
	 */
	private $dbHand;

	public function __construct() {
		 
		$this->dbHand 				= DB::connect(_DB_TYPE);
	}

	public function makeDate($p_duration,$p_interval) {

		if ( _DB_TYPE != 'mysql' ) {

			$sql_date = "SELECT DATEADD( $p_interval,$p_duration ,GETDATE()) ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();
			$dateTime = $pStatement->fetchColumn();

			$sql_date1 = "SELECT CONVERT(date,'".$dateTime."') ";

			$pStatement1 = $this->dbHand->prepare($sql_date1);
			$pStatement1->execute();
			$date_return = $pStatement1->fetchColumn();

		} else {
			$sql_date = "SELECT ADDDATE( CURDATE() , INTERVAL $p_duration $p_interval ) ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();
			$date_return = $pStatement->fetchColumn();
		}


		return $date_return;
	}

	public function makeCustomDate($p_date,$p_duration,$p_interval) {

		if ( _DB_TYPE != 'mysql' ) {

			$sql_date = "SELECT DATEADD( $p_interval,$p_duration ,'".$p_date."') ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();
			$dateTime = $pStatement->fetchColumn();

			$sql_date1 = "SELECT CONVERT(date,'".$dateTime."') ";

			$pStatement1 = $this->dbHand->prepare($sql_date1);
			$pStatement1->execute();
			$date_return = $pStatement1->fetchColumn();

		} else {

			$sql_date = "SELECT ADDDATE( '".$p_date."' , INTERVAL $p_duration $p_interval ) ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();

			$date_return = $pStatement->fetchColumn();
		}

		return $date_return;
	}

	public function makeCustomDatetime($p_date,$p_duration,$p_interval) {

		if ( _DB_TYPE != 'mysql' ) {

			$sql_date = "SELECT DATEADD( $p_interval,$p_duration ,'".$p_date."') ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();
			$date_return = $pStatement->fetchColumn();

		} else {

			$sql_date = "SELECT ADDDATE( '".$p_date."' , INTERVAL $p_duration $p_interval ) ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();

			$date_return = $pStatement->fetchColumn();
		}

		return $date_return;
	}

	public function getCurDate() {

		if ( _DB_TYPE != 'mysql' ) {
			$sql_date = "SELECT CONVERT(date,GETDATE())";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();
			$return_date = $pStatement->fetchColumn();

		} else {
			$sql_date = "SELECT CURDATE() ";

			$pStatement = $this->dbHand->prepare($sql_date);
			$pStatement->execute();
			$return_date = $pStatement->fetchColumn();
		}

		return $return_date;
	}
	
	public function getCurDateMethod() {

		if ( _DB_TYPE != 'mysql' ) {
			return "CONVERT(date,GETDATE())";
		} else {
			return "SELECT CURDATE()";
		}
	}

	public function getCurTime() {

		if ( _DB_TYPE != 'mysql' ) {

			$sql_time = "SELECT CONVERT(time,GETDATE())  ";

			$pStatement = $this->dbHand->prepare($sql_time);
			$pStatement->execute();
			$current_time_full =  $pStatement->fetchColumn();
			$time_arr = explode('.',$current_time_full);
			$current_time = $time_arr[0];

		} else {
			$sql_time = "SELECT CURTIME() ";

			$pStatement = $this->dbHand->prepare($sql_time);
			$pStatement->execute();
			$current_time =  $pStatement->fetchColumn();
		}

		return $current_time;
	}

	public function getDocumentTypes() {

		$sql = sprintf("SELECT SUBSTRING(docTypeName,1,1) as short_code,docTypeName FROM %s.question_docs_type
					ORDER BY sort ASC",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		$document_types = array();

		foreach ( $result as $data ) {
			$document_types[$data['short_code']] = $data['docTypeName'];
		}

		return $document_types;
	}

	public function get_hazard($p_hazard_id) {

		$sql = sprintf("SELECT subCatID FROM %s.hazards WHERE eID = %d ",_DB_OBJ_FULL,$p_hazard_id);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_hazard_id);*/
		$pStatement->execute();
		$primary_hazard_id =  $pStatement->fetchColumn();

		$sql2 = sprintf("SELECT secondaryHazard FROM %s.hazard_classification WHERE ID = %d ",_DB_OBJ_FULL,$primary_hazard_id);
		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$primary_hazard_id);*/
		$pStatement2->execute();
		return $pStatement2->fetchColumn();
	}

	public function get_mse_element($p_mse_id) {

		$sql = sprintf("SELECT subCategory FROM %s.management_elements WHERE eID = %d ",_DB_OBJ_FULL,$p_mse_id);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_mse_id);*/
		$pStatement->execute();
		return $pStatement->fetchColumn();
	}

	public function get_main_hazard($p_hazard_id) {

		$hazards_id_arr = explode(',',$p_hazard_id);

		if ( count($hazards_id_arr) ) {
			foreach( $hazards_id_arr as $value_id ) {

				$sql = sprintf("SELECT primaryHazard FROM %s.hazard_parent_classification WHERE ID = %d ",_DB_OBJ_FULL,$value_id);
				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$value_id);
				*/
				$pStatement->execute();
				$hazards .= $pStatement->fetchColumn().', ';
			}
		}
		return rtrim($hazards,', ');
	}

	public function get_risk_color($p_process_id) {

		if ( _DB_TYPE != 'mysql' ) {
			$sql = sprintf("SELECT TOP 1 riskRating1,riskRatingColor1 FROM %s.risk WHERE processID = %d",_DB_OBJ_FULL,$p_process_id);
		} else {
			$sql = sprintf("SELECT riskRating1,riskRatingColor1 FROM %s.risk WHERE processID = %d LIMIT 0,1 ",_DB_OBJ_FULL,$p_process_id);
		}

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_process_id);*/
		$pStatement->execute();
		$risk_dtata = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $risk_dtata[0];
	}

	public function get_multiple_hazards($p_hazard_id) {

		$hazards_id_arr = explode(',',$p_hazard_id);

		if ( count($hazards_id_arr) ) {
			foreach( $hazards_id_arr as $value_id ) {

				$sql = sprintf("SELECT secondaryHazard FROM %s.hazard_classification WHERE ID = %d ",_DB_OBJ_FULL,$value_id);
				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$value_id);*/
				$pStatement->execute();
				$hazards .= $pStatement->fetchColumn().', ';
			}
		}
		return rtrim($hazards,', ');

	}

	public function saveModuleVersionInfo($p_moduleName,$p_recID) {

		/*
		RA - Risk Assessment
		INSP - Inspection
		INCD - Incidence
		INVG - Investigation
		NHC - NHC
		RA27 - Risk 27k
		*/

		$allowed_modules = array('RA','INSP','INCD','INVG','NHC','RA27','NHCINV');
		$p_recID = (int) $p_recID;

		if ( in_array($p_moduleName,$allowed_modules) ) {

			$already_exists 	= false;

			$sql = sprintf("SELECT * FROM %s.moduleVersionInfo WHERE module = '%s' AND recID = %d",_DB_OBJ_FULL,$p_moduleName,$p_recID);

			if ($res = $this->dbHand->query($sql)) {

				/* Check the number of rows that match the SELECT statement */
				if ($res->fetchColumn() == $p_moduleName ) {
					$already_exists 	= true;
				}
			}

			if (!$already_exists) {
				$upd = sprintf("INSERT INTO %s.moduleVersionInfo (module,recID,subRef) VALUES('%s',%d,'1')",_DB_OBJ_FULL,$p_moduleName,$p_recID);

			} else {
				$upd = sprintf("UPDATE %s.moduleVersionInfo SET subRef = subRef + 1 WHERE module = '%s' AND recID = %d",_DB_OBJ_FULL,$p_moduleName,$p_recID);
			}

			$pStatement = $this->dbHand->prepare($upd);
			$pStatement->execute();

			return 1;
		} else {
			return 0;
		}
	}

	public function getModuleVersionInfo($p_moduleName,$p_recID) {

		/*
		RA - Risk Assessment
		INSP - Inspection
		INCD - Incidence
		INVG - Investigation
		NHC - NHC
		RA27 - Risk 27k
		CT - Contractor
		*/

		$allowed_modules = array('RA','INSP','INCD','INVG','NHC','RA27','CT','NHCINV');
		$p_recID = (int) $p_recID;

		if ( in_array($p_moduleName,$allowed_modules) ) {

			$sql = sprintf("SELECT subRef FROM %s.moduleVersionInfo WHERE module = '%s' AND recID = %d",_DB_OBJ_FULL,$p_moduleName,$p_recID);

			$pStatement = $this->dbHand->prepare($sql);
			$pStatement->execute();

			return $pStatement->fetchColumn();
		} else {
			return 0;
		}
	}

	public function saveSharingInfo($p_sect,$p_part_list) {

		$sql = sprintf("SELECT * FROM %s.setup_sharing WHERE sectionID = '%s'",_DB_OBJ_FULL,$p_sect);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$exists = $pStatement->fetchColumn();

		if ( $exists != '' ) {
			$ins = sprintf("UPDATE %s.setup_sharing SET participantIDs = '%s' WHERE sectionId = '%s'",_DB_OBJ_FULL,$p_part_list,$p_sect);
		} else {
			$ins = sprintf("INSERT INTO %s.setup_sharing (sectionID,participantIDs) VALUES('%s','%s')",_DB_OBJ_FULL,$p_sect,$p_part_list);
		}

		$p2Statement = $this->dbHand->prepare($ins);
		$p2Statement->execute();
	}

	public function getSharingInfo($p_sect) {

		$sql = sprintf("SELECT participantIDs FROM %s.setup_sharing WHERE sectionID = '%s'",_DB_OBJ_FULL,$p_sect);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$records = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $records['participantIDs'];
	}

	public function getSharedSectByID($p_id) {

		$allowed_sections = array();

		$sql = sprintf("SELECT sectionID FROM %s.setup_sharing WHERE
					   (participantIDs LIKE '%s'
					   OR participantIDs LIKE '%s,'
					   OR participantIDs LIKE ',%s'
					   OR participantIDs LIKE ',%s,')
					   ",_DB_OBJ_FULL,$p_id,$p_id,$p_id,$p_id);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($records) ) {
			foreach ( $records as $reclord_ele ) {
				$allowed_sections[] = $reclord_ele['sectionID'];
			}
		}

		return $allowed_sections;
	}

	public function saveRecordAction($arguments=array()) {

		/*
		RA - Risk Assessment
		INSP - Inspection
		INCD - Incidence
		INVG - Investigation
		NHC - NHC
		RA27 - Risk 27k
		MH - Manual Handling
		CT - Contractor
		DSE - DSE
		*/
		$USER_LEVEL = getUserAccessLevel();

		if ( $USER_LEVEL != 3 ) {
		
			$sql = sprintf("SELECT * FROM %s.recordTracking
					WHERE recordRef = '%s'
					AND action = '%s'",_DB_OBJ_FULL,$arguments['ref'],'add');

					$pStatement = $this->dbHand->prepare($sql);
					$pStatement->execute();
					$result = $pStatement->fetch(PDO::FETCH_ASSOC);
			
			$ADD_ALLOWED = false;
			
			if ( $arguments['action'] == 'add' && empty($result['ref']) ) {
				$ADD_ALLOWED = true;
			} else if ( $arguments['action'] != 'add' ) { 
				$ADD_ALLOWED = true;
			}

			if ($ADD_ALLOWED) {	
				$sql = sprintf("INSERT INTO %s.recordTracking (moduleName,recordRef,userID,action,dateTimestamp)
					VALUES ('".$arguments['module']."','".$arguments['ref']."','".getLoggedInUserId()."',
					'".$arguments['action']."','".$this->getCurDate()." ".$this->getCurTime()."')",_DB_OBJ_FULL);

					$pStatement = $this->dbHand->prepare($sql);
					$pStatement->execute();
			}
			

			if ( $arguments['action'] == 'review' ) {
				$creater_details = $this->getRecordCreater($arguments['module'],$arguments['ref']);
				//echo $creater_details.'----------------------------------------------------------------';

				if ( $creater_details ) {

					/*creator details*/
					$participantObj	 	= SetupGeneric::useModule('Participant');
					$participantObj->setItemInfo(array('id'=>$creater_details));
					$partcipantData = $participantObj->displayItemById();

					/*editor details*/
					$arguments['editor_name'] = Session::getSessionField('SESS_FULLNAME');
					$arguments['date_time'] = $this->getCurDate()." ".$this->getCurTime();

					$salutation = $partcipantData['gender'] == 'f' ? 'Ms.' : 'Mr.';
					$mail_id = $partcipantData['emailAddress'];
					$name = $partcipantData['forename'].' '.$partcipantData['surname'];

					$emailObj = new Email('html');
					try {

						$emailObj->addRecipient($name,$mail_id,$salutation);
						$emailObj->generateEmail('RECORDTRACKING',$arguments);
						//$emailObj->send(_LIVE_MODE);

					} catch (ErrorException $e) {
						$e->getMessage();
					}
				}
			}
		}



	}

	public function getRecordAction($p_user_id,$p_date_check) {

		/*
		RA - Risk Assessment
		INSP - Inspection
		INCD - Incidence
		INVG - Investigation
		NHC - NHC
		RA27 - Risk 27k
		MH - Manual Handling
		CT - Contractor
		DSE - DSE
		*/

		$sql = sprintf("SELECT * FROM %s.recordTracking WHERE userID = %d ORDER BY dateTimestamp DESC",
							_DB_OBJ_FULL,$p_user_id);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		return $data;

	}

	private function getRecordCreater($p_module,$p_ref) {
		$sql = sprintf("SELECT userID FROM %s.recordTracking WHERE moduleName = '%s' AND action = 'add' AND recordRef = '%s'",
							_DB_OBJ_FULL,$p_module,$p_ref);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$data = $pStatement->fetchColumn();
		return $data;
	}

	public function saveArchivedRecordInfo($arguments=array()) {

		/*
		RA - Risk Assessment
		INSP - Inspection
		INCD - Incidence
		INVG - Investigation
		NHC - NHC
		RA27 - Risk 27k
		MH - Manual Handling
		CT - Contractor
		DSE - DSE
		*/

		$sql = sprintf("INSERT INTO %s.deleteTrail (moduleName,recordID,addedOn)
		VALUES ('%s',%d,'%s')",_DB_OBJ_FULL,$arguments['module'],$arguments['rec_id'],$this->getCurDate());

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
	}

	public function deleteArchivedRecordInfo($arguments=array()) {

		/*
		RA - Risk Assessment
		INSP - Inspection
		INCD - Incidence
		INVG - Investigation
		NHC - NHC
		RA27 - Risk 27k
		MH - Manual Handling
		CT - Contractor
		DSE - DSE
		*/

		$sql = sprintf("DELETE FROM %s.deleteTrail WHERE  moduleName = '%s' AND recordID = %d ",_DB_OBJ_FULL,$arguments['module'],$arguments['rec_id']);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
	}

	public function getTrailRecords() {
		$sql = sprintf("SELECT * FROM %s.deleteTrail ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $data;
	}

	public function duplicateRecord($arguments=array()) {

		$sql = sprintf("INSERT INTO %s.duplicate_records_metadata (module,recordID,addedOn)
		VALUES ('%s',%d,'%s')",_DB_OBJ_FULL,$arguments['module'],$arguments['rec_id'],$this->getCurDate()." ".$this->getCurTime());

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
	}

}
?>