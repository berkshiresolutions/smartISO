<?php
/**
 $Id: Option.class.php,v 3.20 Thursday, February 10, 2011 4:19:09 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, August 14, 2010 5:04:24 PM>
 */

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class Option
{

	private $name;
	private $value;
	private $participant;
	private $dbHand;

	public function __construct() {
 
		$this->dbHand 		= DB::connect(_DB_TYPE);

		//if ( defined(_USER_ID) ) {
		//$this->participant 	= _USER_ID;
		//} else {
			$this->participant 	= 0;
		//}
	}

	public function getGlobalOption($p_name) {
		$tmp = $this->participant+1; // STORE STATE OF PARTICIPANT
		$this->participant = 0; // 0 IS INVALID USER SO BECOMES GLOBAL
		$res = $this->getOption($p_name); // STORE THE VALUE IN RES
		$this->participant = $tmp-1; // RESTORE STATE OF PARTICIPANT
		return $res; // RETURN AND WE ARE DONE!
	}

	public function isGlobalOptionExist($p_name) {
		$oldname = $this->name; // PRESERVE STATE OF NAME IF SET
		$this->name = $p_name; // SET NAME TO TEMPORARY VALUE
		$tmp = $this->participant+1; // STORE STATE OF PARTICIPANT
		$this->participant = 0; // 0 IS INVALID USER SO BECOMES GLOBAL
		$res = $this->isOptionExist($p_name); // STORE THE VALUE IN RES
		$this->participant = $tmp-1; // RESTORE STATE OF PARTICIPANT
		$this->name = $oldname; // RESTORE STATE OF NAME
		return $res; // RETURN AND WE ARE DONE!
	}

	public function addGlobalOption($p_name,$p_value='') {
		$tmp = $this->participant+1; // STORE STATE OF PARTICIPANT
		$this->participant = 0; // 0 IS INVALID USER SO BECOMES GLOBAL
		$this->addOption($p_name,$p_value); // STORE THE VALUE IN RES
		$this->participant = $tmp-1; // RESTORE STATE OF PARTICIPANT
	}

	public function updateGlobalOption($p_name,$p_value='') {
		$tmp = $this->participant+1; // STORE STATE OF PARTICIPANT
		$this->participant = 0; // 0 IS INVALID USER SO BECOMES GLOBAL
		$this->updateOption($p_name,$p_value); // STORE THE VALUE IN RES
		$this->participant = $tmp-1; // RESTORE STATE OF PARTICIPANT
	}
	
	public function getOption($p_name) {

		$sql = sprintf("SELECT opValue FROM %s.options WHERE opName = '".$p_name."' AND participantID = ".$this->participant,_DB_OBJ_FULL);
		//echo $sql;
		$res = $this->dbHand->prepare($sql);
		$res->execute();

		$result = $res->fetchAll();

		return $result[0]['opValue'];
	}
	
	public function getOption1($p_name) {

		$sql = sprintf("SELECT * FROM %s.options WHERE opName = '".$p_name."' ",_DB_OBJ_FULL);
		//echo $sql;
		$res = $this->dbHand->prepare($sql);
		$res->execute();

		$result = $res->fetchAll();

		return $result[0];
	}

	public function addOption($p_name,$p_value='') {

		$this->name = $p_name;
		$this->value = $p_value;


		if ( !is_string($this->name) ) {
			die("Smartiso Error: Option name should be string.");
		}

		if ( !is_scalar($this->value) ) {
			die("Smartiso Error: Option value should be scalar.");
		}

		if ( $this->isOptionExist() ) {
			die("Smartiso Error: Option already exist.");
		} else {
			$this->updateOptionToDB();
		}

	}

	public function updateOption($p_name,$p_value='') {


		$this->name = $p_name;
		$this->value = $p_value;


		if ( !is_string($this->name) ) {
			die("Smartiso Error: Option name should be string.");
		}

		$this->updateOptionToDB();
	}

	public function deleteOption($p_name) {

		$this->name = $p_name;

		if ( !is_string($this->name) ) {
			die("Smartiso Error: Option name should be string.");
		}

		$this->deleteOptionFromDB();
	}

	public function deleteParticipantOptions($p_participantID) {

		$this->participant 	= (int) $p_participantID;

		if ( !$p_participantID ) {
			die("Smartiso Error: Participant ID should be integer.");
		}

		$this->deleteParticipantOptionFromDB();
	}

	private function isOptionExist() {

		$exist 	= false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.options WHERE opName = '".$this->name."' AND participantID = ".$this->participant,_DB_OBJ_FULL);

		if ($res = $this->dbHand->query($sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$exist 	= true;
			}
		}

		return $exist;

	}

	private function updateOptionToDB() {

		if ( $this->isOptionExist() ) {

			$sql = "UPDATE %s.options SET opValue = '%s' WHERE opName = '%s'  AND participantID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->value,$this->name,$this->participant);
			$stmt = $this->dbHand->prepare($psql);

			/*$stmt->bindParam(1,$this->value);
			$stmt->bindParam(2,$this->name);
			$stmt->bindParam(3,$this->participant,PDO::PARAM_INT);*/

		} else {

			$sql = "INSERT INTO %s.options (opName, opValue, participantID) VALUES ('%s', '%s', %d)";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->name,$this->value,$this->participant);
			$stmt = $this->dbHand->prepare($psql);

			/*$stmt->bindParam(1,$this->name);
			$stmt->bindParam(2,$this->value);
			$stmt->bindParam(3,$this->participant,PDO::PARAM_INT);*/
		}

		return $stmt->execute();
	}

	private function deleteParticipantOptionFromDB() {

		$sql = "DELETE FROM %s.options WHERE participantID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->participant);
		$stmt = $this->dbHand->prepare($psql);

		return $stmt->execute();
	}

}
