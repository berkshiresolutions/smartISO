<?php
 /**
  $Id: ImageSlicing.class.php,v 3.10 Monday, January 03, 2011 6:19:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2009 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Pdf Image
  * @since  Wednesday, December 09, 2009 1:12:09 PM>
  */
class ImageSlicing {

	private $filename;
	private $swimlaneid;
	private $src_img;
	private $dest_img;
	private $slices;
	private $height;
	private $width;
	private $vertical_slices;
	private $horizontal_slices;
	private $slicelist;

	public function __construct($p_filename) {

		$this->swimlaneid = $p_swimlaneid;
		$this->vertical_slices = 1;
		$this->horizontal_slices = 1;
		$this->filename = $p_filename;
		$this->get_dimensions();

		ini_set('memory_limit','40M'); //for memory size
		$this->src_img = imagecreatefrompng($this->filename);

		$this->do_calculations();
	}


	public function slice_list() {
		return $this->slicelist;
	}

	private function get_dimensions() {


		$fileinfo 		= getimagesize($this->filename);
		$size_info 		= explode('=',$fileinfo[3]);

		$size_info[1] 	= explode(' ',$size_info[1]);

		$this->width 	= trim($size_info[1][0],'"');
		$this->height 	= trim($size_info[2],'"');
	}

	private function do_calculations() {

		if ( $this->width > 1103 ) {
			$this->vertical_slices = ceil($this->width/1100);
		}

		if ( $this->height > 1102 ) {
			$this->horizontal_slices = ceil($this->height/1100);
		}

		$total_slices = $this->vertical_slices * $this->horizontal_slices;

		if ($total_slices) {

			$slice_list = array();

			$z = 0;
			//echo $this->vertical_slices;
			//exit;

			for ($k=0;$k<$this->horizontal_slices;$k++) {
				for ($i=0;$i<$this->vertical_slices;$i++) {

					$src_x = $i*1100 + 1;
					$src_y = $k*1600 + 1;
					$des_w = 1100; // dest width
					$des_h = 1600; // dest height

					if ( ($src_x+$des_w) > $this->width ) {
						$des_w = $this->width - $src_x + 1;
					}

					if ( ($src_y+$des_h) > $this->height ) {
						$des_h = $this->height - $src_y + 1;
					}

					$dyn_res = imagecreatetruecolor(1100,1600);

					$bgcolor = imagecolorallocate($dyn_res,255,255,255);
					imagefilledrectangle($dyn_res,0,0,1100,1600,$bgcolor);

					//header('Content-Type: image/png');

					imagecopy($dyn_res,$this->src_img,0,0,$src_x,$src_y,$des_w,$des_h);

					$filename_arr = explode('.',basename($this->filename));
					$filename_wo_ext = $filename_arr[0];

					$dyn_name = $filename_wo_ext.'_'.chr($z+97).'.png';
					imagepng($dyn_res,"../private_files/process_flow/".$dyn_name);

					$slice_list[] = "../private_files/process_flow/".$dyn_name;

					$z++;
				}
			}
		} // end if

		$this->slicelist = $slice_list;
	}
}

?>