<?php

error_reporting(E_ALL);

class RevisionHelper {
	
	// Public
	public $recordID;
	public $revision;
	public $parentID;
	
	// Protected
	protected $dbHand;
	protected $errorMessages;
	protected $cols;
	protected $tblName;
	protected $primaryFieldName;
	
	CONST DEFAULT_COLS = '*';
	CONST DEFAULT_TBLNAME = '';
	CONST DEFAULT_PRIFIELDNAME = 'id';
	
	public function __construct() {
		$this->dbHand = DB::Connect(_DB_TYPE);
		$this->errorMessages = array();
		$this->cols = self::DEFAULT_COLS;
		$this->tblName = self::DEFAULT_TBLNAME;
		$this->primaryFieldName = self::DEFAULT_PRIFIELDNAME;
		$this->parentID = 0;
		$this->recordID = 0;
	}
	
	public function setTableName($tblName=self::DEFAULT_TBLNAME) {
		return $this->setFieldVal('tblName',$tblName);
	}
	
	public function setCols($cols=self::DEFAULT_COLS) {
		return $this->setFieldVal('cols',$cols);
	}
	
	public function setPrimaryFieldName($name=self::PRIFIELDNAME) {
		return $this->setFieldVal('primaryFieldName',$name);
	}
	
	public function setParentID($id=0) {
		return $this->setFieldVal('parentID',$id);
	}
	
	public function setRecordID($id=0) {
		return $this->setFieldVal('recordID',$id);
	}
	
	protected function setFieldVal($field,$val='') {
		if(!empty($val)) {
			$this->$field = $val;
		} return $this;
	}
	
	public function getErrorMessage($id='last') {
		if($id === 'last') {
			return end($this->errorMessages);
		} return $this->errorMessages[$id];
	}
	
	public function reviseObject($addConds='',$rev=0) {
		if($rev === 0) {
			$rev = time();
		}
		$sql = sprintf(
			"INSERT INTO %s.%s (%s) (SELECT %s, %d AS 'rev', %d AS 'parent_id' FROM %s.%s WHERE %s = %d %s);", 
				_DB_OBJ_FULL, 
			$this->tblName,
				$this->cols.', [rev], [parent_id]',
				$this->cols, 
				$rev, 
				$this->parentID, 
				_DB_OBJ_FULL, 
				$this->tblName, 
				$this->primaryFieldName, 
				$this->recordID, 
				$addConds
		);
		$stmt = $this->dbHand->prepare($sql);
		if($stmt->execute()) {
			$this->revision = $rev;
			//$this->recordID = getLastInsertId();
			return true;
		} else {
			echo $sql;
			echo "<br>";
			var_dump( $stmt->errorInfo() );
		} return false;
	}
	
	public function getRevision($revision='last',$addConds='') {
		if($revision == 'last') {
			return $this->getRevisions(' ORDER BY rev DESC ',1);
		} // Implicit else & default case
		$revs = $this->getRevisions();
		return $revs[$revision];
	}
	
	public function getRevisions($addConds=' ORDER BY rev ASC ',$limit=0) {
		$limSQL = '';
		if($limit > 0) { $limSQL = " TOP $limit "; }
		$sql = sprintf(
			/*"SELECT %s FROM %s.%s WHERE %s = %d %s UNION*/
			"SELECT %s %s FROM %s.%s WHERE (%s = %d OR parent_id = %d) %s;",
			/*$cols, _DB_OBJ_FULL, $tblName, $primaryFieldName, $recordID, $addConds,*/
			$limSQL, $this->cols, _DB_OBJ_FULL, $this->tblName, $this->primaryFieldName, $this->recordID, $this->recordID, $addConds
		);
		$stmt = $this->dbHand->prepare($sql);
		if($stmt->execute()) {
			return $stmt->fetchAll(PDO::FETCH_ASSOC); // This gets all revisions linearly
		} else {
			echo "$sql<br/>";
			var_dump( $stmt->errorInfo() );
		} return array();
	}
	
	public function rollBack($rev='prev',$addConds='') {
		$recordID = $this->recordID+1; // Preserve state of recordID
		if($rev === 'prev') { // if we want to perform default of roll-back by single column
			$lastRevs = $this->getRevisions(' '.$addConds.' ORDER BY rev DESC ',2);
			$myRev = end($lastRevs);
			$this->recordID = $myRev[$this->primaryFieldName];
		} else { // default revision
			$revs = $this->getRevisions();
			$myRev = $revs[$revision];
			$this->recordID = $myRev[$this->primaryFieldName];
		}
		$ret = $this->reviseObject(' '.$addConds,time());
		$this->recordID = $recordID-1;
		return $ret;
		//$this->reviseObject( $this->tblName, $this->recordID, $cols, $addConds );
	}

	public function uniqueListingWithRevCount($addConds='') {
		$sql = sprintf(
			"SELECT /* %s */ *, (SELECT COUNT([rev]) AS 'revisions' FROM %s.%s QIN WHERE QIN.[parent_id] = QOUTER.[%s] %s) AS 'revisions'
			FROM %s.%s QOUTER WHERE (parent_id < 1 OR parent_id IS NULL) %s;",
			$this->cols, _DB_OBJ_FULL, $this->tblName, $this->primaryFieldName, $addConds,
			_DB_OBJ_FULL, $this->tblName, $addConds
		);
		$stmt = $this->dbHand->prepare($sql);
		if($stmt->execute()) {
			return $stmt->fetchAll(PDO::FETCH_ASSOC); // This gets all revisions linearly
		} else {
			echo "$sql<br/>";
			var_dump( $stmt->errorInfo() );
		}
		return array();
	}
	
}
