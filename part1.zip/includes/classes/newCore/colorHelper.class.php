<?php

 /**
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  * 
  * @package Smartiso
  * @subpackage xyData class for handiling two-dimensional data, mainly used for tables
  * 
  */

class colorHelper {
	const LIGHT_PURPLE = 'AF99D8';
	const DARK_PURPLE = '7E67A8';
	const RED = 'FF0000';
	const GREY = 'CCCCCC';
	const WHITE = 'FFFFFF';
	const BLACK = '000000';
	
	const DEFAULTR = 0;
	const DEFAULTG = 0;
	const DEFAULTB = 0;
	const DEFAULTALPHA = 255;

	/*
	 * Hex2RGBArr
	 * Used to convert between HEXIDECIMAL (HTML) RGB component colors and RGB (array component) colors used by FPDF
	 * @access public
	 * @param string $hex This must be 6 character long and valid hexidecimal
	 * @returns array (r,g,b) or array (self::DEFAULTR,self::DEFAULTG,self::DEFAULTB)
	 */
	public static function Hex2RGBArr($hex) {
		$hex = str_replace('#','',$hex); // deal with hash
		if(strlen($hex) != 6 ){
			return array(self::DEFAULTR,self::DEFAULTG,self::DEFAULTB);
		}
		
		$r = hexdec(substr($hex,0,2));
		$g = hexdec(substr($hex,2,2));
		$b = hexdec(substr($hex,4,2));
		
		return array($r,$g,$b);
	}
	
	/*
	 * Hex2ARGBArr
	 * Used to convert between HEXIDECIMAL (RGBA|ARGB) component colors and ARGB (array component) colors
	 * @access public
	 * @param string $hex This must be 8 characters long and valid hexidecimal
	 * @param $argb This denotes argb in so full alpha would be FFXXXXXX instead of XXXXXXFF
	 * @returns array (a,r,g,b) or array (self::DEFAULTALPHA,self::DEFAULTR,self::DEFAULTG,self::DEFAULTB)
	 */
	public static function Hex2ARGBArr($hex,$argb=false) {
		$out = self::Hex2RGBAArr($hex,$argb);
		return array($out[3]+0,$out[0]+0,$out[1]+0,$out[2]+0);
	}
	
	/*
	 * Hex2RGBAArr
	 * Used to convert between HEXIDECIMAL (RGBA|ARGB) component colors and RGBA (array component) colors
	 * @access public
	 * @param string $hex This must be 8 characters long and valid hexidecimal
	 * @param $argb This denotes argb in so full alpha would be FFXXXXXX instead of XXXXXXFF
	 * @returns array (r,g,b,a) or array (self::DEFAULTR,self::DEFAULTG,self::DEFAULTB,self::DEFAULTALPHA)
	 */
	public static function Hex2RGBAArr($hex,$argb=false) {
		$hex = str_replace('#','',$hex); // deal with hash
		if(strlen($hex) != 8) {
			return array(self::DEFAULTR,self::DEFAULTG,self::DEFAULTB,self::DEFAULTALPHA);
		}
		$startRGB = $argb ? 2 : 0; 
		$startAlpha = $argb ? 0 : 6;
		$out = self::Hex2RGBArr(substr($hex,$startRGB,6));
		$a = self::getHexByteVal(substr($hex,$startAlpha,2));
		return array($out[0]+0,$out[1]+0,$out[2]+0,$a);
	}
	
	/*
	 * getAlpha
	 * Used to convert Alpha component between HEXIDECIMAL and decimal
	 * @access public
	 * @param string $hex This must be 2 characters long and valid hexidecimal
	 * @returns int (0-255) Invalid always returns 255 to prevent invisible colors accidentally being created
	 */
	public static function getHexByteVal($hex) {
		if(strlen($hex) != 2)
			return self::DEFAULTALPHA; // assume full alpha if nothing supplied
		return hexdec($hex);
	}
}