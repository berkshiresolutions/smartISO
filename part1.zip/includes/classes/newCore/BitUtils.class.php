<?php
/**
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  * 
  * @package Smartiso
  * @subpackage Bit-Testing Utilities
  * 
  */
final class BitUtils {
	
	public static function areAnyBitsSet($in,$chk) {
		return (bool)( ($in & $chk) !== 0 ); //if not zero we have a match
	}
	
	public static function areAllBitsSet($in,$chk) {
		return (bool)( ($in & $chk) === max($in,$chk) ); //if not zero we have a match
	}
	
	public static function genSQLAnyBitsSet($fieldName,$value) {
		return " ($fieldName & $value) != 0 ";
	}
	
	public static function genSQLAllBitsSet($fieldName,$value) {
		return " ($fieldName & $value) = MAX($fieldName,$value) ";
	}
}