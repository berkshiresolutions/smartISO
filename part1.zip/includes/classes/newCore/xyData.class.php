<?php

 /**
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  * 
  * @package Smartiso
  * @subpackage xyData class for handiling two-dimensional data, mainly used for tables
  * @author CODESIGN2 <lewis-cowles@codesign2.co.uk>
  * 
  */
class xyData {
	// bounds information
	protected $x;
	protected $y;
	protected $width;
	protected $height; // unused
	
	// used for array of data
	protected $data;
	
	/**
	 * Creates a new xyData Object
	 *
	 * @param int $width the width of the data table
	 * @param int $height the height of the data table, defaults to whatever width is
	 */
	public function __construct($width,$height=0) {
		$this->width = $width;
		$this->height = $height > 0 ? $height : $width;
		$this->x = 0; $this->y=0;
		$this->data = array();
	}
	
	/**
	 * moves to the next row
	 *
	 * @param int $holdX would increment the row, unless equal to the maximum valid value, as defined by width, but leave column position as-is (useful for setting data for a specific column)
	 * @return instance for chaining
	 */
	public function nextRow($holdX=false) {
		$this->y = $this->y >= $this->height-1 ? $this->height-1 : $this->y+1; // this restricts writing to height specified in constructor
		if(!$holdX) {
			$this->x = 0;
		}
		return $this;
	}
	
	/**
	 * moves to the previous row
	 *
	 * @param int $holdX would decrement the row, unless 0, but leave column position as-is (useful for setting data for a specific column)
	 * @return instance for chaining
	 */
	public function prevRow($holdX=false) {
		$this->y = $this->y > 0 ? $this->y-1 : 0;
		if(!$holdX) {
			$this->x = 0;
		}
		return $this;
	}
	
	/**
	 * moves to the next column, unless on the last column at which point it sets column to the start and attempts to move to the next row
	 * @return instance for chaining
	 */
	public function nextCol() {
		if($this->x >= count($this->data[$this->y])-1) {
			$this->nextRow();
		} else { $this->x++; };
		return $this;
	}
	
	/**
	 * moves to the previous column, unless on the first column at which point it sets column to the end and attempts to move to the previous row
	 * @return instance for chaining
	 */
	public function prevCol() {
		if($this->x > 0) {
			$this->x--;
		} else {
			$this->x = $this->width-1;
			$this->prevRow();
		}
		return $this;
	}
	
	/**
	 * moves to the specified row and column if possible
	 * @param int $fromY this is the new row position
	 * @param int $fromX this is the new column position
	 * @return instance for chaining
	 */
	public function setPos($fromY=null,$fromX=null) {
		//Row
		$this->y = (((int)$fromY >= 1) && ((int)$fromY <= $this->height)) ? (int)$fromY-1 : $this->y;
		if(!is_array($this->data[$this->y])) { // allows for setting position up to value of height
			$this->data[$this->y] = array();
		}
		//Column
		$this->x = (((int)$fromX >= 1) && ((int)$fromX <= (count($this->data[$this->y])-1) )) ? (int)$fromX-1 : $this->x; 

		return $this;
	}
	
	/**
	 * Sets data for entire row
	 * @param array $row this is the row data to set
	 * @param int $fromY this is the row to operate on (optional, if operating on specific row)
	 * @return instance for chaining
	 */
	public function setRowData($row,$fromY=null,$transformDataCallback=null,$transformDataCallbackArgs=array()) {
		$this->setPos($fromY);
		if($transformDataCallback !== null) {
			$out = array();
			foreach($row as $colData) {
				$transformDataCallbackArgs[0] = $colData; // set first argument to be data to work on
				$out[] = call_user_func_array($transformDataCallback,$transformDataCallbackArgs);
			}
			$row = array_merge($out,array());
		}
		if(count($row) <= $this->width) { // To allow for jagged data-sets
			$this->data[$this->y] = $row;
		}
		return $this;
	}
	
	/**
	 * Sets data for column within row
	 * @param mixed $data this is the data to set for column in row
	 * @param int $fromY this is the row to operate on (optional, if operating on specific row)
	 * @param int $fromX this is the column to operate on (optional, if operating on specific row)
	 * @return instance for chaining
	 */
	public function setDataAt($data,$fromY=null,$fromX=null,$transformDataCallback=null,$transformDataCallbackArgs=array()) {
		$this->setPos($fromY, $fromX);
		if(!is_array($this->data[$this->y])) {
			$this->data[$this->y] = array();
		}
		if($transformDataCallback !== null) {
			$transformDataCallbackArgs[0] = $data; // set first argument to be data to work on
			$data = call_user_func_array($transformDataCallback,$transformDataCallbackArgs);
		}
		$this->data[$this->y][$this->x] = $data;
		return $this;
	}
	
	/**
	 * Sets data for column within row
	 * @param mixed $data this is the data to set for column in row, can be value or array of values to set from this point
	 * @return instance for chaining
	 */
	public function addData($data,$transformDataCallback=null,$transformDataCallbackArgs=array()) {
		if(is_array($data)) {
			return $this->addArray($data,$this->y,$this->x,$transformDataCallback,$transformDataCallbackArgs);
		} else {
			return $this->setDataAt($data,$this->y,$this->x,$transformDataCallback,$transformDataCallbackArgs);
		}
		return $this;
	}
	
	/**
	 * Sets data for columns from current column, based upon array
	 * @param mixed $data this is the data to set for column in row, can be value or array of values to set from this point
	 * @return instance for chaining
	 */
	public function addArray($data,$fromY=null,$fromX=null,$transformDataCallback=null,$transformDataCallbackArgs=array()) {
		$this->setPos($fromY, $fromX);
		if($transformDataCallback !== null) {
			$out = array();
			foreach($data as $colData) {
				$transformDataCallbackArgs[0] = $colData; // set first argument to be data to work on
				$out[] = call_user_func_array($transformDataCallback,$transformDataCallbackArgs);
			}
			$data = array_merge($out,array());
		}
		foreach($data as $col) {
			$this->setDataAt($col)->nextCol();
		}
		return $this;
	}
	
	/**
	 * gets data for column
	 * @param int $fromY this is the row to operate on (optional, if operating on specific row)
	 * @param int $fromX this is the column to operate on (optional, if operating on specific row)
	 * @return instance for chaining
	 */
	public function getColData($fromX=null,$fromY=null) {
		$this->setPos($fromY, $fromX);
		return $this->data[$this->y][$this->x];
	}
	
	/**
	 * gets data for row
	 * @param int $fromY this is the row to operate on (optional, if operating on specific row)
	 * @return instance for chaining
	 */
	public function getRowData($fromY=null) { 
		$this->setPos($fromY);
		return $this->data[$this->y];
	}
	
	/**
	 * gets data from object
	 * @return array data
	 */
	public function getData() { 
		return $this->data;
	}
	
	/**
	 * Used For debugging
	 * @return string debugging information on object including row position, column position, width, height and var_export'ed data
	 */
	public function __toString() {
		return "row:".($this->y+1)."\r\ncol:".($this->x+1)."\r\nwidth:".($this->width)."\r\nheight:".($this->height)."\r\ndata:\r\n".var_export($this->getData());
	}
	
	public function fillData() {
		// setup array
		for($j=0;$j<$this->height;$j++) {
			$this->data[$j] = $this->buildRow(); // ensures no reference and width is preserved	
		}
	}
	
	public function buildRow($colCnt=0) {
		if(($colCnt <= 1) || ($colCnt >= $this->width)) {
			$colCnt = $this->width;
		}
		$cols = array();
		for($i=0;$i<$this->width;$i++) {
			$cols[] = "";
		}
		return $cols;
	}
	
	public function shrinkRowColsTo($to=1,$fromY=null) { 
		$this->setPos($fromY);
		$cursize = count($this->data[$this->y]);
		$this->shrinkRowColsBy( abs( $cursize-($to%$cursize) ) );
		return $this;
	}
	
	public function shrinkRowColsBy($by=1,$fromY=null) { 
		$this->setPos($fromY);
		for($i=0;$i<$by;$i++) {
			$this->shrinkRowCols();
		}
		return $this;
	}
	
	public function shrinkRowCols($fromY=null) { 
		$this->setPos($fromY);
		if(count($this->data[$this->y]) > 1) { // must have at least two columns in row to shrink
			array_pop($this->data[$this->y]);
		}
		return $this;
	}
	
	public function growRowCols($by=1,$fromY=null) { 
		$this->setPos($fromY);
		$dest = count($this->data[$this->y]) + $by;
		if($dest >= $this->width) { // do not grow beyond width
			$dest = $this->width;
		}
		array_pad($this->data[$this->y],$dest,"");
		return $this;
	}
}