<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

// NOTICE: WE INCLUDE IN A RELATIVE TO THIS FILE WAY, IF FILE-SYSTEM CHANGES 
// SHOULD OCCUR UPDATE THIS OR KEEP FOLDER HEIRARCHY OF DEPENDANCIES RELATIVE 
// TO THIS FILE. THIS WAS DONE SO THAT ONCE COMPLETED NEW CORE WILL BE RENAMED 
// AND MOVED AND ALL IT'S DEPENDENCIES WILL MOVE WITH IT
require_once realpath(dirname(__FILE__)).'/inductData.class.php';
require_once realpath(dirname(__FILE__)).'/../../xyData.class.php';
require_once realpath(dirname(__FILE__)).'/../../colorHelper.class.php';
require_once realpath(dirname(__FILE__)).'/../../courseClassificationEnums.const.php';
require_once realpath(dirname(__FILE__)).'/../../vendors/fpdf/fpdfTableRowDataHelper.class.php';

/**
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  * 
  * @package Smartiso
  * @subpackage Induct-Reports
  * 
  */
class inductReports {
	
	const NO_RECORDS_R1 = "No Records Found!";
	const NO_RECORDS_R3 = "No More To Be Done!";
	const FLOWS_SEC_HEADER = " Process-Flow Details";
	const RISKS_SEC_HEADER = " Process-Risks Details";
	const DOCS_SEC_HEADER = " Documents Details";
	const TRAINING_SEC_HEADER = "Training / Induction Course Details";
	const COMPLETED = "Completed";
	const INCOMPLETE = "Incomplete";
	
	private $Styles;
	function __construct() {
		$this->Styles = array(
			"sectionHeading"=>array(null,4,11,fpdfTableRowDataHelper::ALIGN_CENTER,colorHelper::hex2RGBArr(colorHelper::WHITE),colorHelper::hex2RGBArr(colorHelper::DARK_PURPLE))
			,"sectionSubHeading"=>array(null,1,10,fpdfTableRowDataHelper::ALIGN_LEFT,colorHelper::hex2RGBArr(colorHelper::WHITE),colorHelper::hex2RGBArr(colorHelper::LIGHT_PURPLE))
			,"sectionSubHeadingTwoCol"=>array(null,2,10,fpdfTableRowDataHelper::ALIGN_LEFT,colorHelper::hex2RGBArr(colorHelper::WHITE),colorHelper::hex2RGBArr(colorHelper::LIGHT_PURPLE))
			,"oneColBlackonWhite"=> array(null,1,9,null,colorHelper::hex2RGBArr(colorHelper::BLACK),colorHelper::hex2RGBArr(colorHelper::WHITE))
			,"twoColBlackonWhite"=> array(null,2,9,null,colorHelper::hex2RGBArr(colorHelper::BLACK),colorHelper::hex2RGBArr(colorHelper::WHITE))
			,"threeColBlackonWhite"=> array(null,3,9,null,colorHelper::hex2RGBArr(colorHelper::BLACK),colorHelper::hex2RGBArr(colorHelper::WHITE))
			,"fourColBlackonWhite"=> array(null,4,9,fpdfTableRowDataHelper::ALIGN_CENTER,colorHelper::hex2RGBArr(colorHelper::BLACK),colorHelper::hex2RGBArr(colorHelper::WHITE))
			,"oneColWhiteOnRed"=> array(null,1,9,null,colorHelper::hex2RGBArr(colorHelper::WHITE),colorHelper::hex2RGBArr(colorHelper::RED))
		);
	}
	
	function genReports($pf=false,$pr=false,$doc=false,$training=true,$r1=true) {
		$tableData = new xyData(4,999999);
		
		$pfcnt = 0;
		$prcnt = 0;
		$doccnt = 0;
		$traincnt = 0;
		
		$proffs = 0;
		$docoffs = 0;
		$trainoffs= 0;
		
		if($pf) {
			$this->genPFReport($tableData,$r1);
			$pfcnt = count($tableData->getData());
			$proffs = $pfcnt+0;
			$docoffs = $proffs+0;
			$trainoffs = $proffs+0;
		} if($pr) {
			$this->genPRReport($tableData,$r1);
			$docoffs = count($tableData->getData());
			$trainoffs = $docoffs+0;
			$prcnt = $docoffs - $pfcnt;
		} if($doc) {
			$this->genDocReport($tableData,$r1);
			$trainoffs = count($tableData->getData());
			$doccnt = $trainoffs-($pfcnt+$prcnt);
		} if($training) {
			$this->genTrainReport($tableData,$r1);
			$traincnt = count($tableData->getData())-($pfcnt+$prcnt+$doccnt);
		}
		
		return array(
			'pfcnt'=>$pfcnt,'prcnt'=>$prcnt,'doccnt'=>$doccnt,'traincnt'=>$traincnt,
			'pfoffs'=>0,'proffs'=>$proffs,'docoffs'=>$docoffs,'trainoffs'=>$trainoffs,
			'data'=>$tableData->getData()
		);
	}
	
	private function genPFReport($tableData,$done=true) {
		//$tableData->fillData();
		$iData = new inductData();
		$processFlowData = $iData->getPFData($done,!$done); // get pf data for done and not-done
		
		$tableData->setRowData(array(($done ? self::COMPLETED : self::INCOMPLETE).self::FLOWS_SEC_HEADER),0
			,array($this,'genCellDets'),$this->Styles['sectionHeading'])
			->shrinkRowColsTo(1)
			->nextRow(); // TOP SECTION ROW
		$tableData->setRowData(array(
			"Reference #","Business Unit",""
			),0,array($this,'genCellDets'),$this->Styles['sectionSubHeading'])->nextCol()->nextCol()
			->setDataAt("Description",null,3,array($this,'genCellDets'),$this->Styles['sectionSubHeadingTwoCol'])->nextCol()
			->nextRow(); // SUB-SECTION HEADERS
		$output = 0; // set up a marker for how many are done
		foreach($processFlowData as $item) {
			if($item['RandU'] != $done) {
					continue;	// if we are looking for done items & key does not exist or if we are looking for not done items and the key does exist	}
			}
			$output++;
			$myRef = $item['reference'];									/* <?php echo $myRef; ?> */
			$myBuID = $item['buID'];										/* <?php echo $myBuID; ?> */
			$myDesc = $item['description'];									/* <?php echo $myDesc; ?> */
			/*
			 * NOT SURE WE NEED PARTICIPANT INFO
			 * $participant_id = $item['whoID'];
			$participantObj->setItemInfo(array('id'=>$participant_id));
			$partcipantData = $participantObj->displayItemById();
			$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
			*/
			$tableData->setRowData(array(
					$myRef,$item['buName']."($myBuID)",""
				),0,array($this,'genCellDets'),$this->Styles['oneColBlackonWhite'])->nextCol()->nextCol()
				->setDataAt($myDesc,null,3,array($this,'genCellDets'),$this->Styles['twoColBlackonWhite'])->nextCol()
				->nextRow(); // CONTENT-RECORD TOP-ROW
		} $this->emptyMsg($output,$tableData,$done);
	}
	
	private function genPRReport($tableData,$done=true) {
		//$tableData->fillData();
		
		$iData = new inductData();
		$RiskData = $iData->getPRData($done,!$done); // get pf data for done and not-done
		
		$tableData->setRowData(array(($done ? self::COMPLETED : self::INCOMPLETE).self::RISKS_SEC_HEADER),0
			,array($this,'genCellDets'),$this->Styles['sectionHeading'])
			->shrinkRowColsTo(1)
			->nextRow(); // TOP SECTION ROW
		$tableData->setRowData(array(
			"Reference #","Business Unit",""
			),0,array($this,'genCellDets'),$this->Styles['sectionSubHeading'])->nextCol()->nextCol()
			->setDataAt("Description",null,3,array($this,'genCellDets'),$this->Styles['sectionSubHeadingTwoCol'])->nextCol()
			->nextRow(); // SUB-SECTION HEADERS
		$output = 0; // set up a marker for how many are done
		foreach($RiskData as $item) {
			if($item['RandU'] != $done) {
				continue;	// if we are looking for done items & key does not exist or if we are looking for not done items and the key does exist
			}
			$output++;
			$myRef = $item['reference'];										/* <?php echo $myRef; ?> */
			$myBuID = $item['buID'];											/* <?php echo $myBuID; ?> */
			$myDesc = $item['description'];										/* <?php echo $myDesc; ?> */
			
			$tableData->setRowData(array(
					$myRef,$item['buName']."($myBuID)",""
				),0,array($this,'genCellDets'),$this->Styles['oneColBlackonWhite'])->nextCol()->nextCol()
				->setDataAt($myDesc,null,3,array($this,'genCellDets'),$this->Styles['twoColBlackonWhite'])->nextCol()
				->nextRow(); // CONTENT-RECORD TOP-ROW
		} $this->emptyMsg($output,$tableData,$done);
	}
	
	private function genDocReport($tableData,$done=true) {
		//$tableData->fillData();
		
		$iData = new inductData();
		$documentlistdata = $iData->getDocData($done,!$done); // get pf data for done and not-done
		
		$tableData->setRowData(array(($done ? self::COMPLETED : self::INCOMPLETE).self::DOCS_SEC_HEADER),0,array($this,'genCellDets'),$this->Styles['sectionHeading'])
			->shrinkRowColsTo(1)
			->nextRow(); // TOP SECTION ROW
		$tableData->setRowData(array('','','',''),0,null,null)
			->setDataAt("Title",null,1,array($this,'genCellDets'),$this->Styles['sectionSubHeading'])->nextCol()
			->setDataAt("Description",null,2,array($this,'genCellDets'),$this->Styles['sectionSubHeadingTwoCol'])->nextCol()->nextCol()
			->setDataAt("Date Completed",null,4,array($this,'genCellDets'),$this->Styles['sectionSubHeading'])->nextCol()->nextRow(); // SUB-SECTION HEADERS
		$output = 0;
		foreach($documentlistdata as $item) {
			if(strlen($item['title']) < 1){ continue; } // SKIPS Blank Docs (should not be needed in live server)
			
			if($item['RandU'] != $done) {
				continue;	// if we are looking for done items & key does not exist or if we are looking for not done items and the key does exist
			}
			$output++;
			
			$tableData->setRowData(array('','','',''),0,null,null)
			->setDataAt( ((strlen($item['title']) > 1) ? $item['title'] : " - "),null,1,array($this,'genCellDets'),$this->Styles['oneColBlackonWhite'])->nextCol()
			->setDataAt( $item['description'],null,2,array($this,'genCellDets'),$this->Styles['twoColBlackonWhite'])->nextCol()->nextCol()
			->setDataAt( date('d-m-Y')."",null,4,array($this,'genCellDets'),$this->Styles['oneColBlackonWhite'])->nextCol()->nextRow(); // should also put us on a newline if we call it here, but I like nextRow()
//			->nextRow(); // CONTENT-RECORD ONLY-ROW
		} $this->emptyMsg($output,$tableData,$done);
	}
	
	private function genTrainReport($tableData,$done=true) {
		//$tableData->fillData();
		
		$iData = new inductData();
		$coursesData = $iData->getCourseData($done,!$done); // get pf data for done and not-done
		
		$tableData->setRowData(array(self::TRAINING_SEC_HEADER),0
			,array($this,'genCellDets'),$this->Styles['sectionHeading'])
			->shrinkRowColsTo(1)
			->nextRow(); // TOP SECTION ROW
		$tableData->setRowData(array(
			"Reference #","Title","Completed","Course Classification"
			),0,array($this,'genCellDets'),$this->Styles['sectionSubHeading'])->nextRow(); // SUB-SECTION HEADERS
		$output = 0;
		foreach($coursesData as $item) {
			//completed date
			$complete_date = date('d-m-Y',strtotime($item["completeDate"])); 
			if($complete_date > date('d-m-Y')) {
				$complete_date = $complete_date;
			} else {
				$complete_date = 'Incomplete';
			}
			//classification's
			$classification = "None";
			$classification .= (($item['course_classification_enum'] & courseClassificationEnums::CORE) > 0) ? "Core" : "";
			$classification .= (($item['course_classification_enum'] & courseClassificationEnums::WORKER) > 0) ? "Worker" : "";
			$classification .= (($item['course_classification_enum'] & courseClassificationEnums::MANAGER) > 0) ? "Manager" : "";
			$classification .= (($item['course_classification_enum'] & courseClassificationEnums::PRACTITIONER) > 0) ? "Practitioner" : "";
			if($classification == ""){ $classification == "None"; }
			
			$tableData->setRowData(array(
			$item["refNumber"],$item["title"],$complete_date,$classification
			),0,array($this,'genCellDets'),$this->Styles['oneColBlackonWhite'])->nextRow(); // CONTENT-RECORD TOP-ROW
			$output++;
		} $this->emptyMsg($output,$tableData,$done);
	}
	
	private function emptyMsg($output, $tableData, $r1) {
		if($output == 0) {
			$tableData->setDataAt(($r1 ? self::NO_RECORDS_R1 : self::NO_RECORDS_R3),null,1,array($this,'genCellDets'),$this->Styles['fourColBlackonWhite'])->nextCol()
					->nextRow(); // CONTENT-RECORD TOP-ROW
		}
	}
	
	public function genCellDets($text="",$cols=1,$size=10,$align=null,$fgColor=colorHelper::BLACK,$bgColor=colorHelper::WHITE,$valign=fpdfTableRowDataHelper::VALIGN_TOP) {
		return fpdfTableRowDataHelper::genRowData(
			$text,$size,$align
			,$fgColor
			,$bgColor
			,$valign,$cols
		);
	}
}