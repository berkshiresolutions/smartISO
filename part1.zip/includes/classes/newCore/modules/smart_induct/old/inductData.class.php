<?php

/*
 * CORE INCLUDES
 */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/functions.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/Db.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/Session.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/Action.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/Documents.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/ProcessFlowMaster.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/Setup.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/InductSetup.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/TrainingCourseSetup.class.php';

// NOTICE: WE INCLUDE IN A RELATIVE TO THIS FILE WAY, IF FILE-SYSTEM CHANGES 
// SHOULD OCCUR UPDATE THIS OR KEEP FOLDER HEIRARCHY OF DEPENDANCIES RELATIVE 
// TO THIS FILE. THIS WAS DONE SO THAT ONCE COMPLETED NEW CORE WILL BE RENAMED 
// AND MOVED AND ALL IT'S DEPENDENCIES WILL MOVE WITH IT
require_once realpath(dirname(__FILE__)).'/../../BitUtils.class.php';
require_once realpath(dirname(__FILE__)).'/../../courseClassificationEnums.const.php';
require_once realpath(dirname(__FILE__)).'/smartInductSettings.const.php';
require_once realpath(dirname(__FILE__)).'/inductToggles.class.php';

/*
error_reporting(E_ALL);
ini_set('display_errors', '1');
*/

/**
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  * 
  * @package Smartiso
  * @subpackage Induct-Data
  * 
  */
class inductData {
	public static function getCCPInfoForFlowsAndRisks() {
		$objProcessMaster = new ProcessFlowMaster();
		$processFlowCCPData = $objProcessMaster->getCcpMatrixData(); //GET CCP DATA
		$ccpBuIDs = array();
		foreach($processFlowCCPData as $ccpFlow) {
			$ccpBuIDs = array_merge(explode(',',$ccpFlow['data']),$ccpBuIDs);
		}
		return array_unique($ccpBuIDs);
	}
	
	public static function getCCPDocs() {
		$dbHand = DB::connect(_DB_TYPE);
		$sql = sprintf(
			" SELECT documentID ".
			" FROM %s.swimlane_documents SD ".
			" LEFT JOIN %s.swimlane_data SData ".
			" ON SD.swimID = SData.swimID ".
			" WHERE documentID > 0 ".
			" AND SData.criticalControlPoint != '' "
			,_DB_OBJ_FULL
			,_DB_OBJ_FULL
		);

		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		return $pStatement->fetchAll(PDO::FETCH_ASSOC); // would be return not $res = for func
	}
	
	public static function getCoreRefs($numeric=true){
		/*
		* the below was based upon /htdocs/process_flow/ccp_report_html.php
		* and cleaned to be more readily recognisable and easily editable
		*/
		if(!$numeric){
			return array(
			   // full names
			   '4.2.3 - Control of Documents'
			   ,'4.2.4 - Control of Records'
			   ,'5.7 - Legal and Other Requirements'
			   ,'5.8 - Emergency Preparedness and Response'
			   ,'8.2.2 - Internal Audit'
			   ,'8.3 - Control of Non-Conforming Product'
			   ,'8.5.2 - Corrective Action'
			   ,'8.5.3 - Preventive Action'
			);
		} else {
			return array(
				// numeric references
				'4.2.3'
				,'4.2.4'
				,'5.7'
				,'5.8'
				,'8.2.2'
				,'8.3'
				,'8.5.2'
				,'8.5.3'
			);
		}
	}
	
	public function getPFData($done=true,$notdone=true,$user=null) {
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		//dump_array($inductData);
		
		$user_id = ((int)$user >= 1) ? $user : Session::getSessionField('SESS_USER_REC_ID');
		
		$objProcessMaster 	= new ProcessFlowMaster();
		$objProcessMaster->setProcessMasterInfo('','','','','','','',0);
		$processFlowData 	= $objProcessMaster->displayProcessFlows();
		
		
		// echo '<pre>'.var_export($objProcessMaster->getCcpMatrixData(),true).'</pre>';
		$ccpFlowIDs = self::getCCPInfoForFlowsAndRisks();
		
		$inductactions = array();
		foreach( inductToggles::getInductActionsForUserByArea('pf',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions[$objID] = $result;
		}
		$data = array();
		foreach($processFlowData as $procflow) {
			$myID = $procflow['swimID'];
			
			$buIDs = array($procflow['buID']);
			//echo '<pre>'.var_export($procflow,true).'</pre>';
			$lozengeData = $objProcessMaster->getProcessFlowAllSteps($myID);
			//echo '<pre>'.var_export($lozengeData,true).'</pre>';
			
			
			$thisCCP = false;
			foreach($lozengeData as $procStep) {
				if($procStep['criticalControlPoint'] != '') {
					$thisCCP = true;
				}
				array_push($buIDs, $procStep['buID']);
			}
			
			/*
			foreach($buIDs as $bu) {
				echo "BU: $bu, ".((int)self::getParticipantBuID($user_id))."<br/>";
			}
			*/
			
			if( (strtotime($inductactions[$myID]['doneDate']) > strtotime('1980-01-01')) && $done === false){ continue; } //if we dont want to show done
			if( (strtotime($inductactions[$myID]['doneDate']) <= strtotime('1980-01-01')) && $notdone === false ){ continue; } // if we dont want to show not done
			
			if($inductData['ccp_check'] == 'TRUE') {
				if($thisCCP){ $procflow['buID'] = 'CCP'; } // this is a trick for CCP's as we do not want them filterable by BU
			}// echo "ccp check ".(($inductData['ccp_check'] != 'TRUE') ? 'off' : 'on');
			
			if($inductData['key_check'] == 'TRUE') {
				if($procflow["keyProcess"]=="1"){ $procflow['buID'] = 'KEY'; } // neat trick for key processes
			}
			/*
			if($inductData['core_check'] == 'TRUE') {
				if($procflow["processType"]=="C"){ $procflow['buID'] = 'CORE'; } // neat trick for core process flows
			}
			*/
			
			$additionalChecks = array('CCP','CORE','KEY');
			$buCheck = false; // default to not match to avoid false positives
			if(smartInductSettings::BU_FILTER_JS){
				$buCheck = true; // if JS is filtering, then we need to disable PHP Check
			} else {
				$buCheck = ( ( in_array(self::getParticipantBuID($user_id), $buIDs) ) || (in_array($procflow['buID'],$additionalChecks)) );
			}
			
			
			
			// echo self::getParticipantBuID();
			
			if( !$buCheck ){ continue; } //skip BuID's that do not belong to the participant
			
			//
			// past this point everything should be valid for the user_id provided
			//
			 
			//
			// setup action records for users
			//
			
			//if(!array_key_exists($myID, $inductactions)) {
			//	inductToggles::createRandUForUser('pf',$myID,$user_id);
				
				//$inductactions[$myID] = inductToggles::getInductActionForUserByArea('pf',$myID,$user_id);
			//}
			
			//dump_array($lozengeData);
		//exit;
			
			
			$data[] = array_merge(
				array(
					'actionData'=>$inductactions[$myID]
					,'recordType'=>'Process Flow'
					,'RandU'=>(strtotime($inductactions[$myID]['doneDate']) > strtotime('1980-01-01') )
				)
				,$procflow
			);
		}
		
		return $data;
	}
	
	public function getPRData($done=true,$notdone=true,$user=null) {
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		$user_id = ((int)$user >= 1) ? $user : Session::getSessionField('SESS_USER_REC_ID');
		$objRiskAssessment 	= new RiskAssessment();
		$RiskData 		= $objRiskAssessment->getRiskAssessmentProcesses();
		
		$ccpFlowIDs = self::getCCPInfoForFlowsAndRisks();
		
		$inductactions = array();
		foreach( inductToggles::getInductActionsForUserByArea('pr',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions[$objID] = $result;
		}
		
		$objProcessMaster 	= new ProcessFlowMaster();
		$objProcessMaster->setProcessMasterInfo('','','','','','','',0);
		
		$data = array();
		foreach($RiskData as $procrisk) {
			$myID = $procrisk['swimID'];
			
			$buIDs = array();	
			$lozengeData = $objProcessMaster->getProcessFlowAllSteps($myID);
			
			array_push($buIDs, (int)$procrisk['buID']);
			$thisCCP = false;
			foreach($lozengeData as $procStep) {
				if($procStep['criticalControlPoint'] != '') {
					$thisCCP = true;
				}
				array_push($buIDs, (int)$procStep['buID']);
			}
			
			/*
			foreach($buIDs as $bu) {
				echo "BU: $bu, ".((int)self::getParticipantBuID($user_id))."<br/>";
			}
			*/
			// Orphaned risks
			$tmpRisk = new RiskAssessment();
			$tmpRisk->setRiskInfo($myID,null);
			$relatedFlows = $tmpRisk->getRiskAssessmentProcesses();
			$archived = 0;
			foreach($relatedFlows as $swim) {
				if($swim['archive'] > 0){ $archived++; }
			}
			//echo '<pre>'.var_export($relatedFlows,true).'</pre>';
			if( ( count($relatedFlows) < 1 ) || ($archived == count($relatedFlows)) ) { // if there is less than one process... ORPHAN!
				
				$tmpRisk->archiveRisk();
				continue;
			}
			
			if( ($inductactions[$myID]['doneDate'] > '1980-01-01') && $done === false){ continue; } //if we dont want to show done
			if( ($inductactions[$myID]['doneDate'] <= '1980-01-01') && $notdone === false ){ continue; } // if we dont want to show not done
			
			if($inductData['ccp_check'] == 'TRUE') {
				if($thisCCP){ $procrisk['buID'] = 'CCP'; } // this is a trick for CCP's as we do not want them filterable by BU
			}// echo "ccp check ".(($inductData['ccp_check'] != 'TRUE') ? 'off' : 'on');
			
			if($inductData['key_check'] == 'TRUE') {
				if($procrisk["keyProcess"]=="1"){ $procrisk['buID'] = 'KEY'; } // neat trick for key processes
			}
			/*
			if($inductData['core_check'] == 'TRUE') {
				if($procrisk["processType"]=="C"){ $procrisk['buID'] = 'CORE'; } // neat trick for core process risks
			}
			*/
			
			$additionalChecks = array('CCP','CORE','KEY');
			$buCheck = false; // default to not match to avoid false positives
			if(smartInductSettings::BU_FILTER_JS){
				$buCheck = true; // if JS is filtering, then we need to disable PHP Check
			} else {
				$buCheck = ( ( in_array(self::getParticipantBuID($user_id), $buIDs) ) || (in_array($procrisk['buID'],$additionalChecks)) );
			}
			
			// echo self::getParticipantBuID();
			
			if( !$buCheck ){ continue; } //skip BuID's that do not belong to the participant
			if($procrisk['archive'] > 0) { continue; }
			
			// past this point everything should be valid for the user_id provided
			//
			//var_dump($procrisk);
			
			//grab process flow for risk
			
			//if invalid reference < 3 chars archive risk
			
			
			//
			// setup action records for users
			//
			//if(!array_key_exists($myID, $inductactions)) {
			//	inductToggles::createRandUForUser('pr',$myID,$user_id);
				
			//	$inductactions[$myID] = inductToggles::getInductActionForUserByArea('pr',$myID,$user_id);
			//}
			
			// change PF to PR in reference
			$procrisk['reference'] = str_replace("PF","PR",$procrisk['reference']);
			
			$data[] = array_merge(
				array(
					'actionData'=>$inductactions[$myID]
					,'recordType'=>'Process Risk'
					,'RandU'=>(strtotime($inductactions[$myID]['doneDate']) > strtotime('1980-01-01') )
				)
				,$procrisk
			);
		}
		return $data;
	}
	
	public function getDocData($done=true,$notdone=true,$user=null) {
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		
		
		$user_id = ((int)$user >= 1) ? $user : Session::getSessionField('SESS_USER_REC_ID');
		$participant = self::getParticipantData();
		$sql12 = sprintf("
SELECT 
	fileID,
	D.title+' '+CAST(D.description as VARCHAR) as 'Title',
	D.buID,
	B.buName,
	D.classification,
	documentType,
	fileReference,
	usrFilename,
	sysFilename,
	mimeType,
	0 As 'isCCP',
	status
	FROM %s.cms_documents D
		INNER JOIN %s.business_units B
		ON D.buID = B.buID
		INNER JOIN %s.uploaded_files U
		ON D.documentID = U.fileID
	WHERE isArchive < 1 ",
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				_DB_OBJ_FULL
		);
		// Additional CCP grab
		if($inductData['ccp_check'] == 'TRUE') {
			$sql12 .= sprintf("
				
UNION 

SELECT 
	fileID,
	'' AS 'Title',
	S.buID,
	BU.buName,
	'U' AS 'classification',
	'' AS 'documentType',
	SData.cmsReference AS 'fileReference',
	usrFilename,
	sysFilename,
	mimeType,
	1 As 'isCCP',
	'A' As 'status'
	FROM %s.[swimlane_documents] SDocs
		LEFT JOIN %s.[swimlane_data] SData
		ON SDocs.swimID = SData.swimID
		LEFT JOIN %s.[business_units] BU
		ON SData.buID = BU.buID
		LEFT JOIN %s.[swimlane] S 
		ON SData.swimID = S.swimID
		LEFT JOIN %s.[uploaded_files] UF
		ON documentID = fileID
	WHERE documentID > 0
	AND (S.archive < 1 OR S.archive IS NULL)
	AND LEN(SData.criticalControlPoint) > 1",
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				_DB_OBJ_FULL
			);
		}
		//echo $sql12;
		$dbHand = DB::connect(_DB_TYPE);
		$pStatement12 = $dbHand->prepare($sql12);
		$pStatement12->execute();
		$documentlistdata = $pStatement12->fetchAll(PDO::FETCH_ASSOC);
		
		
		$coreRefs = array_merge(self::getCoreRefs(),self::getCoreRefs(false)); // get numeric & non-numeric core identifiers
		
		$inductactions = array();
		foreach( inductToggles::getInductActionsForUserByArea('doc',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions[$objID] = $result;
		}
		//$ccpDocs = self::getCCPDocs(); // Retrieve Documents attached to CCP Lozenges
		$done = array();
		$data = array();
		foreach($documentlistdata as $doc) {
		
		
			echo '<!-- '.$participant['docClassification'].' = '.$doc['classification'].' -->';
			
			//echo '<!-- '.var_export($participant,true).' = '.$doc['classification'].' -->';
			//if(!canParticipantAccessDocument($participant['docClassification'],$doc['classification'])) { continue; }
			$myID = $doc["fileID"];
			if(in_array($myID,$done)) { // Duplicate Eradication
				continue;
			}
			
			//dump_array($doc);
		
		//e/xit;
			if($doc['status'] != 'A'){ continue; } // IS Document Approved
			array_push($done, $myID);
			$doc["title"] = ($doc["title"] == "") ? current(explode(".",$doc["usrFilename"])) : $doc["title"] ;
			$doc['description'] = $doc['title'];
			if( ($inductactions[$myID]['doneDate'] > '1980-01-01') && $done === false){ continue; } //if we dont want to show done
			if( ($inductactions[$myID]['doneDate'] <= '1980-01-01') && $notdone === false ){ continue; } // if we dont want to show not done
			if($inductData['ccp_check'] == 'TRUE') {
				if($doc['isCCP'] == 1){ $doc['buID'] = 'CCP'; } // this is a trick for CCP's as we do not want them filterable by BU
			}
			if($inductData['core_check'] == 'TRUE') {
				if( ($inductData['ccp_check'] != 'TRUE') || ( ($inductData['ccp_check'] == 'TRUE') && ($doc['buID'] != 'CCP') ) ) {
					if(in_array($doc['fileReference'], $coreRefs)){ $doc['buID'] = 'CORE'; } // this is a trick for CCP's as we do not want them filterable by BU
				}
			}
			
			
			
			$additionalChecks = array('CCP','CORE');
			$buCheck = false; // default to not match to avoid false positives
			if(smartInductSettings::BU_FILTER_JS){
				$buCheck = true; // if JS is filtering, then we need to disable PHP Check
			} else {
				$buCheck = ( ( (int)$doc['buID'] == (int)self::getParticipantBuID() ) || (in_array($doc['buID'],$additionalChecks)) );
			}
			
			// echo self::getParticipantBuID();
			if( !$buCheck ){ continue; } //skip BuID's that do not belong to the participant
			
			//
			// past this point everything should be valid for the user_id provided
			//
			
			//	echo $doc['fileReference'].'<br/>'; 
			//
			// setup action records for users
			//
			//if(!array_key_exists($myID, $inductactions)) {
			//	inductToggles::createRandUForUser('doc',$myID,$user_id);
				
				//$inductactions[$myID] = inductToggles::getInductActionForUserByArea('doc',$myID,$user_id);
			//}
			
			$data[] = array_merge(
				array(
					'actionData'=>$inductactions[$myID]
					,'recordType'=>'Document'
					,'RandU'=>(strtotime($inductactions[$myID]['doneDate']) > strtotime('1980-01-01') )
				)
				,$doc
			);
		}
		return $data;
	}
	
	public function getCourseData($done=true,$notdone=true,$user=null) {
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		$user_id = ((int)$user >= 1) ? $user : Session::getSessionField('SESS_USER_REC_ID');
		$objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
		$trainingdata = $objTrainingCourse->displayItems(); // FROM record_manage_course.php $var name changed from $dataTrainingCourse
		$participantCourseInfo = self::getParticipantClassification($user_id); // we have set this to always use the current user ID but it supports getting the classification for an arbitrary participant
		// as we have two sets of actions for induct training, lets get both
		
		$inductactions = array();
		foreach( inductToggles::getInductActionsForUserByArea('traincert',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions[$objID] = $result;
		}
		
		$inductactions2 = array();
		foreach( inductToggles::getInductActionsForUserByArea('trainack',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions2[$objID] = $result;
		}
		if($inductData['prereq_depth'] >= 1) {
			$courses = array();
			$prereqs = array();
			$completed = array();
		}
		
		$data = array();
		//$participantInfo = getParticipantData($user_id);
		foreach($trainingdata as $i=>$course) {
		
		
			$myID = $course["cID"];
			if($inductData['prereq_depth'] >= 1) {
				$courses[$myID] = $i; // we use this for dealing with prerequisites
			}
			if( ( (($inductactions[$myID]['doneDate'] > '1980-01-01') & ($inductactions2[$myID]['doneDate'] > '1980-01-01')) === true) && $done === false){ continue; } //if we dont want to show done
			if( ( (($inductactions[$myID]['doneDate'] <= '1980-01-01') & ($inductactions2[$myID]['doneDate'] <= '1980-01-01')) !== true) && $notdone === false ){ continue; } // if we dont want to show not done
			if( ( $course['course_classification_enum'] & courseClassificationEnums::CORE != courseClassificationEnums::CORE ) && ( !in_array($myID ,explode(',',$participantInfo['induction_courses'])) ) ){ continue; }
			//if( ( ($participantCourseInfo & $course['course_classification_enum']) == courseClassificationEnums::NONE ) && ($course['course_classification_enum'] != courseClassificationEnums::CORE) ){ continue; } // if the course is not a match for any of the participant classifications
			
			//
			// past this point everything should be valid for the user_id provided
			//
			 
			//
			// setup action records for users
			//
			
			//if(!array_key_exists($myID, $inductactions)) {
			//	inductToggles::createRandUForUser('traincert',$myID,$user_id);
			//	$inductactions[$myID] = inductToggles::getInductActionForUserByArea('traincert',$myID,$user_id);				
			//}
			//dump_array($course);
		//exit;
		//	if(!array_key_exists($myID, $inductactions2)) {
			//	inductToggles::createRandUForUser('trainack',$myID,$user_id);
			//	$inductactions2[$myID] = inductToggles::getInductActionForUserByArea('trainack',$myID,$user_id);
		//	}
			
			if($inductData['prereq_depth'] >= 1) {
				if(!empty($course['prerequisite'])){
					$prereqs = array_merge($prereqs,explode(',',$course['prerequisite']));
				}
				$completed[$myID] = $i;
			}
			
			$data[$myID] = array_merge(
				array(
					'ID'=>$myID
					,'Certified'=>( strtotime($inductactions[$myID]['doneDate']) > strtotime('1980-01-01') )
					,'Acknowledged'=>( strtotime($inductactions2[$myID]['doneDate']) > strtotime('1980-01-01') )
					,'recordType'=>'Training Course'
					,'actionData'=>$inductactions2[$myID]
				)
				,$course
			);
			
		}
		if($inductData['prereq_check'] == 'TRUE') {
			if($inductData['prereq_depth'] >= 1) {
				//var_dump($prereqs);
				// now loop back through the data to take care of pre-requisites for courses
				for($prereqdepth=0;$prereqdepth<$inductData['prereq_depth'];$prereqdepth++) {
					$prereqs = array_unique($prereqs);
					$newprereqs = array();
					foreach($prereqs as $offset=>$prereqID) {
						//echo $prereqID."<br>";
						if( (!array_key_exists($prereqID, $completed)) && (!empty($prereqID)) ) {
							$newprereqs[$id] = $prereq; // assign
							$trainingdata[(int)($courses[$prereqID])]['buID'] = 'PREREQUISITE';

							//
							// setup action records for users
							//
							if(!array_key_exists($prereqID, $inductactions)) {
								inductToggles::createRandUForUser('traincert',$prereqID,$user_id);
								$inductactions[$prereqID] = inductToggles::getInductActionForUserByArea('traincert',$prereqID,$user_id);
							}

							if(!array_key_exists($prereqID, $inductactions2)) {
								inductToggles::createRandUForUser('trainack',$prereqID,$user_id);
								$inductactions2[$prereqID] = inductToggles::getInductActionForUserByArea('trainack',$prereqID,$user_id);
							}

							$data[$prereqID] = array_merge(
								array(
									'ID'=>$prereqID
									,'Certified'=>( strtotime($inductactions[$prereqID]['doneDate']) > strtotime('1980-01-01') )
									,'Acknowledged'=>( strtotime($inductactions2[$prereqID]['doneDate']) > strtotime('1980-01-01') )
									,'recordType'=>'Training Course'
									,'actionData'=>$inductactions[$prereqID]
								)
								,$trainingdata[(int)($courses[$prereqID])]
							);
							$myPrereqs = $trainingdata[(int)($courses[$prereqID])]['prerequisite'];
							if(!empty($myPrereqs)){
								$newprereqs = array_merge($newprereqs,explode(',',$myPrereqs));
							}
						} else { continue; }
					}
					$prereqs = array_merge($newprereqs,array()); // prereqs becomes a copy of $newprereqs (so the list should regenerate per iteration)
					//var_dump($prereqs);
				}
				//var_dump($data);
			}
		}
		return $data;
	}
	
	public function getCourseAckData($done=true,$notdone=true,$user=null) {
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		$user_id = ((int)$user >= 1) ? $user : Session::getSessionField('SESS_USER_REC_ID');
		$objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
		$trainingdata = $objTrainingCourse->displayItems(); // FROM record_manage_course.php $var name changed from $dataTrainingCourse
		$participantCourseInfo = self::getParticipantClassification($user_id); // we have set this to always use the current user ID but it supports getting the classification for an arbitrary participant
		// as we have two sets of actions for induct training, lets get both
		
		$inductactions = array();
		foreach( inductToggles::getInductActionsForUserByArea('trainack',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions[$objID] = $result;
		}
		
		if($inductData['prereq_depth'] >= 1) {
			$courses = array();
			$prereqs = array();
			$completed = array();
		}
		
		$data = array();
		foreach($trainingdata as $i=>$course) {
			$myID = $course["cID"];
			if($inductData['prereq_depth'] >= 1) {
				$courses[$myID] = $i; // we use this for dealing with prerequisites
			}
			if( ((int)$inductactions[$myID]['approveAU'] > 0) && $done === false){ continue; } //if we dont want to show done
			if( ((int)$inductactions[$myID]['approveAU'] < 1) && $notdone === false ){ continue; } // if we dont want to show not done
/*
			if( ($inductactions[$myID]['doneDate'] > '1980-01-01') && $done === false){ continue; } //if we dont want to show done
			if( ($inductactions[$myID]['doneDate'] <= '1980-01-01') && $notdone === false ){ continue; } // if we dont want to show not done
 */
			if( ( ($participantCourseInfo & $course['course_classification_enum']) == courseClassificationEnums::NONE ) && ($course['course_classification_enum'] != courseClassificationEnums::CORE) ){ continue; } // if the course is not a match for any of the participant classifications
			
			//
			// past this point everything should be valid for the user_id provided
			//
			 
			//
			// setup action records for users
			//
			if(!array_key_exists($myID, $inductactions)) {
				inductToggles::createRandUForUser('trainack',$myID,$user_id);
				$inductactions[$myID] = inductToggles::getInductActionForUserByArea('trainack',$myID,$user_id);				
			}
						
			if($inductData['prereq_depth'] >= 1) {
				if(!empty($course['prerequisite'])){
					$prereqs = array_merge($prereqs,explode(',',$course['prerequisite']));
				}
				$completed[$myID] = $i;
			}
			
			$data[$myID] = array_merge(
				array(
					'ID'=>$myID
					,'dueDate'=>$inductactions[$myID]['dueDate']
					,'doneDate'=>$inductactions[$myID]['doneDate']
					,'recordType'=>'Training Course (Request)'
					,'actionData'=>$inductactions[$myID]
				)
				,$course
			);
			
		}
		if($inductData['prereq_check'] == 'TRUE') {
			if($inductData['prereq_depth'] >= 1) {
				//var_dump($prereqs);
				// now loop back through the data to take care of pre-requisites for courses
				for($prereqdepth=0;$prereqdepth<$inductData['prereq_depth'];$prereqdepth++) {
					$prereqs = array_unique($prereqs);
					$newprereqs = array();
					foreach($prereqs as $offset=>$prereqID) {
						//echo $prereqID."<br>";
						if( (!array_key_exists($prereqID, $completed)) && (!empty($prereqID)) ) {
							$newprereqs[$id] = $prereq; // assign
							$trainingdata[(int)($courses[$prereqID])]['buID'] = 'PREREQUISITE';

							//
							// setup action records for users
							//

							if(!array_key_exists($prereqID, $inductactions)) {
								inductToggles::createRandUForUser('trainack',$prereqID,$user_id);
								$inductactions[$prereqID] = inductToggles::getInductActionForUserByArea('trainack',$prereqID,$user_id);
							}

							$data[$prereqID] = array_merge(
								array(
									'ID'=>$prereqID
									,'dueDate'=>$inductactions[$prereqID]['dueDate']
									,'doneDate'=>$inductactions[$prereqID]['doneDate']
									,'recordType'=>'Training Course (Request)'
									,'actionData'=>$inductactions[$prereqID]
								)
								,$trainingdata[(int)($courses[$prereqID])]
							);
							$myPrereqs = $trainingdata[(int)($courses[$prereqID])]['prerequisite'];
							if(!empty($myPrereqs)){
								$newprereqs = array_merge($newprereqs,explode(',',$myPrereqs));
							}
						} else { continue; }
					}
					$prereqs = array_merge($newprereqs,array()); // prereqs becomes a copy of $newprereqs (so the list should regenerate per iteration)
					//var_dump($prereqs);
				}
				//var_dump($data);
			}
		}
		return $data;
	}
	
	public function getCourseComData($done=true,$notdone=true,$user=null) {
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		$user_id = ((int)$user >= 1) ? $user : Session::getSessionField('SESS_USER_REC_ID');
		$objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
		$trainingdata = $objTrainingCourse->displayItems(); // FROM record_manage_course.php $var name changed from $dataTrainingCourse
		$participantCourseInfo = self::getParticipantClassification($user_id); // we have set this to always use the current user ID but it supports getting the classification for an arbitrary participant
		// as we have two sets of actions for induct training, lets get both
		
		$inductactions = array();
		foreach( inductToggles::getInductActionsForUserByArea('traincert',$user_id) as $result ) {
			$objID = (int)end( explode(':|:',$result['actionDescription']) );
			$inductactions[$objID] = $result;
		}
		
		if($inductData['prereq_depth'] >= 1) {
			$courses = array();
			$prereqs = array();
			$completed = array();
		}
		
		$data = array();
		foreach($trainingdata as $i=>$course) {
			$myID = $course["cID"];
			if($inductData['prereq_depth'] >= 1) {
				$courses[$myID] = $i; // we use this for dealing with prerequisites
			}
			if( ((int)$inductactions[$myID]['approveAU'] > 0) && $done === false){ continue; } //if we dont want to show done
			if( ((int)$inductactions[$myID]['approveAU'] < 1) && $notdone === false ){ continue; } // if we dont want to show not done
/*
			if( ($inductactions[$myID]['doneDate'] > '1980-01-01') && $done === false){ continue; } //if we dont want to show done
			if( ($inductactions[$myID]['doneDate'] <= '1980-01-01') && $notdone === false ){ continue; } // if we dont want to show not done
 */
			if( ( ($participantCourseInfo & $course['course_classification_enum']) == courseClassificationEnums::NONE ) && ($course['course_classification_enum'] != courseClassificationEnums::CORE) ){ continue; } // if the course is not a match for any of the participant classifications
			
			//
			// past this point everything should be valid for the user_id provided
			//
			 
			//
			// setup action records for users
			//
			if(!array_key_exists($myID, $inductactions)) {
				inductToggles::createRandUForUser('traincert',$myID,$user_id);
				$inductactions[$myID] = inductToggles::getInductActionForUserByArea('traincert',$myID,$user_id);				
			}
						
			if($inductData['prereq_depth'] >= 1) {
				if(!empty($course['prerequisite'])){
					$prereqs = array_merge($prereqs,explode(',',$course['prerequisite']));
				}
				$completed[$myID] = $i;
			}
			
			$data[$myID] = array_merge(
				array(
					'ID'=>$myID
					,'dueDate'=>$inductactions[$myID]['dueDate']
					,'doneDate'=>$inductactions[$myID]['doneDate']
					,'recordType'=>'Training Course (Completed)'
					,'actionData'=>$inductactions[$myID]
				)
				,$course
			);
		}
		if($inductData['prereq_check'] == 'TRUE') {
			if($inductData['prereq_depth'] >= 1) {
				//var_dump($prereqs);
				// now loop back through the data to take care of pre-requisites for courses
				for($prereqdepth=0;$prereqdepth<$inductData['prereq_depth'];$prereqdepth++) {
					$prereqs = array_unique($prereqs);
					$newprereqs = array();
					foreach($prereqs as $offset=>$prereqID) {
						//echo $prereqID."<br>";
						if( (!array_key_exists($prereqID, $completed)) && (!empty($prereqID)) ) {
							$newprereqs[$id] = $prereq; // assign
							$trainingdata[(int)($courses[$prereqID])]['buID'] = 'PREREQUISITE';

							//
							// setup action records for users
							//

							if(!array_key_exists($prereqID, $inductactions)) {
								inductToggles::createRandUForUser('traincert',$prereqID,$user_id);
								$inductactions[$prereqID] = inductToggles::getInductActionForUserByArea('traincert',$prereqID,$user_id);
							}

							$data[$prereqID] = array_merge(
								array(
									'ID'=>$prereqID
									,'dueDate'=>$inductactions[$prereqID]['dueDate']
									,'doneDate'=>$inductactions[$prereqID]['doneDate']
									,'recordType'=>'Training Course (Completed)'
									,'actionData'=>$inductactions[$prereqID]
								)
								,$trainingdata[(int)($courses[$prereqID])]
							);
							$myPrereqs = $trainingdata[(int)($courses[$prereqID])]['prerequisite'];
							if(!empty($myPrereqs)){
								$newprereqs = array_merge($newprereqs,explode(',',$myPrereqs));
							}
						} else { continue; }
					}
					$prereqs = array_merge($newprereqs,array()); // prereqs becomes a copy of $newprereqs (so the list should regenerate per iteration)
					//var_dump($prereqs);
				}
				//var_dump($data);
			}
		}
		return $data;
	}
	
	public static function getParticipantClassification($participant=null) {
		$user_id = 0;
		if($participant !== null) {
			$user_id = $participant;
		} else {
			$user_id = Session::getSessionField('SESS_USER_REC_ID');
		}
		$dbHand = DB::connect(_DB_TYPE);
		$stmt = $dbHand->prepare( 
				sprintf(
						"SELECT 
							participant_cassification_enum ,induction_course_id 
						FROM 
							%s.participant_meta_data 
						WHERE 
							participantID = %d",
						_DB_OBJ_FULL, $user_id
				) 
		);
		$stmt->execute();

		// below is a lazy mans PDO if the result set is empty
		$out = array(
			array(
				'participant_cassification_enum'=>0
				,'induction_course_id'=>0
			)
		);
		if($stmt->errorCode() == 0) {
			$out =  $stmt->fetchAll(PDO::FETCH_ASSOC);
		}/* else {
			var_dump($stmt->errorInfo());
		}*/
		return $out;
	}
	
	public static function getParticipantBuID($participant=null) {
		$user_id = 0;
		if($participant !== null) {
			$user_id = $participant;
		} else {
			$user_id = Session::getSessionField('SESS_USER_REC_ID');
		}
		$dbHand = DB::connect(_DB_TYPE);
		$myBuID = 0;
		
		// get curent buID
		$stmt = $dbHand->prepare(
			sprintf(
				" SELECT reportToBuID FROM %s.participant_meta_data WHERE participantID = %d "
				,_DB_OBJ_FULL
				,(int)$user_id
			)
		);
		$stmt->execute();
		if($stmt->errorCode() == 0) {
			$myBuID = (int)current($stmt->fetch(PDO::FETCH_ASSOC));
		}/* else {
			var_dump($stmt->errorInfo());
		}*/
		return $myBuID;
	}
	
	public static function getParticipantData($participant=null) {
		$user_id = 0;
		if($participant !== null) {
			$user_id = $participant;
		} else {
			$user_id = Session::getSessionField('SESS_USER_REC_ID');
		}
		$dbHand = DB::connect(_DB_TYPE);
		$myBuID = 0;
		
		// get curent buID
		$stmt = $dbHand->prepare(
			sprintf(
				" SELECT PM.* FROM %s.participant_database P LEFT JOIN %s.participant_meta_data PM ON P.participantID = PM.participantID WHERE P.participantID = %d "
				,_DB_OBJ_FULL
				,_DB_OBJ_FULL
				,(int)$user_id
			)
		);
		$stmt->execute();
		if($stmt->errorCode() == 0) {
			$myData = $stmt->fetch(PDO::FETCH_ASSOC);
		} else {
			var_dump($stmt->errorInfo());
		}
		return $myData;
	}
	
}