<?php

/*
 * CORE INCLUDES
 */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/functions.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/Db.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/Session.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/Action.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/Documents.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/ProcessFlowMaster.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/Setup.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/TrainingCourseSetup.class.php';
// CODESIGN2 ADD-ONS
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';

/*
 error_reporting(E_ALL);
 ini_set('display_errors', 'On');
 ini_set('html_errors', 'On');
 */
class inductToggles {
	
	const NEED_TRAIN = 'Training request for course ';
	const CERT_REQ = 'Training complete for course ';
    /*
     * This is a SMART-INDUCT Method designed to retrieve a specific action for a 
     * user (we use these for R&U) for the docs, process flows and process risk
     * area is nesecarry to ensure that R&U for Process-Flows do not spill over to
     * Process-Risk or Documents or Vica Versa
     */
    public static function getInductActionForUserByArea($area,$rsrcID,$user_id=null) {
		$rsrc_len = strlen($rsrcID."");
        $area_len = strlen($area."");
        //echo "Area Length: ".$area_len.", $area<br>";
        //echo "RSRC Length: ".$rsrc_len.", $rsrcID<br>";
        if($user_id == null) { // We may wish to provision for participants of certain 
                               // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }
        $dbHand = DB::connect(_DB_TYPE);

        // AS WE STORE THE ID OF THE ELEMENT REFERENCED SERIALIZED BY DELIMITER :|: 
        // IN THE ARRAY, WE NEED TO RETRIEVE THE PORTION OF THE STRING THAT CONTAINS 
        // THE RESOURCE ID.
        $sql = sprintf(
            " SELECT ID, moduleName , actionDescription , who , whoAU , thirdParty, ".
            "dueDate , approve , outstanding , status , approveAU, doneDate ".
            " FROM %s.actions WHERE moduleName = 'INDUCT' ".
            " AND thirdParty = %d ".
            " AND ( LEFT( CAST(actionDescription as varchar(250) ), %d ) = '%s' ".
            " AND RIGHT( CAST(actionDescription as varchar(250) ), %d ) = '%d' ) "
            ,_DB_OBJ_FULL
            ,$user_id
            ,$area_len
            ,$area
            ,$rsrc_len
            ,$rsrcID
        );
        //echo $sql."<br>";
        $stmt = $dbHand->prepare( $sql );
        $stmt->execute();

        if($stmt->errorCode() == 0) {
            $ret = $stmt->fetchAll(PDO::FETCH_ASSOC);
            //echo "<pre>".var_export($ret,true)."</pre>";
            return $ret;
        } else {
            //echo "<pre>Error!\r\n".var_export($stmt->errorInfo(),true)."</pre>";
            return array();
        }
    }

    /*
     * This is a SMART-INDUCT Method designed to retrieve all actions for a given 
     * user (we use these for R&U) for the docs, process flows and process risk
     */
    public static function getInductActionsForUserByArea($area,$user_id=null) {
		$area_len = strlen($area."");
        if($user_id == null) { // We may wish to provision for participants of certain 
                               // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }
        $dbHand = DB::connect(_DB_TYPE);

        // AS WE STORE THE ID OF THE ELEMENT REFERENCED SERIALIZED BY DELIMITER :|: 
        // IN THE ARRAY, WE NEED TO RETRIEVE THE PORTION OF THE STRING THAT CONTAINS 
        // THE RESOURCE ID.
        $stmt = $dbHand->prepare( 
            sprintf(
                " SELECT ID, moduleName , actionDescription , who , whoAU , thirdParty ".
                ", dueDate , approve , outstanding , doneDescription , status , approveAU , doneDate ".
                " FROM %s.actions WHERE moduleName = 'INDUCT' ".
                " AND thirdParty = %d AND LEFT( CAST(actionDescription as varchar(250) ), %d) = '%s' "
                ,_DB_OBJ_FULL
                ,$user_id
                ,$area_len
                ,$area
            ) 
        );
        $stmt->execute();

        if($stmt->errorCode() == 0) {
			return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            //echo "<pre>Error!\r\n".var_export($stmt->errorInfo(),true)."</pre>";
			return array();
        }
    }


    /*
     * This is a SMART-INDUCT Method designed to update a new RandU record for Docs, PF's and PR's
     */
    public static function setInductRandUForUser($area,$rsrcID,$user_id=null) {
        $rsrc_len = strlen($rsrcID."");
        $area_len = strlen($area."");
        if($user_id == null) { // We may wish to provision for participants of certain 
                               // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }

        // now lets check for existing
        $results = self::getInductActionForUserByArea($area,$rsrcID,$user_id);

        $acDBid = 0; // needed to store actions dbid
        $acDesc = '';
        // if not we create
        if( count($results) <= 0) { // some db systems return 0 & some return -1
            $acDBid = self::createRandUForUser($area,$rsrcID,$user_id); // returned on create
            $results = self::getInductActionForUserByArea($area,$rsrcID,$user_id);
        } else { $acDBid = (int)$results[0]['ID']; }
		$defaultDate = date('m/d/Y');
		//	,$aApprove=false,$auApprove
		$date1 = $results[0]['doneDate'];
		$date = ( (!in_array($date1,array('1900-01-01','1970-01-01','NULL'))) && ($date1 != NULL) ) ? '01/01/1970' : $defaultDate;
        // now we set RandU

        // create temporary action object
        $actionTMP = new Action();

		$dueDateNow = $results[0]['dueDate'];
		if(strtotime($dueDateNow))
		if( ( $dueDateNow == "1970-01-01") || ( $dueDateNow == "1900-01-01") ) {
			$dueDateNow = DateTime::createFromFormat( 'd/m/Y', date('d/m/Y') )->add( new DateInterval('P'.((int)self::getUserInductionDays($user_id)).'D') )->format('m/d/Y');//'01/01/1900'
		}

		//get TCM
		$authObj = SetupGeneric::useModule('AuthorizedUser');
		// $authObj->setItemInfo(array('id'=>$user_id,'authorization'=>$permissions,'section'=>$modules));
		// $authObj->editItem();
		$tcm_id = $authObj->getIssuerPermission('perm_mgr_train');
		
		$action_id = $results[0]['ID'];
		//echo $date;
		//var_dump($results[0]['approve']);
		if( (intval($results[0]['approve']) < 1) && (intval($results[0]['approveAU']) < 1) ) {
			// update action
			$actionData = array(
				'description'=>$results[0]['actionDescription']
				,'who'=>$tcm_id
				,'done_date'=>$date
				,'due_date'=>$dueDateNow
				,'outstanding'=>($results['doneDate'] == '01/01/1970' ? 1 : 0)// very important can only be set on update (we modified code to add this & outstanding)
			);
			$actionTMP->setActionDetails((int)$acDBid, $actionData);
			$action_id = $actionTMP->updateActionWithDoneOutstanding();
			$actionTMP->setThirdParty($user_id); // Participant goes here
		}

		if(!in_array($area,array('pf','pr','doc','docs') ) ) {
			usleep(1000);
			$cancelRaised = (($date == '01/01/1970') ? 'Cancelled' : 'Raised');
			//send e-mail
			$emailObj = new inductActionEmailHelper($action_id);

			$who = $emailObj->getWhoDetails();
			$tp = $emailObj->getTPDetails();
			$au = $emailObj->getAUDetails();

			// AU
			if($au != array('displayname'=>' ','email'=>'') ) {
				$emailObj->sendEmail('Action '.$cancelRaised.' [AU]',$au,array(),array(),'other_pending');
			}
			// TP
			if($tp != array('displayname'=>' ','email'=>'') ) {
				$emailObj->sendEmail('Action '.$cancelRaised.' [Participant]',$tp,array(),array(),'other_pending');
			}
			// Who
			if($who != array('displayname'=>' ','email'=>'') ) {
				$emailObj->sendEmail('Action '.$cancelRaised.' [TM]',$who,array(),array(),'me_pending');
			}
		}
        return $action_id;
    }

    /*
     * This is a SMART-INDUCT Method designed to create a new RandU record for Docs, PF's and PR's
     */
    public static function createRandUForUser($area,$rsrcID,$user_id=null) {
        $rsrc_len = strlen($rsrcID."");
        $area_len = strlen($area."");

        $descStr = self::genItemDescStr($area,$rsrcID);
		if($descStr == "") { //empty description is invalid
            errorOut("This is an invalid $area object");
        }
        $actionDesc = "$area:|:$descStr:|:$rsrcID";

        if($user_id == null) { // We may wish to provision for participants of certain 
                             // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }
		$dateDue = DateTime::createFromFormat( 'd/m/Y', date('d/m/Y') )->add( new DateInterval('P'.((int)self::getUserInductionDays($user_id)).'D') )->format('m/d/Y');
        //echo "dateDue = $dateDue";
		
		$authObj = SetupGeneric::useModule('AuthorizedUser');
		// $authObj->setItemInfo(array('id'=>$user_id,'authorization'=>$permissions,'section'=>$modules));
		// $authObj->editItem();
		$tcm_id = $authObj->getIssuerPermission('perm_mgr_train');
		
		// create temporary action object
        $actionTMP = new Action();
        $actionData = array(
            'module_name'=>'INDUCT'
            ,'description'=>$actionDesc
            ,'who'=>$tcm_id // actually this is known in smart as a Participant
			,'whoAU'=>$tcm_id // this is the authorised user
            ,'due_date'=>$dateDue//'01/01/1900'
        );
        $actionTMP->setActionDetails(0,$actionData);
        $action_id = $actionTMP->addAction(/* true */); //Physical Act of Adding an Action
		//echo 'User ID:'.$user_id;
		//$actionTMP->setActionDetails($action_id,$actionData);
		$actionTMP->setThirdParty($user_id); // Participant goes here
        return $action_id;
    }

    /*
     * Generates a description of the resource using the area
     */
    public static function genItemDescStr($area,$rsrcID) {

        $descStr = '';
        //echo $area." Generating Item Desc... for PF ".$rsrcID;
        switch($area) {
            case 'pf':
                $objProcessMaster = new ProcessFlowMaster();
                $res = $objProcessMaster->displayProcessFlowById((int)$rsrcID);
                $descStr = compact_ra_description($res['description'],30);
                // echo var_dump($res);
            break;
            case 'pr':
                // the above may be put into process risk as displayProcessRiskById($id) // Bob to confirm
                $dbHand = DB::connect(_DB_TYPE);
                    $sql = sprintf(
                        " SELECT S.*,B.buName FROM %s.swimlane S ".
                        " INNER JOIN %s.business_units B ".
                        " ON S.buID = B.buID ".
                        " WHERE S.swimID = %d ". 
                        " ORDER BY S.swimID DESC "
                        ,_DB_OBJ_FULL
                        ,_DB_OBJ_FULL
                        ,(int)$rsrcID
                    );

                    $pStatement = $dbHand->prepare($sql);
                    $pStatement->execute();
                    $res = $pStatement->fetchAll(PDO::FETCH_ASSOC); // would be return not $res = for func

                $descStr = compact_ra_description($res[0]['description'],30);
            break;
            case 'doc':
                // Note this is the cmsDocID not the documentID for rsrc
                $sql12 = sprintf("
SELECT 
	fileID,
	D.title+' '+CAST(D.description as VARCHAR) as 'Title',
	D.buID,
	documentType,
	fileReference,
	usrFilename,
	sysFilename,
	mimeType,
	0 As 'isCCP'
	FROM %s.cms_documents D
		INNER JOIN %s.business_units B
		ON D.buID = B.buID
		INNER JOIN %s.uploaded_files U
		ON D.documentID = U.fileID
	WHERE isArchive = 0
	AND fileID = %d
	
UNION 

SELECT 
	fileID,
	'' AS 'Title',
	buID,
	'' AS 'documentType',
	'' AS 'fileReference',
	usrFilename,
	sysFilename,
	mimeType,
	1 As 'isCCP'
	FROM %s.[swimlane_documents] SDocs
		LEFT JOIN %s.[swimlane_data] SData
		ON SDocs.swimID = SData.swimID
		LEFT JOIN %s.[uploaded_files] UF
		ON documentID = fileID
	WHERE documentID > 0
	AND fileID = %d",
			_DB_OBJ_FULL,
			_DB_OBJ_FULL,
			_DB_OBJ_FULL,
			$rsrcID,
			_DB_OBJ_FULL,
			_DB_OBJ_FULL,
			_DB_OBJ_FULL,
			$rsrcID
		);
		$dbHand = DB::connect(_DB_TYPE);
		$pStatement12 = $dbHand->prepare($sql12);
		$pStatement12->execute();
		$DocData = $pStatement12->fetch(PDO::FETCH_ASSOC);
				//$objDoc = new Documents();
                //$DocData = $objDoc ->getDocumentInformation($rsrcID);
		$descStr =  ($DocData['title'] == "") ? $DocData['fileID'].' '.current(explode(".",$DocData['usrFilename'])) : $DocData['title'];
                // var_dump($DocData);
            break;
			case 'trainack':
			case 'traincert':
				$trngObj = SetupGeneric::useModule('TrainingCourse');
				$trngObj->setItemInfo(array('id'=>$rsrcID));
				$courseData = $trngObj->displayItemById();
				$descStr = (($area == 'trainack') ? self::NEED_TRAIN : self::CERT_REQ );
				$descStr .= $courseData['title'];
			break;
        }
        // echo $descStr; //debugging only
        return $descStr;
    }
	
	/*
	 * Gets the days that a participant has to complete induction
	 */
	public static function getUserInductionDays($user_id = 0) {
		
		$eqObj = SetupGeneric::useModule('Induct');
		$inductData = $eqObj->displayItems();
		
		$out = $inductData['min_days']; //smartInductSettings::MIN_INDUCTION_DAYS;
		// ensure that we have a valid user
		if($user_id < 1) { $user_id = Session::getSessionField('SESS_USER_REC_ID'); }
		
		$dbHand = DB::connect(_DB_TYPE);
		
		$sql = "SELECT * FROM %s.participant_database D
				INNER JOIN
					%s.participant_meta_data M
				ON
					D.participantID = M.participantID
				WHERE
					D.participantID = %d";
		
		$pStatement = $dbHand->prepare(sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,$user_id));
		$pStatement->execute();
		$res = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		if(isset($res[0]['induction_period'])){
			$out = ( ($res[0]['induction_period'] > $inductData['min_days'] /* smartInductSettings::MIN_INDUCTION_DAYS */) ? $res[0]['induction_period'] : $inductData['min_days'] /* smartInductSettings::MIN_INDUCTION_DAYS */);
		}
		return $out;
	}
	public static function markCompleteActionTracker($actionID,$date,$desc) {
		$dbHand = DB::connect(_DB_TYPE);

		$sql = sprintf(
			" UPDATE %s.actions
			SET doneDate = '%s',
			doneDescription = '%s'
			WHERE ID = %d ",
			_DB_OBJ_FULL,
			$date,
			$desc,
			$actionID
		);
		
		$pStatement = $dbHand->prepare( $sql );
		$pStatement->execute();
		//echo $sql;
		
		if(!in_array($area,array('pf','pr','doc','docs') ) ) {
			usleep(1000);
			$cancelRaised = 'Completed';
			//send e-mail
			$emailObj = new inductActionEmailHelper($actionID);

			$who = $emailObj->getWhoDetails();
			$tp = $emailObj->getTPDetails();
			$au = $emailObj->getAUDetails();

			// AU
			if($au != array('displayname'=>' ','email'=>'') ) {
				$emailObj->sendEmail('Action '.$cancelRaised.' [AU]',$au,array(),array(),'other_pending');
			}
			// TP
			if($tp != array('displayname'=>' ','email'=>'') ) {
				$emailObj->sendEmail('Action '.$cancelRaised.' [Participant]',$tp,array(),array(),'other_pending');
			}
			// Who
			if($who != array('displayname'=>' ','email'=>'') ) {
				$emailObj->sendEmail('Action '.$cancelRaised.' [TM]',$who,array(),array(),'me_pending');
			}
		}
		return ($pStatement->errorCode() == 0);
	}
	
	public static function authActionTracker($actionID,$aApprove=false,$auApprove=false) {
		$dbHand = DB::connect(_DB_TYPE);

		$sql = sprintf(
			" UPDATE %s.actions
			SET approve = %s,
			approveAU = %s
			WHERE ID = %d ",
			_DB_OBJ_FULL,
			( ($aApprove) ? 1 : 0 ),
			( ($auApprove) ? 1 : 0 ),
			$actionID
		);
		
		$pStatement = $dbHand->prepare( $sql );
		$pStatement->execute();
		//echo $sql;
		return ($pStatement->errorCode() == 0);
	}
}

/*
$dt = DateTime::createFromFormat( 'Y-m-d', date('Y-m-d') )->add( new DateInterval('P'.self::getUserInductionDays($user_id).'D') )->format('Y-m-d');
        
		// create temporary action object
        $actionTMP = new Action();
        $actionData = array(
            'module_name'=>'INDUCT'
            ,'description'=>$actionDesc
            ,'who'=>$user_id // actually this is known in smart as a Participant
            ,'due_date'=>$dt->format('Y-m-d')
        );
        $actionTMP->setActionDetails(0,$actionData);
        $action_id = $actionTMP->addAction(); //Physical Act of Adding an Action
        return $action_id;
    }

	
*/