<?php

/*
 * Class used to store course Classification Constants, possibly to be relocated 
 * to constants.php and have all current constants prefixed with COURSE_CLASS_
 */
require_once realpath(dirname(__FILE__)).'/../../courseClassificationEnums.const.php';
class smartInductSettings {
	const CCP_CHECK = true;
	const KEY_PROCESS_CHECK = true;
	const CORE_PROCESS_CHECK = false;
	const BU_FILTER_JS = false;
	const SUB_BU_FILTER_JS = false;
	const SUB_BU_FILTER_PHP = false;
	const GET_PREREQS = true;
	const PREREQ_DEPTH = 5;
	const MIN_INDUCTION_DAYS = 5;
	const ADDITIONAL_FILTERS = "CCP|KEY|CORE|PREREQUISITE"; /* STILL REQUIRES INDIVIDUAL CCP_CHECK, KEY_PROCESS_CHECK & CORE_PROCESS_CHECK TO BE TRUE */
}