<?php
 /**
  $Id: Equipment.class.php,v 3.16 Monday, January 17, 2011 1:46:11 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, December 17, 2010 4:27:41 PM>
  */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';
class Asset {

	/*
	 * property to hold database object
	 *
	 * access private
	*/
	private $dbHand;

	/*
	 * property to hold equipment id
	 *
	 * @access private
	*/
	private $assetId;

	/*
	 * property to hold equipment info
	*/
	private $assetInfo;
	private $lastRecordId;

	public function __construct() {

		$this->dbHand	= DB::connect(_DB_TYPE);
	}

	public function setAssetInfo( $asset_id, $asset_info ) {

		$this->assetId		= $asset_id;
		$this->assetInfo	= $asset_info;
	}

        public function addAsset() {

			$sql = "INSERT INTO %s.assestMangement
				(assest_c,assest_t,descp,loc,flag_v,ref,model,manufacturer,descriptionlink,owner,custodian,maintenance,calibration ,item_req,is_class,class)
				VALUES (%d, %d, '%s',%d,'%s', '%s', %d, %d, %d, %d, %d, %d, %d, %d,  '%s',%d)";

			$psql = sprintf($sql,_DB_OBJ_FULL,
                                $this->assetInfo['asset_g'],
                                $this->assetInfo['asset_t'],
                                $this->assetInfo['description'],
                                $this->assetInfo['location'],
                                $this->assetInfo['flag'],
                                $this->assetInfo['ref'],
                                $this->assetInfo['asset_mod'],
                                $this->assetInfo['asset_m'],
                                $this->assetInfo['asset_d'],
                                $this->assetInfo['who'],
                                $this->assetInfo['custodian'],
                                $this->assetInfo['maintenance_req'],
                                $this->assetInfo['calib_req'],
                                $this->assetInfo['item_req'],
                                $this->assetInfo['is_class'],
                                $this->assetInfo['asset_c']);
                           
 			$stmt = $this->dbHand->prepare($psql);

			$queryExecute = $stmt->execute();

	}
        
             public function editAsset() {

			$sql = "update %s.assestMangement set assest_c=%d,assest_t=%d,descp='%s',loc=%d,flag_v='%s',model=%d,manufacturer=%d,descriptionlink=%d,owner=%d,custodian=%d,maintenance=%d,calibration=%d ,item_req=%d,is_class='%s',class=%d where id=%d";


		$psql = sprintf($sql,_DB_OBJ_FULL,
                                $this->assetInfo['asset_g'],
                                $this->assetInfo['asset_t'],
                                $this->assetInfo['description'],
                                $this->assetInfo['location'],
                                $this->assetInfo['flag'],
                                $this->assetInfo['asset_mod'],
                                $this->assetInfo['asset_m'],
                                $this->assetInfo['asset_d'],
                                $this->assetInfo['who'],
                                $this->assetInfo['custodian'],
                                $this->assetInfo['maintenance_req'],
                                $this->assetInfo['calib_req'],
                                $this->assetInfo['item_req'],
                                $this->assetInfo['is_class'],
                                $this->assetInfo['asset_c'],
                                $this->assetId);
                       
 			$stmt = $this->dbHand->prepare($psql);

			$queryExecute = $stmt->execute();

	}
        
        	public function displayItemById() {

		$sql = "SELECT * FROM %s.assestMangement WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->assetId);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
        
	public function displayAsset() {

		$sql = sprintf("SELECT * FROM %s.assest_primary_classification",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
	public function getLastInsertedId() {
		return $this->lastRecordId;
	}

	
        public function displayItemsIndex($sort='ORDER BY ID DESC',$search='') {

                if ($this->vars['archive']) {
			$sql = sprintf("SELECT M.*,P.primaryAssest,L.name FROM %s.assestMangement M inner join %s.assest_Primary_classification P on M.assest_c=P.ID inner join %s.locationgram L on M.loc=L.locID WHERE M.archive =  1 %s %s",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$search,$sort);
		} else {
			$sql = sprintf("SELECT M.*,P.primaryAssest,L.name FROM %s.assestMangement M inner join %s.assest_Primary_classification P on M.assest_c=P.ID inner join %s.locationgram L on M.loc=L.locID  WHERE isNull(M.archive,0) = 0 %s %s",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$search,$sort);
		}
  
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
        
                public function displayEquipItems() {

 
		$sql = "SELECT * FROM %s.assestmangement WHERE assest_t = %d  and item_req=1 AND isnull(archive,0) = 0 ";
                
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->assetId);
		$stmt = $this->dbHand->prepare($psql);
		
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $result;
	}
        
        
    public function getTypeAssets() {
        $sql = sprintf("SELECT * FROM %s.asset_type where isnull(archive,0)=0 order by cast(name as varchar(200))", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getMaterialAssets($p_loc) {
        $sql = sprintf("SELECT * FROM %s.assestMangement where item_req=1 and loc=%d order by cast(descp as varchar(200))", _DB_OBJ_FULL, $p_loc);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $data) {
            $id = $data["assest_t"];
           
                $retArray[$id][] = $data;
           
        }

        return $retArray;
    }
    
    		public function getMainteance() {

		$sql = "SELECT * FROM %s.mainteance_data";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$records = array();

		if ( count($result) ) {
			foreach ( $result as $result_ele ) {
				$records[$result_ele['ID']] = $result_ele;
			}
		}

		return $records;

	}
	
        		public function getCalibration() {

		$sql = "SELECT * FROM %s.calibration_data";
		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$records = array();

		if ( count($result) ) {
			foreach ( $result as $result_ele ) {
				$records[$result_ele['ID']] = $result_ele;
			}
		}

		return $records;

	}
        
			public function getMainteance1($id) {
			$this->id = $id;
		$sql = "SELECT * FROM %s.mainteance_data WHERE ID = ".$this->id;
		$psql = sprintf($sql,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		$records = array();

		if ( count($result) ) {
			foreach ( $result as $result_ele ) {
				$records[$result_ele['ID']] = $result_ele;
			}
		}

		return $result;

	}
        
        	public function displayMaintCalData() {


			$sql = "SELECT * FROM %s.maintenance_calibration_data WHERE equipId = %d AND jobType = '%s'";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->assetInfo['equip_id'],$this->assetInfo['job_type']);



		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
        
        	public function getListingforExport() {

		 $type = $_GET['type'];

		if ( $type  =='assest') {

			return $this->getEquipementExportDataFull();

		} else {

			return $this->getEquipementExportData();
		}
	}
	
	public function getEquipementExportDataFull() {

		$objEquip		= SetupGeneric::useModule('Equipment');
		$objOrg			= SetupGeneric::useModule('Organigram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
                $participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 		= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		//$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		$equipment_data = $this->displayItems1();
        //dump_array($equipment_data);
		
		//exit;
		$heading = array(array('Reference','Group','Category','Type','Manufacturer','Model','Description', 'Location', 'Asset','Asset Link Code','Business Unit','Owner','Custodian','Classification',"Maintenance"," Calibration"));
		
		
	//	if ( count($equipment_data) ) {
					$k = 0;
			foreach ( $equipment_data as $element) {

				$equip_id	= (int) $element['equipID'];

				$objEquip->setItemInfo( array('id'=>$element['assest_c']) );
			    $equip_class_data = $objEquip->displayItemById_c();
			    $type = $objEquip->getEquipmentDetailById22($element['assest_t']);
		
		
				$locObj	= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$element['loc']));
				$location_data = "";
				$location = $locObj->getFUllLocation();
				
				$loc	= SetupGeneric::useModule('Locationgram');
				$bu_id	= (int) $element['loc'];
				$loc->setItemInfo( array('id'=>$bu_id) );
				$loc1 = $loc->displayItemById();
			
				$locObj = SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$bu_id));
				$locdata = $locObj->displayItemById();
		

	$business_unit_arr = explode(",",$locdata['businessUnit']);

	$orgObj	= SetupGeneric::useModule('Organigram');
	$data = $orgObj->getBusinessUnitsforSelectedIds($business_unit_arr);

	if ($data) {
		$i = 0;
		foreach ( $data as $data_ele ) {
	
			$business_unit_list1[$i] = $data_ele['buName'];
			$i++;
		}
	}

        if (!$business_unit_list1 =='')
$business_unit_list = implode(",",$business_unit_list1);

		$bu_id	= (int) $element['bu'];
			$objOrg->setItemInfo( array('id'=>$bu_id) );
			$business_unit_data = $objOrg->displayItemById();

			$bu_name = $business_unit_data['buName'] != '' ? $business_unit_data['buName'] : '-';

				//$result[$k] = array($element['ref'],$equip_class_data['primaryAssest'],"Category","Type",'Manufacturer','Model','Description', $loc1['name'],$element['descp'],$element['flag_v'],$business_unit_list,'Owner','Custodian','Classification',"Maintenance"," Calibration");
				$result[$k] = array($element['ref'],$equip_class_data['primaryAssest'],"","",'','','', $loc1['name'],$element['descp'],$element['flag_v'],$business_unit_list,'','','',format_date($element['maintenanceDueDate']),format_date($element['calibrationDueDate']));
		
                                $k++;
			}

			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		
	}
	public function displayItems1() {

		if ($this->vars['archive']) {
			$sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive = '%s' ORDER BY assest_c ASC",_DB_OBJ_FULL,$this->vars['archive']);
		} else {
			$sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive IS NULL OR archive = 0 ORDER BY assest_c ASC",_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	


}
?>