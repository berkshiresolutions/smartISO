<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

class reviewEmailHelper {
	
	protected $reviewDetails;
	
	protected $who;
    protected $decorate;
	
	public function __construct($reviewID){
		// review
        $this->decorate = array();
		$this->getReviewDetails($reviewID);

		$this->getContactInfo(); // INITIALLY GRAB DATA ON CONTACTS
	}
	
	public function getReviewDetails($reviewID) {
        $reviewTMP = new Contract();
		$reviewTMP->setContractsInfo($reviewID,1,null);
		$this->reviewDetails = $reviewTMP->viewContract();
		
		//dump_array($this->reviewDetails);
		
		
		
	}
	
	public function getContactInfo() {
		$participantObj = SetupGeneric::useModule('Participant');
	
			$participantObj->setItemInfo(array('id'=>$this->reviewDetails['contractManagerID']));
	
			$details = $participantObj->displayItemById();
			$this->who = array(
				'displayname' => ucwords($details['forename'].' '.$details['surname']),
				'email' => $details['emailAddress'],
				'id' => $this->reviewDetails['contractManagerID']
			);
		
		return $this;
	}
	
	public function getWhoDetails() {
		return $this->who;
	}
	public function appendInfo($data) {
            $this->decorate = array_merge($this->decorate,$data);
        }
	public function sendEmail($subject,$to,$cc,$bcc,$tab='me_completed',$emailtext='',$escalation=false) {
		
		switch($escalation) {
			case 'mgmt':
				$colourBg = '#804040';
				$colourTxt = '#FFFFFF';
				break;
			case 'red':
				$colourBg = '#FF0000';
				$colourTxt = '#FFFFFF';
				break;
			case 'blue':
				$colourBg = '#7294BF';
				$colourTxt = '#FFFFFF';
				break;
			case 'yellow':
				$colourBg = '#F4A460';
				$colourTxt = '#111111';
				break;
			default: // GREY
				$colourBg = '#808080';
				$colourTxt = '#FFFFFF';
		}
		$to = array($to);
		$cc = array($cc);
		$bcc = array($bcc);
		$from = array(
			'email'=>'info@smart-iso.com','displayname'=>'smart-ISO System E-Mailer'
		);
		//sendemails($to=array(),$subject=null,$body="",$from=null,$bcc=array(),$cc=array(),$attachmentpaths=array(), $imgpaths=array())
		
		$emailContent = new newEmail(); // JUST THE CONTENT BUILDER
		$emailer = new eMailer('',5); // SET TO RETRY 5 TIMES TO SEND NOLOGO, NO DEBUG
		$twoColData = array(
			'actionid'=>array('left'=>'<strong>Reference:</strong>','right'=>$this->reviewDetails['reference']),
			'assignedto'=>array('left'=>'<strong>Assigned To:</strong>','right'=>$this->who['displayname']),
			'authorizing1'=>array('left'=>'<strong>Contract Provision:</strong>','right'=>$this->reviewDetails['contractName']),
			'due'=>array('left'=>'<strong>Due Date:</strong>','right'=>date('m/d/Y',strtotime($this->reviewDetails['reviewDueDate'])) )
		);
                $stdData = array(
                    'emailColour'=>$colourBg,
                    'emailTxtColour'=>$colourTxt,
                    'emailTitle'=>'Contract Review To Be Completed',
					'sentence'=>'',
                    'singleColData'=>array(
                            'summary'=>'<p><strong>Summary</strong><br>Contract Review</p>',
                            'emailtext'=>'<p>'.$emailtext.'</p>'
                    ),
                    'twoColData'=>$twoColData
                );
				//
				//dump_array($this->decorate);
                foreach($this->decorate as $field=>$values) {
                    if(is_array($stdData[$field])) { // add to lists of data
                        $stdData[$field] = array_merge($stdData[$field],$values);
                    } 
					
					else { // overwrite named values
                        $field = $values;
                    }
                }
				//
				
                $thecontent = $emailContent->display(
                    $stdData       
                );
                $headers = '';
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                $headers .= "Reply-To: info@smart-iso.com\r\n";
                $headers .= "Bcc: bob@smart-iso.com;\r\n";
                $headers .= "";
		//mail ( $to['email'] , $subject , $thecontent, $headers ); 
             //   return $this;
           // echo   $thecontent ;
		//	echo   $subject ;

                // Control-flow broken as columbus seems to have a problem working with it...
		 $emailer->sendemails(
                $to, // TO
                $subject, // E-MAIL SUBJCT
                $thecontent, // CONTENT
                $from, // FROM
                $bcc, // BCC
                $cc, // CC
                array( ), // ATTACHMENTS
                array( ) // IMAGES
		) ? "{status:'success',message:'Successfully Sent E-Mail(s)'}" : "status:'error',message:'Sending E-Mail(s) Failed after 5 Attempts =['}";
		return $this;
	}
}