<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';

class actionEmailHelper {
	
	protected $actionDetails;
	
	protected $who;
	protected $whoAU;
	protected $thirdParty;
       	protected $addapprover;
    protected $decorate;
	
	public function __construct($actionID){
		// action
           
        $this->decorate = array();
		$this->getActionDetails($actionID);
		//var_dump($this->actionDetails);
		$this->getContactInfo(); // INITIALLY GRAB DATA ON CONTACTS
	}
	
	public function getActionDetails($actionID) {
		//echo $actionID;
        $actionTMP = new Action($actionID);
        
		$actionTMP->setActionDetails($actionID,null);
		$this->actionDetails = $actionTMP->viewAction();
		
		
	}
	
	public function getContactInfo() {
		$participantObj = SetupGeneric::useModule('Participant');
	
		foreach(array('who','whoAU','thirdParty','addapprover') as $target) {
			$participantObj->setItemInfo(array('id'=>$this->actionDetails[$target]));
	
			$details = $participantObj->displayItemById();
			$this->$target = array(
				'displayname' => ucwords($details['forename'].' '.$details['surname']),
				'email' => $details['emailAddress'],
				'ID' => $details['participantID']
			);
		}
		return $this;
	}
	
	public function getAUDetails() {
		return $this->whoAU;
	}
	public function getTPDetails() {
		return $this->thirdParty;
	}
        public function getSecondApproverDetails() {
		return $this->addapprover;
	}
	public function getWhoDetails() {
		return $this->who;
	}
	public function appendInfo($data) {
            $this->decorate = array_merge($this->decorate,$data);
        }
	public function sendEmail($subject,$to,$cc,$bcc,$tab='me_completed',$emailtext='',$escalation=false) {
		
		switch($escalation) {
			case 'mgmt':
				$colourBg = '#C00000';
				$colourTxt = '#FFFFFF';
				break;
			case 'red':
				$colourBg = '#FF0000';
				$colourTxt = '#FFFFFF';
				break;
			//case 'blue':
				//$colourBg = '#7294BF';
				//$colourTxt = '#FFFFFF';
				//break;
			case 'blue':
				$colourBg = '#008000';
				$colourTxt = '#FFFFFF';
				break;
			case 'yellow':
				$colourBg = '#FFF000';
				$colourTxt = '#111111';
				break;
			case 'green':
				$colourBg = '#7294BF';
				$colourTxt = '#111111';
				break;
			default: // GREY
				$colourBg = '#808080';
				$colourTxt = '#FFFFFF';
		}
		$to = array($to);
		$cc = array($cc);
		$bcc = array($bcc);
		$from = array(
			'email'=>'info@smart-iso.com','displayname'=>'smart-ISO System E-Mailer'
		);
		//sendemails($to=array(),$subject=null,$body="",$from=null,$bcc=array(),$cc=array(),$attachmentpaths=array(), $imgpaths=array())
		
		
		
		if($this->actionDetails['moduleName'] == 'smartlawreview' && $this->actionDetails['doneDate']){
		
		$summ = 'A smart law review has been completed and needs To Be Approved';
		} elseif(($this->actionDetails['moduleName'] == 'SmartlawC' || $this->actionDetails['moduleName'] == 'SmartlawR' || $this->actionDetails['moduleName'] == 'SmartlawT') && $this->actionDetails['doneDate']){
		
		
		
		$summ = 'A smart law action has been completed and needs To Be Approved';
		}elseif($this->actionDetails['moduleName'] == 'InspectionDue'){
		$name = $this->decorate['twoColData']['actionid']['right'];
					$summ = 'A Critical Audit for '.$name.' on '.format_date($this->actionDetails['dueDate']);
		} else{
		//echo "sdfsdfsda";
		$summ = $this->actionDetails['actionDescription'];
		
		}
		
		
		
		
		
		
		
		
                        
		$emailContent = new newEmail(); // JUST THE CONTENT BUILDER
		$emailer = new eMailer('',5); // SET TO RETRY 5 TIMES TO SEND NOLOGO, NO DEBUG
		//echo $this->who['displayname'];
		//dump_array($this->who);
		//exit;
		if($this->who['ID']){
		
		
		
		$twoColData = array(
			'actionid'=>array('left'=>'<strong>ID:</strong>','right'=>$this->actionDetails['ID']),
			'assignedto'=>array('left'=>'<strong>Assigned To:</strong>','right'=>$this->who['displayname']),
			'authorizing'=>array('left'=>'<strong>Authorizing:</strong>','right'=>$this->whoAU['displayname']),
			'due'=>array('left'=>'<strong>Due Date:</strong>','right'=>date('m/d/Y',strtotime($this->actionDetails['dueDate'])) )
		);
		
		}else{
		
		$twoColData = array(
			'actionid'=>array('left'=>'<strong>ID:</strong>','right'=>$this->actionDetails['ID']),
			'assignedto'=>array('left'=>'<strong>Assigned To:</strong>','right'=>'--'),
			'authorizing'=>array('left'=>'<strong>Authorizing:</strong>','right'=>'--'),
			'due'=>array('left'=>'<strong>Due Date:</strong>','right'=>'--' )
		);
		
		
		}
		
		
                $stdData = array(
                    'emailColour'=>$colourBg,
                    'emailTxtColour'=>$colourTxt,
                    'emailTitle'=>'Action E-mail',
					'sentence'=>'',
                    'singleColData'=>array(
					
                            'summary'=>'<p><strong>Summary</strong><br>'.end( explode( ':|:', $summ ) ).'</p>',
                            'emailtext'=>'<p>'.$emailtext.'</p>'
                    ),
                    'twoColData'=>$twoColData
                );
				//dump_array($this->decorate);
                foreach($this->decorate as $field=>$values) {
                    if(is_array($stdData[$field])) { // add to lists of data
                        $stdData[$field] = array_merge($stdData[$field],$values);
                    } else { // overwrite named values
                        $field = $values;
                    }
                }
                $thecontent = $emailContent->display(
                    $stdData       
                );
                
                $headers = '';
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                $headers .= "Reply-To: info@smart-iso.com\r\n";
                //$headers .= "Bcc: jrm@smart-iso.com;lpc@smart-iso.com\r\n";
                //$headers .= "";
		//mail ( $to['email'] , $subject , $thecontent, $headers ); 
             //   return $this;
             echo $thecontent ;

                // Control-flow broken as columbus seems to have a problem working with it...
echo	 $emailer->sendemails(
                $to, // TO
                $subject, // E-MAIL SUBJCT
                $thecontent, // CONTENT
                $from, // FROM
                $bcc, // BCC
                $cc, // CC
                array( ), // ATTACHMENTS
                array( ) // IMAGES
		) ? "{status:'success',message:'Successfully Sent E-Mail(s)'}" : "status:'error',message:'Sending E-Mail(s) Failed after 5 Attempts =['}";

                return $this;
	}
}