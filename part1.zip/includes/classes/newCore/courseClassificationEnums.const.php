<?php

/*
 * Class used to store course Classification Constants, possibly to be relocated 
 * to constants.php and have all current constants prefixed with COURSE_CLASS_
 */
class courseClassificationEnums {
	const NONE = 0;
	const CORE = 1;
	const WORKER = 2;
	const MANAGER = 4;
	const PRACTITIONER = 8;
}