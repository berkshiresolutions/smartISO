<?php

class eMailer {

	var $maxtries;
	var $logoimg;
	var $debug;
	
	
	function __construct($logoimg='',$maxtries=1,$debug=false) {
		$this->maxtries = (int)$maxtries > 1 ? (int)$maxtries : 1;
		$this->logoimg = $logoimg;
		$this->debug = $debug;
	}
	
	public function sendemails($to=array(),$subject=null,$body="",$from=null,$bcc=array(),$cc=array(),$attachmentpaths=array(), $imgpaths=array())
	{

		//check we at least have valid to and from
		if( ((!is_array($to)) && (count($to) < 1)) || (!array_key_exists('email',$from)) ) {
			if($this->debug) { echo "invalid to or from"; }
			return false;
		}
		
		// force your body to conform
		if(strlen($body) <= 20) {
			if($this->debug) { echo "body string below minimum length"; }
			return false;
		}
		
		if(!array_key_exists('displayname',$from)) {
			$from['displayname'] = ''.$from['email'].'';
		}
		
		/* return ''; */ //take this out to re-activate
		
		require_once($_SERVER['DOCUMENT_ROOT'].'/../includes/vendors/PHPMailer/class.phpmailer.php');
		//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

		$mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch

		$mail->IsSMTP(); // telling the class to use SMTP
		try {
			
			//setup server settings
		
			//$mail->SMTPDebug  = 2;
			if($this->debug) { $mail->SMTPDebug  = 2; }					// enables SMTP debug information (for testing)
			$mail->SMTPAuth   = true;									// enable SMTP authentication
			//$mail->SMTPSecure = "tls";								// sets the prefix to the server
			$mail->Host       = "smtpout.europe.secureserver.net";		// sets the SMTP server
			//$mail->Host       = "relay-hosting.secureserver.net�;		// sets the SMTP server
			$mail->Port       = 80;										// set the SMTP port for the server
			$mail->Username   = "test@smart-iso.com";					// username
			$mail->Password   = "jp2dm21GO";							// password
			//$mail->Username   = "test2@smart-iso.com";					// username
			//$mail->Password   = "TEST2febI4";							// password
			//$mail->Username   = "rsa@smart-iso.com";					// username
			//$mail->Password   = "RSAfebI4";							// password

			//set from
			$mail->SetFrom($from['email'], $from['displayname']);
			
			// add replyto if applicable
			if(array_key_exists('reply',$from)) {
				if(!array_key_exists('replydisplayname',$from)) {
					$from['replydisplayname'] = '';
				}
				$mail->AddReplyTo($from['reply'], $from['replydisplayname']);
			}
			
			// to's
			foreach($to as $entry) {
				if( (is_array($entry)) && (array_key_exists('email',$entry)) ) {
					if(!array_key_exists('displayname',$entry)) {
						$entry['displayname'] = ''.$entry['email'].'';
					}
					$mail->AddAddress($entry['email'], $entry['displayname']);
				}
			}
			
			// cc's
			foreach($cc as $entry) {
				if( (is_array($entry)) && (array_key_exists('email',$entry)) ) {
					if(!array_key_exists('displayname',$entry)) {
						$entry['displayname'] = ''.$entry['email'].'';
					}
					$mail->AddCC($entry['email'], $entry['displayname']);
				}
			}
			
			// bcc's
			foreach($bcc as $entry) {
				if( (is_array($entry)) && (array_key_exists('email',$entry)) ) {
					if(!array_key_exists('displayname',$entry)) {
						$entry['displayname'] = ''.$entry['email'].'';
					}
					$mail->AddBCC($entry['email'], $entry['displayname']);
				}
			}
			
			// logoimg
			if(strpos($body, 'cid:logoimg')) {
				if(file_exists($this->logoimg)) {
					$filename_clean = explode('/',str_replace("\\","/",$this->logoimg));
					$mail->AddEmbeddedImage($this->logoimg, 'logoimg', $filename_clean); // attach file logo.jpg, and later link to it using identfier logoimg
				}
			}
			
			// image attachments
			foreach($imgpaths as $entry) {
				if( (!is_array($entry)) || ( (!array_key_exists('id',$entry)) || (!array_key_exists('path',$entry)) ) ) {
					continue;
				}
				if(strpos($body, 'cid:'.$entry['id'].'')) {
					if( (file_exists($entry['path'])) || (strpos($entry['path'], 'data:') == 0) ) {
						$filename_clean = explode('/',str_replace('\\','/',$entry['path']));
						//echo end($filename_clean);
						$mail->AddEmbeddedImage($entry['path'], $entry['id'], end($filename_clean)); // attach file logo.jpg, and later link to it using identfier logoimg
					}
				}
			}
			
			// other attachments
			foreach($attachmentpaths as $entry) {
			
			
				if( (!is_array($entry)) || ( (!array_key_exists('id',$entry)) || (!array_key_exists('path',$entry)) ) ) {
					continue;
				}
				
				if(file_exists($entry['path'])) {
						//$filename_clean = explode('/',str_replace('\\','/',$entry['path']));
						//echo end($filename_clean);
						$mail->AddEmbeddedImage($entry['path'], $entry['id'], $entry['id']); // attach file logo.jpg, and later link to it using identfier logoimg
				}
			}
			
			// Subject
			$mail->Subject = $subject;
			
			// HTML Content
			$mail->MsgHTML($body);
			
			// send send SEND!!!!
			$cnt = 0;
			while( ($cnt < $this->maxtries) && (!$mail->Send()) ) {
				$cnt++; usleep(100*$cnt);
			}
			if($cnt < $this->maxtries) {
				return true;
			}
			
			//fail if not true...
			return false;
		}
		catch (phpmailerException $e) {
			// echo $e->errorMessage(); //Pretty error messages from PHPMailer
		}
		catch (Exception $e) {
			// echo $e->getMessage(); //Boring error messages from anything else!
		}
		// echo "mail sent";
	}
}

/* End of file Auth.php */
