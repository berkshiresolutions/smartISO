<?php
 /**
  $Id: Report.class.php,v 3.18 Tuesday, January 25, 2011 1:20:55 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @since  Monday, August 16, 2010 11:35:41 AM>
  */

class GraphData
{

}
