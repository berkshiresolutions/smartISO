<?php
 /**
  $Id: Report.class.php,v 3.18 Tuesday, January 25, 2011 1:20:55 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @since  Monday, August 16, 2010 11:35:41 AM>
  */

class GraphRequest
{
	private $graphObj;
	private $graphType;
	private $graphIdentifier;
	private $graphContainer;

	public function __construct() {


	}

	/**
	 *
	 * @param array $arr array of parameters to be passed to method
	 */
	public function setParams($arr) {

		if ( is_array($arr) ) {

			$this->graphType 		= $arr['type'];
			$this->graphIdentifier 	= $arr['identifier'];
			$this->params 			= $arr['params'];
			$this->graphContainer	= $arr['divcontainer'];

			if ( empty($this->graphType) ) {
				throw new Exception('<b>GraphRequest::setParam</b> method missing graph type',10002);
			}

			if ( empty($this->graphIdentifier) ) {
				throw new Exception('<b>GraphRequest::setParam</b> method missing graph identifier',10003);
			}

			if ( empty($this->graphContainer) ) {
				throw new Exception('<b>GraphRequest::setParam</b> method missing graph container',10004);
			}
		} else {
			throw new Exception('<b>GraphRequest::setParam</b> method expected an array',10001);
		}
	}

	public function sendRequest() {
		$this->graphObj = new Graph();
		$this->graphObj->setGraphType($this->graphType,$this->graphContainer,$this->params);
	}

	public function getResult() {
		return $this->graphObj->renderGraph();
	}
}
