<?php
 /**
  $Id: Report.class.php,v 3.18 Tuesday, January 25, 2011 1:20:55 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Report
  * @since  Monday, August 16, 2010 11:35:41 AM>
  */

class Graph
{
	private $obj;
	private $graphType;

	public function setGraphType($p_graph_type,$p_container,$p_param) {

		$this->graphType 	= $p_graph_type;
		$this->container	= $p_container;
		$this->param		= $p_param;
	}

	public function renderGraph() {

		$classname = ucfirst($this->graphType).'Graph';
	 	$filename = $classname.'.class.php';

		require_once $filename;
		$graphObj = new $classname($this->container,$this->param);
		return $graphObj->renderGraph();
	}
}
