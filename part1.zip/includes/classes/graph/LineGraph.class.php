<?php
 /**
  $Id: HorizontalGraph.class.php,v 3.14 Thursday, January 20, 2011 3:27:05 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Horizontal graphs
  * @since  Thursday, September 09, 2010 10:08:22 AM>
  */
class LineGraph
{
	private $graph_width;
	private $graph_height;
	private $xml_file_name;
	private $graph_data;
	private $graph_settings;
	private $module_name;
	private $graph_swf_file;
	private $secondary_graph_swf_file;
	private $graph_subtype;
	private $graph_module_type;

	public function __construct($p_module,$p_graph_data,$p_subtype='',$p_graph_module_type='') {

		$this->graph_data = & $p_graph_data;
       //dump_array($this->graph_data);
		$this->module_name = $p_module;
		$this->graph_settings = "/includes/js/graphs/chart_settings.xml" ;
		//$this->graph_type = "/includes/js/graphs/fusion_charts/Bar2D.swf" ;
		
		switch ($p_subtype) {
			case 'stacked': 
					$this->graph_swf_file = "/includes/js/graphs/fusion_charts/FCF_MSLine.swf";
					break;
			case 'group': 
					$this->graph_swf_file = "/includes/js/graphs/fusion_charts/FCF_MSLine.swf";					
					break;
			default : 
					$this->graph_swf_file = "/includes/js/graphs/fusion_charts/FCF_MSLine.swf";
		}

		$this->graph_subtype = $p_subtype;
	$this->graph_module_type = $p_graph_module_type;
	}

	public function convertToXml() {

		$additional_height = $this->graph_data['additional_height'] == '' ? 0 : (int) $this->graph_data['additional_height'];

		$next_label_id = 1;

		//dump_array($this->graph_data['chart_data']);
			

		if ( is_array($this->graph_data['chart_data']) ) {

			switch ($this->graph_subtype) {

				case 'group':



					break;

				default:
							
						foreach ($this->graph_data['chart_data'] as $k=> $val ) {
							
							$url = "";
							if ( $val['link'] != '' ) {
								$url = " link='".urlencode($val['link'])."'";
							}

									//dump_array($val);
									//if($val['key'] == '2011'){
								$graph_data_values .= "<dataset seriesName='".$k."' showValues='0'>\n";
									foreach($val as $k1=> $v){
										
									$graph_data_values .= "<set  label='".$k."' value='".$v."' ".$url."/>\n";
									//$graph_data_values .= "<set  label='".$k."' value='".$v."' ".$url."/>\n";
									
									}
									$graph_data_values .= "</dataset>\n";
									//}
									
								
									
									
									
									
								
								//echo "dfgdfg";

								//	$graph_data_values .= "<dataset seriesName='".$val['key']."'>\n";
								//	$graph_data_values .= "<set  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
								//	$graph_data_values .= "</dataset>\n";

							//	}
							////$graph_data_values .= "</dataset>\n";


							//$graph_data_values .= "<set label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";


							$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
							$this->graph_width = $this->graph_width + 80;
							$i++;

						} // end foreach
			} // end switch

		} // end if

		/* increase height of graph for labels */
		if( is_array($this->graph_data['labels']) ) {
			foreach ( $this->graph_data['labels'] as $label_val ) {
				$this->graph_height = $this->graph_height + 50;
				$graph_data_y .=  "<value xid='".$i."'> </value>";
				$i++;
			} // end foreach
		} // end if


//exportFormats='PDF=Export as PDF|PNG=Export as PNG'
		// LCowles Added Chart Server-Side Export
		//$graph_data =  "<chart exportAction='download' exportFileName='".$this->graph_data['heading']."' exportEnabled='1' exportAtClient='0' exportHandler='/includes/chartExport/FCExporter.php' chartRightMargin='15' showValues='0' numdivlines='3' numVdivlines='0'  yAxisMinValue='80' yAxisMaxValue='80' adjustDiv='' numDivLines='10' caption='".$this->graph_data['heading']."' chartleftmargin='15' ";
			$graph_data =  "<chart caption='Trend Line Graph' xAxisName='years' yAxisName='Score' hovercapbg='FFECAA' hovercapborder='F47E00' formatNumberScale='0' decimalPrecision='0' showvalues='0' animation='1' numdivlines='8' numVdivlines='0' yaxisminvalue='0' yaxismaxvalue='15' lineThickness='3' rotateNames='1'";
		switch ($this->graph_subtype) {

			case 'group':

				$graph_data .= "yAxisName='".$this->graph_data['xaxis_text']."' ";
				$graph_data .= "xAxisName='".$this->graph_data['yaxis_text']."' bgColor='F1F1F1' ";
				$graph_data .= "canvasBorderThickness='1' canvasBorderColor='999999' ";
				
				if ($this->graph_module_type=='graph')
				$graph_data .= "paletteColors='FFCC00,336600,CC0000' ";
				
				$graph_data .= "plotFillAngle='330' plotBorderColor='999999' showAlternateVGridColor='1' divLineAlpha='0'>";
				$graph_data .= "<categories>";
				
				$graph_data .= " <category name='2011' />";

			/*	if ($this->graph_data['chart_data']) {
					foreach ( $this->graph_data['chart_data'] as $cat_name=>$cat_data) {

						if ( $this->graph_module_type == 'risk_impact' ) {

							if ( trim($impact_measures[$cat_name]," ") == '=>3 Days' ) {
								$label = 'Greater than Equal to 3 Days';
							} else if ( trim($impact_measures[$cat_name]," ") == '< 3 Days' ) {
								$label = 'Less than 3 Days';
							} else {
								$label = $impact_measures[$cat_name];
							}

							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'disposition' ) {

							$label = $dispositions[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'causes' ) {

							$label = $causes[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else {
							$graph_data .= "<category label='".ucfirst($cat_name)."'/>";
						}
					}
				}*/

				$graph_data .= "</categories>";
				$graph_data .= $graph_data_values;
				break;

			default:
				//$graph_data .= " yAxisName='".$this->graph_data['xaxis_text']."' ";
				//$graph_data .= " xAxisName='".$this->graph_data['yaxis_text']."' bgColor='F1F1F1' ";
				$graph_data .= " canvasBorderThickness='1' canvasBorderColor='999999' ";

				if ($this->graph_module_type=='graph')
				$graph_data .= "paletteColors='FFCC00,66CC33,339900,336600,CC0000' ";

				if ($this->graph_module_type=='contract')
				$graph_data .= "paletteColors='FFCC00,336600,CC0000' ";

				$graph_data .= "plotFillAngle='330' plotBorderColor='999999' showAlternateVGridColor='1' divLineAlpha='0'>";
				////$graph_data .= "<categories><category label=''/></categories>";
				$graph_data .= "<categories>";
				
				//echo $this->graph_module_type;
				/*if ($this->graph_data['chart_data']) {
					foreach ( $this->graph_data['chart_data'] as $cat_name=>$cat_data) {

						if ( $this->graph_module_type == 'risk_impact' ) {

							if ( trim($impact_measures[$cat_name]," ") == '=>3 Days' ) {
								$label = 'Greater than Equal to 3 Days';
							} else if ( trim($impact_measures[$cat_name]," ") == '< 3 Days' ) {
								$label = 'Less than 3 Days';
							} else {
								$label = $impact_measures[$cat_name];
							}

							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'disposition' ) {

							$label = $dispositions[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'causes' ) {

							$label = $causes[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else {
								//echo $cat_name;
						//foreach($cat_data as $val){
						$graph_data .= "<category label='".ucfirst($cat_name)."'/>";
						//}
							
						}
					}
				}*/
				
				$graph_data .= "<category label='2011'/>";
				$graph_data .= "<category label='2012'/>";
				$graph_data .= "<category label='2014'/>";

				$graph_data .= "</categories>";
				$graph_data .= $graph_data_values;
				//$graph_data .= "</series><graphs><graph gid='1'>";
				//$graph_data .= $graph_data_x;
		}

		$graph_data .= "</chart>";

		
                
                
                
                /* write the xml data into xml file */
		$dyn_xml_name = str_replace(' ','_',$this->graph_data['heading']);
		$this->xml_file_url = realpath($_SERVER['DOCUMENT_ROOT']."/private_files/".$this->module_name)."/graph_data_file_".$dyn_xml_name.".xml";
		$this->xml_file_name  = "/private_files/".$this->module_name."/graph_data_file_".$dyn_xml_name.".xml";

		$file_handle = fopen($this->xml_file_url,'w');

		if ( $file_handle) {

			fwrite($file_handle,$graph_data,strlen($graph_data));
			fclose($file_handle);
		} // end if
	}

	public function getData() {

		if ( $this->graph_width > 740 ) {
			$graph_parameter['graph_width'] = $this->graph_width;
		} else {
			$graph_parameter['graph_width'] = 740;
		}

		if ( $this->graph_width > 400 ) {
			$graph_parameter['graph_height'] = $this->graph_height;
		} else {
			$graph_parameter['graph_height'] = 400;
		}
		//echo $this->graph_swf_file;
		$graph_parameter['xml_file_name'] = $this->xml_file_name;
		$graph_parameter['graph_settings'] = $this->graph_settings;
		$graph_parameter['graph_swf_file'] = $this->graph_swf_file;
		$graph_parameter['secondary_graph_swf_file'] = $this->secondary_graph_swf_file;

		return $graph_parameter;
	}
}
?>