<?php
 /**
  $Id: Session.class.php,v 3.21 Tuesday, December 28, 2010 9:31:10 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:22:56 PM>
  */

/**
 * A setup class for managing session operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" subpackage
 */

class Session
{

	public static function StartSession() {
		if(defined('_APPLICATION_SYSTEMWIDE_TIMEOUT')) {
			session_set_cookie_params(min(array(3600,_APPLICATION_SYSTEMWIDE_TIMEOUT)));
		}
		session_start();
	}

	public static function saveSessionField($p_var,$p_val) {
		$_SESSION['SMARTISO_'.strtoupper($p_var)] = $p_val;
	}

	public static function getSessionField($p_var) {
		//echo $p_var;
		return $_SESSION['SMARTISO_'.strtoupper($p_var)];
	}

	public static function deleteSessionField($p_var) {
	//	session_unregister('SMARTISO_'.strtoupper($p_var));
unset($_SESSION['SMARTISO_'.strtoupper($p_var)] );
	}
	public function dumpSessionData() {
		dump_array($_SESSION);
	}

	public static function destroySession() {
		session_destroy();
	}

}
