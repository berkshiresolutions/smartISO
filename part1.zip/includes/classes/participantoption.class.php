<?php
/**
 $Id: Option.class.php,v 3.20 Thursday, February 10, 2011 4:19:09 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, August 14, 2010 5:04:24 PM>
 */

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class POption
{



	public function __construct() {

		$this->dbHand 		= DB::connect(_DB_TYPE);


	}


}
