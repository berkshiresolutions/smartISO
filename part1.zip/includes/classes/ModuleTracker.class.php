<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */

class ModuleTracker
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 *Property to hold module name
	 *@access private
	 */
	private $module;

	/**
	 *Property to hold record Info
	 *@access private
	 */
	private $recInfo;

	private $user_id;


	/**
	 * Constructor for initializing Incidence object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->miscObj			= new Misc();
		$this->user_id 			= getLoggedInUserId();
	}


	/*
	 * This method is used to set incidence information for the respective object
	 */
	public function setModuleTrackerInfo($p_module,$p_recInfo) {

		global $config_module_mapping;

		$this->module = $p_module;
		$this->recInfo = $p_recInfo;

		// $config_module_mapping are defined in config.inc.php
		$this->moduleMap = $config_module_mapping;
	}

	public function saveRecordLog() {

		$sql = sprintf("SELECT whoID FROM %s.".$this->moduleMap[$this->module]."
					WHERE ID = %d",
					_DB_OBJ_FULL,
					$this->recInfo['rec_id']);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$whoID = $pStatement->fetchColumn();

		$current_date_time = $this->miscObj->getCurDate().' '.$this->miscObj->getCurTime();

		if ( $whoID == $this->user_id ) {
			$role = 'O';
		} else {
			$role = 'M';
		}

		$sql = "INSERT INTO %s.module_tracker (
				recID,module,role,action,dateTimestamp,reference,whoID
				)
				VALUES (%d,'%s','%s','%s','%s','%s',%d)";

		 $psql = sprintf($sql,_DB_OBJ_FULL,$this->recInfo['rec_id'],$this->module,$role,$this->recInfo['action'],$current_date_time,
						$this->getSubReference(),$this->user_id);

		$pstmt = $this->dbHand->prepare($psql);
		$pstmt->execute();
	}

	public function getSubReference() {
        if($this->module == 'DSE'){
			$sql = sprintf("SELECT reference,subReference FROM %s.dse_assessment
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recInfo['rec_id']);
					$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();

				$record = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( empty($record['subReference']) ) {
			return $record['reference'];
		} else {
			return $record['reference'].".".$record['subReference'];
		}
			
		}
		 if($this->module == 'MANUAL'){
			$sql = sprintf("SELECT reference,subReference FROM %s.manual_handling
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recInfo['rec_id']);
					$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();

				$record = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( empty($record['subReference']) ) {
			return $record['reference'];
		} else {
			return $record['reference'].".".$record['subReference'];
		}
			
		}
		if ( $this->module == 'RISK' ) {

			$sql = sprintf("SELECT reference,subReference FROM %s.swimlane
						WHERE swimID = %d",
						_DB_OBJ_FULL,
						$this->recInfo['process_id']);

		} else {

    	$sql = sprintf("SELECT reference,subReference FROM %s.".$this->moduleMap[$this->module]."
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recInfo['rec_id']);
		}

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$record = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( empty($record['subReference']) ) {
			return $record['reference'];
		} else {
			return $record['reference'].".".$record['subReference'];
		}

	}

	/*public function trackRecord() {

		$current_date_time = $this->miscObj->getCurDate().' '.$this->miscObj->getCurTime();

		$sql = "INSERT INTO %s.module_tracker (recID,module,role,dateTime,reference,whoID) VALUES (%d,'%s','%s','%s','%s',%d)";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->recInfo['rec_id'],$this->module,$this->recInfo['role'],$current_date_time,
						$this->recInfo['ref'],$this->user_id);

		$pstmt = $this->dbHand->prepare($psql);
		$pstmt->execute();
		//dump_array_and_exit($pstmt->errorInfo());
	}*/

	public function getTrack() {

		$sql = sprintf("SELECT * FROM %s.module_tracker WHERE module = '%s' AND recID = %d ORDER BY ID DESC",
					   _DB_OBJ_FULL,$this->module,$this->recInfo['rec_id']);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetchAll(PDO::FETCH_ASSOC);
		return $records;
	}
	
	public function getLatestref() {

		$sql = sprintf("SELECT * FROM %s.risk WHERE processStepID = %d ORDER BY ID DESC",
					   _DB_OBJ_FULL,$this->recInfo['rec_id']);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetchAll(PDO::FETCH_ASSOC);
		return $records;
	}
	public function getLatestref1() {

		$sql = sprintf("SELECT * FROM %s.risk WHERE ID = %d ORDER BY ID DESC",
					   _DB_OBJ_FULL,$this->recInfo['rec_id']);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetchAll(PDO::FETCH_ASSOC);
		return $records;
	}
	
	public function getPrimaryHazard($id) {
			$this->id = $id;
		$sql = sprintf("SELECT primaryHazard FROM %s.hazard_parent_classification WHERE ID = ".$this->id,
					   _DB_OBJ_FULL);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetch(PDO::FETCH_ASSOC);
		return $records;
	}
	
		public function getActions($id) {
			$this->id = $id;
		$sql = sprintf("SELECT * FROM %s.actions WHERE ID = ".$this->id,
					   _DB_OBJ_FULL);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetch(PDO::FETCH_ASSOC);
		return $records;
	}
	
			public function getStep($id) {
			$this->id = $id;
		$sql = sprintf("SELECT * FROM %s.swimlane_data WHERE ID = ".$this->id,
					   _DB_OBJ_FULL);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetch(PDO::FETCH_ASSOC);
		return $records;
	}
	
	public function getControlPath($id) {
			$this->id = $id;
		$sql = sprintf("SELECT hazardName FROM %s.control_measures_hazard WHERE ID = ".$this->id,
					   _DB_OBJ_FULL);

		$pstmt = $this->dbHand->prepare($sql);
		$pstmt->execute();

		$records = $pstmt->fetch(PDO::FETCH_ASSOC);
		return $records;
	}

public function saveRecordLog1($table,$code,$recID,$ref,$action) {

		$sql = sprintf("SELECT whoID FROM %s.%s	WHERE ID = %d",
					_DB_OBJ_FULL,$table,	$recID);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$whoID = $pStatement->fetchColumn();
                $userID= getLoggedInUserId();
		$current_date_time = date("Y-m-d H:i:s");

		if ( $whoID == $userID ) {
			$role = 'O';
		} else {
			$role = 'M';
}

		$sql = "INSERT INTO %s.module_tracker (
				recID,module,role,action,dateTimestamp,reference,whoID
				)
				VALUES (%d,'%s','%s','%s','%s','%s',%d)";

		 $psql = sprintf($sql,_DB_OBJ_FULL,$recID,$code,$role,$action,$current_date_time,$ref,$userID);

		$pstmt = $this->dbHand->prepare($psql);
		$pstmt->execute();
	}


}
?>