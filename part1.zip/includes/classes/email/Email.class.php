<?php
 /**
  $Id: Email.class.php,v 3.15 Tuesday, February 01, 2011 2:39:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:51:21 PM>
  */

require_once "EmailBase.abs.php";
require_once "EmailAttachment.class.php";
require_once "EmailRecipient.class.php";
require_once "EmailData.class.php";
require_once "EmailTemplate.class.php";

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class Email extends EmailBase {

	private $mailType;
	private $mailObj;
	private $attachmentObj;
	private $recipientObj;
	private $templateUid;
	private $emailTemplate;
	private $emailModule;

	public function __construct($p_type='text') {

		$this->mailType 		= $p_type;
		$this->attachmentObj 	= new EmailAttachment();
		$this->recipientObj 	= new EmailRecipient();


		//$classname = 'Email'.ucfirst($this->mailType);
		$this->mailObj = EmailTemplate::loadTemplateClass($this->mailType);

	}

	public function template($p_mailtemplate) {
		$this->mailObj->template($p_mailtemplate);
	}

	public function prepare() {

		$this->mailObj->prepare();
	}

	public function addAttachment($p_file) {

		try {
			$this->attachmentObj->addAttachment($p_file);
		} catch ( ErrorException $e ) {
			echo $e->getMessage();
		}

	}

	public function deleteAttachment($p_file) {

		try {
			$this->attachmentObj->deleteAttachment($p_file);
		} catch ( ErrorException $e ) {
			echo $e->getMessage();
		}

	}

	public function addRecipient($p_name,$p_email,$p_salutation='') {

		try {
		 $optObj = new Option();
		 $email_check=$optObj->getOption('_SU_EMAIL_BLOCKER');
		 $pos=strpos($p_email,$email_check);

		 if ($pos === false)
			$this->recipientObj->addRecipient($p_name,$p_email,$p_salutation);
		} catch ( ErrorException $e ) {
			echo $e->getMessage();
		}
	}

	public function deleteRecipient($p_name) {

		try {
			$this->recipientObj->deleteRecipient($p_name);
		} catch ( ErrorException $e ) {
			echo $e->getMessage();
		}
	}

	private function setTemplate($p_uid) {
		$this->templateUid = $p_uid;
	}

	private function getTemplate() {

		$rep_template_arr 		= EmailTemplate::loadTemplate($this->mailType,$this->templateUid);
		$this->emailTemplate 	= $rep_template_arr['template'];
		$this->emailModule 		= $rep_template_arr['module'];
	}

	public function getEmailData($p_record_id='') {

		//echo $p_record_id;

		require_once "EmailData.class.php";
		$dataObj 			= new EmailData($this->emailModule);
		$this->emailData 	= $dataObj->getData($p_record_id);
		$dataObj 			= null;
	}

	private function callTemplate($p_uid) {
		$this->setTemplate($p_uid);
		$this->getTemplate();
	}

	public function generateEmail($p_uid,$p_record_id='') {
		$this->callTemplate($p_uid);
		$this->getEmailData($p_record_id);
		$this->mergeTemplateAndData();
	}

	public function generateEmailFromData($p_uid,$p_data_array) {

		$this->callTemplate($p_uid);
		$this->emailData = $p_data_array;
		$this->mergeTemplateAndData();
	}

	private function mergeTemplateAndData() {

		$this->mailObj->getEmailContent($this->emailTemplate,$this->emailData,$this->recipientObj->getRecipients());

		try {
			$this->mailObj->prepare($this->recipientObj->getRecipients(),$this->attachmentObj->getAttachments());

		} catch (ErrorException $e) {
			echo $e->getMessage();

		}
	}

	public function send($p_flush=true) {

		try {
			$this->mailObj->send();

			if ($p_flush) {
				$this->mailObj->flush();
			}

		} catch (ErrorException $e) {
			echo $e->getMessage();

		}

	}
}
