<?php
 /**
  $Id: EmailHtml.class.php,v 3.43 Saturday, February 05, 2011 1:09:24 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Email
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:49:50 PM>
  */


/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class EmailHtml {

	private $rawMailContent;
	private $mailHeader;
	private $mailContent;
	private $mailSubject;
	private $bound;
	private $bound_last;
	private $bound_text;
	private $sent_to_email_ids;

	public function __construct() {
		$this->sent_to_email_ids = '';
	}

	public function set_boundary_information() {

		$random_hash			= md5(date('r', time()));
		$this->bound_text		= "smartiso".$random_hash;

		$this->bound			= "--".$this->bound_text."\r\n";
		$this->bound_last		= "--".$this->bound_text."--\r\n";
	}

	public function getEmailContent($p_template,$p_data,$p_recObj) {

		require _MYINCLUDES.'email_templates/'.$p_template;

		$this->mailContent = $template_content;
		$this->mailSubject = $p_data['email_subject'];

		/* added by sanjeev used to just module action mails */
		if ( count($p_recObj) ) {
			foreach ( $p_recObj as $value ) {
				$person_name = $value['salutation'].'&nbsp;'.$value['name'];
			}
			$this->mailContent 	= str_replace('[user_name]',$person_name,$this->mailContent);
		} else {
			$this->mailContent 	= str_replace('[user_name]',' ',$this->mailContent);
		}

		foreach ( $p_data as $p_elek=>$p_elev ) {

			$search_string 		= '['.$p_elek.']';
			$this->mailContent 	= str_replace($search_string,$p_elev,$this->mailContent);
		}

		return $this->mailContent;
	}

	public function prepare($p_recObj,$p_attObj) {

		//dump_array($p_recObj);

		$recipient_cnt	= count($p_recObj);
		$attachment_cnt = count($p_attObj);

		if ($attachment_cnt) {
			$this->set_boundary_information();

			$headers = 	"MIME-Version: 1.0\r\nContent-Type: multipart/mixed;\r\n\tboundary=".$this->bound_text."\r\nFrom: "._SITE_RETURN_EMAIL."\r\n";

			$simple_message = $this->mailContent;
		
			$this->mailContent = '';

			$this->mailContent .= $this->bound;
			$this->mailContent .= "Content-Type: text/html; charset=\"iso-8859-1\"\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n".$simple_message."\r\n";

			$i = 0;

			foreach ( $p_attObj as $attachment_ele ) {

				$this->mailContent .= $this->bound;

				$this->mailContent .= "Content-Type: ".$attachment_ele['mime']."; name=\"".$attachment_ele['name']."\"\r\n"
							."Content-Transfer-Encoding: base64\r\n"
							."Content-disposition: attachment; filename=\"".$attachment_ele['name']."\"\r\n\r\n"
							.chunk_split(base64_encode($attachment_ele['content']));

			} // end foreach loop

			$this->mailContent .= "\r\n".$this->bound_last;
		} else {
			$headers = 	"Content-Type: text/html; charset=\"iso-8859-1\"\r\nFrom: "._SITE_RETURN_EMAIL."\r\n";
			
		}

		// add recipient
		if ( $recipient_cnt ) {
           
			$k = 1;
			$multi_recp_prefix .= "Bcc: ";
			$multi_recp_suffix .= "\r\n";
			$multi_recipients = '';


			foreach ( $p_recObj as $recipient_ele ) {

				if ( $k++ == 1 ) {
					$headers .= "To: ".$recipient_ele['name']." <".$recipient_ele['email'].">\r\n";
					$this->sent_to_email_ids .= $recipient_ele['email'].', ';
				} else {
					if ( $recipient_cnt > 2 ) {
						$multi_recipients .= $recipient_ele['name']." <".$recipient_ele['email'].">, ";
						$this->sent_to_email_ids .= $recipient_ele['email'].', ';
					} else {
						$multi_recipients .= $recipient_ele['name']." <".$recipient_ele['email'].">";
						$this->sent_to_email_ids .= $recipient_ele['email'].', ';
					}
				}
			} // end foreach
			$multi_recipients = rtrim($multi_recipients,", ");
			$this->sent_to_email_ids = rtrim($this->sent_to_email_ids,", ");

		//	$multi_recipients = $multi_recipients.', smart-iso Team <smartiso.ehsindia@gmail.com>'; // to check emails

		//	$headers .= $multi_recp_prefix.$multi_recipients.$multi_recp_suffix;
		} // end if

	 $this->mailHeader = $headers;
	

	}

	public function send() {

		/*echo $this->sent_to_email_ids;
		echo $this->mailContent;
		echo "<br/>----------------------------------------------------------------------------<br/>";
		exit;*/
		
			//echo $this->sent_to_email_ids;
			
		//mail('',$this->mailSubject,$this->mailContent,$this->mailHeader);*/

		 require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';
		 $emailer = new eMailer('',5);

$emailer->sendemails(
	array( array('email'=>$this->sent_to_email_ids,'displayname'=>'') ), // TO
	$this->mailSubject, // SUBJECT
	$this->mailContent, // HTML BODY (AUTO-BUILDS IN PLAIN-TEXT)
	array( 'email'=>'test@smart-iso.com','displayname'=>'No-reply Smart-ISO ' ), // FROM
	array( /*array('email'=>'server@smart-iso.com','displayname'=>'smart-ISO')*/ ), // BCC
	array( /*array('email'=>'lpc@smart-iso.com','displayname'=>'Lewis Cowles - CTO, smart-ISO')*/ ), // CC
	array( /*array('id'=>'2819522.pdf','path'=>'2819522.pdf')*/ ), // ATTACHMENTS
	array( /* '','','' */ ) // IMAGES
) ? "" : "Sending E-Mail(s) Failed after 5 Attempts =[";
		
		

		
	}

	public function flush() {
		$this->mailContent = '';
	}
}
