<?php
 /**
  $Id: EmailRecipient.class.php,v 3.04 Monday, December 06, 2010 1:10:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Email
  * @since  Monday, August 16, 2010 5:34:57 PM>
  */

class EmailRecipient
{

	private $recipients;

	public function addRecipient($p_name,$p_email,$p_salutation) {

		if ( validate_email_address($p_email) ) {

			$recipient['name'] 			= $p_name;
			$recipient['email'] 		= $p_email;
			$recipient['salutation'] 	= $p_salutation;

			$this->recipients[$p_email]		= $recipient;
		} else {
			throw new ErrorException('Failed: Invalid Email Address of the recipient.<br/>',14);
		}
	}

	public function deleteRecipient($p_email) {

		if ( !empty($p_email) ) {
			unset($this->recipients[$p_email]);
		}
	}

	public function getRecipients() {

		$recipient_cnt = count($this->recipients);

		if (!$recipient_cnt) { throw new ErrorException("There must be at least one recipient to send an email."); }

		return $this->recipients;
	}
}
?>