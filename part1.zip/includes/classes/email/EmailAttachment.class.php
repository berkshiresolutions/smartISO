<?php
 /**
  $Id: EmailAttachment.class.php,v 3.02 Monday, August 16, 2010 5:34:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Email
  * @since  Monday, August 16, 2010 5:32:49 PM>
  */

class EmailAttachment
{
	private $attachments;

	public function addAttachment($p_file) {

		if ( !file_exists($p_file) ) {
			throw new ErrorException('Failed to attach file '.$p_file,11);
		} else {
			$attach['name'] 	= $p_file;
			$attach['mime'] 	= mime_content_type($p_file);
			$attach['content'] 	= '';

			$content			= file_get_contents($p_file);
			$attach['content'] 	= $content;

			$this->attachments[$p_file] = $attach;
		}
	}

	public function deleteAttachment($p_file) {

		if ( !isset($this->attachments[$p_file]) ) {
			throw new ErrorException('Failed to delete file '.$p_file.'. No such file attached',12);
		} else {
			unset($this->attachments[$p_file]);
		}
	}

	public function getAttachments() {
		return $this->attachments;
	}
}
?>