<?php
 /**
  $Id: EmailTemplate.class.php,v 3.06 Monday, December 06, 2010 1:09:09 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Email
  * @since  Monday, August 16, 2010 6:35:02 PM>
  */


class EmailTemplate
{
    public function loadTemplateClass($p_type) {

		$classname = 'Email'.ucfirst($p_type);

		require_once $classname.'.class.php';
		return new $classname();
	}

	public function loadTemplate($p_type,$p_uid) {

		$xmlUrl = _MYPRIVATECLASSES."email/email.identifiers.xml"; // XML feed file/URL
		$xmlStr = file_get_contents($xmlUrl);
		$xmlObj = simplexml_load_string($xmlStr);
		$arrXml = objects_into_array($xmlObj);

		$sel_template = array();

		foreach ( $arrXml['template'] as $template_arr ) {
			//$this->reportUid
			if ( $template_arr['uid'] == $p_uid ) {
				$sel_template = $template_arr;
				break;
			}
		}

		$template_name = $p_type.'_template';

		$return_arr['template'] = $sel_template[$template_name];
		$return_arr['module'] = $sel_template['module'];

		return $return_arr;
	}
}