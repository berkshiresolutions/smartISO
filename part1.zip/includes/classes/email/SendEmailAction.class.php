<?php
 /**
  $Id: SendEmailAction.class.php,v 3.26 Tuesday, February 01, 2011 2:39:37 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Anil
  * @package Smartiso
  * @subpackage Alert Class
  * @since  Saturday, December 04, 2010 4:17:45 PM>
  */
class SendEmailAction extends Email
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	private $mailData;
	private $emailObj;
	private $recordId;
	private $actionObj;
	private $actionData;
	private $last_participant_id;

	public function __construct($p_module,$p_record_id) {

 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->moduleName = $p_module;
		$this->recordId = $p_record_id;
		$this->participantObj = SetupGeneric::useModule('Participant');
		$this->organigramobj = new OrganigramSetup();

		$this->actionObj = new Action();

	}

	private function getActionData($p_action_id) {
		$this->actionObj->setActionDetails($p_action_id,'');
		$this->actionData = $this->actionObj->viewAction();
		//dump_array($this->actionData);
	}

	/* this method is used to get mail data */

	public function sendMails() {

		$email_data = $this->formatData();
		//dump_array($email_data);
		
		//recipient details
		$this->getMailRecipient($this->mailData['bu_id']);
		$mail_recipient = $this->last_participant_id;

		$this->participantObj->setItemInfo(array('id'=>$mail_recipient));
		$recipient_details = $this->participantObj->displayItemById();
//		dump_array($recipient_details);
	
$recipient_name = $recipient_details['forename'].' '.$recipient_details['surname'];
		$recipient_name = ucwords($recipient_name);
		$recipient_email = $recipient_details['emailAddress'];

		if ( $recipient_details['gender'] == 'F' ) {
			$salutation = 'Ms';
		} else {
			$salutation = 'Mr.';
		}


		$email_token =  strtoupper($this->moduleName).'ACTION';

		if ( $recipient_email != '' ) {

			$this->emailObj = new Email('html');
			try {

				$this->emailObj->addRecipient($recipient_name,$recipient_email,$salutation);

				$this->emailObj->generateEmail($email_token,$email_data);
				$this->emailObj->send(_LIVE_MODE);

			} catch (ErrorException $e) {
				$e->getMessage();
			}
		}

	}

	private function getMailRecipient($bu_id) {


		$this->organigramobj->setItemInfo(array('id'=>$bu_id));
		$org  =  $this->organigramobj->getPostDetails();

		if ( $org == -1 ) {

			$sql = sprintf("SELECT parentBuID FROM %s.business_units WHERE buID = %d",_DB_OBJ_FULL,$bu_id);
			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();

			$bu_data = $stmt->fetch(PDO::FETCH_ASSOC);

			$parent_bu = $bu_data['parentBuID'];

			if ( $parent_bu == 0 ) {

				if ( _DB_TYPE != 'mysql' ) {
					$sql5 = sprintf("SELECT TOP 1 participantID FROM %s.participant_meta_data WHERE accessLevel = 1",_DB_OBJ_FULL);
					$stmt = $this->dbHand->prepare($sql5);
					$stmt->execute();
					$adminid = $stmt->fetch(PDO::FETCH_ASSOC);
					$this->last_participant_id = $adminid['participantID'];

				} else {
					$sql5 = sprintf("SELECT participantID FROM %s.participant_meta_data WHERE accessLevel = 1 LIMIT(0,1)",_DB_OBJ_FULL);
					$stmt = $this->dbHand->prepare($sql5);
					$stmt->execute();
					$adminid = $stmt->fetch(PDO::FETCH_ASSOC);
					$this->last_participant_id = $adminid['participantID'];
				}

			} else {

				$sql2 = sprintf("SELECT participantID FROM %s.organisation_positions WHERE buID = %d",_DB_OBJ_FULL,$parent_bu);

				$stmt = $this->dbHand->prepare($sql2);
				$stmt->execute();
				$participant_data = $stmt->fetch(PDO::FETCH_ASSOC);

				if ( $participant_data['participantID'] != '' ) {

					$this->last_participant_id = $participant_data['participantID'];

				} else {
					$this->getMailRecipient($parent_bu);
				}

			}

		} else {

			$this->last_participant_id = $org['participantID'];

			if ( $this->last_participant_id == '' ) {


				$sql = sprintf("SELECT parentBuID FROM %s.business_units WHERE buID = %d",_DB_OBJ_FULL,$org['buID']);

				$stmt = $this->dbHand->prepare($sql);
				$stmt->execute();

				$bu_data = $stmt->fetch(PDO::FETCH_ASSOC);
				$this->getMailRecipient($bu_data['parentBuID']);

			}
		}
	}

	/*method is used to format the mail data */
	private function formatData() {
		$this->moduleName;
		$dyn_function_name = $this->moduleName.'Email';
		$this->getActionData($this->recordId);
		//dump_array($this->actionData);
		$this->$dyn_function_name();
		//dump_array($this->mailData);

		$participant_id = $this->actionData['who'];

		if ( $participant_id ) {

			$this->participantObj->setItemInfo(array('id'=>$participant_id));
			$participant_details = $this->participantObj->displayItemById();

			$this->mailData['who'] = $participant_details['forename'].' '.$participant_details['surname'];
		}

		$this->mailData['doneDescription'] = $this->actionData['doneDescription'];
		$this->mailData['actionDescription'] = $this->actionData['actionDescription'];

		$this->organigramobj->setItemInfo(array('id'=>$this->mailData['bu_id']));
		$bu_data  =  $this->organigramobj->displayItemById();

		$this->mailData['buname'] = $bu_data['buName'];
		$this->mailData['doneDate'] = format_date($this->actionData['doneDate']);
		$this->mailData['dueDate'] = format_date($this->actionData['dueDate']);

		return $this->mailData;
	}


	/* method is used to get Nhpmail data */

	private function nhpEmail() {

		$moduleClassobj = new NhpMain();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}

	/* method is used to get ManualHandlingmail data */

	private function manualHandlingEmail() {

		$moduleClassobj = new ManualHandling();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}

	/* method is used to get Incidencemail data */

	private function incidenceEmail() {

		$moduleClassobj = new IncidenceMain();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}

	/* method is used to get Incidencemail data */

	private function investigationEmail() {

		$moduleClassobj = new InvestigationMain();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}

	/* method is used to get NHC iNvestigation data */

	private function nhc_investigationEmail() {

		$moduleClassobj = new NhcInvestigationMain();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}

	/* method is used to get Incidencemail data */

	private function risk27kEmail() {

		$moduleClassobj = new Risk27k();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}
	private function riskEmail() {

		$objRisk = new RiskAssessment();
		$this->mailData = $objRisk->getEmailData($this->recordId);
	}

	/* method is used to get Incidencemail data */

	private function manualhandlingtaskEmail() {

		$moduleClassobj = new ManualHandling();
		$this->mailData = $moduleClassobj->getActionTrackerEmailData($this->recordId);
		//echo $this->recordId;
		//dump_array($this->mailData);exit;
	}

	private function dseEmail() {

		$objDSE = new DseAssessment();
		$this->mailData = $objDSE->getActionMailData($this->recordId);
		//dump_array($this->mailData);
	}

	private function inspectionEmail() {

		$objDSE = new InspectionMain();
		$this->mailData = $objDSE->getActionMailData($this->recordId);
		//dump_array($this->mailData);
	}
	private function contractreviewEmail() {

		$objDSE = new contract();
		$this->mailData = $objDSE->getActionMailData($this->recordId);
		//dump_array($this->mailData);
	}
}
?>