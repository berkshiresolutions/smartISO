<?php
 /**
  $Id: EmailBase.abs.php,v 3.03 Saturday, August 14, 2010 6:10:21 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:50:14 PM>
  */

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 *
 * @abstract
 */

abstract class EmailBase {

	protected $template_metadata;

	public function template($p_mailtemplate) {

		$arr = explode('_',$p_mailtemplate);
		$count_arr = count($arr);

		if ( $count_arr > 1 ) {
			foreach ( $arr as $arrele ) {
				$arrsuffix = ucfirst($arrele);
			}

			$tmpname = $arr[0].$arrsuffix;
			$template_file = $tmpname.'.mail.tmpl';

			require_once _MAILTEMPLATES.$template_file;

			$this->template_metadata['template_content'] = $mailtemplate;

		} else {
			die("Invalid template");
		}

		$this->template_metadata['template_file'] = $template_file;
	}
}
