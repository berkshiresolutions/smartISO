<?php
 /**
  $Id: EmailData.class.php,v 3.10 Tuesday, February 01, 2011 2:39:37 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Email
  * @since  Monday, August 16, 2010 6:12:37 PM>
  */

class EmailData
{

	private $moduleObj;

	public function __construct($p_module) {

		// riskModEmail.class.php
		$classname = $p_module.'ModEmail';
		require_once _MYCLASSES.'email/'.$classname.".class.php";

		$this->moduleObj = new $classname();
	}

	public function getData($p_record_id='') {

        $data =  $this->moduleObj->getData($p_record_id);
		$this->moduleObj = null;

		return $data;
	}
}