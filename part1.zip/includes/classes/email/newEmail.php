<?php 
//bob
require_once _VENDOR_SMARTY."Smarty.class.php";

class newEmail {
	
	protected $smarty;
	
	protected $emailTitle;
	protected $emailColour;
	protected $emailTxtColour;
	protected $heading;
	protected $twoColData;
	protected $singleColData;
	protected $rawData;
	protected $contact;
	protected $textcss;
	protected $datefmt;
	protected $sentence;
	protected $videoUrl;
	/*protected $ref;
	protected $make;
	protected $model;
	protected $p;
	protected $t;
	protected $f;
	protected $name;
	protected $descp;
	protected $mileage;
	protected $id;
	protected $type;
	protected $fre;*/
	
	public function __construct($details=null) {
		$this->smarty = new Smarty;
		$this->smarty->template_dir = _THEME_FOLDERPATH._THEME.'/templates';
		$this->smarty->compile_dir = _THEME_FOLDERPATH._THEME.'/templates_c';
		//$smarty->cache_dir = _THEME_FOLDER._THEME.'/cache';
		$this->smarty->config_dir = _MYINCLUDES.'/smarty_configs';
		
		if($details === null) {
			$details = $this->getDefaultData();
		}
		
		$this->setDetails($details);
	}
	
	public function getDefaultData() {
		return array(
			'emailTitle'=>'smart-ISO&trade; Mail ',				// DEFAULT
			'emailColour'=>'#404040',		// GREY was #808080
			'emailTxtColour'=>'#FFFFFF',	// WHITE
			'heading'=>'smart-ISO&trade; Mail ',					// BLANK
			'twoColData'=>array(),			// EMPTY
			'singleColData'=>array(),		// EMPTY
			'rawData'=>array(),				// EMPTY
			'contact'=>'',					// BLANK
			'textcss'=>'table { max-width: 800px; } table tbody { min-height: 200px; } table td[colspan="7"] { width: 50%; }',					// BLANK
			'datefmt'=>'d/m/Y',				// EUROPEAN
			'sentence'=>''
		);
	}
	
	public function setDetails($details) {
		if(is_array($details)) {
			foreach($details as $key=>$detail) {
				$this->setDetail($key,$detail);
			}
		}
		return $this;
	}
	
	public function appendDetail($key,$detail) {
		 if(property_exists($this,$key)) {
			if(is_string($this->$key) && is_string($detail)) {
				$this->$key .= $detail;
			}
			if(is_numeric($this->$key) && is_numeric($detail)) {
				$this->$key += $detail;
			}
			if(is_array($this->$key) && is_array($detail)) {
				array_push($this->$key, $detail);
			}
		 }
		 return $this;
	}
	
	public function setDetail($key,$detail) {
		if(property_exists($this,$key)) {
			$this->$key = $detail;
		}
		return $this;
	}
	
	public function getDetail($key) {
		if(property_exists($this,$key)) {
			return $this->$key;
		}
		return null;
	}
	
	public function display($details) {
		$this->setDetails($details);
		$this->smarty->assign('emailTitle',$this->emailTitle);				// E-mail HTML title
		$this->smarty->assign('emailColour',$this->emailColour);			// E-mail Background heading Colour
		$this->smarty->assign('emailTxtColour',$this->emailTxtColour);		// E-mail Text heading Colour
		$this->smarty->assign('heading',$this->heading);					// Heading
		$this->smarty->assign('twoColData',$this->twoColData);				// Two column data
		$this->smarty->assign('singleColData',$this->singleColData);		// Single column data
		$this->smarty->assign('rawData',$this->rawData);
		$this->smarty->assign('textcss',$this->textcss);					// Text/CSS
		$this->smarty->assign('date',date($this->datefmt));					// Date
		$this->smarty->assign('year',date('Y'));							// Automatic
		$this->smarty->assign('domain',$_SERVER['SERVER_NAME']);			// Automatic
		$this->smarty->assign('sentence',$this->sentence);					// Blank by default
		return $this->smarty->fetch('email.tpl');
	}
        
        public function displayVideo($details) {
		$this->setDetails($details);
		$this->smarty->assign('emailTitle',$this->emailTitle);				// E-mail HTML title
		$this->smarty->assign('emailColour',$this->emailColour);			// E-mail Background heading Colour
		$this->smarty->assign('emailTxtColour',$this->emailTxtColour);		// E-mail Text heading Colour
		$this->smarty->assign('heading',$this->heading);					// Heading
		$this->smarty->assign('videoUrl',$this->videoUrl);					// link to video
		$this->smarty->assign('twoColData',$this->twoColData);				// Two column data
		$this->smarty->assign('singleColData',$this->singleColData);		// Single column data
		$this->smarty->assign('rawData',$this->rawData);
		$this->smarty->assign('textcss',$this->textcss);					// Text/CSS
		$this->smarty->assign('date',date($this->datefmt));					// Date
		$this->smarty->assign('year',date('Y'));							// Automatic
		$this->smarty->assign('domain',$_SERVER['SERVER_NAME']);			// Automatic
		$this->smarty->assign('sentence',$this->sentence);					// Blank by default
		return $this->smarty->fetch('emailv.tpl');
	}

}