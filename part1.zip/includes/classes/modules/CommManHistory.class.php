<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class CommManHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'comms_mangement';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _comms_mangement() {

		$tablename 				= 'comms_mangement';
		$tablename_historical 	= $tablename.'_historical';

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (ID,
	reference,
	uniqueReference,
	date_r,
	client,
	date_u,
	process_r,
	title,
	country,
	type,
	action_r,
	who,
	what,
	whe,
	received,
	company,
	document_n,
	descp,
	related,
	bu,
	document_c,
	d_id,
	drop_n,
	archive,
	country_from,
	completed,
	audit,
	induct,
	business,
	media_type,
	holding_place,
	loc,
	in_out,
	distribute,
	owner,
	custodian_process,
	location,
	last_version,
	whox,
	media_type_str,
	comments,
	archive_date,
	criteria,
	docdate,
        sub_ref
					
					   )
						SELECT
											   ID,
	reference,
	uniqueReference,
	date_r,
	client,
	date_u,
	process_r,
	title,
	country,
	type,
	action_r,
	who,
	what,
	whe,
	received,
	company,
	document_n,
	descp,
	related,
	bu,
	document_c,
	d_id,
	drop_n,
	archive,
	country_from,
	completed,
	audit,
	induct,
	business,
	media_type,
	holding_place,
	loc,
	in_out,
	distribute,
	owner,
	custodian_process,
	location,
	last_version,
	whox,
	media_type_str,
	comments,
	archive_date,
	criteria,
	docdate,
        sub_ref
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
	}
}
?>