<?php
 /**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */
 set_time_limit(180);
class ActionTracker
{

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	private $identifier;

	private $moduleInfo;

	private $module;

	private $actionHandler;

	private $moduleHandler;
	private $dateFilter;

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandler	= new Action();
	}

	/*
	 * to set risk assessment information for performing various operations with an risk assessment object
	 */
	public function setActionTrackerInfo($p_moduleName,$p_tabType,$p_dateFilter='') {

		$this->identifier 			= $p_tabType;
		$this->module 				= $p_moduleName;
		$this->dateFilter			= $p_dateFilter;

		if ( $this->module == '' ) {
			throw new ErrorException("Please specify module to get actions from.");
		} else if ( $this->identifier == '' ) {
			throw new ErrorException("Please specify module tab to get actions for.");
		} else if ( $this->identifier != 'me_pending' && $this->identifier != 'me_completed' && $this->identifier != 'other_pending' && $this->identifier != 'other_completed' ) {
			throw new ErrorException("Invalid tab identifier.");
		} else {

			$classname 	= 'ActionTracker'.str_replace(' ','',ucwords(strtolower($this->module)));

			// Exception starts here
			if ( $classname == 'ActionTrackerInspectionCcp' ) {

				$classname = 'ActionTrackerInspection';
				$this->module = 'inspectionC';

			} else if ( $classname == 'ActionTrackerInspectionHazard' ) {

				$classname = 'ActionTrackerInspection';
				$this->module = 'inspectionH';

			} else if ( $classname == 'ActionTrackerInspectionManagement' ) {

				$classname = 'ActionTrackerInspection';
				$this->module = 'inspectionM';

			} else if ( $classname == 'ActionTrackerInspectionRisk' ) {

				$classname = 'ActionTrackerInspection';
				$this->module = 'inspectionR';
			} else if ( $classname == 'ActionTrackerNonconformanceInc' ) {

				$this->module = 'incidence';

			} else if ( $classname == 'ActionTrackerNonconformanceDi' ) {

				$this->module = 'investigation';

			} else if ( $classname == 'ActionTrackerNonconformanceNhp' ) {

				$this->module = 'nhp';

			} else if ( $classname == 'ActionTrackerManualhandlingTask' ) {

				$this->module = 'manual_handlingT';

			} else if ( $classname == 'ActionTrackerManualhandlingLoad' ) {

				$this->module = 'manual_handlingL';

			} else if ( $classname == 'ActionTrackerManualhandlingEnv' ) {

				$this->module = 'manual_handlingE';

			} else if ( $classname == 'ActionTrackerManualhandlingInd' ) {

				$this->module = 'manual_handlingI';

			} else if ( $classname == 'ActionTrackerContributor' ) {

				$this->module = 'contributor';

			} else if ( $classname == 'ActionTrackerNhcInv' ) {

				$this->module = 'nhcInvestigation';

			} else if ( $classname == 'ActionTrackerGapAct' ) {

				$this->module = 'msr_action';

			} /*else if ( $classname == 'ActionTrackerDocControl' ) {

				$this->module = 'doc_control';
			} */
			// Exception ends here

			if ( !file_exists(_MYPRIVATECLASSES.'modules/'.$classname.'.class.php') ) {
				throw new ErrorException("Failed to load class '".$classname."'.");
			}

			$this->moduleHandler		= new $classname( $this->dbHand, $this->actionHandler->viewAllActionByModule($this->module,false,$this->dateFilter));
			//$this->moduleHandler		= new $classname( $this->dbHand, $this->actionHandler->viewAllActionByModule($this->module,false));
		}
	}

	public function getActionsForActionTracker() {

		if ( $this->module == 'contributor' || $this->module == 'doc_control' ) {
			return $this->getPendingMeActions();
		} else {

			switch($this->identifier) {
				case 'me_pending': return $this->getPendingMeActions(); break;
				case 'me_completed': return $this->getCompletedMeActions(); break;
				case 'other_pending': return $this->getPendingOtherActions(); break;
				case 'other_completed': return $this->getCompletedOtherActions(); break;
			}
		}
	}

	private function getPendingMeActions() {
		return $this->moduleHandler->getPendingMeActions();
	}

	private function getCompletedMeActions() {
		return $this->moduleHandler->getCompletedMeActions();
	}

	private function getPendingOtherActions() {
		return $this->moduleHandler->getPendingOtherActions();
	}

	private function getCompletedOtherActions() {
		return $this->moduleHandler->getCompletedOtherActions();
	}

	public function saveActionInformation($p_actionId,$p_doneDate,$p_comment) {

		$sql = sprintf("UPDATE %s.actions
				SET
				doneDate = '%s',
				doneDescription = '%s'
				WHERE ID = %d",_DB_OBJ_FULL,$p_doneDate,$p_comment,$p_actionId);

		$stmt = $this->dbHand->prepare($sql);

		if ( !$stmt->execute() ) {
			$error_info = $stmt->errorInfo();
			throw new ErrorException($error_info[2],$error_info[1]);
		} else {

			$this->actionHandler->setActionDetails($p_actionId,array());
			$action_data = $this->actionHandler->viewAction();

			/* Exception for msr actions */
			if ( $action_data['moduleName'] == 'msr_action' ) {
				$action_data['moduleName'] = 'MSR Action';

				$revGapObj = new ReviewGap();
				$msr_action_data = $revGapObj->sendActionAlerts($p_actionId);
				$p_reviewID = $revGapObj->getReviewIdFromAction($p_actionId);
				$revGapObj = null;

				$revobj = new ReviewMain();
				$review_data = $revobj->getReviewInfo($p_reviewID);
				$revobj = null;

				$action_data['question'] 		= $msr_action_data[0]['question'];
				$action_data['reference'] 		= $msr_action_data[0]['reference'];
				$action_data['recommendation'] 	= $msr_action_data[0]['recommendation'];
				$action_data['review_type'] 	= $msr_action_data[0]['review_type'];
				$action_data['bu_name'] 		= $review_data['buName'];

				$template_identifier = 'MSRACTION_ACTION_DONE';
			} else {
				$template_identifier = 'INVESTIGATION_ACTION_DONE';
			}

			$action_data['FULLHOSTNAME'] = _MYSERVER;
			$action_data['dueDate'] = format_date($action_data['dueDate']);
			$action_data['doneDate'] = format_date($action_data['doneDate']);
			$action_data['email_subject'] = "Action approval required";

			$objEmail = new Email('html');
			$participantObj	= SetupGeneric::useModule('Participant');

			if ( $action_data['whoAU'] ) {

				$participantObj->setItemInfo(array('id'=>$action_data['whoAU']));
				$participantData = $participantObj->displayItemById();

				$participantObj->setItemInfo(array('id'=>$action_data['who']));
				$participantDataWho = $participantObj->displayItemById();

				$salutation = trim($participantData['gender']) == 'F' ? 'Ms' : 'Mr.' ;
				$mail_address = $participantData['emailAddress'];
				$name = $participantData['forename'].' '.$participantData['surname'];

				$action_data['who'] = $participantDataWho['forename'].' '.$participantDataWho['surname'];

				if ( $mail_address!= '' ) {
					try {
						$objEmail->addRecipient($name,$mail_address,$salutation);
						$objEmail->generateEmailFromData($template_identifier,$action_data);
						$objEmail->send(_LIVE_MODE);
					} catch (ErrorException $e) {
						$e->getMessage();
					}
				}

			}
		}
	}

	public function approveCompletedAction($p_actionId) {

		$approve = 1;

		$sql = sprintf("UPDATE %s.actions
				SET
				approve = '%s'
				WHERE ID = %d
				AND doneDate IS NOT NULL",_DB_OBJ_FULL,$approve,$p_actionId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$approve);
		$stmt->bindParam(2,$p_actionId);*/

		if ( !$stmt->execute() ) {
			$error_info = $stmt->errorInfo();
			throw new ErrorException($error_info[2],$error_info[1]);
		}
	}

	public function approveAUApprovedAction($p_actionId) {

		$au_approve = 1;

		$sql = sprintf("UPDATE %s.actions
				SET
				approveAU = '%s'
				WHERE ID = %d
				AND doneDate IS NOT NULL",_DB_OBJ_FULL,$au_approve,$p_actionId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$approve);
		$stmt->bindParam(2,$p_actionId);*/

		if ( !$stmt->execute() ) {
			$error_info = $stmt->errorInfo();
			throw new ErrorException($error_info[2],$error_info[1]);
		} else {

			/*$this->actionHandler->setActionDetails($p_actionId,array());
			$action_data = $this->actionHandler->viewAction();

			$objEmail = new Email('html');
			$participantObj	= SetupGeneric::useModule('Participant');

			$participantObj->setItemInfo(array('id'=>$action_data['whoAU']));
			$participantData = $participantObj->displayItemById();

			if ( count($participantData) && $participantData!= '' ) {

				$salutation = trim($participantData['gender']) == 'F' ? 'Ms' : 'Mr.' ;
				$mail_address = $participantData['emailAddress'];
				$name = $participantData['forename'].' '.$participantData['surname'];

				if ( $mail_address!= '' ) {
					try {
						$objEmail->addRecipient($name,$mail_address,$salutation);
						$objEmail->generateEmail('INVESTIGATION_ACTION_DONE',$email_data);
						$objEmail->send(_LIVE_MODE);
					} catch (ErrorException $e) {
						$e->getMessage();
					}
				}

			}*/
		}
	}
}