<?php
 /**
  $Id: Comm.int.php,v 3.03 Monday, October 11, 2010 12:43:15 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage comm object
  *
  * This interface will declare the various methods performed
  * by the comm object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface QuestionInterface
{
	/*
	 * to set comm information for performing various operations with the comm object
	 */
	public function setQuestInfo($p_questId,$p_questInfo);

	/*
	 * This method is used to add a new comm
	 */
	public function addQuest();

	/*
	 * This method is used to view comm information.
	 */
	public function viewQuest($id);

	/*
	 * This method is used to edit a comm
	 */
	public function editQuest($id);







}