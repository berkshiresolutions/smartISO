<?php

/**
  $Id: Complaint.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, October 09, 2010 12:50:41 PM>
 */
require "Compliance.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/infoEmail.php';

class Compliance implements ComplianceInterface {

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Complaint Id
     * @access private
     */
    private $complianceId;

    /**
     * Property to hold Complaint Info
     * @access private
     */
    private $complianceInfo;

    /**
     * Constructor for initializing Manual Handling object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /**
     * to set complaint information for performing various operations with the complaint object
     * @param integer This parameter holds the complaint Id
     * @param array This parameter holds the the complaint Info
     */
    public function setComplianceInfo($p_complianceId, $p_complianceInfo) {

        $this->complianceId = $p_complianceId;
        $this->complianceInfo = $p_complianceInfo;
    }

    /**
     * This method is used to add a new complaint
     * reference,unique_reference,location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
     * address,phone,email,complaint_nature,likelihood,impact,risk_rating,risk_color,complaint_category,investigation,action,who,when
     */
    public function addCompliance() {
        $USER_ID = getLoggedInUserId();
        $date = date("m/d/Y"); //todo should be calculated
//        $template = $this->getTemplatebyTTP($this->complianceInfo["ttype"], $this->complianceInfo["country"]);
//        $this->complianceInfo["template"] = $template["ID"];
        //  $sql = sprintf("SELECT M.* FROM %s.compliance_master  M inner join %s.compliance_period P on M.period=P.ID ",_DB_OBJ_FULL, _DB_OBJ_FULL);
        $sql = sprintf("INSERT INTO %s.compliance_master(auditorID,startTime,period,is_complete,current_question,archive,reference,auditlink,description,template ) values (%d,'%s',%d,0,0,0,'%s','0','%s',%d )", _DB_OBJ_FULL, $USER_ID, $date, $this->complianceInfo["period"], $this->complianceInfo["reference"], $this->complianceInfo["descript"], $this->complianceInfo["country"]);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $this->complianceId = customLastInsertId($this->dbHand, 'compliance_master', 'reviewID');


        return $this->complianceId;
    }

    /**
     * This method is used to view complaint information.
     */
    public function viewCompliance() {

        $sql = sprintf("SELECT * FROM %s.compliance_data WHERE ID = %d ", _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    /**
     * This method is used to edit a complaint
     * location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
     * address,phone,email,complaint_nature,likelihood,impact,risk_rating,risk_color,complaint_category,investigation,action,who,when
     */
    public function editCompliance() {

        $sql = sprintf("UPDATE %s.complaint SET locationId = ?,
										considerRisk = ?,
										complaintDescription = ?,
										isPhone = ?,
										isFax = ?,
										isPerson = ?,
										isEmail = ?,
										isLetter = ?,
										firstName = ?,
										lastName = ?,
										relationshipClient = ?,
										address = ?,
										phoneNumber = ?,
										emailAddress = ?,
										complaintNature = ?,
										likelihood = ?,
										impact = ?,
										riskRating = ?,
										riskRatingColor = ?,
										complaintCategory = ?,
										isInvestigation = ?
								WHERE ID = ?", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
    }

    /**
     * This method is used to delete a complaint
     */
    public function deleteCompliance() {
        
    }

    /**
     * This method is used to archive a complaint
     */
    public function archiveCompliance() {
        $sql = sprintf("update %s.compliance_master set archive=1 WHERE reviewID = %d", _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to remove a complaint
     */
    public function purgeCompliance() {
        
    }

    /**
     * This method is used to last insertted record Id
     */
    public function lastrecordId() {
        return $this->complianceId;
    }

    /**
     * This method is used to view all complaints.
     */
    public function viewAllCompliance() {

        $sql = sprintf("SELECT D.* FROM %s.comppliance_data D left join co", _DB_OBJ_FULL);
        $sql = sprintf("select D.*,H.Main_Heading,P.period from %s.compliance_data D left join %s.compliance_period P on D.Period=P.ID inner join %s.compliance_main_hdr H on D.Heading=H.ID", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewAll() {

        $sql = sprintf("SELECT M.*,P.period,TT.template_type,T.title FROM %s.compliance_master  M inner join %s.compliance_period P on M.period=P.ID inner join %s.compliance_templates T on M.template=T.ID inner join %s.compliance_template_type TT on T.template_type=TT.ID where isnull(is_complete,0)=0 and isnull(M.archive,0)=0 ORDER BY reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewClosed() {

        $sql = sprintf("SELECT M.*,P.period,TT.template_type,C.country FROM %s.compliance_master  M inner join %s.compliance_period P on M.period=P.ID inner join %s.compliance_templates T on M.template=T.ID inner join %s.compliance_country C on T.country=C.ID  inner join %s.compliance_template_type TT on T.template_type=TT.ID where is_complete=1 and isnull(M.archive,0)=0 ORDER BY reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getMasterbyID() {

        $sql = sprintf("SELECT * FROM %s.compliance_master M inner join %s.compliance_templates T on M.template=T.ID where reviewID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewAllArchived() {

        $sql = sprintf("SELECT M.*,P.period,T.title  FROM %s.compliance_master  M inner join %s.compliance_period P on M.period=P.ID  inner join %s.compliance_templates T on M.template=T.ID where isnull(is_complete,0)=0 and M.archive=1 ORDER BY reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewComplianceArchived() {

        $sql = sprintf("SELECT M.*,P.period,T.title  FROM %s.compliance_master  M inner join %s.compliance_period P on M.period=T.ID  inner join %s.compliance_templates T on M.template=P.ID where is_complete=1 and M.archive=1 ORDER BY reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getPeriod() {

        $sql = sprintf(" select * from %s.compliance_period order by ordering", _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getOffsetData() {

        $sql = sprintf(" select * from %s.compliance_offset where archive=0 order by offset_text", _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getOffsetDataByID($id) {

        $sql = sprintf(" select * from %s.compliance_offset where id=%d", _DB_OBJ_FULL, $id);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getCountry() {

        $sql = sprintf(" select * from %s.compliance_country order by country", _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getCountrybyID($id) {

        //$sql = sprintf(" select * from %s.compliance_country where ID=%d", _DB_OBJ_FULL,$id);

        $sql = sprintf(" select * from %s.compliance_templates where ID=%d", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getPeriodbyID($id) {

        $sql = sprintf(" select * from %s.compliance_period where id=%d", _DB_OBJ_FULL, $id);


        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getCountryfromTemplate($id) {

        $sql = sprintf(" select C.* from %s.compliance_country C inner join %s.compliance_templates T on C.ID=T.country where T.id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);


        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getTypefromTemplate($id) {
        $sql = sprintf(" select TT.* from %s.compliance_template_type TT inner join %s.compliance_templates T on TT.ID=T.template_type where T.id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);


        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getTemplates() {

        $sql = sprintf(" select T.ID,T.title,TT.template_type,C.country  from %s.compliance_templates T left join %s.compliance_template_type TT on T.template_type=TT.ID left join %s.compliance_country C on T.country=C.ID where isnull(T.archive,0)=0 order by title", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getTemplatesA() {

        $sql = sprintf("T.*,C.template_type T from %s.compliance_templates left join %s.compliance_template_type C on T.template_type=C.ID where T.archive=1 order by title", _DB_OBJ_FULL, _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getChecklist($period, $template, $country) {
        $periodStr = "0";
        for ($x = 1; $x <= $period; $x++) {
            $periodStr .= "," . $x;
        }

        $sql = sprintf("SELECT D.*,P.period,H.Main_Heading,W.forename+' '+W.surname as who1,W1.forename +' '+W1.surname as who2 FROM %s.compliance_data D left join %s.compliance_period P on D.period=P.ID left join %s.compliance_main_hdr H on D.heading=H.ID left join %s.participant_database W on D.who=W.participantID left join %s.participant_database W1 on D.whoro=W1.participantID left join %s.compliance_templates T on D.template=T.ID  where isnull(D.archive,0)=0 and template_type=%d and T.ID=%d and D.period in (%s)", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $template, $country, $periodStr);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function updateChecklist($id, $who, $who1) {



        $sql = sprintf("update  %s.compliance_data set who=%d,whoro=%d where  id=%d", _DB_OBJ_FULL, $who, $who1, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getQuestions($id) {
        $sql = sprintf("SELECT D.*,A.whoID as whoRequired,A.stagedone,A.trail,A.filestr,A.occurencedate,P.period,H.Main_Heading,W.forename,W.surname,A.ID as questID,A.compliance,A.compliance_answer,A.fileID,A.whendate,ACT.* FROM %s.compliance_answer A inner join %s.compliance_data D on A.questionID=D.ID left join %s.compliance_period P on D.period=P.ID left join %s.compliance_main_hdr H on D.heading=H.ID left join %s.participant_database W on A.whoID=W.participantID  left join %s.actions ACT on A.ID=ACT.record      where isnull(D.archive,0)=0 and  isnull(A.whoID,0)>0 and A.complianceID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getPeriodQuestions($id, $period = 1) {
        $sql = sprintf("SELECT D.*,H.main_heading,W.forename+' '+W.surname as who1 FROM %s.compliance_data D left join %s.compliance_main_hdr H on D.heading=H.ID left join %s.participant_database W on D.who=W.participantID  where  isnull(D.archive,0)=0 and D.template =%d  and D.period=%d ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id, $period);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function updateQuestion($id, $data, $date, $compliance, $fileid, $filestr, $dateO) {

        $sql = sprintf("update %s.compliance_answer set compliance_answer='%s',whendate='%s', compliance=%d,fileid=%d,stagedone=1,filestr='%s',occurencedate='%s'  where ID=%d", _DB_OBJ_FULL, $data, $date, $compliance, $fileid, $filestr, $dateO, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function buildQuestionList($id) {
        $periodStr = "0";
        $period = $this->complianceInfo["period"];

        for ($x = 1; $x <= $period; $x++) {
            $periodStr .= "," . $x;
        }

        $sql = sprintf("insert into %s.compliance_answer (questionid,complianceid,whoID) select Id,%d,who from %s.compliance_data where Period in (%s) and archive=0 and template=%d", _DB_OBJ_FULL, $id, _DB_OBJ_FULL, $periodStr, $this->complianceInfo["country"]);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getTemplatebyTTP($ttid, $cid) {
        $sql = sprintf("SELECT * FROM %s.compliance_templates  where  template_type=%d and country=%d", _DB_OBJ_FULL, $ttid, $cid);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        return $result = $pStatement->fetch(PDO::FETCH_ASSOC);
    }

    public function sendMail($id) {



        $periodArr = array(1 => 'Monthly', 2 => 'Bi- Monthly', 3 => 'Quarterly', 4 => 'Annually', 5 => 'Bi - Annually', 6 => 'Semi - Annually', 7 => 'Tri - Annually');
        $sql = sprintf("select *,A.ID as answerID from %s.compliance_answer A inner join %s.compliance_data D on A.questionID=D.ID inner join %s.compliance_master M on A.complianceID=M.reviewID inner join %s.compliance_main_hdr H on D.heading=H.ID where complianceID  =%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $row) {
            $date = new DateTime(date("Y-m-d", strtotime("last day of previous month")));

            date_add($date, date_interval_create_from_date_string($row["dateoffset"] . ' days'));

            $report_date = $date->format('m/d/Y');
            $date1 = new DateTime(date("Y-m-d", strtotime("last day of previous month")));
            date_add($date1, date_interval_create_from_date_string('20 days'));
            if ($row["dateoffset"] > 20) {
                date_add($date1, date_interval_create_from_date_string('1 month'));
            }
            $due_date = $date1->format('m/d/Y');

            $sql2 = sprintf("INSERT INTO %s.actions(
                              				moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
							VALUES('template','%s','%d','$due_date','%d',1,'%d',%d,'compliance_answer'
							)", _DB_OBJ_FULL, $row["Description"], $row["who"], $row["who"], $row["who"], $row["answerID"]
            );

            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();

            $this->Id = customLastInsertId($this->dbHand, 'actions', 'ID');

            $sql2 = sprintf(" UPDATE %s.compliance_answer SET
						
						actionID = '$this->Id'
						
				
						WHERE ID = %d", _DB_OBJ_FULL, $row["answerID"]);

            $pStatement2 = $this->dbHand->prepare($sql2);
            $pStatement2->execute();


            $emailObj = new actionEmailHelper($this->Id);
            $who = $emailObj->getwhoDetails();

            $data = array(
                'singleColData' => array(
                    'comment' => '<BR>'
                    ,
                    'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/compliance.php?filter_date=">CLICK</a> Here to View Compliance Action<BR><BR>
                Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/compliance/add_edit.php?id=' . $this->complianceId . '">CLICK</a> here to answer to this action',
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $row["reference"]
                    ),
                    'datetext' => array(
                        'left' => '<strong>Date Info</strong>',
                        'right' => $row["datetext"]
                    ),
                    'period' => array(
                        'left' => '<strong>Period</strong>',
                        'right' => $periodArr[(int) $row["period"]]
                    ),
                    'rptdate' => array(
                        'left' => '<strong>Report Date</strong>',
                        'right' => $report_date
                    ),
                    'heading' => array(
                        'left' => '<strong>Heading</strong>',
                        'right' => $row["Main_Heading"]
                    )
                )
            );


            $emailObj->appendInfo($data);

            $emailObj->sendEmail('A Compliance  Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
        }
    }

    public function finish($p_review_id) {

        $sql = sprintf("UPDATE %s.compliance_master
				SET is_complete = '1',
				endTime = " . customCurrentDate() . "
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_review_id);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        //todo   $this->sendActionEmails($p_review_id);
    }

    public function getTypes() {

        $sql = sprintf("SELECT * FROM %s.compliance_template_type where archive=0 order by ID desc", _DB_OBJ_FULL);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTypesA() {

        $sql = sprintf("SELECT * FROM %s.compliance_template_type where archive=1 order by ID desc", _DB_OBJ_FULL);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function viewRegisterAll() {

        $sql = sprintf("SELECT * FROM %s.compliance_report_reg_master  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function addComplianceregister() {

        $sql = sprintf("INSERT INTO %s.compliance_report_reg_master(Reportdate,reportfor,reference ) values ('%s','%s','%s')", _DB_OBJ_FULL, $this->complianceInfo["rmonth"], $this->complianceInfo["rfor"], $this->complianceInfo["reference"]);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $this->complianceId = customLastInsertId($this->dbHand, 'compliance_report_reg_master', 'ID');

        return $this->complianceId;
    }

    public function editComplianceregister() {

        $sql = sprintf("update %s.compliance_report_reg_master set Reportdate='%s',reportfor='%s',reference='%s' where id=%d", _DB_OBJ_FULL, $this->complianceInfo["rmonth"], $this->complianceInfo["rfor"], $this->complianceInfo["reference"], $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getReporthdr($id) {

        $sql = sprintf("SELECT * FROM %s.compliance_report_reg_master where id=%d ORDER BY ID DESC", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getReportview($id) {

        $sql = sprintf("SELECT * FROM %s.compliance_register_data where  masterID=%d  ORDER BY ID ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function removedata($id) {

        $sql = sprintf("delete from %s.compliance_register_data where masterid=%d", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function savedata() {

        $sql = sprintf("INSERT INTO %s.compliance_register_data(masterID,month,concern,status,register_updated,regorder ) values (%d,'%s','%s','%s','%s',%d)", _DB_OBJ_FULL, $this->complianceInfo["id"], $this->complianceInfo["month"], $this->complianceInfo["concern"], $this->complianceInfo["status"], $this->complianceInfo["rupd"], $this->complianceInfo["order"]);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function copyComplianceregister($newID, $lastID) {
        $sql = sprintf("insert into  %s.compliance_register_data (masterID,month,concern,status,register_updated,regorder) select %d,month,concern,status,register_updated,regorder from %s.compliance_register_data where masterID=%d", _DB_OBJ_FULL, $newID, _DB_OBJ_FULL, $lastID);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function restoreRecord() {
        $sql = sprintf("update %s.compliance_master set archive=0 WHERE reviewID = %d", _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getCountryData($ttype) {

        $sql = sprintf("select * from %s.compliance_templates T  where template_type=%d and isnull(archive,0)=0 order by title", _DB_OBJ_FULL, $ttype);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getCheckData0($cID) {

        $userID = getLoggedInUserId();

        $sql = sprintf("select COUNT(A.ID) as results from %s.compliance_answer A inner join %s.compliance_data D on A.questionID = D.ID where A.complianceID=%d and D.who = %d and isnull(A.whoID,0)=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $cID, $userID);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result["results"];
    }

    public function getHeadings() {

        $sql = sprintf(" select * from %s.compliance_main_hdr  where archive=0 order by Main_heading", _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getHeadingsA() {

        $sql = sprintf(" select * from %s.compliance_main_hdr  where archive=1 order by Main_heading", _DB_OBJ_FULL);



        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function addHeadingsItem() {
//INSERT dbSmartAlpha.dbo.compliance_main_hdr (Main_Heading) VALUES ('Income Tax Acthggfhfghh')
        $sql = sprintf("INSERT INTO %s.[compliance_main_hdr] ([Main_Heading]) VALUES ('%s')", _DB_OBJ_FULL, $this->complianceInfo["title"]);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function addComplianceItem() {
//INSERT dbSmartAlpha.dbo.compliance_main_hdr (Main_Heading) VALUES ('Income Tax Acthggfhfghh')
        $sql = sprintf("INSERT INTO %s.[compliance_template_type] (template_type,reference) VALUES ('%s','%s')", _DB_OBJ_FULL, $this->complianceInfo["title"], $this->complianceInfo["ref"]);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $id = customLastInsertId($this->dbHand, 'compliance_template_type', 'ID');
        return $id;
    }

    public function updateHeading($id) {
        $sql = "UPDATE %s.compliance_main_hdr SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function restoreHeading($id) {
        $sql = "UPDATE %s.compliance_main_hdr SET archive = 0 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function restoreTemplate($id) {
        $sql = "UPDATE %s.compliance_template_type SET archive = 0 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function updateTemplate($id) {
        $sql = "UPDATE %s.compliance_template_type SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function getTemplateByID($id) {
        $sql = "select * from %s.compliance_template_type WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($psql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function copyTemplate($newid, $id) {
        $sql = "select * from %s.compliance_templates WHERE template_type = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($psql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $row) {
           $sql2 = sprintf("INSERT INTO %s.compliance_templates(title,detail,country,template_type)
							VALUES('%s','%s',%d,%d)", _DB_OBJ_FULL, $row["Title"], $row["detail"], $row["country"], $newid);

            $pStatement2 = $this->dbHand->prepare($sql2);
            $pStatement2->execute();
            $this->Id = customLastInsertId($this->dbHand, 'compliance_templates', 'ID');
            $sql3 = sprintf("INSERT INTO %s.compliance_data(Period, heading, Description, datetext, template, who, dateoffset, datatype, whoro, code, penalty) 
                             select Period, heading, Description, datetext, %d, who, dateoffset, datatype, whoro, code, penalty from %s.compliance_data where template=%d"
                    , _DB_OBJ_FULL, $this->Id, _DB_OBJ_FULL, $id);

            $pStatement3 = $this->dbHand->prepare($sql3);
            $pStatement3->execute();
        }
        
    }

    public function archiveTemplate($id) {
        $sql = sprintf("update %s.compliance_template_type set archive=1 WHERE ID = %d", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function linkTemplate($newid, $id) {
        $sql = sprintf("update %s.compliance_template_type set parent_id=%d WHERE ID = %d", _DB_OBJ_FULL, $id, $newid);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getTemplatePartbyID($id) {
        $sql = sprintf("SELECT * FROM %s.compliance_templates  where ID=%d ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        return $result = $pStatement->fetch(PDO::FETCH_ASSOC);
    }

    public function addCompliancePartItem() {
//INSERT dbSmartAlpha.dbo.compliance_main_hdr (Main_Heading) VALUES ('Income Tax Acthggfhfghh')
        $sql = sprintf("INSERT INTO %s.[compliance_templates] (title,detail,template_type,country) VALUES ('%s','%s',%d,'%d')", _DB_OBJ_FULL, $this->complianceInfo["title"], $this->complianceInfo["descript"], $this->complianceInfo["template"], $this->complianceInfo["country"]);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $id = customLastInsertId($this->dbHand, 'compliance_templates', 'ID');
        return $id;
    }

    public function copyPartTemplate($newid, $id) {


        $sql3 = sprintf("INSERT INTO %s.compliance_data(Period, heading, Description, datetext, template, who, dateoffset, datatype, whoro, code, penalty) 
                             select Period, heading, Description, datetext, %d, who, dateoffset, datatype, whoro, code, penalty from %s.compliance_data where template=%d and archive =0"
                , _DB_OBJ_FULL, $newid, _DB_OBJ_FULL, $id);

        $pStatement3 = $this->dbHand->prepare($sql3);
        $pStatement3->execute();
    }

    public function archivePartTemplate($id) {
        $sql = sprintf("update %s.compliance_templates set archive=1 WHERE ID = %d", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function archivedata($template, $period) {
        $sql = sprintf("update %s.compliance_data set archive=1 WHERE template = %d and period=%d", _DB_OBJ_FULL, $template, $period);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function insertnewedata($period, $heading, $Description, $datetext, $template, $who, $offsettype, $days, $datatype, $whoro, $code, $penalty) {
        $sql3 = sprintf("INSERT INTO %s.compliance_data(Period, heading, Description, datetext, template, who, dateoffset, datatype, whoro, code, penalty,offsettype) 
                  VALUES (%d,%d,'%s','%s',%d,%d,%d,'%s',%d,'%s','%s',%d)", _DB_OBJ_FULL, $period, $heading, $Description, $datetext, $template, $who, $days, $datatype, $whoro, $code, $penalty, $offsettype);


        $pStatement3 = $this->dbHand->prepare($sql3);
        $pStatement3->execute();
    }

    public function createTemplates() {
        $objRef = new UniqueReference();
        $month = (int) date("m");

        switch ($month - 1) {
            case 1 :
            case 5 :
            case 7 :
            case 11 :

                $period = 1;
                break;
            case 2 :
            case 4:
            case 8 :
            case 10 :
                $period = 2;
                break;
            case 3 :
            case 9:
                $period = 3;
                break;
            case 6 :
                $period = 4;
                break;
            case 12 :
            case 0 :
                $period = 5;
                break;
            case 13 :
                $period = 6;
                break;
            case 14 :
                $period = 7;
                break;
        }
        $results = $this->getTypes();
        $htmlstr = '';
        foreach ($results as $row) {
            $htmlstr .= $row['reference'] . "  " . $row['template_type'] . "<BR>";

            $data = $this->getCountryData($row['ID']);
            foreach ($data as $row1) {


                $data["reference"] = $objRef->getUniqueNumber('CP');
                $data["country"] = $row1["ID"];
                $data["ttype"] = $row['ID'];
                $data["period"] = $period;
                $data["title"] = $row1["title"];
                $data["descript"] = $row1["descript"];

                $this->setComplianceInfo(0, $data);

                $id = $this->addCompliance();

                $this->buildQuestionList($id);
                $this->sendMail($id);
            }
        }



        $emailObj = new infoEmailHelper();
        $participantObj = SetupGeneric::useModule('Participant');
        $authtObj = SetupGeneric::useModule('AuthorizedUser');
        $partGLOC = $authtObj->getIssuerPermission("PERM_HOC");

        $participantObj->setItemInfo(array('id' => $partGLOC));

        $details = $participantObj->displayItemById();
        $whoGLOC = array(
            'displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']
        );
        $subject = "smart-ISO Compliance Templates.";

        $mergeData = array(
            'twoColData' => array(
                'actionid' => array('left' => '<strong>Information:</strong>', 'right' => 'The following template emails have been sent')),
            'singleColData' => array(
                'summary2' => '<p><strong>Templates</strong><br>' . $htmlstr . '</p>')
        );


        $emailObj->appendInfo($mergeData);

        $emailObj->sendEmail($subject, $whoGLOC, array(), array(), 'me_completed', '', 'grey');
        exit();
    }

    public function getComments($id) {

        $sql = sprintf("SELECT * FROM %s.compliance_template_comments C left join  %s.participant_database P on C.commentwho=P.participantID  WHERE dataID=%d order by ID desc ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($record) == 0) {
            $html = "No comments";
        } else {
            foreach ($record as $row) {
                $d = strtotime($row["commentdate"]);
                $html .= $row["comments"] . "<BR><BR>Entered on " . date("m/d/Y H:i", $d) . " by " . $row["forename"] . " " . $row["surname"] . "<BR><BR>";
            }
        }

        echo $html;
    }

    public function saveComments($id, $comments) {
        $commentwho = getLoggedInUserId();
        $sql = sprintf("insert into %s.compliance_template_comments (dataID,comments,commentwho) VALUES (%d,'%s',%d)", _DB_OBJ_FULL, $id, $comments, $commentwho);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function getAnswerCataById($id) {

        $sql = sprintf(" select A.ID,D.Description,D.penalty,H.Main_Heading,D.period from %s.compliance_answer A inner join %s.compliance_data D on A.questionID=D.id inner join %s.compliance_main_hdr H on D.heading=H.ID  where A.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getCountries($id) {

        $sql = sprintf("select * from %s.locationgram L inner join %s.regions R on L.regionlink=R.ID where not regionlink =0", _DB_OBJ_FULL, _DB_OBJ_FULL);


        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $bu) {

            $regions[$bu['regionlink']] = $bu['name'];
        }

        return $regions;
    }

    public function getCompanies($id, $region = '') {
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');



        $busa = $orgObj->getCompanies();

        if ($region == '') {
            foreach ($busa as $bu) {
                $business_units[$bu["buID"]] = $bu["buName"];
            }
        } else {
            $comp = $locObj->getBufromCountries($region);

            foreach ($busa as $bu) {

                if (is_array($comp) && in_array($bu["buID"], $comp)) {
                    $business_units[$bu["buID"]] = $bu["buName"];
                }
            }
        }
        return $business_units;
    }

    public function finishSection($p_review_id) {
        $objRouting = new Routing();
        $userid = getLoggedInUserId();
        $emailer = $objRouting->getEmailer($userid);

        $userid = getLoggedInUserId();
        $emailer = $objRouting->getEmailer($userid);
        $sql = sprintf("UPDATE %s.compliance_answer
				SET trail = whoID,
				whoID = %d,
                                stagedone = 0
				WHERE ID in (%s)", _DB_OBJ_FULL, $emailer["participantID"], $p_review_id);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $emailer;
    }

    public function finishSection1($p_review_id) {
        $objRouting = new Routing();

        $userid = getLoggedInUserId();
        $emailer = $objRouting->getEmailer($userid);

        if (!$emailer) {
            $authtObj = SetupGeneric::useModule('AuthorizedUser');
            $emailer["participantID"] = $authtObj->getIssuerPermission("PERM_HOC");
        }
        $sql = sprintf("UPDATE %s.compliance_answer
				SET trail = cast(whoID as varchar(10)) +','+trail,
				whoID = %d,
                                stagedone = 0
				WHERE ID in (%s)", _DB_OBJ_FULL, $emailer["participantID"], $p_review_id);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $emailer;
    }

    public function roaEmails($emailer, $id) {
        $this->setComplianceInfo($id, '');
        $data = $this->getMasterbyID();

        $date = new DateTime(date("Y-m-d"));

        $due_date = $date->format('m/d/Y');

        $sql2 = sprintf("INSERT INTO %s.actions(moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
					VALUES('template','%s','%d','%s','%d',1,'%d',%d,'compliance_master')", _DB_OBJ_FULL, "Check Compliance Data", $emailer["participantID"], $due_date, $emailer["participantID"], $emailer["participantID"], $id);


        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->Id = customLastInsertId($this->dbHand, 'actions', 'ID');

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $emailObj = new actionEmailHelper($this->Id);
        $who = $emailObj->getwhoDetails();


        $authtObj = SetupGeneric::useModule('AuthorizedUser');
        $partGLOC = $authObj->getIssuerPermission("PERM_HOC");

        if ($emailer["participantID"] == $partGLOC) {
            $url = '/compliance/viewGHL';
        } else {
            $url = '/compliance/add_edit2';
        }

        $participantObj = SetupGeneric::useModule('Participant');
        $userID = getLoggedInUserId();
        $participantObj->setItemInfo(array('id' => $userID));

        $details = $participantObj->displayItemById();


        $data = array(
            'singleColData' => array(
                'comment' => '<BR>'
                ,
                'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/compliance.php?filter_date=">CLICK</a> Here to View Compliance Action<BR><BR>
                Please <a href="http://' . $_SERVER['HTTP_HOST'] . $url . '.php?id=' . $this->complianceId . '">CLICK</a> here to complete this action',
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $data["reference"]),
                'authorizing' => array(
                    'left' => '<strong>Actioned By</strong>',
                    'right' => $details["forename"] . " " . $details["surname"]
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('A Compliance  Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function evalmath($equation) {
        $result = 0;
        // sanitize imput
        $equation = preg_replace("/[^a-z0-9+\-.*\/()%]/", "", $equation);
        // convert alphabet to $variabel 
        $equation = preg_replace("/([a-z])+/i", "\$$0", $equation);
        // convert percentages to decimal
        $equation = preg_replace("/([+-])([0-9]{1})(%)/", "*(1\$1.0\$2)", $equation);
        $equation = preg_replace("/([+-])([0-9]+)(%)/", "*(1\$1.\$2)", $equation);
        $equation = preg_replace("/([0-9]{1})(%)/", ".0\$1", $equation);
        $equation = preg_replace("/([0-9]+)(%)/", ".\$1", $equation);
        /* if ( $equation != "" ){
          $result = @eval("return " . $equation . ";" );
          }
          if ($result == null) {
          throw new Exception("Unable to calculate equation");
          }
          return $result; */
        return $equation;
    }

    public function getCodeData($code) {

        $sql = sprintf("SELECT * FROM %s.compliance_code_data  WHERE ID=%d ", _DB_OBJ_FULL, $code);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetch(PDO::FETCH_ASSOC);

        if (count($record) == 0) {
            $html = "An Error has Occurred";
        } else {
            if ($record["atext"])
                $html .= "<P>" . $record["atext"] . "<INPUT type='text' id='dataa' ></p>";
            if ($record["btext"])
                $html .= "<P>" . $record["btext"] . "<INPUT type='text' id='datab' ></p>";
            if ($record["ctext"])
                $html .= "<P>" . $record["ctext"] . "<INPUT type='text' id='datac' ></p>";
            if ($record["dtext"])
                $html .= "<P>" . $record["dtext"] . "<INPUT type='text' id='datad' ></p>";
            if ($record["etext"])
                $html .= "<P>" . $record["etext"] . "<INPUT type='text' id='datae' ></p>";
            $html .= "<INPUT type='hidden' id='dataeq' value='" . $record["equation"] . "' >";
        }

        echo $html;
    }

    public function getCommentsbyID($id) {

        $sql = sprintf("SELECT * FROM %s.compliance_template_comments C left join  %s.participant_database P on C.commentwho=P.participantID  WHERE dataID=%d order by ID desc ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($record) == 0) {
            $html = "No comments";
        } else {
            foreach ($record as $row) {
                $d = strtotime($row["commentdate"]);
                $html .= $row["comments"] . "<BR><BR>Entered on " . date("m/d/Y H:i", $d) . " by " . $row["forename"] . " " . $row["surname"] . "<BR><BR>";
            }
        }

        return $html;
    }

    public function getLastCommentsbyID($id) {

        $sql = sprintf("SELECT * FROM %s.compliance_template_comments C left join  %s.participant_database P on C.commentwho=P.participantID  WHERE dataID=%d order by ID desc ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $row = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($row["comments"] == '') {
            $html = "No comments";
        } else {

            $d = strtotime($row["commentdate"]);
            $html = $row["comments"] . "<BR><BR>Entered on " . date("m/d/Y H:i", $d) . " by " . $row["forename"] . " " . $row["surname"] . "<BR><BR>";
        }
        return $html;
    }

    public function buildCode($a, $b, $c, $d, $e, $eqStr) {

        $sql = sprintf("insert into %s.compliance_code_data (atext,btext,ctext,dtext,etext,equation) VALUES ('%s','%s','%s','%s','%s','%s')  ", _DB_OBJ_FULL, $a, $b, $c, $d, $e, $eqStr);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $recID = customLastInsertId($this->dbHand, 'compliance_code_data', 'ID');
        return $recID;
    }

    public function getAROforTemplate($tid) {

        //get bus
        $sql = sprintf("select businessUnit from %s.compliance_templates T inner join  %s.locationgram L on T.country=L.regionlink where T.id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $tid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $row = $pStatement->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf("select P.surname,p.forename,P.participantID from  %s.participant_database P  where  gcupositions=1 order by forename", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return ($row1);
    }

        public function getAROforTemplateNew($tid) {

        //get bus
        $sql = sprintf("select businessUnit from %s.compliance_templates T inner join  %s.locationgram L on T.country=L.regionlink where T.id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $tid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $row = $pStatement->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf("select P.surname,p.forename,P.participantID from %s.organisation_positions O inner join %s.participant_database P on O.participantID=P.participantID  where buID in (%s) and gcupositions=1 order by forename", _DB_OBJ_FULL, _DB_OBJ_FULL, $row["businessUnit"]);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $row1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return ($row1);
    }
    public function sendReminderEmail($aro, $id, $period, $template) {
        $periodArr = array(1 => 'Monthly', 2 => 'Bi- Monthly', 3 => 'Quarterly', 4 => 'Annually', 5 => 'Bi - Annually', 6 => 'Semi - Annually', 7 => 'Tri - Annually');
        $templateName = $this->getTemplateByID($template);

        $partName = $this->getCountrybyID($id);
        $emailObj = new actionEmailHelper(0);

        $participantObj = SetupGeneric::useModule('Participant');
        $userID = getLoggedInUserId();
        $participantObj->setItemInfo(array('id' => $userID));

        $details = $participantObj->displayItemById();
        
        $participantObj->setItemInfo(array('id' => $aro));

        $detailsaro = $participantObj->displayItemById();
        $whoARO = array(
            'displayname' => ucwords($detailsaro['forename'] . ' ' . $detailsaro['surname']),
            'email' => $detailsaro['emailAddress'],
            'ID' => $detailsaro['participantID']
        );


        $data = array(
            'singleColData' => array(
                'comment' => '<BR>The "Action By" needs to be checked'
                ,
                'click-here-url' => '<BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/setup/compliance/checklist.php?id=' . $id . '&period=' . $period . '&template=' . $template . '">CLICK</a> here to check',
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Template</strong>',
                    'right' => $templateName["template_type"]
                ),
                'assignedto' => array(
                    'left' => '<strong>Assigned To</strong>',
                    'right' => $detailsaro["forename"]." ". $detailsaro["surname"]
                ),
                'period' => array(
                    'left' => '<strong>Period</strong>',
                    'right' => $periodArr[$period]
                ),
                'heading' => array(
                    'left' => '<strong>Part/Country</strong>',
                    'right' => $partName["Title"]
                ),
                'from' => array(
                    'left' => '<strong>From</strong>',
                    'right' =>$details["forename"]." ". $details["surname"]
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('A Compliance Template Action By', $whoARO, array(), array(), 'me_completed', '', 'grey');
        exit();
    }

}

?>