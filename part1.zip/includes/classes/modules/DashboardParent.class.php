<?php
 /**
  $Id: Documents.class.php,v 9.67 Monday, January 31, 2011 9:54:24 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Manage Document object
  *
  * This class will define the various methods performed
  * by document object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Friday, September 10, 2010 8:17:06 PM>
  */
abstract class DashboardParent
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	protected $dbHand;
	protected $qtrsRange;
	protected $filter;

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {
 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	public function setFilter($p_filter) {

		$this->filter = $p_filter;
	}

	public function setBlockRange($p_range) {

		$this->qtrsRange = $p_range;
	}

	public function __call($name,$arr) {
		die('Undefined function '.$name);
	}

	protected function getAllBUs() {

		$bu_list = array();

		$bu_list[] = $this->filter['selected_bu'];

		$this->organigramObj = SetupGeneric::useModule('Organigram');
		$this->organigramObj->setItemInfo(array(
											'id'=>$this->filter['selected_bu']
								));

		$child_business_units = $this->organigramObj->si_getAllBUs();
		$this->organigramObj = null;

        //dump_array($child_business_units);    
		if ($child_business_units) {
			//foreach ( $child_business_units as $child_business_unit_ele ) {
				$bu_list[] = $child_business_units['buID'];
			//}
		}
		
		//dump_array($bu_list);

		return implode(",",$child_business_units);

	}
}
?>