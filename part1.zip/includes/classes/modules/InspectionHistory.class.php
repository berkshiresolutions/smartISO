<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class InspectionHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {

		 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'inspection';
		$this->tables[] 		= 'inspection_metadata';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _inspection() {

		$tablename 				= 'inspection';
		$tablename_historical 	= $tablename.'_historical';

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (
						ID
						,reference
						,uniqueReference
						,locationID
						,buID
						,participantID
						,whenDate
						,archive
						,status
						,subReference
					   )
						SELECT
						ID
						,reference
						,uniqueReference
						,locationID
						,buID
						,participantID
						,whenDate
						,archive
						,status
						,subReference
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$sql = sprintf("SELECT subReference FROM %s.inspection
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$this->subReference = $pStatement->fetchColumn();

		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
	}

	private function _inspection_metadata() {

		$tablename 				= 'inspection_metadata';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from inspection_metadata
		 */
		$sql = sprintf("SELECT * FROM %s.".$tablename."
						WHERE inspectionID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$inspection_meta_data_resultset = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($inspection_meta_data_resultset) ) {

			foreach ( $inspection_meta_data_resultset as $inspection_meta_data ) {

				$sql = sprintf("INSERT INTO %s.".$tablename_historical."
							   (
								ID
								,inspectionID
								,tab
								,step
								,subStep
								,expectation
								,problem
								,actionID
								,documentID
								,isRiskValid
								,hazardClassificationID
								,hazardsID
								,processID
								,actionDescOld
								,outstanding
								,archive
								,mainProcessID
								,processStepID
								,managementHazardID
								,subReference
							   ) VALUES (%d,%d,%d,%d,%d,'%s','%s',%d,%d,'%s',%d,'%s',%d,'%s','%s','%s',%d,%d,%d,%d)",
								_DB_OBJ_FULL,
								$inspection_meta_data['ID'],
								$inspection_meta_data['inspectionID'],
								$inspection_meta_data['tab'],
								$inspection_meta_data['step'],
								$inspection_meta_data['subStep'],
								$inspection_meta_data['expectation'],
								$inspection_meta_data['problem'],
								$inspection_meta_data['actionID'],
								$inspection_meta_data['documentID'],
								$inspection_meta_data['isRiskValid'],
								$inspection_meta_data['hazardClassificationID'],
								$inspection_meta_data['hazardsID'],
								$inspection_meta_data['processID'],
								$inspection_meta_data['actionDescOld'],
								$inspection_meta_data['outstanding'],
								$inspection_meta_data['archive'],
								$inspection_meta_data['mainProcessID'],
								$inspection_meta_data['processStepID'],
								$inspection_meta_data['managementHazardID'],
								$this->subReference);

				$pStatement2 = $this->dbHand->prepare($sql);
				$pStatement2->execute();
			}
		}
	}
}
?>