<?php
 /**
  $Id: Contractor.class.php,v 3.60 Thursday, February 03, 2011 3:17:03 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Contractor object
  *
  * This interface will declare the various methods performed
  * by the contractor object for operations like add, edit, delete, archive, purge.
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */

require_once "ContractReview.int.php";

class ContractReview implements ContractReviewInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Property to hold tabs name and ID mapping
	 * @access private
	 */
	private $tabsMapping;

	/**
	 * Property to hold contractor ID
	 * @access private
	 */
	private $contractreviewId;

	/**
	 * Property to hold contractor Data
	 * @access private
	 */
	private $contractreviewInfo;

	/**
	 * Property to hold current contractor Tab
	 * @access private
	 */
	private $contractreviewCurrentTab;

	/**
	 * Constructor for initializing Contractor object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 				= DB::connect(_DB_TYPE);
		
	
	}

	/**
	 * to set contractorreview information for performing various operations with the Contractor object
	 * @param integer $p_contractorId 	This parameter is used to set contractor id for adding, editing, archiving, restoring, delete 
	 * review_ID in table
	 * @param integer $p_currentTab 	This parameter is used to define current working tab
	 * @param array $p_contractorInfo	This array is used to pass set of parameters for each tab. This is Optional
	 */
	public function setContractReviewInfo($p_contractreviewId,$p_currentTab,$p_contractreviewInfo) {

		$this->contractreviewId 		= $p_contractreviewId;
		$this->contractreviewCurrentTab = $p_currentTab;
		$this->contractreviewInfo 		= $p_contractreviewInfo;
	}


	
private function addContractReview() {
	$sql = sprintf("INSERT INTO %s.contract_review (ID, contractID, f1f2,
			quarterCovered, yearCovered, reviewer, reviewDate, reviewEndDate,
			contractAnnualValue, disputedInvoices, disputedInvoicesComment,
			healthAndQuality, healthAndQualityCNCR, healthAndQualityComment,
			finance, financeCNCR, financeComment,
			contractReviewMeetings, complaints,
			amountPaidInCurrentFinancialYear, contractStillValid,
			evaluate1, evaluate2, evaluate3, evaluate4, evaluate5,
			evaluate6, evaluate7, evaluate8, evaluate9, evaluate10,
			productQuality, productQualityCNCR, productQualityComment,
			serviceQuality, serviceQualityCNCR, serviceQualityComment,
			onTimeDelivery, onTimeDeliveryCNCR, onTimeDeliveryComment,
			knowledge, knowledgeCNCR, knowledgeComment,
			reputation, reputationCNCR, reputationComment,
			customerFocus, customerFocusCNCR, customerFocusComment,
			customerService, customerServiceCNCR, customerServiceComment,
			responsiveness, responsivenessCNCR, responsivenessComment,notes, files_invoice , files_meeting , meeting_date,archive,score_average,approved)
			VALUES ('%s', %d, %d,
				%d, %d, %d, '%s','%s',
				%d, %d, '%s',

				%d, %d, '%s',
				%d, %d, '%s',
				'%s', '%s',
				%d, %d,
				'%s', '%s', '%s', '%s', '%s',
				'%s', '%s', '%s', '%s', '%s',

				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s','%s','%s','%s','%s','%d',%f,1)",

				_DB_OBJ_FULL, $this->contractreviewInfo["reviewID"], $this->contractreviewInfo["contractID"], $this->contractreviewInfo["f1f2"], 
				$this->contractreviewInfo["quarterCovered"], $this->contractreviewInfo["yearCovered"], $this->contractreviewInfo["reviewer"],
				$this->contractreviewInfo["reviewDate"], $this->contractreviewInfo["reviewEndDate"], $this->contractreviewInfo["contractAnnualValue"], 
				$this->contractreviewInfo["disputedInvoices"], $this->contractreviewInfo["disputedInvoicesComment"], 
				$this->contractreviewInfo["healthAndQuality"], $this->contractreviewInfo["healthAndQualityCNCR"], 
				$this->contractreviewInfo["healthAndQualityComment"], $this->contractreviewInfo["finance"], $this->contractreviewInfo["financeCNCR"], 
				$this->contractreviewInfo["financeComment"], $this->contractreviewInfo["contractReviewMeetings"], $this->contractreviewInfo["complaints"], 
				$this->contractreviewInfo["amountPaidInCurrentFinancialYear"], $this->contractreviewInfo["contractStillValid"], 
				$this->contractreviewInfo["evaluate1"], $this->contractreviewInfo["evaluate2"], $this->contractreviewInfo["evaluate3"], 
				$this->contractreviewInfo["evaluate4"], $this->contractreviewInfo["evaluate5"], $this->contractreviewInfo["evaluate6"], 
				$this->contractreviewInfo["evaluate7"], $this->contractreviewInfo["evaluate8"], $this->contractreviewInfo["evaluate9"], 
				$this->contractreviewInfo["evaluate10"], $this->contractreviewInfo["productQuality"], $this->contractreviewInfo["productQualityCNCR"], 
				$this->contractreviewInfo["productQualityComment"], $this->contractreviewInfo["serviceQuality"], 
				$this->contractreviewInfo["serviceQualityCNCR"], $this->contractreviewInfo["serviceQualityComment"], 
				$this->contractreviewInfo["onTimeDelivery"], $this->contractreviewInfo["onTimeDeliveryCNCR"], 
				$this->contractreviewInfo["onTimeDeliveryComment"], $this->contractreviewInfo["knowledge"], $this->contractreviewInfo["knowledgeCNCR"], 
				$this->contractreviewInfo["knowledgeComment"], $this->contractreviewInfo["reputation"], $this->contractreviewInfo["reputationCNCR"], 
				$this->contractreviewInfo["reputationComment"], $this->contractreviewInfo["customerFocus"], $this->contractreviewInfo["customerFocusCNCR"], 
				$this->contractreviewInfo["customerFocusComment"], $this->contractreviewInfo["customerService"], 
				$this->contractreviewInfo["customerServiceCNCR"], $this->contractreviewInfo["customerServiceComment"], 
				$this->contractreviewInfo["responsiveness"], $this->contractreviewInfo["responsivenessCNCR"], 
				$this->contractreviewInfo["responsivenessComment"], $this->contractreviewInfo["notes"], $this->contractreviewInfo["files_invoice"], 
				$this->contractreviewInfo["files_meeting"], $this->contractreviewInfo["meeting_date"], 0, $this->contractreviewInfo["score_average"]);

$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
}

private function addContractActions() {
	$sql = sprintf("INSERT INTO %s.contract_actions
           (contractreviewID
           ,sectionId
           ,questionId
           ,problem
           ,actionID
           ,score
           ,cncr)
     VALUES
           (%d
           ,%d
           ,%d
           ,'%s'
           ,%d
           ,%d
           ,%d)",_DB_OBJ_FULL, $this->contractreviewInfo["contractreviewID"], $this->contractreviewInfo["sectionId"], 
		   $this->contractreviewInfo["questionId"], $this->contractreviewInfo["problem"], $this->contractreviewInfo["actionID"], 
		   $this->contractreviewInfo["score"], $this->contractreviewInfo["cncr"]);

$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
}


public function convertf2() {
//copy review
$sql = sprintf("SELECT * FROM %s.contract_review WHERE review_ID = %d",_DB_OBJ_FULL,$this->contractreviewId );
$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
$records = $pStatement->fetch(PDO::FETCH_ASSOC);
$sql = sprintf("update %s.contract_review set archive=1 WHERE review_ID = %d",_DB_OBJ_FULL,$this->contractreviewId );
$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
	
$uniqueObj = new UniqueReference();
//set for f2 edit
$records['reviewID'] = $uniqueObj->getUniqueNumber('REVIEW');
$records['cmApproved']=0;	
$records['f1f2']=2;


$cid=$records["contractID"];
$qc=$records["quarterCovered"];
$yc=$records["yearCovered"];
$f1f2=2;

$sql = sprintf("SELECT count(*) as cnt,review_ID FROM %s.contract_review WHERE contractID = %d AND quarterCovered = %d AND yearCovered = %d AND f1f2 = %d",_DB_OBJ_FULL,$cid,$qc,$yc,$f1f2);
$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
$recordsF2 = $pStatement->fetch(PDO::FETCH_ASSOC);



if ($recordsF2["cnt"]>0)
return $recordsF2["review_ID"];

$this->setContractreviewInfo(0,0,$records);
$this->addContractReview();
$reviewID= (int)customLastInsertId( $this->dbHand,'contract_review','review_ID');



$sql = sprintf("SELECT * FROM %s.contract_actions WHERE contractreviewID = %d",_DB_OBJ_FULL,$records["review_ID"] );
//$sql = sprintf("SELECT * FROM %s.contract_actions ",_DB_OBJ_FULL);
$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
$actions = $pStatement->fetchAll(PDO::FETCH_ASSOC);
foreach ($actions as $newaction)
{
if ($newaction["questionId"]>2)
$newaction["questionId"]++;
$newaction["sectionId"]=2;
$newaction["contractreviewID"]=$reviewID;
$this->setContractreviewInfo(0,0,$newaction);
$this->addContractActions();


}
return $reviewID;
	}

public function getLastNotes($p_recordID)
{
$sql = sprintf("SELECT notes,maNotes,daNotes,subReference FROM %s.contract_review_historical WHERE review_ID = %d order by subReference ",_DB_OBJ_FULL,$p_recordID);
$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

foreach($records as $row)
{
 $reject=$row["subReference"]+1;
$rtnrecord["notes"].=$reject." - ";	
$rtnrecord["notes"].=$row["notes"]."  ";	
$rtnrecord["maNotes"].=$reject." - ";	
$rtnrecord["maNotes"].=$row["maNotes"]." ";
$rtnrecord["daNotes"].=$reject." - ";	
if (trim($row["daNotes"]) == "")
$rtnrecord["daNotes"].=" N/A  ";		
else
$rtnrecord["daNotes"].=$row["daNotes"]."  ";	
}



return $rtnrecord;
}

    public function getReviewsExportData() {

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

       $openReview = $this->listCSVReview($archive_session);

        $heading = array(array('Contract Ref', 'Rev Type', 'Title', 'Qtr', 'Reviewed By', 'Due Date', 'Complete Date', 'Next Review Date'));
  $heading = array(array('Contract Ref', 'Rev Type', 'Title', 'Qtr', 'Reviewed By', 'Due Date', 'Complete Date', 'Next Review Date','Still Valid'));

        $result = array();
        $i = 0;
        if (is_array($openReview)) {

            foreach ($openReview as $value) {
                $refValue = $value['subReference'] > 0 ? $value['reference'] . "." . $value['subReference'] : $value['reference'];

                if ($value['f1f2'] == 2)
                    $f1f2Str = "Detailed";
                else
                    $f1f2Str = "Standard";



                $result[$i][] = $refValue;
                $result[$i][] = $f1f2Str;
                $result[$i][] = $value['contractName'];
                $result[$i][] = $value['quarterCovered'] . "'" . $value['yearCovered'];
                $result[$i][] = $value['forename'] . ' ' . $value['surname'];
                $result[$i][] = $value['reviewEndDate'] ? format_date($value['reviewEndDate']) : '   ';
                $result[$i][] = $value['reviewCompleteDate'] ? format_date($value['reviewCompleteDate']) : '   ';


                $quarterCovered = 5;
                $nowMonth = intval(date('m'));
                if ($nowMonth >= 1 && $nowMonth <= 3)
                    $quarterCovered = 1;
                else if ($nowMonth >= 4 && $nowMonth <= 6)
                    $quarterCovered = 2;
                else if ($nowMonth >= 7 && $nowMonth <= 9)
                    $quarterCovered = 3;
                else if ($nowMonth >= 10 && $nowMonth <= 12)
                    $quarterCovered = 4;

                $quarterCovered ++;

                if ($value['f1f2'] == '2') {
                    $quarterCovered = "4";
}


               $sql = sprintf("SELECT * FROM %s.contract_review_date WHERE quarter = " . $quarterCovered . " ORDER BY quarter", _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
                $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



                if ($value['f1f2'] == '2') {
                    $Year = $resultSet['year'] + 1;
                } else {
                    $Year = $resultSet['year'];
                }
                $reviewDate = $resultSet['month'] . "/" . $resultSet['day'] . "/" . $Year;



                $result[$i][] = $reviewDate;


                $i++;
            }
        }

        $new_result = array_merge($heading, $result);
       
        return $new_result;
    }
    
    public function getListingforExport() {

        return $this->getReviewsExportData();
    }
        public function listCSVReview($p_archive_val) {

$isShortTermOrTender  = $_GET['tender'];
$where = "";
if($isShortTermOrTender != "" and $isShortTermOrTender !="-1")
{
	$where = " And shortTermOrTender = '".$isShortTermOrTender."'  ";
}


 
		$dbHand = DB::connect(_DB_TYPE);
$sql = sprintf("SELECT R.ID as cid, * ,R.reviewDate as reviewDate FROM %s.contract_review R LEFT JOIN %s.contract C ON R.contractID = C.ID LEFT JOIN %s.participant_database P ON R.reviewer = P.participantID where R.archive='".$archive_session."' ".$where." ORDER BY cid desc",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
return $records;
    }
}
