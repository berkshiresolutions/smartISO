<?php
/* 
 * *******************************
 * Created by Luong Tran
 * *************************

 */
interface VehicleInterface
{
	/*
	 * to set vehicle information for performing various operations with the Vehicle object
	 */
//	public function setVehicleInfo($p_vehicleId,$p_vehicleInfo);
//
//	/*
//	 * This method is used to add a new vehicle
//	 */
//	public function addVehicle();

	///*
//	 * This method is used to view the vehicle information.
//	 */
//	public function viewVehicles();
//
//	/*
//	 * This method is used to edit the vehicle
//	 */
//	public function editVehicle();
//
//	/*
//	 * This method is used to delete the vehicle
//	 */
//	public function deleteVehicle();
//
//	/*
//	 * This method is used to archive the vehicle
//	 */
//	public function archiveVehicle();
//
//	/*
//	 * This method is used to remove the vehicle
//	 */
//	public function purgeVehicle();

}
//interface VehicleInterface {
//    public function setVehicleInfo();
//    public function addVehicle();
//    public function editVehicle();
//    public function viewVehicle();
//    public function deleteVehicle();
//    public function archiveVehicle();
//}
?>
