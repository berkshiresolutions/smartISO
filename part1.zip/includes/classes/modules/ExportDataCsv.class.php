<?php
 /**
  $Id: ExportDataCsv.class.php,v 3.25 Monday, January 31, 2011 12:04:24 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, January 13, 2011 3:57:07 PM>
  */

class ExportDataCsv
{
	private $objCont;
	private $fileName;
	private $filePath;

	public function __construct($p_modulename='') {
		$this->filePath = realpath(_MYROOT).'/private_files/export_files/';
		$this->fileName = "Testfile.xls";

		if ( $p_modulename != '' ) {
		 
		 if ($p_modulename=="contractors")
		 	$this->fileName = "suppliers.xls";
		 			else
			$this->fileName = $p_modulename.".csv";
		}
	}

	public function downloadFile($p_obj) {
		$this->objCont = $p_obj;


		$fp = fopen($this->filePath.$this->fileName, "w");

		$line = "";
		$comma = ",";


		if ( is_array($this->objCont->exportData) ) {

			foreach($this->objCont->exportData as $value) {
				//dump_array($value);
				if ( is_array($value)) {
					foreach($value as $value_Ele) {

						$line .= "\"".$value_Ele ."\"". $comma ;
					}
				}
				$line .= "\n";
			}

		}


		fputs($fp, $line);

//exit;

		fclose($fp);


		header('Content-type: application/download');
		header('Content-Description: File Transfer');
		header('Content-Disposition: attachment; filename="'.$this->fileName.'"');
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header('Content-Transfer-Encoding: binary');

		// Read the file from disk
		readfile($this->filePath.$this->fileName);

		//dump_array($this->objCont);
	}
}
?>