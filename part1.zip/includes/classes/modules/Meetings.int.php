<?php
 /**
  $Id: Meeting.int.php,v 3.03 Monday, October 11, 2010 12:43:15 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage meeting object
  *
  * This interface will declare the various methods performed
  * by the meeting object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface MeetingsInterface
{
	/*
	 * to set meeting information for performing various operations with the meeting object
	 */
	public function setMeetingInfo($p_meetingId,$p_meetingInfo);

	/*
	 * This method is used to add a new meeting
	 */
	public function addMeeting();

	/*
	 * This method is used to view meeting information.
	 */
	public function viewMeeting();

	/*
	 * This method is used to edit a meeting
	 */
	public function editMeeting();

	/*
	 * This method is used to delete a meeting
	 */
	public function deleteMeeting();

	/*
	 * This method is used to archive a meeting
	 */
	public function archiveMeeting();

	/*
	 * This method is used to remove a meeting
	 */
	public function purgeMeeting();

}