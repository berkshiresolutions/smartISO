<?php

/**
  $Id: BCPMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, November 03, 2010 12:25:00 PM>
 */
require_once "GOV.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class GOVMain implements GOV {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * property contains witness data
     * @access private
     */
    private $reviewIDd;

    /**
     * Property to hold GOV Info
     * @access private
     */
    private $reviewInfo;

    /**
     * Constructor for initializing GOV object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set incidence information for the respective object
     */

    public function setGOVInfo($p_GOVId, $p_GOVInfo) {
        $this->reviewID = $p_GOVId;
        $this->reviewInfo = $p_GOVInfo;
    }

    /*
     * This method is used to add new incidence
     * reference,unique_reference,incidence_date,incidence_date_time,location,business_unit
     */

    public function getLastInsertID() {
        return $this->reviewID;
    }

    public function purgeGOV() {
        
    }

    public function deleteGOV() {
        
    }

    public function archiveGOV() {
        
    }

    public function getGOV_id($pos, $auditid) {

        $sql = sprintf("select * from  %s.GOV_results  where question=%d and GOV_ID=%d", _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    public function getGOV2_id($pos, $auditid) {

        $sql = sprintf("select * from  %s.GOV2_results  where question=%d and GOV_ID=%d", _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

        public function getGOVOb_id($pos, $auditid) {

        $sql = sprintf("select * from  %s.GOVOb_results  where question=%d and GOV_ID=%d", _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }
            public function getGOVInt_id($pos, $auditid) {

        $sql = sprintf("select * from  %s.GOVInt_results  where question=%d and GOV_ID=%d", _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }
    
    public function get_question_detail($id) {

        $sql = sprintf("select * from  %s.gov_question_detail where question_link=%d ", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }

    public function getGOV_question($Govid) {

        $sql = sprintf("select Q.*,S.data,S.number as subnumber,H.heading,C.criteria as crit_data,A.aspect from %s.gov_questions Q  inner join %s.gov_sub_hdr S on Q.link=S.ID inner join %s.gov_hdrs H on S.hdr_link=H.ID left join %s.gov_aspect A on Q.aspect_link=A.ID left join %s.gov_criteria C on Q.criteria_link=C.ID where Q.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $Govid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getGOVdata($Govid) {

        $sql = sprintf("select Q.*,S.data,S.number as subnumber,H.heading,C.criteria as crit_data,A.aspect from %s.gov_questions Q  inner join %s.gov_sub_hdr S on Q.link=S.ID inner join %s.gov_hdrs H on S.hdr_link=H.ID left join %s.gov_aspect A on Q.aspect_link=A.ID left join %s.gov_criteria C on Q.criteria_link=C.ID   ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getGOVdata2($Govid, $type) {

       $sql = sprintf("select Q.*,S.*,R.result,R.comment,R.problem,A.* from %s.gov_quest2 Q  inner join %s.gov_quest2_hdr S on Q.qsubtype=S.hID left join %s.gov2_results R on Q.ID=R.question left join %s.actions A on R.actionID=A.ID where Q.qtype=%d and R.GOV_ID=%d ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $type, $Govid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getGOV_action($id) {

        $sql = sprintf("select * from  %s.actions where moduleelement='gov_results' and record=%d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

        public function getGOVOb_action($id) {

        $sql = sprintf("select * from  %s.actions where moduleelement='govOb_results' and record=%d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }
    
            public function getGOVInt_action($id) {

        $sql = sprintf("select * from  %s.actions where moduleelement='govInt_results' and record=%d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }
    public function updateGOV_id($id, $answer, $comments) {

        $sql = sprintf("update  %s.GOV_results set result=%d,problem='%s' where ID=%d", _DB_OBJ_FULL, $answer, $comments, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function add_action($id, $data) {
        $this->aid = $id;
        $this->actionData = $data;


        if ($this->aid == 0) {

            $this->actionHandling->setActionDetails(0, $this->actionData);
            $new_action_id = $this->actionHandling->addAction2015();
        } else {

            $this->actionHandling->setActionDetails($this->aid, $this->actionData);
            $new_action_id = $this->actionHandling->updateAction2015();
        }
        $sql = sprintf("update %s.GOV_results set actionID=%d where ID=%d ", _DB_OBJ_FULL, $new_action_id, $this->actionData["record"]);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function updateGOV_question($id, $question_No, $answer) {

        $sql = sprintf("insert into %s.IAR_pfresults (SLR_ID,question,result) VALUES (%d,%d,'%s')", _DB_OBJ_FULL, $id, $question_No, $answer);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getGOVFiles($p_rid) {
        $this->reviewID = $p_rid;
        $sql = sprintf("select * from %s.gov_detail_files where rID=%d"
                , _DB_OBJ_FULL
                , $this->reviewID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function listOpenReview($p_archive_val) {

        $sql = sprintf("SELECT M.*,C.company from %s.gov_master M left join %s.gov_company C on M.company=C.ID

				WHERE M.is_complete = '0' AND M.archive = '%s' 
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listclosedReview($p_archive_val) {

        $sql = sprintf("SELECT M.* from %s.gov_master M

				WHERE M.is_complete = '1' AND M.archive = '%s' 
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function startReview($p_reviewType, $p_businessId, $p_mseListId = 0, $p_ref = "Admin", $audit,$company) {

        $this->questionList = '';
        $this->buID = $p_businessId;
        $this->reference = $p_ref;
        $this->audit = $audit;
		$this->company = $company;
		
        $default_datetime = '1900-01-01 00:00:00';


        $sql = sprintf("INSERT INTO %s.gov_master (auditorID,buID,startTime,endTime,reviewType,is_complete,current_question,questions,reference,auditlink,company)
				VALUES (%d, '%s'," . customCurrentDate() . ",'%s', '%s','0','1','%s','%s',%d,%d)"
                , _DB_OBJ_FULL
                , $this->auditorID
                , $this->buID
                , $default_datetime
                , $this->reviewType
                , $this->questionList
                , $this->reference
                , $this->audit
				, $this->company);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $last_insert_id = customLastInsertId($this->dbHand, 'gov_master', 'reviewID');

        $this->buildList($last_insert_id);

        return $last_insert_id;
    }

        public function startReviewOB($p_ref,   $audit) {

        $this->reference = $p_ref;
        $this->audit = $audit;
        $this->auditorID= getLoggedInUserId();

     $sql = sprintf("INSERT INTO %s.gov_observation (uniqueReference,who,GOV_ID)
				VALUES ( '%s','%d',%d)"
                , _DB_OBJ_FULL
                , $this->reference
                , $this->auditorID
  
                , $this->audit);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $last_insert_id = customLastInsertId($this->dbHand, 'gov_observation', 'ID');

        $this->buildListOb($last_insert_id);

        return $last_insert_id;
    }
    
            public function startReviewInt($p_ref,   $audit) {

        $this->reference = $p_ref;
        $this->audit = $audit;
        $this->auditorID= getLoggedInUserId();

     $sql = sprintf("INSERT INTO %s.gov_interview (uniqueReference,who,GOV_ID)
				VALUES ( '%s','%d',%d)"
                , _DB_OBJ_FULL
                , $this->reference
                , $this->auditorID
  
                , $this->audit);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $last_insert_id = customLastInsertId($this->dbHand, 'gov_interview', 'ID');

        $this->buildListInt($last_insert_id);

        return $last_insert_id;
    }
    
    public function editOrganigramDetail() {
        $sql = "update %s.gov_audit_detail set archive=1 where rID=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $sql = "INSERT into %s.gov_audit_detail(plan_d,summary,rID)
            VALUES('%s','%s', %d)";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewInfo['plan'], $this->reviewInfo['summary'], $this->reviewID);

        $stmt = $this->dbHand->prepare($psql);

        return $stmt->execute();
    }

    public function updatePersonDetail() {

        $sql = "update %s.gov_audit_participants set archive=1 where reviewID=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $sql = "INSERT into %s.gov_audit_participants (reviewID,persontype,personid) VALUES (%d,'%s',%d)";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'L', $this->reviewInfo["l_aud"]);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        if ($this->reviewInfo["auditor"]) {
            foreach ($this->reviewInfo["auditor"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'A', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }

        if ($this->reviewInfo["audit"]) {
            foreach ($this->reviewInfo["audit"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'E', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }
        if ($this->reviewInfo["person"]) {
            foreach ($this->reviewInfo["person"] as $p => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'P', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }

        return;
    }

    public function moveFiles($p_identifier, $ridA, $rid,$hdr) {
        $rec_id = $ridA;
        $this->questionId = $rec_id;
        $module = 'governance';

        // $this->removeDocFiles(); consider how this would work

        $path = _MYROOT . 'tmp/' . $p_identifier;


       $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();

            if (count($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);


                            $file_details = array('user_file_name' => $file_details_arr[2]
                                , 'name' => ''
                                , 'tmp_name' => ''
                                , 'file_details' => ''
                                , 'size' => 0
                                , 'id' => 0
                                , 'error' => 0
                                , 'destination' => ''
                                , 'file_type' => $file_type
                                , 'type' => $file_type
                            );


                            $objFile->setFileInfo($module, $file_details);

                            $objFile->setBogusDetails($file_details);

                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                           $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
//	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);

                                    $this->setGOVInfo($rid, $data_array);
                                    $this->addDocFiles($hdr);
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }

    public function getReviewInfo($p_reviewID) {

        $sql = sprintf("SELECT M.* FROM %s.gov_master M

				WHERE M.reviewID = %d", _DB_OBJ_FULL, $p_reviewID);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getParticipants($id) {
        $this->id = $id;
        $sql = "SELECT R.persontype,P.forename+' '+P.surname  as name,R.personid FROM %s.gov_audit_participants R inner join %s.participant_database P on R.personid=P.participantid WHERE R.archive=0 and reviewID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgan($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.gov_audit_detail WHERE archive=0 and rID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getFiles($p_rid) {
        $this->reviewID = $p_rid;
        $sql = sprintf("select * from %s.gov_detail_files where rID=%d"
                , _DB_OBJ_FULL
                , $this->reviewID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function finishReviewOutside($p_review_id) {

        $sql = sprintf("UPDATE %s.gov_master
				SET is_complete = '1',
				endTime = " . customCurrentDate() . "
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_review_id);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $this->sendActionEmails($p_review_id);
    }

    public function sendActionEmails($aid) {

        $reviewData = $this->getReviewInfo($aid);
        // $sql = sprintf("select A.* from %s.actions A  where moduleName='ISA_Action' ",_DB_OBJ_FULL,$aid);
        $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID  where moduleName='GOV_Action' and moduleelement='gov_results' and D.reviewid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        if (count($result) > 0) {  //only mse give actions 
            foreach ($result as $value) {

                $emailObj = new actionEmailHelper($value["ID"]);


                $who = $emailObj->getwhoDetails();

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/gov.php?id='.$value["ID"].'">CLICK</a> Here to View GOV - Review Action<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/governance/pdfreport.php?id=' . $aid . '">CLICK</a> Here to View Governance Report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $reviewData["reference"]
                        ),
                        'problem' => array(
                            'left' => '<strong>Problem</strong>',
                            'right' => $value["problem"]
                        )
                    )
                );
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Governnance Audit Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $whoAU = $emailObj->getAUDetails();
                $emailObj->sendEmail('A Governnance Audit Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

                if ($value['who2AU'] > 0) {
                    $who2AU = $emailObj->getSecondApproverDetails();
                    $emailObj->sendEmail('A Governnance Audit Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
                }

                $sql = sprintf("update %s.actions set status=1 where ID=%d", _DB_OBJ_FULL, $value["ID"]);

                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
            }
        }
       
        $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.govOb_results R on A.record=R.ID inner join %s.gov_observation O on R.GOV_id=O.ID inner join %s.gov_master D on O.GOV_id=D.reviewID  where moduleName='GOV1_Action'  and D.reviewid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        if (count($result) > 0) {  //only mse give actions 
            foreach ($result as $value) {

                $emailObj = new actionEmailHelper($value["ID"]);


                $who = $emailObj->getwhoDetails();

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/gov1.php?id='.$value["ID"].'">CLICK</a> Here to View GOV - Review Action<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/governance/pdfreport.php?id=' . $aid . '">CLICK</a> Here to View Governance Report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $reviewData["reference"]
                        ),
                        'problem' => array(
                            'left' => '<strong>Problem</strong>',
                            'right' => $value["problem"]
                        )
                    )
                );
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Governnance Observation Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $whoAU = $emailObj->getAUDetails();
                $emailObj->sendEmail('A Governnance Observation Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

                if ($value['who2AU'] > 0) {
                    $who2AU = $emailObj->getSecondApproverDetails();
                    $emailObj->sendEmail('A Governnance Observation Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
                }

                $sql = sprintf("update %s.actions set status=1 where ID=%d", _DB_OBJ_FULL, $value["ID"]);

                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
            }
        }

        $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.govInt_results R on A.record=R.ID inner join %s.gov_interview I on R.GOV_id=I.ID inner join %s.gov_master D on I.GOV_id=D.reviewID  where moduleName='GOV2_Action'  and D.reviewid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        if (count($result) > 0) {  //only mse give actions 
            foreach ($result as $value) {

                $emailObj = new actionEmailHelper($value["ID"]);


                $who = $emailObj->getwhoDetails();

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/gov2.php?id='.$value["ID"].'">CLICK</a> Here to View GOV - Review Action<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/governance/pdfreport.php?id=' . $aid . '">CLICK</a> Here to View Governance Report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $reviewData["reference"]
                        ),
                        'problem' => array(
                            'left' => '<strong>Problem</strong>',
                            'right' => $value["problem"]
                        )
                    )
                );
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Governnance Interview Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $whoAU = $emailObj->getAUDetails();
                $emailObj->sendEmail('A Governnance Interview Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

                if ($value['who2AU'] > 0) {
                    $who2AU = $emailObj->getSecondApproverDetails();
                    $emailObj->sendEmail('A Governnance Interview Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
                }

                $sql = sprintf("update %s.actions set status=1 where ID=%d", _DB_OBJ_FULL, $value["ID"]);

                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
            }
        }
    }

    public function buildList($auditid) {

        $sql = sprintf("insert into %s.gov_results (GOV_ID,question) select %d,Id from %s.gov_questions ", _DB_OBJ_FULL, $auditid, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $sql = sprintf("insert into %s.gov2_results (GOV_ID,question) select %d,Id from %s.gov_quest2 ", _DB_OBJ_FULL, $auditid, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

        public function buildListOb($auditid) {

        $sql = sprintf("insert into %s.govOb_results (GOV_ID,question) select %d,Id from %s.gov_questOb ", _DB_OBJ_FULL, $auditid, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }
        public function buildListInt($auditid) {

       $sql = sprintf("insert into %s.govInt_results (GOV_ID,question) select %d,Id from %s.gov_questInt ", _DB_OBJ_FULL, $auditid, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }
    public function archiveReview($p_review_id, $p_archive_val) {

        $sql = sprintf("UPDATE %s.gov_master SET archive = '%s' WHERE reviewID = %d", _DB_OBJ_FULL, $p_archive_val, $p_review_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function getGovFile($id) {

        $sql = sprintf("SELECT * FROM %s.gov_files WHERE questionID = %d and type=2 "
                , _DB_OBJ_FULL
                , $id
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $resultSet;
    }

    public function getTotalCount($auditid) {

        $sql = sprintf("select count(*) as Count from  %s.gov_questions", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["Count"];
    }

    public function getCurrentCount($auditid) {

        $sql = sprintf("select count(*) as Count from  %s.gov_results where isnull(result,0)>0 and GOV_id =%d", _DB_OBJ_FULL, $auditid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["Count"];
    }

    public function getGOVInfo($p_reviewID) {

        $sql = sprintf("SELECT M.* FROM %s.gov_master M

				WHERE M.reviewID = %d", _DB_OBJ_FULL, $p_reviewID);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_doc_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getGOVIntData($p_ID) {

        $sql = sprintf("SELECT *  FROM %s.gov_questInt  Q inner join %s.gov_quest_hdr H on Q.qsubType=H.hID

				WHERE Q.ID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_ID);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_doc_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

        public function getGOVObData($p_ID) {

        $sql = sprintf("SELECT *  FROM %s.gov_questOb  Q inner join %s.gov_quest_hdr H on Q.qsubType=H.hID

				WHERE Q.ID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_ID);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_doc_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function getGOV2TotalCount($p_ID,$hdr) {
if($hdr == 1)
        $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questOb  WHERE qtype = %d", _DB_OBJ_FULL, $p_ID);
else
        $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questInt  WHERE qtype = %d", _DB_OBJ_FULL, $p_ID);
        
$stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result["cnt"];
    }

    public function getGOV2SectionCount($p_ID,$hdr) {
if($hdr == 1)
        $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questOb  WHERE qsubtype = %d", _DB_OBJ_FULL, $p_ID);
else
                $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questInt  WHERE qsubtype = %d", _DB_OBJ_FULL, $p_ID);
                
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result["cnt"];
    }

    public function getGOV2SectionDoneCount($p_ID, $p_auditID,$hdr) {
if($hdr == 1)
        $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questOb Q inner join  %s.govOb_results R on Q.ID=R.question WHERE qsubtype = %d and not isnull(result,0) = 0 and GOV_ID=%d  ", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_ID, $p_auditID);
else  
    $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questInt Q inner join  %s.govInt_results R on Q.ID=R.question WHERE qsubtype = %d and not isnull(result,0) = 0 and GOV_ID=%d  ", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_ID, $p_auditID);

  
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result["cnt"];
    }

    public function getGOV2TotalDoneCount($p_ID, $p_auditID,$hdr) {
if($hdr == 1)
        $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questOb Q inner join  %s.govOb_results R on Q.ID=R.question WHERE qtype = %d and not isnull(result,0) = 0 and GOV_ID=%d  ", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_ID, $p_auditID);
else 
  $sql = sprintf("SELECT count(*) as cnt  FROM %s.gov_questOb Q inner join  %s.govOb_results R on Q.ID=R.question WHERE qtype = %d and not isnull(result,0) = 0 and GOV_ID=%d  ", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_ID, $p_auditID);

  
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result["cnt"];
    }

    public function updateGOVOb_id($id, $answer, $problem, $comments,$fileid) {

        $sql = sprintf("update  %s.GOVOb_results set result=%d,problem='%s',comment='%s',fileID=%d where ID=%d", _DB_OBJ_FULL, $answer, $problem, $comments,$fileid, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

        public function updateGOVInt_id($id, $answer, $problem, $comments,$fileid) {

        $sql = sprintf("update  %s.GOVInt_results set result=%d,problem='%s',comment='%s',fileID=%d where ID=%d", _DB_OBJ_FULL, $answer, $problem, $comments,$fileid, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }
    
    public function add_action2($id, $data) {
        $this->aid = $id;
        $this->actionData = $data;


        if ($this->aid == 0) {

            $this->actionHandling->setActionDetails(0, $this->actionData);
            $new_action_id = $this->actionHandling->addAction2015();
        } else {

            $this->actionHandling->setActionDetails($this->aid, $this->actionData);
            $new_action_id = $this->actionHandling->updateAction2015();
        }
        
        if ($this->actionData["element"] =='govOb_results')
           $sql = sprintf("update %s.GOVOb_results set actionID=%d where ID=%d ", _DB_OBJ_FULL, $new_action_id, $this->actionData["record"]);
        else
           $sql = sprintf("update %s.GOVInt_results set actionID=%d where ID=%d ", _DB_OBJ_FULL, $new_action_id, $this->actionData["record"]);
        
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    public function addDocFiles($hdr) {

        $record_data = $this->reviewDocId;

        $new_files_id_string = $record_data['uploadFilesID'] . ',' . $this->reviewInfo['file_id'];
        $new_files_id_string = ltrim($new_files_id_string, ',');

       $sql2 = sprintf("insert into %s.gov_files (fileID,questionID,type) VALUES (%d,%d,%d)", _DB_OBJ_FULL, $new_files_id_string, $this->reviewID,$hdr);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }
    
       public function listOpenReviewOb($p_govID) {

     $sql = sprintf("SELECT *  FROM %s.gov_Observation WHERE GOV_ID = %d order by iD desc", _DB_OBJ_FULL, $p_govID);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    } 
    
           public function listOpenReviewInt($p_govID) {

       $sql = sprintf("SELECT *  FROM %s.gov_Interview WHERE GOV_ID = %d  order by iD desc", _DB_OBJ_FULL, $p_govID);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
    
        public function getGOVParentData($p_ID,$hdr) {
if($hdr == 1)
    $sql = sprintf("select * from %s.gov_master M inner join %s.GOV_observation D on M.reviewID=D.gov_ID where D.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,$p_ID);
else
         $sql = sprintf("select * from %s.gov_master M inner join %s.GOV_interview D on M.reviewID=D.gov_ID where D.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,$p_ID);
        
$stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    
            public function getCompanies($archive) {
                            
			$sql = sprintf("select * from %s.gov_company", _DB_OBJ_FULL);
$stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
         public function getCompany($p_id) {

         $sql = sprintf("select * from %s.gov_company where id=%d", _DB_OBJ_FULL,$p_id);
$stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
	         public function editCompany() {
 
if ($this->reviewID == 0)
	     $sql = sprintf("insert into  %s.gov_company (company) values ('%s') ", _DB_OBJ_FULL,$this->reviewInfo["company"]);	
 else
      $sql = sprintf("update  %s.gov_company set company='%s' where id=%d", _DB_OBJ_FULL,$this->reviewInfo["company"], $this->reviewID);

$stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

    }
}

?>