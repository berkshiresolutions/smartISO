<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class PCI {

    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */

    /**
     * Property to hold PCI Id
     * @access private
     */
    private $PCIId;

    /**
     * Property to hold PCI Info
     * @access private
     */
    private $PCIInfo;

    public function __construct($id = 0) {

         
$this->dbHand 			= DB::connect(_DB_TYPE);
    }

    public function setPCIInfo($p_PCIId, $p_PCIInfo) {
//dump_array($p_Risk27kInfo);
        $this->PCIId = $p_PCIId;
        $this->PCIInfo = $p_PCIInfo;
    }

    public function getQuestionList1() {

        $sql = sprintf("SELECT question
				FROM %s.pci_question_new
				", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();

        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);
        //$questions = explode(',',$rec['ques']);
        $questionsCount = count($rec);

        $questionList = array();

        for ($i = 0; $i < $questionsCount; $i++) {
            $k = $i + 1;
            $questionList[$k] = $rec[$i];
        } // end for

        return $questionList;
    }

    public function getAnswers1() {

        $sql = sprintf("SELECT * FROM %s.pci_answer WHERE  reviewID = %d ", _DB_OBJ_FULL, $this->PCIInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);


        return $rec;
    }

    public function listClosedPci($p_archive_val = 0) {

        $sql = sprintf("SELECT * FROM %s.pciReview WHERE complete = 1 AND archived = %s ", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listOpenPci($p_archive_val = 1) {

        $sql = sprintf("SELECT * FROM %s.pciReview WHERE archived = %s AND (complete IS NULL OR complete != 1) ORDER BY ID DESC", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function savePCIAnswer($q_no, $yes, $cw, $no, $na, $comment, $radio, $r_id, $action, $summary, $date, $who, $who_hidden,$whoAU,$whoAU2, $comment_a, $saq, $file) {
        $this->q_no = $q_no;
        $this->yes = $yes;
        $this->cw = $cw;
        $this->no = $no;
        $this->na = $na;
        $this->comment = $comment;
        $this->radio = $radio;
        $this->r_id = $r_id;
        $this->action = $action;
        $this->summary = $summary;
        $this->date_t = format_date_for_mysql($date);
        $this->who = $who;
        $this->who_hidden = $who_hidden;
        $this->comment_a = $comment_a;
        $this->saq = $saq;
        $this->file = $file;
        $sql = sprintf("select * FROM %s.pci_answer
				WHERE reviewID = " . $this->r_id . "
				AND ques_no = '" . $this->q_no . "'"
                , _DB_OBJ_FULL
        );

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
if ($rec){
      $sql11 = sprintf("UPDATE %s.pci_answer set reviewID=$this->r_id,ques_no='$this->q_no',yes='$this->yes',cw='$this->cw',no='$this->no',na='$this->na',comment='$this->comment',radio='$this->radio',action='$this->action',summary='$this->summary',date='$this->date_t',who='$this->who',who_h='$this->who_hidden',comment_a='$this->comment_a',saq='$this->saq',file_name='$this->file'
		where ID=%d"
                , _DB_OBJ_FULL,$rec["ID"]
        );
              $stmt = $this->dbHand->prepare($sql11);

        $stmt->execute();
 $recID=$rec["ID"];
}
else{
        $sql11 = sprintf("INSERT INTO %s.pci_answer (reviewID,ques_no,yes,cw,no,na,comment,radio,action,summary,date,who,who_h,comment_a,saq,file_name)
						VALUES ($this->r_id, '$this->q_no', '$this->yes', '$this->cw', '$this->no','$this->na', '$this->comment','$this->radio','$this->action','$this->summary','$this->date_t','$this->who','$this->who_hidden','$this->comment_a','$this->saq','$this->file')"
                , _DB_OBJ_FULL
        );
                $stmt = $this->dbHand->prepare($sql11);

        $stmt->execute();
       $recID = customLastInsertId($this->dbHand,'pcianswer','ID');
}

	$actionObj = new Action();	
	 $actionExists = $actionObj->getActionLinkedTo($recID, 'pciAnswer');	
         
         $actionData = array('description' => $this->summary,
            'who' => $this->who_hidden,
            'whoAU' => $whoAU,
            'who2AU' => $whoAU2,
            'module_name' => 'PCI',
            'record' =>  $recID,
            'status' => 1,
            'buname' => $bu["buName"],
            'currentwho' => $this->who_hidden,
            'element' => "pciAnswer",
            'due_date' => $date);


        if ($actionExists){
             $actionObj->setActionDetails($actionExists["ID"], $actionData);
            $actionObj->updateAction2015();
        }
        else
        {
             $actionObj->setActionDetails(0, $actionData);
            $action_id = $actionObj->addAction2015();
    }
         
    }



    public function addPciReview() {
        // buIDs have been removed from the below as if added in future they should be attached to the review rather than stored delimited
        $sql = sprintf("INSERT INTO %s.pciReview(pciName,startDate,location,archived,complete,uniqueReference) 
			OUTPUT INSERTED.ID
			VALUES ('%s' ,'%s' ,%d,0,0 ,'%s')"
                , _DB_OBJ_FULL
                , $this->PCIInfo['name']
                , $this->PCIInfo['date']
                , $this->PCIInfo['location']
                , $this->PCIInfo['ref']
        );

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $res = $pStatement->fetch(PDO::FETCH_ASSOC);
        $this->PCIId = $res['ID'];
        if (!$res) { // DEAL WITH RETURNING FALSE
            mail('server@smart-iso.com', 'server error ' . $_SERVER['SERVER_NAME'], "SQL ERROR\r\n\r\nSQL:\r\n" . $sql . "\r\nError:\r\n" . var_export($this->dbHand->errorInfo()));
        }
    }

    public function finishPci() {
        $sql = sprintf(
                "UPDATE %s.pciReview SET complete=1 WHERE ID = %d ", _DB_OBJ_FULL, $this->PCIInfo['reviewID']
        );

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function lastRecordId() {
        return $this->PCIId;
    }

    public function getQuestionInfo1($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT * FROM %s.pci_question_new
				WHERE ID = %d", _DB_OBJ_FULL, $p_questionIdentifier);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$p_questionIdentifier);
        $stmt->execute();



        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getQuestionInfo14($p_questionIdentifier, $rid) {

        //$p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT * FROM %s.pci_question_new
				WHERE  id_q = '" . $rid . "' ", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$p_questionIdentifier);
        $stmt->execute();



        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getQuestionAnswerInfo1($p_questionIdentifier, $id) {

        $this->id = $id;
        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT * FROM %s.pci_answer 
				 WHERE ques_no = '" . $p_questionIdentifier . "' AND reviewID =" . $this->id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

public function getAttemptedQuestionStats1($p_reviewID) {

		$this->rew = $p_reviewID;


	 	$sql = sprintf("SELECT max(cast(ques_no as int)) as countQ FROM %s.pci_answer WHERE reviewID = ".$this->rew,_DB_OBJ_FULL);

		$stmt 	= $this->dbHand->prepare($sql);

		$stmt->execute();
                $result=$stmt->fetch(PDO::FETCH_ASSOC);
		return $result["countQ"];
	}

	public function getAttemptedSectionQuestionStats1($p_id,$p_sectionHeadingCode,$reviewID) {
	//cannot think of another solution as the jumping means not all questions answwered
	$this->rew = $p_sectionHeadingCode;
        $this->qid = $p_id;
	$sql = sprintf("SELECT * FROM %s.pci_question_new WHERE section = %d and id<= %d",_DB_OBJ_FULL,$this->rew,$this->qid);

		$stmt 	= $this->dbHand->prepare($sql);
$count=0;
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                for ($x=0;$x<count($result);$x++){
            //    foreach($result as $row){
                  $ans=$this->getAnswers1a($reviewID, $result[$x]["ID"]);

                  if (!$ans)
                      continue;
                 else if ($ans["yes"] == 1 ){
                     $count++;
                      continue;
                 }
                 else if ($ans["cw"] == 1){
                     $count++;
                      continue;
                  
                }
                else{
                   $groupCount=  $this->getGroupCount($result[$x]["id_q"]);
                   $count+=$groupCount;
                    $x=$x+$groupCount-1;
                   //add jumps
                }
                }

		
		return $count;
	}
        
    public function getAttemptedSectionQuestionStats1xxx($p_sectionHeadingCode) {
        $sql = sprintf("SELECT ID FROM %s.pci_answer
				WHERE reviewID = 1
				"
                , _DB_OBJ_FULL
        );

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $c = count($result);
        return $c;
    }

    public function addSoaData116($head, $ques, $test, $guide, $note, $ref, $ref1, $text4, $text5, $text6, $text7, $ques1, $idd, $r) {

        $this->head = $head;
        $this->ques = $ques;
        $this->test = $test;
        $this->guide = $guide;
        $this->note = $note;
        $this->ref = $ref;
        $this->ref1 = $ref1;
        $this->text4 = $text4;
        $this->text5 = $text5;
        $this->text6 = $text6;
        $this->text7 = $text7;
        $this->ques1 = $ques1;
        $this->idd = $idd;


        $sql = sprintf("INSERT INTO %s.pci_question_new(head,question,testing,guide,notes,ref,ref_1,text4,text5,text6,text7,ques,id_q,r)
						VALUES ( '$this->head' ,'$this->ques' ,'$this->test','$this->guide','$this->note','$this->ref','$this->ref1','$this->text4','$this->text5','$this->text6','$this->text7','$this->ques1','$this->idd','$this->r')"
                , _DB_OBJ_FULL
        );

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function getQuestionAnswerInfo15($p_questionIdentifier, $id) {
        $this->id = $id;
        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT * FROM %s.pci_yes_check 
				 WHERE quesID = '" . $p_questionIdentifier . "' AND reviewID ='" . $this->id . "'", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function toggleArchived() {
        $sql = sprintf("UPDATE %s.soaReview SET archived=%d WHERE ID = %d ", _DB_OBJ_FULL, ($this->isArchived() ? 0 : 1), $this->PCIInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function toggleArchived1() {
        $sql = sprintf("UPDATE %s.pciReview SET archived=%d WHERE ID = %d ", _DB_OBJ_FULL, ($this->isArchived() ? 0 : 1), $this->PCIInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function getQuestions1() {
        $sql = sprintf("SELECT * FROM %s.pci_question_new ORDER BY ID ASC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAnswers1a($reviewID, $ID) {
        $this->id = $ID;
       $sql = sprintf("SELECT * FROM %s.pci_answer WHERE reviewID = %d AND ques_no = " . $this->id, _DB_OBJ_FULL, $reviewID);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        return $rec;
    }

    public function listOpenPci23($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.pciReview WHERE ID = " . $this->id . "  ORDER BY ID DESC", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
	
	    public function getAnswersGroup($reviewID, $ID,$link) {
        //$sql = sprintf("SELECT A.* FROM %s.pci_question_new Q left join %s.pci_answer A on Q.ID=A.quest_no WHERE q.id_q=24 andreviewID = %d AND ques_no = %d" , _DB_OBJ_FULL, _DB_OBJ_FULL, $reviewID,$ID);
	$sql = sprintf("SELECT * FROM %s.pci_answer  where reviewid =%d and (cw=1 or yes=1)and ques_no in (select id from %s.pci_question_new where id_q=%d )", _DB_OBJ_FULL,$reviewID, _DB_OBJ_FULL,$link);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetchALL(PDO::FETCH_ASSOC);

        return $rec;
    }
	    public function getNextFromGroup($link) {
                $link++;
	$sql = sprintf("select id from %s.pci_question_new where id_q=%d order by ID", _DB_OBJ_FULL,$link);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetchALL(PDO::FETCH_ASSOC);

        return $rec[0]['id'];
    }
	
		    public function getFromGroup($link) {

		$sql = sprintf("select id from %s.pci_question_new where id_q=%d order by ID", _DB_OBJ_FULL,$link);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetchALL(PDO::FETCH_ASSOC);

        return $rec[0]['id'];
    }
      public function getQuestionSearch($search) {
                $link++;
	$sql = sprintf("select id from %s.pci_question_new where r like '%s' order by ID", _DB_OBJ_FULL,$search."%");
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        return $rec['id'];
    }
    
    		    public function getGroupCount($link) {

	$sql = sprintf("select id from %s.pci_question_new where id_q=%d", _DB_OBJ_FULL,$link);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetchALL(PDO::FETCH_ASSOC);

        return count($rec);
    }
}
