<?php

/**
  $Id: SendActionAlerts.class.php,v 3.17 Friday, February 04, 2011 3:21:19 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Alert Class
 * @since  Saturday, December 04, 2010 4:17:45 PM>
 */
class SendActionAlerts extends Email {

    private $moduleName;
    private $recordId;
    private $mailData;
    private $participantObj;
    private $emailObj;
    private $moduleClassobj;

    public function __construct($p_module, $p_record_id) {

        $this->moduleName = $p_module;
        $this->recordId = $p_record_id;

        $this->participantObj = SetupGeneric::useModule('Participant');
    }

    public function sendAlerts() {

        $dyn_function_name = ucwords($this->moduleName) . 'Alerts';

        $this->$dyn_function_name();

        if ($dyn_function_name == 'RiskInvalidAlerts') {

            $this->mailData = $this->moduleClassobj->sendInvalidAssessmentAlert($this->recordId);
            $this->moduleName = 'RISKINVALID';
        } else if ($dyn_function_name == 'TrainingParticipantAlerts') {

            $this->mailData = $this->moduleClassobj->assignCourseTraniee($this->recordId);
            $this->moduleName = 'ASSIGNCOURSEP';
        } else if ($dyn_function_name == 'TrainingInstAlerts') {

            $this->mailData = $this->moduleClassobj->assignCourseInst($this->recordId);
            $this->moduleName = 'ASSIGNCOURSET';
        } else if ($dyn_function_name == 'IncidenceActionReportAlerts') {

            $this->mailData = $this->moduleClassobj->sendReportableActions($this->recordId);
            $this->moduleName = 'INCIDENCEACTIONREPORTABLE';
        } else if ($dyn_function_name == 'SmartlawreviewAlerts') {

            $this->mailData = $this->moduleClassobj->sendReviewActions($this->recordId);
            $this->moduleName = 'SMARTLAWREVIEW';
        } else {

            $this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        }



        if ($dyn_function_name == 'InspectionAlerts') {

            switch ($this->mailData[0]['tab']) {
                case 2: $this->moduleName = 'INSPECTIONC';
                    break;
                case 3: $this->moduleName = 'INSPECTIONR';
                    break;
                case 4: $this->moduleName = 'INSPECTIONM';
                    break;
                case 5: $this->moduleName = 'INSPECTIONH';
                    break;
                case 6: $this->moduleName = 'INSPECTIONAH';
                    break;
                case 7: $this->moduleName = 'INSPECTIONH';
                    break;
                case 8: $this->moduleName = 'INSPECTIONH';
                    break;
            }
        }

        $this->formatData();

        //echo $this->recordId.'-----------';
        //dump_array($this->mailData);

        $email_token = strtoupper($this->moduleName);
        $email_token_au = strtoupper($this->moduleName . '_au');

        if (count($this->mailData)) {
            foreach ($this->mailData as $value) {

                if ($value['email'] != '') {


                    $this->emailObj = new Email('html');
                    try {

                        $this->emailObj->addRecipient($value['who'], $value['email'], $value['salutation']);
                        $this->emailObj->generateEmail($email_token, $value);
                        $this->emailObj->send(_LIVE_MODE);

                        $this->emailObj = null;
                        $this->emailObj = new Email('html');

                        //$this->emailObj->flushRecipient();

                        if ($value['whoAU'] != '') {

                            $this->emailObj->addRecipient($value['whoAU'], $value['emailAU'], $value['salutationAU']);
                            $this->emailObj->generateEmail($email_token_au, $value);
                            $this->emailObj->send(_LIVE_MODE);
                        }
                    } catch (ErrorException $e) {
                        $e->getMessage();
                    }
                }
            }
        }

        //return $this->mailData;
    }

    private function IncidenceActionReportAlerts() {
        $this->moduleClassobj = new IncidenceMain();
    }

    private function IncidenceVoidActionAlerts() {
        $this->moduleClassobj = new IncidenceMain();
    }

    private function IncidenceVoidActionAUAlerts() {
        $this->moduleClassobj = new IncidenceMain();
    }

    private function IncidenceModifiedActionAlerts() {
        $this->moduleClassobj = new IncidenceMain();
    }

    private function TrainingParticipantAlerts() {
        $this->moduleClassobj = new Training();
    }

    private function TrainingInstAlerts() {
        $this->moduleClassobj = new Training();
    }

    private function RiskInvalidAlerts() {
        $this->moduleClassobj = new RiskAssessment();
    }

    private function RiskAlerts() {

        $this->moduleClassobj = new RiskAssessment();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function RiskVoidActionAlerts() {
        $this->moduleClassobj = new RiskAssessment();
    }

    private function RiskVoidActionAUAlerts() {
        $this->moduleClassobj = new RiskAssessment();
    }

    private function RiskModifiedActionAlerts() {
        $this->moduleClassobj = new RiskAssessment();
    }

    private function NhpVoidActionAlerts() {
        $this->moduleClassobj = new Nhpmain();
    }

    private function NhpVoidActionAUAlerts() {
        $this->moduleClassobj = new Nhpmain();
    }

    private function NhpModifiedActionAlerts() {
        $this->moduleClassobj = new RiskAssessment();
    }

    private function Risk27kVoidActionAlerts() {
        $this->moduleClassobj = new Risk27k();
    }

    private function Risk27kVoidActionAUAlerts() {
        $this->moduleClassobj = new Risk27k();
    }

    private function Risk27kModifiedActionAlerts() {
        $this->moduleClassobj = new Risk27k();
    }

    private function InspectionAlerts() {

        $this->moduleClassobj = new InspectionMain();
        /* $this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);

          switch ( $this->mailData[0]['tab'] ) {
          case 2: $this->moduleName = 'INSPECTIONC'; break;
          case 3: $this->moduleName = 'INSPECTIONR'; break;
          case 4: $this->moduleName = 'INSPECTIONM'; break;
          case 5: $this->moduleName = 'INSPECTIONH'; break;
          case 6: $this->moduleName = 'INSPECTIONAH'; break;
          } */

        /* dump_array($this->mailData);
          exit; */
        //echo $this->recordId;
    }

    private function IncidenceAlerts() {

        $this->moduleClassobj = new IncidenceMain();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function InvestigationAlerts() {

        $this->moduleClassobj = new InvestigationMain();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function InvestigationVoidActionAlerts() {
        $this->moduleClassobj = new InvestigationMain();
    }

    private function InvestigationVoidActionAUAlerts() {
        $this->moduleClassobj = new InvestigationMain();
    }

    private function InvestigationModifiedActionAlerts() {
        $this->moduleClassobj = new InvestigationMain();
    }

    private function NhcinvestigationAlerts() {

        $this->moduleClassobj = new NhcInvestigationMain();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function NhcinvestigationVoidActionAlerts() {
        $this->moduleClassobj = new NhcInvestigationMain();
    }

    private function NhcinvestigationVoidActionAUAlerts() {
        $this->moduleClassobj = new NhcInvestigationMain();
    }

    private function NhcinvestigationModifiedActionAlerts() {
        $this->moduleClassobj = new NhcInvestigationMain();
    }

    private function NhpAlerts() {

        $this->moduleClassobj = new NhpMain();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function DseAlerts() {

        $this->moduleClassobj = new DseAssessment();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function ManualHandlingAlerts() {

        $this->moduleClassobj = new ManualHandling();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function ComplaintAlerts() {

        $this->moduleClassobj = new Complaint();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //dump_array($this->mailData);
        //echo $this->recordId;
    }

    private function MsractionAlerts() {
        $this->moduleClassobj = new ReviewGap();
    }

    private function Risk27KAlerts() {

        $this->moduleClassobj = new Risk27k();
        //$this->mailData = $this->moduleClassobj->sendActionAlerts($this->recordId);
        //echo $this->recordId;
    }

    private function ContractReviewF1Alerts() {
        $this->moduleClassobj = new Contract();
    }

    private function SmartlawAlerts() {
        $this->moduleClassobj = new SmartLaw();
    }

    private function SmartlawReviewAlerts() {
        $this->moduleClassobj = new SmartLaw();
    }

    private function formatData() {

        if (count($this->mailData)) {

            foreach ($this->mailData as $key => $value) {

                if ($this->moduleName == 'ASSIGNCOURSET') {

                    $participant_details['forename'] = $this->mailData[$key]['inst_fname'];
                    $participant_details['surname'] = $this->mailData[$key]['inst_lname'];
                    $participant_details['emailAddress'] = $this->mailData[$key]['email'];
                    $salutation = "";
                } else {

                    $this->participantObj->setItemInfo(array(
                        'id' => $value['who']
                    ));

                    $participant_details = $this->participantObj->displayItemById();

                    if ($participant_details['gender'] == 'F') {
                        $salutation = 'Ms.';
                    } else {
                        $salutation = 'Mr.';
                    }

                    // for AU approver
                    if ($value['whoAU']) {

                        $this->participantObj->setItemInfo(array(
                            'id' => $value['whoAU']
                        ));

                        $participant_details_au = $this->participantObj->displayItemById();

                        if ($participant_details_au['gender'] == 'F') {
                            $salutation_au = 'Ms.';
                        } else {
                            $salutation_au = 'Mr.';
                        }
                    }
                }


                $this->mailData[$key]['who'] = $participant_details['forename'] . ' ' . $participant_details['surname'];
                $this->mailData[$key]['email'] = $participant_details['emailAddress'];
                $this->mailData[$key]['salutation'] = $salutation;

                if ($value['whoAU']) {
                    $this->mailData[$key]['whoAU'] = $participant_details_au['forename'] . ' ' . $participant_details_au['surname'];
                    $this->mailData[$key]['emailAU'] = $participant_details_au['emailAddress'];
                    $this->mailData[$key]['salutationAU'] = $salutation_au;
                }
            }
        }
    }

    public function sendAlertsRiskInvalid() {
     
        $pfObj = new ProcessFlowMaster($p_actionid);
        $actionObj = new Action();
        $manObj = SetupGeneric::useModule('Participant');
        $data1 = $pfObj->displayProcessFlowById($this->recordId);

        $this->actionData['module_name'] = "risk";
        $this->actionData['description'] = "Carry out a Risk Assessment for ".$data['description']." as it is no longer considered valid";
        $this->actionData['who'] = $data1['whoID'];


        $dataMan = $manObj->getManagerDetails($data1['whoID']);
        $this->actionData['whoAU'] = $dataMan['participantID'];
        $this->actionData['due_date'] = date("m/d/Y", strtotime("+2 week"));
        $this->actionData['status'] = 1;
        $this->actionData['record'] = $data1['swimID'];
        $this->actionData['element'] = "process_flow";

        $actionObj->setActionDetails(0, $this->actionData);
        $p_actionid = $actionObj->addAction2015();


        
        $emailObj = new actionEmailHelper($p_actionid);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/process_risk_assessment/list_process_steps.php?risk_id='.$data['swimID'].'>CLICK</a> Here to Start a Risk Assessment Review'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => str_replace("PF","PR",$data1['reference'])
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('An Invalid Risk Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
           
    }
    public function sendAlertsNoProcess($p_buID,$p_type,$p_record,$p_ref_No,$who=0) {
        $actionObj = new Action();
        $manObj    = SetupGeneric::useModule('Participant');
        $authObj   = SetupGeneric::useModule('AuthorizedUser');
       
if($who==0)
 	$pf_au	= $authObj->getIssuerPermissionBu('perm_pflow',$p_buID,0);
     else {
    $pf_au=$who;     
     }
     if(!$pf_au){
         $details = $manObj->getAdminDetails();
          $pf_au=$details["participantID"];
     }
        $this->actionData['module_name'] = "PF";
        $this->actionData['description'] = "A Process Flow is required for ".$p_ref_No;
        $this->actionData['who'] = $pf_au;

        $dataMan = $manObj->getManagerDetails($pf_au);
        $this->actionData['whoAU'] = $dataMan['participantID'];
        $this->actionData['due_date'] = date("m/d/Y", strtotime("+2 week"));
        $this->actionData['status'] = 1;
        $this->actionData['record'] = 0;
        $this->actionData['element'] = "process_flow";

        switch ($p_type){
         case "nhc_investigation" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/nhc_investigation/report.php?cid='.$p_record;break;
	 case "manual_handling" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/manual_handling/report.php?cid='.$p_record;break;
         case "smartlaw_review" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/smart_law/index.php?cid='.$p_record;break;
        }
     
        $actionObj->setActionDetails(0, $this->actionData);
        $p_actionid = $actionObj->addAction2015();
        $actionObj->insertRequestRecord($p_actionid, $p_record, $p_type);
        $pfurl= 'https://' . $_SERVER['HTTP_HOST'] . '/process_flow/manage_process_flow.php?aid='.$p_actionid;
        $emailObj = new actionEmailHelper($p_actionid);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                'click-here-url' => '<BR><BR>As no Process is available for '.$p_ref_No.' please create a new process flow.<BR>Please <a href='. $url.'>CLICK</a> Here to view the record<BR><BR>Please <a href='. $pfurl.'>CLICK</a> Here to create the new process flow'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $p_ref_No
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('Create a Process Flow Action', $who, array(), array(), 'me_completed', '', 'grey');
           
    }
   
    public function sendAlertsAccident($p_buID,$p_type,$p_record,$p_ref_No,$who=0) {
        $actionObj = new Action();
        $manObj    = SetupGeneric::useModule('Participant');
        $authObj   = SetupGeneric::useModule('AuthorizedUser');

       
if($who==0)
 	$acc_au	= $authObj->getIssuerPermissionBu('perm_acc_rep',$p_buID,0);
     else {
    $acc_au=$who;     
     }
     if(!$acc_au){
         $details = $manObj->getAdminDetails();
          $acc_au=$details["participantID"];
     }
        $this->actionData['module_name'] = "incidence";
        $this->actionData['description'] = "A Report is required for ".$p_ref_No;
        $this->actionData['who'] = $acc_au;

        $dataMan = $manObj->getManagerDetails($acc_au);
        $this->actionData['whoAU'] = $dataMan['participantID'];
        $this->actionData['due_date'] = date("m/d/Y", strtotime("+1 week"));
        $this->actionData['status'] = 1;
        $this->actionData['record'] = $p_record;
        $this->actionData['element'] = "incidence";

        switch ($p_type){
         case "nhc_investigation" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/nhc_investigation/report.php?cid='.$p_record;break;
	 case "manual_handling" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/manual_handling/report.php?cid='.$p_record;break;
         case "smartlaw_review" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/smart_law/index.php?cid='.$p_record;break;
         case "incidence" : $url= 'https://' . $_SERVER['HTTP_HOST'] . '/incidence/pdfReport.php?type=R1&id='.$p_record;break;
     
        }
     
        $actionObj->setActionDetails(0, $this->actionData);
        $p_actionid = $actionObj->addAction2015();
        $actionObj->insertRequestRecord($p_actionid, $p_record, $p_type);

        $emailObj = new actionEmailHelper($p_actionid);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                 'click-here-url' => '<BR><BR>This incident '.$p_ref_No.' requires an incidence Report is sent to the relevent Authority.<BR>Please <a href='. $url.'>CLICK</a> Here to view the record<BR>'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $p_ref_No
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('Create an Incidence Report', $who, array(), array(), 'me_completed', '', 'grey');
           
    }
    
     public function sendIncidenceDetail($p_buID,$p_type,$p_record,$p_ref_No,$who=0) {
        $actionObj = new Action();
        $manObj    = SetupGeneric::useModule('Participant');
        $authObj   = SetupGeneric::useModule('AuthorizedUser');
        $objReference		= new UniqueReference();
       $reference	= $objReference->getNumber('INVESTIGATION');
               $this->dbHand = DB::connect(_DB_TYPE);
               
if($who==0)
 	$acc_au	= $authObj->getIssuerPermissionBu('perm_acc_rep',$p_buID,0);
     else {
    $acc_au=$who;     
     }
     if(!$acc_au){
         $details = $manObj->getAdminDetails();
          $acc_au=$details["participantID"];
     }
     
        $sql2 = sprintf("INSERT INTO %s.investigation (incID,reference,uniqueReference,archive,status,whoID)
											VALUES (%d,'%s','%s','0','0',%d)", _DB_OBJ_FULL, $p_record, $reference, $reference, $acc_au);
            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();
     
     $investigationId = customLastInsertId($this->dbHand, 'investigation', 'ID');
     
        $this->actionData['module_name'] = "investigation";
        $this->actionData['description'] = "An Incidence Investigation is to be carried out for ".$p_ref_No;
        $this->actionData['who'] = $acc_au;

        $dataMan = $manObj->getManagerDetails($acc_au);
        $this->actionData['whoAU'] = $dataMan['participantID'];
        $this->actionData['due_date'] = date("m/d/Y");
        $this->actionData['status'] = 1;
        $this->actionData['record'] = $investigationId;
        $this->actionData['element'] = "investigation";

        $url= 'https://' . $_SERVER['HTTP_HOST'] . '/incidence/pdfReport.php?type=R1&id='.$p_record;
     
        $url1= 'https://' . $_SERVER['HTTP_HOST'] . '/investigation/add_edit_incidence_details.php?cid='.$investigationId;
     
        $actionObj->setActionDetails(0, $this->actionData);
        $p_actionid = $actionObj->addAction2015();

        $emailObj = new actionEmailHelper($p_actionid);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                'click-here-url' => '<BR><BR>The incident '.$p_ref_No.' requires an Incidence Investigation.<BR>Please <a href='. $url.'>CLICK</a> Here to view the incident record<BR><BR>Please <a href='. $url1.'>CLICK</a> here to carry out the Investigation<BR>'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $reference
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('Create an Incidence Investigation', $who, array(), array(), 'me_completed', '', 'grey');

    }
   
}



?>