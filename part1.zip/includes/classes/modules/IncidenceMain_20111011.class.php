<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "Incidence.int.php";
require_once "Action.class.php";

class IncidenceMain implements Incidence
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 * property contains witness data
	 * @access private
	 */
	private $witnessData;

	/**
	 *Property to hold Incidence Id
	 *@access private
	 */
	private $incidenceId;

	/**
	 *Property to hold Incidence Info
	 *@access private
	 */
	private $incidenceInfo;


	/**
	 * Constructor for initializing Incidence object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 				= DB::connect(_DB_TYPE);
		$this->actionHandling		= new Action();
		$this->accidentReportable 	= false;
	}


	/*
	 * This method is used to set incidence information for the respective object
	 */
	public function setIncidenceInfo($p_incidenceId,$p_incidenceInfo) {
		$this->incidenceId = $p_incidenceId;
		$this->incidenceInfo = $p_incidenceInfo;
	}

	/*
	 * This method is used to add new incidence
	 * reference,unique_reference,incidence_date,incidence_date_time,location,business_unit
	 */
	public function addIncidence() {

		$sql = sprintf("SELECT * FROM %s.incidence WHERE reference LIKE '%s'",_DB_OBJ_FULL,$this->incidenceInfo['reference']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->incidenceInfo['reference']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {
			throw new ErrorException('Incidence with this Reference # already exists.');
		} else {

			$USER_ID = getLoggedInUserId();

			$sql2 = sprintf("INSERT INTO %s.incidence (reference,uniqueReference,incidenceDateTime,locID,buID,driverTest,instructor,archive,status,whoID,
							accidentReportable)
											VALUES ('%s','%s','%s',%d,%d,'%s',%d,'0','0',%d,'%s')",_DB_OBJ_FULL,$this->incidenceInfo['reference'],
											$this->incidenceInfo['unique_reference'],format_date_time_for_mysql($this->incidenceInfo['incidence_date']),
											$this->incidenceInfo['location'],$this->incidenceInfo['business_unit'],$this->incidenceInfo['driver_test'],
											$this->incidenceInfo['instructor_name'],$this->incidenceInfo['whoID'],$this->incidenceInfo['accident_reportable']);
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->incidenceInfo['reference']);
			$pStatement2->bindParam(2,$this->incidenceInfo['unique_reference']);
			$pStatement2->bindParam(3,format_date_time_for_mysql($this->incidenceInfo['incidence_date']));
			$pStatement2->bindParam(4,$this->incidenceInfo['location']);
			$pStatement2->bindParam(5,$this->incidenceInfo['business_unit']);*/

			$pStatement2->execute();
			//dump_array($pStatement2->errorInfo());
			$this->incidenceId = customLastInsertId( $this->dbHand,'incidence','ID');

			//$this->trackRecord();
		}

	}

	public function getLastInsertID() {
		return $this->incidenceId;
	}

	private function trackRecord() {
		$trackRec = new ModuleTracker();
		$trackRec->setModuleTrackerInfo('INCD',array('rec_id'=>$this->incidenceId,'role'=>'O','ref'=>$this->incidenceInfo['reference']));
		$trackRec->trackRecord();
	}

	/*
	 * This method is used to edit an incidence
	 * incidence_date,location,business_unit
	 */
	public function editIncidence() {

		$sql2 = sprintf("UPDATE %s.incidence SET incidenceDateTime = '%s',
										locID = %d,
										buID = %d,
										driverTest = %d,
										instructor = %d,
										accidentReportable = '%s',
										whoID = %d
									WHERE
										ID = %d",_DB_OBJ_FULL,format_date_time_for_mysql($this->incidenceInfo['incidence_date']),
										$this->incidenceInfo['location'],$this->incidenceInfo['business_unit'],
										$this->incidenceInfo['driver_test'],$this->incidenceInfo['instructor_name'],$this->incidenceInfo['accident_reportable'],
										$this->incidenceInfo['whoID'],
										$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,format_date_time_for_mysql($this->incidenceInfo['incidence_date']));
		$pStatement2->bindParam(2,$this->incidenceInfo['location']);
		$pStatement2->bindParam(3,$this->incidenceInfo['business_unit']);
		$pStatement2->bindParam(4,$this->incidenceId);*/

		$pStatement2->execute();
	}

	/*
	 * This method is used to update incidence participant
	 * is_participant,surname,forename,works_number,shift_work,gender
	 */
	public function manageParticipantOld() {

		$sql2 = sprintf("UPDATE %s.incidence SET isParticipant = '%s',
										participantSurname = '%s',
										participantForename = '%s',
										participantWorksNumber = '%s',
										participantShiftWork = '%s',
										participantGender = '%s',
										rtwDate = '%s',
										absentDays = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['is_participant'],
										$this->incidenceInfo['surname'],$this->incidenceInfo['forename'],
										$this->incidenceInfo['works_number'],$this->incidenceInfo['shift_work'],
										$this->incidenceInfo['gender'],$this->incidenceInfo['rtwDate'],
										$this->incidenceInfo['days_absent'],$this->incidenceId);


		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->incidenceInfo['is_participant']);
		$pStatement2->bindParam(2,$this->incidenceInfo['surname']);
		$pStatement2->bindParam(3,$this->incidenceInfo['forename']);
		$pStatement2->bindParam(4,$this->incidenceInfo['works_number']);
		$pStatement2->bindParam(5,$this->incidenceInfo['shift_work']);
		$pStatement2->bindParam(6,$this->incidenceInfo['gender']);
		$pStatement2->bindParam(7,$this->incidenceInfo['rtw_date']);
		$pStatement2->bindParam(8,$this->incidenceInfo['days_absent']);
		$pStatement2->bindParam(9,$this->incidenceId);*/

		$pStatement2->execute();
		//dump_array($pStatement2->errorInfo());
	}

	/*
	 * This method is used to update incidence activity
	 * treatment,impact,accident,part_body,nature_injury,hazard_class,hazards,factor
	 */
	public function manageActivity() {

		$sql2 = sprintf(" UPDATE %s.incidence SET activityTreatment = %d,
										activityImpact = %d,
										activityAccident = %d,
										activityPartBody = '%s',
										activityNatureInjury = '%s',
										activityHazardClass = %d,
										activityHazards = '%s',
										activityFactor = %d
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['treatment'],$this->incidenceInfo['impact'],
										$this->incidenceInfo['accident'],$this->incidenceInfo['part_body'],$this->incidenceInfo['nature_injury'],
										$this->incidenceInfo['hazard_class'],$this->incidenceInfo['hazards'],$this->incidenceInfo['factor'],
										$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();

		if ( !$this->isAccidentReportable() && $this->incidenceInfo['accident_reportable'] ) {
			$this->markAccidentAsReportable();
		}
	}

	/**
	 * This method is used to manage witness
	 * witness = array(array('participant'=>'dfg','works_number'=>'gdfg','surname'=>'gdfg',
	 * 							'forename'=>'dfg'f,'email'=>'gdfg','telephone'=>'dgdf','description'=>'sdf'),
	 * 					array('participant'=>'dfg','works_number'=>'gdfg','surname'=>'gdfg',
	 * 							'forename'=>'dfg'f,'email'=>'gdfg','telephone'=>'dgdf','description'=>'sdf'),
	 * 					array('participant'=>'dfg','works_number'=>'gdfg','surname'=>'gdfg',
	 * 							'forename'=>'dfg'f,'email'=>'gdfg','telephone'=>'dgdf','description'=>'sdf'));
	 */
	public function manageWitness() {

		if ( count($this->incidenceInfo['witness']) ) {
			foreach( $this->incidenceInfo['witness'] as $value ) {

				$this->witnessData = array('participant'=>$value['participant'],'works_number'=>$value['works_number'],'surname'=>$value['surname'],
										   'forename'=>$value['forename'],'email'=>$value['email'],'telephone'=>$value['telephone'],
										   'description'=>$value['description']);
				if ( $value['witness_id'] ) {
					// do update
					$this->editWitness($value['witness_id']);
				} else {
					// do add
					$this->addWitness();
				}
			}
		}

		$sql2 = sprintf(" UPDATE %s.incidence SET noWitness = '%s'
								WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['no_witness'],$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->incidenceInfo['no_witness']);
		$pStatement2->bindParam(2,$this->incidenceId);*/

		$pStatement2->execute();
	}

	private function addWitness() {

		//$rtw_date = $this->witnessData['rtw_date'] == '' ? '' : format_date_for_mysql($this->witnessData['rtw_date']);

		$sql = sprintf("INSERT INTO %s.incidence_witness (incID,isParticipant,surname,forename,worksNumber,emailAddress,telephone,description)
										VALUES (%d,'%s','%s','%s','%s','%s','%s','%s') ",_DB_OBJ_FULL,$this->incidenceId,
										$this->witnessData['participant'],$this->witnessData['surname'],$this->witnessData['forename'],
										$this->witnessData['works_number'],$this->witnessData['email'],$this->witnessData['telephone'],
										$this->witnessData['description']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->bindParam(2,$this->witnessData['participant']);
		$pStatement->bindParam(3,$this->witnessData['surname']);
		$pStatement->bindParam(4,$this->witnessData['forename']);
		$pStatement->bindParam(5,$this->witnessData['works_number']);
		$pStatement->bindParam(6,$this->witnessData['email']);
		$pStatement->bindParam(7,$this->witnessData['telephone']);
		$pStatement->bindParam(8,$this->witnessData['description']);
		$pStatement->bindParam(9,$rtw_date);
		$pStatement->bindParam(10,$this->witnessData['absent_days']);*/

		$pStatement->execute();
		/*$a = $pStatement->errorInfo();
		if ( $a[0] != '0000') {
			echo $sql;
			echo "<br/>";
		}*/
	}

	private function editWitness($p_witness_id) {

		//echo $this->witnessData['rtw_date'];
		//$rtw_date = $this->witnessData['rtw_date'] == '' ? '' : format_date_for_mysql($this->witnessData['rtw_date']);
		//exit;

		$sql = sprintf("UPDATE %s.incidence_witness SET isParticipant = '%s',
											surname = '%s',
											forename = '%s',
											worksNumber = '%s',
											emailAddress = '%s',
											telephone = '%s',
											description = '%s'

										WHERE ID = %d",_DB_OBJ_FULL,$this->witnessData['participant'],$this->witnessData['surname'],
										$this->witnessData['forename'],$this->witnessData['works_number'],$this->witnessData['email'],
										$this->witnessData['telephone'],$this->witnessData['description'],$p_witness_id);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->witnessData['participant']);
		$pStatement->bindParam(2,$this->witnessData['surname']);
		$pStatement->bindParam(3,$this->witnessData['forename']);
		$pStatement->bindParam(4,$this->witnessData['works_number']);
		$pStatement->bindParam(5,$this->witnessData['email']);
		$pStatement->bindParam(6,$this->witnessData['telephone']);
		$pStatement->bindParam(7,$this->witnessData['description']);
		$pStatement->bindParam(8,$rtw_date);
		$pStatement->bindParam(9,$this->witnessData['absent_days']);
		$pStatement->bindParam(10,$p_witness_id);*/

		/*dump_array($this->witnessData);*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/
	}

	public function deleteWitness() {

		$sql = sprintf("DELETE FROM %s.incidence_witness WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['witness_id']);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);

		$pStatement->execute();

	}

	/*
	 * This method is used to update incidence problem
	 * description,detailed_description
	 */
	public function manageProblem() {

		$sql2 = sprintf("UPDATE %s.incidence SET problemDescription = '%s',
										problemDetailedInvestigation = '%s',
										noInvestigationReqReason = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['description'],$this->incidenceInfo['detailed_description'],$this->incidenceInfo['no_di_reason'],$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->incidenceInfo['description']);
		$pStatement2->bindParam(2,$this->incidenceInfo['detailed_description']);
		$pStatement2->bindParam(3,$this->incidenceId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage action
	 * actions = array(array('description'=>'dfg','who'=>'gdfg','due_date'=>'gdfg'),
	 * 					array('description'=>'dfg','who'=>'gdfg','due_date'=>'gdfg'),
	 * 					array('description'=>'dfg','who'=>'gdfg','due_date'=>'gdfg'));
	 */
	public function manageActions() {

		$action_array = $this->incidenceInfo['actions'];

		if ( count($action_array) ) {

			$action_ids = "";
			foreach( $action_array as $value ) {

				$this->actionData = array('module_name'=>'incidence','description'=>$value['action'],
								  'who'=>$value['who'],'due_date'=>$value['when']);
				if ( $value['action_id'] ) {
					// do update
					$this->actionHandling->setActionDetails($value['action_id'],$this->actionData);
					$this->actionHandling->updateAction();
					$action_ids .= $value['action_id'].',';
				} else {
					// do add
					$this->actionHandling->setActionDetails(0,$this->actionData);
					$new_action_id = $this->actionHandling->addAction();
					$action_ids .= $new_action_id.',';
				}
			}

			$action_ids = rtrim($action_ids,',');

			$sql2 = sprintf("UPDATE %s.incidence SET actionsID = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$action_ids,$this->incidenceId);

			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$action_ids);
			$pStatement2->bindParam(2,$this->incidenceId);*/

			$pStatement2->execute();
		}

		$sql3 = sprintf("UPDATE %s.incidence SET noActionReason = '%s',noAction = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['no_action_reason'],$this->incidenceInfo['no_action'],
									$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql3);

		$pStatement2->execute();
	}

	/*
	 * This method is used to update incidence process
	 * process,is_risk
	 */
	public function manageProcess() {

		$sql2 = sprintf(" UPDATE %s.incidence SET processID = %d,
										isRiskValid = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['process'],$this->incidenceInfo['is_risk'],$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->incidenceInfo['process']);
		$pStatement2->bindParam(2,$this->incidenceInfo['is_risk']);
		$pStatement2->bindParam(3,$this->incidenceId);*/

		$pStatement2->execute();
	}

	/*
	 * This method is used to delete an incidence
	 */
	public function deleteIncidence() {}

	/*
	 * This method is used to archive an incidence record
	 */
	public function archiveIncidence() {

		$sql2 = sprintf(" UPDATE %s.incidence SET archive = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['archive'],$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->incidenceInfo['archive']);
		$pStatement2->bindParam(2,$this->incidenceId);*/

		$pStatement2->execute();
	}

	/*
	 * This method is used to completely delete an incidence record
	 */
	public function purgeIncidence() {
		$incidence_details = $this->viewIncidenceById();
		//dump_array($incidence_details);
		$action_arr = explode(',',$incidence_details['actionsID']);
		//dump_array($action_arr);

		if ( count($action_arr) ) {
			foreach ( $action_arr as $value ) {
				if ( $value != '' ) {
					$this->actionHandling->setActionDetails($value,"");
					$this->actionHandling->deleteAction();
				}
			}
		}

		$sql = sprintf("DELETE FROM %s.incidence_participants WHERE incID = %d",_DB_OBJ_FULL,$this->incidenceId);

		$pStatement = $this->dbHand->prepare($sql);
	//	$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();

		$sql = sprintf("DELETE FROM %s.incidence_witness WHERE incID = %d",_DB_OBJ_FULL,$this->incidenceId);

		$pStatement = $this->dbHand->prepare($sql);
	//	$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();

		$sql2 = sprintf("DELETE FROM %s.incidence WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);
		//$pStatement2->bindParam(1,$this->incidenceId);
		$pStatement2->execute();

		/* to delete related investigations */
		$invObj		=		new InvestigationMain();

		$invObj->setInvestigationInfo(1,array('incidence_id'=>$this->incidenceId));
		$inv_records = $invObj->viewInvestigationByIncidence();

		//dump_array($inv_records);

		if ( count($inv_records) ) {
			foreach ( $inv_records as $value ) {
				$invObj->setInvestigationInfo($value['ID'],"");
				$inv_records = $invObj->purgeInvestigation();
			}
		}
		/**********************************/


	}

	/*
	 * This method is used to view an incidence record
	 */
	public function viewIncidenceById() {

		if ( $this->incidenceInfo['history'] ) {

			$ref_array 		= explode(".",$this->incidenceInfo['ref']);
			$cmpref_array 	= explode(".",$this->incidenceInfo['cmpref']);
			$sub_reference 		= $ref_array[1];
			$cmp_sub_reference 	= $cmpref_array[1];

			if ( $this->incidenceInfo['tables_involved'] == 2 ) {
				$sql = sprintf("(SELECT * FROM %s.incidence WHERE ID = %d) UNION ALL (SELECT * FROM %s.incidence_historical WHERE ID = %d and subReference = %d)",_DB_OBJ_FULL,$this->incidenceId,_DB_OBJ_FULL,$this->incidenceId,$cmp_sub_reference);
			} else {
				$sql = sprintf("SELECT * FROM %s.incidence_historical WHERE ID = %d AND subReference IN(%d,%d) ORDER BY subReference DESC",_DB_OBJ_FULL,$this->incidenceId,$sub_reference,$cmp_sub_reference);
			}

		} else {
			$sql = sprintf("SELECT * FROM %s.incidence WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceId);
		}

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( $resultSet[0]['accidentReportable'] ) {
			$this->accidentReportable = true;
		}

		if ( $this->incidenceInfo['history'] ) {
			return $resultSet;
		} else {
			return $resultSet[0];
		}
	}

	/**
	 * This method is used to get last insert id
	 */
	public function lastRecordId() {
		return $this->incidenceId;
	}

	/*
	 * This method is used to view incidence records
	 * archive
	 */
	public function viewIncidences() {

		//$sql = sprintf("SELECT * FROM %s.incidence WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->incidenceInfo['archive'] );

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.incidence A
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'INCD'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->incidenceInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->incidenceInfo['archive']);
		//dump_array($pStatement->errorInfo());
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view witness records
	 */
	public function viewWitness() {

		$sql = sprintf("SELECT * FROM %s.incidence_witness WHERE incID = %d ORDER BY ID ASC",_DB_OBJ_FULL,$this->incidenceId);
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view action records
	 */
	public function viewActions() {

		$resultSet = $this->viewIncidenceById();

		$actions = $resultSet['actionsID'];

		if ( $actions != '' ) {
			$actions_id_arr = explode(',',$actions);
			if ( count($actions_id_arr) ) {
				$i=0;
				foreach( $actions_id_arr as $value ) {
					$this->actionHandling->setActionDetails($value,"");
					$action_data = $this->actionHandling->viewAction();
					if ( $action_data ) {
						$action_details[$i] = $this->actionHandling->viewAction();
						$action_details[$i]['action_id'] = $value;
						$i++;
					}
				}
				return $action_details;
			}
		}
	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('incidence');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('incidence');
		}

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT M.reference,M.buID,M.ID AS inc_id FROM %s.incidence M
											WHERE M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' ",_DB_OBJ_FULL,
											$search_value1,$search_value2,$search_value3,$search_value4);

				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$search_value1);
				$pStatement->bindParam(2,$search_value2);
				$pStatement->bindParam(3,$search_value3);
				$pStatement->bindParam(4,$search_value4);*/

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['buID'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['inc_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function addOutstandingAction() {

		$sql = sprintf("SELECT actionsID FROM %s.incidence WHERE ID = %d ",_DB_OBJ_FULL,$this->incidenceId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();

		$improvements = $pStatement->fetchColumn();
		$new_improvements = $improvements.','.$this->incidenceInfo['new_improvement'];

		$sql2 = sprintf("UPDATE %s.incidence SET actionsID = %d WHERE ID = %d ",_DB_OBJ_FULL,$new_improvements,$this->incidenceId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_improvements);
		$pStatement2->bindParam(2,$this->incidenceId);*/
		$pStatement2->execute();
	}

	protected function getNoOfAccidents() {

		$sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0' ",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
					$bu_id = $row['buID'];
					$date_time = $row['incidenceDateTime'];
					$year = substr($date_time,0,4);

					if ( $row['activityAccident'] ) {
						$result_set[$year][$bu_id]++;
					}
			}
		}

		return $result_set;
	}

	protected function getNoOfParticipants() {

		$sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0'",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
					$bu_id = $row['buID'];
					$date_time = $row['incidenceDateTime'];
					$year = substr($date_time,0,4);

					if ( $row['participantShiftWork'] ) {
						$result_set['shift_work'][$year][$bu_id]['yes']++;
					} else {
						$result_set['shift_work'][$year][$bu_id]['no']++;
					}
					//echo $row['participantGender']."<br/>";
					if ( $row['participantGender'] == 'M' || $row['participantGender'] == 'm' ) {
						$result_set['gender'][$year][$bu_id]['male']++;
					} else if ( $row['participantGender'] == 'F' || $row['participantGender'] == 'f' ) {
						$result_set['gender'][$year][$bu_id]['female']++;
					}
			}

			return $result_set;
		}
	}

	protected function getNoOfActions() {

		$sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0'",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {

					$bu_id = $row['buID'];
					$date_time = $row['incidenceDateTime'];
					$year = substr($date_time,0,4);

					if ( $row['actionsID'] != '' ) {

						$action_count = explode(',',$row['actionsID']);
						if ( count($action_count) ) {
							$result_set[$year][$bu_id] += count($action_count);
						}

					}
			}

			return $result_set;
		}
	}

	protected function getNoOfActivities() {

		$sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0'",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {

					$bu_id = $row['buID'];
					$date_time = $row['incidenceDateTime'];
					$year = substr($date_time,0,4);

					/* for body parts*/
					if ( $row['activityPartBody'] != '' ) {

						$parts = explode(',',$row['activityPartBody']);
						if ( count($parts) ) {
							foreach ( $parts as $value ) {
								$result_set['body_part'][$year][$bu_id][$value]++;
							}
						}
					} // end if

					/* for nature of injury*/
					if ( $row['activityNatureInjury'] != '' ) {

						$nature_injury = explode(',',$row['activityNatureInjury']);
						if ( count($nature_injury) ) {
							foreach ( $nature_injury as $value ) {
								$result_set['injury'][$year][$bu_id][$value]++;
							}
						}
					} // end if

					/* for treatment*/
					if ( $row['activityTreatment'] ) {

						$treatment = $row['activityTreatment'];
						$result_set['treatment'][$year][$bu_id][$treatment]++;

					} // end if

					/* for accident*/
					if ( $row['activityAccident'] ) {

						$treatment = $row['activityAccident'];
						$result_set['accident'][$year][$bu_id][$treatment]++;

					} // end if

					/* for accident*/
					if ( $row['activityImpact'] ) {

						$activity = $row['activityImpact'];
						$result_set['impact'][$year][$bu_id][$activity]++;

					} // end if

					/* for hazard classification*/
					if ( $row['activityHazardClass'] ) {

						$hazard_class = $row['activityHazardClass'];
						$result_set['hazard_class'][$year][$bu_id][$hazard_class]++;

					} // end if

					/* for hazards of injury*/
					if ( $row['activityHazards'] != '' ) {

						$hazards = explode(',',$row['activityHazards']);
						if ( count($hazards) ) {
							foreach ( $hazards as $value ) {
								$result_set['hazards'][$year][$bu_id][$value]++;
							}
						}
					} // end if
			}

			return $result_set;
		}
	}

	public function getIncidenceBySearch() {

		$search_filter	 = '';
		$date_filter	 = '';

		if ( $this->incidenceInfo['reference'] != '' ) {

			if ( $search_filter == '' ) {
				$search_filter = " WHERE reference = '".$this->incidenceInfo['reference']."'";
			} else {
				$search_filter .= " AND reference = '".$this->incidenceInfo['reference']."'";
			}
		}

		if ( $this->incidenceInfo['surname'] != '' ) {

			if ( $search_filter == '' ) {
				$search_filter = " WHERE participantSurname = '".$this->incidenceInfo['surname']."'";
			} else {
				$search_filter .= " AND participantSurname = '".$this->incidenceInfo['surname']."'";
			}
		}

		if ( $this->incidenceInfo['location'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE locID = '.$this->incidenceInfo['location'];
			} else {
				$search_filter .= ' AND locID = '.$this->incidenceInfo['location'];
			}
		}

		if ( $this->incidenceInfo['driver_test'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE driverTest = '.$this->incidenceInfo['driver_test'];
			} else {
				$search_filter .= ' AND driverTest = '.$this->incidenceInfo['driver_test'];
			}
		}

		if ( $this->incidenceInfo['treatment'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE activityTreatment = '.$this->incidenceInfo['treatment'];
			} else {
				$search_filter .= ' AND activityTreatment = '.$this->incidenceInfo['treatment'];
			}
		}

		if ( $this->incidenceInfo['impact'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE activityImpact = '.$this->incidenceInfo['impact'];
			} else {
				$search_filter .= ' AND activityImpact = '.$this->incidenceInfo['impact'];
			}
		}

		if ( $this->incidenceInfo['accident'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE activityAccident = '.$this->incidenceInfo['accident'];
			} else {
				$search_filter .= ' AND activityAccident = '.$this->incidenceInfo['accident'];
			}
		}

		if ( $this->incidenceInfo['body_part'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = " WHERE ( activityPartBody LIKE '".$this->incidenceInfo['body_part']."' OR activityPartBody LIKE '%,".$this->incidenceInfo['body_part'].",%' OR activityPartBody LIKE '%,".$this->incidenceInfo['body_part']."' OR activityPartBody LIKE '".$this->incidenceInfo['body_part'].",%')";
			} else {
				$search_filter .= " AND ( activityPartBody LIKE '".$this->incidenceInfo['body_part']."' OR activityPartBody LIKE '%,".$this->incidenceInfo['body_part'].",%' OR activityPartBody LIKE '%,".$this->incidenceInfo['body_part']."' OR activityPartBody LIKE '".$this->incidenceInfo['body_part'].",%')";
			}
		}

		if ( $this->incidenceInfo['nature_of_injury'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = " WHERE ( activityNatureInjury LIKE '".$this->incidenceInfo['nature_of_injury']."' OR activityNatureInjury LIKE '%,".$this->incidenceInfo['nature_of_injury'].",%' OR activityNatureInjury LIKE '%,".$this->incidenceInfo['nature_of_injury']."' OR activityNatureInjury LIKE '".$this->incidenceInfo['nature_of_injury'].",%')";
			} else {
				$search_filter .= " AND ( activityNatureInjury LIKE '".$this->incidenceInfo['nature_of_injury']."' OR activityNatureInjury LIKE '%,".$this->incidenceInfo['nature_of_injury'].",%' OR activityNatureInjury LIKE '%,".$this->incidenceInfo['nature_of_injury']."' OR activityNatureInjury LIKE '".$this->incidenceInfo['nature_of_injury'].",%')";
			}
		}

		if ( $this->incidenceInfo['primary_hazard'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE activityHazardClass = '.$this->incidenceInfo['primary_hazard'];
			} else {
				$search_filter .= ' AND activityHazardClass = '.$this->incidenceInfo['primary_hazard'];
			}
		}

		if ( $this->incidenceInfo['secondary_hazard'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = " WHERE ( activityHazards LIKE '".$this->incidenceInfo['secondary_hazard']."' OR activityHazards LIKE '%,".$this->incidenceInfo['secondary_hazard'].",%' OR activityHazards LIKE '%,".$this->incidenceInfo['secondary_hazard']."' OR activityHazards LIKE '".$this->incidenceInfo['secondary_hazard'].",%')";
			} else {
				$search_filter .= " AND ( activityHazards LIKE '".$this->incidenceInfo['secondary_hazard']."' OR activityHazards LIKE '%,".$this->incidenceInfo['secondary_hazard'].",%' OR activityHazards LIKE '%,".$this->incidenceInfo['secondary_hazard']."' OR activityHazards LIKE '".$this->incidenceInfo['secondary_hazard'].",%')";
			}
		}

		if ( $this->incidenceInfo['factor'] != 0 ) {

			if ( $search_filter == '' ) {
				$search_filter = ' WHERE activityFactor = '.$this->incidenceInfo['factor'];
			} else {
				$search_filter .= ' AND activityFactor = '.$this->incidenceInfo['factor'];
			}
		}

		//$date_filter = " incidenceDateTime BETWEEN '".$this->incidenceInfo['start_date']." 00:00:00' AND '".$this->incidenceInfo['end_date']." 23:59:59'";
		if ( $this->incidenceInfo['start_date'] != '--' && $this->incidenceInfo['end_date'] != '--' && $this->incidenceInfo['start_date'] != '' && $this->incidenceInfo['end_date'] != '' ) {
			$date_filter = " AND (dateTimestamp BETWEEN '".$this->incidenceInfo['start_date']." 00:00:00.000' AND '".$this->incidenceInfo['end_date']." 23:59:59.000')";
			$join_type = 'INNER';
			$date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
		} else {
			$date_filter = '';
			$join_type = 'LEFT OUTER';
			$date_timestamp_not_null = '';
		}

		if ( $this->incidenceInfo['search_type'] == 's' ) {

			$sql = sprintf("SELECT A.*,userID, dateTimestamp FROM %s.incidence A
							".$join_type." JOIN (
								SELECT recID,
									dateTimestamp,
									whoID as userID,
									reference as recordRef,
									role
								FROM %s.module_tracker
								WHERE module = 'INCD'
								AND action = 'add'
								".$date_timestamp_not_null."
							) B
							ON recordRef = reference ",_DB_OBJ_FULL,_DB_OBJ_FULL);

			$sql = $sql.$search_filter.$date_filter;

		} else if ( $this->incidenceInfo['search_type'] == 'd' ) {

			$sql = sprintf("SELECT * FROM %s.incidence WHERE".$date_filter,_DB_OBJ_FULL);

		} else if ( $this->incidenceInfo['search_type'] == 'b' ) {

			if ( $search_filter != '' ) {
				$sql = sprintf("SELECT * FROM %s.incidence",_DB_OBJ_FULL);
				$sql = $sql.$search_filter." AND".$date_filter;
			} else {
				$sql = sprintf("SELECT * FROM %s.incidence WHERE".$date_filter,_DB_OBJ_FULL);
			}
		}

		$sql .= " AND A.archive = '0'";

		/*$sql = sprintf("SELECT A.*,dateTimestamp FROM %s.incidence A
			LEFT OUTER JOIN (
				SELECT *
				FROM %s.recordTracking
				WHERE moduleName = 'INCD'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->incidenceInfo['archive']);*/

		//echo $sql;

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function updateStatus() {
		$sql = sprintf("UPDATE %s.incidence SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->incidenceId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();

	}

	public function sendActionAlerts($p_record_id) {

		$this->incidenceId = $p_record_id;

		$incidence_details = $this->viewIncidenceById();
		$record_data = $this->viewActions();

		if ( count($record_data) ) {
			$i = 0;

			$orgObj		= SetupGeneric::useModule('Organigram');
			$orgObj->setItemInfo(array('id'=>$incidence_details['buID']));
			$org_data 	= $orgObj->displayItemById();
			$orgObj 	= null;

			foreach ( $record_data as $value ) {

				$email_data[$i]['reference']	 		= $incidence_details['reference'];
				$email_data[$i]['summary']		 		= $value['actionDescription'];
				$email_data[$i]['due_date']		 		= format_date($value['dueDate']);
				$email_data[$i]['who']			 		= $value['who'];

				$email_data[$i]['process_bu'] 	 		= $org_data['buName'];
				$email_data[$i]['problem_description']	= $incidence_details['problemDescription'];

				$this->actionHandling->updateStatus($value['ID']);
				$i++;
			}
		}

		return $email_data;
	}

	/*public function sendActionEmail($p_record_id) {

		$this->actionHandling->setActionDetails($p_record_id,'');
		$record_data = $this->actionHandling->viewAction();

		$email_data[0]['reference']	 = $incidence_details['reference'];
		$email_data[0]['summary']		 = $value['actionDescription'];
		$email_data[0]['due_date']		 = format_date($value['dueDate']);
		$email_data[0]['who']			 = $value['who'];

		return $email_data;
	}*/

	public function sendReportableActions($p_record_id) {
		$this->incidenceId = $p_record_id;

		$incidence_details = $this->viewIncidenceById();

		$record_data = $this->viewActions();

		if ( count($record_data) ) {
			$i = 0;

			$orgObj		= SetupGeneric::useModule('Organigram');
			$orgObj->setItemInfo(array('id'=>$incidence_details['buID']));
			$org_data 	= $orgObj->displayItemById();
			$orgObj 	= null;

			foreach ( $record_data as $value ) {
				$email_data[$i]['reference']	 = $incidence_details['reference'];
				$email_data[$i]['summary']		 = $value['actionDescription'];
				$email_data[$i]['due_date']		 = format_date($value['dueDate']);
				$email_data[$i]['who_allocated'] = $value['who'];
				$email_data[$i]['who']			 = _INCIDENCE_REPORTABLE_ACTION_USER_ID;
				$email_data[$i]['type']			 = "action_reportable";
				$email_data[$i]['process_bu'] = $org_data['buName'];
				$i++;
			}
		}

		return $email_data;

	}

	/**
	 * This method is used to add an incidence files
	 * id, uploadfilesid
	 */
	public function addIncidenceFile() {
		$files_arr = $this->getIncidenceFile();
		$files = implode(',',$files_arr);

		$new_files = $files.','.$this->incidenceInfo['file_id'];

		$sql = sprintf("UPDATE %s.incidence SET uploadFilesID = '%s' WHERE ID = %d",_DB_OBJ_FULL,$new_files,$this->incidenceId);
		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$new_files);
		$pStatement->bindParam(2,$this->incidenceId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to get an incidence files
	 * id, identifier
	 */
	public function getIncidenceFile() {
		$sql = sprintf("SELECT uploadFilesID FROM %s.incidence WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->incidenceId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchColumn();

		$files_list = explode(',',$resultSet);
		//dump_array($files_list);
		return $files_list;
	}

	/**
	 * This method is used to delete an incidence files
	 * id
	 */
	public function deleteIncidenceFile() {
		$files_arr = $this->getIncidenceFile();

		$new_files = array();

		if ( count($files_arr) ) {

			foreach ( $files_arr as $value ) {

				if ( $value != $this->incidenceInfo['file_id'] ) {
					$new_files[] = $value;
				}

			}
		}

		$files = implode(',',$new_files);

		$sql = sprintf("UPDATE %s.incidence SET uploadFilesID = '%s' WHERE ID = %d",_DB_OBJ_FULL,$files,$this->incidenceId);
		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$files);
		$pStatement->bindParam(2,$this->incidenceId);*/

		$pStatement->execute();
	}

	protected function getNoOfActivitiesNew() {

		$sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0'",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {

					$bu_id = $row['buID'];
					$date_time = $row['incidenceDateTime'];
					$year = substr($date_time,0,4);

					$isParticipant = $row['participantShiftWork'];
					$participantGender = $row['participantGender'];

					/* for body parts*/
					if ( $row['activityPartBody'] != '' ) {

						$parts = explode(',',$row['activityPartBody']);
						if ( count($parts) ) {
							foreach ( $parts as $value ) {
								$result_set['body_part'][$year][$bu_id][$value][$isParticipant]++;
								$result_set['body_part'][$year][$bu_id][$value][$participantGender]++;
							}
						}
					} // end if

					/* for nature of injury*/
					if ( $row['activityNatureInjury'] != '' ) {

						$nature_injury = explode(',',$row['activityNatureInjury']);
						if ( count($nature_injury) ) {
							foreach ( $nature_injury as $value ) {
								$result_set['injury'][$year][$bu_id][$value][$isParticipant]++;
								$result_set['injury'][$year][$bu_id][$value][$participantGender]++;
							}
						}
					} // end if

					/* for treatment*/
					if ( $row['activityTreatment'] ) {

						$treatment = $row['activityTreatment'];
						$result_set['treatment'][$year][$bu_id][$treatment][$isParticipant]++;
						$result_set['treatment'][$year][$bu_id][$treatment][$participantGender]++;

					} // end if

					/* for accident*/
					if ( $row['activityAccident'] ) {

						$treatment = $row['activityAccident'];
						$result_set['accident'][$year][$bu_id][$treatment][$isParticipant]++;
						$result_set['accident'][$year][$bu_id][$treatment][$participantGender]++;

					} // end if

					/* for accident*/
					if ( $row['activityImpact'] ) {

						$activity = $row['activityImpact'];
						$result_set['impact'][$year][$bu_id][$activity][$isParticipant]++;
						$result_set['impact'][$year][$bu_id][$activity][$participantGender]++;

					} // end if

					/* for hazard classification*/
					if ( $row['activityHazardClass'] ) {

						$hazard_class = $row['activityHazardClass'];
						$result_set['hazard_class'][$year][$bu_id][$hazard_class][$isParticipant]++;
						$result_set['hazard_class'][$year][$bu_id][$hazard_class][$participantGender]++;

					} // end if

					/* for hazards of injury*/
					if ( $row['activityHazards'] != '' ) {

						$hazards = explode(',',$row['activityHazards']);
						if ( count($hazards) ) {
							foreach ( $hazards as $value ) {
								$result_set['hazards'][$year][$bu_id][$value][$isParticipant]++;
								$result_set['hazards'][$year][$bu_id][$value][$participantGender]++;
							}
						}
					} // end if
			}

			return $result_set;
		}
	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$type = $_GET['type'];

		if ( $type ) {

			return $this->getSearchExportData();

		} else {

			return $this->getIncidenceExportData();
		}
	}

	public function getIncidenceExportData() {

		$heading = array(array('refrence'=>'Reference #','bu'=>'Business Unit','who'=>'Who','When'=>'Incidence Date','loc'=>'Location'));

		$orgObj			 = SetupGeneric::useModule('Organigram');
		$locObj			 = SetupGeneric::useModule('Locationgram');
		$participantObj	 = SetupGeneric::useModule('Participant');
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$this->setIncidenceInfo(1,array('archive'=>$archive_session));
		$records = $this->viewIncidences();

		if ( count($records) ) {
			$i=0;
			foreach ($records as $value ) {

				$orgObj->setItemInfo(array('id'=>$value['buID']));
				$bu_details = $orgObj->displayItemById();

				$locObj->setItemInfo(array('id'=>$value['locID']));

				$location = $locObj->getFUllLocation();

				$participant_id = $value['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$search_date = substr($value['incidenceDateTime'],0,10);

				$result[$i]['ref'] = $value['reference'];
				$result[$i]['bu'] = $bu_details['buName'];
				$result[$i]['who'] = $participant_name;
				$result[$i]['when'] = format_datetime($value['incidenceDateTime']);
				$result[$i]['loc'] = str_replace(',','-',$location);

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
	}

	public function getSearchExportData() {

		$orgObj				= SetupGeneric::useModule('Organigram');
		$locObj				= SetupGeneric::useModule('Locationgram');

		$search_type		= 's';
		$reference_no		= $_GET['ref_no'];
		$surname			= $_GET['surname'];
		$location			= $_GET['location'];
		$driver_test		= $_GET['driver_test'];
		$treatment			= $_GET['treatment'];
		$risk				= $_GET['risk'];
		$accident			= $_GET['accident'];
		$body_part			= $_GET['body_part'];
		$nature_of_injury	= $_GET['nature_of_injury'];
		$primary_hazard		= $_GET['primary_hazard'];
		$secondary_hazard	= $_GET['secondary_hazard'];
		$factor				= $_GET['factor'];

		$search_data = array(
							'search_type'=>$search_type,
							'reference'=>$reference_no,
							'surname'=>$surname,
							'location'=>$location,
							'driver_test'=>$driver_test,
							'treatment'=>$treatment,
							'impact'=>$risk,
							'accident'=>$accident,
							'body_part'=>$body_part,
							'nature_of_injury'=>$nature_of_injury,
							'primary_hazard'=>$primary_hazard,
							'secondary_hazard'=>$secondary_hazard,
							'factor'=>$factor,
							);

		$this->setIncidenceInfo('', $search_data);
		$search_result = $this->getIncidenceBySearch();

		$heading = array(array('Reference #', 'Business Unit', 'Incidence Date', 'Location'));

		if ( count($search_result) ) {

			foreach ( $search_result as $element ) {

				$orgObj->setItemInfo(array('id'=>$element['buID']));
				$bu_details = $orgObj->displayItemById();
				$business_unit = $bu_details['buName'];

				$locObj->setItemInfo(array('id'=>$element['locID']));
				$location_data = "";
				$location = $locObj->getFUllLocation();
				$location = str_replace(',','-',$location);

				$date = format_datetime($element['incidenceDateTime']);

				$result[] = array($element['reference'], $business_unit, $date, $location);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;

	}

	public function getInstructorGraphData($b_unit=0,$year='') {

		$instructor_data = "";

		if ( $b_unit == 0 ) {
			$b_unit = '';
		}

		if ( $b_unit == '' ) {
			$sql = sprintf("SELECT COUNT(*) AS tot_acc,instructor,incidenceDateTime FROM %s.incidence WHERE driverTest='1' GROUP BY instructor,incidenceDateTime",
					   _DB_OBJ_FULL);
		} else {
			$sql = sprintf("SELECT COUNT(*) AS tot_acc,instructor,incidenceDateTime FROM %s.incidence WHERE driverTest='1' AND buID IN (%s)  GROUP BY instructor,incidenceDateTime",
					   _DB_OBJ_FULL,$b_unit);

			//echo "<br/>";
		}

		//echo $sql;


		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($result);

		if ( count($result) ) {
			$i=0;
			foreach ( $result as $value ) {
				$ins_id = $value['instructor'];
				$date = $value['incidenceDateTime'];

				$year_db = substr($date,0,4);
				if ( $year_db == $year ) {
					$instructor_data[$ins_id]['tot_acc']	+= $value['tot_acc'];
					$instructor_data[$ins_id]['instructor']	 = $value['instructor'];
				}
			}
		}

		return $instructor_data;
	}

	public function getInstructorGraphDataPublic() {

		$sql = sprintf("SELECT * FROM %s.incidence",
				   _DB_OBJ_FULL);

		//echo $sql;


		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($result);

		if ( count($result) ) {
			$i=0;
			foreach ( $result as $value ) {
				$date = $value['incidenceDateTime'];  //isParticipant // buID
				$bu = $value['buID'];
				$emp = $value['isParticipant'];

				$year_db = substr($date,0,4);

				if ( $emp == 1 ) {
					$instructor_data[$year_db][$bu]['employee']++;
					$instructor_data[$year_db][$bu]['public'] += 0;
				} else if ( $emp == 0 ) {
					$instructor_data[$year_db][$bu]['public']++;
					$instructor_data[$year_db][$bu]['employee'] += 0;
				}

				$name = $value['participantForename'].' '.$value['participantSurname'];
				if ( $name != ' ' ) {
					$instructor_data[$year_db][$bu]['instructors'][$name]++;
				}


			}
		}

		return $instructor_data;
	}

	/* function is used to send mail to manager of approved record */

	public function getActionTrackerEmailData($p_record_id) {

		$sql2 = sprintf("SELECT * FROM %s.incidence ",_DB_OBJ_FULL);
		$sql2 = $sql2." WHERE actionsID LIKE '".$p_record_id."' OR actionsID LIKE '%,".$p_record_id."' OR actionsID LIKE '".$p_record_id.",%' OR actionsID LIKE '%,".$p_record_id.",%' ";

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();
		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($result);exit;

		if ( count($result) ) {
			$email_data['bu_id']		 		= $result[0]['buID'];
			$email_data['reference']		 	= $result[0]['reference'];
			$email_data['DueDate']				= $result[0]['incidenceDateTime'];
			$email_data['who_id']				= $result[0]['whoID'];

		}
		return $email_data;
	}

	public function manageParticipant() {

		if ( (int) $this->incidenceInfo['participant_id'] ) {
			// do update
			$this->updateParticipant();
		} else {
			// do insert
			$this->addParticipant();
		}
	}

	public function markAccidentAsReportable() {


		$sql2 = sprintf(" UPDATE %s.incidence SET
						accidentReportable = %d
						WHERE ID = %d",
						_DB_OBJ_FULL,1,$this->incidenceId);

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();

	}

	public function isAccidentReportable() {
		return $this->accidentReportable;
	}

	public function getParticipants() {

		if ( $this->incidenceInfo['history'] ) {

			$ref_array = explode(".",$this->incidenceInfo['ref']);
			$sub_reference = $ref_array[1];

			$sql2 = sprintf("SELECT * FROM %s.incidence_participants_historical WHERE incID = %d AND subReference = %d",_DB_OBJ_FULL,$this->incidenceId,$sub_reference);
		} else {
			$sql2 = sprintf("SELECT * FROM %s.incidence_participants WHERE incID = %d ",_DB_OBJ_FULL,$this->incidenceId);
		}

		$pStatement2 = $this->dbHand->prepare($sql2);

		$pStatement2->execute();

		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}

	private function addParticipant() {

		$sql2 = sprintf("INSERT INTO %s.incidence_participants (incID,isParticipant,surname,forename,worksNumber,daysAbsent,shiftWork,gender)
									 VALUES (%d,'%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,$this->incidenceId,$this->incidenceInfo['is_participant'],
										$this->incidenceInfo['surname'],$this->incidenceInfo['forename'],
										$this->incidenceInfo['works_number'],$this->incidenceInfo['days_absent']
										,$this->incidenceInfo['shift_work'],
										$this->incidenceInfo['gender']);


		$pStatement2 = $this->dbHand->prepare($sql2);

		$pStatement2->execute();
		/*dump_array($pStatement2->errorInfo());
		exit;*/
	}

	private function updateParticipant() {

		$sql2 = sprintf("UPDATE %s.incidence_participants SET isParticipant = '%s',
										surname = '%s',
										forename = '%s',
										worksNumber = '%s',
										daysAbsent = '%s',
										shiftWork = '%s',
										gender = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['is_participant'],
										$this->incidenceInfo['surname'],$this->incidenceInfo['forename'],
										$this->incidenceInfo['works_number'],$this->incidenceInfo['days_absent']
										,$this->incidenceInfo['shift_work'],
										$this->incidenceInfo['gender'],$this->incidenceInfo['participant_id']);


		$pStatement2 = $this->dbHand->prepare($sql2);

		$pStatement2->execute();
		//dump_array($pStatement2->errorInfo());
	}

	public function deleteParticipant() {
		$sql2 = sprintf("DELETE FROM %s.incidence_participants WHERE ID = %d",_DB_OBJ_FULL,$this->incidenceInfo['participant_id']);


		$pStatement2 = $this->dbHand->prepare($sql2);

		$pStatement2->execute();
	}

	public function duplicateRecord() {
		$rec_data		=	$this->viewIncidenceById();
		$witness		=	$this->viewWitness();
		$participants	=	$this->getParticipants();
		$miscObj		= 	$this->incidenceInfo['miscObj'];
		$view_action	=	$this->viewActions();
		/*dump_array($view_action);
		//dump_array($participants);
		exit;*/

		$sql = sprintf("INSERT INTO %s.incidence ",_DB_OBJ_FULL);

		if ( count($rec_data) ) {
			foreach( $rec_data as $field=>$val ) {
				if ( $field != 'ID' ) {

					$fields .= $field.",";
					if ( $field == 'reference' ) {

						if ( $this->incidenceInfo['sub_ref'] ) {
							$values .= "'".$val.".".$this->incidenceInfo['sub_ref']."',";
						} else {
							$values .= "'".$val."',";
						}

					} else if ( $field == 'archive' ) {
						$values .= "'1',";
					}else {
						$values .= "'".$val."',";
					}
				}
			}
		}

		$sql .= "(".trim($fields,',').") VALUES (".trim($values,',').") ";
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$this->incidenceId = customLastInsertId( $this->dbHand,'incidence','ID');

		/**************************************  copy action start ************************************* */

		if ( count($view_action) ) {
			foreach ( $view_action as $value ) {
				$this->actionData = array('module_name'=>'incidence','description'=>$value['actionDescription'],
								  'who'=>$value['who'],'due_date'=>$value['when']);
				$sql_action = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,dueDate,doneDate,doneDescription,approve,outstanding,status)
								VALUES ('incidence','".$value['actionDescription']."','".$value['who']."','".$value['dueDate']."'
								,'".$value['doneDate']."','".$value['doneDescription']."','".$value['approve']."','".$value['outstanding']."'
								,'0')",_DB_OBJ_FULL);
				$pStatement_action = $this->dbHand->prepare($sql_action);

				$pStatement_action->execute();
				//dump_array($pStatement_action->errorInfo());

				$action_ids .= customLastInsertId( $this->dbHand,'actions','ID').',';
			}
		}

		//exit;


			$action_ids = rtrim($action_ids,',');

			$sql_upd = sprintf("UPDATE %s.incidence SET actionsID = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$action_ids,$this->incidenceId);

			$pStatement_upd = $this->dbHand->prepare($sql_upd);

			$pStatement_upd->execute();

		/************************************** copy action end *******************************************/

		//echo $sql;

		/**************************************  copy witness start ************************************* */

		if ( count($witness) ) {
			foreach( $witness as $row ) {

				$sql_wt = sprintf("INSERT INTO %s.incidence_witness ",_DB_OBJ_FULL);
				$fields_wt = $values_wt = "";
				foreach( $row as $field=>$val ) {
					if ( $field != 'ID' ) {

						$fields_wt .= $field.",";
						if ( $field == 'incID' ) {
							$values_wt .= "'".$this->incidenceId."',";
						} else {
							$values_wt .= "'".$val."',";
						}
					}
				}

				$sql_wt .= "(".trim($fields_wt,',').") VALUES (".trim($values_wt,',').") ";
				$pStatement2 = $this->dbHand->prepare($sql_wt);
				$pStatement2->execute();
				/*echo "<br/>";
				echo $sql_wt;*/

			}
		}

		/**************************************  copy witness end ************************************* */
		/**************************************  copy participants start ************************************* */

		if ( count($participants) ) {
			foreach( $participants as $row ) {

				$sql_pt = sprintf("INSERT INTO %s.incidence_participants ",_DB_OBJ_FULL);
				$fields_pt = $values_pt = "";
				foreach( $row as $field=>$val ) {
					if ( $field != 'ID' ) {

						$fields_pt .= $field.",";
						if ( $field == 'incID' ) {
							$values_pt .= "'".$this->incidenceId."',";
						} else {
							$values_pt .= "'".$val."',";
						}
					}
				}

				$sql_pt .= "(".trim($fields_pt,',').") VALUES (".trim($values_pt,',').") ";
				$pStatement3 = $this->dbHand->prepare($sql_pt);
				$pStatement3->execute();
				/*echo "<br/>";
				echo $sql_pt;*/
			}
		}
		/**************************************  copy participants end ************************************* */

		$miscObj->duplicateRecord(array('module'=>'INCD','rec_id'=>$this->incidenceId));

		//dump_array($rec_data);
		//exit;
	}
}
?>