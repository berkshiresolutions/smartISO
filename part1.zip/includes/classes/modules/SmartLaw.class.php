<?php

/**
  $Id: SmartLaw.class.php,v 3.14 Thursday, February 03, 2011 3:49:46 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Monday, December 20, 2010 6:32:46 PM>
 */
require_once "SmartLaw.int.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class SmartLaw implements SmartLawInterface {

    private $smartLawId;
    private $smartLawInfo;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    public function __construct() {
        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * to set smart law information for performing various operations with the smart law object
     */

    public function setSmartLawInfo($p_smartLawId, $p_smartLawInfo) {

        $this->smartLawId = $p_smartLawId;
        $this->smartLawInfo = $p_smartLawInfo;
    }

    /*
     * This method is used to view the smart law information.
     */

    public function viewSmartLaw() {

        $sql = sprintf("SELECT * FROM %s.smartlaw_sections
					WHERE slsID = %d ", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$this->smartLawId); */

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $result['ammended'] = $this->displayItemAmendById($result['slsID']);
        $result['revoked'] = $this->displayItemRevokeById($result['slsID']);

        return $result;
    }

    /**
     * This method is used to view revoked smart law data by ID for smartlaw module.
     *
     * @access public
     */
    public function displayItemRevokeById($p_slsid = 0) {


        $sql = sprintf("SELECT * FROM %s.smartlaw_amend_revoke WHERE sarType = 'R' AND sarSlsID = %d ORDER BY sarID ASC", _DB_OBJ_FULL, $p_slsid);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_slsid); */
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    /**
     * This method is used to view ammended smart law data by ID for smartlaw module.
     *
     * @access private
     */
    private function displayItemAmendById($p_slsid = 0) {


        $sql = sprintf("SELECT * FROM %s.smartlaw_amend_revoke WHERE sarType = 'A' AND sarSlsID = %d ORDER BY sarID ASC", _DB_OBJ_FULL, $p_slsid);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_slsid); */
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    /*
     * This method is used to save the smart law information
     */

    public function editSmartLaw() {

        $sql = sprintf("INSERT INTO %s.smartlaw_actions(slaSlsID,slaType,slaDesc,slsreviewID,isNa,slaDocumentID,slsNaDesc) VALUES (%d,'%s','%s',%d,'%s',%d,'%s') "
                , _DB_OBJ_FULL
                , $this->smartLawId
                , $this->smartLawInfo['type']
                , smartisoAddslashes($this->smartLawInfo['description'])
                , $this->smartLawInfo['reviewID']
                , $this->smartLawInfo['is_na']
                , $this->smartLawInfo['doc_ID']
                , smartisoAddslashes($this->smartLawInfo['na_description']));

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $reviewID = customLastInsertId($this->dbHand, 'smartlaw_review', 'ID');
        $status = 2;

   $sql = sprintf("insert into %s.smartlaw_review_files (fileID,lawreviewactionID,type) select fileid,%d,type from %s.smartlaw_review_files where lawreviewactionID=%d and type='%s' and not fileID in(%s)"
            , _DB_OBJ_FULL
            ,$reviewID
            , _DB_OBJ_FULL
            ,$this->smartLawInfo['oldReviewID']
            ,$this->smartLawInfo['type']
            ,$this->smartLawInfo['dlist']
             );
   
            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

        //      if ($this->smartLawInfo['type'] == "R") {
  

            $status = 3;
          $objModTracker = new ModuleTracker();
   $objModTracker->saveRecordLog1("smartlaw_review","LAW Review", $reviewID,'---','edit');     

        return  $reviewID;
    }

    public function editSmartLawGHL() {
        $ogrObj = SetupGeneric::useModule('Organigram');
        $region=new Region();
        $periodArr = array(1 => 'Monthly', 2 => 'Bi- Monthly', 3 => 'Quarterly', 4 => 'Annually', 5 => 'Bi - Annually', 6 => 'Semi - Annually', 7 => 'Tri - Annually');
   
        $sql = sprintf("INSERT INTO %s.smartlaw_actions(slaSlsID,slaType,slaDesc,slsreviewID,isNa,slaDocumentID,slsNaDesc) VALUES (%d,'%s','%s',%d,'%s',%d,'%s') "
                , _DB_OBJ_FULL
                , $this->smartLawId
                , $this->smartLawInfo['type']
                , smartisoAddslashes($this->smartLawInfo['description'])
                , $this->smartLawInfo['reviewID']
                , $this->smartLawInfo['is_na']
                , $this->smartLawInfo['doc_ID']
                , smartisoAddslashes($this->smartLawInfo['na_description']));

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $reviewID = customLastInsertId($this->dbHand, 'smartlaw_review', 'ID');
        $status = 2;

        if ($this->smartLawInfo['type'] == "R") {
            $status = 3;

            foreach($this->smartLawInfo['who'] as $x=>$value){ 
     //       for ($x = 0; $x < count($this->smartLawInfo['who']); $x++) {
                
                $this->actionData = array('description' => $this->smartLawInfo['action'][$x],
                    'who' => $this->smartLawInfo['who'][$x],
                    'whoAU' => $this->smartLawInfo['whoAU'][$x],
                    'who2AU' => $this->smartLawInfo['whoAU2'][$x],
                    'module_name' => "smartlaw" . $this->smartLawInfo['typeaction'][$x],
                    'record' => $reviewID,
                    'status' => $this->smartLawInfo['save_finish'],
                    'buname' => 0,
                    'element' => "smartlaw_review",
                    'currentwho' => $this->smartLawInfo['who'][$x],
                    'due_date' => $this->smartLawInfo['when'][$x]);

                if ($this->smartLawInfo['actionID'] > 0) {
                    $this->actionHandling->setActionDetails($this->smartLawInfo['actionID'], $this->actionData);
                    $this->actionHandling->updateAction();
                    $this->actionHandling->updateActionDetail('moduleName', $this->smartLawInfo['module']); //updates module name as may have been changed bythe user
                    $new_action_id = $this->smartLawInfo['actionID'];
                } else {
                    $this->actionHandling->setActionDetails(0, $this->actionData);
                    $new_action_id = $this->actionHandling->addAction2015();
                }

                $action_id = $new_action_id;
                $this->actionHandling->updateStatus($action_id);

              $sql = sprintf("INSERT INTO %s.smartlaw_action_link(smartlawreviewID,actionID,company,region,alerttype,law_period) VALUES (%d,%d,%d,%d,'%s',%d) "
                        , _DB_OBJ_FULL
                        , $this->smartLawInfo['reviewID']
                        , $action_id
                        , $this->smartLawInfo['company'][$x]
                        , $this->smartLawInfo['country'][$x]
                        , $this->smartLawInfo['atype'][$x]
                        , $this->smartLawInfo['period'][$x]);

                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();

                $this->smartLawInfo["save_finish"] = 1;

                if ($this->smartLawInfo["save_finish"] == 1) {

                    $emailObj = new actionEmailHelper($action_id);
                    $who = $emailObj->getwhoDetails();
                    
                $resultC =   $region->getItemsbyId($this->smartLawInfo['country'][$x]);
                $country= $resultC ? $resultC['Country'] : '-';
                $ogrObj->setItemInfo(array('id'=>$this->smartLawInfo['company'][$x]));   
                $resultCo =   $ogrObj->displayItemsByid();
                $company= $resultCo ? $resultCo['buName'] : '-';
                if ((int)$this->smartLawInfo['period'][$x]>0)
                $period=$periodArr[$this->smartLawInfo['period'][$x]];
                                else
                      $period='-';
                                
                 if ($this->smartLawInfo['atype'][$x] == 'Update Template')   
                     $url='<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/setup/compliance/compliance.php">CLICK</a> Here to Amend the templates';
                  else
                      $url='';
                    $slawdata = $this->getActionsbyID($action_id);

                    $sentence = array('sentence' => array("You have an action to carry out the following smart-Law Action"));
                    $emailObj->appendInfo($sentence);


                    $data = array('singleColData' => array('click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Action'.$url),
                        'twoColData' => array(
                            'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slawdata['reference'] . " " . $slawdata['slyear']),
                            'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation']),
                            'country' => array('left' => '<strong>Country</strong>', 'right' => $country),
                            'company' => array('left' => '<strong>Company</strong>', 'right' => $company),
                            'atype' => array('left' => '<strong>Type</strong>', 'right' => $this->smartLawInfo['atype'][$x]),
                            'period' => array('left' => '<strong>Period</strong>', 'right' => $period)
                    ));

                    $emailObj->appendInfo($data);
                    $emailObj->sendEmail('A smart law Action To Be Completed', $who, array(), array(), 'me_completed', '', 'grey');
                    
                }
            }
        }

        $sql = sprintf("update %s.smartlaw_sections set status=%d,reviewduedate=null where slsID=%d", _DB_OBJ_FULL, $status, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function updateDocument() {

        $sql = sprintf("SELECT slaDocumentID FROM %s.smartlaw_actions WHERE slaSlsID = %d AND slaType = '%s' "
                , _DB_OBJ_FULL
                , $this->smartLawId
                , $this->smartLawInfo['type']);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->smartLawId);
          $stmt->bindParam(2,$this->smartLawInfo['type']); */

        $stmt->execute();
        $resultSet = $stmt->fetchColumn();

        if ($resultSet != '') {

            $objFile = new Upload();

            $objFile->setFileInfo('smart_law', array('id' => $resultSet));
            $single_files_data = $objFile->getFileDetails();

            $objFile->setFileInfo('smart_law', array('id' => $single_files_data['fileID'], 'destination' => 'smart_law'));
            $objFile->delete_file();
        }
        //dump_array($stmt->errorInfo());

        $sql = sprintf("UPDATE %s.smartlaw_actions SET slaDocumentID = %d WHERE slaSlsID = %d AND slaType = '%s' "
                , _DB_OBJ_FULL
                , $this->smartLawInfo['file_id']
                , $this->smartLawId
                , $this->smartLawInfo['type']);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->smartLawInfo['file_id']);
          $stmt->bindParam(2,$this->smartLawId);
          $stmt->bindParam(3,$this->smartLawInfo['type']); */

        $stmt->execute();
    }

    public function displaySmartLawDetails() {

        $sql = sprintf("SELECT lastreviewid FROM %s.smartlaw_sections where slsID = %d ", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);


        $stmt->execute();
        $resultSet = $stmt->fetch(PDO::FETCH_ASSOC);

        $reviewID = $resultSet["lastreviewid"];

        $sql = sprintf("SELECT * FROM %s.smartlaw_review R left join %s.smartlaw_actions A on R.ID=A.slsreviewID WHERE R.ID = %d order by ID desc ", _DB_OBJ_FULL, _DB_OBJ_FULL, $reviewID);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$this->smartLawId); */

        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getFirstLastRecord($first = false) {

        if ($first) {
            $fxn = 'MIN';
        } else {
            $fxn = 'MAX';
        }

        $sql = sprintf("SELECT %s(slsID) AS next_id FROM %s.smartlaw_sections", $fxn, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getNexttPrevRecord($rec_id, $prev = false) {

        if ($prev) {
            $opr = '<';
            $filter = 'DESC';
        } else {
            $opr = '>';
            $filter = 'ASC';
        }
        if (_DB_TYPE == 'mysql') {
            $sql = sprintf("SELECT slsID FROM %s.smartlaw_sections WHERE slsID %s %d LIMIT 0,1", _DB_OBJ_FULL, $opr, $rec_id);
        } else {
            $sql = sprintf("SELECT TOP 1 slsID FROM %s.smartlaw_sections WHERE slsID %s %d ORDER BY slsID %s", _DB_OBJ_FULL, $opr, $rec_id, $filter);
        }

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function editBuList() {

        $sql = sprintf("delete from %s.smartlaw_bu WHERE slawID = %d ", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
if (is_array($this->smartLawInfo["bus"])){
        foreach ($this->smartLawInfo["bus"] as $key => $data) {
            $sql = sprintf("insert into %s.smartlaw_bu (slawID,buId) values(%d, %d )", _DB_OBJ_FULL, $this->smartLawId, $data);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
        }
}
    }

    public function getBuList() {

        $sql = sprintf("select buId from %s.smartlaw_bu WHERE slawID = %d and buId>0", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function checkReview() {

        $sql = sprintf("select * from %s.smartlaw_review WHERE smartlawID = %d ", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function insertReview($p_smartlawid) {

        $userid = getLoggedInUserId();

        $sql = sprintf("insert into %s.smartlaw_review (smartlawID,rev,lastamendedby) values( %d,%d,%d)", _DB_OBJ_FULL, $p_smartlawid, time(), $userid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);


        $newID = customLastInsertId($this->dbHand, 'smartlaw_review', 'ID');


        $sql = sprintf("update %s.smartlaw_sections set lastreviewid=%d where  slsID= %d", _DB_OBJ_FULL, $newID, $p_smartlawid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $newID;
    }

    public function getLastReview() {

        $sql = sprintf("select * from %s.smartlaw_review where  smartlawID= %d order by rev", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($resultSet)
            return $resultSet[0];
        else
            return null;
    }

    public function finishGap() {

        $whoid = getLoggedInUserId();
        $ogrObj = SetupGeneric::useModule('Organigram');
        $ogrObj->setItemInfo(array('id' => $whoid));
        $whoAUarray = $ogrObj->getManager($whoid);
        $whoAU = $whoAUarray["participantID"];

        $datestr = _DB_TYPE == 'mysql' ? 'now()' : 'getdate()';

        $sql = sprintf("insert into %s.smartlaw_review (smartlawID,compliance,whoid,reviewdate,actionID,gapreason,rev,status) values( %d,%d,%d,%s,%d,'%s',%d,1)", _DB_OBJ_FULL, $this->smartLawId, $this->smartLawInfo['compliance'], $whoid, $datestr, $action_id, $this->smartLawInfo['reason'], time());

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $sql = sprintf("update %s.smartlaw_sections set datelastreview=%s,status=1 where slsID=%d", _DB_OBJ_FULL, $datestr, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function finishReview() {
        $whoid = getLoggedInUserId();
        $datestr = _DB_TYPE == 'mysql' ? 'now()' : 'getdate()';
 $newID=$this->editSmartLaw();

       $sql = sprintf("update %s.smartlaw_review set compliance=100,status=1, whoid=%d,reviewdate=%s,gapreason='%s' where ID=%d", _DB_OBJ_FULL,$whoid,  $datestr,$this->smartLawInfo['reason'], $newID);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        
       $sql = sprintf("update %s.smartlaw_sections set datelastreview=%s,status=1 where slsID=%d", _DB_OBJ_FULL, $datestr, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        
 
    }



        public function aproveReview() {
        $whoid = getLoggedInUserId();
        $ogrObj = SetupGeneric::useModule('Organigram');
        $ogrObj->setItemInfo(array('id' => $whoid));
        $whoAUarray = $ogrObj->getManager($whoid);
        $whoAU = $whoAUarray["participantID"];
/* not used now
        if ($this->smartLawInfo['type'] == 'R' && $this->smartLawInfo['is_na'] == 1)
            $not_relevant = 1;
        else
            $not_relevant = 0;

*/


        $datestr = _DB_TYPE == 'mysql' ? 'now()' : 'getdate()';

        $sql = sprintf("update %s.smartlaw_review set whoid=%d,reviewdate='%s', where ID=%d", _DB_OBJ_FULL,  $whoid, $datestr, $this->smartLawInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);


        $sql = sprintf("update %s.smartlaw_sections set datelastreview=%s,status=1 where slsID=%d", _DB_OBJ_FULL, $datestr, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();


        return;
    }
    
    public function sendActionAlerts($p_record_id) {
        $this->smartlawReviewId = $p_record_id;

        $sql = sprintf("select *,R.ID as ref from %s.smartlaw_sections S inner join %s.smartlaw_review R on S.slsID=R.smartlawID inner join %s.smartlaw_action_link L on R.ID=L.smartlawreviewID inner join %s.actions A on L.actionID=A.ID  where R.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->smartlawReviewId);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($data)) {

            $i = 0;
            foreach ($data as $value) {
                $email_data[$i]['module'] = $value['moduleName'];
                $email_data[$i]['reference'] = $value['reference'] . " " . $value['slyear'];
                $email_data[$i]['description'] = $value['slsLegislation'];
                ;
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];
                $email_data[$i]['URL'] = _MYSERVER . '/action_tracker/smartlaw.php';
                $i++;
            }
        }
        return $email_data;
    }

    public function sendReviewActions($p_record_id) {
        $this->smartlawReviewId = $p_record_id;

        $sql = sprintf("select *,R.ID as ref from %s.smartlaw_sections S inner join %s.smartlaw_review R on S.slsID=R.smartlawID inner join %s.actions A on R.actionID=A.ID  where R.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->smartlawReviewId);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);



        if (count($data)) {

            $i = 0;
            foreach ($data as $value) {
                $email_data[$i]['module'] = $value['moduleName'];
                $email_data[$i]['reference'] = $value['refNo'];
                $email_data[$i]['description'] = $value['slsLegislation'];
                $email_data[$i]['slref'] = $value['reference'] . " " . $value['slyear'];
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];
                $email_data[$i]['URL'] = _MYSERVER . '/action_tracker/smartlaw.php';
                $i++;
            }
        }

        return $email_data;
    }

    public function getReviewActionsbyID($p_record_id) {
        $sql = sprintf("SELECT S.*  fROM  %s.smartlaw_sections S inner join %s.smartlaw_review R on S.slsID=R.smartlawID  where R.actionID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data;
    }

    public function getActionsbyID($p_record_id) {
        $sql = sprintf("SELECT S.*,R.lastamendedby  fROM  %s.smartlaw_sections S inner join %s.smartlaw_review R on S.slsID=R.smartlawID inner join %s.smartlaw_action_link A on R.ID=A.smartlawreviewID where A.actionID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data;
    }

    public function saveReviewRevision($p_record_id, $p_parent_id, $p_smart_law_id) {
        $revHelper = new RevisionHelper();
        $revHelper->setTableName('smartlaw_review')
                ->setCols('[smartlawID]
      ,[reviewduedate]
      ,[compliance]
      ,[whoID]
      ,[archive]
      ,[reviewdate]
	  ,[actionID]
	  ,[gapreason]
	  ,[status]
	  ,[not_relevant] ')
                ->setPrimaryFieldName('ID')
                ->setParentID($p_parent_id)
                ->setRecordID($p_record_id);
        $revHelper->reviseObject('', time());

       $newID = customLastInsertId($this->dbHand, "smartlaw_review", "ID");

     $sql = sprintf("update %s.smartlaw_sections set lastreviewid=%d where  slsID= %d", _DB_OBJ_FULL, $newID, $p_smart_law_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        return $newID;
    }

    public function updateStatus($p_action_record_id) {
        $sql = sprintf("update  %s.smartlaw_sections set status=2  where not status=1 and slsID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data;
    }

    public function resetActionData($p_record_id) {
        $sql = sprintf("delete from  %s.smartlaw_actions  where slsreviewID=%d", _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    public function getActions($p_record_id) {
        $sql = sprintf("select A.* from  %s.actions A inner join  %s.smartlaw_action_link L on A.ID=L.actionID where L.smartlawreviewID=%d and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }

    public function cancelAction($p_record_id) {

        $actionID = $p_record_id * -1;
        $this->actionHandling->setActionDetails($actionID, '');
        $this->actionHandling->updateActionDetail('doneDescription', "Cancelled");
        $duedate = date("Y-m-d");
        $this->actionHandling->updateActionDetail('doneDate', $duedate);
        $this->actionHandling->updateActionDetail('approveAU', 1);

        $emailObj = new actionEmailHelper($actionID);
        $who = $emailObj->getwhoDetails();

        $slawdata = $this->getActionsbyID($actionID);

        $sentence = array('sentence' => array("This smart-Law Action has been cancelled"));
        $emailObj->appendInfo($sentence);

        $data = array('singleColData' => array('click-here-url' => ''), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slawdata['reference'] . " " . $slawdata['slyear']), 'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation'])));

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('A smart law Action has been Cancelled', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function updateAction($done_date, $p_value, $actionId) {

        $sql = sprintf("select * from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $actionId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf("UPDATE %s.actions SET doneDate = '%s',doneDescription = '%s' WHERE ID = %d", _DB_OBJ_FULL, $done_date, $p_value, $actionId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $data;
    }

    public function displayId($p_slsid = 0) {

        $sql = "SELECT * FROM %s.smartlaw_sections
					WHERE slsID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $p_slsid);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function updatePF($law, $pf_id) {


        $sql = sprintf("UPDATE %s.smartlaw_sections SET pfID = %d WHERE slsID = %d", _DB_OBJ_FULL, $pf_id, $law);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

       // return $data;
    }

    public function editPFList() {

        $sql = sprintf("delete from %s.smartlaw_pf_links WHERE lawID = %d ", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        foreach ($this->smartLawInfo["pfs"] as $key => $data) {

            $sql = sprintf("insert into %s.smartlaw_pf_links (lawID,pfstep) values(%d, %d )", _DB_OBJ_FULL, $this->smartLawId, $data);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
        }
    }

    public function getPFList() {

        $sql = sprintf("select pfstep from %s.smartlaw_pf_links WHERE lawID = %d ", _DB_OBJ_FULL, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function rejectProcessFlow($aid) {
        $date = date("Y-m-d");

        $sql = sprintf("update %s.actions set approveAU = 1,donedate='%s',donedescription='Process Flow Request rejected' where id=%d", _DB_OBJ_FULL, $date, $aid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $emailObj = new actionEmailHelper($aid);


        $slawdata = $this->getActionsbyID($aid);

        $AuthorizedUserObj = SetupGeneric::useModule('AuthorizedUser');
        $participantObj = SetupGeneric::useModule('Participant');
        $data1 = $AuthorizedUserObj->getIssuerPermission('PERM_CCO');

        $participantObj->setItemInfo(array('id' => $data1));
        $details = $participantObj->displayItemById();
        $whocco = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);

        $participantObj->setItemInfo(array('id' => $slawdata["lastamendedby"]));
        $details = $participantObj->displayItemById();
        $who = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);

        $sentence = array('sentence' => array("This Process Flow request has been rejected"));
        $emailObj->appendInfo($sentence);

        $data = array('singleColData' => array('click-here-url' => 'This Process Flow request has been rejected'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slawdata['reference'] . " " . $slawdata['slyear']), 'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation'])));

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('A smart law Action has been Rejected', $who, array(), array(), 'me_completed', '', 'grey');
        $emailObj->sendEmail('A smart law Action has been Rejected', $whocco, array(), array(), 'me_completed', '', 'grey');
    }

    public function rejectProcedure($aid) {
        $date = date("Y-m-d");

        $sql = sprintf("update %s.actions set approveAU = 1,donedate='%s',donedescription='Procedure Request rejected' where id=%d", _DB_OBJ_FULL, $date, $aid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $emailObj = new actionEmailHelper($aid);


        $slawdata = $this->getActionsbyID($aid);

        $AuthorizedUserObj = SetupGeneric::useModule('AuthorizedUser');
        $participantObj = SetupGeneric::useModule('Participant');
        $data1 = $AuthorizedUserObj->getIssuerPermission('PERM_CCO');

        $participantObj->setItemInfo(array('id' => $data1));
        $details = $participantObj->displayItemById();
        $whocco = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);

        $participantObj->setItemInfo(array('id' => $slawdata["lastamendedby"]));
        $details = $participantObj->displayItemById();
        $who = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);

        $sentence = array('sentence' => array("This Procedure request has been rejected"));
        $emailObj->appendInfo($sentence);

        $data = array('singleColData' => array('click-here-url' => 'This Procedure request has been rejected'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slawdata['reference'] . " " . $slawdata['slyear']), 'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation'])));

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('A smart law Action has been Rejected', $who, array(), array(), 'me_completed', '', 'grey');
        $emailObj->sendEmail('A smart law Action has been Rejected', $whocco, array(), array(), 'me_completed', '', 'grey');
    }

    public function acceptProcessFlow($aid, $who) {

        $lawdata = $this->getActionsbyID($aid);
        $this->setSmartLawInfo($lawdata["slsID"], null);
        $objAlert = new SendActionAlerts('riskInvalid', $lawdata['lastreviewid']);
        $objAlert->sendAlertsNoProcess(0, "smartlaw_review", $lawdata['lastreviewid'], $lawdata['slsLegislation'], $who);
    }

    public function sendDocRequests() {
        if ($this->smartLawInfo['pfReq'] == 1) {
            $AuthorizedUserObj = SetupGeneric::useModule('AuthorizedUser');
            $participantObj = SetupGeneric::useModule('Participant');
            if ($who == 0)
                $data1 = $AuthorizedUserObj->getIssuerPermission('PERM_CCO');
            else {
                $data1 = $who;
            }
            $slData = $this->viewSmartLaw();
            $this->actionData = array('description' => "Authorisation for a Process Flow is required for " . $slData['slsLegislation'],
                'who' => $data1,
                'who2AU' => 0,
                'module_name' => "smartLawD",
                'record' => $this->smartLawInfo['reviewID'],
                'status' => 1,
                'buname' => 0,
                'element' => "smartlaw_review",
                'currentwho' => $data1,
                'due_date' => date('m/d/Y', strtotime(' + 14 days')));


            $this->actionHandling->setActionDetails(0, $this->actionData);
            $new_action_id = $this->actionHandling->addAction2015();


            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);

            $sql = sprintf("INSERT INTO %s.smartlaw_action_link(smartlawreviewID,actionID) VALUES (%d,%d) "
                    , _DB_OBJ_FULL
                    , $this->smartLawInfo['reviewID']
                    , $action_id);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();


            $emailObj = new actionEmailHelper($action_id);
            $who = $emailObj->getwhoDetails();

            $data = array('singleColData' =>
                array('click-here-url' => 'Please <a href="' . $slData['slsInstUrl'] . '">CLICK</a> Here to View Law<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_law/agreed1.php?aid=' . $action_id . '">CLICK</a> Here to agree a process flow is required<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_law/reject1.php?aid=' . $action_id . '">CLICK</a> Here to reject the process flow request'),
                'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slData['reference'] . " " . $slData['slyear']),
                    'description' => array('left' => '<strong>Title</strong>', 'right' => $slData['slsLegislation'])));

            $emailObj->appendInfo($data);
            $emailObj->sendEmail('A Process Flow Authorisation Required', $who, array(), array(), 'me_completed', '', 'grey');
        }

        if ($this->smartLawInfo['docReq'] == 1) {

            $AuthorizedUserObj = SetupGeneric::useModule('AuthorizedUser');
            $participantObj = SetupGeneric::useModule('Participant');
            $data1 = $AuthorizedUserObj->getIssuerPermission('PERM_CCO');
            $slData = $this->viewSmartLaw();
            $this->actionData = array('description' => "Authorisation for a Procedure is required for " . $slData['slsLegislation'],
                'who' => $data1,
                'who2AU' => 0,
                'module_name' => "smartLawD",
                'record' => $this->smartLawInfo['reviewID'],
                'status' => 1,
                'buname' => 0,
                'element' => "smartlaw_review",
                'currentwho' => $data1,
                'due_date' => date('m/d/Y', strtotime(' + 14 days')));


            $this->actionHandling->setActionDetails(0, $this->actionData);
            $new_action_id = $this->actionHandling->addAction2015();


            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);

            $sql = sprintf("INSERT INTO %s.smartlaw_action_link(smartlawreviewID,actionID) VALUES (%d,%d) "
                    , _DB_OBJ_FULL
                    , $this->smartLawInfo['reviewID']
                    , $action_id);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();


            $emailObj = new actionEmailHelper($action_id);
            $who = $emailObj->getwhoDetails();

            $data = array('singleColData' =>
                array('click-here-url' => 'Please <a href="' . $slData['slsInstUrl'] . '">CLICK</a> Here to View Law<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_law/agreed2.php?aid=' . $action_id . '">CLICK</a> Here to agree a procedure is required<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_law/reject2.php?aid=' . $action_id . '">CLICK</a> Here to reject the procedure request'),
                'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slData['reference'] . " " . $slData['slyear']),
                    'description' => array('left' => '<strong>Title</strong>', 'right' => $slData['slsLegislation'])));

            $emailObj->appendInfo($data);
            $emailObj->sendEmail('A Procedure Authorisation Required', $who, array(), array(), 'me_completed', '', 'grey');
        }
    }

    public function acceptProcedure($aid, $who = 0) {

        $lawdata = $this->getActionsbyID($aid);

        $AuthorizedUserObj = SetupGeneric::useModule('AuthorizedUser');
        $participantObj = SetupGeneric::useModule('Participant');

        $this->actionData = array('description' => "A Procedure is required for " . $lawdata['slsLegislation'],
            'who' => $who,
            'who2AU' => 0,
            'module_name' => "Procedure",
            'record' => $lawdata['slsID'],
            'status' => 1,
            'buname' => 0,
            'element' => "smartlaw_section",
            'currentwho' => $data1,
            'due_date' => date('m/d/Y', strtotime(' + 14 days')));


        $this->actionHandling->setActionDetails(0, $this->actionData);
        $new_action_id = $this->actionHandling->addAction2015();


        $action_id = $new_action_id;

        $emailObj = new actionEmailHelper($action_id);
        $who = $emailObj->getwhoDetails();

        $data = array('singleColData' =>
            array('click-here-url' => 'Please <a href="' . $lawdata['slsInstUrl'] . '">CLICK</a> Here to View Law<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/documents/upload_document.php">CLICK</a> Here to upload a new procedure'),
            'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $lawdata['reference'] . " " . $lawdata['slyear']),
                'description' => array('left' => '<strong>Title</strong>', 'right' => $lawdata['slsLegislation'])));

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('A Procedure to be Created and Uploaded', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function getLawCoNames($buId) {

        $sql = sprintf("SELECT buName FROM %s.business_units WHERE buID in (%s)", _DB_OBJ_FULL, $buId);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($records as $key => $value) {
            $recStr .= " " . $value["buName"] . ",";
        }

        return trim($recStr, ",");
    }

    public function getHistory($id) {

        $sql = sprintf("SELECT * FROM %s.smartlaw_sections WHERE ( slsID=%d  OR parent_id=%d) order by slsid desc", _DB_OBJ_FULL, $id, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $records;
    }

    public function getCompanies($id, $region = '') {
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $sql = sprintf("SELECT * FROM %s.smartlaw_sections WHERE slsID=%d  ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetch(PDO::FETCH_ASSOC);



        $busa = $orgObj->getCompanies();

        if ($region != '' && $region != 0) {
            $comp1 = explode(",", $record['companies']);
            $comp2 = $locObj->getBufromCountries($region);
            $comp = array_intersect($comp1, $comp2);
        } else
            $comp = explode(",", $record['companies']);


        foreach ($busa as $bu) {


            if (is_array($comp) && in_array($bu["buID"], $comp)) {
                $business_units .= "<option value='" . $bu["buID"] . "' >" . $bu["buName"] . "</option>";
            }
        }

        return $business_units;
    }

    public function getCountries($id) {
        $regObj = new Region();
        $sql = sprintf("SELECT * FROM %s.smartlaw_sections WHERE slsID=%d  ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetch(PDO::FETCH_ASSOC);

        $comp = explode(",", $record['regions']);
        $rega = $regObj->getItems();


        foreach ($comp as $bu) {



            $regions .= "<option value='" . $bu . "' >" . $rega[$bu] . "</option>";
        }

        return $regions;
    }

    public function comfirmGHL($aid) {
        $date = date("Y-m-d");

        $sql = sprintf("update %s.actions set approveAU = 1,donedate='%s',donedescription='Confirm Review carried out' where id=%d", _DB_OBJ_FULL, $date, $aid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    
        public function addLawFiles($rec_id, $file_id,$type) {

   $sql = sprintf("INSERT INTO %s.smartlaw_review_files (lawreviewactionID,fileID,type) VALUES (%d,%d,'%s')"
                , _DB_OBJ_FULL
                , $rec_id
                , $file_id
                , $type);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getLawFile($id,$type) {
 $sql = sprintf("select F.* from %s.uploaded_files F inner join %s.smartlaw_review_files R on F.fileID=R.fileID where lawreviewactionID=%d and type='%s'"

                , _DB_OBJ_FULL
                , _DB_OBJ_FULL
                , $id
                , $type
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $resultSet;
    }

    
        public function getLawFileStr($id,$type) {
   $sql = sprintf("select * from %s.smartlaw_review_files  where archive=0 and lawreviewactionID=%d and type='%s'"

               , _DB_OBJ_FULL
                , $id
                , $type
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $filestr='';
        if (is_array($resultSet)){
            foreach ($resultSet as $row){
              $filestr.=",".$row["fileID"];  
            }
        }
        return trim($filestr,",");
    }
    
   public function editActions() {

for($x=1;$x<=count($this->smartLawInfo['who']);$x++){
            $this->actionData = array('description' => $this->smartLawInfo['action'][$x],
                'who' => $this->smartLawInfo['who'][$x],
                'whoAU' => $this->smartLawInfo['whoAU'][$x],
                'who2AU' => $this->smartLawInfo['whoAU2'][$x],
                'module_name' => "smartlaw".$this->smartLawInfo['type'],
                'record' => $this->smartLawInfo['reviewID'],
                'status' => $this->smartLawInfo['save_finish'],
                'buname' => 0,
                'element' => "smartlaw_review",
                'currentwho' => $this->smartLawInfo['who'][$x],
                'due_date' => $this->smartLawInfo['when'][$x]);
   
            if ($this->smartLawInfo['actionID'] > 0) {
                $this->actionHandling->setActionDetails($this->smartLawInfo['actionID'], $this->actionData);
                $this->actionHandling->updateAction();
                $this->actionHandling->updateActionDetail('moduleName', $this->smartLawInfo['module']); //updates module name as may have been changed bythe user
                $new_action_id = $this->smartLawInfo['actionID'];
            } else {
                $this->actionHandling->setActionDetails(0, $this->actionData);
                $new_action_id = $this->actionHandling->addAction2015();
            }

            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);

            $sql = sprintf("INSERT INTO %s.smartlaw_action_link(smartlawreviewID,actionID) VALUES (%d,%d) "
                    , _DB_OBJ_FULL
                    , $this->smartLawInfo['reviewID']
                    , $action_id);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();


  // if ($this->smartLawInfo['save_finish'] == 1) {         
            $emailObj = new actionEmailHelper($action_id);
            $who = $emailObj->getwhoDetails();

            $slawdata = $this->getActionsbyID($action_id);

            $sentence = array('sentence' => array("You have an action to carry out the following smart-Law Action"));
            $emailObj->appendInfo($sentence);

            $data = array('singleColData' => array('click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slawdata['ref_No'] ), 'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation'])));
            

            $emailObj->appendInfo($data);
            $emailObj->sendEmail('A smart law Action To Be Completed', $who, array(), array(), 'me_completed', '', 'grey');
            
            $data = array('singleColData' => array('click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $slawdata['ref_No'] ), 'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A smart law Action To Be Approved Once Complete', $whoAU, array(), array(), 'me_completed', '', 'grey');
            
            
    //    }

        $sql = sprintf("update %s.smartlaw_sections set status=%d,reviewduedate=null where slsID=%d", _DB_OBJ_FULL, $status, $this->smartLawId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }
   
   }
   
       public function rejectreason($newid, $reason) {

        $participantObj = SetupGeneric::useModule('Participant');
        $ogrObj = SetupGeneric::useModule('Organigram');

        $this->UpdateStatus2($newid, $reason);

$sql = sprintf("select * from %s.smartlaw_review R inner join %s.smartlaw_sections S on R.smartlawID=S.slsid left join %s.smartlaw_action_link L on R.id=L.smartlawreviewID left join %s.actions A on L.actionID=A.ID    where R.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $newid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
       
        $participantObj->setItemInfo(array('id' => $results[0]['lastamendedby']));
        $details = $participantObj->displayItemById();
        $whoarr = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);

        $ogrObj->setItemInfo(array('id' =>$results[0]['lastamendedby']));

        if (getUserAccessLevel != 1)
            $whoAUarray = $ogrObj->getManager($results[0]['lastamendedby']);

        if ($whoAUarray)
            $whoAU = $whoAUarray["participantID"];
        else
            $whoAU = $whoid;

        $participantObj->setItemInfo(array('id' => getLoggedInUserId()));
        $details = $participantObj->displayItemById();

        $whofrom = ucwords($details['forename'] . ' ' . $details['surname']);

        $data = array(
            'singleColData' => array('click-here-url' => 'Reason for Review Rejection: </BR><BR/>' . $reason . '</BR><BR/>'),
            'twoColData' => array(
                'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $results[0]['ref_No']),
                'assignedto' => array('left' => '<strong>Assigned To:</strong>', 'right' => $whoarr['displayname']),
                'from' => array('left' => '<strong>From:</strong>', 'right' => $whofrom),
                'description' => array('left' => '<strong>Title</strong>', 'right' => $results[0]['slsLegislation'])));
        $emailObj = new actionEmailHelper(0);

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('Smart-ISO Legislation Review Rejection', $whoarr, array(), array(), 'me_completed', '', 'grey');
        
        
        foreach($results as $row){
            if ($row["actionID"] == 0)
                continue;
                    $participantObj->setItemInfo(array('id' => $row['currentWho']));
        $details = $participantObj->displayItemById();
        $whoarr = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);
        
                $data = array(
            'singleColData' => array('click-here-url' => 'Your action has been cancelled as the review has been rejected: </BR><BR/>' . $reason . '</BR><BR/>'),
            'twoColData' => array(
                'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $results[0]['ref_No']),
                'assignedto' => array('left' => '<strong>Assigned To:</strong>', 'right' => $whoarr['displayname']),
                'from' => array('left' => '<strong>From:</strong>', 'right' => $whofrom),
                'description' => array('left' => '<strong>Title</strong>', 'right' => $$results[0]['slsLegislation'])));
        $emailObj = new actionEmailHelper(0);

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('Smart-ISO Legislation Review Rejection', $whoarr, array(), array(), 'me_completed', '', 'grey');    
          
        
        $sql = sprintf("update actions set donedescription='Cancelled',doneDate='".date('Y-m-d'). "',approveau=1,rejectionreason='%s'   where ID=%d", _DB_OBJ_FULL, $row["actionID"]);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        }
      
    }
    
        public function UpdateStatus2($id, $reason) {

       $sql = sprintf("update %s.smartlaw_review set status='2',rejectreason='%s',lastamendedby=%d where ID=" . $id, _DB_OBJ_FULL, $reason, getLoggedInUserId());
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }
    
        public function finalApproval($id,$reviewid) {
        $participantObj = SetupGeneric::useModule('Participant');
        $whoid = getLoggedInUserId();
        $ogrObj = SetupGeneric::useModule('Organigram');
        $ogrObj->setItemInfo(array('id' => $whoid));
        $whoAUarray = $ogrObj->getManager($whoid);
        $whoAU = $whoAUarray["participantID"];

        $datestr = _DB_TYPE == 'mysql' ? 'now()' : 'getdate()';

        $sql = sprintf("update %s.smartlaw_review set whoid=%d,reviewdate=%s,status=1 where ID=%d", _DB_OBJ_FULL,  $whoid, $datestr ,$reviewid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);


        $sql = sprintf("update %s.smartlaw_sections set datelastreview=%s,status=1 where slsID=%d", _DB_OBJ_FULL, $datestr, $id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
      
        
      $sql = sprintf("select * from %s.smartlaw_review R inner join %s.smartlaw_sections S on R.smartlawID=S.slsid left join %s.smartlaw_action_link L on R.id=L.smartlawreviewID  where R.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $reviewid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetch(PDO::FETCH_ASSOC);

          $participantObj->setItemInfo(array('id' => getLoggedInUserId()));
        $details = $participantObj->displayItemById();

        $whofrom = ucwords($details['forename'] . ' ' . $details['surname']);

         $participantObj->setItemInfo(array('id' => $results['whoID']));
        $details = $participantObj->displayItemById();
        $whoarr = array('displayname' => ucwords($details['forename'] . ' ' . $details['surname']),
            'email' => $details['emailAddress'],
            'ID' => $details['participantID']);

        $ogrObj->setItemInfo(array('id' =>$results['whoID']));

        if (getUserAccessLevel != 1)
            $whoAUarray = $ogrObj->getManager($results['whoID']);

        if ($whoAUarray)
            $whoAU = $whoAUarray["participantID"];
        else
            $whoAU = $whoid;
        
        $data = array(
            'singleColData' => array('click-here-url' => 'This law Review has been approved: </BR><BR/>'),
            'twoColData' => array(
                'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $results['ref_No']),
                'assignedto' => array('left' => '<strong>Assigned To:</strong>', 'right' => $whoarr['displayname']),
                'from' => array('left' => '<strong>From:</strong>', 'right' => $whofrom),
                'description' => array('left' => '<strong>Title</strong>', 'right' => $results['slsLegislation'])));
        $emailObj = new actionEmailHelper(0);

        $emailObj->appendInfo($data);
        $emailObj->sendEmail('Smart-ISO Legislation Review Approval', $whoarr, array(), array(), 'me_completed', '', 'grey');
      
        return;
    }
    
        public function archiveReviewFiles($file_id) {


      $sql = sprintf("UPDATE %s.smartlaw_review_files SET archive = 1 WHERE fileID in (%s)", _DB_OBJ_FULL, $file_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

       // return $data;
    }
}

?>