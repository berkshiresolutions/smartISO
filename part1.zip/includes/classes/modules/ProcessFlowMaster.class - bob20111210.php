<?php
 /**
  $Id: ProcessFlowMaster.class.php,v 10.0 Monday, February 07, 2011 8:11:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 2:57:54 PM>
  */

class ProcessFlowMaster
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $dbHand2;
	private $swimlaneId;
	private $businessUnitID;
	private $uniqueReference;
	private $reference;
	private $description;
	private $sourceProcessFlow;
	private $destinationProcessFlow;
	private $stepInformation;
    private $archiveFlag;
	private $process_type;
	private $who_id;
	private $key_process;
	/**
	 * Constructor for initializing process flow master object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 					= DB::connect(_DB_TYPE);
		$this->dbHand2 					= DB::connect(_DB_TYPE);
		$this->swimlaneId				= 0;
		$this->status 					= 0;
		$this->sourceProcessFlow		= 0;
		$this->destinationProcessFlow	= 0;
        $this->archiveFlag              = 0;
		$this->process_type				= 'C';
	}

	/**
	 * to set Risk 27k information for performing various operations with the Risk 27k object
	 */
	public function setProcessMasterInfo($p_swimlaneId,$p_businessUnit,$p_uniqueReference,$p_reference,$p_description,$p_process_type,$p_who_id,$p_key_process,$p_copyFrom=0) {

		$this->swimlaneId			= (int) $p_swimlaneId;
		$this->businessUnitID		= (int) $p_businessUnit;
		$this->uniqueReference		= $p_uniqueReference;
		$this->reference			= $p_reference;
		$this->description			= nl2br($p_description);
		$this->sourceProcessFlow 	= (int) $p_copyFrom;
		$this->archiveFlag			= (int) Session::getSessionField('ARCHIVE_RECORDS');
		$this->process_type			= $p_process_type;
		$this->who_id				= $p_who_id;
		$this->key_process			= $p_key_process;
	}

	public function addProcessCopyLog($p_source,$p_destination) {

		if ( $p_source && $p_destination ) {

			$sql = sprintf("INSERT INTO %s.swimlane_risk_copy_log (sourceSwimID,destinationSwimID)
				VALUES (%d, %d)",_DB_OBJ_FULL,$p_source,$p_destination);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();
		}
	}

	/**
	 * This method is used to add new process flow master
	 *
	 * Array Variables :
	 */
	public function addProcessMaster($p_direct=false) {

		$USER_ID = $this->who_id;

		if ($p_direct) {
			$status = '1';
		} else {
			$status = '0';
		}

		$sql = sprintf("INSERT INTO %s.swimlane (buID,uniqueReference,reference,description,status,whoID,keyProcess,isDirect,processType)
				VALUES
				(%d, '%s', '%s', '%s', '%s' ,%d, %d, %d, '%s')"
				,_DB_OBJ_FULL
				,$this->businessUnitID
				,$this->uniqueReference
				,$this->reference
				,$this->description
				,$status
				,$USER_ID
				,$this->key_process
				,$status
				,$this->process_type);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->businessUnitID);
		$stmt->bindParam(2,$this->uniqueReference);
		$stmt->bindParam(3,$this->reference);
		$stmt->bindParam(4,$this->description);*/

		$stmt->execute();

		// $sth->debugDumpParams();

		//$this->destinationProcessFlow = $this->dbHand->lastInsertId();
		$this->destinationProcessFlow = customLastInsertId( $this->dbHand,'swimlane','swimID');

		if ( !$p_direct && $this->sourceProcessFlow ) {
			$this->copyProcessFlow();
		} else if ( $p_direct && $this->sourceProcessFlow ) {
			$this->copyProcessFlowDirect();
		}

        $this->copyProcessFlowCrossLinks();

		return $this->destinationProcessFlow;
	}

    public function copyProcessFlowCrossLinks() {

        /*$this->sourceProcessFlow = 700;
        $this->destinationProcessFlow = 704;*/

        $sql = sprintf("SELECT ID,swimID,stepLevel,gotoProcess,gotoProcessStep,gotoExtProcess,gotoExtProcessStep
 FROM %s.swimlane_data WHERE ( gotoProcess != 0 OR gotoExtProcess != 0 ) AND swimID = %d",_DB_OBJ_FULL,$this->sourceProcessFlow);

        $stmt 		= $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ( $result ) {
            $upd = '';

            foreach ( $result as $record ) {

                $sql = sprintf("SELECT ID FROM %s.swimlane_data WHERE gotoProcess = %d AND gotoProcessStep = %d AND swimID = %d",_DB_OBJ_FULL,$record['gotoProcess'],$record['ID'],$this->destinationProcessFlow);

                $stmt_sec = $this->dbHand->prepare($sql);
                $stmt_sec->execute();

                $newgotoProcessStep = $stmt_sec->fetchColumn();


                $upd .= sprintf("UPDATE %s.swimlane_data
                               SET gotoProcess = %d,gotoProcessStep = %d
                               WHERE stepLevel = %d AND swimID = %d",_DB_OBJ_FULL,$this->destinationProcessFlow,$newgotoProcessStep,$record['stepLevel'],$this->destinationProcessFlow);

                $upd .= ";";

                //break;
            }

            $stmt_upd = $this->dbHand->prepare($upd);
            $stmt_upd->execute();
        }
    }

	private function copyProcessFlow() {

		$tables = array();

		$tables[] 	= 'swimlane_data';
		$tables[]	= 'swimlane_documents';
		$tables[] 	= 'swimlane_metadata';
		$tables[] 	= 'swimlane_path_information';

		foreach ( $tables as $table_ele ) {
			$method_name_arr = explode('_',$table_ele);

			$method_name = '';

			foreach ( $method_name_arr as $method_name_ele ) {
				$method_name .= ucfirst($method_name_ele);
			}

			$method_name = 'copyPF'.$method_name;

			$this->$method_name();
		}

		//($this->destinationProcessFlow,$this->sourceProcessFlow);
	}

	private function copyProcessFlowDirect() {
		//$p_source_process_id,$p_destination_process_id) {

		/*$this->sourceProcessFlow		= $p_source_process_id;
		$this->destinationProcessFlow	= $p_destination_process_id;*/

		$tables = array();

		$tables[] 	= 'swimlane_data';
		$tables[]	= 'swimlane_documents';
		$tables[] 	= 'swimlane_metadata';
		$tables[] 	= 'swimlane_path_information';

		foreach ( $tables as $table_ele ) {
			$method_name_arr = explode('_',$table_ele);

			$method_name = '';

			foreach ( $method_name_arr as $method_name_ele ) {
				$method_name .= ucfirst($method_name_ele);
			}

			$method_name = 'copyPF'.$method_name;

			$this->$method_name();
		}

		//($this->destinationProcessFlow,$this->sourceProcessFlow);
	}

	private function copyPFSwimlaneData() {

		$sql = sprintf("SELECT * FROM %s.swimlane_data
				WHERE swimID = %d
				ORDER BY ID ASC",_DB_OBJ_FULL,$this->sourceProcessFlow);

		/*$ins = sprintf("INSERT %s.swimlane_data(swimID,type,stepLevel,descQues,criticalControlPoint,buID,
									cmsReference,imageMaps,subSwimID,altPathIndex,startAltPath,interProcess,gotoProcess,gotoProcessStep)
				VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",_DB_OBJ_FULL);*/

		/*$ins_raw = "INSERT %s.swimlane_data(swimID,type,stepLevel,descQues,criticalControlPoint,buID,
					cmsReference,imageMaps,subSwimID,altPathIndex,startAltPath,intraProcess,gotoProcess,gotoProcessStep,gotoImageMaps)
					VALUES(%d, '%s', %d, '%s', '%s', %d, '%s', '%s', %d, %d, %d, %d, %d, %d, '%s')";*/

        $ins_raw = "INSERT %s.swimlane_data(swimID,type,stepLevel,descQues,criticalControlPoint,buID,
                    cmsReference,imageMaps,subSwimID,altPathIndex,startAltPath,endLozenge,intraProcess,gotoProcess,gotoProcessStep,interProcess,gotoExtProcess,gotoExtProcessStep,gotoImageMaps,assessmentDone,assessmentReason)
                    VALUES(%d, '%s', %d, '%s', '%s', %d,
                    '%s', '%s', %d, %d, %d, %d, %d, %d, '%d', %d, %d, %d, %d, %d, '%d')";

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->sourceProcessFlow,PDO::PARAM_INT);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $result_ele ) {

			/*$stmt_ins->bindParam(1,$this->destinationProcessFlow);
			$stmt_ins->bindParam(2,$result_ele['type']);
			$stmt_ins->bindParam(3,$result_ele['stepLevel']);
			$stmt_ins->bindParam(4,$result_ele['descQues']);
			$stmt_ins->bindParam(5,$result_ele['criticalControlPoint']);
			$stmt_ins->bindParam(6,$result_ele['buID']);
			$stmt_ins->bindParam(7,$result_ele['cmsReference']);
			$stmt_ins->bindParam(8,$result_ele['imageMaps']);
			$stmt_ins->bindParam(9,$result_ele['subSwimID']);
			$stmt_ins->bindParam(10,$result_ele['altPathIndex']);
			$stmt_ins->bindParam(11,$result_ele['startAltPath']);
			$stmt_ins->bindParam(12,$result_ele['interProcess']);
			$stmt_ins->bindParam(13,$result_ele['gotoProcess']);
			$stmt_ins->bindParam(14,$result_ele['gotoProcessStep']);*/

			/*$ins = sprintf($ins_raw
						   ,_DB_OBJ_FULL
						   ,$this->destinationProcessFlow
							,$result_ele['type']
							,$result_ele['stepLevel']
							,$result_ele['descQues']
							,$result_ele['criticalControlPoint']
							,$result_ele['buID']
							,$result_ele['cmsReference']
							,$result_ele['imageMaps']
							,$result_ele['subSwimID']
							,$result_ele['altPathIndex']
							,$result_ele['startAltPath']
							,$result_ele['interProcess']
							,$result_ele['gotoProcess']
							,$result_ele['gotoProcessStep']
							,$result_ele['gotoImageMaps']
							,$result_ele['budget']
							,$result_ele['startDate']
							,$result_ele['endDate']);*/

            $result_ele['assessmentDone'] = '';
            $result_ele['assessmentReason'] = '';

			$ins = sprintf($ins_raw
						   ,_DB_OBJ_FULL
						   ,$this->destinationProcessFlow
							,$result_ele['type']
							,$result_ele['stepLevel']
							,$result_ele['descQues']
							,$result_ele['criticalControlPoint']
							,$result_ele['buID']
							,$result_ele['cmsReference']
							,$result_ele['imageMaps']
							,$result_ele['subSwimID']
							,$result_ele['altPathIndex']
							,$result_ele['startAltPath']
                            ,$result_ele['endLozenge']
							,$result_ele['intraProcess']
							,$result_ele['gotoProcess']
							,$result_ele['gotoProcessStep']
							,$result_ele['interProcess']
                            ,$result_ele['gotoExtProcess']
							,$result_ele['gotoExtProcessStep']
							,$result_ele['gotoImageMaps']
							,$result_ele['assessmentDone']
							,$result_ele['assessmentReason']);

			$stmt_ins 	= $this->dbHand->prepare($ins);
			$stmt_ins->execute();
		}
	}

	private function copyPFSwimlaneDocuments() {

		$sql = sprintf("SELECT * FROM %s.swimlane_documents
				WHERE swimID = %d
				ORDER BY sdID ASC",_DB_OBJ_FULL,$this->sourceProcessFlow);

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->sourceProcessFlow);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $result_ele ) {

			$ins = sprintf("INSERT %s.swimlane_documents (swimID,stepID,contentType,documentID)
							VALUES(%d, %d, '%s', %d)"
							,_DB_OBJ_FULL
							,$this->destinationProcessFlow
							,$result_ele['stepID']
							,$result_ele['contentType']
							,$result_ele['documentID']);

			$stmt_ins 	= $this->dbHand->prepare($ins);

			/*$stmt_ins->bindParam(1,$this->destinationProcessFlow);
			$stmt_ins->bindParam(2,$result_ele['stepID']);
			$stmt_ins->bindParam(3,$result_ele['contentType']);
			$stmt_ins->bindParam(4,$result_ele['documentID']);*/

			$stmt_ins->execute();
		}
	}

	private function copyPFSwimlaneMetadata() {

		$inspection_performed = 0;

		$ins = sprintf("INSERT %s.swimlane_metadata(swimID,inspection_performed)
				VALUES(%d, %d)"
				,_DB_OBJ_FULL
				,$this->destinationProcessFlow
				,$inspection_performed);

		$stmt_ins 	= $this->dbHand->prepare($ins);

		/*$stmt_ins->bindParam(1,$this->destinationProcessFlow);
		$stmt_ins->bindParam(2,$inspection_performed);*/

		$stmt_ins->execute();
	}

	private function copyPFSwimlanePathInformation() {

		$sql = sprintf("SELECT * FROM %s.swimlane_path_information
				WHERE swimID = %d
				ORDER BY altPathIndex ASC",_DB_OBJ_FULL,$this->sourceProcessFlow);

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->sourceProcessFlow,PDO::PARAM_INT);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $result_ele ) {

			$ins = sprintf("INSERT %s.swimlane_path_information(swimID,altPathIndex,path_information,support_information)
				VALUES(%d, %d, '%s', '%s')"
				,_DB_OBJ_FULL
				,$this->destinationProcessFlow
				,$result_ele['altPathIndex']
				,$result_ele['path_information']
                ,$result_ele['support_information']);

			$stmt_ins 	= $this->dbHand->prepare($ins);

			/*$stmt_ins->bindParam(1,$this->destinationProcessFlow);
			$stmt_ins->bindParam(2,$result_ele['altPathIndex']);
			$stmt_ins->bindParam(3,$result_ele['path_information']);*/

			$stmt_ins->execute();
		}

	}

	public function editProcessMaster() {

		$sql = sprintf("UPDATE %s.swimlane
				SET
					buID = %d,
					description = '%s',
					processType = '%s',
					keyProcess = %d,
					whoID = %d
				WHERE
					swimID = %d"
					,_DB_OBJ_FULL
					,$this->businessUnitID
					,$this->description
					,$this->process_type
					,$this->key_process
					,$this->who_id
					,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->businessUnitID);
		$stmt->bindParam(2,$this->description);
		$stmt->bindParam(3,$this->swimlaneId);*/

		$stmt->execute() or die(dump_array($stmt->errorInfo()));
	}

	public function hideProcessMaster() {

	    $this->archiveProcessMaster();

		$sql = sprintf("UPDATE %s.swimlane SET isDirect='1'
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
	}

	private function archiveProcessMaster() {

	 $restore_flag = (int) $_GET['restore'];

	  $this->archiveFlag = 1;

	  if ( $restore_flag ) {
		  $this->archiveFlag = 0;
	  }

	 $sql = sprintf("UPDATE %s.swimlane SET archive='%s'
				WHERE swimID = %d",_DB_OBJ_FULL,$this->archiveFlag,$this->swimlaneId);

	 $stmt = $this->dbHand->prepare($sql);
	 $stmt->execute();
	}

	public function deleteProcessMaster() {

		$this->deleteProcessFlowDocuments();
		$this->deleteProcessFlowData();
		$this->deleteProcessFlowMetaData();
		$this->deleteProcessFlowComments();

		$sql = sprintf("DELETE FROM %s.swimlane
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

	}

	private function deleteProcessFlowDocuments() {

		$sql = sprintf("DELETE FROM %s.swimlane_documents
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

	}

	private function deleteProcessFlowData() {

		$sql = sprintf("DELETE FROM %s.swimlane_data
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$sql = sprintf("DELETE FROM %s.swimlane_path_information
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
	}

	private function deleteProcessFlowMetaData() {

		$sql = sprintf("DELETE FROM %s.swimlane_metadata
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
	}

	private function deleteProcessFlowComments() {

		$sql = sprintf("DELETE FROM %s.swimlane_comments
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
	}

	public function displayProcessFlows() {

		$archive_flag = (int) Session::getSessionField('ARCHIVE_RECORDS');

		if ( $archive_flag ) {
			$sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID WHERE  S.isDirect = 0 AND
				S.archive = '1'
				ORDER BY swimID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
		} else {
			$sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID WHERE S.isDirect = 0 AND
				S.archive = '0' OR S.archive IS NULL
				ORDER BY swimID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);
		}

        $stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$new_result 	= array();

		if ($result) {
			$k = 0;
			foreach ( $result as $resultEle ) {

				$sql = sprintf("SELECT MAX(stepLevel) as max_step_level
						FROM %s.swimlane_data
						WHERE swimID = %d",_DB_OBJ_FULL,$resultEle['swimID']);

				$stmt_sec = $this->dbHand->prepare($sql);
				//$stmt_sec->bindParam(1,$resultEle['swimID']);
				$stmt_sec->execute();

				$result_sec = $stmt_sec->fetch(PDO::FETCH_ASSOC);

				$result[$k]['max_step_level'] = $result_sec['max_step_level'];

				$k++;
			}
		}

		return $result;
	}

	public function displayProcessFlowById($p_id) {

		$sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID
				WHERE swimID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_id);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_id);

		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	public function getCurrentProcessFlowInformation() {
		return $this->displayProcessFlowById($this->swimlaneId);
	}

	public function setStepInformation($p_swimlaneId,$p_stepInformation) {

		$this->swimlaneId		= (int) $p_swimlaneId;
		$this->stepInformation	= $p_stepInformation;
	}

	public function saveStepInformation() {

		if (1) {
			switch ($this->stepInformation['form_type']) {
				case 'M': return $this->saveMainPathStep(); break;
				case 'A': return $this->saveAlternatePathStep(); break;
				case 'E': return $this->editSingleStep(); break;
				case 'S': return $this->saveSingleStep(); break;
				case 'R': return $this->removeSingleStep(); break;
				case 'RS': return $this->removeSingleStepSupport(); break;
				case 'D': return $this->dropAlternatePath(); break;
			}
		}
	}

	private function getMaxProcessLevel() {

		$sql = sprintf("SELECT max(stepLevel) as max_level FROM %s.swimlane_data
				WHERE swimID = %d
				AND altPathIndex = 0",_DB_OBJ_FULL,$this->stepInformation['process_flow_id']);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->stepInformation['process_flow_id']);*/
		$stmt->execute();

		return $stmt->fetchColumn();
	}

	public function getProcessFlowPathCount() {

		$sql = sprintf("SELECT DISTINCT altPathIndex FROM %s.swimlane_data
				WHERE swimID = %d
				AND altPathIndex != 0",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$this->swimlaneId);

		$stmt->execute();
		$result = $stmt->fetchALL(PDO::FETCH_ASSOC);

		return count($result);
	}

	private function saveMainPathStep() {

		if ( $this->stepInformation['object_type'] == 'S' ) {
			$level = $this->getMaxProcessLevel();
		} else {
			$level = $this->getMaxProcessLevel() + 1;
		}

		/*$sql = sprintf("INSERT INTO %s.swimlane_data (swimID,type,stepLevel,descQues,criticalControlPoint,buID,cmsReference,imageMaps,subSwimID,altPathIndex,
				startAltPath,interProcess,gotoProcess,gotoProcessStep,budget,startDate,endDate)
				VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",_DB_OBJ_FULL);*/

		$sql_raw = "INSERT INTO %s.swimlane_data (swimID,type,stepLevel,descQues,criticalControlPoint,buID,cmsReference,imageMaps,subSwimID,altPathIndex,
				startAltPath,interProcess,gotoProcess,gotoProcessStep)
				VALUES(%d, '%s', %d, '%s', '%s', %d, '%s', '%s', %d, %d, %d, %d, %d, %d)";

		$image_maps 			= '';
		$sub_swim_id 			= 0;
		$alternate_path_index 	= 0;
		$zero 					= 0;

		$this->stepInformation['ccps'] = str_replace(' ','',$this->stepInformation['ccps']);
		/*$this->stepInformation['ccps'] = str_replace(",","','",$this->stepInformation['ccps']);
		$this->stepInformation['ccps'] = "'".$this->stepInformation['ccps']."'";*/

		if ( $this->stepInformation['start_date'] == '' ) {
			$this->stepInformation['start_date'] = '1900-01-01';
		} else {
			$this->stepInformation['start_date'] = format_date_for_mysql($this->stepInformation['start_date']);
		}

		if ( $this->stepInformation['end_date'] == '' ) {
			$this->stepInformation['end_date'] = '1900-01-01';
		} else {
			$this->stepInformation['end_date'] = format_date_for_mysql($this->stepInformation['end_date']);
		}

		$sql = sprintf($sql_raw
					   ,_DB_OBJ_FULL
					   ,$this->swimlaneId
						,$this->stepInformation['object_type']
						,$level
						,$this->stepInformation['description']
						,$this->stepInformation['ccps']
						,$this->stepInformation['business_unit']
						,$this->stepInformation['cms_reference']
						,$image_maps
						,$sub_swim_id
						,$alternate_path_index
						,$zero
						,$zero
						,$zero
						,$zero);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$this->stepInformation['object_type']);
		$stmt->bindParam(3,$level);
		$stmt->bindParam(4,$this->stepInformation['description']);
		$stmt->bindParam(5,$this->stepInformation['ccps']);
		$stmt->bindParam(6,$this->stepInformation['business_unit']);
		$stmt->bindParam(7,$this->stepInformation['cms_reference']);
		$stmt->bindParam(8,$image_maps);
		$stmt->bindParam(9,$sub_swim_id);
		$stmt->bindParam(10,$alternate_path_index);

		$stmt->bindParam(11,$zero);
		$stmt->bindParam(12,$zero);
		$stmt->bindParam(13,$zero);
		$stmt->bindParam(14,$zero);
		$stmt->bindParam(15,$this->stepInformation['budget']);
		$stmt->bindParam(16,$this->stepInformation['start_date']);
		$stmt->bindParam(17,$this->stepInformation['end_date']);*/

		if ( !$stmt->execute() ) {
			return 0;
		} else {
			//$step_insert_id = $this->dbHand->lastInsertId();
			$step_insert_id = customLastInsertId( $this->dbHand,'swimlane_data','ID');

			$this->addUploadedFiles($step_insert_id);

			if ( $this->stepInformation['vertical_output_required'] == 'Y' || $this->stepInformation['horizontal_output_required'] == 'Y' ) {
				$this->addVerticalHorizontalOutput($step_insert_id);
			}

			return 1;
		}
	}

	private function addUploadedFiles($p_stepId) {

		$rec_id = $this->stepInformation['process_flow_id'];
		$module = 'process_flow';

		$path = $_SERVER['DOCUMENT_ROOT'].'/tmp/'.$module;

		$log_file = $path.'/script'.$rec_id.'.log';

		if ( file_exists($log_file) ) {
			$log = fopen($log_file, 'r');

			if ($log) {
				$contents = fread($log, filesize($log_file));
				fclose($log);

				$file_records = explode("\n",$contents);
			}


			/* added by sanjeev to exclude files */
			$exclude_file_name_array = array();
			$exclude_file_name_array = explode('##!!',$this->stepInformation['upload_exclude_file_names']);

			$objFile = new Upload();
			//$incidenceObj		= new IncidenceMain();

			if ( count($file_records) ) {
				foreach ( $file_records as $value ) {
					if ( $value != '' ) {

						$file_details_arr = explode('~#~',$value);
						$file_path = $path.'/'.$file_details_arr[1];

						if ( file_exists($file_path)) {

							$file_type = mime_content_type($file_path);

							if ( !in_array($file_details_arr[2],$exclude_file_name_array) ) {

								$file_details = array('user_file_name'=>$file_details_arr[2],'file_type'=>$file_type);
								$objFile->setFileInfo($module,$file_details);
								$objFile->setBogusDetails($file_details);
								$objFile->uploadifyAddFileDb();
								$sys_file_name = $objFile->uploadifySysFileName();

								$new_file_path = _PATH_PUB.$module.'/'.$sys_file_name;
							//	echo "<br/>";

								if ( copy($file_path,$new_file_path )) {

									$objFile->updateUploadifyFileName();
									$file_id = $objFile->getLastFileId();

									if ($file_id ) {
										$this->saveStepDocumentInformation($p_stepId,'MAIN',$file_id);
									}

									unlink($file_path);
								}

							} else {
								unlink($file_path);
							}


						}
					}
				}
			}

			unlink($log_file);
		}

	}

	private function saveStepDocumentInformation($p_stepId,$p_documentType,$p_fileId) {


		$sql = sprintf("INSERT INTO %s.swimlane_documents (swimID, stepID, contentType, documentID)
						VALUES (%d, %d, '%s', %d)"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$p_stepId
						,$p_documentType
						,$p_fileId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$p_stepId);
		$stmt->bindParam(3,$p_documentType);
		$stmt->bindParam(4,$p_fileId);*/

		$stmt->execute();
	}

	private function addVerticalHorizontalOutput($p_stepInsertId) {

		$sql_raw = "INSERT INTO %s.swimlane_comments (swimID,stepID,contentType,comment)
						VALUES(%d, %d, '%s', '%s')";

		/*$stmt->bindParam(1,$this->stepInformation['process_flow_id']);
		$stmt->bindParam(2,$p_stepInsertId);*/

		if ( $this->stepInformation['add_furthur_input'] == 'Y' ) {

			$type = 'IN';

			$sql = sprintf($sql_raw
					,_DB_OBJ_FULL
					,$this->stepInformation['process_flow_id']
					,$p_stepInsertId
					,$type
					,$this->stepInformation['input_comment1']);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();
		}

		if ( $this->stepInformation['add_furthur_output'] == 'Y' ) {

			$type = 'OUT';

			$sql = sprintf($sql_raw
					,_DB_OBJ_FULL
					,$this->stepInformation['process_flow_id']
					,$p_stepInsertId
					,$type
					,$this->stepInformation['output_comment1']);

			$stmt = $this->dbHand2->prepare($sql);
			$stmt->execute();
		}

		if ( $this->stepInformation['add_furthur_comment'] == 'Y' ) {

			$type = 'MAIN';

			$sql = sprintf($sql_raw
					,_DB_OBJ_FULL
					,$this->stepInformation['process_flow_id']
					,$p_stepInsertId
					,$type
					,$this->stepInformation['additional_comment1']);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();

		}

		if ( $this->stepInformation['horizontal_output_required'] == 'Y' ) {

			$type = 'HORZ';

			$sql = sprintf($sql_raw
					,_DB_OBJ_FULL
					,$this->stepInformation['process_flow_id']
					,$p_stepInsertId
					,$type
					,$this->stepInformation['horizontal_comment1']);

			$stmt = $this->dbHand2->prepare($sql);
			$stmt->execute();
		}


	}

	private function getStepLevelAndNextLevel() {

		$step_information 			= $this->getStepInformation($this->swimlaneId,$this->stepInformation['insert_after_step']);

		return array($step_information['stepLevel'],($step_information['stepLevel'] + 1));
	}


	private function getStepLevel() {

		$step_information 			= $this->getStepInformation($this->swimlaneId,$this->stepInformation['remove_step']);

		if ( _FIREPHP_ENABLED ) {
			fb($step_information,FirePHP::INFO);
			fb('swimlane: '.$this->swimlaneId.' step: '.$this->stepInformation['remove_step'],FirePHP::INFO);
		}

		return  $step_information['stepLevel'];
	}

	private function nodeExist() {

		list($insert_after_step_level,$next_step_level) 			= $this->getStepLevelAndNextLevel();

		$sql = sprintf("SELECT * FROM %s.swimlane_data
						WHERE swimID = %d
						AND stepLevel = %d
						AND altPathIndex = %d"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$next_step_level
						,$this->stepInformation['alternate_path_index']);

		/*
		echo  "SELECT * FROM swimlane_data
				WHERE swimID = $this->swimlaneId
				AND level = $next_step_level
				AND altPathIndex = ".$this->stepInformation['alternate_path_index'];	*/

		$stmt = $this->dbHand->prepare($sql);

		saveLog($sql);
		saveLog("\n");

		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$next_step_level);
		$stmt->bindParam(3,$this->stepInformation['alternate_path_index']);*/

		$stmt->execute();
		$result = $stmt->fetchALL(PDO::FETCH_ASSOC);

		if ( count($result) ) {
			return true;
		} else {
			return false;
		}

	}

	private function getNodesAfterLevel($p_path_index,$p_level) {

		$sql = sprintf("SELECT count(*) as nodesCount FROM %s.swimlane_data
				WHERE swimID = %d
				AND altPathIndex = %d
				AND stepLevel > %d"
				,_DB_OBJ_FULL
				,$this->swimlaneId
				,$p_path_index
				,$p_level);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$p_path_index);
		$stmt->bindParam(3,$p_level);*/

		$stmt->execute();

		return $stmt->fetchColumn(0);

	}

	private function resetStepInterprocessData() {

		$sql = sprintf("UPDATE %s.swimlane_data
						SET interProcess = '0'
						WHERE ID = %d",_DB_OBJ_FULL,$this->stepInformation['insert_after_step']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

	}

	private function saveSingleStep() {

		$inter_process 			= 0;
		$image_maps 			= '';
		$sub_swim_id 			= 0;
		$alternate_path_index 	= 0;
		$zero 					= 0;

		$step_data = $this->getStepInformation($this->swimlaneId,$this->stepInformation['insert_after_step']);

		if ( $this->stepInformation['object_type'] == 'S' ) {
			$next_step_level = $step_data['stepLevel'];
		} else {
			list($insert_after_step_level,$next_step_level) 			= $this->getStepLevelAndNextLevel();
		}

		if ( $step_data['interProcess'] == 3 ) {
			$this->resetStepInterprocessData();
			$inter_process = 3;
		}

		/*echo $this->getNodesAfterLevel(0,$insert_after_step_level);
		echo "<br/>";
		echo ($this->getNodesAfterLevel(1,$insert_after_step_level)+1);*/
		//exit;



		if ( $this->stepInformation['object_type'] != 'S' ) {
//bob not sure why all this is here
/*
			if ( 1 && $this->getProcessFlowPathCount()  ) {

				if ( $this->getProcessFlowPathCount() == 1 ) {
					if ( ($this->getNodesAfterLevel(0,$insert_after_step_level) > ($this->getNodesAfterLevel(1,$insert_after_step_level)+1)) && $this->nodeExist() ) {
						$this->increaseSubsequentLevels($insert_after_step_level,true);
					} else {
						$this->increaseSubsequentLevels($insert_after_step_level);
					}
				}

			} else if ( $this->nodeExist() ) {
				$this->increaseSubsequentLevels($insert_after_step_level,true);
			}
bob has left this line to increase levels
*/
$this->increaseSubsequentLevels($insert_after_step_level,true);
		}

		$this->stepInformation['ccps'] = str_replace(' ','',$this->stepInformation['ccps']);
		/*$this->stepInformation['ccps'] = str_replace(",","','",$this->stepInformation['ccps']);
		$this->stepInformation['ccps'] = "'".$this->stepInformation['ccps']."'";*/

		if ( $this->stepInformation['start_date'] == '' ) {
			$this->stepInformation['start_date'] = '1900-01-01';
		} else {
			$this->stepInformation['start_date'] = format_date_for_mysql($this->stepInformation['start_date']);
		}

		if ( $this->stepInformation['end_date'] == '' ) {
			$this->stepInformation['end_date'] = '1900-01-01';
		} else {
			$this->stepInformation['end_date'] = format_date_for_mysql($this->stepInformation['end_date']);
		}

		$sql = sprintf("INSERT INTO %s.swimlane_data (swimID,type,stepLevel,descQues,criticalControlPoint,buID,cmsReference,imageMaps,subSwimID,altPathIndex,startAltPath,interProcess,gotoProcess,gotoProcessStep)
						VALUES(%d ,'%s', %d, '%s', '%s', %d, '%s', '%s', %d, %d, %d, %d, %d, %d)"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$this->stepInformation['object_type']
						,$next_step_level
						,$this->stepInformation['description']
						,$this->stepInformation['ccps']
						,$this->stepInformation['business_unit']
						,$this->stepInformation['cms_reference']
						,$image_maps
						,$sub_swim_id
						,$this->stepInformation['alternate_path_index']
						,$zero
						,$inter_process
						,$zero
						,$zero);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$this->stepInformation['object_type']);
		$stmt->bindParam(3,$next_step_level);
		$stmt->bindParam(4,$this->stepInformation['description']);
		$stmt->bindParam(5,$this->stepInformation['ccps']);
		$stmt->bindParam(6,$this->stepInformation['business_unit']);
		$stmt->bindParam(7,$this->stepInformation['cms_reference']);
		$stmt->bindParam(8,$image_maps);
		$stmt->bindParam(9,$sub_swim_id);
		$stmt->bindParam(10,$this->stepInformation['alternate_path_index']);

		$stmt->bindParam(11,$zero);
		$stmt->bindParam(12,$zero);
		$stmt->bindParam(13,$zero);
		$stmt->bindParam(14,$zero);
		$stmt->bindParam(15,$this->stepInformation['budget']);
		$stmt->bindParam(16,$this->stepInformation['start_date']);
		$stmt->bindParam(17,$this->stepInformation['end_date']);*/

		if ( !$stmt->execute() ) {
			return 0;
		} else {
			//$step_insert_id = $this->dbHand->lastInsertId();
			$step_insert_id = customLastInsertId( $this->dbHand,'swimlane_data','ID');
			$this->addUploadedFiles($step_insert_id);

				if ( $this->stepInformation['vertical_output_required'] == 'Y' || $this->stepInformation['horizontal_output_required'] == 'Y' ) {
								$this->addVerticalHorizontalOutput($step_insert_id);
				}

			return 1;
		}
	}

	private function editSingleStep() {

		$this->stepInformation['ccps'] = str_replace(' ','',$this->stepInformation['ccps']);
		/*$this->stepInformation['ccps'] = str_replace(",","','",$this->stepInformation['ccps']);
		$this->stepInformation['ccps'] = "'".$this->stepInformation['ccps']."'";*/

		if ( $this->stepInformation['start_date'] == '' ) {
			$this->stepInformation['start_date'] = '1900-01-01';
		} else {
			$this->stepInformation['start_date'] = format_date_for_mysql($this->stepInformation['start_date']);
		}

		if ( $this->stepInformation['end_date'] == '' ) {
			$this->stepInformation['end_date'] = '1900-01-01';
		} else {
			$this->stepInformation['end_date'] = format_date_for_mysql($this->stepInformation['end_date']);
		}

		$sql = sprintf("UPDATE %s.swimlane_data
				SET
					type = '%s',
					descQues = '%s',
					criticalControlPoint = '%s',
					buID = %d,
					cmsReference = '%s'
				WHERE ID = %d
				AND swimID = %d"
				,_DB_OBJ_FULL
				,$this->stepInformation['object_type']
				,$this->stepInformation['description']
				,$this->stepInformation['ccps']
				,$this->stepInformation['business_unit']
				,$this->stepInformation['cms_reference']
				,$this->stepInformation['insert_after_step']
				,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->stepInformation['object_type']);
		$stmt->bindParam(2,$this->stepInformation['description']);
		$stmt->bindParam(3,$this->stepInformation['ccps']);
		$stmt->bindParam(4,$this->stepInformation['business_unit']);
		$stmt->bindParam(5,$this->stepInformation['cms_reference']);

		$stmt->bindParam(6,$this->stepInformation['budget']);
		$stmt->bindParam(7,$this->stepInformation['start_date']);
		$stmt->bindParam(8,$this->stepInformation['end_date']);

		$stmt->bindParam(9,$this->stepInformation['insert_after_step']);
		$stmt->bindParam(10,$this->swimlaneId);*/

		//return $a;
		if ( !$stmt->execute() ) {
			return 0;
		} else {
			$this->addUploadedFiles($this->stepInformation['insert_after_step']);

				if ( $this->stepInformation['vertical_output_required'] == 'Y' || $this->stepInformation['horizontal_output_required'] == 'Y' ) {
								$this->addVerticalHorizontalOutput($this->stepInformation['insert_after_step']);
				}

				return 1;
		}
	}

	private function removeSingleStep() {

		$step_level 			= $this->getStepLevel();

		/*echo $this->getNodesAfterLevel(0,$step_level);
		echo "<br/>";
		echo ($this->getNodesAfterLevel(1,$step_level)+1);*/
		//exit;

		if ( $this->getProcessFlowPathCount()  ) {

			$step_data = $this->getStepInformation($this->swimlaneId,$this->stepInformation['remove_step']);

			if ( $step_data['interProcess'] == 3 ) {

				if ( _DB_TYPE == 'mssql' ) {
					$sql_pre1 = sprintf("SELECT TOP 1 ID FROM %s.swimlane_data
							   WHERE altPathIndex = %d
							   AND swimID = %d
							   AND ID != %d
							   AND type != 'S'
							   ORDER BY stepLevel DESC"
							   ,_DB_OBJ_FULL
								,$step_data['altPathIndex']
								,$this->swimlaneId
								,$this->stepInformation['remove_step']);
				} else {
					$sql_pre1 = sprintf("SELECT ID FROM %s.swimlane_data
							   WHERE altPathIndex = %d
							   AND swimID = %d
							   AND ID != %d
							   AND type != 'S'
							   ORDER BY stepLevel DESC
							   LIMIT 0,1"
							   ,_DB_OBJ_FULL
								,$step_data['altPathIndex']
								,$this->swimlaneId
								,$this->stepInformation['remove_step']);
				}



				$stmt_pre1 = $this->dbHand->prepare($sql_pre1);
				$stmt_pre1->execute();

				$new_interprocess_record_id = $stmt_pre1->fetchColumn(0);

				if ($new_interprocess_record_id) {

					$sql_pre2 = sprintf("UPDATE %s.swimlane_data
								   SET interProcess = '3'
								   WHERE ID = %d"
									,_DB_OBJ_FULL
									,$new_interprocess_record_id);

					$stmt_pre2 = $this->dbHand->prepare($sql_pre2);
					$stmt_pre2->execute();
				}
			}



			$sql = sprintf("DELETE FROM %s.swimlane_data
					WHERE swimID = %d
					AND ID = %d"
					,_DB_OBJ_FULL
					,$this->swimlaneId
					,$this->stepInformation['remove_step']);



			$stmt = $this->dbHand->prepare($sql);

			$sql_sec = sprintf("DELETE FROM %s.swimlane_data
						WHERE swimID = %d
						AND stepLevel = %d
						AND type = 'S'"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$step_level);

			$stmt_sec = $this->dbHand->prepare($sql_sec);

			/*$stmt->bindParam(1,$this->swimlaneId);
			$stmt->bindParam(2,$this->stepInformation['remove_step']);*/

			if ( !$stmt->execute() ) {
				return 0;
			} else {

				$stmt_sec->execute();


				/* bob removed to delete items
				if ( $this->getProcessFlowPathCount() == 1 ) {
					if ( $this->getNodesAfterLevel(0,$step_level) > ($this->getNodesAfterLevel(1,$step_level)+1) ) {
						$this->decreaseSubsequentLevels($step_level);
					} else {
						$this->decreaseSubsequentLevels($step_level,true);
					}
				}
				*/
				$this->decreaseSubsequentLevels($step_level,true,$step_data['altPathIndex']);
				return 1;
			}


		} else {

			$this->removeSingleStepRelatedProcesses($this->swimlaneId);

			$sql = sprintf("DELETE FROM %s.swimlane_data
					WHERE swimID = %d
					AND ID = %d"
					,_DB_OBJ_FULL
					,$this->swimlaneId
					,$this->stepInformation['remove_step']);


			$stmt = $this->dbHand->prepare($sql);


			if ( _FIREPHP_ENABLED ) {
				fb($sql,FirePHP::INFO);
			}

			$sql_sec = sprintf("DELETE FROM %s.swimlane_data
						WHERE swimID = %d
						AND stepLevel = %d
						AND type = 'S'"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$step_level);

			$stmt_sec = $this->dbHand->prepare($sql_sec);

			if ( _FIREPHP_ENABLED ) {
				fb($sql_sec,FirePHP::INFO);
			}

			/*$stmt->bindParam(1,$this->swimlaneId);
			$stmt->bindParam(2,$this->stepInformation['remove_step']);*/

			if ( !$stmt->execute() ) {
				return 0;
			} else {
				$stmt_sec->execute();
				$this->decreaseSubsequentLevels($step_level,true,$step_data['altPathIndex']);

				return 1;
			}

		}
	}

	private function removeSingleStepRelatedProcesses($p_src_process_id) {

		$step_level = $this->getStepLevel();

		$step_data_related = $this->getStepInformation($p_src_process_id,$this->stepInformation['remove_step']);
		//$this->decreaseSubsequentLevelsRelatedProcesses($p_src_process_id,$step_level,true,$step_data_related['altPathIndex']);

		if ( _FIREPHP_ENABLED ) {
			fb('step level '+$step_level,FirePHP::INFO);
		}

		$sql = sprintf("SELECT destinationSwimID
							FROM %s.swimlane_risk_copy_log
							WHERE sourceSwimID = %d",
							_DB_OBJ_FULL,
							$p_src_process_id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		if ( _FIREPHP_ENABLED ) {
			fb($sql,FirePHP::INFO);
		}

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ($resultset) {
			foreach ( $resultset as $resultset_ele ) {
				// $resultset_ele['destinationSwimID']

				$sql2 = sprintf("DELETE FROM %s.swimlane_data
						WHERE swimID = %d
						AND stepLevel = %d"
						,_DB_OBJ_FULL
						,$resultset_ele['destinationSwimID']
						,$step_level);


				if ( _FIREPHP_ENABLED ) {
					fb($sql2,FirePHP::INFO);
				}


				$stmt2 = $this->dbHand->prepare($sql2);
				$stmt2->execute();

				$sql_sec = sprintf("DELETE FROM %s.swimlane_data
							WHERE swimID = %d
							AND stepLevel = %d
							AND type = 'S'"
							,_DB_OBJ_FULL
							,$resultset_ele['destinationSwimID']
							,$step_level);

				$stmt_sec = $this->dbHand->prepare($sql_sec);

				$stmt_sec->execute();
				if ( _FIREPHP_ENABLED ) {
					fb($stmt_sec,FirePHP::INFO);
				}
			}
		}
	}

	private function removeSingleStepSupport() {

		$step_level 			= $this->getStepLevel();

		/*echo $this->getNodesAfterLevel(0,$step_level);
		echo "<br/>";
		echo ($this->getNodesAfterLevel(1,$step_level)+1);*/
		//exit;

		if ( 1 && $this->getProcessFlowPathCount()  ) {

			$sql_sec = sprintf("DELETE FROM %s.swimlane_data
						WHERE swimID = %d
						AND stepLevel = %d
						AND type = 'S'"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$step_level);

			$stmt_sec = $this->dbHand->prepare($sql_sec);

			/*$stmt->bindParam(1,$this->swimlaneId);
			$stmt->bindParam(2,$this->stepInformation['remove_step']);*/

			if ( !$stmt_sec->execute() ) {
				return 0;
			} else {
				return 1;
			}


		} else {

			$sql_sec = sprintf("DELETE FROM %s.swimlane_data
						WHERE swimID = %d
						AND stepLevel = %d
						AND type = 'S'"
						,_DB_OBJ_FULL
						,$this->swimlaneId
						,$step_level);

			$stmt_sec = $this->dbHand->prepare($sql_sec);

			/*$stmt->bindParam(1,$this->swimlaneId);
			$stmt->bindParam(2,$this->stepInformation['remove_step']);*/

			if ( !$stmt_sec->execute() ) {
				return 0;
			} else {
				return 1;
			}

		}
	}

	private function dropAlternatePath() {

		$sql = sprintf("DELETE FROM %s.swimlane_data
				WHERE swimID = %d
				AND altPathIndex = %d"
				,_DB_OBJ_FULL
				,$this->swimlaneId
				,$this->stepInformation['alternate_path_id']);


		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$this->stepInformation['alternate_path_id']);*/

		if ( $stmt->execute() ) {

			if ( $this->stepInformation['alternate_path_id'] > 0 ) {

				$alternate_path_index_end = $this->stepInformation['alternate_path_id']*1000;

				$sql_sec = sprintf("UPDATE %s.swimlane_data
					SET startAltPath = '0'
					WHERE swimID = %d
					AND (
						startAltPath = %d
						OR
						startAltPath = %d
					)"
					,_DB_OBJ_FULL
					,$this->swimlaneId
					,$this->stepInformation['alternate_path_id']
					,$alternate_path_index_end);


				$stmt_sec = $this->dbHand->prepare($sql_sec);

				/*$stmt_sec->bindParam(1,$this->swimlaneId);
				$stmt_sec->bindParam(2,$this->stepInformation['alternate_path_id']);
				$stmt_sec->bindParam(3,$alternate_path_index_end);*/

				$stmt_sec->execute();

//bob extra info for resetting numbers after drop path limited to 5
//bob fix properly in v4 with more alt paths
				for ($x=$this->stepInformation['alternate_path_id'];$x<5;$x++)
				{
				$sql_alt1 = sprintf("UPDATE %s.swimlane_data
					SET startAltPath = %d
					WHERE swimID = %d
					AND startAltPath = %d"
					,_DB_OBJ_FULL
					,$x-1
					,$this->swimlaneId
					,$x
					,$alternate_path_index_end);
					$stmt_alt1 = $this->dbHand->prepare($sql_alt1);
					$stmt_alt1->execute();

					$sql_alt2 = sprintf("UPDATE %s.swimlane_data
					SET altPathIndex = %d
					WHERE swimID = %d
					AND altPathIndex = %d"
					,_DB_OBJ_FULL
					,$x-1
					,$this->swimlaneId
					,$x
					,$alternate_path_index_end);
					$stmt_alt2 = $this->dbHand->prepare($sql_alt2);
					$stmt_alt2->execute();

				}





				if ( !$this->getProcessFlowPathCount() ) {
					$this->rearrangeMainPath();
				}
			}

			return 1;
		} else {
			return 0;
		}

	}

	private function saveAlternatePathStep() {

		$startAltPath = 0;

		if ( $this->stepInformation['alternate_path_first_step'] ) {
			$this->stepInformation['alternate_path_index'] 	= $this->getProcessFlowPathCount() + 1;
		} else {

			if ( _DB_TYPE == 'mssql' ) {

				$sql_alt = sprintf("SELECT TOP 1 altPathIndex FROM %s.swimlane_data
						WHERE swimID = %d
						ORDER BY ID DESC",_DB_OBJ_FULL,$this->stepInformation['process_flow_id']);
			} else {
				$sql_alt = sprintf("SELECT altPathIndex FROM %s.swimlane_data
						WHERE swimID = %d
						ORDER BY ID DESC
						LIMIT 1",_DB_OBJ_FULL,$this->stepInformation['process_flow_id']);
			}

			$stmt_alt = $this->dbHand->prepare($sql_alt);
			/*$stmt_alt->bindParam(1,$this->stepInformation['process_flow_id']);*/
			$stmt_alt->execute();
			$this->stepInformation['alternate_path_index'] = $stmt_alt->fetchColumn(0);
		}

		list($insert_after_step_level,$next_step_level) 			= $this->getStepLevelAndNextLevel();

		//saveLog("$insert_after_step_level,$next_step_level\n"); // to be deleted

		if ( $this->nodeExist() ) {
			//saveLog("Node exits\n"); //to be deleted
		//	$this->increaseSubsequentLevels($insert_after_step_level);
		}

		$image_maps 			= '';
		$sub_swim_id 			= 0;
		$alternate_path_index 	= $this->stepInformation['alternate_path_index'];
		$zero					= 0;
		$interProcess			= 0;
		$endLozenge 			= 0;

		if ( $this->stepInformation['another_step_involved'] == 'N' && $this->stepInformation['mid_air_stop'] == 'N' && $this->stepInformation['end_at_step'] == 'END' ) {
		//	$interProcess = 3;
		$interProcess=0;
			$endLozenge = 1;
		}

		$this->stepInformation['ccps'] = str_replace(' ','',$this->stepInformation['ccps']);
		/*$this->stepInformation['ccps'] = str_replace(",","','",$this->stepInformation['ccps']);
		$this->stepInformation['ccps'] = "'".$this->stepInformation['ccps']."'";*/

		if ( $this->stepInformation['start_date'] == '' ) {
			$this->stepInformation['start_date'] = '1900-01-01';
		} else {
			$this->stepInformation['start_date'] = format_date_for_mysql($this->stepInformation['start_date']);
		}

		if ( $this->stepInformation['end_date'] == '' ) {
			$this->stepInformation['end_date'] = '1900-01-01';
		} else {
			$this->stepInformation['end_date'] = format_date_for_mysql($this->stepInformation['end_date']);
		}

		if ($alternate_path_index) {

			$sql_sec = sprintf("SELECT max(stepLevel) as nextStepLevel FROM %s.swimlane_data
								WHERE swimID = %d
								AND altPathIndex = %d",_DB_OBJ_FULL,$this->swimlaneId,$alternate_path_index);

			$stmt_sec 	= $this->dbHand->prepare($sql_sec);

			$stmt_sec->execute();
			$result_sec = $stmt_sec->fetch(PDO::FETCH_ASSOC);

			if ( $result_sec['nextStepLevel'] == 0 ) {
				$next_step_level = $insert_after_step_level + $result_sec['nextStepLevel'] + 1;
			} else {
				$next_step_level = $result_sec['nextStepLevel'] + 1;
			}

		}

		$step_id 				= $this->stepInformation['end_at_step'];

		$sql = sprintf("INSERT INTO %s.swimlane_data (swimID,type,stepLevel,descQues,criticalControlPoint,buID,cmsReference,imageMaps,subSwimID,altPathIndex,startAltPath,intraProcess,gotoProcess,gotoProcessStep,endLozenge,endAltPath)
									VALUES(%d, '%s', %d, '%s', '%s', %d, '%s', '%s', '%s', %d, %d, %d, %d, %d, %d,%d)"
									,_DB_OBJ_FULL
									,$this->swimlaneId
									,$this->stepInformation['object_type']
									,$next_step_level
									,$this->stepInformation['description']
									,$this->stepInformation['ccps']
									,$this->stepInformation['business_unit']
									,$this->stepInformation['cms_reference']
									,$image_maps
									,$sub_swim_id
									,$alternate_path_index
									,$startAltPath
									,$interProcess
									,$zero
									,$zero
									,$endLozenge
									,$step_id);

		$stmt = $this->dbHand->prepare($sql);

		//saveLog($sql."\n"); // to be deleted


		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$this->stepInformation['object_type']);
		$stmt->bindParam(3,$next_step_level);
		$stmt->bindParam(4,$this->stepInformation['description']);
		$stmt->bindParam(5,$this->stepInformation['ccps']);
		$stmt->bindParam(6,$this->stepInformation['business_unit']);
		$stmt->bindParam(7,$this->stepInformation['cms_reference']);
		$stmt->bindParam(8,$image_maps);
		$stmt->bindParam(9,$sub_swim_id);
		$stmt->bindParam(10,$alternate_path_index);
		$stmt->bindParam(11,$startAltPath);
		$stmt->bindParam(12,$interProcess);
		$stmt->bindParam(13,$zero);
		$stmt->bindParam(14,$zero);
		$stmt->bindParam(15,$this->stepInformation['budget']);
		$stmt->bindParam(16,$this->stepInformation['start_date']);
		$stmt->bindParam(17,$this->stepInformation['end_date']);*/

		$stmt->execute() or die(dump_array($stmt->errorInfo()));

		//bob fix for midair first entry
//		if ( $this->stepInformation['mid_air_stop'] != 'Y' ) {

			/*$sql_sec = sprintf("UPDATE %s.swimlane_data
							SET startAltPath = ?
							WHERE swimID = ?
							AND ID = ?",_DB_OBJ_FULL);*/

			$sql_sec_raw = "UPDATE %s.swimlane_data
							SET startAltPath = %d
							WHERE swimID = %d
							AND ID = %d";


			if ( $this->stepInformation['alternate_path_first_step'] ) {

				$step_id 				= $this->stepInformation['insert_after_step'];

				/*$sql_test = "UPDATE swimlane_data
							SET startAltPath = ".$this->stepInformation['alternate_path_index']."
							WHERE swimID = ".$this->stepInformation['process_flow_id']."
							AND ID = ".$this->stepInformation['insert_after_step'];*/

				/*$stmt_sec->bindParam(1,$this->stepInformation['alternate_path_index']);
				$stmt_sec->bindParam(2,$this->swimlaneId);
				$stmt_sec->bindParam(3,$this->stepInformation['insert_after_step']);
				*/
			$sql_sec = sprintf($sql_sec_raw,_DB_OBJ_FULL,$alternate_path_index,$this->swimlaneId,$step_id);

			$stmt_sec = $this->dbHand->prepare($sql_sec);
			$stmt_sec->execute();

			}
/*
			if ( $this->stepInformation['alternate_path_last_step'] ) {

				$alternate_path_index 	= $alternate_path_index*1000;
				$step_id 				= $this->stepInformation['end_at_step'];

				/*$sql_test = "UPDATE swimlane_data
							SET startAltPath = ".$alternate_path_index."
							WHERE swimID = ".$this->stepInformation['process_flow_id']."
							AND ID = ".$this->stepInformation['end_at_step'];*/

				/*$stmt_sec->bindParam(1,$alternate_path_index);
				$stmt_sec->bindParam(2,$this->swimlaneId);
				$stmt_sec->bindParam(3,$this->stepInformation['end_at_step']);*/
/*
							$sql_sec_end = "UPDATE %s.swimlane_data
							SET endAltPath = %d
							WHERE swimID = %d
							AND ID = %d";

			$sql_sec = sprintf($sql_sec_end,_DB_OBJ_FULL,$step_id,$this->swimlaneId,$step_id);

			$stmt_sec = $this->dbHand->prepare($sql_sec);
			$stmt_sec->execute();

			}
*/


			return 1;
			/*
		} else {
			return 1;
		}
		*/
	}

	public function getDistinctBusinessUnits($p_outputType='N') {

		$businessUnits = array();

		if ( _DB_TYPE == 'mssql' ) {

			$sql_bus = sprintf("SELECT TOP 1 A.buID,A.buName FROM %s.business_units A
								INNER JOIN %s.swimlane_data B
								ON A.buID = B.buID
								WHERE swimID = %d
								AND type != 'S'
								AND altPathIndex = '0'
								ORDER BY stepLevel ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

		} else {

			$sql_bus = sprintf("SELECT A.buID,A.buName FROM %s.business_units A
								INNER JOIN %s.swimlane_data B
								ON A.buID = B.buID
								WHERE swimID = %d
								AND type != 'S'
								AND altPathIndex = '0'
								ORDER BY stepLevel ASC LIMIT 0,1",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

		}

	    if ( $res_business_units = $this->dbHand->query($sql_bus)) {

			$rec_ele = null;
			$rec_ele = $res_business_units->fetch(PDO::FETCH_ASSOC);

			$z = 0;
			$businessUnits[chr(65+$z)] = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
			$z++;

		} // end if

		if ( _DB_TYPE == 'mssql' ) {

			$sql_bus = sprintf("SELECT TOP 1 A.buID,A.buName FROM %s.business_units A
								INNER JOIN %s.swimlane_data B
								ON A.buID = B.buID
								WHERE swimID = %d
								AND type != 'S'
								AND altPathIndex = '0'
								ORDER BY stepLevel DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

		} else {

			$sql_bus = sprintf("SELECT A.buID,A.buName FROM %s.business_units A
								INNER JOIN %s.swimlane_data B
								ON A.buID = B.buID
								WHERE swimID = %d
								AND type != 'S'
								AND altPathIndex = '0'
								ORDER BY stepLevel DESC LIMIT 0,1",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

		}

	    if ( $res_business_units = $this->dbHand->query($sql_bus)) {

			$rec_ele = null;
			$rec_ele = $res_business_units->fetch(PDO::FETCH_ASSOC);

			$rec_ele_bottom = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];

		} // end if

		/*echo $sql_bus = sprintf("SELECT buID,buName,stepLevel FROM %s.business_units
							WHERE buID IN (
								SELECT DISTINCT buID,stepLevel
								FROM %s.swimlane_data
								WHERE swimID = %d
								AND type != 'S'
								ORDER BY stepLevel ASC)",
								_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);*/

		$sql_bus = sprintf("SELECT DISTINCT B.buID,buName,stepLevel FROM %s.business_units A
							INNER JOIN %s.swimlane_data B
							ON A.buID = B.buID
							WHERE B.swimID = %d AND B.type != 'S' and altpathindex=0 ORDER BY stepLevel ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

	    if ( $res_business_units = $this->dbHand->query($sql_bus)) {

			$rec = null;
			$rec = $res_business_units->fetchAll(PDO::FETCH_ASSOC);

			$z = 1;

			foreach ( $rec as $rec_ele ) {
				$buvalue = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
				if ( !in_array($buvalue,$businessUnits)  ) {
					$businessUnits[chr(65+$z)] = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
					$z++;
				}
			} // end foreach
		} // end if
/*
		if ( !empty($rec_ele_bottom) && !in_array($rec_ele_bottom,$businessUnits) ) {
			$businessUnits[chr(65+$z)] = $rec_ele_bottom;
			$z++;
		}

*/

		$sql_bus = sprintf("SELECT DISTINCT B.buID,buName,stepLevel FROM %s.business_units A
							INNER JOIN %s.swimlane_data B
							ON A.buID = B.buID
							WHERE B.swimID = %d AND B.type != 'S' and altpathindex>0 ORDER BY stepLevel ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

	    if ( $res_business_units = $this->dbHand->query($sql_bus)) {

			$rec = null;
			$rec = $res_business_units->fetchAll(PDO::FETCH_ASSOC);


			foreach ( $rec as $rec_ele ) {
				$buvalue = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
				if ( !in_array($buvalue,$businessUnits)  ) {
					$businessUnits[chr(65+$z)] = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
					$z++;
				}
			} // end foreach
		} // end if


		$sql_bus = sprintf("SELECT A.buID,buName FROM %s.business_units A
						   INNER JOIN %s.swimlane_data B
						   ON A.buID = B.buID
							WHERE swimID = %d
							AND type = 'S'
							ORDER BY stepLevel ASC",
							_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

		if ( $res_business_units = $this->dbHand->query($sql_bus)) {

			$rec = null;
			$rec = $res_business_units->fetchAll(PDO::FETCH_ASSOC);

			foreach ( $rec as $rec_ele ) {
                // edited on 20110705
                $buvalue = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
				if ( !in_array($buvalue,$businessUnits) ) {
                    //$businessUnits[chr(65+$z)] = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID']*1000;
                    $businessUnits[chr(65+$z)] = ucfirst($rec_ele['buName']).'|'.$rec_ele['buID'];
                    $z++;
                }

			} // end foreach
		} // end if

		return $businessUnits;
	}

	public function refreshPathInformation() {

		$paths	= array();

		$sql 				= sprintf("SELECT ID,type,
								stepLevel,altPathIndex , B.buName,B.buID,startAltPath,
								intraProcess,interProcess,gotoProcess,gotoProcessStep,gotoExtProcess,gotoExtProcessStep,endLozenge,endAltPath
								FROM %s.swimlane_data S
								INNER JOIN %s.business_units B
								ON S.buID = B.buID
								WHERE S.swimID = %d
								ORDER BY altPathIndex,stepLevel,ID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->swimlaneId);

		$del_stmt 			= sprintf("DELETE FROM %s.swimlane_path_information
								WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$del_stmt = $this->dbHand->prepare($del_stmt);
		/*$del_stmt->bindParam(1,$this->swimlaneId,PDO::PARAM_INT);*/

		/*$update = "UPDATE swimlane_path_information
					SET path_information = ?
					WHERE swimID = ?
					AND altPathIndex = ?";*/

		$stmt 				= $this->dbHand->prepare($sql);
		//$stmt_update 		= $this->dbHand->prepare($update);

		$businessUnits = $this->getDistinctBusinessUnits();

		//dump_array($businessUnits);

		/*$stmt->bindParam(1,$this->swimlaneId);*/
		$stmt->execute();

		$result_all_paths = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$result 					= array();
		$nodes_per_alternate_path 	= array();

		if ($result_all_paths) {
			foreach ( $result_all_paths as $result_all_paths_ele ) {

				$path_key = $result_all_paths_ele['altPathIndex'];
				$result[$path_key][] = $result_all_paths_ele;

				if ($path_key) {
					$nodes_per_alternate_path[$path_key]++;
				}

				if ( !in_array($path_key,$paths) ) {
					$paths[] = $path_key;
				}
			}
		}

		//dump_array($result);

		$field_sep = ':';
		$record_sep = '~#~';
		$support_special_sep = '=>';

		// delete all existing paths for specific swimlane

		if (1 && $this->swimlaneId) {
			$del_stmt->execute();
		}

		//dump_array($paths);

		if ( 1 && count($paths) ) {

			foreach ( $paths as $path_ele ) {

				$already_exists 		= false;

				// Code block starts for generating path information
				$path_data 			= '';
				$support_node_data = '';

				if ($path_ele) {

					$path_ele1000 = $path_ele*1000;

					$sql_for_altpath 	= sprintf("SELECT ID, startAltPath, stepLevel
								FROM %s.swimlane_data
								WHERE swimID = %d
								AND altPathIndex = 0
								AND type != 'S'
								ORDER BY stepLevel",_DB_OBJ_FULL,$this->swimlaneId);

					$stmt_for_altpath	= $this->dbHand->prepare($sql_for_altpath);

					//$stmt_for_altpath->bindParam(1,$this->swimlaneId);
					//$stmt_for_altpath->bindParam(2,$path_ele,PDO::PARAM_INT);
					//$stmt_for_altpath->bindParam(3,$path_ele1000,PDO::PARAM_INT);

					$stmt_for_altpath->execute();

					$altpath_result = $stmt_for_altpath->fetchAll(PDO::FETCH_ASSOC);

					//dump_array($altpath_result);
				}

				$k = 0;

				foreach ( $result[$path_ele] as $result_ele ) {

                    $end_lozenge_exist = false;

					$sql_third = sprintf("SELECT * FROM %s.swimlane_data
						WHERE swimID = ".$this->swimlaneId."
						AND endLozenge = 1
						AND altPathIndex = ".$path_ele,_DB_OBJ_FULL);

					if ($res_third = $this->dbHand->query($sql_third)) {

						/* Check the number of rows that match the SELECT statement */
						if ($res_third->fetch() > 0) {
							$end_lozenge_exist 	= true;
						}
					}

					//echo $end_lozenge_exist;echo "<br/>";

					// order Depth:Column:AltPath:ProcessStep
					// special case for support
					if ( $result_ele['type'] == 'S' ) {
                        // edited on 20110705
						//$search_business_unit = $result_ele['buName'].'|'.$result_ele['buID']*1000;
                        $search_business_unit = $result_ele['buName'].'|'.$result_ele['buID'];
					} else {
						$search_business_unit = $result_ele['buName'].'|'.$result_ele['buID'];
					}

                    //dump_array($businessUnits);
                    //echo $search_business_unit."<br/>";

					$depth = '';
					$depth = array_search(ucfirst($search_business_unit),$businessUnits);

					switch ( $result_ele['intraProcess'] ) {
						case 1: $inout_process = 'OUT'; break;
						case 2: $inout_process = 'IN'; break;
						case 0: $inout_process = 'NONE'; break;
					}

					switch ( $result_ele['interProcess'] ) {
						case 1: $ext_inout_process = 'EXOUT'; break;
						case 2: $ext_inout_process = 'EXIN'; break;
						case 0: $ext_inout_process = 'NONE'; break;
					}

					//echo $result_ele['intraProcess'].$result_ele['interProcess'].$inout_process.$ext_inout_process;

					//echo $result_ele['gotoProcess'].''.$result_ele['gotoProcessStep']."<br/>";

					if (!$k) {

						$parent_step_id = 0;

						if ( $altpath_result ) {
							foreach ( $altpath_result as $altpath_result_ele_key=>$altpath_result_ele_value ) {

								if ( $altpath_result_ele_value['startAltPath'] == $path_ele ) {

									$parent_step_id = $altpath_result_ele_key + 1;
									break;
								}
							}
						}

						if ( $result_ele['type'] != 'S' ) {

							if ( $end_lozenge_exist && count($result[$path_ele]) == 1 ) {
								$parent_step_id 		= $parent_step_id;
								$parent_step_id_sec 	= 'END';
							}

							$path_data .= $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];

							if ( $ext_inout_process != 'NONE' ) {
								$path_data .= $record_sep . $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $ext_inout_process . $field_sep . $result_ele['gotoExtProcess'] . $field_sep . $result_ele['gotoExtProcessStep'];
							}

							if ( $end_lozenge_exist && count($result[$path_ele]) == 1 ) {

								$path_data .= $record_sep . $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id_sec . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];

							}

							/*if ( count($result[$path_ele]) == 1 && $altpath_result && $k == ($nodes_per_alternate_path[$path_ele]-1) ) {
								foreach ( $altpath_result as $altpath_result_ele_key=>$altpath_result_ele_value ) {

									if ( $altpath_result_ele_value['startAltPath'] == ($path_ele*1000) ) {
										$parent_step_id = $altpath_result_ele_key + 1;
										break;
									}
								}

								$path_data .= $record_sep . $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id_sec . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];
							}
*/
							$prev_path_data = $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];
						} else {



							$s_node = $prev_path_data;
							$e_node = $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];


						}
					} else {



						$parent_step_id = 0;

						if ( $altpath_result && $k == ($nodes_per_alternate_path[$path_ele]-1) ) {
							foreach ( $altpath_result as $altpath_result_ele_key=>$altpath_result_ele_value ) {

								if ( $altpath_result_ele_value['startAltPath'] == ($path_ele*1001) ) {
									//echo $altpath_result_ele_value['startAltPath']."-".$path_ele."<br/>";
									$parent_step_id = $altpath_result_ele_key + 1;
									//echo $parent_step_id;
									break;
								}
							}
						}

						if ( $result_ele['type'] != 'S' ) {

						//dump_array($result);

						if ($result_ele['endAltPath']>0)
						{
												$parent_step_id = $this->getEndAltLevel($result_ele['endAltPath']);


						}


							if ( $result[$path_ele][count($result[$path_ele])-1]['type'] == 'S' ) {
								$compare_key = $k+2;
							} else {
								$compare_key = $k+1;
							}

							if ( $end_lozenge_exist && count($result[$path_ele]) == $compare_key ) {
								$parent_step_id = 'END';
							}


							/*echo $result[$path_ele][count($result[$path_ele])-1]['type'];
							echo $end_lozenge_exist.$parent_step_id."--".count($result[$path_ele])." == ".($k+1)."<br/>";*/

							$path_data .= $record_sep . $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];

							if ( $ext_inout_process != 'NONE' ) {
								$path_data .= $record_sep . $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $ext_inout_process . $field_sep . $result_ele['gotoExtProcess'] . $field_sep . $result_ele['gotoExtProcessStep'];
							}

							$prev_path_data = $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];

						} else {

							$s_node = $prev_path_data;
							$e_node = $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $parent_step_id . $field_sep . $inout_process . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];

						}

					}

					if ( $result_ele['type'] == 'S' ) {

						if ( $support_node_data == '' ) {
							$support_node_data .= $s_node. $support_special_sep .$e_node;
						} else {
							$support_node_data .= $record_sep . $s_node. $support_special_sep .$e_node;
						}
					}

					// added for debugging
					/*if ( $path_ele == 1) { */
						/*echo $path_data;
						echo "<br/>";*/
					/* }*/


					$k++;
				} // end foreach

					// Code block ends for generating path information


					$sql_sec = sprintf("SELECT * FROM %s.swimlane_path_information
						WHERE swimID = ".$this->swimlaneId."
						AND altPathIndex = ".$path_ele,_DB_OBJ_FULL);

					if ($res = $this->dbHand->query($sql_sec)) {

						/* Check the number of rows that match the SELECT statement */
						if ($res->fetchColumn() > 0) {
							$already_exists 	= true;
						}
					}


					//emergency fix from bob
$pos=strpos($path_data,$record_sep);


		if ($pos===false)
		{
$altcheck = $this->getEndAltLevel($result_ele['endAltPath']);




$path_data .= $record_sep . $depth . $field_sep . $result_ele['stepLevel'] . $field_sep . $path_ele . $field_sep . $result_ele['ID'] . $field_sep . $altcheck . $field_sep . "NONE" . $field_sep . $result_ele['gotoProcess'] . $field_sep . $result_ele['gotoProcessStep'];

}



					$insert = sprintf("INSERT %s.swimlane_path_information (swimID,altPathIndex,path_information,support_information)
								VALUES(%d,%d,'%s','%s')",_DB_OBJ_FULL
								,$this->swimlaneId
								,$path_ele
								,$path_data
								,$support_node_data);

					$stmt_insert = $this->dbHand2->prepare($insert);
					$stmt_insert->execute();

					/*echo $insert;
					echo "<br/>";*/


				//echo $path_data."<br>";
			} // end foreach paths

		}
	}

	public function getBlocksInfo() {

		$swimlane_id = (int) $this->swimlaneId;

		$sql = sprintf("SELECT * FROM %s.swimlane_path_information
				WHERE swimID = %d
				ORDER BY altPathIndex ASC",_DB_OBJ_FULL,$swimlane_id);

		//echo $sql;

		$stmt 			= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$swimlane_id);*/

		$stmt->execute();
		//$a = $stmt->errorInfo();

		//dump_array($a);

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$newresult = array();

		if ( count($result) ) {

			$k = 0;

			foreach ( $result as $result_ele ) {

				$newresult[$k]['swimID'] 				= $result_ele['swimID'];
				$newresult[$k]['altPathIndex'] 			= $result_ele['altPathIndex'];
				$newresult[$k]['path_information'] 		= $result_ele['path_information'];
				$newresult[$k]['support_information'] 	= $result_ele['support_information'];

				$nodes = explode('~#~',$result_ele['path_information']);

				foreach ( $nodes as $nodes_ele ) {
					$node_arr = explode(':',$nodes_ele);

					$rec = $this->getStepInformation($result_ele['swimID'],$node_arr[3]);

					$newresult[$k]['step_information'][$node_arr[3]] = $rec;
				}

				$nodes = explode('~#~',$result_ele['support_information']);

				foreach ( $nodes as $nodes_ele ) {

					$nodes_ele_values = explode('=>',$nodes_ele);

					$node_arr = explode(':',$nodes_ele_values[1]);

					$rec = $this->getStepInformation($result_ele['swimID'],$node_arr[3]);

					$newresult[$k]['step_information'][$node_arr[3]] = $rec;
				}

				$k++;
			}
		}

		return $newresult;
	}

	private function getStepCommentsInformation($p_swimlane_id,$p_step_id) {

		$sql 		= sprintf("	SELECT contentType,comment FROM %s.swimlane_comments
						WHERE swimID = %d
						AND	stepID = %d
						ORDER BY contentType ASC",_DB_OBJ_FULL,$p_swimlane_id,$p_step_id);


		$stmt 	= $this->dbHand2->prepare($sql);

		/*$stmt->bindParam(1,$p_swimlane_id);
		$stmt->bindParam(2,$p_step_id);*/

		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$record = array();

		foreach ( $result as $result_ele ) {
			$record[trim($result_ele['contentType'])][] = $result_ele['comment'];
		}

		return $record;
	}

	public function getStepSupportInformation($p_swimlane_id,$p_step_level) {

		$sql 		= sprintf("SELECT buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						AND type = 'S'
						AND stepLevel = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id,$p_step_level);


		$stmt 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_swimlane_id);
		$stmt->bindParam(2,$p_step_id);*/
		//saveLog($sql."\n");

		$stmt->execute();

		$record = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$result = array();

		if ( count($record) ) {

			foreach ( $record as $record_ele ) {
				$result[] = $record_ele['buName'];
			}
		}

		return $result;
	}

	public function getStepInformation($p_swimlane_id,$p_step_id) {

		$sql 		= sprintf("SELECT SD.*,buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						AND ID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id,$p_step_id);


		$stmt 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_swimlane_id);
		$stmt->bindParam(2,$p_step_id);*/
		//saveLog($sql."\n");

		$stmt->execute();

		$rec_comments = $this->getStepCommentsInformation($p_swimlane_id,$p_step_id);

		$record = $stmt->fetch(PDO::FETCH_ASSOC);
		$record['comments_information'] = $rec_comments;

		$record['step_support_information'] = $this->getStepSupportInformation($p_swimlane_id,$record['stepLevel']);

		if ( $record['gotoProcess'] ) {
			$process_data = $this->displayProcessFlowById($record['gotoProcess']);
			$record['gotoProcessLabel'] = $process_data['reference'];
		} else {
			$record['gotoProcessLabel'] = 0;
		}

		return $record;
	}

	private function increaseSubsequentLevels($p_step_level,$p_main_path_only=false) {

		$alternate_path_index = (int) $this->stepInformation['alternate_path_index'];

		if ($p_main_path_only) {

			$sql = sprintf("SELECT ID FROM %s.swimlane_data
				WHERE swimID = %d
				AND stepLevel > %d
				AND altPathIndex = %d",_DB_OBJ_FULL,$this->swimlaneId,$p_step_level,$alternate_path_index);

		} else {

			$sql = sprintf("SELECT ID FROM %s.swimlane_data
				WHERE swimID = %d
				AND stepLevel > %d
				AND altPathIndex = 0",_DB_OBJ_FULL,$this->swimlaneId,$p_step_level);
		}

		saveLog($sql."\n\n");

		$stmt 	= $this->dbHand->prepare($sql);

		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$IN  = "ID IN (";

		foreach ( $result as $resultele ) {

			$IN .= $resultele['ID'].",";
		}

		$IN = rtrim($IN,',').")";

		$sql = sprintf("UPDATE %s.swimlane_data SET stepLevel = stepLevel + 1
				WHERE $IN
				AND swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);


		$stmt_sec 	= $this->dbHand->prepare($sql);

		$stmt_sec->execute();


	}

	private function decreaseSubsequentLevels($p_step_level,$p_main_path_only=false,$altPath=0) {
		//bob cannot find correct altpath once deleted
			//	$alternate_path_index = (int) $this->stepInformation['alternate_path_index'];

		$alternate_path_index=$altPath;

		if ($p_main_path_only) {

			$sql = sprintf("SELECT ID FROM %s.swimlane_data
				WHERE swimID = %d
				AND stepLevel > %d
				AND altPathIndex = %d",_DB_OBJ_FULL,$this->swimlaneId,$p_step_level,$alternate_path_index);

		} else {

			$sql = sprintf("SELECT ID FROM %s.swimlane_data
				WHERE swimID = %d
				AND stepLevel > %d",_DB_OBJ_FULL,$this->swimlaneId,$p_step_level,$alternate_path_index);
		}

		$stmt 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$p_step_level);

		if ($p_main_path_only) {
			$stmt->bindParam(3,$alternate_path_index);
		}*/

		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
		$sql1 = sprintf("INSERT INTO %s.boblog (data) values ('%s')",_DB_OBJ_FULL,$sql);
		$stmt1 	= $this->dbHand->prepare($sql1);
		$stmt1->execute();
*/


		$IN  = "ID IN (";

		foreach ( $result as $resultele ) {

			$IN .= $resultele['ID'].",";
		}

		$IN = rtrim($IN,',').")";

		$sql = sprintf("UPDATE %s.swimlane_data SET stepLevel = stepLevel - 1
				WHERE $IN
				AND swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt_sec 	= $this->dbHand->prepare($sql);
		/*$stmt_sec->bindParam(1,$this->swimlaneId);*/

		$stmt_sec->execute();
	}

	private function decreaseSubsequentLevelsRelatedProcesses($p_swimlaneId,$p_step_level,$p_main_path_only=false,$altPath=0) {
		//bob cannot find correct altpath once deleted
			//	$alternate_path_index = (int) $this->stepInformation['alternate_path_index'];

		$alternate_path_index=$altPath;

		if ($p_main_path_only) {

			$sql = sprintf("SELECT ID FROM %s.swimlane_data
				WHERE swimID = %d
				AND stepLevel > %d
				AND altPathIndex = %d",_DB_OBJ_FULL,$p_swimlaneId,$p_step_level,$alternate_path_index);

		} else {

			$sql = sprintf("SELECT ID FROM %s.swimlane_data
				WHERE swimID = %d
				AND stepLevel > %d",_DB_OBJ_FULL,$p_swimlaneId,$p_step_level,$alternate_path_index);
		}

		$stmt 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$p_step_level);

		if ($p_main_path_only) {
			$stmt->bindParam(3,$alternate_path_index);
		}*/

		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
		$sql1 = sprintf("INSERT INTO %s.boblog (data) values ('%s')",_DB_OBJ_FULL,$sql);
		$stmt1 	= $this->dbHand->prepare($sql1);
		$stmt1->execute();
*/


		$IN  = "ID IN (";

		foreach ( $result as $resultele ) {

			$IN .= $resultele['ID'].",";
		}

		$IN = rtrim($IN,',').")";

		$sql = sprintf("UPDATE %s.swimlane_data SET stepLevel = stepLevel - 1
				WHERE $IN
				AND swimID = %d",_DB_OBJ_FULL,$p_swimlaneId);

		$stmt_sec 	= $this->dbHand->prepare($sql);
		/*$stmt_sec->bindParam(1,$this->swimlaneId);*/

		$stmt_sec->execute();
	}

	/**
	 *
	 * @access private
	 * @param $p_businessUnit
	 * @param $p_altPath
	 * @return boolean	This will return TRUE if step of same alternate path and business unit already exists, otherwise it will return FALSE.
	 *
	 */
	private function isBusinessUnitAltPathExist($p_businessUnit,$p_altPath) {

		$already_exists = false;

		$sql	 	= "SELECT * FROM %s.swimlane_data
						WHERE swimID = %d,
						buID = %d,
						altPathIndex = %d";

		$pred_sql 	= sprintf($sql,_DB_OBJ_FULL,$this->swimlaneId,$p_businessUnit,$p_altPath);

		if ($res = $this->dbHand->query($pred_sql)) {

			/* Check the number of rows that match the SELECT statement */
			if ($res->fetchColumn() > 0) {
				$already_exists 	= true;
			}
		}

		return $already_exists;
	}

	private function getMaximumLevelByProcess($p_swimlane_id) {

		$sql	 	= sprintf("SELECT MAX(stepLevel) as max_level FROM %s.swimlane_data
						WHERE swimID = %d",_DB_OBJ_FULL,$p_swimlane_id);

		$stmt 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/

		$stmt->execute();

		return $stmt->fetchColumn(0);
	}

	public function saveNodeCoordinates($p_step_no,$p_coordinates) {

		$sql	 	= sprintf("UPDATE %s.swimlane_data
						SET imageMaps = '%s'
						WHERE swimID = %d
						AND ID = %d",_DB_OBJ_FULL,$p_coordinates,$this->swimlaneId,$p_step_no);

		$stmt 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_coordinates);
		$stmt->bindParam(2,$this->swimlaneId);
		$stmt->bindParam(3,$p_step_no);*/

		$stmt->execute();
	}

	public function saveProcessInOutCoordinates($p_step_no,$p_coordinates) {

		$sql	 	= sprintf("UPDATE %s.swimlane_data
						SET gotoImageMaps = '%s'
						WHERE swimID = %d
						AND ID = %d",_DB_OBJ_FULL,$p_coordinates,$this->swimlaneId,$p_step_no);

		$stmt 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_coordinates);
		$stmt->bindParam(2,$this->swimlaneId);
		$stmt->bindParam(3,$p_step_no);*/

		$stmt->execute();
	}

	public function rearrangeMainPath() {

		$sql = sprintf("SELECT * FROM %s.swimlane_data
				WHERE swimID = %d
				AND type != 'S'
				ORDER BY stepLevel ASC",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->swimlaneId);*/
		$stmt->execute();

		$result_arr = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$node_count = count($result_arr);

		if ($node_count) {
			foreach ( $result_arr as $result_ele ) {

				$level = $result_ele['stepLevel'];

				if ( $level > 1 ) {
					$level--;
				}

				$sql_sec = sprintf("SELECT * FROM %s.swimlane_data
							WHERE swimID = %d
							AND stepLevel = %d",_DB_OBJ_FULL,$this->swimlaneId,$level);

				$stmt_sec 	= $this->dbHand->prepare($sql_sec);

				/*$stmt_sec->bindParam(1,$this->swimlaneId);
				$stmt_sec->bindParam(2,$level);*/
				$stmt_sec->execute();

				$res = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);

				$res_count = count($res);

				if ( !$res_count ) {

					$upd = sprintf("UPDATE %s.swimlane_data
							SET stepLevel = %d
							WHERE ID = %d
							AND swimID = %d",_DB_OBJ_FULL,$level,$result_ele['ID'],$this->swimlaneId);

					$stmt_upd 	= $this->dbHand->prepare($upd);

					/*$stmt_upd->bindParam(1,$level);
					$stmt_upd->bindParam(2,$result_ele['ID']);
					$stmt_upd->bindParam(3,$this->swimlaneId);*/

					$stmt_upd->execute();
				}
			} // end foreach
		} // end if

		if ( $this->getMaxProcessLevel() != $node_count ) {
			$this->rearrangeMainPath();
		}
	}

	public function getAllProcessFlows() {

		$sql 		= sprintf("SELECT * FROM %s.swimlane WHERE isDirect = 0",_DB_OBJ_FULL);
		$stmt	 	= $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function getAllProcessFlowsWithSteps() {

		$innersql 		= sprintf("SELECT DISTINCT S.swimID FROM %s.swimlane S
						INNER JOIN %s.swimlane_data D
						ON S.swimID = D.swimID",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$sql = sprintf("SELECT * FROM %s.swimlane WHERE swimID IN ($innersql) ",_DB_OBJ_FULL);

		$stmt	 	= $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function getProcessFlowSteps($p_swimlane_id) {

		$sql 		= sprintf("SELECT SD.*,buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						ORDER BY altPathIndex,ID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$records = array();

		if ( count($result) ) {
			$k = 0;
			foreach ( $result as $result_ele ) {

				$records[$k] = $result_ele;

				if ( $result_ele['gotoExtProcess'] ) {
					$process_data = $this->displayProcessFlowById($result_ele['gotoExtProcess']);
					$goto_process_label = $process_data['reference'];
				} else {
					$goto_process_label = 0;
				}

				//$records[$k]['budget_simplified'] 		= substr($result_ele['budget'],0,-2);

 				/*if ( $result_ele['startDate'] != '1900-01-01' && $result_ele['startDate'] != '0000-00-00' && $result_ele['startDate'] != '' ) {
					$records[$k]['startDate_simplified'] 	= format_date($result_ele['startDate']);
				}

				if ( $result_ele['endDate'] != '1900-01-01' && $result_ele['endDate'] != '0000-00-00' && $result_ele['endDate'] != '' ) {
					$records[$k]['endDate_simplified'] 		= format_date($result_ele['endDate']);
				}*/

				if ( strlen($records[$k]['descQues']) > 200 ) {
$records[$k]['mid_desc'] = substr($records[$k]['descQues'],0,200).'...';
} else {
$records[$k]['mid_desc'] = $records[$k]['descQues'];
}

				$records[$k]['hasGoToLink'] = $this->hasGoToLink($p_swimlane_id,$result_ele['ID']);

				$records[$k]['gotoProcessLabel'] = $goto_process_label;
				$records[$k]['documents'] = $this->getStepDocuments($p_swimlane_id,$result_ele['ID']);
				$k++;
			}
		}

		return $records;
	}

	private function hasGoToLink($p_swimlane_id,$p_stepId) {

		$sql = sprintf("SELECT * FROM %s.swimlane_data
					   WHERE swimID = %d
					   AND gotoProcess = %d
					   AND gotoProcessStep = %d",_DB_OBJ_FULL,$p_swimlane_id,$p_swimlane_id,$p_stepId);

		$stmt	 	= $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $result['ID'] ) {
			return 1;
		} else {

			$sql = sprintf("SELECT * FROM %s.swimlane_data
					   WHERE gotoExtProcess = %d
					   AND gotoExtProcessStep = %d",_DB_OBJ_FULL,$p_swimlane_id,$p_stepId);

			$stmt	 	= $this->dbHand->prepare($sql);
			$stmt->execute();

			$result = $stmt->fetch(PDO::FETCH_ASSOC);

			if ( $result['ID'] ) {
				return 1;
			} else {
				return 0;
			}
		}
	}

	private function getStepDocuments($p_swimlane_id,$p_stepId) {

		$sql 		= sprintf("	SELECT SD.contentType,SD.documentID,U.usrFilename,U.sysFilename,U.module FROM %s.swimlane_documents SD
						INNER JOIN %s.uploaded_files U
						ON U.fileID = SD.documentID
						WHERE SD.swimID = %d
						AND SD.stepID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id,$p_stepId);

		$stmt	 	= $this->dbHand->prepare($sql);


		/*$stmt->bindParam(1,$p_swimlane_id);
		$stmt->bindParam(2,$p_stepId);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$list = "";

		if ( count($result) ) {
			foreach ( $result as $result_ele ) {

				$list .= "<a href='javascript: void(0)' class='download_file' rel='".$result_ele['documentID']."'>".$result_ele['usrFilename']."</a>&nbsp;";
				$list .= "<a href='javascript:void(0)' style='color:red;font-weight:bold' class='delete_file' alt='".$p_swimlane_id."'";
				$list .= "rel='".$result_ele['documentID']."'>X</a>,<br/>";
			}
		}

		$list = rtrim($list,",<br/>");

		return $list;
	}

	// only main path steps
	public function getProcessFlowMainSteps($p_swimlane_id) {

		$sql 		= sprintf("	SELECT SD.*,buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						AND SD.altPathIndex = 0",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$records = array();

		if ( count($result) ) {
			$k = 0;
			foreach ( $result as $result_ele ) {

				$records[$k] = $result_ele;

				if ( $result_ele['gotoProcess'] ) {
					$process_data = $this->displayProcessFlowById($result_ele['gotoProcess']);
					$goto_process_label = $process_data['reference'];
				} else {
					$goto_process_label = 0;
				}

				$records[$k]['gotoProcessLabel'] = $goto_process_label;
				$k++;
			}
		}

		return $records;
	}

	public function getProcessFlowAllSteps($p_swimlane_id,$p_step_id) {

		$sql 		= sprintf("	SELECT SD.*,buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						ORDER BY SD.altPathIndex,SD.stepLevel ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$records = array();

		if ( count($result) ) {
			$k = 0;
			foreach ( $result as $result_ele ) {

				$records[$k] = $result_ele;

				if ( $result_ele['ID'] == $p_step_id ) { continue; }

				if ( $result_ele['gotoProcess'] ) {
					$process_data = $this->displayProcessFlowById($result_ele['gotoProcess']);
					$goto_process_label = $process_data['reference'];
				} else {
					$goto_process_label = 0;
				}

				$records[$k]['gotoProcessLabel'] = $goto_process_label;
				$k++;
			}
		}

		//dump_array($records);

		return $records;
	}
	public function getProcessFlowAllStepsD($p_swimlane_id,$p_step_id) {

		$sql 		= sprintf("	SELECT SD.*,buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						AND NOT type='D'
						ORDER BY SD.altPathIndex,SD.stepLevel ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$records = array();

		if ( count($result) ) {
			$k = 0;
			foreach ( $result as $result_ele ) {

				$records[$k] = $result_ele;

				if ( $result_ele['ID'] == $p_step_id ) { continue; }

				if ( $result_ele['gotoProcess'] ) {
					$process_data = $this->displayProcessFlowById($result_ele['gotoProcess']);
					$goto_process_label = $process_data['reference'];
				} else {
					$goto_process_label = 0;
				}

				$records[$k]['gotoProcessLabel'] = $goto_process_label;
				$k++;
			}
		}

		//dump_array($records);

		return $records;
	}

	public function getProcessFlowAllStepsG($p_swimlane_id,$p_step_id) {

		$sql 		= sprintf("	SELECT SD.*,buName FROM %s.swimlane_data SD
						INNER JOIN %s.business_units B
						ON B.buID = SD.buID
						WHERE SD.swimID = %d
						AND  (SD.intraProcess = 0 OR SD.intraProcess IS NULL)
						ORDER BY SD.altPathIndex,SD.stepLevel ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$records = array();

		if ( count($result) ) {
			$k = 0;
			foreach ( $result as $result_ele ) {

				$records[$k] = $result_ele;

				if ( $result_ele['ID'] == $p_step_id ) { continue; }

				if ( $result_ele['gotoProcess'] ) {
					$process_data = $this->displayProcessFlowById($result_ele['gotoProcess']);
					$goto_process_label = $process_data['reference'];
				} else {
					$goto_process_label = 0;
				}

				$records[$k]['gotoProcessLabel'] = $goto_process_label;
				$k++;
			}
		}

		//dump_array($records);

		return $records;
	}

	public function linkGotoProcessStep($p_context_process_flow, $p_context_process_flow_step, $p_link_process_flow, $p_link_process_flow_step) {

				$interProcessIN 	= 2;
				$interProcessOUT 	= 1;

				// for intra process
				if ( $p_context_process_flow == $p_link_process_flow ) {

								$sql 		= sprintf("	UPDATE %s.swimlane_data
												SET
													intraProcess = %d,
													gotoProcess = %d,
													gotoProcessStep = %d
													WHERE swimID = %d
													AND ID = %d"
												,_DB_OBJ_FULL
												,$interProcessOUT
												,$p_link_process_flow
												,$p_link_process_flow_step
												,$p_context_process_flow
												,$p_context_process_flow_step);

								$sql_sec	= sprintf("UPDATE %s.swimlane_data
												SET
													intraProcess = %d,
													gotoProcess = %d,
													gotoProcessStep = %d
												WHERE swimID = %d
												AND ID = %d"
												,_DB_OBJ_FULL
												,$interProcessIN
												,$p_context_process_flow
												,$p_context_process_flow_step
												,$p_link_process_flow
												,$p_link_process_flow_step);

				// for inter process
				} else {

								$sql 		= sprintf("	UPDATE %s.swimlane_data
												SET
													interProcess = %d,
													gotoExtProcess = %d,
													gotoExtProcessStep = %d
													WHERE swimID = %d
													AND ID = %d"
												,_DB_OBJ_FULL
												,$interProcessOUT
												,$p_link_process_flow
												,$p_link_process_flow_step
												,$p_context_process_flow
												,$p_context_process_flow_step);

								$sql_sec	= sprintf("UPDATE %s.swimlane_data
												SET
													interProcess = %d,
													gotoExtProcess = %d,
													gotoExtProcessStep = %d
												WHERE swimID = %d
												AND ID = %d"
												,_DB_OBJ_FULL
												,$interProcessIN
												,$p_context_process_flow
												,$p_context_process_flow_step
												,$p_link_process_flow
												,$p_link_process_flow_step);

				}


		$stmt			= $this->dbHand->prepare($sql);
		$stmt_sec	 	= $this->dbHand->prepare($sql_sec);

		/*$stmt->bindParam(1,$interProcessOUT);
		$stmt->bindParam(2,$p_link_process_flow);
		$stmt->bindParam(3,$p_link_process_flow_step);
		$stmt->bindParam(4,$p_context_process_flow);
		$stmt->bindParam(5,$p_context_process_flow_step);*/

		/*$stmt_sec->bindParam(1,$interProcessIN);
		$stmt_sec->bindParam(2,$p_context_process_flow);
		$stmt_sec->bindParam(3,$p_context_process_flow_step);
		$stmt_sec->bindParam(4,$p_link_process_flow);
		$stmt_sec->bindParam(5,$p_link_process_flow_step);*/

		$stmt->execute();
		$stmt_sec->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);

	}

	public function finishProcessFlow($p_swimlane_id) {

		$sql 		= sprintf("UPDATE %s.swimlane
						SET status = 1
						WHERE swimID = %d
						AND status = 0",_DB_OBJ_FULL,$p_swimlane_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_swimlane_id);*/
		$stmt->execute();

	}

	public function getPreviousNextProcessFlow($p_swimlane_id) {


		if ( _DB_TYPE == 'mssql' ) {

			$sql 		= sprintf("	(SELECT TOP 1 swimID as process_flow_id
						FROM %s.swimlane
						WHERE swimID < %d
						AND status = 1
						ORDER BY swimID DESC)
							UNION
						(SELECT TOP 1 swimID as process_flow_id
						FROM %s.swimlane
						WHERE swimID > %d
						AND status = 1
						ORDER BY swimID ASC)",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id,$p_swimlane_id);

		} else {
			$sql 		= sprintf("	(SELECT swimID as process_flow_id
						FROM %s.swimlane
						WHERE swimID < %d
						AND status = 1
						ORDER BY swimID DESC
						LIMIT 0 , 1)
							UNION
						(SELECT swimID as process_flow_id
						FROM %s.swimlane
						WHERE swimID > %d
						AND status = 1
						ORDER BY swimID ASC
						LIMIT 0 , 1)",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlane_id,$p_swimlane_id);
		}


		$stmt	 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_swimlane_id);
		$stmt->bindParam(2,$p_swimlane_id);*/
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function save_subprocess_info($p_process_flow_id, $p_process_flow_step, $p_sub_process_flow) {

		$sql 		= sprintf("UPDATE %s.swimlane_data
						SET
							subSwimID = %d
						WHERE
							ID = %d
						AND
							swimID = %d"
							,_DB_OBJ_FULL
							,$p_sub_process_flow
							,$p_process_flow_step
							,$p_process_flow_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_sub_process_flow);
		$stmt->bindParam(2,$p_process_flow_step);
		$stmt->bindParam(3,$p_process_flow_id);*/
		$stmt->execute();

	}

	public function reset_subprocess_info($p_process_flow_id, $p_process_flow_step ) {

		$sql 		= sprintf("UPDATE %s.swimlane_data
						SET
							subSwimID = 0
						WHERE
							ID = %d
						AND
							swimID = %d",_DB_OBJ_FULL,$p_process_flow_step,$p_process_flow_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_process_flow_step);
		$stmt->bindParam(2,$p_process_flow_id);*/
		$stmt->execute();

	}

	public function downloadDocument($p_doc_id) {

		$updObj = new Upload();
		$updObj->setFileInfo('process_flow',array('id'=>$p_doc_id));
		$file_details = $updObj->getFileDetails();

		$file = _PATH_PUB.'process_flow/'.$file_details['sysFilename'];

		$download_file_name = $file_details['usrFilename'];

		if ( !$file ) {
				// File doesn't exist, output error
				die('file not found');
		} else {
				// Set headers
				header('Content-type: application/download');
				header('Content-Description: File Transfer');
				header('Content-Disposition: attachment; filename="'.$download_file_name.'" ');
				header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
				header('Content-Transfer-Encoding: binary');

				// Read the file from disk
				readfile($file);
		}

		$updObj = null;
    }

	public function getCurrentProcessFlow() {
		return $this->swimlaneId;
	}

	public function getHazardControlSymbols() {

		$sql 		= sprintf("	SELECT hazardSymbols,controlSymbols
						FROM %s.risk
						WHERE processID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->swimlaneId);*/
		$stmt->execute();

		$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$hazard_symbol_arr 	= array();
		$control_symbol_arr = array();

		if ( count($records) ) {
			foreach ( $records as $record_ele ) {

				if ( $record_ele['hazardSymbols'] != '' ) {
					$arr = explode(",",$record_ele['hazardSymbols']);

					foreach ( $arr as $arr_ele ) {
						$arr_ele_name = 'ha'.$arr_ele.'.jpg';

						if ( !in_array($arr_ele_name,$hazard_symbol_arr) ) {
							$hazard_symbol_arr[] = $arr_ele_name;
						} // end if
					} // end foreach
				} // end if


				if ( $record_ele['controlSymbols'] != '' ) {
					$arr = explode(",",$record_ele['controlSymbols']);

					foreach ( $arr as $arr_ele ) {
						$arr_ele_name = $arr_ele.'.jpg';

						if ( !in_array($arr_ele_name,$control_symbol_arr) ) {
							$control_symbol_arr[] = $arr_ele_name;
						} // end if
					} // end foreach
				} // end if
			} // end outer foreach
		}

		$symbols['hazard'] 		= $hazard_symbol_arr;
		$symbols['control'] 	= $control_symbol_arr;

		return $symbols;
	}

	public function getRiskRating() {

		$sql 		= sprintf("SELECT riskRating1,	riskRatingColor1
						FROM %s.risk
						WHERE processID = %d
						ORDER BY ID ASC",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->swimlaneId);*/
		$stmt->execute();

		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		return $record;
	}

	public function dropGoToLink($p_process_flow_id, $p_process_flow_step ) {

		$sql 		= sprintf("SELECT gotoProcess,gotoProcessStep
						FROM %s.swimlane_data
						WHERE
							ID = %d
						AND
							swimID = %d",_DB_OBJ_FULL,$p_process_flow_step,$p_process_flow_id);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_process_flow_step);
		$stmt->bindParam(2,$p_process_flow_id);*/

		$stmt->execute();

		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		/*$sql_sec		= sprintf("	UPDATE %s.swimlane_data
						SET
							interProcess = 0,
							gotoProcess = 0,
							gotoProcessStep = 0,
							gotoImageMaps = ''
						WHERE
							ID = ?
						AND
							swimID = ?",_DB_OBJ_FULL);*/

		$sql_sec_raw	= "UPDATE %s.swimlane_data
						SET
							intraProcess = 0,
							gotoProcess = 0,
							gotoProcessStep = 0,
							interProcess = 0,
							gotoExtProcess = 0,
							gotoExtProcessStep = 0,
							gotoImageMaps = ''
						WHERE
							ID = %d
						AND
							swimID = %d";


		$sql_sec	= sprintf($sql_sec_raw,_DB_OBJ_FULL,$record['gotoProcessStep'],$record['gotoProcess']);
		$stmt_sec 	= $this->dbHand->prepare($sql_sec);

		$stmt_sec->execute();

		$sql_sec	= sprintf($sql_sec_raw,_DB_OBJ_FULL,$p_process_flow_step,$p_process_flow_id);
		$stmt_sec 	= $this->dbHand->prepare($sql_sec);

		$stmt_sec->execute();
	}

	public function intraprocess_goto_link_information() {

		$sql 		= sprintf("	SELECT ID,stepLevel,altPathIndex,startAltPath,
						interProcess,gotoProcess,gotoProcessStep
						FROM %s.swimlane_data
						WHERE swimID = %d
						AND gotoProcess = %d
						ORDER BY ID ASC",_DB_OBJ_FULL,$this->swimlaneId,$this->swimlaneId);

		$stmt	 	= $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->swimlaneId);
		$stmt->bindParam(2,$this->swimlaneId);*/

		$stmt->execute();

		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		return $record;
	}

	public function getProcessessByParentDeprecated($p_parent_id=0) {

		$sql = sprintf("SELECT * FROM %s.swimlane WHERE parentSwimID = %d ORDER BY swimID ASC",_DB_OBJ_FULL,$p_parent_id);

		$stmt 		= $this->dbHand->prepare($sql);
		$stmt->execute();
		$resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function getProcessessByParent($p_parent_id=0) {

        if ( !$p_parent_id ) {

			if ( !$this->archiveFlag ) {
				$sql = sprintf("SELECT * FROM %s.swimlane S INNER JOIN %s.business_units B ON S.buID = B.buID
							WHERE (isDirect = 0 OR isDirect IS NULL) AND (archive = '%s' OR archive IS NULL) ORDER BY swimID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->archiveFlag);
			} else {
				$sql = sprintf("SELECT * FROM %s.swimlane S INNER JOIN %s.business_units B ON S.buID = B.buID
							WHERE (isDirect = 0 OR isDirect IS NULL) AND archive = '%s' ORDER BY swimID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->archiveFlag);
			}

		} else {

			if ( !$this->archiveFlag ) {
				$sql = sprintf("SELECT * FROM %s.swimlane S INNER JOIN %s.business_units B ON S.buID = B.buID
							WHERE (isDirect = 0 OR isDirect IS NULL) AND (archive = '%s' OR archive IS NULL) AND swimID IN (SELECT subSwimID FROM %s.swimlane_data WHERE swimID = %d)
					   ORDER BY swimID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->archiveFlag,_DB_OBJ_FULL,$p_parent_id);
			} else {
				$sql = sprintf("SELECT * FROM %s.swimlane S INNER JOIN %s.business_units B ON S.buID = B.buID
							WHERE (isDirect = 0 OR isDirect IS NULL) AND archive = '%s' AND swimID IN (SELECT subSwimID FROM %s.swimlane_data WHERE swimID = %d)
					   ORDER BY swimID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->archiveFlag,_DB_OBJ_FULL,$p_parent_id);
			}
		}

		if ( _FIREPHP_ENABLED ) {
			fb($sql,FirePHP::INFO);
		}

		$stmt 		= $this->dbHand->prepare($sql);
		$stmt->execute();
		$resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function getProcessessByParentCCPMatrix($p_parent_id=0) {

        if ( !$p_parent_id ) {
            $sql = sprintf("SELECT * FROM %s.swimlane S INNER JOIN %s.business_units B ON S.buID = B.buID WHERE isDirect = 0 AND archive = '%s' ORDER BY swimID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->archiveFlag);
		} else {
			$sql = sprintf("SELECT * FROM %s.swimlane S INNER JOIN %s.business_units B ON S.buID = B.buID WHERE isDirect = 0 AND archive = '%s'
						   AND swimID IN (SELECT subSwimID FROM %s.swimlane_data WHERE swimID = %d)
						   OR swimID = %d
					   ORDER BY swimID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->archiveFlag,_DB_OBJ_FULL,$p_parent_id,$p_parent_id);
		}

		if ( _FIREPHP_ENABLED ) {
			fb($sql,FirePHP::INFO);
		}

		$stmt 		= $this->dbHand->prepare($sql);
		$stmt->execute();
		$resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function getProcessByBuID($p_buID) {

		$sql = sprintf("SELECT * FROM %s.swimlane WHERE buID = %d",_DB_OBJ_FULL,$p_buID);

		$stmt 		= $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function getProcessBySelProcess($p_sel_processes) {

		if ( count($p_sel_processes) ) {
			$in_processes = implode(',',$p_sel_processes);
			$in_processes = "(".$in_processes.")";

			$sql = sprintf("SELECT * FROM %s.swimlane WHERE swimID IN %s",_DB_OBJ_FULL,$in_processes);

			$stmt 		= $this->dbHand->prepare($sql);
			$stmt->execute();

			return $stmt->fetchAll(PDO::FETCH_ASSOC);
		} else {
			return array();
		}
	}

	public function getListingforExport() {

		$participantObj	 	= SetupGeneric::useModule('Participant');

		$this->setProcessMasterInfo('','','','','','');
		$processFlowData 	= $this->displayProcessFlows();

		$heading = array(array('Reference #', 'Business Unit', 'Who', 'Description'));
		$result = array();

		if ( count($processFlowData) ) {

			foreach ( $processFlowData as $element ) {

				$participant_id = $element['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$result[] = array($element['reference'], $element['buName'], $participant_name, $element['description']);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}

	public function deleteStepDocument($p_documentID) {

		$sql = sprintf("UPDATE %s.swimlane_documents SET documentID = 0 WHERE documentID = %d",_DB_OBJ_FULL,$p_documentID);
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
	}

	public function altPathLastStep() {

		$sql = sprintf("SELECT * FROM %s.swimlane_path_information
				WHERE swimID = %d",_DB_OBJ_FULL,$this->swimlaneId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$rec = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$arr = array();
		$alt_path_last_step = array();

		foreach ( $rec as $rec_ele ) {

			if ( $rec_ele['altPathIndex'] == 0 ) { continue; }

			$arr = explode("~#~",$rec_ele['path_information']);
			$step_info = $arr[count($arr)-1];
			$step_info_arr = explode(":",$step_info);
			$alt_path_last_step[$rec_ele['altPathIndex']] = $step_info_arr[3];

			$arr = null;
		}

		return $alt_path_last_step;
	}

	public function changeAltPathSetting($process_flow_id,$step_id,$alt_path,$mid_air_stop,$alt_process_flow_stops_at) {

		if ( $mid_air_stop == 'Y' ) {

			$upd = sprintf("UPDATE %s.swimlane_data
					SET endLozenge = 0,endAltPath = 0
					WHERE ID = %d
					AND swimID = %d
					AND altPathIndex =  %d",_DB_OBJ_FULL,$step_id,$process_flow_id,$alt_path);

			$stmt = $this->dbHand->prepare($upd);
			$stmt->execute();
/*
			$upd_sec = sprintf("UPDATE %s.swimlane_data
					SET startAltPath = '0'
					WHERE swimID = %d
					AND startAltPath =  %d",_DB_OBJ_FULL,$process_flow_id,($alt_path*1000));

			$stmt_sec = $this->dbHand->prepare($upd_sec);
			$stmt_sec->execute();
*/
		} else if ( $mid_air_stop == 'N' ) {

			if ( $alt_process_flow_stops_at == 'END' ) {

				echo $upd = sprintf("UPDATE %s.swimlane_data
					SET endLozenge = 1,endAltPath=0
					WHERE ID = %d
					AND swimID = %d
					AND altPathIndex =  %d",_DB_OBJ_FULL,$step_id,$process_flow_id,$alt_path);

				$stmt = $this->dbHand->prepare($upd);
				$stmt->execute();

			} else {

				$upd = sprintf("UPDATE %s.swimlane_data
					SET endLozenge = 0,endAltPath=%d
					WHERE ID = %d
					AND swimID = %d
					AND altPathIndex =  %d",_DB_OBJ_FULL,$alt_process_flow_stops_at,$step_id,$process_flow_id,$alt_path);

/*
				$upd_sec = sprintf("UPDATE %s.swimlane_data
					SET startAltPath = '".($alt_path*1000)."'
					WHERE ID = %d
					AND swimID = %d",_DB_OBJ_FULL,$alt_process_flow_stops_at,$process_flow_id);
*/
				$stmt = $this->dbHand->prepare($upd);
				$stmt->execute();
//				$stmt_sec = $this->dbHand->prepare($upd_sec);
//				$stmt_sec->execute();
			}
		}
	}

	public function reversePathLevels($p_process_flow_id) {

		for ($i=1;$i<6;$i++) {

			$sql = sprintf("SELECT * FROM %s.swimlane_data
						   WHERE swimID = %d
						   AND altPathIndex = %d
						   ORDER BY stepLevel ASC",_DB_OBJ_FULL,$p_process_flow_id,$i);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();

			$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

			//$upd = sprintf("UPDATE SET %s.swimlane_data");

			$level_array = array();

			foreach ( $records as $records_ele ) {
				$level_array[] = $records_ele['stepLevel'];
			}

			$sql = sprintf("SELECT * FROM %s.swimlane_data
						   WHERE swimID = %d
						   AND altPathIndex = %d
						   ORDER BY stepLevel DESC",_DB_OBJ_FULL,$p_process_flow_id,$i);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();

			$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$k = 0;
			foreach ( $records as $records_ele ) {

				$upd = sprintf("UPDATE %s.swimlane_data SET stepLevel = ".$level_array[$k]." WHERE ID = ".$records_ele['ID'],_DB_OBJ_FULL);
				$stmt = $this->dbHand->prepare($upd);
				$stmt->execute();

				$k++;
			}
		}
	}

	public function getMaxStepLevelByAltPath($p_process_flow_id,$p_alt_path_index) {

		$sql = sprintf("SELECT * FROM %s.swimlane_data
						WHERE swimID = %d
						AND altPathIndex = %d
						ORDER BY stepLevel DESC",_DB_OBJ_FULL,$p_process_flow_id,$p_alt_path_index);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		return $record['stepLevel'];
	}

	public function getEndPathSettings($p_process_flow_id,$p_alt_path) {

		$path_settings['has_end_lozenge'] 	= 0;
		$path_settings['mid_air']		  	= 0;
		$path_settings['stop_at']			= 0;

		$sql = sprintf("SELECT * FROM %s.swimlane_data
						WHERE swimID = %d
						AND altPathIndex = %d",_DB_OBJ_FULL,$p_process_flow_id,$p_alt_path);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $resultset as $record ) {
			if ( $record['endLozenge'] ) {
				$path_settings['has_end_lozenge'] = 1;
				break;
			}
		}

		$sql = sprintf("SELECT * FROM %s.swimlane_data
						WHERE swimID = %d
						and endAltpath>0
						AND AltPathIndex = %d",_DB_OBJ_FULL,$p_process_flow_id,($p_alt_path));

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultset) ) {
			$path_settings['stop_at'] = $resultset[0]['ID'];
		} else if (!$path_settings['has_end_lozenge']) {
			$path_settings['mid_air'] = 1;
		}

		return $path_settings;

	}
	public function getEndAltLevel($p_swim_id) {

		$sql = sprintf("SELECT stepLevel FROM %s.swimlane_data
						WHERE ID = %d ",_DB_OBJ_FULL,$p_swim_id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetch(PDO::FETCH_ASSOC);

		$altLevel = 0;

		if ( $resultset['stepLevel'] ) {
			$altLevel =  $resultset['stepLevel'];
		}

		return $altLevel;
	}




	public function getEndLozengeCount($p_process_flow_id) {

		$sql = sprintf("SELECT * FROM %s.swimlane_data
						WHERE swimID = %d
						AND endLozenge = 1
						AND altPathIndex != 0",_DB_OBJ_FULL,$p_process_flow_id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetch(PDO::FETCH_ASSOC);

		$has_end_lozenge = 0;

		if ( $resultset['endLozenge'] ) {
			$has_end_lozenge = 1;
		}

		return $has_end_lozenge;
	}

	public function getCCPSections() {

		$sql = sprintf("SELECT code,name FROM %s.msr_departments
					   WHERE sID = 11
					   AND SUBSTRING(code,1,1) > 3
					   AND code NOT IN ('4','5','6','7','8','9') ORDER BY code ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultset) ) {

			foreach ( $resultset as $ele ) {
				$records[$ele['code']] = $ele['code'].' - '.$ele['name'];
			}
		}

		return $records;
	}

	public function getProcessesWithCCPs() {

		$sql = sprintf("SELECT uniqueReference,reference,cmsReference,processType,description
						FROM %s.swimlane_data A
						INNER JOIN %s.swimlane B
						ON A.swimID = B.swimID
						WHERE cmsReference != ''",_DB_OBJ_FULL,_DB_OBJ_FULL);

		/*$sql = sprintf("SELECT uniqueReference,reference,cmsReference,processType
						FROM %s.swimlane_data A
						INNER JOIN %s.swimlane B
						ON A.swimID = B.swimID",_DB_OBJ_FULL,_DB_OBJ_FULL);*/

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultset) ) {

			foreach ( $resultset as $ele ) {

				switch ($ele['processType']) {
					case 'C' : $process_type = 'CBP'; break;
					case 'P' : $process_type = 'PBP'; break;
					case 'S' : $process_type = 'SBP'; break;
					default : $process_type = 'CBP'; break;
				}

				$records[$process_type][] = $ele;
			}


		}

		return $records;
	}

	public function getProcessesWithCCPsForMatrix($p_parent_arr) {

		$p_parent_str = implode(",",$p_parent_arr);

		$sql = sprintf("SELECT uniqueReference,reference,cmsReference,processType,description
						FROM %s.swimlane_data A
						INNER JOIN
						(SELECT * FROM %s.swimlane
						WHERE swimID IN (%s)
						OR swimID IN (SELECT subSwimID FROM %s.swimlane_data WHERE swimID IN (%s))
						) B
						ON A.swimID = B.swimID",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_parent_str,_DB_OBJ_FULL,$p_parent_str);


		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultset) ) {

			foreach ( $resultset as $ele ) {

				switch ($ele['processType']) {
					case 'C' : $process_type = 'CBP'; break;
					case 'P' : $process_type = 'PBP'; break;
					case 'S' : $process_type = 'SBP'; break;
					default : $process_type = 'CBP'; break;
				}

				$records[$process_type][] = $ele;
			}


		}

		return $records;
	}

	public function setProcessesAssessmentDone($p_swimlaneId) {

		$sql = sprintf("UPDATE %s.swimlane_data SET assessmentDone = 3 WHERE assessmentDone != 1 AND swimID = %d",_DB_OBJ_FULL,$p_swimlaneId);

		$stmt 	= $this->dbHand->prepare($sql);

		if ( $stmt->execute() ) {
			return true;
		} else {
			return false;
		}
	}

	public function sendActionMail($p_swimlaneId) {

		$sql = "SELECT * FROM %s.risk WHERE processStepID IN (SELECT ID FROM %s.swimlane_data WHERE assessmentDone != 1 AND swimID = %d)";

		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,$p_swimlaneId);

		$stmt 	= $this->dbHand->prepare($psql);
		$stmt->execute();

		$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ($records) {
			foreach ( $records as $record_ele ) {

				$objAlert = new SendActionAlerts('risk',$record_ele['ID']);
				$objAlert->sendAlerts();
			}
		}
	}
		public function getTopProcesses() {

		$sql = sprintf("SELECT * FROM %s.swimlane WHERE keyProcess = 1 ",_DB_OBJ_FULL);

		$stmt 		= $this->dbHand->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ($result) {
			foreach ( $result as $record_ele ) {

				$resultSet[] = $record_ele['swimID'];
			}
		}
		return $resultSet;
	}
		public function saveCcpMatrixData() {
$result_ele=$this->stepInformation;
			$ins = sprintf("INSERT %s.ccp_matrix_data (title,description,data,who,date)
							VALUES('%s', '%s', '%s', '%s', %s)"
							,_DB_OBJ_FULL
							,$result_ele['title']
							,$result_ele['description']
							,$result_ele['ccp_data']
							,getLoggedInUserId()
							,customCurrentDate());

echo $ins;

		$stmt 		= $this->dbHand->prepare($ins);
		$stmt->execute();



	}	

	
}
?>