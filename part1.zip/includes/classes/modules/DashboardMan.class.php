<?php
 /**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */
class DashboardMan  extends DashboardParent
{

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {
		parent::__construct();
	}

	public function getImpactMeasures() {

		$sql = "SELECT * FROM %s.impact_measure
				ORDER BY sort ASC";

		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$impact_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $impact_data;

	}

	public function getNHPData() {

		if ( $this->filter['selected_bu'] ) {

			$bu_list = $this->getAllBUs();

			$sql = "SELECT * FROM %s.actions WHERE moduleName= 'load'";

			$psql = sprintf($sql,_DB_OBJ_FULL);
		} else {
			$sql = "SELECT * FROM %s.actions WHERE moduleName= 'load'";

			$psql = sprintf($sql,_DB_OBJ_FULL);
		}
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result_data;
	}

	public function getData() {

		$bu_list 	= array();
		$hlist 		= array();
		$dlist 		= array();

		$q1_sr 		= $this->qtrsRange['q1_sr'];
		$q1_er		= $this->qtrsRange['q1_er'];
		/*$q11_sr 	= $this->qtrsRange['q11_sr'];
		$q11_er 	= $this->qtrsRange['q11_er'];
		$q12_sr 	= $this->qtrsRange['q12_sr'];
		$q12_er 	= $this->qtrsRange['q12_er'];
		$q13_sr 	= $this->qtrsRange['q13_sr'];
		$q13_er	 	= $this->qtrsRange['q13_er'];*/
		$q2_sr 		= $this->qtrsRange['q2_sr'];
		$q2_er 		= $this->qtrsRange['q2_er'];
		$q3_sr 		= $this->qtrsRange['q3_sr'];
		$q3_er 		= $this->qtrsRange['q3_er'];
		$q4_sr 		= $this->qtrsRange['q4_sr'];
		$q4_er 		= $this->qtrsRange['q4_er'];
		$q5_sr 		= $this->qtrsRange['q5_sr'];
		$q5_er 		= $this->qtrsRange['q5_er'];
		$cqtr		= $this->qtrsRange['cqtr'];

		$impact_measures = $this->getImpactMeasures();

		//if ($impact_measures) {

			//foreach ( $impact_measures as $impact_measure_ele ) {
				//$impact_measure_ele_name = explode("|",$impact_measure_ele['name']);
				//$hlist[$impact_measure_ele['ID']] = trim($impact_measure_ele_name[0]);
			//}
		//}

		$nhp_data_actions = $this->getNHPData();
		//dump_array($nhp_data_actions);
		//exit;
		// Action Object
		$actObj = new Action();
		$nc = array();

		$buObj = SetupGeneric::useModule('organigram');

		//foreach ( $nhp_data as $nhp_data_ele ) {

			//dump_array($nhp_data_actions);

			//if ( $nhp_data_ele['actionsID'] != '' ) {

				//$nhp_data_actions 	= explode(",",$nhp_data_ele['actionsID']);
			

				foreach ( $nhp_data_actions as $nhp_data_action_ele ) {
				
					$buid 				= $nhp_data_action_ele['ID'];
				

				if ( !$buid ) { continue; }

				
				if ( !in_array($buid,$dlist) )
					$dlist[] = $buid;

					if ( $buid != '' ) {

						$actObj->setActionDetails($buid,array());
						$action_data = $actObj->viewAction();
							//dump_array($action_data);
						//$nc[$buid][$problemRiskImpact]['hazards']['D']++;

						//if ( $action_data['approve'] == 1 ) {
						//	$nc[$buid]['actions']['D']++;
						//} else {
						//	$nc[$buid]['actions']['P']++;
						//}
						
						//dump_array($action_data);

					//	switch ($cqtr) {

							//case 1 :
						
							if($action_data['status'] == '1' && $action_data['doneDate']){
							//echo $action_data['dueDate']."---"; 
							if ($action_data['doneDate'] >= $q1_sr && $action_data['doneDate'] <= $q1_er ) {
									//echo $action_data['dueDate']."---"; 
									if ( $action_data['approveAU'] == '0') {
										$nc[$buid]['q1']['P']++;
									} else {
										$nc[$buid]['q1']['D']++;
									}
								} else if ( $action_data['doneDate'] >= $q2_sr && $action_data['doneDate'] <= $q2_er ) {
									if ( $action_data['approveAU'] == '0') {
										$nc[$buid]['q2']['P']++;
									} else {
										$nc[$buid]['q2']['D']++;
									}
								} else if ( $action_data['doneDate'] >= $q3_sr && $action_data['doneDate'] <= $q3_er ) {
									if ($action_data['approveAU'] == '0') {
										$nc[$buid]['q3']['P']++;
									} else {
										$nc[$buid]['q3']['D']++;
									}
								} else if ($action_data['doneDate'] >= $q4_sr && $action_data['doneDate'] <= $q4_er ) {
									if ($action_data['approveAU'] == '0') {
										$nc[$buid]['q4']['P']++;
									} else {
										$nc[$buid]['q4']['D']++;
									}
								} else if ( $action_data['doneDate'] >= $q5_sr && $action_data['doneDate'] <= $q5_er ) {
									if ($action_data['approveAU'] == '0') {
										$nc[$buid]['q5']['P']++;
									} else {
										$nc[$buid]['q5']['D']++;
									}
								} else{
									if ($action_data['doneDate'] < $q1_sr && $action_data['who'] != 0 && $action_data['whoAU'] != 0 &&  $action_data['approveAU'] == '0' &&  ($action_data['doneDate'] =='' || $action_data['doneDate'] = '1900-01-01')) {
										$nc[$buid]['q6']['A']++;
										}
								}
							}else{
							
							if($action_data['status'] == '1'){
							//echo $action_data['dueDate']."---"; 
							if ($action_data['dueDate'] >= $q1_sr && $action_data['dueDate'] <= $q1_er ) {
									//echo $action_data['dueDate']."---"; 
									if ( $action_data['approveAU'] == '0') {
										$nc[$buid]['q1']['P']++;
									} else {
										$nc[$buid]['q1']['D']++;
									}
								} else if ( $action_data['dueDate'] >= $q2_sr && $action_data['dueDate'] <= $q2_er ) {
									if ( $action_data['approveAU'] == '0') {
										$nc[$buid]['q2']['P']++;
									} else {
										$nc[$buid]['q2']['D']++;
									}
								} else if ( $action_data['dueDate'] >= $q3_sr && $action_data['dueDate'] <= $q3_er ) {
									if ($action_data['approveAU'] == '0') {
										$nc[$buid]['q3']['P']++;
									} else {
										$nc[$buid]['q3']['D']++;
									}
								} else if ($action_data['dueDate'] >= $q4_sr && $action_data['dueDate'] <= $q4_er ) {
									if ($action_data['approveAU'] == '0') {
										$nc[$buid]['q4']['P']++;
									} else {
										$nc[$buid]['q4']['D']++;
									}
								} else if ( $action_data['dueDate'] >= $q5_sr && $action_data['dueDate'] <= $q5_er ) {
									if ($action_data['approveAU'] == '0') {
										$nc[$buid]['q5']['P']++;
									} else {
										$nc[$buid]['q5']['D']++;
									}
								} else{
									if ($action_data['dueDate'] < $q1_sr && $action_data['who'] != 0 && $action_data['whoAU'] != 0 &&  $action_data['approveAU'] == '0' &&  ($action_data['doneDate'] =='' || $action_data['doneDate'] = '1900-01-01')) {
										$nc[$buid]['q6']['A']++;
										}
								}
							}
							
							
							}
								
							
					} else {
						continue;
					}

				} // end foreach $nhp_data_action_ele
			//}
		//}

		//dump_array($nc);
		// initialize null records

		/*foreach( $dlist as $d ) {
			//foreach( $hlist as $hk=>$hv ) {

				if ( empty($nc[$d][$hk]['hazards']['D']) )  $nc[$d][$hk]['hazards']['D'] = 0;
				if ( empty($nc[$d][$hk]['actions']['D']) )  $nc[$d][$hk]['actions']['D'] = 0;
				if ( empty($nc[$d][$hk]['actions']['P']) )  $nc[$d][$hk]['actions']['P'] = 0;

				if ( empty($nc[$d][$hk]['q1']['D']) )  $nc[$d][$hk]['q1']['D'] = 0;
				if ( empty($nc[$d][$hk]['q2']['D']) )  $nc[$d][$hk]['q2']['D'] = 0;
				if ( empty($nc[$d][$hk]['q3']['D']) )  $nc[$d][$hk]['q3']['D'] = 0;
				if ( empty($nc[$d][$hk]['q4']['D']) )  $nc[$d][$hk]['q4']['D'] = 0;
				if ( empty($nc[$d][$hk]['q5']['D']) )  $nc[$d][$hk]['q5']['D'] = 0;

				if ( empty($nc[$d][$hk]['q1']['P']) )  $nc[$d][$hk]['q1']['P'] = 0;
				if ( empty($nc[$d][$hk]['q2']['P']) )  $nc[$d][$hk]['q2']['P'] = 0;
				if ( empty($nc[$d][$hk]['q3']['P']) )  $nc[$d][$hk]['q3']['P'] = 0;
				if ( empty($nc[$d][$hk]['q4']['P']) )  $nc[$d][$hk]['q4']['P'] = 0;
				if ( empty($nc[$d][$hk]['q5']['P']) )  $nc[$d][$hk]['q5']['P'] = 0;

				$nc[$d][$hk]['q1']['DUE']	= $nc[$d][$hk]['q1']['D'] + $nc[$d][$hk]['q1']['P'];
				$nc[$d][$hk]['q2']['DUE']	= $nc[$d][$hk]['q2']['D'] + $nc[$d][$hk]['q1']['P'];
				$nc[$d][$hk]['q3']['DUE']	= $nc[$d][$hk]['q3']['D'] + $nc[$d][$hk]['q1']['P'];
				$nc[$d][$hk]['q4']['DUE']	= $nc[$d][$hk]['q4']['D'] + $nc[$d][$hk]['q1']['P'];
				$nc[$d][$hk]['q5']['DUE'] 	= $nc[$d][$hk]['q5']['D'] + $nc[$d][$hk]['q1']['P'];
			//}
		}*/


		//dump_array($ra);

			return array(
				'hlist' => $hlist,
				'dlist' => $dlist,
				'bu_list' => $bu_list,
				'section_data'=>$nc
				);

	}

	public function getGraphData() {

		$grid_data 	= $this->getData();

		$dlist 		= $grid_data['dlist'];
		$hlist 		= $grid_data['hlist'];
		$ra 		= $grid_data['section_data'];

		$graph = array();
		//dump_array($ra);
		foreach( $dlist as $d ) {
			//foreach( $hlist as $hk=>$hv ) {

				/*$ra[$d][$hk]['q1']['P'] = $ra[$d][$hk]['q2']['P'] = $ra[$d][$hk]['q3']['P'] = 10;
				$ra[$d][$hk]['q1']['D'] = $ra[$d][$hk]['q2']['D'] = $ra[$d][$hk]['q3']['D'] = 20;*/

				$graph['q1']['D'] += $ra[$d]['q1']['D'];
				$graph['q2']['D'] += $ra[$d]['q2']['D'];
				$graph['q3']['D'] += $ra[$d]['q3']['D'];
				$graph['q4']['D'] += $ra[$d]['q4']['D'];

				$graph['q5']['D'] += $ra[$d]['q1']['D'] + $ra[$d]['q2']['D'] + $ra[$d]['q3']['D'] + $ra[$d]['q4']['D'];

				$graph['q1']['P'] += $ra[$d]['q1']['P'];
				$graph['q2']['P'] += $ra[$d]['q2']['P'];
				$graph['q3']['P'] += $ra[$d]['q3']['P'];
				$graph['q4']['P'] += $ra[$d]['q4']['P'];

				$graph['q5']['P'] += $ra[$d]['q1']['P'] + $ra[$d]['q2']['P'] + $ra[$d]['q3']['P'] + $ra[$d]['q4']['P'];
				$graph['q6']['A'] += $ra[$d]['q6']['A'];

			//}
		}

		return $graph;
	}
}