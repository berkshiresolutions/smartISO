<?php
 /**
  $Id: InvestigationMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, November 04, 2010 8:32:17 AM>
  */
require_once "Action.class.php";

class ContributorActionExport 
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Investigation Id
	 *@access private
	 */
	private $investigationId;

	/**
	 *Property to hold Investigation Info
	 *@access private
	 */
	private $investigationInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing Investigation object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setInvestigationInfo($p_investigationId,$p_investigationInfo) {

		$this->investigationId		=	$p_investigationId;
		$this->investigationInfo	=	$p_investigationInfo;
	}

	public function getListingforExport() {
 $type = $_GET['type'];
 
 if ($type == "stats")
$data=	 $this->getListingforExport3();
else if ($test== 1)
$data=	 $this->getListingforExport2();
else
$data=		$this->getListingforExport1();
	return $data;	
	}

public function getListingforExport1() {

		//$heading = array(array('section'=>'Section Reference','document'=>'Document','comment'=>'Comment','due'=>'Due Date'));
		$docObj = new Documents();

		$contribObj = new DocumentContributor();
		$documents = $contribObj->viewAssignedDocuments($filter_date);
		$documentsCount = count($documents);
		//dump_array($documents);
		
		if(!empty($documents)){
			
			foreach($documents as $documentItem){
			
			$document_information 	= $docObj->getDocumentInformation($documentItem['cmsdocID']);
			$document_metadata 		= $docObj->getDocumentMetadata($documentItem['cmsdocID']);

			$document_code_info   = $docObj->getSectionByStandardAndCode('52',$document_information['fileReference']);

			$section_ref	= $document_information['fileReference']." ".$document_code_info['name'];
			$document		= '['.$document_information['documentType'].']  '.$document_information['title'].' Ver '.$document_information['versionNew'];

			$comment 		= $documentItem['comments'] == '' ? '-' : smartisoStripslashes($documentItem['comments']);
			$due_date		= format_date($documentItem['contribDueDate']);

			
			$result[$i]['section'] = $section_ref;
			$result[$i]['document'] = $document;
			$result[$i]['comment'] = $comment;
			$result[$i]['due'] = $due_date;
                        $result[$i]['alert'] = $documentItem['alert'];
			$i++;
			
		}
		//$result = array_merge($heading,$result);
		return $result;
			
		}

		
	}
	
	public function getListingforExport2() {

		$heading = array(array('surname'=>'Surname','forename'=>'Forename','title'=>'Title','pass'=>'Passed'));
		
		$contribObj = new DocumentContributor();
		$documents = $contribObj->viewContributorDetails();
		$documentsCount = count($documents);
		//dump_array($documents);
		
		if(!empty($documents)){
			
			foreach($documents as $documentItem){
			
			$document_information 	= $docObj->getDocumentInformation($documentItem['cmsdocID']);
			$document_metadata 		= $docObj->getDocumentMetadata($documentItem['cmsdocID']);

			$document_code_info   = $docObj->getSectionByStandardAndCode('11',$document_information['fileReference']);

			$section_ref	= $document_information['fileReference']." ".$document_code_info['name'];
			$document		= '['.$document_information['documentType'].']&nbsp;&nbsp;<a href="/documents/download.php?src='.$document_information['documentID'].'&name='.$document_information['title'].'">'.$document_information['title'].'</a> Ver <a href="javascript:void(0)">'.$document_information['versionNew'].'</a>';

			$comment 		= $documentItem['comments'] == '' ? '-' : smartisoStripslashes($documentItem['comments']);
			$due_date		= format_date($documentItem['contribDueDate']);

			
			$result[$i]['section'] = $section_ref;
			$result[$i]['document'] = $document;
			$result[$i]['comment'] = $comment;
			$result[$i]['due'] = $due_date;
                         $result[$i]['alert'] = $documentItem['alert'];
			$i++;
			
		}
		$result = array_merge($heading,$result);
		return $result;
			
		}

		
	}
        	public function getListingforExport3() {

		$heading = array(array('surname'=>'Surname','forename'=>'Forename','ref'=>'Reference','title'=>'Title','duee'=>'Date','pass'=>'Passed'));
		
		$contribObj = new DocumentContributor();
		$data = $contribObj->getExportDetails();

                $passArr=array(0=>"No Contribution",1=>"Passed",2=>"Rejected",3=>"Cancelled by User");
		if(!empty($data)){
			$i=0;
			foreach($data as $documentItem){
			
			$due_date		= format_date($documentItem['date']);


			$result[$i]['surname'] = $documentItem['surname'];
			$result[$i]['forename'] = $documentItem['forename'];
			$result[$i]['ref'] = $documentItem['fileReference'];
                        $result[$i]['title'] = $documentItem['title'];
			$result[$i]['due'] = $due_date;
                         $result[$i]['alert'] = $documentItem['alert'];
            $result[$i]['pass'] = $passArr[$documentItem['passed']];
			$i++;
			
		}
		$resultset = array_merge($heading,$result);

		return $resultset;
			
		}

		
	}
}
?>