<?php
 /**
  $Id: Equipment.int.php,v 3.05 Saturday, October 09, 2010 10:39:36 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage an equipment object
  *
  * This interface will declare the various methods performed
  * by an equipment object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface EquipmentInterface
{
	/*
	 * to set equipment information for performing various operations with an equipment object
	 */
	public function setEquipmentInfo($p_dseAssessmentId,$p_dseAssessmentInfo);


	/*
	 * This method is used to view an equipment information.
	 */
	public function viewEquipment();

	/*
	 * This method is used to edit an equipment
	 */
	public function editEquipment();

}