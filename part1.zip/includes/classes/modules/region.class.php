<?php


class Region {

   /**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;


	/**
	 * Constructor for initializing Vehicle object
	 * @access public
	 */
	public function __construct() {
	 
$this->dbHand 			= DB::connect(_DB_TYPE);

	}

	public function getItems() {
	
		$sql = sprintf("SELECT * FROM %s.regions order by country" ,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach($result as $res)
			$data[$res["ID"]]=$res["Country"];
		
		return $data;
	}
	
	public function getSelectedItems($p_selected) {
	
		$sql = sprintf("SELECT * FROM %s.regions where ID in(%s) order by country" ,_DB_OBJ_FULL,$p_selected);
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach($result as $res)
			$dataStr.=$res["Country"].", ";
		
		return trim($dataStr,", ");
	}
        	public function getItemsbyId($p_id) {
	
		$sql = sprintf("SELECT * FROM %s.regions where ID = %d " ,_DB_OBJ_FULL,$p_id);
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		
		return $result;
	}
}

?>
