<?php
 /**
  $Id: ActionTrackerNonconformanceInc.class.php,v 3.51 Wednesday, January 26, 2011 5:58:26 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerNonconformanceInc extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;

	public function getPendingMeActions() {

		$this->sql_query = sprintf("SELECT * FROM %s.perform_daily_inspection
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}
//exit;
	public function getCompletedMeActions() {

		$this->sql_query = sprintf("SELECT * FROM %s.perform_daily_inspection
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getPendingOtherActions() {

		$this->sql_query = sprintf("SELECT * FROM %s.perform_daily_inspection
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedOtherActions() {

		$this->sql_query = sprintf("SELECT * FROM %s.perform_daily_inspection
							WHERE actionID IS NOT NULL
							ORDER BY ID DESC",_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	private function getActionsByFilter($p_callingMethod) {

		$USER_ID = getLoggedInUserId();

		$p_callingMethod_arr 	= explode('::',$p_callingMethod);
		$calling_method 		= $p_callingMethod_arr[1];
		//echo $calling_method;
		//echo $this->sql_query;

		$pStatement = $this->dbHand->prepare($this->sql_query);
		$pStatement->execute();

		$result 				=  $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$this->new_resultset 	= array();

		$organoObj = SetupGeneric::useModule('Organigram');

		if ( $result ) {
			foreach ( $result as $result_element ) {

				if ( $result_element['actionID'] != '' ) {

					$actions_arr = explode(',',$result_element['actionID']);

					foreach ( $actions_arr as $actions_ele ) {

						$organoObj->setItemInfo(array('id'=>$result_element['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();

						$this->new_resultset[$actions_ele] = array('uniqueReference'=>$result_element['uniqueReference']
																  );
					}

				}
			}
		}

		$organoObj = null;

		$module_info = array();

		//echo $calling_method;

		if ($this->moduleInfo) {

			$participantObj = SetupGeneric::useModule('participant');

			foreach ( $this->moduleInfo as $module_element ) {

				$participantObj->setItemInfo(array('id'=>$module_element['who']));
				$participant_arr 				= $participantObj->displayItemMaininfoById();
				$module_element['who_name'] 	= $participant_arr['forename'].' '.$participant_arr['surname'];

				$module_element['approveAU'] = (int) $module_element['approveAU'];

				if ( $calling_method == 'getPendingMeActions' ) {

					if ( $USER_ID == $module_element['who']  && $module_element['approveAU']==0 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				if ( $USER_ID == $module_element['whoAU']  && $module_element['approveAU']==0 && $module_element['doneDescription']  ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getPendingOtherActions' ) {

					if (  $module_element['approveAU']==0 && ( $USER_ID != $module_element['who'] && $module_element['who'] != 0) ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedMeActions' ) {

					if ( ( $USER_ID == $module_element['who'] ) && $module_element['approveAU']==1 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedOtherActions' ) {

					if ( $USER_ID != $module_element['who'] && $module_element['who'] != 0 && $module_element['approveAU']==1 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				}
			}
		}

		//dump_array($module_info);

		ksort($module_info);
		$module_info = array_reverse($module_info,true);
		ksort($this->new_resultset);

		array_walk($module_info,array($this,'combine_actions_with_data'));

		return $module_info;

	}

	private function combine_actions_with_data($item,$key) {

		$item['reference'] 		= $this->new_resultset[$key]['reference'];
        $item['buID'] 			= $this->new_resultset[$key]['buID'];
		$item['buName'] 		= $this->new_resultset[$key]['buName'];
	}
}