<?php
 /**
  $Id: Action.class.php,v 3.84 Saturday, January 29, 2011 5:04:35 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, October 07, 2010 12:46:05 PM>
  */

class ActionEditTriggers
{

	/**
	 * Property to hold Action Id
	 * @access private
	 */
	private $actionId;

	/**
	 * Property to hold record Id
	 * @access private
	 */
	private $contextRecordId;

	private $moduleName;

	private $details;

	const _MethodVoidAction = 'VoidAction';
	const _MethodVoidActionAu = 'VoidActionAU';
	const _MethodModifiedAction = 'ModifiedAction';
	const _MethodPlain = ''; // left blank intentionally for plain action


	/**
	 * Constructor for initializing Action object
	 * @access public
	 */
	public function __construct() {
		// do nothing
	}

	public function setActionTriggerDetails($p_module,$p_actionId,$p_recordId,$p_actionInfo) {

		$this->moduleName 		= $p_module;
		$this->details 			= $p_actionInfo;
		$this->actionId			= (int) $p_actionId;
		$this->contextRecordId 	= (int) $p_recordId;

		// get action information
		$actionHandler = new Action();
		$actionHandler->setActionDetails($this->actionId,$this->actionData);
		$action_info = $actionHandler->viewAction();
		
		
		$actionHandler = null;

		$this->details['old_who'] 	= $action_info['who'];
		$this->details['old_whoAU'] = $action_info['whoAU'];
	}

	public function beforeUpdateTrigger() {

		// execute this block if who has been changed
		if ( $this->details['old_who'] != $this->details['new_who'] ) {
		 
	         
			$objAlert = new SendActionAlerts($this->moduleName.self::_MethodVoidAction,$this->contextRecordId);
			$objAlert->sendAlerts();
			$objAlert = null;
		}
		

		// execute this block if who AU responsible has been changed
		if ( $this->details['old_whoAU'] != $this->details['new_whoAU'] ) {
		
			$objAlert = new SendActionAlerts($this->moduleName.self::_MethodVoidActionAu,$this->contextRecordId);
			$objAlert->sendAlerts();
			$objAlert = null;
		}
	

	}

	public function afterUpdateTrigger() {
        
		// execute this block if who and who AU responsible are not changed but action information has been changed
		if ( $this->details['old_who'] == $this->details['new_who'] && $this->details['old_whoAU'] == $this->details['new_whoAU'] ) {
		
			$objAlert = new SendActionAlerts($this->moduleName.self::_MethodModifiedAction,$this->contextRecordId);
			$objAlert->sendAlerts();
			$objAlert = null;
		}

		// execute this block if either who and who AU responsible are changed
	if ( $this->details['old_who'] != $this->details['new_who'] || $this->details['old_whoAU'] != $this->details['new_whoAU'] ) {
	

			$objAlert = new SendActionAlerts($this->moduleName.self::_MethodPlain,$this->contextRecordId);
			$objAlert->sendAlerts();
			$objAlert = null;
		}
		
	}


}
?>