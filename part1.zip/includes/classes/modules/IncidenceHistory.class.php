<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class IncidenceHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'incidence';
		$this->tables[] 		= 'incidence_participants';
		$this->tables[]			= 'incidence_witness';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _incidence() {

		$tablename 				= 'incidence';
		$tablename_historical 	= $tablename.'_historical';

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (
						ID
						,reference
						,uniqueReference
						,incidenceDateTime
						,locID
						,buID
						,isParticipant
						,participantSurname
						,participantForename
						,participantWorksNumber
						,participantShiftWork
						,participantGender
						,activityTreatment
						,activityImpact
						,activityAccident
						,activityPartBody
						,activityNatureInjury
						,activityHazardClass
						,activityHazards
						,activityFactor
						,noWitness
						,problemDescription
						,problemDetailedInvestigation
						,uploadFilesID
						,actionsID
						,processID
						,isRiskValid
						,archive
						,status
						,whoID
						,driverTest
						,instructor
						,rtwDate
						,absentDays
						,noActionReason
						,noAction
						,accidentReportable
						,noInvestigationReqReason
						,subReference
					   )
						SELECT
						ID
						,reference
						,uniqueReference
						,incidenceDateTime
						,locID
						,buID
						,isParticipant
						,participantSurname
						,participantForename
						,participantWorksNumber
						,participantShiftWork
						,participantGender
						,activityTreatment
						,activityImpact
						,activityAccident
						,activityPartBody
						,activityNatureInjury
						,activityHazardClass
						,activityHazards
						,activityFactor
						,noWitness
						,problemDescription
						,problemDetailedInvestigation
						,uploadFilesID
						,actionsID
						,processID
						,isRiskValid
						,archive
						,status
						,whoID
						,driverTest
						,instructor
						,rtwDate
						,absentDays
						,noActionReason
						,noAction
						,accidentReportable
						,noInvestigationReqReason
						,subReference
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$sql = sprintf("SELECT subReference FROM %s.incidence
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$this->subReference = $pStatement->fetchColumn();

		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
	}

	private function _incidence_participants() {

		$tablename 				= 'incidence_participants';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from incidence_participants
		 */
		$sql = sprintf("SELECT * FROM %s.".$tablename."
						WHERE incID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$participant_data = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( !empty($participant_data) ) {

			$sql = sprintf("INSERT INTO %s.".$tablename_historical."
						   (
							ID
							,incID
							,isParticipant
							,surname
							,forename
							,worksNumber
							,daysAbsent
							,shiftWork
							,gender
							,subReference
						   ) VALUES (%d,%d,'%s','%s','%s','%s','%d','%s','%s',%d)",
							_DB_OBJ_FULL,
							$participant_data['ID'],
							$participant_data['incID'],
							$participant_data['isParticipant'],
							$participant_data['surname'],
							$participant_data['forename'],
							$participant_data['worksNumber'],
							$participant_data['daysAbsent'],
							$participant_data['shiftWork'],
							$participant_data['gender'],
							$this->subReference);

			$pStatement2 = $this->dbHand->prepare($sql);
			$pStatement2->execute();
		}
	}

	private function _incidence_witness() {

		$tablename 				= 'incidence_witness';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from incidence_witness
		 */
		$sql = sprintf("SELECT * FROM %s.".$tablename."
						WHERE incID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$witness_data = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( !empty($witness_data) ) {

			$sql = sprintf("INSERT INTO %s.".$tablename_historical."
						   (
							ID
							,incID
							,isParticipant
							,surname
							,forename
							,worksNumber
							,emailAddress
							,telephone
							,description
							,subReference
						   ) VALUES (%d,%d,'%s','%s','%s','%s','%s','%s','%s',%d)",
							_DB_OBJ_FULL,
							$witness_data['ID'],
							$witness_data['incID'],
							$witness_data['isParticipant'],
							$witness_data['surname'],
							$witness_data['forename'],
							$witness_data['worksNumber'],
							$witness_data['emailAddress'],
							$witness_data['telephone'],
							$witness_data['description'],
							$this->subReference);

			$pStatement2 = $this->dbHand->prepare($sql);
			$pStatement2->execute();
		}
	}
}
?>