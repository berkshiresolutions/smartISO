<?php
 /**
  $Id: DocumentAlert.class.php,v 3.68 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This object define the various operations related with Document Alert object
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Document
  * @since  Saturday, September 11, 2010 2:16:06 PM>
  */

class DocumentAlert
{
	/*
	 * This method is used to set information to perform various operations.
	 *
	 * @param $p_alertId integer	Unique alert id
	 * @param $p_alertInfo array	Alert information to be used by obect to perform crud operations
	 *
	 * @access public
	 */
	public function setAlertInfo($p_alertId,$p_alertInfo) {

	}

	/*
	 * This method is used to add an alert.
	 *
	 * @access public
	 */
	public function addAlert() {

	}

	/*
	 * This method is used to edit an alert
	 *
	 * @access public
	 */
	public function editAlert() {

	}

	/*
	 * This method is used to delete an alert
	 *
	 * @access public
	 */
	public function deleteAlert() {

	}
}
?>