<?php

/**
  $Id: Comm.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, October 09, 2010 12:50:41 PM>
 */
require "Reporting.int.php";


class TrainingReport implements ReportingInterface {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Comm Id
     * @access private
     */
    private $rptId;

    /**
     * Property to hold Comm Info
     * @access private
     */
    private $rptInfo;

    /**
     * Constructor for initializing Manual Handling object
     * @access public
     */
    public function __construct() {

       
$this->dbHand 			= DB::connect(_DB_TYPE);
      
    }

    /**
     * to set comm information for performing various operations with the comm object
     * @param integer This parameter holds the comm Id
     * @param array This parameter holds the the comm Info
     */
    public function setRptInfo($p_rptId, $p_rptInfo) {

        $this->rptId = $p_rptId;
        $this->rptInfo = $p_rptInfo;
    }

    public function addReport() {

      $sql = sprintf("INSERT INTO %s.context ( reference,uniqueReference, title,descp,bu
										)
										VALUES ( '%s','%s','%s','%s','%s') ", _DB_OBJ_FULL, $this->questInfo['reference'], $this->questInfo['uniqueref'], $this->questInfo['title'], $this->questInfo['description'], $this->questInfo['bu']
        );

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();

        $this->rptId = customLastInsertId($this->dbHand, 'context', 'ID');

        return $this->rptId;
    }

    /*
     * This method is used to view comm information.
     */

    public function viewReport($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.context WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    /*
     * This method is used to edit a comm
     */

    public function editReport($id) {

       $sql = sprintf("UPDATE %s.context set title='%s',descp='%s',bu='%s'
										where id=%d
										", _DB_OBJ_FULL, $this->questInfo['title'], $this->questInfo['description'], $this->questInfo['bu'], $id
        );

        $pStatement = $this->dbHand->prepare($sql);



        $pStatement->execute();
    }

    public function viewAll($type) {

       $sql = sprintf("SELECT * FROM %s.context  where isnull(complete,0)=0 and isnull(archive,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
	    public function viewAllArchived($type) {

     $sql = sprintf("SELECT * FROM %s.context  where isnull(complete,0)=0 and archive=1 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }


	
    public function lastrecordId() {
        return $this->rptId;
    }

    public function archiveRecord() {
	
	$sql = sprintf("UPDATE %s.context SET archive = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->questId);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

	}

    public function restoreRecord() {
       	$sql = sprintf("UPDATE %s.context SET archive = '0' WHERE ID = %d ",_DB_OBJ_FULL,$this->questId);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute(); 
    }






    
          

}

?>