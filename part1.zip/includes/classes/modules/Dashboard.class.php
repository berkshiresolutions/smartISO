<?php
 /**
  $Id: Dashboard.class.php,v 3.13 Wednesday, January 26, 2011 10:53:10 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Dashboard Class
  * @since  Tuesday, January 25, 2011 1:04:56 PM>
  */



class Dashboard
{
	private $result;
	protected $moduleInfo;
	private $gridType;
	private $modObj;
	private $qtrsRange;
	private $rangeType;

	/**
	 * Constructor for initializing Dashboard Object
	 * @access public
	 */
	public function __construct() {

	}

	public function setGridType($p_gridType) {

		$this->gridType = $p_gridType;
		self::getInstance();
	}

	public function setBlockRange($p_rangeType) {

		$this->rangeType = $p_rangeType;

		switch ($this->rangeType) {
			case 'Q': $range = getQuarterRanges(); break;
			case 'M': $range = getMonthRanges(); break;
			case 'W': $range = getWeekRanges(); break;
		}

		$p_range = array(
			'q1_sr'=>$range['C'.$this->rangeType]['srd'],
			'q1_er'=>$range['C'.$this->rangeType]['erd'],
			'q2_sr'=>$range[$this->rangeType.'1']['srd'],
			'q2_er'=>$range[$this->rangeType.'1']['erd'],
			'q3_sr'=>$range[$this->rangeType.'2']['srd'],
			'q3_er'=>$range[$this->rangeType.'2']['erd'],
			'q4_sr'=>$range[$this->rangeType.'3']['srd'],
			'q4_er'=>$range[$this->rangeType.'3']['erd'],
			'q5_sr'=>$range[$this->rangeType.'4']['srd'],
			'q5_er'=>$range[$this->rangeType.'4']['erd'],
			);

		$this->qtrsRange = $p_range;
	}

	public function getBlockLabel($p_id) {

		switch ($this->rangeType) {
			case 'Q': $range = getQuarterRanges(); break;
			case 'M': $range = getMonthRanges(); break;
			case 'W': $range = getWeekRanges(); break;
		}

		switch ($p_id) {
			case 1: return $range['C'.$this->rangeType]['label']; break;
			case 2: return $range[$this->rangeType.'1']['label']; break;
			case 3: return $range[$this->rangeType.'2']['label']; break;
			case 4: return $range[$this->rangeType.'3']['label']; break;
			case 5: return $range[$this->rangeType.'4']['label']; break;
		}
	}

	public function getInstance() {

		$name_exp = explode("_",$this->gridType);

		array_walk($name_exp,array($this,'capitalcase'));
		$this->gridType = implode('',$name_exp);

		$objname = 'Dashboard'.$this->gridType;
		$this->modObj = new $objname();
	}

	public function capitalcase($p_item,$p_key) {
		$p_item = ucfirst($p_item);
	}

	public function getData() {

		$this->modObj->setBlockRange($this->qtrsRange);
		return $this->modObj->getData();
	}
}

?>