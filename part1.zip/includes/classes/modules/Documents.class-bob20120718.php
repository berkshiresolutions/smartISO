<?php
 /**
  $Id: Documents.class.php,v 9.67 Monday, January 31, 2011 9:54:24 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Manage Document object
  *
  * This class will define the various methods performed
  * by document object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Friday, September 10, 2010 8:17:06 PM>
  */
require_once "Documents.int.php";

class Documents implements DocumentsInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	private $xmlobj;

	private $xmlDocumentName;

	private $documentInformation;
	private $documentId;
	private $participantObj;
	private $fileObj;
	private $logged_user_name;

	/**
	 * Constructor for initializing Dse Assessment object
	 * @access public
	 */
	public function __construct() {
		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->xmlDocumentName	= 'documents.xml';

		$this->participantObj	= 		SetupGeneric::useModule('Participant');
		$this->fileObj	= new Upload();
		$this->logged_user_name = Session::getSessionField('SESS_FULLNAME');
	}

	/**
	 * This method is used to set document information before uploading and edit operation.
	 */
	public function setDocumentInfo($p_doc_info) {
		$this->documentInformation = $p_doc_info;
	}

	/**
	 * This method is used to upload the document
	 */
	public function uploadDocument($p_recordSep=0) {

		$p_recordSep_org = $p_recordSep;

		try {

			$this->uploadDocumentFile();

			$standard_id 		= 11;

			if ( $this->documentInformation['gap_document'] ) {
				$is_gap_document 	= 1;
			} else {
				$is_gap_document 	= 0;
			}

			$default_status 	= 'U';

			$optObj				= new Option();
			$version_type 		= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

			if ( $version_type == 'version' ) {
				$version_type 	= 'V';
			} else if ( $version_type == 'revision' ) {
				$version_type 	= 'R';
			} else {
				$version_type 	= 'M';
			}

			$optObj				= null;

			/*$stmt->bindParam(1,$this->documentId);
			$stmt->bindParam(2,$this->documentInformation['version']);
			$stmt->bindParam(3,$this->documentInformation['file_reference']);
			$stmt->bindParam(4,$this->documentInformation['document_name']);
			$stmt->bindParam(5,$this->documentInformation['document_description']);
			$stmt->bindParam(6,$this->documentInformation['document_type']);
			$stmt->bindParam(7,$this->documentInformation['check_document']);
			$stmt->bindParam(8,$this->documentInformation['date_initiated']);
			$stmt->bindParam(9,$this->documentInformation['initiated_by']);
			$stmt->bindParam(10,$this->documentInformation['action_summary']);
			$stmt->bindParam(11,$this->documentInformation['pages']);
			$stmt->bindParam(12,$standard_id);
			$stmt->bindParam(13,$this->documentInformation['business_unit']);
			$stmt->bindParam(14,$is_gap_document);
			$stmt->bindParam(15,$default_status);
			$stmt->bindParam(16,$this->documentInformation['document_class']);
			$stmt->bindParam(17,$version_type);*/

			if ( $this->documentInformation['version_old'] == '' ) {
				$this->documentInformation['version_old'] = '-';
			}

			if ( $p_recordSep == 0 ) {

				if ( _DB_TYPE == 'mssql' ) {
					$sql = sprintf("SELECT TOP 1 recordSep FROM %s.cms_documents
							   WHERE fileReference LIKE '%s'
							   ORDER BY recordSep DESC",_DB_OBJ_FULL,$this->documentInformation['file_reference']);
				} else {
					$sql = sprintf("SELECT recordSep FROM %s.cms_documents
							   WHERE fileReference LIKE '%s'
							   ORDER BY recordSep DESC LIMIT 1",_DB_OBJ_FULL,$this->documentInformation['file_reference']);
				}


				$stmt = $this->dbHand->prepare($sql);

				$stmt->execute();
				$record_sep_result = $stmt->fetch(PDO::FETCH_ASSOC);
				$p_recordSep = $record_sep_result['recordSep'] + 1;
			}

			$sql = sprintf("INSERT INTO %s.cms_documents (documentID,versionOld,versionNew,fileReference,title,description,
					documentType,documentSubType,dateInitiated,initiatedByParticipant,actionSummary,pages,
					standardID,buID,isGapDocument,status,classification,docControl,versionMinor,isArchive, reasonForUpdate, recordSep)
					VALUES (%d,'%s', '%s' ,'%s' ,'%s' ,'%s', '%s', '%s', '%s', %d, '%s', %d, %d, %d, %d, '%s', '%s', '%s','%s',%d,'%s',%d)"
					,_DB_OBJ_FULL
					,$this->documentId
					,$this->documentInformation['version_old']
					,$this->documentInformation['version']
					,$this->documentInformation['file_reference']
					,$this->documentInformation['document_name']
					,$this->documentInformation['document_description']
					,$this->documentInformation['document_type']
					,$this->documentInformation['check_document']
					,$this->documentInformation['date_initiated']
					,$this->documentInformation['initiated_by']
					,$this->documentInformation['action_summary']
					,$this->documentInformation['pages']
					,$standard_id
					,$this->documentInformation['business_unit']
					,$is_gap_document
					,$default_status
					,$this->documentInformation['document_class']
					,$version_type
					,$this->documentInformation['version_minor']
					,0
					,$this->documentInformation['reason_for_update']
					,$p_recordSep);

			$stmt = $this->dbHand->prepare($sql);

			$stmt->execute();

			$last_insert_id 	= customLastInsertId( $this->dbHand,'cms_documents','cmsdocID');

			$versionComment		= '';
			$allocatedTo		= 0;
			$gapDocID			= (int) $this->documentInformation['doc_id'];
			$authorizerComment 	= '';
			$uploadedBy 		= 0;
			$dateApproved 		= '1900-01-01';
			$approvedBy 		= 0;

			$sql_sec = sprintf("INSERT INTO %s.cms_documents_metadata
					(cmsdocID,versionComment,allocatedTo,gapDocID,authorizerComment,uploadedBy,dateApproved,approvedBy)
					VALUES (%d, '%s', %d, %d, '%s', %d, '%s', %d)"
					,_DB_OBJ_FULL
					,$last_insert_id
					,$versionComment
					,$allocatedTo
					,$gapDocID
					,$authorizerComment
					,$uploadedBy
					,$dateApproved
					,$approvedBy);

			$stmt_sec = $this->dbHand->prepare($sql_sec);

			/*$stmt_sec->bindParam(1,$last_insert_id);
			$stmt_sec->bindParam(2,$versionComment);
			$stmt_sec->bindParam(3,$allocatedTo);
			$stmt_sec->bindParam(4,$gapDocID);
			$stmt_sec->bindParam(5,$authorizerComment);
			$stmt_sec->bindParam(6,$uploadedBy);
			$stmt_sec->bindParam(7,$dateApproved);
			$stmt_sec->bindParam(8,$approvedBy);*/

			$stmt_sec->execute();

			//$this->addDocReplicateInfo($last_insert_id);
			/*if ( $p_recordSep == 0 ) {
				$message = "Document Replaced '".$this->documentInformation['document_name']."' for ".$this->documentInformation['file_reference']." - ".$this->documentInformation['document_name']." by ".$this->logged_user_name;
			} else {*/
				//$message = "Uploaded document '".$this->documentInformation['document_name']."' for ".$this->documentInformation['file_reference']." - ".$this->documentInformation['document_name']." by ".$this->logged_user_name;
			//}

			if ( $p_recordSep_org == 0 ) {
				$message = "Uploaded document '".$this->documentInformation['document_name']."' for ".$this->documentInformation['file_reference']." - ".$this->documentInformation['document_name']." by ".$this->logged_user_name;
				$this->saveDocumentLog($this->documentId,$message);
			}



			return $this->documentId;

		} catch ( ErrorException $e ) {
			$objFile = null;
			throw new ErrorException('Invalid File format',11);
		}
	}

	/**
	 * This method is used to upload the document
	 */
	public function replaceDocument() {

		$document_information 	= $this->getDocumentInformation($this->documentInformation['doc_id']);

		$this->uploadDocument($document_information['recordSep']);

		/*$old_document_id 		= $document_information['documentID'];
		$cms_document_id		= $document_information['cmsdocID'];

		$sql = sprintf("UPDATE %s.cms_documents
				SET isArchive = 1
				WHERE documentID = %d
				AND cmsdocID = %d
				AND recordSep = %d"
				,_DB_OBJ_FULL
				,$old_document_id
				,$cms_document_id
				,$document_information['recordSep']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();*/

		$message = "Document Replaced '".$this->documentInformation['document_name']."' for ".$this->documentInformation['file_reference']." - ".$this->documentInformation['document_name']." by ".$this->logged_user_name;

		$this->saveDocumentLog($this->documentInformation['doc_id'],$message);
	}

	/**
	 * This method is used to upload the document
	 */
	public function replaceDocumentDeprecated() {

		$document_information 	= $this->getDocumentInformation($this->documentInformation['doc_id']);
		//dump_array_and_exit($document_information);
		$old_document_id 		= $document_information['documentID'];

		//$this->removeDocumentFile($old_document_id);
		$this->updDocReplaceInfo($this->documentInformation['doc_id'],$old_document_id,'0',true);
		$this->uploadDocumentFile();

		$sql_sec = sprintf("UPDATE %s.cms_documents_metadata
				SET versionComment = ?
				WHERE cmsdocID = ?",_DB_OBJ_FULL,$this->documentInformation['version_notes'],$this->documentInformation['doc_id']);


		$stmt_sec = $this->dbHand->prepare($sql_sec);

		$standard_id 		= 11;
		$is_gap_document 	= 0;
		$default_status 	= 'U';

		$optObj				= new Option();
		$version_type 		= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

		if ( $version_type == 'version' ) {
			$version_type 	= 'V';
		} else {
			$version_type 	= 'R';
		}

		$optObj				= null;

		$sql = sprintf("UPDATE %s.cms_documents
				SET documentID = %d,
					versionOld = '%s',
					versionNew = '%s',
					pages = %d,
					buID = %d,
					classification = '%s',
					docControl = '%s',
					versionMinor = '%s'
				WHERE cmsdocID = '%s'"
				,_DB_OBJ_FULL
				,$this->documentId
				,$this->documentInformation['version_old']
				,$this->documentInformation['version_new']
				,$this->documentInformation['pages']
				,$this->documentInformation['business_unit']
				,$this->documentInformation['document_class']
				,$version_type
				,$this->documentInformation['version_minor']
				,$this->documentInformation['doc_id']);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->documentId);
		$stmt->bindParam(2,$this->documentInformation['version_old']);
		$stmt->bindParam(3,$this->documentInformation['version_new']);
		$stmt->bindParam(4,$this->documentInformation['pages']);
		$stmt->bindParam(5,$this->documentInformation['business_unit']);
		$stmt->bindParam(6,$this->documentInformation['document_class']);
		$stmt->bindParam(7,$version_type);
		$stmt->bindParam(8,$this->documentInformation['doc_id']);*/

		$stmt->execute();

		/*$stmt_sec->bindParam(1,$this->documentInformation['version_notes']);
		$stmt_sec->bindParam(2,$this->documentInformation['doc_id']);*/
		$stmt_sec->execute();

		$this->addDocReplicateInfo($this->documentInformation['doc_id']); // add new uploaded file details
	}

	private function deleteDocumentAlldata($p_document_id) {

		$tables = array('cms_documents','cms_documents_metadata','cms_document_alerts');

		foreach ( $tables as $table ) {

			$del = sprintf("DELETE FROM %s.".$table."
					WHERE cmsdocID = %d",_DB_OBJ_FULL,$p_document_id);

			$stmt = $this->dbHand->prepare($del);
			/*$stmt->bindParam(1,$p_document_id);*/
			$stmt->execute();
		}


		// Document has  by Claire Boulley.
	}

	private function uploadDocumentFile() {

		$objFile = new Upload();

		$this->documentInformation['file_info']['destination'] = 'documents';

		$objFile->setFileInfo($this->documentInformation['file_info']['destination'],$this->documentInformation['file_info']);

		try {
			$objFile->add_file();
			$this->documentId = $objFile->getLastFileId();
			$objFile = null;

		} catch ( ErrorException $e ) {

			$objFile = null;
			throw new ErrorException('Invalid File format',11);
		}

	}

	private function removeDocumentFile($p_file_id) {

		$p_file_id = (int) $p_file_id;

		$objFile = new Upload();

		$objFile->setFileInfo('documents',array('id'=>$p_file_id,'destination'=>'documents'));
		$objFile->delete_file();

		$objFile = null;
	}

	/**
	 * This method is used to delete the document.
	 */
	public function deleteDocument($p_doc_id,$p_reject=false) {

		$p_doc_id = (int) $p_doc_id;

		$document_information = $this->getDocumentInformation($p_doc_id);
		$this->removeDocumentFile($document_information['documentID']);
		$this->deleteDocumentAlldata($p_doc_id);

		if ( $p_reject ) {
			$message = "Document has been rejected by ".$this->logged_user_name;
		} else {
			$message = "Document has been deleted by ".$this->logged_user_name;
		}

		$this->saveDocumentLog($p_doc_id,$message);
	}

	public function authorizeDocument($p_document_id,$p_date_approved,$p_approved_by) {

		$sql = sprintf("UPDATE %s.cms_documents
				SET status = 'A'
				WHERE cmsdocID = %d",_DB_OBJ_FULL,$p_document_id);

		$sql_sec = sprintf("UPDATE %s.cms_documents_metadata
				SET dateApproved = '%s',
				approvedBy = %d
				WHERE cmsdocID = %d"
				,_DB_OBJ_FULL
				,format_date_for_mysql($p_date_approved)
				,$p_approved_by
				,$p_document_id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt_sec = $this->dbHand->prepare($sql_sec);

		/*$stmt->bindParam(1,$p_document_id,PDO::PARAM_INT);*/

		/*$stmt_sec->bindParam(1,format_date_for_mysql($p_date_approved));
		$stmt_sec->bindParam(2,$p_approved_by);
		$stmt_sec->bindParam(3,$p_document_id);*/

		$stmt->execute();
		$stmt_sec->execute();

		$document_information 	= $this->getDocumentInformation($p_document_id);

		$sql = sprintf("UPDATE %s.cms_documents
				SET isArchive = 1
				WHERE cmsdocID != %d
				AND fileReference LIKE '%s'
				AND recordSep = %d"
				,_DB_OBJ_FULL
				,$p_document_id
				,$document_information['fileReference']
				,$document_information['recordSep']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$participantObj	 = SetupGeneric::useModule('Participant');
		$participantObj->setItemInfo(array('id'=>$p_approved_by));
		$partcipantData = $participantObj->displayItemById();

		$contributor_name = $partcipantData['forename'].' '.$partcipantData['surname'];

		$message = "Document has been authorised by ".$contributor_name;
		$this->saveDocumentLog($p_document_id,$message);
		$participantObj = null;
	}

	/**
	 * This method is used to view already uploaded document.
	 */
	public function viewDocument($p_doc_id) {}

	/**
	 * This method is used to list all the alerts related with the document
	 */
	public function listDocumentAlerts() {}

	/**
	 * This method is used to view the document alert details.
	 */
	public function viewDocumentAlertDetails() {}

	/**
	 * This method is used to store the agreement of alert raised by others
	 */
	public function agreeDocumentAlert() {

		$sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				alertStatus = 'A',
				reply = '%s'
				WHERE alertID = %d",_DB_OBJ_FULL,$this->documentInformation['docissuer_comment'],$this->documentInformation['alert_id']);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->documentInformation['docissuer_comment']);
		$stmt->bindParam(2,$this->documentInformation['alert_id']);*/

		$stmt->execute();
	}

	/**
	 * This method is used to store the disagreement of alert raised by others
	 */
	public function disagreeDocumentAlert() {

		$sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				alertStatus = 'D',
				reply = '%s'
				WHERE alertID = %d",_DB_OBJ_FULL,$this->documentInformation['docissuer_comment'],$this->documentInformation['alert_id']);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->documentInformation['docissuer_comment']);
		$stmt->bindParam(2,$this->documentInformation['alert_id']);*/

		$stmt->execute();

	}

	/**
	 * This method is used to view document history
	 */
	public function viewDocumentHistory() {}

	/**
	 * This method is used to raise new alert for document.
	 */
	public function raiseDocumentAlert() {

		if ( $this->documentInformation['file_info']['name'] != '' ) {
			$this->uploadDocumentFile();
		} else {
			$this->documentId = 0;
		}

		$this->documentInformation['alert_raised_by'] = getLoggedInUserId();
		$alert_status 	= 'N';
		$reply			= '';

		$sql = sprintf("INSERT INTO %s.cms_document_alerts(cmsdocID,alertRaisedBy,alertComment,documentID,alertWhen,alertStatus,reply)
				VALUES(%d, %d,'%s',%d,".customCurrentDate().",'%s','%s')"
				,_DB_OBJ_FULL
				,$this->documentInformation['doc_id']
				,$this->documentInformation['alert_raised_by']
				,$this->documentInformation['document_comment']
				,$this->documentId
				,$alert_status
				,$reply);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->documentInformation['doc_id']);
		$stmt->bindParam(2,$this->documentInformation['alert_raised_by']);
		$stmt->bindParam(3,$this->documentInformation['document_comment']);
		$stmt->bindParam(4,$this->documentId);
		$stmt->bindParam(5,$alert_status);
		$stmt->bindParam(6,$reply);*/

		$stmt->execute();

		/*$message = "Document has been authorised by ".$this->logged_user_name;
		$this->saveDocumentLog($this->documentInformation['doc_id'],$message);*/

		return $this->documentId;
	}

	/**
	 * This method is used to get document information
	 */
	public function getDocumentInformation($p_doc_id) {

		$p_doc_id = (int) $p_doc_id;

		$sql = sprintf("SELECT * FROM %s.cms_documents
				WHERE cmsdocID = %d
				ORDER BY cmsdocID",_DB_OBJ_FULL,$p_doc_id);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_doc_id);
		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	/**
	 *
	 *
	 */
	public function getDocumentContributors($p_doc_id) {
		return $this->getDocumentAdditionalInfo($p_doc_id,'cms_documents_contributors','contributorID');
	}

	/**
	 *
	 */
	private function getDocumentAlerts($p_doc_id) {
		return $this->getDocumentAdditionalInfo($p_doc_id,'cms_document_alerts','alertID');
	}

	/**
	 *
	 */
	private function getDocumentHistoryLog($p_doc_id) {
		return $this->getDocumentAdditionalInfo($p_doc_id,'cms_document_log','logID');
	}

	/**
	 *
	 */
	private function getDocumentAdditionalInfo($p_doc_id,$p_module,$p_orderby) {

		$p_doc_id = (int) $p_doc_id;

		$sql = sprintf("SELECT * FROM %s.".$p_module."
				WHERE cmsdocID = %d
				ORDER BY ".$p_orderby." ASC",_DB_OBJ_FULL,$p_doc_id);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_doc_id);*/
		$stmt->execute();

		//$a = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($a);

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	//cms_document_log

	/**
	 * This method is used to draw document tree
	 */
	public function drawDocumentTree() {}

	/**
	 * This method is used to generate document tree xml from database
	 */
	public function generateDocumentTreeXml() {

		$standards 	=  $this->getDocumentStandards();
		$xmlstr 	= "<cmsdocuments></cmsdocuments>";

		$this->xmlobj = new SimpleXMLElement($xmlstr);

		$standards_node = $this->xmlobj->addChild('standards');

		foreach ( $standards as $standard_ele ) {


			$std_node = $standards_node->addChild('standard');
			$std_node->addAttribute('standard_id',$standard_ele['sID']);

			$root_sections_data = $this->getRootDocumentsByStdCode($standard_ele['sID'],0);

			foreach ( $root_sections_data as $root_sections_ele ) {

				$section_node 	= $std_node->addChild('section');
				$section_node->addAttribute('code',$root_sections_ele['code']);
				$label_name 	= str_replace('&',' and ',$root_sections_ele['name']);
				$section_node->addChild('label',$label_name);

				$this->getChildSections($section_node,$standard_ele['sID'],$root_sections_ele['ID']);
			}
		}

		$this->xmlobj->asXML(realpath(_PATH_PRIVATE_FILES.'../documents').'/'.$this->xmlDocumentName);
		//echo $this->xmlobj->asXML();
	}

	private function getChildSections($p_context_node,$p_standard_id,$p_id) {

		$node_sections_data 		= $this->getRootDocumentsByStdCode($p_standard_id,$p_id);

		$node_sections_data_count 	= count($node_sections_data);

		if ($node_sections_data_count) {

			$inner_section_node 	= $p_context_node->addChild('sections');

			foreach ( $node_sections_data as $node_sections_ele ) {

				$section_block 		= $inner_section_node->addChild('section');
				$section_block->addAttribute('code',$node_sections_ele['code']);
				$label_name 		= str_replace('&',' and ',$node_sections_ele['name']);
				$section_block->addChild('label',$label_name);

				$this->getChildSections($section_block,$p_standard_id,$node_sections_ele['ID']);
			}
		}

	}

	/**
	 * This method is used to generate document nodes data from database
	 */
	public function generateDocumentDataXml() {

		$standards 	=  $this->getDocumentStandards();
		$xmlstr 	= "<cmsdocuments></cmsdocuments>";

		$this->xmlobj = new SimpleXMLElement($xmlstr);

		$standards_node = $this->xmlobj->addChild('standards');

		$docclassObj 					= SetupGeneric::useModule('DocClassification');
		$optObj							= new Option();
		$miscObj 						= new Misc();

		$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
		$document_types 				= $miscObj->getDocumentTypes();
		$document_classification 		= $docclassObj->displayItems();

		foreach ( $standards as $standard_ele ) {

			//if ( $standard_ele['sID'] != 11 ) { continue; }      // for debugging

			$std_node = $standards_node->addChild('standard');
			$std_node->addAttribute('standard_id',$standard_ele['sID']);

			$root_sections_data = $this->getRootDocumentsByStdCode($standard_ele['sID'],0);

			foreach ( $root_sections_data as $root_sections_ele ) {

				$uploaded_document_list = $this->getDocumentsByStandardAndCode($standard_ele['sID'],$root_sections_ele['code']);

				/*echo "calling for code ".$standard_ele['sID'].",".$root_sections_ele['code'];
				dump_array($uploaded_document_list);
				echo "---------------------------------------------------------------------";*/

				$section_node 	= $std_node->addChild('section');
				$section_node->addAttribute('code',$root_sections_ele['code']);
				$label_name 	= str_replace('&',' and ',$root_sections_ele['name']);

				//$section_node->addChild('label',$label_name);
				$documents_section = $section_node->addChild('documents');

				if ( count($uploaded_document_list) ) {

					foreach ( $uploaded_document_list as $uploaded_document_element ) {

						$document_node = $documents_section->addChild('document');

							$cmsdocID 	= $uploaded_document_element['cmsdocID'];

							$document_node->addAttribute('id',$cmsdocID);
							$document_node->addAttribute('path',$uploaded_document_element['documentID']);
							$document_node->addAttribute('name',addslashes($uploaded_document_element['title']));

						$document_info = $document_node->addChild('information');

						$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
						$document_types 				= $miscObj->getDocumentTypes();
						$document_classification 		= $docclassObj->displayItems();


						if ($document_classification) {

							foreach ( $document_classification as $document_class_ele => $document_class_val ) {

								if ( substr($document_class_ele,0,1) == $uploaded_document_element['classification'] ) {
									$uploaded_document_element['classification'] = $document_class_val;
									break;
								}
							}
						}

						$document_info->addChild('file_reference',$uploaded_document_element['fileReference']);
						$document_info->addChild('title',addslashes(ucfirst($uploaded_document_element['title'])));
						$document_info->addChild('description',addslashes(ucfirst($uploaded_document_element['description'])));
						$document_info->addChild('type',$document_types[$uploaded_document_element['documentType']]);
						$document_info->addChild('type_code',ucfirst(substr($document_types[$uploaded_document_element['documentType']],0,2)));

						switch ($uploaded_document_element['documentSubType']) {
							case 'P': $subtype = 'Procedure'; break;
							case 'R': $subtype = 'Process'; break;
							case 'W': $subtype = 'Work Instructions'; break;
						}

						$document_info->addChild('subtype',$subtype);

						$participant_id = $uploaded_document_element['initiatedByParticipant'];
						$this->participantObj->setItemInfo(array('id'=>$participant_id));
						$partcipantData = $this->participantObj->displayItemById();

						$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

						$initiated_by 	= $participant_name == ' ' ? '-' : $participant_name;

						$document_info->addChild('initiated',format_date($uploaded_document_element['dateInitiated']));
						$document_info->addChild('initiated_by',$initiated_by);

						$document_info->addChild('version_old',$uploaded_document_element['versionOld']);
						$document_info->addChild('version_revision',$uploaded_document_element['docControl']);
						$document_info->addChild('version_new',$uploaded_document_element['versionNew']);
						$document_info->addChild('version_extended',$uploaded_document_element['versionMinor']);
						$document_info->addChild('classification',$uploaded_document_element['classification']);
						$document_info->addChild('action_summary',addslashes(ucfirst($uploaded_document_element['actionSummary'])));
						$document_info->addChild('pages',$uploaded_document_element['pages']);

						$document_info->addChild('businessID',$uploaded_document_element['buID']);
						$document_info->addChild('standardID',$uploaded_document_element['standardID']);
						$document_info->addChild('is_gap_document',$uploaded_document_element['isGapDocument']);
						$document_info->addChild('status',$uploaded_document_element['status']);
						$document_info->addChild('doc_control',$uploaded_document_element['docControl']);

						$document_info->addChild('allocated_to',$uploaded_document_element['allocatedTo']);
						$document_info->addChild('gap_document_id',$uploaded_document_element['gapDocID']);
						$document_info->addChild('authorizer_comment',ucfirst($uploaded_document_element['authorizerComment']));
						$document_info->addChild('uploaded_by',$uploaded_document_element['uploadedBy']);
						$document_info->addChild('date_approved',format_date($uploaded_document_element['dateApproved']));
						$document_info->addChild('is_archive',$uploaded_document_element['isArchive']);
						$document_info->addChild('record_sep',$uploaded_document_element['recordSep']);

						$apprv_participant_id = $uploaded_document_element['approvedBy'];
						$this->participantObj->setItemInfo(array('id'=>$apprv_participant_id));
						$partcipantData = $this->participantObj->displayItemById();

						$apprv_participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

						$apprv_initiated_by 	= $apprv_participant_name == ' ' ? '-' : $apprv_participant_name;

						$document_info->addChild('approved_by',$apprv_initiated_by);

						$alert_block = $document_info->addChild('alerts');

						$new_alerts_count = 0;

						$document_alerts_list 		= $this->getDocumentAlerts($cmsdocID);
						$document_historylog_list 	= $this->getDocumentHistoryLog($cmsdocID);
						$document_contributors_list	= $this->getDocumentContributors($cmsdocID);

						if ( count($document_alerts_list) )	 {
							foreach ( $document_alerts_list as $document_alert_element ) {

								$alert_node = $alert_block->addChild('alert');

								/* alert raised by */
								$alert_participant_id = $document_alert_element['alertRaisedBy'];
								$this->participantObj->setItemInfo(array('id'=>$alert_participant_id));
								$partcipantData = $this->participantObj->displayItemById();

								$alert_initiated_by = '';
								$alert_participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
								$alert_initiated_by 	= $alert_participant_name == ' ' ? '-' : $alert_participant_name;
								/*********************/

								switch($document_alert_element['alertStatus']) {
									case 'A' : $status = 'Agree'; break;
									case 'D' : $status = 'Disagree'; break;
									case 'N' : $status = 'New'; break;
								}

								$this->fileObj->setFileInfo('contributors',array('id'=>$document_alert_element['documentID']));
								$file_detail = $this->fileObj->getFileDetails();
								$file_name = $file_detail['usrFilename'] == '' ? '-' : $file_detail['usrFilename'];

								$alert_node->addChild('id',$document_alert_element['alertID']);
								$alert_node->addChild('raised_by',$alert_initiated_by);
								$alert_node->addChild('comment',$document_alert_element['alertComment']);
								$alert_node->addChild('document_id',$file_name);
								$alert_node->addChild('when_raise',format_date($document_alert_element['alertWhen']));
								$alert_node->addChild('status',$status);

								if ( $document_alert_element['reply'] != '' ) {
									$alert_node->addChild('reply',$document_alert_element['reply']);
								} else {
									$alert_node->addChild('reply','-');
								}


								if ( !$new_alerts_count && $document_alert_element['alertStatus'] == 'N' ) {
									$new_alerts_count = 1;
								}
							}
						}

						if ( $new_alerts_count ) {
							$alert_block->addAttribute('new',1);
						} else {
							$alert_block->addAttribute('new',0);
						}

						$history_block = $document_info->addChild('history');

						if ( count($document_historylog_list) )	 {
							foreach ( $document_historylog_list as $document_historylog_element ) {

								$history_node = $history_block->addChild('log');

								$history_node->addChild('logID',$document_historylog_element['logID']);
								$history_node->addChild('message',$document_historylog_element['message']);
								$history_node->addChild('when_logged',$document_historylog_element['whenDate']);
							}
						}

						$contributor_block 			= $document_info->addChild('contributors');
						$contributor_count 			= 0;
						$contributor_replied 		= 0;
						$contributor_replied_na 	= 0; // not approved
						$contributor_replied_a 		= 0; // approved
						$contributor_count 			= count($document_contributors_list);

						if ( $contributor_count )	 {
							foreach ( $document_contributors_list as $document_contributor_element ) {

								$contributor_node = $contributor_block->addChild('contributor');

								$passed_literal = '';

								switch ($document_contributor_element['passed']) {
									case 0: $passed_literal = 'pending'; break;
									case 1: $passed_literal = 'approved'; $contributor_replied_a++; $contributor_replied++; break;
									case 2: $passed_literal = 'not approved'; $contributor_replied_na++; $contributor_replied++; break;
								}

								$contributor_node->addChild('contributorID',$document_contributor_element['contributorID']);
								$contributor_node->addChild('authParticipantID',$document_contributor_element['authParticipantID']);
								$contributor_node->addChild('date',$document_contributor_element['date']);
								$contributor_node->addChild('passed',$passed_literal);
								$contributor_node->addChild('comments',$document_contributor_element['comments']);
								$contributor_node->addChild('docIssuerAuth',$document_contributor_element['docIssuerAuth']);
								$contributor_node->addChild('contributorAssign',$document_contributor_element['contributorAssign']);
								$contributor_node->addChild('documentID',$document_contributor_element['documentID']);
								$contributor_node->addChild('contribDueDate',$document_contributor_element['contribDueDate']);
							}
						}

						//echo "$contributor_count $contributor_replied $contributor_replied_a $contributor_replied_na<br/>";


						if ( $contributor_count > 0 && $contributor_replied == 0 ) {

							$document_status = "Wait for Contributors's response";

						} else if ( $contributor_count > 0 && $contributor_replied < $contributor_count ) {

							$document_status = "Sent to contributors";

						} else if ( $contributor_count > 0 && $contributor_replied == $contributor_replied_a ) {

							$document_status = "Approved by contributors";

						} else if ( $contributor_count > 0 && $contributor_replied == $contributor_replied_na ) {

							$document_status = "Not approved by contributors";

						} else {
							$document_status = "";
						}

						$document_info->addChild('document_status',$document_status);

					} // end foreach $uploaded_document_list
				} // end if

				$this->getChildSectionsData($std_node,$standard_ele['sID'],$root_sections_ele['ID']);
			}
		}

		$optObj							= null;
		$miscObj 						= null;
		$docclassObj					= null;

		$this->xmlobj->asXML(realpath(_PATH_PRIVATE_FILES.'../documents').'/'.$this->xmlDocumentName);
		//echo $this->xmlobj->asXML();
	}

	private function getChildSectionsData($p_context_node,$p_standard_id,$p_id) {

		$docclassObj 					= SetupGeneric::useModule('DocClassification');
		$optObj							= new Option();
		$miscObj 						= new Misc();

		$root_sections_data 		= $this->getRootDocumentsByStdCode($p_standard_id,$p_id);

			foreach ( $root_sections_data as $root_sections_ele ) {

				$uploaded_document_list = $this->getDocumentsByStandardAndCode($p_standard_id,$root_sections_ele['code']);

				/*echo "calling for code ".$p_standard_id.",".$root_sections_ele['code'];
				dump_array($uploaded_document_list);
				echo "---------------------------------------------------------------------";*/

				$section_node 	= $p_context_node->addChild('section');
				$section_node->addAttribute('code',$root_sections_ele['code']);
				$label_name 	= str_replace('&',' and ',$root_sections_ele['name']);

				//$section_node->addChild('label',$label_name);
				$documents_section = $section_node->addChild('documents');

				if ( count($uploaded_document_list) ) {
					foreach ( $uploaded_document_list as $uploaded_document_element ) {

						$document_node = $documents_section->addChild('document');

							$cmsdocID 	= $uploaded_document_element['cmsdocID'];

							$document_node->addAttribute('id',$cmsdocID);
							$document_node->addAttribute('path',$uploaded_document_element['documentID']);
							$document_node->addAttribute('name',addslashes($uploaded_document_element['title']));

						$document_info = $document_node->addChild('information');

						$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
						$document_types 				= $miscObj->getDocumentTypes();
						$document_classification 		= $docclassObj->displayItems();


						if ($document_classification) {

							foreach ( $document_classification as $document_class_ele => $document_class_val ) {

								if ( substr($document_class_ele,0,1) == $uploaded_document_element['classification'] ) {
									$uploaded_document_element['classification'] = $document_class_val;
									break;
								}
							}
						}

						$document_info->addChild('file_reference',$uploaded_document_element['fileReference']);
						$document_info->addChild('title',addslashes(ucfirst($uploaded_document_element['title'])));
						$document_info->addChild('description',addslashes(ucfirst($uploaded_document_element['description'])));
						$document_info->addChild('type',$document_types[$uploaded_document_element['documentType']]);
						$document_info->addChild('type_code',ucfirst(substr($document_types[$uploaded_document_element['documentType']],0,2)));

						switch ($uploaded_document_element['documentSubType']) {
							case 'P': $subtype = 'Procedure'; break;
							case 'R': $subtype = 'Process'; break;
							case 'W': $subtype = 'Work Instructions'; break;
						}

						$document_info->addChild('subtype',$subtype);


						$participant_id = $uploaded_document_element['initiatedByParticipant'];
						$this->participantObj->setItemInfo(array('id'=>$participant_id));
						$partcipantData = $this->participantObj->displayItemById();

						$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

						$initiated_by 	= $participant_name == ' ' ? '-' : $participant_name;

						$document_info->addChild('initiated',format_date($uploaded_document_element['dateInitiated']));
						$document_info->addChild('initiated_by',$initiated_by);

						$document_info->addChild('version_old',$uploaded_document_element['versionOld']);
						$document_info->addChild('version_revision',$uploaded_document_element['docControl']);
						$document_info->addChild('version_new',$uploaded_document_element['versionNew']);
						$document_info->addChild('version_extended',$uploaded_document_element['versionMinor']);
						$document_info->addChild('classification',$uploaded_document_element['classification']);
						$document_info->addChild('action_summary',addslashes(ucfirst($uploaded_document_element['actionSummary'])));
						$document_info->addChild('pages',$uploaded_document_element['pages']);

						$document_info->addChild('businessID',$uploaded_document_element['buID']);
						$document_info->addChild('standardID',$uploaded_document_element['standardID']);
						$document_info->addChild('is_gap_document',$uploaded_document_element['isGapDocument']);
						$document_info->addChild('status',$uploaded_document_element['status']);
						$document_info->addChild('doc_control',$uploaded_document_element['docControl']);

						$document_info->addChild('allocated_to',$uploaded_document_element['allocatedTo']);
						$document_info->addChild('gap_document_id',$uploaded_document_element['gapDocID']);
						$document_info->addChild('authorizer_comment',ucfirst($uploaded_document_element['authorizerComment']));
						$document_info->addChild('uploaded_by',$uploaded_document_element['uploadedBy']);
						$document_info->addChild('date_approved',format_date($uploaded_document_element['dateApproved']));
						$document_info->addChild('is_archive',$uploaded_document_element['isArchive']);
						$document_info->addChild('record_sep',$uploaded_document_element['recordSep']);

						$apprv_participant_id = $uploaded_document_element['approvedBy'];
						$this->participantObj->setItemInfo(array('id'=>$apprv_participant_id));
						$partcipantData = $this->participantObj->displayItemById();

						$apprv_participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

						$apprv_initiated_by 	= $apprv_participant_name == ' ' ? '-' : $apprv_participant_name;

						$document_info->addChild('approved_by',$apprv_initiated_by);

						$alert_block = $document_info->addChild('alerts');

						$new_alerts_count = 0;

						$document_alerts_list 		= $this->getDocumentAlerts($cmsdocID);
						$document_historylog_list 	= $this->getDocumentHistoryLog($cmsdocID);
						$document_contributors_list	= $this->getDocumentContributors($cmsdocID);

						if ( count($document_alerts_list) )	 {
							foreach ( $document_alerts_list as $document_alert_element ) {

								$alert_node = $alert_block->addChild('alert');

								/* alert raised by */
								$alert_participant_id = $document_alert_element['alertRaisedBy'];
								$this->participantObj->setItemInfo(array('id'=>$alert_participant_id));
								$partcipantData = $this->participantObj->displayItemById();

								$alert_initiated_by = '';
								$alert_participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
								$alert_initiated_by 	= $alert_participant_name == ' ' ? '-' : $alert_participant_name;
								/*********************/

								switch($document_alert_element['alertStatus']) {
									case 'A' : $status = 'Agree'; break;
									case 'D' : $status = 'Disagree'; break;
									case 'N' : $status = 'New'; break;
								}

								$this->fileObj->setFileInfo('contributors',array('id'=>$document_alert_element['documentID']));
								$file_detail = $this->fileObj->getFileDetails();
								$file_name = $file_detail['usrFilename'] == '' ? '-' : $file_detail['usrFilename'];

								$alert_node->addChild('id',$document_alert_element['alertID']);
								$alert_node->addChild('raised_by',$alert_initiated_by);
								$alert_node->addChild('comment',$document_alert_element['alertComment']);
								$alert_node->addChild('document_id',$file_name);
								$alert_node->addChild('when_raise',format_date($document_alert_element['alertWhen']));
								$alert_node->addChild('status',$status);

								if ( $document_alert_element['reply'] != '' ) {
									$alert_node->addChild('reply',$document_alert_element['reply']);
								} else {
									$alert_node->addChild('reply','-');
								}

								if ( !$new_alerts_count && $document_alert_element['alertStatus'] == 'N' ) {
									$new_alerts_count = 1;
								}
							}
						}

						if ( $new_alerts_count ) {
							$alert_block->addAttribute('new',1);
						} else {
							$alert_block->addAttribute('new',0);
						}

						$history_block = $document_info->addChild('history');

						if ( count($document_historylog_list) )	 {
							foreach ( $document_historylog_list as $document_historylog_element ) {

								$history_node = $history_block->addChild('log');

								$history_node->addChild('logID',$document_historylog_element['logID']);
								$history_node->addChild('message',$document_historylog_element['message']);
								$history_node->addChild('when_logged',$document_historylog_element['whenDate']);
							}
						}

						$contributor_block 			= $document_info->addChild('contributors');
						$contributor_count 			= 0;
						$contributor_replied 		= 0;
						$contributor_replied_na 	= 0; // not approved
						$contributor_replied_a 		= 0; // approved
						$contributor_count 			= count($document_contributors_list);

						if ( $contributor_count )	 {
							foreach ( $document_contributors_list as $document_contributor_element ) {

								$contributor_node = $contributor_block->addChild('contributor');

								$passed_literal = '';

								switch ($document_contributor_element['passed']) {
									case 0: $passed_literal = 'pending'; break;
									case 1: $passed_literal = 'approved'; $contributor_replied_a++; $contributor_replied++; break;
									case 2: $passed_literal = 'not approved'; $contributor_replied_na++; $contributor_replied++; break;
								}

								$contributor_node->addChild('contributorID',$document_contributor_element['contributorID']);
								$contributor_node->addChild('authParticipantID',$document_contributor_element['authParticipantID']);
								$contributor_node->addChild('date',$document_contributor_element['date']);
								$contributor_node->addChild('passed',$passed_literal);
								$contributor_node->addChild('comments',$document_contributor_element['comments']);
								$contributor_node->addChild('docIssuerAuth',$document_contributor_element['docIssuerAuth']);
								$contributor_node->addChild('contributorAssign',$document_contributor_element['contributorAssign']);
								$contributor_node->addChild('documentID',$document_contributor_element['documentID']);
								$contributor_node->addChild('contribDueDate',$document_contributor_element['contribDueDate']);
							}
						}

						if ( $contributor_count > 0 && $contributor_replied == 0 ) {

							$document_status = "Wait for Contributors's response";

						} else if ( $contributor_count > 0 && $contributor_replied < $contributor_count ) {

							$document_status = "Sent to contributors";

						} else if ( $contributor_count > 0 && $contributor_replied == $contributor_replied_a ) {

							$document_status = "Approved by contributors";

						} else if ( $contributor_count > 0 && $contributor_replied_na > 0 ) {

							$document_status = "Not approved by contributors";

						} else {
							$document_status = "";
						}

						//echo "$contributor_count $contributor_replied $contributor_replied_a $contributor_replied_na $document_status<br/>";

						$document_info->addChild('document_status',$document_status);

					} // end foreach $uploaded_document_list
				} // end if

				$this->getChildSectionsData($p_context_node,$p_standard_id,$root_sections_ele['ID']);
			}

		$optObj							= null;
		$miscObj 						= null;
		$docclassObj					= null;
	} // end method

	/**
	 *
	 *
	 */
	public function changeXmlDocumentFilename($p_filename) {
		$this->xmlDocumentName = $p_filename;
	}

	/**
	 * This method is used to get document tree data from xml file
	 */
	public function getDocumentTree($p_standard_id,$p_context='documents') {

		$xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES.'../documents').'/'.$this->xmlDocumentName);

		$tree_html = "";

		foreach ( $xmldata->standards->standard as $standard_xml_data ) {

			$att = $standard_xml_data->attributes();

			if ( $att['standard_id'] == $p_standard_id ) {

				$tree_html = "<div id='sidetree' class='filetree'>";

				//if ( $context == 'documents' ) {
					$tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";
				//}

				$tree_html .= "<ul class='treeview' id='dmstree'>";

				foreach ( $standard_xml_data as $section_data) {

					$section_attr = $section_data->attributes();

					$escaped_code 		= str_replace('.','_',$section_data['code']);
					$document_name		= urlencode($section_data->label);

					$doc_detail_block = "<div class='abc' id='doclist_".$escaped_code."' style='margin-left:20px'></div>";

					// Hardcoded by davinder
					// 11 is id for CMS 9k

					$toggle_class 	= "";
					$upload_link	= "";

					if ( ( getUserAccessLevel() == 1 || getUserAccessLevel() == 2 )  && $p_standard_id  == 11 && $p_context == 'documents' ) {
						$toggle_class 	= " class='toggle_upload_link'";
						$upload_link 	= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=".$escaped_code."&doc_name=".$document_name."','upload_document','width=700,height=600,scrollbars=yes')\" class='updl_".$escaped_code."'><b>Upload Document</b></a>";
					}

					if ( is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code,$this->documentInformation['sel_cms_refs']) ) {
						$select_reference_link 	= "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_".$escaped_code."' class='cms_select state_sel' rel='".$escaped_code."'><b>Unselect</b></a>";
					} else {
						$select_reference_link 	= "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_".$escaped_code."' class='cms_select state_unsel' rel='".$escaped_code."'><b>Select</b></a>";
					}

					$tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$section_attr['code'];
					$tree_html .= "&nbsp;-&nbsp;<a".$toggle_class." rel='".$escaped_code."' href='javascript: void(0)'>".$section_data->label."</a>";
					$tree_html .= "&nbsp;(<span class='document_count_for_".$escaped_code."'>0</span>)";

					if ( $p_context != 'process_flow' ) {
						$tree_html .= "<span class='loader_class' id='loader_block_".$escaped_code."' style='margin-left:20px'><img src='/images/ajax-loader.gif'></span>";
						$tree_html .= $upload_link;
						$tree_html .= $doc_detail_block;
					} else {
						$tree_html .= $select_reference_link;
					}

					$tree_html .= "</span><ul>";

					$count = 0;
		//			if (phpversion() >= '5.3.0') {
		//				$count = $section_data->sections->section->count();
		//			} else {
						$count = count($section_data->sections->section);
		//			}

					if ( $count ) {
						$tree_html .= $this->getSectionChildren($section_data->sections->section,$p_standard_id,$p_context);
					}

					$tree_html .= "</ul>";
					$tree_html .= "</li>";

				}

				$tree_html .= "</ul></div>";
			}
		} // end foreach

		return $tree_html;
	}

	/**
	 * This method is used to get document meta data from xml file
	 */
	public function getDocumentMetadata($p_standard_id) {

		$xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES.'../documents').'/'.$this->xmlDocumentName);

		$json_data = array();

		foreach ( $xmldata->standards->standard as $standard_xml_data ) {

			$att = $standard_xml_data->attributes();

			if ( $att['standard_id'] == $p_standard_id ) {

				foreach ( $standard_xml_data as $section_data) {

					$document_data = $section_data->attributes();
					$document_data_code = (string) $document_data['code'];

					$documents_list = $section_data->children()->children();

					$count = 0;
	//				if (phpversion() >= '5.3.0') {
	//					$count = $documents_list->count();
	//				} else {
						$count = count($documents_list);
	//				}

					$document_array = array(0);

					if ($documents_list) {

						$document_index = 0;

						foreach ( $documents_list as $documents_list_record ) {

							$specific_document_attr = $documents_list_record->attributes();
							$document_metadata 		= $documents_list_record->children()->children();



							foreach ( $specific_document_attr as $attr_ele_key=>$attr_ele_val ) {
								$json_data[$document_data_code][$document_index]['attributes'][$attr_ele_key] = (string) $attr_ele_val;
							}

							foreach ( $document_metadata as $metadata_ele => $metadata_val) {

								if ( $metadata_ele == 'alerts' || $metadata_ele == 'history' ) { continue; }

								$json_data[$document_data_code][$document_index]['information'][$metadata_ele] = (string) $metadata_val;
							}

							$document_alert 		= $document_metadata->alerts;
							$document_history 		= $document_metadata->history;
							$document_contributors 	= $document_metadata->contributors;

							$alert_attr = $document_alert->attributes();
							$new_alerts = 0;
							$new_alerts = $alert_attr['new'];

							$alerts_count = 0;
	//						if (phpversion() >= '5.3.0') {
	//							$alerts_count = $document_alert->children()->count();
	//						} else {
								$alerts_count = count($document_alert->children());
	//						}

							$alerts_array 			= $document_alert->children();
							$history_array 			= $document_history->children();
							$contributors_array 	= $document_contributors->children();

							$json_data[$document_data_code][$document_index]['alerts']['new'] 	= (int) $new_alerts;
							$json_data[$document_data_code][$document_index]['alerts']['total'] = $alerts_count;

							foreach ( $alerts_array as $alerts_ele ) {
								$json_data[$document_data_code][$document_index]['alerts_list'][] 	= (array) $alerts_ele;
							}

							foreach ( $history_array as $history_ele ) {
								$json_data[$document_data_code][$document_index]['history'][] 	= (array) $history_ele;
							}

							foreach ( $contributors_array as $contributor_ele ) {
								$json_data[$document_data_code][$document_index]['contributors'][] 	= (array) $contributor_ele;
							}

							$document_index++;
						}
					}
				}
			} // end if
		} // end foreach

		return $json_data;
	}

	private function getSectionChildren($p_section_data,$p_standard_id,$p_context) {

		$tree_html = "";

		foreach ( $p_section_data as $section_data_ele ) {

			$escaped_code 	= str_replace('.','_',$section_data_ele['code']);
			$document_name	= urlencode($section_data_ele->label);

			$doc_detail_block = "<div class='abc' id='doclist_".$escaped_code."' style='margin-left:20px'></div>";

			// Hardcoded by davinder
			// 11 is id for CMS 9k
			$toggle_class 	= "";
			$upload_link	= "";

			//$debstr =  getUserAccessLevel()."~".$p_standard_id."~".$p_context."~";

			if ( ( getUserAccessLevel() == 1 || getUserAccessLevel() == 2 ) && $p_standard_id  == 11 && $p_context == 'documents' ) {
				$toggle_class 	= " class='toggle_upload_link'";
				$upload_link 	= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=".$escaped_code."&doc_name=".$document_name."','upload_document','width=700,height=600,scrollbars=yes')\" class='updl_".$escaped_code."'><b>Upload Document</b></a>";
			}

			$tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$section_data_ele['code']."<span class='expandable'>";
			$tree_html .= "&nbsp;-&nbsp;<a".$toggle_class." rel='".$escaped_code."' href='javascript: void(0)'>".$section_data_ele->label."</a>";
			$tree_html .= "</span>&nbsp;(<span class='document_count_for_".$escaped_code."'>0</span>)";

			if ( is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code,$this->documentInformation['sel_cms_refs']) ) {
				$select_reference_link 	= "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_".$escaped_code."' class='cms_select state_sel' rel='".$escaped_code."'><b>Unselect</b></a>";
			} else {
				$select_reference_link 	= "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_".$escaped_code."' class='cms_select state_unsel' rel='".$escaped_code."'><b>Select</b></a>";
			}

			if ( $p_context != 'process_flow' ) {
				$tree_html .= "<span class='loader_class' id='loader_block_".$escaped_code."' style='margin-left:20px'><img src='/images/ajax-loader.gif'></span>";
				$tree_html .= $upload_link;
				$tree_html .= $doc_detail_block;
			} else {
				$tree_html .= $select_reference_link;
			}

			$tree_html .= "</span><ul>";

			$count = 0;

	//		if (phpversion() >= '5.3.0') {
	//			$count = $section_data_ele->sections->section->count();
	//		} else {
				$count = count($section_data_ele->sections->section);
	//		}

			if ( $count ) {
				$tree_html .= $this->getSectionChildren($section_data_ele->sections->section,$p_standard_id,$p_context);
			}

			$tree_html .= "</ul>";
			$tree_html .= "</li>";
		}

		return $tree_html;
	}

	private function getDocumentStandards() {

		$sql = sprintf("SELECT DISTINCT sID FROM %s.msr_departments
				ORDER BY sID ASC",_DB_OBJ_FULL);

		$stmt 		= $this->dbHand->prepare($sql);

		$stmt->execute();
		$result 		= $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}

	private function getRootDocumentsByStdCode($p_standard_id,$p_id) {

		if ( $p_id == 0 ) {
			$sql = sprintf("SELECT ID,code,name,pID,sID FROM %s.msr_departments
				WHERE code >= '4'
				AND sID = %d
				AND pID = %d
				ORDER BY code ASC",_DB_OBJ_FULL,$p_standard_id,$p_id);
		} else {
			$sql = sprintf("SELECT ID,code,name,pID,sID FROM %s.msr_departments
				WHERE sID = %d
				AND pID = %d
				ORDER BY code ASC",_DB_OBJ_FULL,$p_standard_id,$p_id);
		}

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_standard_id);
		$stmt->bindParam(2,$p_id);*/
		$stmt->execute();

		$result 		= $stmt->fetchAll(PDO::FETCH_ASSOC);
		$resultCount 	= count($result);

		$new_result = array();

		if ($resultCount) {
			foreach ( $result as $resultEle ) {
				$new_result[] = $resultEle;
			}
		}

		return $new_result;

	}

	private function getDocumentsByStandardAndCode($p_standard_id,$p_code) {

		if ( $p_standard_id == 11 ) {

			//echo "Called for $p_standard_id $p_code <br/>";

			$sql = sprintf("SELECT *,C.cmsdocID as cmsdocID FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID
					WHERE fileReference = '%s'
					ORDER BY C.cmsdocID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_code);

			//echo $sql."<br/>";
			/*$stmt->bindParam(1,$p_code);*/

			$stmt 		= $this->dbHand->prepare($sql);
			$stmt->execute();

			$result 		= $stmt->fetchAll(PDO::FETCH_ASSOC);

		} else {

			$new_code = $this->getLinkingCode($p_standard_id,$p_code);

			if ( $new_code != '' ) {

				$sql = sprintf("SELECT *,C.cmsdocID as cmsdocID FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID
					WHERE fileReference = '%s' AND standardID = 11
					ORDER BY C.cmsdocID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$new_code);

				$stmt 		= $this->dbHand->prepare($sql);
				$stmt->execute();

				$result 		= $stmt->fetchAll(PDO::FETCH_ASSOC);
				if ( count($result) ) {
					$result[0]['fileReference'] = $p_code;
				}

			}

		}

		//dump_array($result);
		return $result;
	}

	private function getLinkingCode($p_standard_id,$p_code) {

		$sql2 = sprintf("SELECT code FROM %s.review_question_metadata
								WHERE questionID IN (SELECT questionID FROM %s.review_question_metadata WHERE standardID = %d AND code = '%s')
								AND standardID = 11",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_standard_id,$p_code);

		$stmt2 		= $this->dbHand->prepare($sql2);
		$stmt2->execute();
		$code = $stmt2->fetchColumn();

		//dump_array($code);

		return $code;

	}

	public function getSectionByStandardAndCode($p_standard_id,$p_code) {

		$sql = sprintf("SELECT * FROM %s.msr_departments
				WHERE code = '%s'
				AND sID = %d",_DB_OBJ_FULL,$p_code,$p_standard_id);

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_code);
		$stmt->bindParam(2,$p_standard_id);*/
		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	public function downloadDocument($p_doc_id,$p_document_title='') {

		$updObj = new Upload();
		$updObj->setFileInfo('documents',array('id'=>$p_doc_id));
		$file_details = $updObj->getFileDetails();

		$file = _PATH_PUB.'documents/'.$file_details['sysFilename'];
		$file_name_ext = substr($file_details['sysFilename'],-4,4);

		$download_file_name = $p_document_title.$file_name_ext;

		if ( !$file ) {
				// File doesn't exist, output error
				die('file not found');
		} else {
				// Set headers
				header('Content-type: application/download');
				header('Content-Description: File Transfer');
				header('Content-Disposition: attachment; filename="'.$download_file_name.'" ');
				header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
				header('Content-Transfer-Encoding: binary');

				// Read the file from disk
				readfile($file);
		}

		$updObj = null;
    }

	/**
	 * This method is used to store the disagreement of alert raised by others
	 */
	public function getAlertDetails() {

		$sql = sprintf("SELECT * FROM  %s.cms_document_alerts WHERE alertID = %d",_DB_OBJ_FULL,$this->documentInformation['alert_id']);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;

	}

	public function getDocRegisterData() {

		$sql = sprintf("SELECT D.*,C.approvedBy,C.dateApproved,C.authorizerComment FROM  %s.cms_documents D
					   INNER JOIN %s.cms_documents_metadata C ON C.cmsdocID = D.cmsdocID
					   WHERE D.status = 'A' ORDER By D.fileReference ASC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function getDocRef($p_code,$p_sid) {

		$sql = sprintf("SELECT name FROM  %s.msr_departments D
					   WHERE D.code = '%s' AND sID='%s' ",_DB_OBJ_FULL,$p_code,$p_sid);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$resultSet = $stmt->fetchColumn();

		return $resultSet;
	}

	private function updDocReplaceInfo($p_cms_doc_id,$p_doc_id,$p_status,$comment_upd=false) {
		$sql = sprintf("UPDATE %s.cms_document_replace SET is_active = '%s' WHERE cmsdocID = %d  AND documentID = %d ",
					   _DB_OBJ_FULL,$p_status,$p_cms_doc_id,$p_doc_id);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();

		if ( $comment_upd ) {
			$sql_sec = sprintf("UPDATE %s.cms_document_replace SET comment = '%s' WHERE cmsdocID = %d AND documentID = %d ",
					   _DB_OBJ_FULL,$this->documentInformation['reason_replace'],$p_cms_doc_id,$p_doc_id);

			$stmt_sec = $this->dbHand->prepare($sql_sec);

			$stmt_sec->execute();
		}
	}

	private function addDocReplicateInfo($dms_doc_id) {
		$sql_doc_active = sprintf("INSERT INTO %s.cms_document_replace (cmsdocID,documentID,is_active,uploaded_on) VALUES (%d,%d,'1',".customCurrentDate().")",
									  _DB_OBJ_FULL,$dms_doc_id,$this->documentId);
			$stmt_doc_active = $this->dbHand->prepare($sql_doc_active);
			$stmt_doc_active->execute();
	}

	public function getDocHistory($p_file_ref,$p_sep) {

		$sql_sec = sprintf("SELECT * FROM %s.cms_documents
						   WHERE
						   fileReference LIKE '%s'
						   AND recordSep = %d
						   AND isArchive = 1 ORDER BY cmsdocID ASC",_DB_OBJ_FULL,$p_file_ref,$p_sep);

		$stmt_sec = $this->dbHand->prepare($sql_sec);
		$stmt_sec->execute();

		$result = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}

	public function changeDocument($p_fr,$p_cdid,$p_sep) {

		$sql 		= sprintf("UPDATE %s.cms_documents SET isArchive = 1 WHERE fileReference LIKE '%s' AND cmsdocID != %d AND recordSep = %d",
					   _DB_OBJ_FULL,$p_fr,$p_cdid,$p_sep);

		$sql_sec 	= sprintf("UPDATE %s.cms_documents SET isArchive = 0 WHERE fileReference LIKE '%s' AND cmsdocID = %d AND recordSep = %d",
					   _DB_OBJ_FULL,$p_fr,$p_cdid,$p_sep);

		$stmt 		= $this->dbHand->prepare($sql);
		$stmt_sec 	= $this->dbHand->prepare($sql_sec);

		$stmt->execute();
		$stmt_sec->execute();
	}

	public function saveDocumentLog($p_doc_id,$p_message) {

		$message = smartisoAddslashes($p_message);

		$sql = sprintf(" INSERT INTO %s.cms_document_log (cmsdocID,message,whenDate) VALUES (%d,'%s',%s)",_DB_OBJ_FULL,$p_doc_id,$message,customCurrentDate());
		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
		//dump_array_and_exit($stmt->errorInfo());
	}
}
?>