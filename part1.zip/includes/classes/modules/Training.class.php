<?php

/**
  $Id: Training.class.php,v 3.43 Thursday, February 03, 2011 3:49:46 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, November 27, 2010 6:32:11 PM>
 */
require_once "Training.int.php";

class Training implements TrainingInterface {


	const STATUS_APPROVAL_REQUIRED = 4; // this is required for the course to be approved
	const STATUS_REJECTED = 8; // this cannot be set if the course is to be approved
	const STATUS_CANCELLED = 16; // this cannot be set if the course is to be approved
	const STATUS_EXTERNAL = 32; // this cannot be set if the course is to be approved
	const STATUS_HISTORIC = 64; 
        
        const PROGRESS_STATUS_APPROVAL_STARTED = 1; //sets start of approval
        const PROGRESS_STATUS_DIRECTOR_APPROVAL = 2; //sets director approval
        const PROGRESS_STATUS_FINANCE_APPROVAL = 4; //sets finance approval
	const PROGRESS_STATUS_READY= 8; //sets readsy to run completed
	const PROGRESS_STATUS_COMPLETED= 16; //sets completed
	const PROGRESS_STATUS_REJECTED= 32; //sets rejected
	const PROGRESS_STATUS_FINAL= 512; //sets final completion after all feedbacks
        
        //particpants
        const STATUS_ACTIVE = 1;
	const STATUS_APPROVED = 2;
	const STATUS_CERTIFICATE = 4;
	const STATUS_ATTENDED = 8;
	const STATUS_SATISFACTORY = 16;
	const STATUS_PARTICIPANT_REJECTED = 32;
	const STATUS_PARTICIPANT_CANCELLED = 64;
	const STATUS_CONFIRM = 128;
	const STATUS_FEEDBACK_REQD = 256;
	const STATUS_FEEDBACK_RECD = 512;     
	const STATUS_HISTORY = 1024;   
    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * property to hold misc object
     * @access private
     */
    private $miscObj;

    /**
     * Property to hold Training Id
     * @access private
     */
    private $trainingId;

    /**
     * Property to hold multiple Training Id
     * @access private
     */
    private $trainingIdArr;

    /**
     * Property to hold Training Info
     * @access private
     */
    private $trainingInfo;

    /**
     * Constructor for initializing Training object
     * @access public
     */
    public function __construct() {


        
        
        $this->dbHand = DB::connect(_DB_TYPE);
        $this->miscObj = new Misc();
    }

    /*
     * to set trainee information for performing various operations with the training object
     */

    public function setTraineeInfo($p_traineeId, $p_traineeInfo) {
        $this->trainingId = $p_traineeId;
        $this->trainingInfo = $p_traineeInfo;
    }

    /*
     * to set personal record information for performing various operations with the training object
     */

    public function setPersonalRecordCardInfo($p_traineeId, $p_recordInfo) {
        
    }

    /*
     * This method is used to assign a course to the trainee
     */

    public function addTraineeToCourse() {

        $this->trainingInfo['assign_date'] = format_date_for_mysql($this->trainingInfo['assign_date']);

        $sql = sprintf("SELECT * FROM %s.trng_assign_course WHERE reference = '%s'", _DB_OBJ_FULL, $this->trainingInfo['reference']);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->trainingInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //$resultSet = '';
        //dump_array($this->trainingInfo);

        if ($this->trainingInfo['ref_unique']) {
            //dump_array($resultSet);
            if (!is_array($resultSet)) {
                $allow_check = true;
            } else {
                $allow_check = false;
            }
        } else {
            $allow_check = true;
        }

        if ($allow_check) {

            $z = 0;
            $parti = explode(",", $this->trainingInfo['participant_name']);
            foreach ($parti as $participant_name_ele) {

                /* skip first record for new unqiue reference number
                  As the URN for first record will come from reference number
                 */

                $sql2 = sprintf("SELECT * FROM %s.trng_assign_course WHERE worksNumber = '%s' AND courseID = %d AND assignDate = '%s' AND startTime = '%s' ",
                        _DB_OBJ_FULL, $this->trainingInfo['works_number'], $this->trainingInfo['course_id'], $this->trainingInfo['assign_date'],
                        $this->trainingInfo['start_time']);

                $pStatement2 = $this->dbHand->prepare($sql2);

                /* $pStatement2->bindParam(1,$this->trainingInfo['works_number']);
                  $pStatement2->bindParam(2,$this->trainingInfo['course_id']);
                  $pStatement2->bindParam(3,$this->trainingInfo['assign_date']); */
                $pStatement2->execute();
                $resultSet2 = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

                if (!is_array($resultSet2)) {

                    $course_seperator = $this->getCourseSeperator();

                    $USER_ID = getLoggedInUserId();


                    if ($z) {
                        $uniqueRef = new UniqueReference();
                        $this->trainingInfo['unique_reference'] = $uniqueRef->getNumber('TRAINING_ASSIGN_COURSE');
                        $this->trainingInfo['reference'] = $this->trainingInfo['unique_reference'];
                    }

                    $sql3 = sprintf("INSERT INTO %s.trng_assign_course (reference,uniqueReference,courseID,participantName,worksNumber,instructorID,
										roomID,assignDate,assignTime,refreshment,courseSeperator,archive,whoID,startTime,isPlanned,isGrouped)
										VALUES ('%s', '%s', %d, '%s', '%s', '%s', %d, '%s', '%s', '%s', %d, '0', %d,'%s','0','%s') ", _DB_OBJ_FULL,
                            $this->trainingInfo['reference'], $this->trainingInfo['unique_reference'], $this->trainingInfo['course_id'],
                            $this->trainingInfo['participant_name'], $this->trainingInfo['works_number'], $this->trainingInfo['instructor_id'],
                            $this->trainingInfo['room_id'], $this->trainingInfo['assign_date'],
                            $this->trainingInfo['assign_time'], smartisoAddslashes($this->trainingInfo['refreshment']),
                            $course_seperator, $USER_ID, $this->trainingInfo['start_time'], $this->trainingInfo['group_flag']);
                    //exit;

                    $pStatement3 = $this->dbHand->prepare($sql3);
                    $pStatement3->execute();

                    //$this->trainingId = customLastInsertId(& $this->dbHand,'trng_assign_course','ID');
                    $this->trainingIdArr[] = customLastInsertId($this->dbHand, 'trng_assign_course', 'ID');
                    $z++;
                }
                //else {
                //	throw new ErrorException('Some of the trainees are already assigned to this course for this interval.');
                //}
            }
        } else {
            throw new ErrorException('Assigned course with this reference number already exists.');
        }

        //dump_array($this);
    }

    /**
     * This method is used to get course seperator
     */
    private function getCourseSeperator() {

        $sql = sprintf("SELECT * FROM %s.trng_assign_course WHERE courseID = %d AND assignDate = '%s'
						AND courseSeperator=(SELECT MAX(courseSeperator) FROM %s.trng_assign_course WHERE courseID = %d AND assignDate = '%s') ", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->trainingInfo['course_id'], $this->trainingInfo['assign_date'], $this->trainingInfo['course_id'], $this->trainingInfo['assign_date']);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->trainingInfo['course_id']);
          $pStatement->bindParam(2,$this->trainingInfo['assign_date']);
          $pStatement->bindParam(3,$this->trainingInfo['course_id']);
          $pStatement->bindParam(4,$this->trainingInfo['assign_date']);
         */

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        if (is_array($resultSet)) {
            $resultCount = count($resultSet);
            if ($resultCount < 18) {

                if (_DB_TYPE != 'mysql') {
                    $sql2 = sprintf("SELECT TOP 1 courseSeperator FROM %s.trng_assign_course WHERE courseID = %d AND assignDate = '%s' ORDER BY ID DESC", _DB_OBJ_FULL, $this->trainingInfo['course_id'], $this->trainingInfo['assign_date']);
                } else {
                    $sql2 = sprintf("SELECT courseSeperator FROM %s.trng_assign_course WHERE courseID = %d AND assignDate = '%s' ORDER BY ID DESC LIMIT 1", _DB_OBJ_FULL, $this->trainingInfo['course_id'], $this->trainingInfo['assign_date']);
                }

                $pStatement2 = $this->dbHand->prepare($sql2);

                /* $pStatement2->bindParam(1,$this->trainingInfo['course_id']);
                  $pStatement2->bindParam(2,$this->trainingInfo['assign_date']); */

                $pStatement2->execute();

                $seperator_value = $pStatement2->fetchColumn();
            } else {

                $sql2 = sprintf("SELECT MAX(courseSeperator) as newseperator FROM %s.trng_assign_course WHERE courseID = %d AND assignDate = '%s' ", _DB_OBJ_FULL, $this->trainingInfo['course_id'], $this->trainingInfo['assign_date']);
                $pStatement2 = $this->dbHand->prepare($sql2);

                /* $pStatement2->bindParam(1,$this->trainingInfo['course_id']);
                  $pStatement2->bindParam(2,$this->trainingInfo['assign_date']); */

                $pStatement2->execute();

                $seperator_value = $pStatement2->fetchColumn();
                $seperator_value++;
            }
        } else {
            $seperator_value = 1;
        }

        return $seperator_value;
    }

    /*
     * This method is used to view the trainee information.
     */

    public function viewCourseAssignedToTrainee() {


        $sql2 = sprintf("SELECT * FROM %s.trng_assign_course WHERE ID = %d ", _DB_OBJ_FULL, $this->trainingId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->trainingId); */
        $pStatement2->execute();
        $resultSet2 = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet2[0];
    }

    /*
     * This method is used to edit the trainee
     */

    public function editCourseAssignedTrainee() {


echo        $sql3 = sprintf("UPDATE %s.trng_assign_course SET courseID = %d,
												instructorID = %d,
													roomID = %d,
													assignDate = '%s',
													assignTime = '%s',
													refreshment = '%s'
													WHERE ID = %d",
                _DB_OBJ_FULL
                , $this->trainingInfo['course_id']
                , $this->trainingInfo['instructor_id']
                , $this->trainingInfo['room_id']
                , $this->trainingInfo['assign_date']
                , $this->trainingInfo['assign_time']
                , smartisoAddslashes($this->trainingInfo['refreshment'])
                , $this->trainingId);

        $pStatement3 = $this->dbHand->prepare($sql3);



        $pStatement3->execute();
    }

    /*
     * This method is used to delete the trainee
     */

    public function deleteCourseAssignedTrainee() {

        $this->deletePersonalRecordCard();
    }

    /*
     * This method is used to archive the trainee
     */

    public function archiveCourseAssignTrainee() {

        $sql = sprintf("UPDATE %s.trng_assign_course
				SET archive = '%s'
				WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->trainingInfo['archive']
                , $this->trainingId);

        $pStatement3 = $this->dbHand->prepare($sql);

        /* $pStatement3->bindParam(1,$this->trainingInfo['archive']);
          $pStatement3->bindParam(2,$this->trainingId); */

        $pStatement3->execute();
    }

    /*
     * This method is used to remove the trainee
     */

    public function purgeCourseAssignTrainee() {
        
    }

    /*
     * This method is used to get the list of courses which are assigned to atleast one trainee
     */

    public function getCourseAssigned() {

        $sql = sprintf("SELECT * FROM %s.trng_assign_course ORDER BY ID DESC ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get the list of courses which are planned
     */

    public function getCoursePlanned() {

        $current_date = $this->miscObj->getCurDate();

        $sql = sprintf("SELECT * FROM %s.trng_assign_course WHERE ( completeDate IS NULL OR completeDate ='1900-01-01' ) AND assignDate >= '%s' AND isPlanned = '1' ", _DB_OBJ_FULL, $current_date);

        $sql = $sql . " ORDER BY ID DESC";
        $pStatement = $this->dbHand->prepare($sql);
        /* $pStatement->bindParam(1,$current_date); */

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get the list of courses which are confirmed
     */

    public function getCourseConfirmed() {

        $current_date = $this->miscObj->getCurDate();

        $sql = sprintf("SELECT * FROM %s.trng_assign_course WHERE (completeDate IS NULL OR completeDate = '1900-01-01') AND assignDate < '%s' ", _DB_OBJ_FULL, $current_date);

        /* $sql = sprintf("SELECT * FROM %s.trng_assign_course WHERE (completeDate IS NULL OR completeDate = '1900-01-01') ",_DB_OBJ_FULL); */

        $sql = $sql . " ORDER BY ID DESC";
        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$current_date);

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get the list of trainees who has completed training grouped by course
     * array variables : start_date,end_date,course_id,course_seprator
     * // do not pass course seprator to main completed listing
     */

    public function getCourseCompleted() {


        $vstatements = array();
        $vstatements[] = _DB_OBJ_FULL;

        $start_date = $this->miscObj->getCurDate();
        $end_date = $this->miscObj->getCurDate();

        if ($this->trainingInfo['start_date'] != '') {
            $start_date = format_date_for_mysql($this->trainingInfo['start_date']);
        }

        if ($this->trainingInfo['end_date'] != '') {
            $end_date = format_date_for_mysql($this->trainingInfo['end_date']);
        }

        if ($this->trainingInfo['course'] != '') {

            $course_filter = "INNER JOIN %s.trng_course C ON C.cID=T.courseID";
            $course_filter_clause = " AND C.title LIKE '" . $this->trainingInfo['course'] . "%' ";
            $vstatements[] = _DB_OBJ_FULL;
        }

        $vstatements[] = $start_date;
        $vstatements[] = $end_date;

        $sql = vsprintf("SELECT T.* FROM %s.trng_assign_course T " . $course_filter . " WHERE T.completeDate IS NOT NULL AND T.attended='1' AND T.successfull='1' AND
					T.assignDate >= '%s' AND T.assignDate <= '%s' ", $vstatements);


        $sql = $sql . $course_filter_clause . " ORDER BY ID DESC";

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$start_date);
          $pStatement->bindParam(2,$end_date); */

        if (!$pStatement->execute()) {
            dump_array($pStatement->errorInfo());
        }

        //$pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get trainees by course
     * course_id,assign_date,course_seprator
     */

    public function getTraineesByCourse() {

        //$this->trainingInfo['assign_date'] = format_date_for_mysql($this->trainingInfo['assign_date']);
        $this->trainingInfo['assign_date'] = $this->trainingInfo['assign_date'];

        $archive = $this->trainingInfo['archive'] == '' ? '0' : $this->trainingInfo['archive'];

        $sql = sprintf("SELECT * FROM %s.trng_assign_course
					   WHERE courseID = %d AND assignDate = '%s'  AND archive = '%s' ",
                _DB_OBJ_FULL
                , $this->trainingInfo['course_id']
                , $this->trainingInfo['assign_date']
                , $archive);

        if ($this->trainingInfo['filter'] == 'time') {
            $sql .= " AND startTime = '" . $this->trainingInfo['start_time'] . "' ";
        }

        $sql .= " ORDER BY ID DESC";

        // AND courseSeperator = %d
        //	,$this->trainingInfo['course_seperator']

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->trainingInfo['course_id']);
          $pStatement->bindParam(2,$this->trainingInfo['assign_date']);
          $pStatement->bindParam(3,$this->trainingInfo['course_seperator']);
          $pStatement->bindParam(4,$archive); */

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get trainee metadata
     */

    public function getTraineeMetaData() {
        
    }

    /*
     * This method is used to save trainee metadata
     * attended,successfull,certificate_issued,certificate_not_issued,finish_date
     */

    public function saveTraineeMetaData() {

        if ($this->trainingInfo['finish_date']) {
            $this->trainingInfo['finish_date'] = format_date_for_mysql($this->trainingInfo['finish_date']);
        } else {
            $this->trainingInfo['finish_date'] = NULL;
        }

        $sql3 = sprintf("UPDATE %s.trng_assign_course SET attended = '%s',
												successfull = '%s',
												certificateIssued = '%s',
												certificateNotIssued = '%s',
												completeDate = '%s'
												WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->trainingInfo['attended']
                , $this->trainingInfo['successfull']
                , $this->trainingInfo['certificate_issued']
                , $this->trainingInfo['certificate_not_issued']
                , $this->trainingInfo['finish_date']
                , $this->trainingId);

        $pStatement3 = $this->dbHand->prepare($sql3);

        /* $pStatement3->bindParam(1,$this->trainingInfo['attended']);
          $pStatement3->bindParam(2,$this->trainingInfo['successfull']);
          $pStatement3->bindParam(3,$this->trainingInfo['certificate_issued']);
          $pStatement3->bindParam(4,$this->trainingInfo['certificate_not_issued']);
          $pStatement3->bindParam(5,$this->trainingInfo['finish_date']);
          $pStatement3->bindParam(6,$this->trainingId); */

        /* if ( !$pStatement3->execute() ) {
          dump_array($pStatement3->errorInfo());
          } */

        $pStatement3->execute();
    }

    /*
     * This method is used to get trainee personal record card
     * array variables : last_name,works_number
     *
     */

    public function getPersonalRecordCards() {


        $sql = sprintf("select L.*,C.title,C.description,C.validity_duration,C.validity_duration_period from %s.course_assignment_participant_link L inner join %s.trng_assign_course C on L.course_assignment_id=C.ID where participant_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->trainingInfo['partid']);

     $sql = $sql . " ORDER BY c.ID DESC";
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to view trainee personal record card
     */

    public function viewPersonalRecordCard() {
        
    }

    /*
     * This method is used to remove trainee personal record card
     */

    public function deletePersonalRecordCard() {

        $recordData = $this->viewCourseAssignedToTrainee();

        if ($recordData['uploadedFileID']) {
            $objFile = new Upload();

            $objFile->setFileInfo('training', array('id' => $recordData['uploadedFileID'], 'destination' => 'training'));
            $objFile->delete_file();
        }

        $sql2 = sprintf("DELETE FROM %s.trng_assign_course WHERE ID = %d", _DB_OBJ_FULL, $this->trainingId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->trainingId); */
        $pStatement2->execute();
    }

    /*
     * This method is used to get scheduled courses list
     * array variables : start_date,end_date,course_id
     */

    public function getScheduledCourses() {

        $start_date = date('m/d/Y', strtotime('-5 years'));
        $end_date = date('m/d/Y', strtotime('+5 years'));
        //$vstatements  	= array();


        if (isset($this->trainingInfo['start_date'])) {
            $start_date = format_date_for_mysql($this->trainingInfo['start_date']);
        }

        if (isset($this->trainingInfo['end_date'])) {
            $end_date = format_date_for_mysql($this->trainingInfo['end_date']);
        }

        //$vstatements[] = _DB_OBJ_FULL;
        $course_filter = '';
        $course_filter_clause = '';
        if (isset($this->trainingInfo['course'])) {
            $course_filter = "INNER JOIN " . _DB_OBJ_FULL . ".trng_course C ON C.cID=T.courseID";
            $course_filter_clause = " AND C.title LIKE '" . $this->trainingInfo['course'] . "%' ";
            //	$vstatements[] = _DB_OBJ_FULL;
        }

        //$vstatements[] = $start_date;
        //$vstatements[] = $end_date;

        $sql = sprintf("SELECT * FROM %s.trng_assign_course T %s WHERE T.assignDate > '%s' AND T.assignDate < '%s' %s", _DB_OBJ_FULL, $course_filter, $start_date, $end_date, $course_filter_clause);

        $sql = $sql . " ORDER BY ID DESC";

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$start_date);
          $pStatement->bindParam(2,$end_date); */

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to add training certificate
     */

    public function addTraineeCertificate() {

   echo     $sql3 = sprintf("UPDATE %s.trng_assign_course SET uploadedFileID = %d
												WHERE ID = %d", _DB_OBJ_FULL
                , $this->trainingInfo['file_id']
                , $this->trainingId);

        $pStatement3 = $this->dbHand->prepare($sql3);

        /* $pStatement3->bindParam(1,$this->trainingInfo['file_id']);
          $pStatement3->bindParam(2,$this->trainingId); */

        $pStatement3->execute();

        /* if ( !$pStatement3->execute() ) {
          dump_array($pStatement3->errorInfo());
          } */

        $pStatement3->execute();
    }

    /**
     * This methos is used to aad trg records
     */
    public function addTrgRecordDeprec() {

        $sql3 = sprintf("INSERT INTO %s.trng_assign_course (reference,uniqueReference,courseID,participantName,worksNumber,instructorID,
											roomID,assignDate,assignTime,refreshment,courseSeperator,attended,successfull)
										VALUES ('%s', '%s', %d, '%s', '%s', NULL, NULL, " . customCurrentDate() . ", '%s', NULL, '1','1','1')"
                , _DB_OBJ_FULL
                , $this->trainingInfo['reference']
                , $this->trainingInfo['unique_reference']
                , $this->trainingInfo['course_id']
                , $this->trainingInfo['participant_name']
                , $this->trainingInfo['works_number']
                , date('H:i:s'));

        $pStatement3 = $this->dbHand->prepare($sql3);

        /* $pStatement3->bindParam(1,$this->trainingInfo['reference']);
          $pStatement3->bindParam(2,$this->trainingInfo['unique_reference']);
          $pStatement3->bindParam(3,$this->trainingInfo['course_id']);
          $pStatement3->bindParam(4,$this->trainingInfo['participant_name']);
          $pStatement3->bindParam(5,$this->trainingInfo['works_number']);
          $pStatement3->bindParam(6,date('H:i:s')); */

        $pStatement3->execute();

        $this->trainingId = customLastInsertId($this->dbHand, 'trng_assign_course', 'ID');
    }

    public function addTrgRecord() {
        $unRefObj = new UniqueReference();

        $uniqueRefNo = $unRefObj->getUniqueNumber('TRAINING_ASSIGN_COURSE');
        $sql = sprintf("insert into %s.trng_assign_course (courseID,instructorID,roomID,certificateCostsYN,examCostsYN,certificateCost,examCost,title,validity_duration,validity_duration_period,reference,uniqueReference,assigndate,attended,successfull,description) 
select cid,instructorID,roomID,certificateCosts  ,examCosts,certificateCost,examCost,title,validityvalue,validityType,'%s','%s','%s','Y','Y',description from %s.trng_course where cid=%d", _DB_OBJ_FULL, $uniqueRefNo, $uniqueRefNo, $this->trainingInfo['date_of_completion'], _DB_OBJ_FULL, $this->trainingInfo['course_id']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $this->courseId = customLastInsertId($this->dbHand, 'trng_assign_course', 'ID');
//refnumber,assigndate,attended,sucessfull    



        $sql3 = sprintf("INSERT INTO %s.course_assignment_participant_link (course_assignment_id,participant_id,status,completion_date,upload_id,cost)
										VALUES (%d, %d, %d, '%s', %d,%d)"
                , _DB_OBJ_FULL
                , $this->courseId
                , $this->trainingInfo['part_id']
                , $this->trainingInfo['status']
                , $this->trainingInfo['date_of_completion']
                , $this->trainingInfo['fileid']
                , $this->trainingInfo['cost']
        );

        $pStatement3 = $this->dbHand->prepare($sql3);

        $pStatement3->execute();

        $this->trainingId = customLastInsertId($this->dbHand, 'trng_assign_course', 'ID');
    }

    public function getLastRecordId() {
        return $this->trainingId;
    }

    public function getListingforExport($p_listId) {

        switch ($p_listId) {
            case 1: $data = $this->getPlannedCoursesExportData();
                break;
            case 2: $data = $this->getConfirmedCoursesExportData();
                break;
            case 3: $data = $this->getTraineesExportData($p_listId);
                break;
            case 4: $data = $this->getTraineesExportData($p_listId);
                break;
            case 5: $data = $this->getTraineesExportData($p_listId);
                break;
            case 6: $data = $this->getCourseAssignedExportData();
                break;
            case 7: $data = $this->getTrainingScheduleExportData();
                break;
            case 8: $data = $this->getPersonalRecordExportData();
                break;
            case 9: $data = $this->getCompletedCoursesExportData();
                break;
            case 10: $data = $this->getTraineesExportData($p_listId);
                break;
            case 11: $data = $this->getTraineesExportData($p_listId);
                break;
        }

        return $data;
    }

    public function getPlannedCoursesExportData() {

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');

        $plannedCoursesData = $this->getCoursePlanned();

        $heading = array(array('Reference #', 'Course Title', 'Due Date', 'Room Number'));

        if (is_array($plannedCoursesData)) {

            foreach ($plannedCoursesData as $element) {

                $course_id = $element['courseID'];
                $room_id = $element['roomID'];

                $objTrainingCourse->setItemInfo(array('id' => $course_id));
                $courseData = $objTrainingCourse->displayItemById();

                $course_reference = $courseData['refNumber'];
                $course_title = $courseData['title'];

                $objTrainingRoom->setItemInfo(array('id' => $room_id));
                $roomData = $objTrainingRoom->displayItemById();
                $room_no = $roomData['roomNo'];

                $result[] = array($course_reference, $course_title, $element['assignDate'], $room_no);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getConfirmedCoursesExportData() {

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');

        $confirmedCoursesData = $this->getCourseConfirmed();

        $heading = array(array('Reference #', 'Course Title', 'Due Date', 'Room Number'));

        $unique_course_arr = array();

        if (is_array($confirmedCoursesData)) {

            foreach ($confirmedCoursesData as $element) {

                $key = $element['courseID'] . '&' . $element['assignDate'] . '&' . $element['courseSeperator'];

                if (!in_array($key, $unique_course_arr)) {

                    $course_id = $element['courseID'];
                    $room_id = $element['roomID'];

                    $objTrainingCourse->setItemInfo(array('id' => $course_id));
                    $courseData = $objTrainingCourse->displayItemById();

                    $course_reference = $courseData['refNumber'];
                    $course_title = $courseData['title'];

                    $objTrainingRoom->setItemInfo(array('id' => $room_id));
                    $roomData = $objTrainingRoom->displayItemById();

                    $room_no = $roomData['roomNo'];

                    $result[] = array($course_reference, $course_title, $element['assignDate'], $room_no);
                }

                $unique_course_arr[] = $key;
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getTraineesExportData($p_listId) {

        $list = $p_listId;

        $course_id = (int) $_GET['course_id'];
        $due_date = $_GET['due_date'];
        $course_sep = (int) $_GET['course_sep'];

        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');
        $objFile = new Upload();

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setTraineeInfo('', array(
            'course_id' => $course_id,
            'assign_date' => $due_date,
            'course_seperator' => $course_sep,
            'archive' => $archive_session
        ));

        $trainee_info = $this->getTraineesByCourse();

        //dump_array($trainee_info);

        $heading = array();

        if ($list == 3) {
            $heading = array(array('Reference #', 'Works No.', 'First Name', 'Last Name', 'Room No.'));
        } else if ($list == 4) {
            $heading = array(array('Reference #', 'Works No.', 'First Name', 'Last Name'));
        } else if ($list == 5) {
            $heading = array(array('Works No.', 'First Name', 'Last Name'));
        } else if ($list == 10) {
            $heading = array(array('Works No.', 'First Name', 'Last Name', 'Certificate', 'Date Completed', 'Due Date'));
        } else if ($list == 11) {
            $heading = array(array('Works No.', 'First Name', 'Last Name', 'Due Date'));
        }

        $result = array();

        if (is_array($trainee_info)) {

            foreach ($trainee_info as $element) {

                if ($list == 10) {

                    if ($element['completeDate'] == '') {
                        continue;
                    }
                }

                $participant_name = $element['participantName'];
                $participant_arr = explode(' ', $participant_name);

                $first_name = $participant_arr[0];
                $last_name = $participant_arr[1] . ' ' . $participant_arr[2];

                if ($element['assignDate'] != '') {
                    $due_date = format_date($element['assignDate']);
                }

                if ($list == 3) {

                    $room_id = $element['roomID'];
                    $objTrainingRoom->setItemInfo(array('id' => $room_id));
                    $roomData = $objTrainingRoom->displayItemById();

                    $room_no = $roomData['roomNo'];

                    $result[] = array($element['reference'], $element['worksNumber'], $first_name, $last_name, $room_no);
                } elseif ($list == 4) {

                    $result[] = array($element['reference'], $element['worksNumber'], $first_name, $last_name);
                } elseif ($list == 5) {

                    $result[] = array($element['worksNumber'], $first_name, $last_name);
                } else if ($list == 10) {

                    if ($element['completeDate'] != '') {
                        $complete_date = format_date($element['completeDate']);
                    }

                    $objFile->setFileInfo('training', array('id' => $element['uploadedFileID']));
                    $file_detail = $objFile->getFileDetails();

                    $result[] = array($element['worksNumber'], $first_name, $last_name, $file_detail['usrFilename'], $complete_date, $due_date);
                } else if ($list == 11) {

                    $result[] = array($element['worksNumber'], $first_name, $last_name, $due_date);
                }
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getCourseAssignedExportData() {

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');
        $participantObj = SetupGeneric::useModule('Participant');

        $assigned_course_data = $this->getCourseAssigned();

        $heading = array(array('Reference #', 'Works Number', 'Who', 'Course Title', 'Due Date', 'Room No.'));
        $result = array();

        if (is_array($assigned_course_data)) {

            $unique_course_arr = array();

            foreach ($assigned_course_data as $element) {

                $key = $element['courseID'] . '&' . $element['assignDate'] . '&' . $element['courseSeperator'];

                if (!in_array($key, $unique_course_arr)) {

                    $course_id = $element['courseID'];
                    $room_id = $element['roomID'];

                    $objTrainingCourse->setItemInfo(array('id' => $course_id));
                    $courseData = $objTrainingCourse->displayItemById();

                    $course_reference = $courseData['refNumber'];
                    $course_title = $courseData['title'];

                    $objTrainingRoom->setItemInfo(array('id' => $room_id));
                    $roomData = $objTrainingRoom->displayItemById();
                    $room_no = $roomData['roomNo'];

                    $participant_id = $element['whoID'];
                    $participantObj->setItemInfo(array('id' => $participant_id));
                    $partcipantData = $participantObj->displayItemById();
                    $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                    $due_date = format_date($element['assignDate']);

                    $result[] = array($course_reference, $element['worksNumber'], $participant_name, $course_title, $due_date, $room_no);
                }

                $unique_course_arr[] = $key;
            }
            //dump_array($result);
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getTrainingScheduleExportData() {

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');

        $data_array = array();

        $data_array['course'] = $_GET['course_title'];
        $data_array['start_date'] = $_GET['start_date'];
        $data_array['end_date'] = $_GET['end_date'];

        $this->setTraineeInfo(1, $data_array);
        $scheduled_courses = $this->getScheduledCourses();

        $heading = array(array('Course Title', 'Description', 'Room', 'Due date', 'No. of Attendants'));

        if (is_array($scheduled_courses)) {

            foreach ($scheduled_courses as $element) {

                $key = $element['courseID'] . '&' . $element['assignDate'] . '&' . $element['courseSeperator'];

                $course_id = $element['courseID'];
                $room_id = $element['roomID'];

                $objTrainingCourse->setItemInfo(array('id' => $course_id));
                $courseData = $objTrainingCourse->displayItemById();

                $course_reference = $courseData['refNumber'];
                $course_title = $courseData['title'];
                $description = $courseData['description'];

                $objTrainingRoom->setItemInfo(array('id' => $room_id));
                $roomData = $objTrainingRoom->displayItemById();
                $room_no = $roomData['roomNo'];

                $date = format_date($element['assignDate']);

                $course_list[$key]['course_title'] = $course_title;
                $course_list[$key]['description'] = $description;
                $course_list[$key]['course_date'] = $date;
                $course_list[$key]['room_no'] = $room_no;
                $course_list[$key]['attendent'] ++;
            }
        }

        $result = array_merge($heading, $course_list);
        return $result;
    }

    public function getPersonalRecordExportData() {

        $objFile = new Upload();
        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objPart = SetupGeneric::useModule('Participant');

        $works_no = $_GET['works_no'];
        $last_name = $_GET['last_name'];
        $part_id = $_GET['part_id'];
        $this->setTraineeInfo('', array('partid' => $part_id,'works_number' => $works_no, 'last_name' => $last_name));
        $traineeData = $this->getPersonalRecordCards();

        $heading = array(array(0=>'Works No.', 1=>'First Name',2=> 'Last Name',3=> 'Course Title',4=> 'Course Description',5=> 'Date Completed',6=>'Certificate',7=> 'Due Date',8=> 'Satisfactory' ));
$i=1;
        if (is_array($traineeData)) {
                $objPart->setItemInfo(array('id'=>$part_id));
                $partDetails= $objPart->displayItemById();
              $objFile = new Upload();
              
            foreach ($traineeData as $element) {

              // $result[$i][0] = $works_no;
             //   $result[$i][1] = $last_name;


                if ($element['assignDate']) {
                    $due_date = format_date($element['assignDate']);
                }

                if ($element['completeDate']) {
                    $complete_date = format_date($element['completeDate']);
                }


                $course_id = $element['courseID'];
                $objTrainingCourse->setItemInfo(array('id' => $course_id));
                $courseData = $objTrainingCourse->displayItemById();

                
                $course_title = $courseData['title'];
                //$objFile->setFileInfo('training', array('id' => $element['uploadedFileID']));
                $file_detail = $objFile->getFileDetails();
                $file_name = $file_detail['usrFilename'];
     
 $file_detail=$objFile->getFileData($element['upload_id']);

 if(is_array($file_detail))
 $filestr = $file_detail['usrFilename'];
else {
 
$filestr="-";
        
}

$status =($element['status'] & 32) == 32 ? "S" : "N/S";

$result[] = array(0=>$partDetails['worksNumber'], 1=>$partDetails['forename'],2=>$partDetails['surname'],3=>$element['title'],4=>$element['description'],5=>format_date($element['assignDate']),6=>$filestr,7=>format_date($element['completion_date']),8=>$status);
             //  $result[$i] = array($works_no, $first_name, $last_name, $course_title, $complete_date, $due_date, $file_name);
            $i++;    
            }
          
        }
if (is_array($result))
        $new_result = array_merge($heading, $result);
else
    $new_result = $heading;
        return $new_result;
    }

    public function getCompletedCoursesExportData() {

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');

        $data_array = array();

        $data_array['course'] = $_GET['course_title'];
        $data_array['start_date'] = $_GET['start_date'];
        $data_array['end_date'] = $_GET['end_date'];

        $this->setTraineeInfo(1, $data_array);
        $completedCourse = $this->getCourseCompleted();

        $heading = array(array('Reference #', 'Course Title', 'Due Date', 'Room Number'));
        $unique_course_arr = array();

        if (is_array($completedCourse)) {

            foreach ($completedCourse as $element) {

                $key = $element['courseID'] . '&' . $element['assignDate'] . '&' . $element['courseSeperator'];

                if (!in_array($key, $unique_course_arr)) {

                    $course_id = $element['courseID'];
                    $room_id = $element['roomID'];

                    $objTrainingCourse->setItemInfo(array('id' => $course_id));
                    $courseData = $objTrainingCourse->displayItemById();
                    $course_reference = $courseData['refNumber'];
                    $course_title = $courseData['title'];

                    $objTrainingRoom->setItemInfo(array('id' => $room_id));
                    $roomData = $objTrainingRoom->displayItemById();
                    $room_no = $roomData['roomNo'];

                    if ($element['assignDate'] != '') {

                        $due_date = format_date($element['assignDate']);
                    }

                    $result[] = array($course_reference, $course_title, $due_date, $room_no);
                }

                $unique_course_arr[] = $key;
            }
        }
if(is_array($result))
        $new_result = array_merge($heading, $result);
    else {
     $new_result = $heading;    
    }
        return $new_result;
    }

    public function getTotalCourseAllocated() {
        $sql = sprintf("SELECT participantName FROM %s.trng_assign_course WHERE courseID = %d AND assignDate = '%s' AND startTime = '%s' ORDER BY ID DESC",
                _DB_OBJ_FULL, $this->trainingId, $this->trainingInfo['due_date'], $this->trainingInfo['start_time']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$start_date);
          $pStatement->bindParam(2,$end_date); */

        $pStatement->execute();

        return $pStatement->fetch(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get the cron data
     */

    public function getCronData() {

        $current_date = $this->miscObj->getCurDate();
        $current_date_arr = explode('-', $current_date);
        $current_year = $current_date_arr[0];
        $current_month = $current_date_arr[1];
        $next_month = $current_month + 1;
        if ($next_month >= 13) {
            $current_year = $current_year + 1;
            $next_month = '01';
        }
        $next_month_date = $current_year . '-' . $next_month . '-01';
        $current_mnth_start_date = $current_date_arr[0] . '-' . $current_month . '-01';

        /* $sql1 = sprintf("SELECT * FROM %s.trng_assign_course WHERE assignDate > '%s' AND assignDate < '%s' ",_DB_OBJ_FULL,$current_mnth_start_date,$next_month_date); */
        $sql = sprintf("SELECT * FROM %s.trng_assign_course WHERE assignDate > '%s'", _DB_OBJ_FULL, $current_date);

        $sql = $sql . " ORDER BY ID DESC";
        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$next_month_date);

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function lastInsertId() {
        return $this->trainingId;
    }

    public function assignCourseTraniee($p_record_id) {
        $this->trainingId = $p_record_id;
        $data = $this->viewCourseAssignedToTrainee();

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');
        $participantObj = SetupGeneric::useModule('Participant');
        $objTrainingInstructor = SetupGeneric::useModule('TrainingInstructor');

        if (is_array($data)) {
            //foreach( $data as $value ) {

            $objTrainingCourse->setItemInfo(array('id' => $data['courseID']));
            $courseData = $objTrainingCourse->displayItemById();

            $objTrainingRoom->setItemInfo(array('id' => $data['roomID']));
            $roomData = $objTrainingRoom->displayItemById();

            $participantObj->setItemInfo(array('id' => 1, 'works_number' => $data['worksNumber']));
            $participantData = $participantObj->displayItemByWorksNumber();

            $objTrainingInstructor->setItemInfo(array('id' => $data['instructorID']));
            $instructor_data = $objTrainingInstructor->displayItemById();


            $email_data_primary['ref'] = $data['reference'];
            $email_data_primary['c_ref'] = $courseData['refNumber'];
            $email_data_primary['c_title'] = $courseData['title'];
            $email_data_primary['instructor'] = $instructor_data['fname'] . ' ' . $instructor_data['lname'];
            $email_data_primary['room'] = $roomData['roomNo'];
            $email_data_primary['assignDate'] = format_date($data['assignDate']);
            $email_data_primary['refreshment'] = $data['refreshment'];
            $email_data_primary['who'] = $participantData['participantID'];
            $email_data_primary['type'] = 'assign_training';
            $email_data_primary['start_time'] = $data['startTime'];
            //}
        }

        $email_data[0] = $email_data_primary;

        return $email_data;
    }

    public function assignCourseInst($p_record_id) {
        $this->trainingId = $p_record_id;
        $data = $this->viewCourseAssignedToTrainee();

        $objTrainingCourse = SetupGeneric::useModule('TrainingCourse');
        $objTrainingRoom = SetupGeneric::useModule('TrainingRoom');
        $objTrainingInstructor = SetupGeneric::useModule('TrainingInstructor');

        if (is_array($data)) {
            //foreach( $data as $value ) {

            $objTrainingCourse->setItemInfo(array('id' => $data['courseID']));
            $courseData = $objTrainingCourse->displayItemById();

            $objTrainingRoom->setItemInfo(array('id' => $data['roomID']));
            $roomData = $objTrainingRoom->displayItemById();

            $objTrainingInstructor->setItemInfo(array('id' => $data['instructorID']));
            $instructor_data = $objTrainingInstructor->displayItemById();


            $email_data_primary['ref'] = $data['reference'];
            $email_data_primary['c_ref'] = $courseData['refNumber'];
            $email_data_primary['c_title'] = $courseData['title'];
            $email_data_primary['participant'] = $data['participantName'];
            $email_data_primary['room'] = $roomData['roomNo'];
            $email_data_primary['assignDate'] = format_date($data['assignDate']);
            $email_data_primary['refreshment'] = $data['refreshment'];
            $email_data_primary['who'] = $data['instructorID'];
            $email_data_primary['inst_fname'] = $instructor_data['fname'];
            $email_data_primary['inst_lname'] = $instructor_data['lname'];
            $email_data_primary['email'] = $instructor_data['emailAddress'];
            $email_data_primary['type'] = 'assign_training_inst';
            $email_data_primary['start_time'] = $data['startTime'];
            //}
        }

        $email_data[0] = $email_data_primary;

        return $email_data;
    }

    public function moveCourseToPlanned($send_mail = false) {
        $sql3 = sprintf("SELECT * FROM %s.trng_assign_course
							WHERE courseID = %d AND assignDate = '%s' AND startTime = '%s'",
                _DB_OBJ_FULL
                , $this->trainingInfo['cid'], $this->trainingInfo['due_date'], $this->trainingInfo['start_time']);

        $pStatement3 = $this->dbHand->prepare($sql3);

        $pStatement3->execute();
        $records = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

        //dump_array($records);

        if (is_array($records)) {
            foreach ($records as $value) {

                if ($send_mail) {
                    $objAlert = new SendActionAlerts('trainingParticipant', $value['ID']);
                    $objAlert->sendAlerts();
                    $objAlert = null;

                    $objAlert = new SendActionAlerts('trainingInst', $value['ID']);
                    $objAlert->sendAlerts();
                    $objAlert = null;
                }

                $rec_ids .= $value['ID'] . ",";
            }

            if (!$send_mail) {
                $rec_ids = rtrim($rec_ids, ',');

                $sql_upd = sprintf("UPDATE %s.trng_assign_course SET isPlanned='1'
								WHERE ID IN(%s) ",
                        _DB_OBJ_FULL
                        , $rec_ids);

                $pStatement_upd = $this->dbHand->prepare($sql_upd);

                $pStatement_upd->execute();
                //dump_array($pStatement_upd->errorInfo());
            }
        }
    }

    public function updateIsGrouped($p_rec_id) {
        $sql3 = sprintf("UPDATE %s.trng_assign_course SET isGrouped = '1'
												WHERE ID = %d",
                _DB_OBJ_FULL
                , $p_rec_id);

        $pStatement3 = $this->dbHand->prepare($sql3);

        $pStatement3->execute();
    }

    public function updateIsGroupedMultiple() {

        if (is_array($this->trainingIdArr)) {
            foreach ($this->trainingIdArr as $trainingId) {

                $sql3 = sprintf("UPDATE %s.trng_assign_course
								SET isGrouped = '1'
								WHERE ID = %d",
                        _DB_OBJ_FULL
                        , $trainingId);

                $pStatement3 = $this->dbHand->prepare($sql3);
                $pStatement3->execute();
            }
        }
    }

    public function getFutureInvalidCourses() {

        $sql = sprintf("SELECT ID
						,A.reference
						,A.uniqueReference
						,courseID
						,participantName
						,worksNumber
						,completeDate
						,title
						,reoccuranceType
						,reoccuranceValue
					FROM %s.trng_assign_course A
					INNER JOIN %s.trng_course B
					ON A.courseID = B.cID
					WHERE completeDate IS NOT NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $records;
    }

    public function getDueCourses() {

        $sql = sprintf("SELECT ID
						,A.reference
						,A.uniqueReference
						,courseID
						,participantName
						,worksNumber
						,assignDate
						,title
						,reoccuranceType
						,reoccuranceValue
					FROM %s.trng_assign_course A
					INNER JOIN %s.trng_course B
					ON A.courseID = B.cID
					WHERE assignDate IS NOT NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $records;
    }

    public function checkInstructorRoom() {

        $arguments[] = _DB_OBJ_FULL;
        $arguments[] = format_date_for_mysql($this->trainingInfo['assign_date']);
        $arguments[] = $this->trainingInfo['start_time'];

        $sql_query = "SELECT * FROM %s.trng_assign_course WHERE assignDate = '%s' AND startTime = '%s' ";

        if ($this->trainingInfo['check'] == 'instructor') {
            $sql_query .= " AND instructorID = %d ORDER BY ID DESC";
            $arguments[] = $this->trainingInfo['instructor_id'];
        } else {
            $sql_query .= " AND roomID = %d ORDER BY ID DESC ";
            $arguments[] = $this->trainingInfo['room_id'];
        }

        $sql2 = vsprintf($sql_query, $arguments);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);
        return $result[0];
    }

    public function getTrainingEquipment() {
        $trn = "%TRG%";
        $sql = sprintf("SELECT * FROM %s.assestmangement WHERE flag_v like '%s'", _DB_OBJ_FULL, $trn);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getAssignedCourse($id) {


        $sql2 = sprintf("SELECT * FROM %s.trng_assign_course WHERE ID = %d ", _DB_OBJ_FULL, $id);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->trainingId); */
        $pStatement2->execute();
        $resultSet2 = $pStatement2->fetch(PDO::FETCH_ASSOC);

        return $resultSet2;
    }

    public function addTrgRecordPt1() {

//dump_array($this->trainingInfo);
        $sql = sprintf("insert into %s.trng_assign_course (courseID,certificateCostsYN,examCostsYN,certificateCost,examCost,title,validity_duration,validity_duration_period,course_duration,course_duration_period,reference,uniqueReference,description,pov,max_seats,classification,buID) VALUES (
%d,'%s','%s',%d,%d,'%s','%d','%s','%d','%s','%s','%s','%s','%s',%d,%d,%d)"
                , _DB_OBJ_FULL
                , $this->trainingInfo['course_id']
                , $this->trainingInfo['certificateCostsYN']
                , $this->trainingInfo['examYN']
                , $this->trainingInfo['certificateCost']
                , $this->trainingInfo['exam']
                , $this->trainingInfo['title']
                , $this->trainingInfo['validity_period']
                , $this->trainingInfo['validity_period_unit']
                , $this->trainingInfo['course_duration']
                , $this->trainingInfo['course_duration_unit']
                , $this->trainingInfo['unique_reference']
                , $this->trainingInfo['unique_reference']
                , $this->trainingInfo['description']
                , $this->trainingInfo['pov']
                , $this->trainingInfo['max_seats']
                , $this->trainingInfo['classification']
                , $this->trainingInfo['bus'][0]
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $this->courseId = customLastInsertId($this->dbHand, 'trng_assign_course', 'ID');
        return $this->courseId;
    }

    public function addTraineeRecord($partID) {
        $this->trainingInfo['part_id'] = $partID;
  
        $sql = sprintf("INSERT INTO %s.course_assignment_participant_link (course_assignment_id,participant_id,status,completion_date,upload_id,cost)
    
										VALUES (%d, %d, %d, '%s', %d,%d)"
        , _DB_OBJ_FULL
        , $this->trainingInfo['id']
        , $this->trainingInfo['part_id']
        , $this->trainingInfo['status']
        , $this->trainingInfo['duedate']
        , $this->trainingInfo['fileid']
        , $this->trainingInfo['cost']
        );
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

}

?>