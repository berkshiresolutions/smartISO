<?php
 /**
  $Id: ExportData.class.php,v 3.62 Monday, January 31, 2011 12:04:24 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Thursday, January 13, 2011 3:23:19 PM>
  */


class ExportData
{

	private $fileName;
	private $modulename;
	private $exportType;
	private $allowedExportTypes;
	private $exportObject;
	public $exportData;

	public function __construct($p_modulename,$p_exportType='csv',$p_fileName='temporary') {

		$this->dbHand = DB::connect(_DB_TYPE);

		$this->allowedExportTypes = array('csv','pdf');

		$this->fileName		= $p_fileName.".".strtolower($p_exportType);
		$this->modulename 	= $p_modulename;
		$this->exportType 	= $p_exportType;

		$classname = 'ExportData'.ucfirst($p_exportType);
		$this->exportObject = new $classname($p_modulename);

	}

	private function getModuleObject() {

		switch ($this->modulename) {
			case 'employementtype': return new EmploymentTypeSetup(); break;
			case 'participants': return new ParticipantSetup(); break;
			case 'docClassification': return new DocClassificationSetup(); break;
			case 'equipClassification': return new EquipmentClassificationSetup(); break;
			case 'managementElements': return new ManagementElementSetup(); break;
			case 'smartlaw': return new SmartLawSetup(); break;
			case 'trainingcourse': return new TrainingCourseSetup(); break;
			case 'traininginstructor': return new TrainingInstructorSetup(); break;
			case 'trainingroom': return new TrainingRoomSetup(); break;
			case 'authoriseduser': return new AuthorizedUserSetup(); break;
			case 'equipmentsetup': return SetupGeneric::useModule('Equipment'); break;
			case 'control': return SetupGeneric::useModule('ControlMeasure'); break;
			case 'hazards': return SetupGeneric::useModule('HazardClassification'); break;
			case 'hazardlists': return SetupGeneric::useModule('Hazard'); break;
			case 'impact': return SetupGeneric::useModule('ImpactMeasure'); break;
			case 'typetreatment': return SetupGeneric::useModule('IncidenceDetail'); break;
			case 'accidentoccured': return SetupGeneric::useModule('IncidenceDetail'); break;
			case 'partbody': return SetupGeneric::useModule('IncidenceDetail'); break;
			case 'nature': return SetupGeneric::useModule('IncidenceDetail'); break;
			case 'additionalfactor': return SetupGeneric::useModule('IncidenceDetail'); break;
			case 'incidentanalysis': return SetupGeneric::useModule('Investigation'); break;
			case 'immediatecauses': return SetupGeneric::useModule('Investigation'); break;
			case 'basiccauses': return SetupGeneric::useModule('Investigation'); break;
			case 'netimpact': return SetupGeneric::useModule('NetImpact'); break;
			case 'enviornmentaltype': return SetupGeneric::useModule('NhpOption'); break;
			case 'enviornmentalscale': return SetupGeneric::useModule('NhpOption'); break;
			case 'disposition': return SetupGeneric::useModule('NhpOption'); break;
			case 'contractors': return new Contractor(); break;
			case 'dseAssessment': return new DseAssessment(); break;
			case 'equipment': return new Equipment(); break;
			case 'manualHandling': return new ManualHandling(); break;
			case 'trainingMod': return new Training(); break;
			case 'Inspection': return new InspectionMain(); break;
			case 'incidence': return new IncidenceMain(); break;
			case 'investigation': return new InvestigationMain(); break;
			case 'nhp': return new NhpMain(); break;
			case 'risk27k': return new Risk27k(); break;
			case 'risk': return new RiskAssessment(); break;
			case 'processFlow': return new ProcessFlowMaster(); break;
			case 'systemReviews': return new ReviewMain(); break;
			//case 'smartLaw': return new SmartLaw(); break;
		}
	}

	private function getListingData() {

		$obj = $this->getModuleObject();
		//$this->exportData = $obj->getListingData();

		$list = (int) $_GET['list'];

		if ($list) {
			$this->exportData = $obj->getListingforExport($list);
		} else {
			$this->exportData = $obj->getListingforExport();
		}

		//dump_array($this->exportData);
		//$listing_data = $this->exportData;
		//return $listing_data;
	}

	public function downloadFile() {

		$this->fileName;

		$this->getListingData();
		//dump_array($this);
		$this->exportObject->downloadFile( $this);
	}
}
?>