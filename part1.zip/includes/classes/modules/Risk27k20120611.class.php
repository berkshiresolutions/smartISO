<?php
 /**
  $Id: Risk27k.class.php,v 3.53 Thursday, February 03, 2011 4:23:33 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, October 18, 2010 4:13:07 PM>
  */

/*require_once "Risk27k.int.php";*/
require_once "Action.class.php";

class Risk27k// implements Risk27kInterface
{

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Risk 27k Id
	 *@access private
	 */
	private $Risk27kId;

	/**
	 *Property to hold Risk 27k Info
	 *@access private
	 */
	private $Risk27kInfo;


	/**
	 * Constructor for initializing Risk 27k object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/**
	 * to set Risk 27k information for performing various operations with the Risk 27k object
	 * $p_Risk27kId,$p_Risk27kInfo
	 */
	public function setRisk27kInfo($p_Risk27kId,$p_Risk27kInfo) {
//dump_array($p_Risk27kInfo);
		$this->Risk27kId	 = $p_Risk27kId;
		$this->Risk27kInfo	 = $p_Risk27kInfo;
	}

	/**
	 * This method is used to add a new Risk 27k
	 *
	 * Array Variables : reference,unique_reference,description,location,who,business_unit,when
	 */
	public function addRisk27k() {

		$sql = sprintf("INSERT INTO %s.risk27k (reference ,uniqueReference ,description, locID ,who ,businessUnit ,whenDate )
						VALUES ( '%s' ,'%s' ,'%s' ,%d ,%d ,%d, '%s' )"
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['reference']
						,$this->Risk27kInfo['unique_reference']
						,$this->Risk27kInfo['description']
						,$this->Risk27kInfo['location']
						,$this->Risk27kInfo['who']
						,$this->Risk27kInfo['business_unit']
						,format_date_for_mysql($this->Risk27kInfo['whenDate']));

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['reference']);
		$pStatement->bindParam(2,$this->Risk27kInfo['unique_reference']);
		$pStatement->bindParam(3,$this->Risk27kInfo['description']);
		$pStatement->bindParam(4,$this->Risk27kInfo['location']);
		$pStatement->bindParam(5,$this->Risk27kInfo['who']);
		$pStatement->bindParam(6,$this->Risk27kInfo['business_unit']);
		$pStatement->bindParam(7,format_date_for_mysql($this->Risk27kInfo['when']));*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

		//$this->Risk27kId = $this->dbHand->lastInsertId();
		$this->Risk27kId = customLastInsertId( $this->dbHand,'risk27k','ID');
	}

	public function addRisk27kDeleteAssest() {

		$sql1 = sprintf("DELETE FROM %s.risk27kAssest WHERE recordID = %d ",_DB_OBJ_FULL,$this->Risk27kId);

	$pStatement = $this->dbHand->prepare($sql1);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();


	}

	public function addRisk27kDeleteThreat() {
		$sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'threats' ",_DB_OBJ_FULL,$this->Risk27kId);

	$pStatement = $this->dbHand->prepare($sql1);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();


	}

	public function addRisk27kDeleteImprovements() {
		$sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'improvements' ",_DB_OBJ_FULL,$this->Risk27kId);

	$pStatement = $this->dbHand->prepare($sql1);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();


	}
	public function addRisk27kDeleteControls() {
		$sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'controls' ",_DB_OBJ_FULL,$this->Risk27kId);

	$pStatement = $this->dbHand->prepare($sql1);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();


	}


	public function addRisk27kDeleteEquipment() {

		$sql1 = sprintf("DELETE FROM %s.risk27kaddEquipment WHERE recordID = %d ",_DB_OBJ_FULL,$this->Risk27kId);

	$pStatement = $this->dbHand->prepare($sql1);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();


	}

	public function addRisk27kAsses() {

		if ( count($this->Risk27kInfo) > 0 ) {

			$ins = "INSERT INTO %s.risk27kAssest (recordID ,assestClass ,assestType, assestComment) VALUES";
			$ins = sprintf($ins,_DB_OBJ_FULL);
			$dataArray = array();

			for ($k=0;$k<count($this->Risk27kInfo);$k++) {

				$ins .= "( %d ,'%s' ,'%s' ,'%s'),";

				$dataArray[] 	= $this->Risk27kId;
				$dataArray[] 	= $this->Risk27kInfo[$k]['class'];
				$dataArray[] 	= implode(",",$this->Risk27kInfo[$k]['type']);
				$dataArray[] 	= $this->Risk27kInfo[$k]['comment'];
			}

			$ins = rtrim($ins,",");
			$ins = vprintf($ins,$dataArray);

			if ( count($dataArray) > 0  ) {
				$pStatement = $this->dbHand->prepare($ins);
				$pStatement->execute();
			}
		}
	}

	public function addRisk27kThreats() {


	$sql = sprintf("INSERT INTO %s.risk27kReport (recordID ,name ,details,comment)
						VALUES ( %d ,'%s' ,%d,'%s')"
						,_DB_OBJ_FULL
						,$this->Risk27kId
						,$this->Risk27kInfo['name']
						,$this->Risk27kInfo['nameID']
						,$this->Risk27kInfo['comment']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['reference']);
		$pStatement->bindParam(2,$this->Risk27kInfo['unique_reference']);
		$pStatement->bindParam(3,$this->Risk27kInfo['description']);
		$pStatement->bindParam(4,$this->Risk27kInfo['location']);
		$pStatement->bindParam(5,$this->Risk27kInfo['who']);
		$pStatement->bindParam(6,$this->Risk27kInfo['business_unit']);
		$pStatement->bindParam(7,format_date_for_mysql($this->Risk27kInfo['when']));*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

		//$this->Risk27kId = $this->dbHand->lastInsertId();
	}

	public function addSoaData() {


	$sql = sprintf("INSERT INTO %s.soaAnswerData(questionID ,answer,ref,detail,reviewID)
						VALUES ( %d ,'%s' ,'%s','%s',%d)"
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['question_id']
						,$this->Risk27kInfo['answer']
						,$this->Risk27kInfo['ref']
						,$this->Risk27kInfo['detail']
						,$this->Risk27kInfo['reviewID']
						);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['reference']);
		$pStatement->bindParam(2,$this->Risk27kInfo['unique_reference']);
		$pStatement->bindParam(3,$this->Risk27kInfo['description']);
		$pStatement->bindParam(4,$this->Risk27kInfo['location']);
		$pStatement->bindParam(5,$this->Risk27kInfo['who']);
		$pStatement->bindParam(6,$this->Risk27kInfo['business_unit']);
		$pStatement->bindParam(7,format_date_for_mysql($this->Risk27kInfo['when']));*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

		//$this->Risk27kId = $this->dbHand->lastInsertId();
	}

	public function addSoaReview() {


	$sql = sprintf("INSERT INTO %s.soaReview(soaName,startDate,tim,location)
						VALUES ('%s' ,'%s' ,'%s','%s')"
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['name']
						,$this->Risk27kInfo['date']
						,$this->Risk27kInfo['time']
						,$this->Risk27kInfo['location']
						);

		$pStatement = $this->dbHand->prepare($sql);



		$pStatement->execute();


		$this->Risk27kId = customLastInsertId( $this->dbHand,'soaReview','ID');
	}
	public function deleteAnswer() {

		//$sql = "SELECT * FROM assest_classification WHERE aID = %d ";
		$sql = "DELETE FROM %s.soaAnswerData WHERE questionID = %d AND reviewID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->Risk27kInfo['question_id'],$this->Risk27kInfo['reviewID']);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		//$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		//return $result;
	}

	public function getAnswers() {

	$sql = sprintf("SELECT *
				FROM %s.soaAnswerData WHERE  reviewID = %d ",_DB_OBJ_FULL,$this->Risk27kInfo['reviewID']);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$this->reviewID);
		$stmt->execute();

		$rec = $stmt->fetchAll(PDO::FETCH_ASSOC);
		//$questions = explode(',',$rec['controlQuestion']);
		//dump_array($questions);
		//$questionsCount = count($questions);

	//	$questionList = array();

	//	for ($i=0;$i<$questionsCount;$i++) {
		//	$k = $i + 1;
		//	$questionList[$k] = $questions[$i];
	//	} // end for

		return $rec;
	}

	public function getAnswer() {

	$sql = sprintf("SELECT *
				FROM %s.soaAnswerData WHERE questionID = %d AND reviewID = %d ",_DB_OBJ_FULL,$this->Risk27kId,$this->Risk27kInfo['reviewID']);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$this->reviewID);
		$stmt->execute();

		$rec = $stmt->fetch(PDO::FETCH_ASSOC);
		//$questions = explode(',',$rec['controlQuestion']);
		//dump_array($questions);
		//$questionsCount = count($questions);

	//	$questionList = array();

	//	for ($i=0;$i<$questionsCount;$i++) {
		//	$k = $i + 1;
		//	$questionList[$k] = $questions[$i];
	//	} // end for

		return $rec;
	}


	public function addRisk27kEquipment() {


	$sql = sprintf("INSERT INTO %s.risk27kaddEquipment (recordID ,addEquipment)
						VALUES ( %d ,'%s')"
						,_DB_OBJ_FULL
						,$this->Risk27kId
						,$this->Risk27kInfo['equipment']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['reference']);
		$pStatement->bindParam(2,$this->Risk27kInfo['unique_reference']);
		$pStatement->bindParam(3,$this->Risk27kInfo['description']);
		$pStatement->bindParam(4,$this->Risk27kInfo['location']);
		$pStatement->bindParam(5,$this->Risk27kInfo['who']);
		$pStatement->bindParam(6,$this->Risk27kInfo['business_unit']);
		$pStatement->bindParam(7,format_date_for_mysql($this->Risk27kInfo['when']));*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

		//$this->Risk27kId = $this->dbHand->lastInsertId();
	}



	/**
	 * This method is used to view the Risk 27k information.
	 */
	public function viewRisk27k() {



		$sql = sprintf("SELECT * FROM %s.risk27k WHERE ID = %d ",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function viewRisk27kAssest() {

		$sql = sprintf("SELECT * FROM %s.risk27kAssest WHERE recordID = %d ",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}


public function viewRisk27kThreat() {

		$sql = sprintf("SELECT * FROM %s.risk27kReport WHERE recordID = %d  AND name = 'threats'",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function viewRisk27kaddEquipment() {

		$sql = sprintf("SELECT * FROM %s.risk27kaddEquipment WHERE recordID = %d ",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function viewParticipantRisk27k() {

		$sql = sprintf("SELECT * FROM %s.participant_locationgram WHERE participantID = %d  AND sectionName ='risk27k'",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to edit the Risk 27k
	 *
	 * Array Variables : description,who,business_unit,when
	 */
	public function editRisk27k() {

		$sql = sprintf("UPDATE %s.risk27k SET description = '%s' ,
									who = %d ,
									businessUnit = %d ,
									whenDate = '%s'
									WHERE ID = %d"
									,_DB_OBJ_FULL
									,$this->Risk27kInfo['description']
									,$this->Risk27kInfo['who']
									,$this->Risk27kInfo['business_unit']
									,format_date_for_mysql($this->Risk27kInfo['whenDate'])
									,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['description']);
		$pStatement->bindParam(2,$this->Risk27kInfo['who']);
		$pStatement->bindParam(3,$this->Risk27kInfo['business_unit']);
		$pStatement->bindParam(4,format_date_for_mysql($this->Risk27kInfo['when']));
		$pStatement->bindParam(5,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage Assets
	 *
	 * Array Variables : assets,assets_reason
	 */
	public function manageAssets() {

		$sql = sprintf("UPDATE %s.risk27k SET assets = '%s' ,
						assetsReason = '%s',
						addEquipment = '%s'
						WHERE ID = %d "
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['assets']
						,$this->Risk27kInfo['assets_reason']
						,$this->Risk27kInfo['add_equip']

						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['assets']);
		$pStatement->bindParam(2,$this->Risk27kInfo['assets_reason']);
		$pStatement->bindParam(3,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage threats
	 *
	 * Array Variables : threats,threats_summary,no_threat,threats_reason
	 */
	public function manageThreats() {

		$sql = sprintf("UPDATE %s.risk27k SET threats = '%s' ,
						threatsSummary = '%s',
						noThreat = '%s',
						threatReason = '%s'
						WHERE ID = %d "
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['threats']
						,$this->Risk27kInfo['threats_summary']
						,$this->Risk27kInfo['no_threat']
						,$this->Risk27kInfo['threats_reason']
						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['threats']);
		$pStatement->bindParam(2,$this->Risk27kInfo['threats_summary']);
		$pStatement->bindParam(3,$this->Risk27kInfo['no_threat']);
		$pStatement->bindParam(4,$this->Risk27kInfo['threats_reason']);
		$pStatement->bindParam(5,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage CIA
	 *
	 * Array Variables : cia_confidentiality,cia_integrity,cia_availability
	 */
	public function manageCia() {

		$sql = sprintf("UPDATE %s.risk27k SET ciaConfidentiality = %d ,
						ciaIntegrity = %d,
						ciaAvailability = %d
						WHERE ID = %d "
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['cia_confidentiality']
						,$this->Risk27kInfo['cia_integrity']
						,$this->Risk27kInfo['cia_availability']
						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['cia_confidentiality']);
		$pStatement->bindParam(2,$this->Risk27kInfo['cia_integrity']);
		$pStatement->bindParam(3,$this->Risk27kInfo['cia_availability']);
		$pStatement->bindParam(4,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage Risk Rating 1
	 *
	 * Array Variables : likelihood,impact,risk_rating,risk_rating_color
	 */
	public function manageRiskRating1() {

		$sql = sprintf("UPDATE %s.risk27k SET likelihood1 = %d,
									impact1 = %d,
									riskRating1 = '%s',
									riskRatingColor1 = '%s'
									WHERE ID = %d "
									,_DB_OBJ_FULL
									,$this->Risk27kInfo['likelihood']
									,$this->Risk27kInfo['impact']
									,$this->Risk27kInfo['risk_rating']
									,$this->Risk27kInfo['risk_rating_color']
									,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['likelihood']);
		$pStatement->bindParam(2,$this->Risk27kInfo['impact']);
		$pStatement->bindParam(3,$this->Risk27kInfo['risk_rating']);
		$pStatement->bindParam(4,$this->Risk27kInfo['risk_rating_color']);
		$pStatement->bindParam(5,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage improvement
	 *
	 * Array Variables : source,path,worker,no_improvement,improvement_reason,improvement_ids = array(),
	 * improvement = array()
	 */
	public function manageImprovement() {

		$sql = sprintf("UPDATE %s.risk27k SET atSource = '%s' ,
									atPath = '%s',
									atWorker = '%s',
									noImprovement = '%s',
									improvementReason = '%s'
									WHERE ID = %d "
									,_DB_OBJ_FULL
									,$this->Risk27kInfo['source']
									,$this->Risk27kInfo['path']
									,$this->Risk27kInfo['worker']
									,$this->Risk27kInfo['no_improvement']
									,$this->Risk27kInfo['improvement_reason']
									,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['source']);
		$pStatement->bindParam(2,$this->Risk27kInfo['path']);
		$pStatement->bindParam(3,$this->Risk27kInfo['worker']);
		$pStatement->bindParam(4,$this->Risk27kInfo['no_improvement']);
		$pStatement->bindParam(5,$this->Risk27kInfo['improvement_reason']);
		$pStatement->bindParam(6,$this->Risk27kId);*/

		$pStatement->execute();

		if ( count($this->Risk27kInfo['improvement_ids']) ) {
			$improvement_ids = "";
			foreach ( $this->Risk27kInfo['improvement_ids'] as $key=>$value ) {

				if ( !$value ) {
					// add action
					$this->actionData = array('module_name'=>'risk27k','description'=>$this->Risk27kInfo['improvement'][$key],'who'=>0,'due_date'=>'01/01/1900');
					$this->actionHandling->setActionDetails(0,$this->actionData);
					$action_id = $this->actionHandling->addAction();
					$improvements .= $action_id.',';

				} else {

					// update action
					$this->actionHandling->setActionDetails($value,"");
					$improvement = $this->actionHandling->viewAction();

					$imp_date = $improvement['dueDate'] == '1900-01-01' ? '01/01/1900' : format_date($improvement['dueDate']);

					$this->actionData = array('description'=>$this->Risk27kInfo['improvement'][$key],'who'=>$improvement['who'],'due_date'=>$imp_date);
					$this->actionHandling->setActionDetails($value,$this->actionData);
					$action_id = $this->actionHandling->updateAction();
					$improvements .= $value.',';
				}
			}

			$improvements = rtrim($improvements,',');
		}

		if ( $this->Risk27kInfo['no_improvement'] ) {
			$risk_data = $this->viewRisk27k();

			//echo $risk_data['improvements'];

			if ( $risk_data['improvements'] != "" || $risk_data['improvements'] != 0) {

				$improvements_arr = explode(',',$risk_data['improvements']);
				if ( count($improvements_arr) ) {
					foreach ($improvements_arr as $value ) {
						$this->actionHandling->setActionDetails($value,"");
						$improvement = $this->actionHandling->deleteAction();
					}
				}
			}

			$improvements = 0;
		}


		$sql = sprintf("UPDATE %s.risk27k SET improvements = '%s'
						WHERE ID = %d ",_DB_OBJ_FULL,$improvements,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$improvements);
		$pStatement->bindParam(2,$this->Risk27kId);*/

		$pStatement->execute();

	}

	/**
	 * This method is used to update files id
	 */
	public function addFiles() {

		$record_data = $this->viewRisk27k();

		$new_files_id_string = $record_data['uploadFilesID'].','.$this->Risk27kInfo['file_id'];
		$new_files_id_string = ltrim($new_files_id_string,',');

		$sql2 = sprintf(" UPDATE %s.risk27k SET uploadFilesID = %d WHERE
						ID = %d",_DB_OBJ_FULL,$new_files_id_string,$this->Risk27kId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_files_id_string);
		$pStatement2->bindParam(2,$this->Risk27kId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to delete file id
	 */
	public function deleteFile() {

		$record_data = $this->viewRisk27k();

		$files_id_arr = explode(',',$record_data['uploadFilesID']);

		if ( count($files_id_arr) ) {
			foreach ( $files_id_arr as $value ) {
				if ( $value != $this->Risk27kInfo['file_id'] ) {
					$new_files_id_string .= $value.',';
				}
			}
			$new_files_id_string = rtrim($new_files_id_string,',');

			$sql2 = sprintf(" UPDATE %s.risk27k SET uploadFilesID = %d WHERE
							ID = %d"
							,_DB_OBJ_FULL
							,$new_files_id_string
							,$this->Risk27kId);

			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$new_files_id_string);
			$pStatement2->bindParam(2,$this->Risk27kId);*/

			$pStatement2->execute();
		}

	}

	/**
	 * This method is used to manage risk rating 2
	 *
	 * Array Variables : likelihood,impact,risk_rating,risk_rating_color
	 */
	public function manageRiskRating2() {

		$sql = sprintf("UPDATE %s.risk27k SET likelihood2 = %d ,
						impact2 = %d,
						riskRating2 = '%s',
						riskRatingColor2 = '%s'
						WHERE ID = %d "
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['likelihood']
						,$this->Risk27kInfo['impact']
						,$this->Risk27kInfo['risk_rating']
						,$this->Risk27kInfo['risk_rating_color']
						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['likelihood']);
		$pStatement->bindParam(2,$this->Risk27kInfo['impact']);
		$pStatement->bindParam(3,$this->Risk27kInfo['risk_rating']);
		$pStatement->bindParam(4,$this->Risk27kInfo['risk_rating_color']);
		$pStatement->bindParam(5,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage priority
	 *
	 * Array Variables : time_trouble,net_impact,priority
	 */
	public function managePriority() {

		$sql = sprintf("UPDATE %s.risk27k SET timeTrouble = %d ,
						netImpact = %d,
						priority = '%s'
						WHERE ID = '%s' "
						,_DB_OBJ_FULL
						,$this->Risk27kInfo['time_trouble']
						,$this->Risk27kInfo['net_impact']
						,$this->Risk27kInfo['priority']
						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['time_trouble']);
		$pStatement->bindParam(2,$this->Risk27kInfo['net_impact']);
		$pStatement->bindParam(3,$this->Risk27kInfo['priority']);
		$pStatement->bindParam(4,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage action
	 *
	 * Array Variables : improvement,who,when,improvement_id
	 */
	public function manageAction() {

		$this->actionData = array('description'=>$this->Risk27kInfo['improvement'],'who'=>$this->Risk27kInfo['who'],'whoAU'=>$this->Risk27kInfo['whoAU'],
								  'due_date'=>$this->Risk27kInfo['when']);
		$this->actionHandling->setActionDetails($this->Risk27kInfo['improvement_id'],$this->actionData);

		$save_finish = (int) $_POST['save_finish'];

		if ( $save_finish && Session::getSessionField('action') == 'edit' ) {

			$actTriggerObj = new ActionEditTriggers();
			$actTriggerObj->setActionTriggerDetails('risk27k',$value['action_id'],$this->Risk27kId,array(
																									'new_who' => $this->Risk27kInfo['who'],
																									'new_whoAU' => $this->Risk27kInfo['whoAU']
																											 ));

			$actTriggerObj->beforeUpdateTrigger();
		}

		$action_id = $this->actionHandling->updateAction();

		if ( $save_finish && Session::getSessionField('action') == 'edit' ) {
			$actTriggerObj->afterUpdateTrigger();
			$actTriggerObj = null;
		}
	}

	/**
	 * This method is used to view the improvement Risk 27k information.
	 */
	public function viewImprovementRisk27k() {

		$sql = sprintf("SELECT atSource,atPath,atWorker,improvements,noImprovement,improvementReason FROM %s.risk27k
					   WHERE ID = %d",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {

			if ( $resultSet[0]['improvements'] != "" ) {

				$improvement_arr = explode(',',$resultSet[0]['improvements']);

				if ( count($improvement_arr) ) {
					foreach ($improvement_arr as $value ) {
						$this->actionHandling->setActionDetails($value,"");
						$improvement = $this->actionHandling->viewAction();
						$riskImprovements[$value] = $improvement;
					}
				}

				$resultSet[0]['improvements'] = $riskImprovements;
			}
		}
		return $resultSet[0];
	}

	/**
	 * This method is used to delete the Risk 27k
	 */
	public function deleteRisk27k() {

		$sql = sprintf("DELETE FROM %s.risk27k WHERE ID = %d",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kId);*/
		$pStatement->execute();
	}

	/**
	 * This method is used to archive the Risk 27k
	 */
	public function archiveRisk27k() {

		$sql = sprintf("UPDATE %s.risk27k SET archive = '%s' WHERE ID = %d",_DB_OBJ_FULL,$this->Risk27kInfo['archive'],$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
	}

	/**
	 * This method is used to remove the Risk 27k
	 */
	public function purgeRisk27k() {}

	/**
	 * This method is used to get last record id
	 */
	public function lastRecordId() {
		return $this->Risk27kId;
	}

	/**
	 * This method is used to view  All the Risk 27k information.
	 */
	public function viewAllRisk27k() {
		$sql = sprintf("SELECT * FROM %s.risk27k  ORDER BY ID DESC",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to view  All the Risk 27k information.
	 */
	public function getRisk27kByLocation() {
		$sql = sprintf("SELECT * FROM %s.risk27k WHERE locID = %d",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->Risk27kId);*/
		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('risk27k');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('risk27k');
		}

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT M.reference,M.businessUnit,M.ID AS risk_id FROM %s.risk27k M
								WHERE M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' "
								,_DB_OBJ_FULL
								,$search_value1
								,$search_value2
								,$search_value3
								,$search_value4);

				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$search_value1);
				$pStatement->bindParam(2,$search_value2);
				$pStatement->bindParam(3,$search_value3);
				$pStatement->bindParam(4,$search_value4);*/

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['businessUnit'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['risk_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function addOutstandingAction() {

		$sql = sprintf("SELECT improvements FROM %s.risk27k WHERE ID = %d ",_DB_OBJ_FULL,$this->Risk27kId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->Risk27kId);
		$pStatement->execute();

		$improvements = $pStatement->fetchColumn();
		$new_improvements = $improvements.','.$this->Risk27kInfo['new_improvement'];

		$sql2 = sprintf("UPDATE %s.risk27k SET improvements = '%s' WHERE ID = %d "
						,_DB_OBJ_FULL
						,$new_improvements
						,$this->Risk27kId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_improvements);
		$pStatement2->bindParam(2,$this->Risk27kId);*/
		$pStatement2->execute();
	}

	public function updateStatus() {

		$sql = sprintf("UPDATE %s.risk27k SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kId);*/
		$pStatement->execute();
	}

	public function sendActionAlerts($p_record_id) {

		$this->Risk27kId = $p_record_id;

		$record_data = $this->viewRisk27k();
		$improvement_data = $this->viewImprovementRisk27k();

		if ( count($improvement_data['improvements']) ) {
			$i = 0;
			foreach ( $improvement_data['improvements'] as $value ) {
				$email_data[$i]['reference']	 = $record_data['reference'];
				$email_data[$i]['summary']		 = $value['actionDescription'];
				$email_data[$i]['due_date']		 = format_date($value['dueDate']);
				$email_data[$i]['who']			 = $value['who'];
				$email_data[$i]['whoAU']			 = $value['whoAU'];

				$this->actionHandling->updateStatus($value['ID']);
				$i++;
			}
		}

		/*dump_array($email_data);
		exit;*/

		return $email_data;
	}

	/**
	 * This method is used to manage Control Tab data
	 */
	public function updateControl() {

		$sql = sprintf("UPDATE %s.risk27k SET controlAlongPath = %d,
									controlAlongWorker = %d,
									controlSymbols = '%s',
									controlSummary = '%s'
								WHERE ID = %d"
								,_DB_OBJ_FULL
								,$this->Risk27kInfo['along_path']
								,$this->Risk27kInfo['at_worker']
								,$this->Risk27kInfo['control_symbol']
								,$this->Risk27kInfo['control_summary']
								,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kInfo['along_path']);
		$pStatement->bindParam(2,$this->Risk27kInfo['at_worker']);
		$pStatement->bindParam(3,$this->Risk27kInfo['control_symbol']);
		$pStatement->bindParam(4,$this->Risk27kInfo['control_summary']);
		$pStatement->bindParam(5,$this->Risk27kId);*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

	}

	/**
	 * This method is used to add an risk 27 k control files
	 * id, uploadfilesid
	 */
	public function addControlFile() {

		$files_arr = $this->getControlFile();
		$files = implode(',',$files_arr);

		$new_files = $files.','.$this->Risk27kInfo['file_id'];

		$sql = sprintf("UPDATE %s.risk27k SET controlFiles = '%s' WHERE ID = %d"
					   ,_DB_OBJ_FULL
					   ,$new_files
					   ,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$new_files);
		$pStatement->bindParam(2,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to get an risk 27 k control files
	 * id, identifier
	 */
	public function getControlFile() {

		$sql = sprintf("SELECT controlFiles FROM %s.risk27k WHERE ID = %d"
					   ,_DB_OBJ_FULL
					   ,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kId);*/
		$pStatement->execute();
		$resultSet = $pStatement->fetchColumn();

		$files_list = explode(',',$resultSet);
		return $files_list;
	}

	/**
	 * This method is used to delete an risk 27 k control files
	 * id
	 */
	public function deleteControlFile() {
		$files_arr = $this->getControlFile();

		$new_files = array();

		if ( count($files_arr) ) {

			foreach ( $files_arr as $value ) {

				if ( $value != $this->Risk27kInfo['file_id'] ) {
					$new_files[] = $value;
				}

			}
		}

		$files = implode(',',$new_files);

		$sql = sprintf("UPDATE %.risk27k SET controlFiles = '%s' WHERE ID = %d"
					   ,_DB_OBJ_FULL,$files
						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$files);
		$pStatement->bindParam(2,$this->Risk27kId);*/

		$pStatement->execute();
	}
	public function addImprovementFile() {
		$files_arr = $this->getImprovementFile();
		$files = implode(',',$files_arr);

		$new_files = $files.','.$this->Risk27kInfo['file_id'];

		$sql = sprintf("UPDATE %s.risk27k SET improvementFiles = '%s' WHERE ID = %d"
						,_DB_OBJ_FULL,$new_files,$this->Risk27kId);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$new_files);
		$pStatement->bindParam(2,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to get an risk 27 k control files
	 * id, identifier
	 */
	public function getImprovementFile() {

		$sql = sprintf("SELECT improvementFiles FROM %s.risk27k WHERE ID = %d"
					   ,_DB_OBJ_FULL
					   ,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kId);*/
		$pStatement->execute();
		$resultSet = $pStatement->fetchColumn();

		$files_list = explode(',',$resultSet);
		return $files_list;
	}

	public function getAssestType() {

		$sql = sprintf("SELECT * FROM %s.assest_classification"
					   ,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->Risk27kId);*/
		$pStatement->execute();
			$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}



	/**
	 * This method is used to delete an risk 27 k control files
	 * id
	 */
	public function deleteImprovementFile() {
		$files_arr = $this->getImprovementFile();

		$new_files = array();

		if ( count($files_arr) ) {

			foreach ( $files_arr as $value ) {

				if ( $value != $this->Risk27kInfo['file_id'] ) {
					$new_files[] = $value;
				}

			}
		}

		$files = implode(',',$new_files);

		$sql = sprintf("UPDATE %s.risk27k SET improvementFiles = '%s' WHERE ID = %d"
					   ,_DB_OBJ_FULL
					   ,$files
						,$this->Risk27kId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$files);
		$pStatement->bindParam(2,$this->Risk27kId);*/

		$pStatement->execute();
	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$is_admin = false;
		$show_participant_name = false;


		if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
				$is_admin = false;

			} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
				$show_participant_name = true;
		}


		$heading = array(array('bu'=>'Business Unit','refrence'=>'Process No.','threat'=>'Threat','action'=>'Action','due'=>'Due Date','assigned'=>'Assigned To','done'=>'Done Date'));
		$p_moduleName = 'risk27k';

		$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
		//echo $tab_type;
	    $actTrackObj = new ActionTracker();

		$actTrackObj->setActionTrackerInfo('risk27k',$tab_type,$p_dateFilter='');
		$resultset = $actTrackObj->getActionsForActionTracker();
		//dump_array($resultset);

		if(!empty($resultset)){

			foreach($resultset as $resultElement){

			$ac_id = $resultElement['ID'];
			$action_description 		= compact_action_tracker_description($resultElement['actionDescription']);
			$action_description_full 	= javascript_safe_string($resultElement['actionDescription']);
			$threat_summary 			= ($resultElement['threatsSummary']);

			$result[$i]['bu'] = $resultElement['buName'];
			$result[$i]['refrence'] = getRiskReferenceFromProcessFlow($resultElement['reference']);
			$result[$i]['threat'] = $threat_summary;
			$result[$i]['action'] = $action_description_full;
			$result[$i]['due'] = format_datetime($resultElement['dueDate']);
			$result[$i]['assigned'] = $resultElement['who_name'];
			$result[$i]['done'] = format_datetime($resultElement['doneDate']);
			$i++;

		}
		$result = array_merge($heading,$result);
		return $result;

		}

		/*$heading = array(array('refrence'=>'Reference #','bu'=>'Business Unit','When'=>'When','who'=>'Who','loc'=>'Location','desc'=>'Description'));

		$orgObj			 = SetupGeneric::useModule('Organigram');
		$locObj			 = SetupGeneric::useModule('Locationgram');
		$participantObj	 = SetupGeneric::useModule('Participant');
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$this->setRisk27kInfo(0, array('archive'=>$archive_session));
		$view_data		=		$this->viewAllRisk27k();

		$result = array();

		if ( count($view_data) ) {
			$i=0;
			foreach ($view_data as $value ) {

				$insp_id = $value['ID'];
				$orgObj->setItemInfo(array('id'=>$value['businessUnit']));
				$bu_details = $orgObj->displayItemById();

				$locObj->setItemInfo(array('id'=>$value['locID']));
				$location_data = "";
				$location = $locObj->getFUllLocation();

				$participant_id = $value['who'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];


				$result[$i]['ref'] = $value['reference'];
				$result[$i]['bu'] = $bu_details['buName'];
				$result[$i]['when'] = format_date($value['whenDate']);
				$result[$i]['who'] = $participant_name;
				$result[$i]['loc'] = str_replace(',','-',$location);
				$result[$i]['desc'] = str_replace(',',' ',$value['description']);

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
		//return $heading;*/
	}

	/* function is used to send mail to manager of approved record */

	public function getActionTrackerEmailData($p_record_id) {

		$sql2 = sprintf("SELECT * FROM %s.risk27k ",_DB_OBJ_FULL);
		$sql2 = $sql2." WHERE improvements LIKE '".$p_record_id."' OR improvements LIKE '%,".$p_record_id."' OR improvements LIKE '".$p_record_id.",%' OR improvements LIKE '%,".$p_record_id.",%' ";

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();
		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

		/*** to show the threats ********/
		$hpc_id = $result[0]['threats'];

		$threat_arr = explode(',',$hpc_id);

		$hazard_list 		= 		SetupGeneric::useModule('HazardClassification');

		$hazard_list->setItemInfo(array(
					'id'=>14
					));
		$data_records = $hazard_list->displayItems();


		if ( count($data_records) ) {

			foreach ( $data_records as $key=>$value ) {
				$threats[$value['ID']] = $value['secondaryHazard'];
			}
		}
		if (count($threat_arr)) {
			foreach($threat_arr as $value) {
				$threats_names  .= $threats[$value].',';
			}

		}
		/******* ************/

		if ( count($result) ) {
			$email_data['bu_id']		 		= $result[0]['businessUnit'];
			$email_data['reference']		 	= $result[0]['reference'];
			$email_data['DueDate']				= $result[0]['whenDate'];
			$email_data['threats'] 				= rtrim($threats_names,',');

		}

		return $email_data;
	}
}

?>