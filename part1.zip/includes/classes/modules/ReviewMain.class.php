<?php

/**
  $Id: ReviewMain.class.php,v 7.80 Thursday, February 03, 2011 3:13:04 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Review object used to manage operation related to review
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Monday, September 13, 2010 5:30:32 PM>
 */

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';

class ReviewMain {
    /*
     * Object container for PDO Database resource class
     * @access private
     */

    private $dbHand;
    private $dbHand2;
    private $reviewObj;

    /*
     * This property will hold the value of ID of review under process.
     * @access private
     */
    private $reviewID;
    private $reviewInfo;

    /*
     * This property will store participant ID of the auditor who is performing a review.
     * @access private
     */
    private $auditorID;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;
    /*
     * This property will act as a container object for ReviewQuestion class.
     * @access private
     */
    private $reviewQuestionContainer;

    public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->dbHand2 = DB::connect(_DB_TYPE);
        $this->auditorID = getLoggedInUserId();
        $this->buID = 0;
        $this->reviewType = 'MSR';
        $this->reviewInfo = null;
        $this->reviewID = Session::getSessionField('review_id');
        $this->reviewQuestionContainer = new ReviewQuestion();
        $this->reviewGapContainer = new ReviewGap();
        $this->reviewObj = SetupGeneric::useModule('MSR');
        $this->actionHandling = new Action();
    }

    public function setMSRInfo($p_Id, $p_reviewInfo) {

        $this->reviewID = $p_Id;
        $this->reviewInfo = $p_reviewInfo;
    }

    public function checkReviewFrequency() {

        $a = false;
        if ($a) {
            return true;
        } else {
            return false;
        }
    }

    private function getIsrSectionByQtr20110922($p_qtr = 1) {

        $start_index = ($p_qtr - 1) * 2;

       if ( _DB_TYPE != 'mysql' ) {

            $sql = sprintf("SELECT TOP " . ($start_index + 2) . " code
				FROM %s.msr_departments
				WHERE sID = 7
				ORDER BY ID ASC", _DB_OBJ_FULL);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = '';

            $f_index = 0;
            while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if ($f_index < $start_index) {
                    $f_index++;
                    continue;
                }

                $result[] = $rec['code'];
                $f_index++;
            }
        } else {

            $sql = sprintf("SELECT code
				FROM %s.msr_departments
				WHERE sID = 7
				ORDER BY ID ASC
				LIMIT $start_index,2", _DB_OBJ_FULL);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = '';

            while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $result[] = $rec['code'];
            }
        }



        return $result;
    }

    private function getIsrSectionByQtr($p_qtr = 1) {

        $objOption = new Option();
        $result_qrtr_codes = $objOption->getOption('_SU_INTERNAL_AUDIT_MSR_QRTR' . $p_qtr);
        $result = explode(",", $result_qrtr_codes);

        $objOption = null;
        return $result;
    }

    private function getIsrQuestionsStow() {

        $sql = sprintf("SELECT ID
				FROM %s.review_questions
				WHERE isStowContractor = '1'
				ORDER BY ID ASC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $questions = '';

        while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $questionsmeta[] = $rec['ID'];
        }


        $rec = $this->reviewObj->displayItems();
        foreach ($rec as $data) {
            $questions[$data['display_order']] = $data['ID'];
        }
        ksort($questions);
        $result = array_intersect($questions, $questionsmeta);

        $this->questionList = implode(",", $result);
    }

        public function getIsrQuestionsMse($buID) {
        
 /*      $sql = sprintf("select E.* from %s.management_elements E  
        inner join %s.management_element_permissions P on E.memlListID=P.listID 
        inner join %s.msr_departments M on E.mainCatID=M.ID 
        where permission=1 and buid=%d order by M.code", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$buID); */

              $sql = sprintf("select E.* from %s.management_elements E  
        inner join %s.msr_departments M on E.mainCatID=M.ID 
        where isnull(archive,0) =0 order by M.code", _DB_OBJ_FULL,  _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);     
        
        $ins_raw = "INSERT INTO %s.review_questions_mse(question, score, recommendationOption, mseListID,eid)
				VALUES ('%s',1,'%s','%s','%s')";
          foreach ($rec as $list) {
             
              $sql = sprintf($ins_raw
              , _DB_OBJ_FULL
             ,$list['question']
             ,$list['guidance']
             ,$list['memlListID']  
             ,$list['eID']);
              
          
              $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
             $questions .= "," .customLastInsertId($this->dbHand, 'review_questions_mse', 'ID');
            
          }
      $this->questionList = ltrim($questions, ',');
      return $this->questionList;
        }
   
                public function getIsrQuestionsICR($buID) {
        
        $sql = sprintf("select E.* from %s.management_elements E  
        inner join %s.msr_departments M on E.mainCatID=M.ID 
        where isnull(archive,0) =0 order by M.code", _DB_OBJ_FULL,  _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);     
        
        $ins_raw = "INSERT INTO %s.review_questions_mse(question, score, recommendationOption, mseListID,eid)
				VALUES ('%s',1,'%s','%s','%s')";
          foreach ($rec as $list) {
             
              $sql = sprintf($ins_raw
              , _DB_OBJ_FULL
             ,$list['question']
             ,$list['guidance']
             ,$list['memlListID']  
             ,$list['eID']);
              
          
              $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
             $questions .= "," .customLastInsertId($this->dbHand, 'review_questions_mse', 'ID');
            
          }
      $this->questionList = ltrim($questions, ',');
      return $this->questionList;
        }
        
        public function getIsrQuestionsMseDeprec($buID) {

        $sql = sprintf("SELECT listID
				FROM %s.management_element_permissions
				WHERE buID = " . $buID . " AND permission = 1
				", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rec as $p_mseListId) {
           $sql = sprintf("SELECT * FROM %s.management_elements
					   WHERE memlListID = %d", _DB_OBJ_FULL, $p_mseListId['listID']);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $questions = '';
            $vdata = array();

            $vdata[] = _DB_OBJ_FULL;

            $ins_raw = "INSERT INTO %s.review_questions_mse(question, score, recommendationOption, mseListID)
				VALUES ";

            $i = 0;
            while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {

                $sqlItr = sprintf("SELECT * FROM %s.review_questions_mse
					WHERE question LIKE '%s'
					AND mseListID = %d", _DB_OBJ_FULL, $rec['subCategory'], $p_mseListId['listID']);

                $already_exists = false;

                $stmt_itr = $this->dbHand->prepare($sqlItr);
                $stmt_itr->execute();

// Check the number of rows that match the SELECT statement
                $rec_itr = $stmt_itr->fetch(PDO::FETCH_ASSOC);

                if ($rec_itr['ID']) {
                    $already_exists = true;
                }

                if (!$already_exists) {

                    if ($i) {
                        $ins_raw .= ",";
                    }

                    $ins_raw .= "('%s', %d, '%s', %d)";

                    $vdata[] = $rec['subCategory'];
                    $vdata[] = 1;
                    $vdata[] = $rec['pointsToReview'];
                    $vdata[] = $p_mseListId;

                    $i++;
                }
            }

     $ins = vsprintf($ins_raw, $vdata);

            $stmt_ins = $this->dbHand->prepare($ins);
            $stmt_ins->execute();

// get questions for mse

            $sql = sprintf("SELECT *
				FROM %s.review_questions_mse
				WHERE mseListID = %d
				ORDER BY ID ASC", _DB_OBJ_FULL, $p_mseListId['listID']);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $questions = '';

            while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $questions .= "," . $rec['ID'];
            }

            $this->questionList = ltrim($questions, ',');
        }
        
        

        return $this->questionList;
    }

    private function getMsrQuestions() {
//altered to get revised quesion lists
        /*
          $sql = sprintf("SELECT ID
          FROM %s.review_questions
          ORDER BY ID ASC",_DB_OBJ_FULL);

          $stmt = $this->dbHand->prepare($sql);
          $stmt->execute();

          $questions = '';

          while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
          $questions .= ",".$rec['ID'];
          }
         */


        $rec = $this->reviewObj->displayApprovedItems();

        foreach ($rec as $data) {
            $questions[$data['display_order']] = $data['ID'];
        }
        ksort($questions);


        $this->questionList = implode(",", $questions);
    }

    private function getIsrQuestions($p_codes) {

        $str = implode("','", $p_codes);

       $sql = sprintf("SELECT questionID
				FROM %s.review_question_metadata
				WHERE standardID = 52
				AND SUBSTRING(code,1,1) IN ('$str')
				ORDER BY questionID ASC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $questions = '';

        while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $questionsmeta[] = $rec['questionID'];
        }


        $rec = $this->reviewObj->displayItems();
        foreach ($rec as $data) {
            $questions[$data['display_order']] = $data['ID'];
        }
        ksort($questions);
        $result = array_intersect($questions, $questionsmeta);

        $this->questionList = implode(",", $result);
    }

    
        private function getIsrQuestionsLevel30() {

       $sql = sprintf("SELECT ID
				FROM %s.review_questions
				WHERE stage1=1
				ORDER BY ID ASC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $questions = '';

        foreach ($rec as $value) {
            $questions .= $rec['ID'].",";
        }



        $this->questionList = trim($questions,",");
    }
    private function isSimilarReviewDone() {

        $sql = sprintf("SELECT reviewID
				FROM %s.review_master
				WHERE buID = %d
				AND reviewType = '%s'
				ORDER BY reviewID DESC"
                , _DB_OBJ_FULL
                , $this->buID
                , $this->reviewType);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->buID);
          $stmt->bindParam(2,$this->reviewType,PDO::PARAM_STR,5); */

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    //    $count = count($result);

        if (is_array($result)) {
            return $result['reviewID'];
        } else {
            return 0;
        }
    }

        private function cloneReview($p_sourceReviewId, $p_destinationReviewId) {

        /* for extra protection */
        $p_sourceReviewId = (int) $p_sourceReviewId;
        $p_destinationReviewId = (int) $p_destinationReviewId;

        $sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_sourceReviewId);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_sourceReviewId); */
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $resultSet) {

            $ins = sprintf("INSERT INTO %s.review_answers (reviewID,questionID,answer,standardID,recommendation)
				VALUES (%d, %d, '%s', %d, '%s')"
                    , _DB_OBJ_FULL
                    , $p_destinationReviewId
                    , $resultSet['questionID']
                    , $resultSet['answer']
                    , $resultSet['standardID']
                    , $resultSet['recommendation']);

            $stmt_ins = $this->dbHand->prepare($ins);


            $stmt_ins->execute();
        } // end foreach
    }
    
    private function cloneMSEReview($p_sourceReviewId, $p_destinationReviewId) {

        /* for extra protection */
        $p_sourceReviewId = (int) $p_sourceReviewId;
        $p_destinationReviewId = (int) $p_destinationReviewId;

        $sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_sourceReviewId);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_sourceReviewId); */
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $resultSet) {

            $ins = sprintf("INSERT INTO %s.review_answers (reviewID,questionID,answer,standardID,recommendation)
				VALUES (%d, %d, '%s', %d, '%s')"
                    , _DB_OBJ_FULL
                    , $p_destinationReviewId
                    , $resultSet['questionID']
                    , $resultSet['answer']
                    , $resultSet['standardID']
                    , $resultSet['recommendation']);

            $stmt_ins = $this->dbHand->prepare($ins);


            $stmt_ins->execute();
        } // end foreach
    }

    /**
     * Format a mysql formatted date to d/m/Y format.
     *
     * This function convert date to d/m/Y using strtotime function if the year is more than 1970
     * else it uses explode function to format the date.
     *
     * @param date $date Stores date to convert.
     * @access public
     */
    public function startReview($p_reviewType, $p_businessId, $p_mseListId = 0, $p_ref = "Admin",$grp=5) {

        $this->questionList = '';
       $this->buID = $p_businessId;
$this->reference=$p_ref;
   $this->grp = $grp;

        if ($p_reviewType == 'MSR') {

            $this->getMsrQuestions();
        } else if ($p_reviewType == 'ISR_STOW') {

            $this->getIsrQuestionsStow();
            $this->reviewType = 'ISR';
        } else if ($p_reviewType == 'ISR_30') {

            $this->getIsrQuestionsLevel30();
            $this->reviewType = 'ISR_30';
        } else if ($p_reviewType == 'ISR_MSE') {

            $this->getIsrQuestionsMse($this->buID);
            $this->reviewType = 'MSE';
        } else if ($p_reviewType == 'S1') {
            $this->getIsrQuestionsICR($this->buID);
            $this->reviewType = 'S1';
        } else {

            $qtr = ceil(date("n") / 3);
            $codes = $this->getIsrSectionByQtr($qtr);


            $this->getIsrQuestions($codes);
            $this->reviewType = 'IA';
        }
        /* Check if similar review is done or not
          Need some testing
         */

        $similar_review_id = (int) $this->isSimilarReviewDone();

        if ($similar_review_id) {

           if ( _DB_TYPE != 'mysql' ) {
                $default_datetime = '1900-01-01 00:00:00';
            } else {
                $default_datetime = '0000-00-00 00:00:00';
            }

             $sql = sprintf("INSERT INTO %s.review_master (auditorID,buID,startTime,endTime,reviewType,is_complete,current_question,questions,reference,grouptype)
				VALUES (%d, %d, " . customCurrentDate() . ", '%s', '%s','0','1','%s','%s',%d)"
                    , _DB_OBJ_FULL
                    , $this->auditorID
                    , $this->buID
                    , $default_datetime
                    , $this->reviewType
                    , $this->questionList
                    , $this->reference
                    , $this->grp);

            $stmt = $this->dbHand->prepare($sql);

            if ($stmt->execute()) {
                $destination_review_id = customLastInsertId($this->dbHand, 'review_master', 'reviewID');

// add review tracker entry
                $this->punchBusinessUnitReview();
if($this->reviewType == 'MSE')
                $this->cloneMSEReview($similar_review_id, $destination_review_id);
               else 
                $this->cloneReview($similar_review_id, $destination_review_id);
                
                return $destination_review_id;
            }
        } else {

          if ( _DB_TYPE != 'mysql' ) {
                $default_datetime = '1900-01-01 00:00:00';
            } else {
                $default_datetime = '0000-00-00 00:00:00';
            }

            $sql = sprintf("INSERT INTO %s.review_master (auditorID,buID,startTime,endTime,reviewType,is_complete,current_question,questions,reference,grouptype)
				VALUES (%d, %d," . customCurrentDate() . ",'%s', '%s','0','1','%s','%s',%d)"
                    , _DB_OBJ_FULL
                    , $this->auditorID
                    , $this->buID
                    , $default_datetime
                    , $this->reviewType
                    , $this->questionList
                    , $this->reference
                    , $this->grp);


            $stmt = $this->dbHand->prepare($sql);

            if (!$stmt->execute()) {
                throw new ErrorException("Unable to start a review", 11);
            } else {
// add review tracker entry
                $last_insert_id = customLastInsertId($this->dbHand, 'review_master', 'reviewID');

                if ($this->reviewType != 'MSE') {
                    $this->punchBusinessUnitReview();
                }

                return $last_insert_id;
            }
        }
    }

    private function punchBusinessUnitReview() {

        $orgObj = SetupGeneric::useModule('Organigram');
        $orgObj->setItemInfo(array('id' => $this->buID));

        $business_unit_info = $orgObj->displayItemByIdForMSR();
        $currentCalendarQuarter = currentCalendarQuarter();

        if ($this->reviewType == 'MSR') {
            $reviewType = $this->reviewType;
            $currentCalendarQuarter = $business_unit_info['optionA'];
        } else {
            $optionA = $business_unit_info['optionA'];
            $optionB = $business_unit_info['optionB'];

            if ($optionA && !$optionB) {
                $reviewType = $this->reviewType . $currentCalendarQuarter;
            } else if (!$optionA && $optionB) {
                $reviewType = $this->reviewType . 'STOW';
            }
        }

        $orgObj = null;

        $sql = sprintf("INSERT INTO %s.review_periodicity_tracker (businessUnit,whenDate,reviewType,quarter)
				VALUES (%d, %s,'%s', %d)"
                , _DB_OBJ_FULL
                , $this->buID
                , customCurrentDate()
                , $reviewType
                , $currentCalendarQuarter);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->buID);
          $stmt->bindParam(2,$reviewType);
          $stmt->bindParam(3,$currentCalendarQuarter); */

        $stmt->execute();
    }

    public function isReviewDone($p_reviewType, $p_businessUnit) {
//$p_businessUnit = 1211;
        /*
          businessUnit when 	reviewType 	quarter quarter number
         */
        $current_year = date('Y');
        $current_qrtr = currentCalendarQuarter();

//echo $p_reviewType.",".$p_businessUnit."<br/>";

        if ($p_reviewType == 'MSE') {

            $is_complete = 0;

            $sql_pre = sprintf("SELECT endTime,reviewID,is_complete FROM %s.review_master
							   WHERE buID = %d ORDER BY reviewID DESC", _DB_OBJ_FULL, $p_businessUnit);

            $stmt_pre = $this->dbHand->prepare($sql_pre);
            $stmt_pre->execute();

            $result_pre = $stmt_pre->fetchAll(PDO::FETCH_ASSOC);

            if (count($result_pre)) {
                $is_complete = 1;
                return true;
            }

            return false;
        }

        if ($p_reviewType == 'MSR') {

            $is_complete = 0;

            $sql_pre = sprintf("SELECT startTime,endTime,reviewID,is_complete FROM %s.review_master
							   WHERE buID = %d ORDER BY reviewID DESC", _DB_OBJ_FULL, $p_businessUnit);

            $stmt_pre = $this->dbHand->prepare($sql_pre);
            $stmt_pre->execute();

            $result_pre = $stmt_pre->fetch(PDO::FETCH_ASSOC);
            $start_date = substr($result_pre['startTime'], 0, 10);

            $sql = sprintf("SELECT msr,optionA FROM %s.business_units WHERE buID = %d", _DB_OBJ_FULL, $p_businessUnit);
            $stmt = $this->dbHand2->prepare($sql);
            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $miscObj = new Misc();
            $new_start_date = $miscObj->makeCustomDate($start_date, $result['optionA'], 'MONTH');
            $current_date = $miscObj->getCurDate();
            $miscObj = null;

//echo $new_start_date." - ".$current_date;

            if ($result_pre['reviewID'] && $result_pre['is_complete'] && $new_start_date <= $current_date) {
                $is_complete = 1;
            } else if ($result_pre['reviewID'] && !$result_pre['is_complete']) {
                $is_complete = 0;
            } else if (!$result_pre['reviewID'] && $new_start_date <= $current_date) {
                $is_complete = 1;
            }

            if ($is_complete != 0) {
                return true;
            }

            return false;
        }

        /* if ( $p_reviewType == 'MSR' || $p_reviewType == 'MSE' ) {

          $is_complete = 0;

          $sql_pre = sprintf("SELECT endTime,reviewID,is_complete FROM %s.review_master
          WHERE buID = %d ORDER BY reviewID DESC",_DB_OBJ_FULL,$p_businessUnit);

          $stmt_pre = $this->dbHand->prepare($sql_pre);
          $stmt_pre->execute();

          $result_pre = $stmt_pre->fetch(PDO::FETCH_ASSOC);

          if ( $result_pre['reviewID'] && $result_pre['is_complete'] ) {
          $is_complete = 1;
          } else if ( $result_pre['reviewID'] && !$result_pre['is_complete'] ) {
          $is_complete = 0;
          } else if ( !$result_pre['reviewID'] ) {
          $is_complete = 1;
          }

          if ( $p_reviewType == 'MSE' ) {
          return false;
          }

          if ( !$is_complete ) {
          return true;
          }

          return false;
          } */

        if ($p_reviewType == 'IA') {

            $sql = sprintf("SELECT * FROM %s.review_periodicity_tracker
					WHERE businessUnit = %d
					AND YEAR(whenDate) = %d
					AND quarter = %d"
                    , _DB_OBJ_FULL
                    , $p_businessUnit
                    , $current_year
                    , $current_qrtr);

            $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($result)) {
                return true;
            } else {
                return false;
            }
        } else if ($p_reviewType == 'MSR') {

            if ( _DB_TYPE != 'mysql' ) {

                $sql = sprintf("SELECT TOP 1 * FROM %s.review_periodicity_tracker
					WHERE businessUnit = %d
					ORDER BY whenDate DESC"
                        , _DB_OBJ_FULL
                        , $p_businessUnit
                        , $current_year);
            } else {

                $sql = sprintf("SELECT * FROM %s.review_periodicity_tracker
					WHERE businessUnit = %d
					ORDER BY whenDate DESC
					LIMIT 1"
                        , _DB_OBJ_FULL
                        , $p_businessUnit
                        , $current_year);
            }

            $stmt = $this->dbHand->prepare($sql);

            /* $stmt->bindParam(1,$p_businessUnit);
              $stmt->bindParam(2,$current_year); */

            $stmt->execute();
            $a = $stmt->errorInfo();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $last_when = $result['whenDate'];
            $frequency = $result['quarter'];

// to be deleted
//$frequency = $t_fre;

            $miscObj = new Misc();

            $next_date = $miscObj->makeCustomDate($last_when, $frequency, 'MONTH');
            $current_date = $miscObj->getCurDate();

//echo " $next_date <= $current_date <br/>";

            if ($next_date <= $current_date) {
                return false;
            } else {
                return true;
            }
        } /* else if ( $p_reviewType == 'MSE' ) {

          if ( !$is_complete ) {
          return true;
          } else {
          return false;
          }
          } */
    }

    public function continueReview() {

        $sql = sprintf("SELECT * FROM %s.review_master
				WHERE reviewID = %d", _DB_OBJ_FULL, $this->reviewID);


        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$this->reviewID);

        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        $current_question = $rec['current_question'];
        $questions = $rec['questions'];
        $questions_arr = explode(',', $questions);
        $questions_arr_flipped = array_flip($questions_arr);
        $current_question = $questions_arr_flipped[$current_question] + 1;

        return array('current_question_index' => $current_question,
            'current_question_real_identifier' => $rec['current_question']);
    }

    public function saveReview($p_questionIdentifier) {

        $sql = sprintf("UPDATE %s.review_master
				SET is_complete = '0',
				current_question = %d
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_questionIdentifier, $this->reviewID);


        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();
    }

    public function finishReview() {

        $sql = sprintf("UPDATE %s.review_master
				SET is_complete = '1',
				endTime = " . customCurrentDate() . "
				WHERE reviewID = %d", _DB_OBJ_FULL, $this->reviewID);


        $stmt = $this->dbHand->prepare($sql);

//$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();

        $this->sendActionEmails($this->reviewID);
    }

    public function finishReviewOutside($p_review_id) {

        $sql = sprintf("UPDATE %s.review_master
				SET is_complete = '1',
				endTime = " . customCurrentDate() . "
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_review_id);


        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_review_id);
        $stmt->execute();
        
        $this->sendActionEmails($p_review_id);
        
        
    }

    public function deleteReview($p_review_id) {

        $sql = sprintf("DELETE FROM %s.review_answers
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_review_id);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_review_id);

        $sql_sec = sprintf("DELETE FROM %s.review_master
					WHERE reviewID = %d", _DB_OBJ_FULL, $p_review_id);

        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_sec->execute();
    }

    public function archiveReview($p_review_id, $p_archive_val) {

        $sql = sprintf("UPDATE %s.review_master SET archive = '%s' WHERE reviewID = %d", _DB_OBJ_FULL, $p_archive_val, $p_review_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function listOpenReview($p_archive_val) {

        $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '0' AND M.archive = '%s' AND reviewType = 'MSR'
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listOpenReview1($p_archive_val) {

        $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '0' AND M.archive = '%s' AND reviewType = 'IA'
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listOpenReview2($p_archive_val) {

        $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '0' AND M.archive = '%s' AND reviewType = 'S1'
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

        public function listOpenReviewICR($p_archive_val) {

      $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '0' AND M.archive = '%s' AND reviewType = 'S1'
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function listOpenSoa($p_archive_val = 1) {

       $sql = sprintf("SELECT * FROM %s.soaReview WHERE archived = %s AND (complete IS NULL OR complete != 1) ORDER BY ID DESC", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listClosedSoa($p_archive_val = 0) {

        $sql = sprintf("SELECT * FROM %s.soaReview WHERE complete = 1 AND archived = %s ", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listClosedReview1($p_archive_val) {
   $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '1'   AND M.archive = %s AND reviewType = 'IA'
				ORDER BY M.reviewID,M.endTime DESC", _DB_OBJ_FULL, _DB_OBJ_FULL,$p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = array();

        while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $rec['attempted_questions'] = $this->reviewQuestionContainer->getAttemptedQuestionStats($rec['reviewID']);
            $rec['total_questions'] = count(explode(',', $rec['questions']));

            $result[] = $rec;
        }

        return $result;
    }

    public function listClosedReview2($p_archive_val) {

       $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '1'   AND M.archive = %s AND reviewType = 'MSE'
				ORDER BY M.reviewID,M.endTime DESC", _DB_OBJ_FULL, _DB_OBJ_FULL,$p_archive_val ); // startTime
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = array();

        while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $rec['attempted_questions'] = $this->reviewQuestionContainer->getAttemptedQuestionStats($rec['reviewID']);
            $rec['total_questions'] = count(explode(',', $rec['questions']));

            $result[] = $rec;
        }

        return $result;
    }

    public function listClosedReviewICR($p_archive_val) {

       $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '1'   AND M.archive = %s AND reviewType = 'S1'
				ORDER BY M.reviewID,M.endTime DESC", _DB_OBJ_FULL, _DB_OBJ_FULL,$p_archive_val ); // startTime
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = array();

        while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $rec['attempted_questions'] = $this->reviewQuestionContainer->getAttemptedQuestionStats($rec['reviewID']);
            $rec['total_questions'] = count(explode(',', $rec['questions']));

            $result[] = $rec;
        }

        return $result;
    }
    
    public function listClosedReview($p_archive_val) {

        $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
		                WHERE M.is_complete = '1' AND isnull(M.archive,0) = '%s' AND reviewType = 'MSR'
				ORDER BY M.reviewID,M.endTime DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = array();

        while ($rec = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $rec['attempted_questions'] = $this->reviewGapContainer->getAttemptedQuestionStats($rec['reviewID']);
            $rec['total_questions'] = count($this->reviewGapContainer->getQuestionList($rec['reviewID']));

            $result[] = $rec;
        }

        return $result;
    }

    public function downloadDocument($p_doc_id) {

        $sql = sprintf("SELECT * FROM %s.question_docs
				WHERE ID = %d", _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_doc_id);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);


        $file = _PATH_PRIVATE_FILES . $rec['filename'];
        $file_arr = explode('.', basename($rec['filename']));

        $download_file_name = str_replace(' ', '_', basename($rec['displayName']));
        $download_file_name_ext = $download_file_name . '.' . $file_arr[count($file_arr) - 1];

        if (!$file) {
// File doesn't exist, output error
            die('file not found');
        } else {
// Set headers
            header('Content-type: application/download');
            header('Content-Description: File Transfer');
            header('Content-Disposition: attachment; filename="' . $download_file_name_ext . '" ');
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header('Content-Transfer-Encoding: binary');

// Read the file from disk
            readfile($file);
        }

        $updObj = null;
    }

    public function getReviewInfo($p_reviewID) {

        $sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
					   INNER JOIN %s.business_units B
					   ON M.buID = B.buID
				WHERE M.reviewID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_reviewID);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_doc_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getListingforExport() {

        $reviews = $_GET['reviews'];

        if ($reviews == 'open') {

            return $this->getOpenReviewsExportData();
        } else if ($reviews == 'closed') {

            return $this->getClosedReviewsExportData();
        }
        return $this->getReviewsExportData();
    }

    public function listCSVReview($p_archive_val) {

        $sql = sprintf("SELECT R.ID as cid, * ,R.reviewDate as reviewDate FROM %s.contract_review R LEFT JOIN %s.contract C ON R.contractID = C.ID LEFT JOIN %s.participant_database P ON R.reviewer = P.participantID " . $where . " ORDER BY cid desc", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getReviewsExportData() {

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $openReview = $this->listCSVReview($archive_session);
        /*
cid	ID	f1f2	contractID	quarterCovered	yearCovered	reviewDate	reviewEndDate	reviewer	contractStillValid	disputedInvoices	productQuality	productQualityCNCR	productQualityComment	serviceQuality	serviceQualityCNCR	serviceQualityComment	onTimeDelivery	onTimeDeliveryCNCR	onTimeDeliveryComment	knowledge	knowledgeCNCR	knowledgeComment	reputation	reputationCNCR	reputationComment	customerFocus	customerFocusCNCR	customerFocusComment	customerService	customerServiceCNCR	customerServiceComment	responsiveness	responsivenessCNCR	responsivenessComment	amountPaidInCurrentFinancialYear	contractAnnualValue	disputedInvoicesComment	contractReviewMeetings	complaints	healthAndQuality	healthAndQualityCNCR	healthAndQualityComment	finance	financeCNCR	financeComment	evaluate1	evaluate2	evaluate3	evaluate4	evaluate5	evaluate6	evaluate7	evaluate8	evaluate9	evaluate10	cmFinished	cmApproved	maApproved	daApproved	cmRejected	maRejected	daRejected	notes	review_ID	approved	files_invoice	meeting_date	files_meeting	status	subReference	reviewCompleteDate	score_average	archive	maNotes	daNotes	qtr_spend	ID	reference	contractName	buID	contractManagerID	shortTermOrTender	endDate	detail	managerApproverID	directorApproverID	startDate	totalValue	remarks	useApprovedContractor	reviewDueDate	archive	location	reviewDate	ISFlag	BCP	participantID	uniqueReference	worksNumber	username	passwd	forename	surname	dateOfBirth	gender	emailAddress	active	joiningDate	leavingDate	lang	phonenumber	archive	mobile	gcupositions	reviewDate
 */
       
        $heading = array(array('Contract Ref', 'Rev Type', 'Title', 'Qtr', 'Reviewed By', 'Due Date', 'Complete Date', 'Next Review Date'));
       

        $result = array();
        $i = 0;
        if (count($openReview)) {

            foreach ($openReview as $value) {
                $refValue = $value['subReference'] > 0 ? $value['reference'] . "." . $value['subReference'] : $value['reference'];

                if ($value['f1f2'] == 2)
                    $f1f2Str = "Detailed";
                else
                    $f1f2Str = "Standard";



                $result[$i][] = $refValue;
                $result[$i][] = $f1f2Str;
                $result[$i][] = $value['contractName'];
                $result[$i][] = $value['quarterCovered'] . "'" . $value['yearCovered'];
                $result[$i][] = $value['forename'] . ' ' . $value['surname'];
                $result[$i][] = $value['reviewEndDate'] ? format_date($value['reviewEndDate']) : '   ';
                $result[$i][] = $value['reviewCompleteDate'] ? format_date($value['reviewCompleteDate']) : '   ';


                $quarterCovered = 5;
                $nowMonth = intval(date('m'));
                if ($nowMonth >= 1 && $nowMonth <= 3)
                    $quarterCovered = 1;
                else if ($nowMonth >= 4 && $nowMonth <= 6)
                    $quarterCovered = 2;
                else if ($nowMonth >= 7 && $nowMonth <= 9)
                    $quarterCovered = 3;
                else if ($nowMonth >= 10 && $nowMonth <= 12)
                    $quarterCovered = 4;

                $quarterCovered ++;

                if ($value['f1f2'] == '2') {
                    $quarterCovered = "4";
                }


                $sql = sprintf("SELECT * FROM %s.contract_review_date WHERE quarter = " . $quarterCovered . " ORDER BY quarter", _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
                $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



                if ($value['f1f2'] == '2') {
                    $Year = $resultSet['year'] + 1;
                } else {
                    $Year = $resultSet['year'];
                }
                $reviewDate = $resultSet['month'] . "/" . $resultSet['day'] . "/" . $Year;



                $result[$i][] = $reviewDate;


                $i++;
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getOpenReviewsExportData() {

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $openReview = $this->listOpenReview($archive_session);

        $heading = array(array('Reference','Business Unit', 'Start Date/time', 'Current Question'));

        $result = array();

        if (count($openReview)) {

            foreach ($openReview as $element) {

                $review_type = rtrim($element['reviewType']);
				$reference = rtrim($element['reference']);
                $business_unit = $element['buName'] . ' (' . $review_type . ')';
                $start_date = format_datetime($element['startTime']);

                $current_question = $element['current_question'];
                $questions = $element['questions'];
                $questions_arr = explode(',', $questions);
                $questions_arr_flipped = array_flip($questions_arr);
                $current_question = $questions_arr_flipped[$current_question] + 1;

                $result[] = array($reference,$business_unit, $start_date, $current_question);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getClosedReviewsExportData() {

        $participantObj = SetupGeneric::useModule('Participant');

        $closedReview = $this->listClosedReview();

        $heading = array(array('Reference','Auditor', 'Business Unit', 'Start date/time', 'End date/time', 'Questions'));

        if (count($closedReview)) {

            foreach ($closedReview as $element) {
$reference = $element['reference'];
                $participantObj->setItemInfo(array('id' => $element['auditorID']));
                $participant_details = $participantObj->displayItemById();

                $auditor_name = ucwords($participant_details['forename'] . ' ' . $participant_details['surname']);
                $business_unit = $element['buName'] . ' (' . $element['reviewType'] . ')';
                $start_date = format_datetime($element['startTime']);
                $end_date = format_datetime($element['endTime']);
                $questions = $element['attempted_questions'] . '/' . $element['total_questions'];

                $result[] = array($reference,$auditor_name, $business_unit, $start_date, $end_date, $questions);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getDetailOrgan($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.review_audit_detail WHERE archive=0 and rID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgani77($id) {
        $this->id = $id;

        $sql_rev1 = sprintf("SELECT * FROM %s.review_master WHERE reviewID = %d ", _DB_OBJ_FULL, $this->id);
        $pStatement_rev1 = $this->dbHand->prepare($sql_rev1);
//$pStatement_rev->bindParam(1,$this->filters['aid'],PDO::PARAM_INT);
        $pStatement_rev1->execute();

        $records_rev1 = $pStatement_rev1->fetch(PDO::FETCH_ASSOC);

        $result = format_date($records_rev1['startTime']);


        return $result;
    }

    public function getDetailOrgani1($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.review_audit_detail WHERE archive=0 and ID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgani199($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.organigramPerson WHERE buID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgani1999() {

        $sql = "SELECT * FROM %s.business_units WHERE whenIsr != '1900-01-01'";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgani19999() {

        $sql = "SELECT * FROM %s.review_master WHERE reviewType = 'ISR' AND is_complete = '0'";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgani13($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.review_audit_detail WHERE buID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getParticipants($id) {
        $this->id = $id;
        $sql = "SELECT R.persontype,P.forename+' '+P.surname  as name,R.personid FROM %s.review_audit_participants R inner join %s.participant_database P on R.personid=P.participantid WHERE R.archive=0 and reviewID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function addAction($p_data) {
        $optionObj = new Option();
        $this->actionData = $p_data;
        $this->actionHandling->setActionDetails(0, $this->actionData);
        $new_action_id = $this->actionHandling->addAction2015();

        $emailObj = new actionEmailHelper($new_action_id);
        $who = $emailObj->getwhoDetails();
        $str = (strtotime($this->actionData['due_date'])) - strtotime(date("M d Y "));
        $dateinc = floor($str / 3600 / 24);
        $green = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
        echo $this->actionData['when'];
        if ($dateinc <= $green)
            $click_here_url = 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/system_review/detail.php?rID=' . $this->actionData["record"] . '&start=1">CLICK</a> Here to start review<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/msr_action.php">CLICK</a> Here to see the action';
        else
            $click_here_url = 'You will recieve a reminder to start this review at a later date<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/msr_action.php">CLICK</a> Here to see the action';

        $data = array(
            'singleColData' => array(
                'click-here-url' => $click_here_url
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Business Unit</strong>',
                    'right' => $this->actionData["buname"]
                )
            )
        );

        $emailObj->appendInfo($data);
        $cto = array('displayname' => 'bob', 'email' => 'robertabery@btinternet.com');
        $emailObj->sendEmail('smart-ISO Review due', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function editOrganigramDetail() {
        $sql = "update %s.review_audit_detail set archive=1 where rID=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $sql = "INSERT into %s.review_audit_detail(plan_d,summary,rID)
            VALUES('%s','%s', %d)";

   $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewInfo['plan'], $this->reviewInfo['summary'], $this->reviewID);
      
   $stmt = $this->dbHand->prepare($psql);
        
         return $stmt->execute();
    }

    
        public function updateFiles($filesIn,$filesOut) {
        $sql = "update %s.review_detail_files set archive=1 where fileID in (%s)";
       $psql = sprintf($sql, _DB_OBJ_FULL, $filesOut);
  
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
       if(is_array($filesIn)){ 
        foreach($filesIn as $row => $value ){
        $sql = "INSERT into %s.review_detail_files (rID,fileID,archive) VALUES (%d,'%s',0)";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, $value);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        }
       }
        return;
    }
    
    public function updatePersonDetail() {
        $sql = "update %s.review_audit_participants set archive=1 where reviewID=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $sql = "INSERT into %s.review_audit_participants (reviewID,persontype,personid) VALUES (%d,'%s',%d)";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'L', $this->reviewInfo["l_aud"]);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        if ($this->reviewInfo["auditor"]) {
            foreach ($this->reviewInfo["auditor"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'A', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }
        if ($this->reviewInfo["audit"]) {
            foreach ($this->reviewInfo["audit"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'E', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }
        if ($this->reviewInfo["person"]) {
            foreach ($this->reviewInfo["person"] as $p => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'P', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }
        return;
    }

    public function updateReview($p_reviewType, $p_review, $p_mseListId = 0) {

        $this->questionList = '';

        $this->reviewID = $p_review;
        if ($p_reviewType == 'MSR') {

            $this->getMsrQuestions();
        } else if ($p_reviewType == 'ISR_STOW') {

            $this->getIsrQuestionsStow();
            $this->reviewType = 'ISR';
        } else if ($p_reviewType == 'ISR_MSE') {

            $this->getIsrQuestionsMse($this->buID);
            $this->reviewType = 'MSE';
        } else {

            $qtr = ceil(date("n") / 3);
            $codes = $this->getIsrSectionByQtr($qtr);
            $this->getIsrQuestions($codes);
            $this->reviewType = 'ISR';
        }


        $default_datetime = '1900-01-01 00:00:00';


        $sql = sprintf("update %s.review_master set auditorID=%d,startTime=%s,endTime='%s',is_complete=0,current_question=1,questions='%s' where reviewid=%d"
                , _DB_OBJ_FULL
                , $this->auditorID
                , customCurrentDate()
                , $default_datetime
                , $this->questionList
                , $this->reviewID);


        $stmt = $this->dbHand->prepare($sql);

        if (!$stmt->execute()) {
            throw new ErrorException("Unable to start a review", 11);
        } else {
// add review tracker entry
            $last_insert_id = customLastInsertId($this->dbHand, 'review_master', 'reviewID');

            if ($this->reviewType != 'MSE') {
                $this->punchBusinessUnitReview();
            }

            $this->moveFiles('', $this->reviewID, $this->reviewID);

            return;
        }
    }

    public function moveFiles($p_identifier, $ridA, $rid) {
        $rec_id = $ridA;

        $module = 'review';

        $path = _MYROOT . 'tmp/' . $module . '/' . $p_identifier;


        $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();
//$this = new RiskAssessment();

            if (count($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);


                            $file_details = array('user_file_name' => $file_details_arr[2]
                                , 'name' => ''
                                , 'tmp_name' => ''
                                , 'file_details' => ''
                                , 'size' => 0
                                , 'id' => 0
                                , 'error' => 0
                                , 'destination' => ''
                                , 'file_type' => $file_type
                                , 'type' => $file_type
                            );


                            $objFile->setFileInfo($module, $file_details);

                            $objFile->setBogusDetails($file_details);

                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
//	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);

                                    $this->setMSRInfo($rid, $data_array);
                                    $this->addMSRFiles();
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }

    public function getNewPossibleReviewsBUs($p_type) {
        $orgObj = SetupGeneric::useModule('Organigram');
        $list_bu = $orgObj->getBusinessUnitsList();

        if ($p_type == "MSE") {

            $sql = "select buID from %s.review_master where is_complete=0 and isnull(archive,0)=0 and reviewtype='MSE'";
       $psql = sprintf($sql,  _DB_OBJ_FULL);
        } else {
            $sql = "select buID from %s.review_master where is_complete=0 and isnull(archive,0)=0 and reviewtype='%s'";
            $psql = sprintf($sql,  _DB_OBJ_FULL, $p_type);
        }
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
if(is_array($result)){
        foreach($result as $row){
            unset($list_bu[$row["buID"]]);
        }
}
if(is_array($list_bu)){
        foreach($list_bu as $key=>$newlist) {
           
            $newlisting[$key]=$newlist["plainname"];

        }
		}
if(is_array($newlisting)){		
asort($newlisting);
}
        return $newlisting;
    }

    public function addMSRFiles($file_id, $rID) {

        $sql = sprintf("INSERT INTO %s.review_detail_files (rID,fileid) VALUES (%d,%d)"
                , _DB_OBJ_FULL
                , $rID
                , $file_id);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
    }

    public function getMSRFiles($p_rid) {
        $this->reviewID = $p_rid;
        $sql = sprintf("select * from %s.review_detail_files where archive=0 and rID=%d"
                , _DB_OBJ_FULL
                , $this->reviewID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function GapReportdata($aid) {
        $this->aid = $aid;
        global $REVIEW_MANDATORY_COLOR;
        global $REVIEW_QUESTION_COLOR;

        $objMSR = SetupGeneric::useModule('MSR');

        $questions = $objMSR->displayAllItems();

//	$standard = $this->filters['sid'] == '' ? 7 : $this->filters['sid'];

        $sql = sprintf("SELECT questions FROM %s.review_master WHERE reviewID = %d", _DB_OBJ_FULL, $this->aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $questions_list = $pStatement->fetchColumn();
        $questions_list_arr = explode(",", $questions_list);


        $sql_msr_action = sprintf("SELECT * FROM %s.actions A
									   INNER JOIN
									   %s.review_tracker_msractions B
									   ON A.ID = B.actionID
									   WHERE reviewID = %d ", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->aid);

        $pStatement_msr_action = $this->dbHand->prepare($sql_msr_action);

        $pStatement_msr_action->execute();
        $result_msr_action_records = $pStatement_msr_action->fetchAll(PDO::FETCH_ASSOC);

        $question_msr_actions = array();





        $partObj = SetupGeneric::useModule('Participant');

        if ($result_msr_action_records) {
            foreach ($result_msr_action_records as $result_msr_action_element) {
                $partObj = SetupGeneric::useModule('Participant');
                $partObj->setItemInfo(array(
                    'id' => $result_msr_action_element['who']
                ));
                $participant_details = $partObj->displayItemById();
                $participant_name = $participant_details['forename'] . ' ' . $participant_details['surname'];

                $qid = $result_msr_action_element['questionID'];
                $question_msr_actions[$qid]['actionDescription'] = $result_msr_action_element['actionDescription'];
                $question_msr_actions[$qid]['who'] = $participant_name;
                $question_msr_actions[$qid]['dueDate'] = format_date($result_msr_action_element['dueDate']);
                $question_msr_actions[$qid]['doneDate'] = format_date($result_msr_action_element['doneDate']);
                $question_msr_actions[$qid]['doneDescription'] = $result_msr_action_element['doneDescription'];
                $question_msr_actions[$qid]['approve'] = $result_msr_action_element['approve'];
                $question_msr_actions[$qid]['outstanding'] = $result_msr_action_element['outstanding'];
                $question_msr_actions[$qid]['status'] = $result_msr_action_element['status'];
                $question_msr_actions[$qid]['whoAU'] = $result_msr_action_element['whoAU'];
                $question_msr_actions[$qid]['questionID'] = $result_msr_action_element['questionID'];
            }
        }



        $sql_rev1 = sprintf("SELECT * FROM %s.review_master WHERE reviewID = %d ", _DB_OBJ_FULL, $this->aid);
        $pStatement_rev1 = $this->dbHand->prepare($sql_rev1);
//$pStatement_rev->bindParam(1,$this->filters['aid'],PDO::PARAM_INT);
        $pStatement_rev1->execute();

        $records_rev1 = $pStatement_rev1->fetch(PDO::FETCH_ASSOC);

        $result['detail']['0']['date'] = format_date($records_rev1['startTime']);


//get answers
//standard 7(MSR first)	
        $sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE standardID = 7 AND reviewID = %d ", _DB_OBJ_FULL, $this->aid);
        $pStatement_rev = $this->dbHand->prepare($sql_rev);
//$pStatement_rev->bindParam(1,$this->filters['aid'],PDO::PARAM_INT);
        $pStatement_rev->execute();

        $records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);

        if (count($records_rev)) {

            foreach ($records_rev as $value) {

                $answers[$value['questionID']] = $value;
            }
        }

//selected standard to overwrite msr if it has been entered
        $sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE standardID = 52 AND reviewID = %d ", _DB_OBJ_FULL, $this->aid);
        $pStatement_rev = $this->dbHand->prepare($sql_rev);
//$pStatement_rev->bindParam(1,$this->filters['aid'],PDO::PARAM_INT);
        $pStatement_rev->execute();

        $records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);
        if (count($records_rev)) {

            foreach ($records_rev as $value) {

                $answers[$value['questionID']] = $value;
            }
        }


//get standard codes

        $sql = sprintf("SELECT * FROM %s.msr_departments WHERE sID = 7 ORDER BY ID", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
//$pStatement->bindParam(1,$standard,PDO::PARAM_INT);
        $pStatement->execute();
        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        $sql = sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = 7", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $meta = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($meta as $data) {
            if (isset($data["code"])) {
// if ($this->filters['sid']==7)
                $results45[$data["questionID"]] = substr($data["code"], 0, 1);
// else
//$results45[$data["questionID"]]=$data["code"]	;
            }
        }
        $metadata = $results45;

//dump_array($metadata);
        $result = array();
        foreach ($questions_list_arr as $key => $value) {


            if (!array_key_exists($value, $metadata))
                continue;

            if ($_GET["gap"] != 1) {
				 if (!isset($answers[$value])){    
     $answers[$value]["answer"]=0;
				 }
                if ($answers[$value]["answer"] == 'NA' || $answers[$value]["answer"] == '100') //gap filling
                    continue;
            }
            $main_dep = $metadata[$value];


            $pos = $questions[$value]["display_order"];

            $background_color = $REVIEW_QUESTION_COLOR;

            if ($questions[$value]['isStowContractor'] == 1) {
                $background_color = $REVIEW_MANDATORY_COLOR;
            }
				 if (!isset($answers[$value])){    
     $answers[$value]["answer"]=0;
				 }
            $answer = $answers[$value]['answer'] == '' ? '0' : $answers[$value]['answer'];
            $answer = $answer == 'NA' ? '0' : $answer;
            $answer = $answer == 'na' ? '0' : $answer;

            switch ($answer) {
                case 0 : $option = 1;
                    break;
                case 20 : $option = 2;
                    break;
                case 80 : $option = 3;
                    break;
                case 100 : $option = 4;
                    break;
            }


            $result[$main_dep][$pos]['question_no'] = $questions[$value]['display_order'];
            $result[$main_dep][$pos]['question'] = $questions[$value]['question'];
            $result[$main_dep][$pos]['back_color'] = $background_color;
            $result[$main_dep][$pos]['answer'] = $answer;
            $result[$main_dep][$pos]['description'] = $questions[$value]['option' . $option];


  if(!isset($answers[$value]['answer']))
                                                      $result[$main_dep][$pos]['recommendation'] = $questions[$value]['recommendationOption'.$option];
  						else if ( $answers[$value]['answer'] == '' ) {
                $result[$main_dep][$pos]['recommendation'] = $questions[$value]['recommendationOption' . $option];
            } else {
                $result[$main_dep][$pos]['recommendation'] = $answers[$value]['recommendation'];
            }

            if (isset($question_msr_actions[$value])) {
                if ($question_msr_actions[$value]['whoAU'] != '') {

                    $result[$main_dep][$pos]['action_description'] = $question_msr_actions[$value]['actionDescription'];
                    $result[$main_dep][$pos]['who'] = $question_msr_actions[$value]['who'];
                    $result[$main_dep][$pos]['due_date'] = $question_msr_actions[$value]['dueDate'];
                    $result[$main_dep][$pos]['done_date'] = $question_msr_actions[$value]['doneDate'];
                    $result[$main_dep][$pos]['done_description'] = $question_msr_actions[$value]['doneDescription'];
                    $result[$main_dep][$pos]['approve'] = $question_msr_actions[$value]['approve'];
                    $result[$main_dep][$pos]['outstanding'] = $question_msr_actions[$value]['outstanding'];
                    $result[$main_dep][$pos]['status'] = $question_msr_actions[$value]['status'];
                    $result[$main_dep][$pos]['who_au'] = $question_msr_actions[$value]['whoAU'];
                    $result[$main_dep][$pos]['question_id'] = $question_msr_actions[$value]['questionID'];
                }
            }


            $sql4 = "SELECT * FROM %s.review_gap_question WHERE questionID = %d and reviewID=%d";
            $sql4_p = sprintf($sql4, _DB_OBJ_FULL, $value, $this->aid);
            $pStatement4 = $this->dbHand->prepare($sql4_p);
            $pStatement4->execute();
            $records4 = $pStatement4->fetchAll(PDO::FETCH_ASSOC);

            if (count($records4) > 0) {
                $x1 = 0;
                foreach ($records4 as $gapinfo) {

                    $partObj = SetupGeneric::useModule('Participant');
                    $partObj->setItemInfo(array(
                        'id' => $gapinfo['participantID']
                    ));
                    $participant_details = $partObj->displayItemById();
                    $participant_name1 = $participant_details['forename'] . ' ' . $participant_details['surname'];
                    $result[$main_dep][$pos]['details'][$x1]['who'] = $participant_name1;
                    $result[$main_dep][$pos]['details'][$x1]['whenDate'] = format_date($gapinfo['whenDate']);
                    $result[$main_dep][$pos]['details'][$x1]['comments'] = $gapinfo['description'];
                    $x1++;
                }
            } else {
                $result[$main_dep][$pos]['details'][0]['who'] = "";
                $result[$main_dep][$pos]['details'][0]['whenDate'] = "";
                $result[$main_dep][$pos]['details'][0]['comments'] = "";
            }
        }
//dump_array($result);

        return $result;
    }
    public function sendActionEmails($aid) {
    
  $sql = sprintf("select A.*,M.reference,M.reviewtype from %s.actions A  inner join %s.review_answers R on A.record=R.ID inner join %s.review_master M on R.reviewID=M.reviewID where moduleName='MSE_Action' and R.reviewID=%d ",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$aid);
	
  $pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

if (is_array($result)){  //only mse give actions 
		foreach($result as $value)
		
		{
                $sql2 = sprintf("UPDATE %s.actions SET status = 1 WHERE ID = " . $value['ID'], _DB_OBJ_FULL);

                $pStatement2 = $this->dbHand->prepare($sql2);
                $pStatement2->execute();

                $emailObj = new actionEmailHelper($value["ID"]);


            $who = $emailObj->getwhoDetails();

            $data = array(
                'singleColData' => array(
                    'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/icr.php">CLICK</a> Here to View ISO Clause Review Action<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/system_review_s1/pdfReporticr.php?id=' . $aid . '">CLICK</a> Here to View ISO Clause Review report'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $value["reference"]
                    )
                )
            );
            $emailObj->appendInfo($data);
            $emailObj->sendEmail('An ISO Clause Review Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

            $whoAU = $emailObj->getAUDetails();
            $emailObj->sendEmail('An ISO Clause Review Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

            if ($value['who2AU'] > 0) {
                $who2AU = $emailObj->getSecondApproverDetails();
                $emailObj->sendEmail('An ISO Clause Review Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
            }
        } 
}
//exit();
}
    
}

?>
