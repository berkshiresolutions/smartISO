<?php

/**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Interface to manage Organigram object
 *
 * This interface will declare the various methods performed
 * by organigram object for operations like add, edit, delete, archive, purge.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Interface
 * @since  Thursday, September 09, 2010 6:29:33 PM>
 */
set_time_limit(180);
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class ActionTracker {

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $identifier;
	private $moduleInfo;
	private $module;
	private $actionHandler;
	private $moduleHandler;
	private $dateFilter;

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand = DB::connect(_DB_TYPE);
		$this->actionHandler = new Action();
	}

	/*
	 * to set risk assessment information for performing various operations with an risk assessment object
	 */

	public function setActionTrackerInfo($p_moduleName, $p_tabType, $p_dateFilter = '') {

		$this->identifier = $p_tabType;
		$this->module = $p_moduleName;
		$this->dateFilter = $p_dateFilter;

		if ($this->module == '') {
			throw new ErrorException("Please specify module to get actions from.");
		} else if ($this->identifier == '') {
			throw new ErrorException("Please specify module tab to get actions for.");
		} else if ($this->identifier != 'me_pending' && $this->identifier != 'me_completed' && $this->identifier != 'other_pending' && $this->identifier != 'other_completed' && $this->identifier != 'total_action') {
			throw new ErrorException("Invalid tab identifier.");
		} else {

			$classname = 'ActionTracker' . str_replace(' ', '', ucwords(strtolower($this->module)));

			// Exception starts here
			if ($classname == 'ActionTrackerInspectionCcp') {
			
				$this->module = 'inspectionC';
			} else if ($classname == 'ActionTrackerInspectionHazard') {

				
				$this->module = 'inspectionH';
            } else if ($classname == 'ActionTrackerInspectionDue') {

				
				$this->module = 'inspectionDue';
			} else if ($classname == 'ActionTrackerInspectionManagement') {

				
				$this->module = 'inspectionM';
			} else if ($classname == 'ActionTrackerInspectionRisk') {

				
				$this->module = 'inspectionR';
			} else if ($classname == 'ActionTrackerNonconformanceInc') {

				$this->module = 'incidence';
			} else if ($classname == 'ActionTrackerNonconformanceDi') {

				$this->module = 'investigation';
			} else if ($classname == 'ActionTrackerNonconformanceNhp') {

				$this->module = 'nhp';
			} else if ($classname == 'ActionTrackerManualhandlingTask') {

				$this->module = 'manual_handlingT';
			} else if ($classname == 'ActionTrackerManualhandlingLoad') {

				$this->module = 'manual_handlingL';
			} else if ($classname == 'ActionTrackerManualhandlingEnv') {

				$this->module = 'manual_handlingE';
			} else if ($classname == 'ActionTrackerManualhandlingInd') {

				$this->module = 'manual_handlingI';
			} else if ($classname == 'ActionTrackerContributor') {

				$this->module = 'contributor';
			} else if ($classname == 'ActionTrackerNhcInv') {

				$this->module = 'nhcInvestigation';
			} else if ($classname == 'ActionTrackerGapAct') {

				$this->module = 'msr_action';
			} else if ($classname == 'ActionTrackerSmartLaw') {

				$classname = 'ActionTrackerSmartLaw';
				$this->module = 'smartlaw';
			} else if ($classname == 'ActionTrackerSmartLawReview') {

				$classname = 'ActionTrackerSmartLawReview';
				$this->module = 'smartlawreview';
            } else if ($classname == 'ActionTrackerMaintenance') {

				$classname = 'ActionTrackerMaintenance';
				$this->module = 'equipmentM';
            } else if ($classname == 'ActionTrackerCalibration') {

				$classname = 'ActionTrackerCalibration';
				$this->module = 'equipmentC';
            } else if ($classname == 'ActionTrackerBCP') {

				$classname = 'ActionTrackerBCP';
				$this->module = 'bcp';
			}  else if ($classname == 'ActionTrackerBIA') {

				$classname = 'ActionTrackerBIA';
				$this->module = 'bia';
   		}  else if ($classname == 'ActionTrackerCommsmgr') {

				$this->module = 'commsmgr';
			}else if ($classname == 'ActionTrackerContext') {

				$this->module = 'context';
			}

			
                        /* else if ( $classname == 'ActionTrackerDocControl' ) {

			  $this->module = 'doc_control';
			  } */
			// Exception ends here
				//echo $this->module;
			if (!file_exists(_MYPRIVATECLASSES . 'modules/' . $classname . '.class.php')) {
				throw new ErrorException("Failed to load class '" . $classname . "'.");
			}

			$this->moduleHandler = new $classname($this->dbHand, $this->actionHandler->viewAllActionByModule($this->module, false, $this->dateFilter));
			//$this->moduleHandler		= new $classname(& $this->dbHand, $this->actionHandler->viewAllActionByModule($this->module,false));
		}
	}

	public function getActionsForActionTracker() {

		if ($this->module == 'contributor' || $this->module == 'doc_control') {
			return $this->getPendingMeActions();
		} else {

			switch ($this->identifier) {
				case 'me_pending': return $this->getPendingMeActions();
					break;
				case 'me_completed': return $this->getCompletedMeActions();
					break;
				case 'other_pending': return $this->getPendingOtherActions();
					break;
				case 'other_completed': return $this->getCompletedOtherActions();
					break;
                                case 'total_action': return $this->getTotalActions();
					break;
			}
		}
	}

	private function getPendingMeActions() {
		return $this->moduleHandler->getPendingMeActions();
	}

	private function getCompletedMeActions() {
		return $this->moduleHandler->getCompletedMeActions();
	}

	private function getPendingOtherActions() {
        		return $this->moduleHandler->getPendingOtherActions();
	}

	private function getCompletedOtherActions() {
		return $this->moduleHandler->getCompletedOtherActions();
	}
        	private function getTotalActions() {
		return $this->moduleHandler->getTotalActions($this->dateFilter);
	}

	public function saveActionInformation($p_actionId, $p_doneDate, $p_comment) {

	
			$sql = sprintf("select doneDate,moduleName,who,whoAU from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $p_actionId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_NUM);
        $dateVal = $result[0];
        $module = $result[1];
        $who = $result[2];
        $whoAU = $result[3];

        if ($module == "risk27k") {
			$ogrObj = SetupGeneric::useModule('Organigram');
			//$ogrObj->setItemInfo(array('id'=> $who));
            $whoAUarray = $ogrObj->getManager($who);
		if ($whoAUarray)
                $whoAU = $whoAUarray["participantID"]; //changes AU if manager
			else{
                $participantObj = SetupGeneric::useModule('Participant');
                $details = $participantObj->getAdminDetails();
                $whoAU = $details["participantID"]; //changes to admin if no manager found
		}
        }
		$p_value = str_replace("'", "`", $p_comment);
		$sql = sprintf("UPDATE %s.actions
				SET
				doneDate = '%s',
				doneDescription = '%s',
				whoAU=%d
				WHERE ID = %d", _DB_OBJ_FULL, $p_doneDate, $p_value, $whoAU, $p_actionId);

	/*			
		$sql = sprintf("select doneDate from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $p_actionId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
		$dateVal = $stmt->fetchColumn(0);
		//dump_array($dateVal);
		$p_value = str_replace("'", "`", $p_comment);
		$sql = sprintf("UPDATE %s.actions
				SET
				doneDate = '%s',
				doneDescription = '%s'
				WHERE ID = %d", _DB_OBJ_FULL, $p_doneDate, $p_value, $p_actionId);
*/
		$stmt = $this->dbHand->prepare($sql);

		if (!$stmt->execute()) {
			$error_info = $stmt->errorInfo();
			throw new ErrorException($error_info[2], $error_info[1]);
        } elseif ($dateVal == '') {

			//echo $p_actionId;
			$this->actionHandler->setActionDetails($p_actionId, array());
			$action_data = $this->actionHandler->viewAction();

			//dump_array($action_data['ID']);
			//exit;
			/* Exception for msr actions */
			if ($action_data['moduleName'] == 'msr_action') {
				$action_data['moduleName'] = 'MSR Action';

				$revGapObj = new ReviewGap();
				$msr_action_data = $revGapObj->sendActionAlerts($p_actionId);
				$p_reviewID = $revGapObj->getReviewIdFromAction($p_actionId);
				$revGapObj = null;

				$revobj = new ReviewMain();
				$review_data = $revobj->getReviewInfo($p_reviewID);
				$revobj = null;

				$action_data['question'] = $msr_action_data[0]['question'];
				$action_data['reference'] = $msr_action_data[0]['reference'];
				$action_data['recommendation'] = $msr_action_data[0]['recommendation'];
				$action_data['review_type'] = $msr_action_data[0]['review_type'];
				$action_data['bu_name'] = $review_data['buName'];

				$template_identifier = 'MSRACTION_ACTION_DONE';
			} else {
				$template_identifier = 'INVESTIGATION_ACTION_DONE';
			}

			if ($action_data['moduleName'] == 'vehicleMonthly') {
				$template_identifier = 'MONTHLY_DONE';
			}
			if ($action_data['moduleName'] == 'vehicleDaily') {
				$template_identifier = 'MONTHLY_DONE';
			}
			if ($action_data['moduleName'] == 'vehicleService') {
				$template_identifier = 'SERVICE_DONE';
			}

			if ($action_data['moduleName'] == 'vehicleDocument') {
				$template_identifier = 'DOCUMENT_DONE';
			}

			if ($action_data['moduleName'] == 'nhp') {
				$action_data['moduleName'] = 'NHC';
			}
			if ($action_data['moduleName'] == 'vehicleMonthly') {


				$action_data['moduleName'] = 'Monthly Inspection';
				$action_data['ID'] = $action_data['ID'];
				$sql = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql);


				$pStatement->execute();
				$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
				if ($resultSet == '') {
					$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

					$pStatement = $this->dbHand->prepare($sql);


					$pStatement->execute();
					$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
				}
				$sql2 = sprintf("SELECT * FROM %s.vehicle WHERE ID = " . $resultSet['vID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql2);


				$pStatement->execute();
				$data = $pStatement->fetch(PDO::FETCH_ASSOC);
				if ($resultSet['name']) {
					$action_data['name'] = $resultSet['name'];
				} else {
					$action_data['name'] = $resultSet['dailyInspection'];
				}

				$action_data['type'] = $resultSet['type'];
				if ($action_data['type'] == "1") {
					$action_data['type'] = "External";
				}
				if ($action_data['type'] == "2") {
					$action_data['type'] = "Fluids";
				}
				if ($action_data['type'] == "3") {
					$action_data['type'] = "Internal";
				}
				if ($action_data['type'] == "4") {
					$action_data['type'] = "Functional";
				}
				if ($action_data['type'] == "5") {
					$action_data['type'] = "Equipment";
				}
				if ($action_data['type'] == "0") {
					$action_data['type'] = "Custom";
				}
				$action_data['fre'] = 'Monthly';

				$action_data['comment'] = $action_data['doneDescription'];
				$action_data['ref'] = $data['uniqueReference'];
				$action_data['make'] = $data['vehicleMake'];
				if ($action_data['make'] == "" || $action_data['make'] == "0") {
					$action_data['make'] = "-";
				}

				$action_data['model'] = $data['vehicleModel'];
				if ($action_data['model'] == "" || $action_data['model'] == "0") {
					$action_data['model'] = "-";
				}
				$action_data['p'] = $data['permanentOwnerName'];

				$action_data['t'] = $data['temporaryOwnerName'];
			}
			if ($action_data['moduleName'] == 'vehicleDaily') {
				$action_data['moduleName'] = 'Daily Inspection';
				$action_data['ID'] = $action_data['ID'];
				$sql = sprintf("SELECT * FROM %s.perform_vehicle_daily WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql);


				$pStatement->execute();
				$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
				$sql2 = sprintf("SELECT * FROM %s.vehicle WHERE ID = " . $resultSet['vID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql2);


				$pStatement->execute();
				$data = $pStatement->fetch(PDO::FETCH_ASSOC);
				$action_data['name'] = $resultSet['name'];
				$action_data['type'] = $resultSet['type'];
				if ($action_data['type'] == "1") {
					$action_data['type'] = "External";
				}
				if ($action_data['type'] == "2") {
					$action_data['type'] = "Fluids";
				}
				if ($action_data['type'] == "3") {
					$action_data['type'] = "Internal";
				}
				if ($action_data['type'] == "4") {
					$action_data['type'] = "Functional";
				}
				if ($action_data['type'] == "5") {
					$action_data['type'] = "Equipment";
				}
				if ($action_data['type'] == "0") {
					$action_data['type'] = "Custom";
				}
				$action_data['fre'] = 'Daily';
				//$action_data['date'] = $resultSet['dateDaily'];
				$action_data['comment'] = $action_data['doneDescription'];
				$action_data['ref'] = $data['uniqueReference'];
				$action_data['make'] = $data['vehicleMake'];
				if ($action_data['make'] == "" || $action_data['make'] == "0") {
					$action_data['make'] = "-";
				}

				$action_data['model'] = $data['vehicleModel'];
				if ($action_data['model'] == "" || $action_data['model'] == "0") {
					$action_data['model'] = "-";
				}
				$action_data['p'] = $data['permanentOwnerName'];

				$action_data['t'] = $data['temporaryOwnerName'];
			}

			if ($action_data['moduleName'] == 'vehicleService') {
				$action_data['moduleName'] = 'Service';
				$action_data['ID'] = $action_data['ID'];
				$sql = sprintf("SELECT * FROM %s.perform_vehicle_service WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql);


				$pStatement->execute();
				$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
				if ($resultSet == "") {
					$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

					$pStatement = $this->dbHand->prepare($sql);


					$pStatement->execute();
					$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
				}
				$sql2 = sprintf("SELECT * FROM %s.vehicle WHERE ID = " . $resultSet['vID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql2);


				$pStatement->execute();
				$data = $pStatement->fetch(PDO::FETCH_ASSOC);
				if ($resultSet['service']) {
					$action_data['name'] = $resultSet['service'];
				} else {
					$action_data['name'] = $resultSet['servicingRequired'];
				}
				if ($resultSet['services']) {
					$action_data['mil'] = $resultSet['services'];
				} else {
					$action_data['mil'] = $resultSet['mileage'];
				}

				$action_data['type'] = $resultSet['type'];


				$action_data['comment'] = $action_data['doneDescription'];
				$action_data['ref'] = $data['uniqueReference'];
				$action_data['make'] = $data['vehicleMake'];
				if ($action_data['make'] == "" || $action_data['make'] == "0") {
					$action_data['make'] = "-";
				}

				$action_data['model'] = $data['vehicleModel'];
				if ($action_data['model'] == "" || $action_data['model'] == "0") {
					$action_data['model'] = "-";
				}
				$action_data['p'] = $data['permanentOwnerName'];

				$action_data['t'] = $data['temporaryOwnerName'];
			}
			if ($action_data['moduleName'] == 'vehicleDocument') {
				$action_data['moduleName'] = 'Document';
				$action_data['ID'] = $action_data['ID'];

				$sql = sprintf("SELECT * FROM %s.vehicle_document_action WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql);


				$pStatement->execute();
				$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



				$sql2 = sprintf("SELECT * FROM %s.vehicle WHERE ID = " . $resultSet['vID'], _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql2);


				$pStatement->execute();
				$data = $pStatement->fetch(PDO::FETCH_ASSOC);

				$action_data['name'] = $action_data['actionDescription'];


				$action_data['type'] = $resultSet['type'];


				$action_data['comment'] = $action_data['doneDescription'];
				$action_data['ref'] = $data['uniqueReference'];
				$action_data['make'] = $data['vehicleMake'];
				if ($action_data['make'] == "" || $action_data['make'] == "0") {
					$action_data['make'] = "-";
				}

				$action_data['model'] = $data['vehicleModel'];
				if ($action_data['model'] == "" || $action_data['model'] == "0") {
					$action_data['model'] = "-";
				}
				$action_data['p'] = $data['permanentOwnerName'];

				$action_data['t'] = $data['temporaryOwnerName'];

				//dump_array($action_data);
				//exit;
			}


			$action_data['FULLHOSTNAME'] = _MYSERVER;
			$action_data['dueDate'] = format_date($action_data['dueDate']);
			$action_data['doneDate'] = format_date($action_data['doneDate']);
			$action_data['email_subject'] = "Action approval required";
			if ($action_data['moduleName'] == 'Daily Inspection') {

				$action_data['email_subject'] = "smart-ISO action for Smart Fleet Inspection";
			}
			if ($action_data['moduleName'] == 'Monthly Inspection') {

				$action_data['email_subject'] = "smart-ISO action for Smart Fleet Inspection";
			}
			if ($action_data['moduleName'] == 'Service') {

				$action_data['email_subject'] = "smart-ISO action for Smart Fleet Service";
			}
			if ($action_data['moduleName'] == 'Document') {

				$action_data['email_subject'] = "smart-ISO action for Smart Fleet Document Upload";
			}


			$objEmail = new Email('html');
			$participantObj = SetupGeneric::useModule('Participant');

			if ($action_data['whoAU']) {
			
					
				$actionHandler = new Action();
				
					$res = $actionHandler->viewRisk27kSelectDetail($action_data['ID']);

				$participantObj->setItemInfo(array('id' => $action_data['whoAU']));
				$participantData = $participantObj->displayItemById();

				$participantObj->setItemInfo(array('id' => $action_data['who']));
				$participantDataWho = $participantObj->displayItemById();

				$salutation = trim($participantData['gender']) == 'F' ? 'Ms' : 'Mr.';
				$mail_address = $participantData['emailAddress'];
				//dump_array($mail_address);
				$name = $participantData['forename'] . ' ' . $participantData['surname'];

				$action_data['who'] = $participantDataWho['forename'] . ' ' . $participantDataWho['surname'];
				$action_data['ID'] = $action_data['ID'];


				$emailObj = new actionEmailHelper($action_data['ID']);
				//$who=$emailObj->getwhoDetails();
				//$sentence=array('sentence'=>array("You have an action to carry out the following risk Action"));	
				//$emailObj->appendInfo($sentence);
				//$data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/">CLICK</a> Here to View Risk  Action'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>'')));
				//$emailObj->appendInfo($data);
				//$emailObj->sendEmail('A Risk Action To Be Carried Out',$who,array(),array(),'me_completed','','grey');
				//dump_array($data);
				$whoAU = $emailObj->getAUDetails();
				
				if ($action_data['moduleName'] == 'equipmenM') {

				//$slawdata = $this->getActionsbyID($action_id);

				$sentence = array('sentence' => array("You have an action to approve the following Equipment Maintenance Action"));
				$emailObj->appendInfo($sentence);
				
				//$ref = $data['uniqueReference'];
				//$data1 = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/">CLICK</a> Here to View Risk Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $ref)));

				$data1 = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/">CLICK</a> Here to View Equipment Maintenance Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $res["reference"]
							)
					)
			);
				$emailObj->appendInfo($data1);
				$emailObj->sendEmail('An Equipment Maintenance  Action To Be Approved', $whoAU, array(), array(), 'me_completed', '', 'grey');
                } else {
				
				//$slawdata = $this->getActionsbyID($action_id);

				$sentence = array('sentence' => array("You have an action to approve the following Equipment Action"));
				$emailObj->appendInfo($sentence);
				
				//$ref = $data['uniqueReference'];
				//$data1 = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/">CLICK</a> Here to View Risk Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $ref)));

				$data1 = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/">CLICK</a> Here to View Equipment  Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => 'EQ140517313'
							)
					)
			);
				$emailObj->appendInfo($data1);

//removed by bob to spurious emails not sure how we get here 
			//	$emailObj->sendEmail('A Equipment  Action To Be Approved', $whoAU, array(), array(), 'me_completed', '', 'grey');
				}
				//echo $template_identifier;
				if ($mail_address != '') {

					//echo $salutation;
					//dump_array($action_data);
					try {
						$objEmail->addRecipient($name, $mail_address, $salutation);
						$objEmail->generateEmailFromData($template_identifier, $action_data);
						//$objEmail->send(_LIVE_MODE);
					} catch (ErrorException $e) {
						$e->getMessage();
					}
				}
			}
		}
	}

	public function getNameWhoAU($id_au) {

		$this->id = $id_au;
		$sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $this->id, _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		$name = ucwords($result['forename'] . ' ' . $result['surname']);
		return $name;
	}

	public function getDetailsAction($id_au) {

		$this->id = $id_au;
		$sql = sprintf("SELECT * FROM %s.actions WHERE ID = " . $this->id, _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function updateDueDate($action_id, $date, $who, $whoAU) {

		$this->action_id = $action_id;
		$this->date_due = $date;
		$this->who = $who;
		$this->whoAU = $whoAU;


		$sql = sprintf("UPDATE %s.actions
				SET
				dueDate = '" . $this->date_due . "',
				who = " . $this->who . ",
				whoAU = " . $this->whoAU . ",
				doneDate = NULL,
				doneDescription= ''
			
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		/* $stmt->bindParam(1,$approve);
		  $stmt->bindParam(2,$p_actionId); */
		$stmt->execute();
	}

    


     public function updateApp2($action_id, $date, $reason, $who, $action, $action_str) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;

        $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
                                addapprover = " . $this->who . ",
			        last_action='Action Updated',
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	
		
			$emailObj = new actionEmailHelper($action_id);
                        
			$who = $emailObj->getSecondApproverDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/'.$action_str.'?id='.$action_id.'">CLICK</a> Here to View '.$module.' Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Reason</strong>', 
								'right' => $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			

			$emailObj->sendEmail('A '.$action.' Action To Be Second Approved', $who, array(), $cto, 'me_completed', '', 'grey');

			
        
        
    }
    
    public function approveAlert($action_id, $date, $reason,$action) {

        $this->action_id = $action_id;
        $this->date = $date;
        $this->who = $who;
        $this->reason = $reason;

        $sql = sprintf("UPDATE %s.actions
				SET
				approvecomment = '" . $this->reason . "',
                                approveAU = 1,
                                approvedate = '" . $this->date . "'  ,
                                last_action='Completed',
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    /*    
        $emailObj = new actionEmailHelper($action_id);

        $recordData = $this->getRecordData($action_id);


        		$participantObj = SetupGeneric::useModule('Participant');
	
		
			$participantObj->setItemInfo(array('id'=>$recordData["whoID"]));
	
			$details = $participantObj->displayItemById();
			$who = array(
				'displayname' => ucwords($details['forename'].' '.$details['surname']),
				'email' => $details['emailAddress'],
				'ID' => $details['participantID']
			);
       

         $data = array(
            'singleColData' => array(
                'click-here-url' => ''
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $recordData['reference']
                ),
                'reason' => array(
                    'left' => '<strong>Reason</strong>',
                    'right' => 'This action has been completed.' 
                )
            )
        );

        $emailObj->appendInfo($data);

        $emailObj->sendEmail('The ' . $action . ' action has been completed', $who, array(), array(), 'me_completed', '', 'grey');

*/
    }

        
    public function approve2AppAlert($action_id, $date, $reason,$action,$action_str) {

        $this->action_id = $action_id;
        $this->date = $date;
        $this->reason = $reason;

        $sql = sprintf("UPDATE %s.actions
				SET
				approve2comment = '" . $this->reason . "',
                                currentWho = whoAU,
                                app2date = '" . $this->date . "'  ,
                                last_action='Verified',
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
      

        $stmt->execute();
      
    }
    
	public function approveCompletedAction($p_actionId) {

		$approve = 1;

		$sql = sprintf("UPDATE %s.actions
				SET
				approve = '%s'
				WHERE ID = %d
				AND doneDate IS NOT NULL", _DB_OBJ_FULL, $approve, $p_actionId);

		$stmt = $this->dbHand->prepare($sql);

		/* $stmt->bindParam(1,$approve);
		  $stmt->bindParam(2,$p_actionId); */

		if (!$stmt->execute()) {
			$error_info = $stmt->errorInfo();
			throw new ErrorException($error_info[2], $error_info[1]);
		}
	}

	public function getNameWho($who) {
		$this->who = $who;
		$sql2 = sprintf("SELECT surname,forename,emailAddress FROM %s.participant_database WHERE participantID = " . $this->who, _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql2);

		$pStatement->execute();

		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $result_1;
	}

	public function getactiondetail($id) {
		$this->id = $id;
		$sql1 = sprintf("SELECT moduleName,actionDescription FROM %s.actions WHERE ID =" . $this->id, _DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql1);
		$pStatement->execute();
		$result_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $result_1;
	}

	public function getincidenceaction($action) {
		$this->action = $action;
		$sql3 = sprintf("SELECT reference,buID,actionsID,problemDescription FROM %s.incidence
							WHERE actionsID LIKE '" . $this->action . "'", _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql3);

		$pStatement->execute();

		$res_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $res_1;
	}

	public function getnhpaction($action) {
		$this->action = $action;
		$sql3 = sprintf("SELECT reference,businessUnitID,actionsID,problemDescription FROM %s.nhp
							WHERE actionsID LIKE '" . $this->action . "'", _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql3);

		$pStatement->execute();

		$res_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $res_1;
	}

	public function getincaction($action) {
		$this->action = $action;
		$sql3 = sprintf("SELECT C.*,N.ID,buID,problemDescription FROM %s.investigation C
												INNER JOIN %s.incidence N
											ON N.ID = C.incID
							WHERE actionsID LIKE '" . $this->action . "'", _DB_OBJ_FULL, _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql3);

		$pStatement->execute();

		$res_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $res_1;
	}

	public function getinvnhpaction($action) {
		$this->action = $action;
		$sql3 = sprintf("SELECT C.*,N.ID,businessUnitID,problemDescription FROM %s.nhc_investigation C
												INNER JOIN %s.nhp N
											ON N.ID = C.incID WHERE actionsID LIKE '" . $this->action . "'", _DB_OBJ_FULL, _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql3);

		$pStatement->execute();

		$res_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $res_1;
	}

	public function approveAUApprovedAction($p_actionId) {

		$outstanding = 2;
		$au_approve = 1;


		$sql = sprintf("UPDATE %s.actions
				SET
				outstanding = '%s',
				approveAU = '%s'
				WHERE ID = %d
				", _DB_OBJ_FULL, $outstanding, $au_approve, $p_actionId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$sql1 = sprintf("select * from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $p_actionId);

		$stmt = $this->dbHand->prepare($sql1);
		$stmt->execute();
		$action_data = $stmt->fetch();
		
			if ($action_data['moduleName'] == 'nhp') {
			
            $thi_id = '%' . $action_data['ID'] . '%';
			//echo _DB_OBJ_FULL;
            $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".nhp WHERE actionsID LIKE '" . $thi_id . "'";
				//$psql = sprintf($sql, _DB_OBJ_FULL);
			$pStatement = $this->dbHand->prepare($sql);


			$pStatement->execute();
			$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
			
			$emailObj = new actionEmailHelper($p_actionId);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NHC Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_nhp.php?filter_date=">CLICK</a> Here to View NCR Investigation Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $resultSet['reference']
							),
							'actionid1' => array(
								'left' => '<strong>Problem Description</strong>', 
								'right' => $resultSet['problemDescription']
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
		//	$emailObj->sendEmail('A NHC  Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();

				
				$sentence = array('sentence' => "You have an action to approve the following NHC  Action");
				$emailObj->appendInfo($sentence);
				$who = $emailObj->getAUDetails();
				$emailObj->sendEmail('A NHC  Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
		
			$d = array();
			
            $pieces = explode(",", $resultSet['actionsID']);
				$i = 0;
				//dump_array($pieces);
            foreach ($pieces as $val) {
				
				  $sql1 = sprintf("select * from %s.actions WHERE ID = %d AND approveAU = 0", _DB_OBJ_FULL, $val);

				$stmt = $this->dbHand->prepare($sql1);
				$stmt->execute();
				$action_data = $stmt->fetch(PDO::FETCH_ASSOC);
				$d = $action_data;
				$i++;
				}
				//dump_array($d);
            if ($d == '') {
			//dump_array($d);
				  $sql99 = sprintf("UPDATE %s.nhp
				SET
				status = '2' WHERE ID =" . $resultSet['ID'], _DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql99);
			$stmt->execute();
			}
			}
			
			if ($action_data['moduleName'] == 'incidence') {
			
            $thi_id = '%' . $action_data['ID'] . '%';

            $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".incidence WHERE actionsID LIKE '" . $thi_id . "'";
				//$psql = sprintf($sql, _DB_OBJ_FULL);
			$pStatement = $this->dbHand->prepare($sql);



			$pStatement->execute();
			$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
			$emailObj = new actionEmailHelper($action_data['ID']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_inc.php?filter_date=">CLICK</a> Here to View Incidence Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $resultSet['reference']
							),
							'actionid1' => array(
								'left' => '<strong>Problem Description</strong>', 
								'right' => $resultSet['problemDescription']
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
		//	$emailObj->sendEmail('A NHC  Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();

				
				$sentence = array('sentence' => "You have an action to approve the following Incidence Action");
				$emailObj->appendInfo($sentence);
				$who = $emailObj->getAUDetails();
				$emailObj->sendEmail('An Incidence  Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
		
			$d = array();
			//dump_array($resultSet);
            $pieces = explode(",", $resultSet['actionsID']);
				$i = 0;
            foreach ($pieces as $val) {
				
				 $sql1 = sprintf("select * from %s.actions WHERE ID = %d AND approveAU = 0", _DB_OBJ_FULL, $val);

				$stmt = $this->dbHand->prepare($sql1);
				$stmt->execute();
				$action_data = $stmt->fetch(PDO::FETCH_ASSOC);
				$d = $action_data;
				$i++;
				}
				
            if ($d == '') {
			
				 $sql99 = sprintf("UPDATE %s.incidence
				SET
				status = '2' WHERE ID =" . $resultSet['ID'], _DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql99);
			$stmt->execute();
			}
			}
			
			if ($action_data['moduleName'] == 'investigation') {
			
            $thi_id = '%' . $action_data['ID'] . '%';

            $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".investigation WHERE actionsID LIKE '" . $thi_id . "'";

			

			$pStatement = $this->dbHand->prepare($sql);


			$pStatement->execute();
			$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
			
			$emailObj = new actionEmailHelper($action_data['ID']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Investigation Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_di.php?filter_date=">CLICK</a> Here to View Investigation Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $resultSet['reference']
							),
							'actionid1' => array(
								'left' => '<strong>Problem Description</strong>', 
								'right' => $resultSet['incidentAnalysisDescription']
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
		//	$emailObj->sendEmail('A NHC  Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();

				
				$sentence = array('sentence' => "You have an action to approve the following Investigation Action");
				$emailObj->appendInfo($sentence);
				$who = $emailObj->getAUDetails();
				$emailObj->sendEmail('An Investigation  Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
		
			$d = array();
			//dump_array($resultSet);
            $pieces = explode(",", $resultSet['actionsID']);
				$i = 0;
            foreach ($pieces as $val) {
				
				 $sql1 = sprintf("select * from %s.actions WHERE ID = %d AND approveAU = 0", _DB_OBJ_FULL, $val);

				$stmt = $this->dbHand->prepare($sql1);
				$stmt->execute();
				$action_data = $stmt->fetch(PDO::FETCH_ASSOC);
				$d = $action_data;
				$i++;
				}
				
            if ($d == '') {
			
				 $sql99 = sprintf("UPDATE %s.investigation
				SET
				status = 2 WHERE ID =" . $resultSet['ID'], _DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql99);
			$stmt->execute();
			}
			}
			if ($action_data['moduleName'] == 'nhcInvestigation') {
			
            $thi_id = '%' . $action_data['ID'] . '%';

            $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".nhc_investigation WHERE actionsID LIKE '" . $thi_id . "'";

			

			$pStatement = $this->dbHand->prepare($sql);


			$pStatement->execute();
			$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
			
			$emailObj = new actionEmailHelper($action_data['ID']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following NCR Investigation Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/nhc_inv.php?filter_date=">CLICK</a> Here to View NCR Investigation Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $resultSet['reference']
							),
							'actionid1' => array(
								'left' => '<strong>Problem Description</strong>', 
								'right' => $resultSet['incidentAnalysisDescription']
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
		//	$emailObj->sendEmail('A NHC  Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();

				
				$sentence = array('sentence' => "You have an action to approve the following NCR Investigation Action");
				$emailObj->appendInfo($sentence);
				$who = $emailObj->getAUDetails();
				$emailObj->sendEmail('A NCR Investigation  Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
		
			$d = array();
			//dump_array($resultSet);
            $pieces = explode(",", $resultSet['actionsID']);
				$i = 0;
            foreach ($pieces as $val) {
				
				 $sql1 = sprintf("select * from %s.actions WHERE ID = %d AND approveAU = 0", _DB_OBJ_FULL, $val);

				$stmt = $this->dbHand->prepare($sql1);
				$stmt->execute();
				$action_data = $stmt->fetch(PDO::FETCH_ASSOC);
				$d = $action_data;
				$i++;
				}
				
            if ($d == '') {
			
				 $sql99 = sprintf("UPDATE %s.nhc_investigation
				SET
				status = 2 WHERE ID =" . $resultSet['ID'], _DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql99);
			$stmt->execute();
			}
			}

		//dump_array($action_data);

		if ($action_data['moduleName'] == 'vehicleDocument') {
			//$action_data['moduleName'] = 'Document';
			$action_data['ID'] = $action_data['ID'];

			$sql = sprintf("SELECT * FROM %s.vehicle_document_action WHERE actionID = " . $action_data['ID'], _DB_OBJ_FULL);

			$pStatement = $this->dbHand->prepare($sql);


			$pStatement->execute();
			$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



			$sql2 = sprintf("SELECT * FROM %s.vehicle WHERE ID = " . $resultSet['vID'], _DB_OBJ_FULL);

			$pStatement = $this->dbHand->prepare($sql2);


			$pStatement->execute();
			$data = $pStatement->fetch(PDO::FETCH_ASSOC);

			$action_data['name'] = $action_data['actionDescription'];



			$action_data['comment'] = $action_data['doneDescription'];
			$action_data['ref'] = $data['uniqueReference'];
			$action_data['make'] = $data['vehicleMake'];
			if ($action_data['make'] == "" || $action_data['make'] == "0") {
				$action_data['make'] = "-";
			}

			$action_data['model'] = $data['vehicleModel'];
			if ($action_data['model'] == "" || $action_data['model'] == "0") {
				$action_data['model'] = "-";
			}
			$action_data['p'] = $data['permanentOwnerName'];

			$action_data['t'] = $data['temporaryOwnerName'];
			$piec = explode("-", $action_data['dueDate']);
			$sql28 = sprintf("SELECT * FROM %s.addFrequency WHERE archive is NULL OR archive ='0'", _DB_OBJ_FULL);

			$pStatement = $this->dbHand->prepare($sql28);


			$pStatement->execute();
			$data_g = $pStatement->fetchAll(PDO::FETCH_ASSOC);

			if ($action_data['name'] == $data_g['0']['name']) {
				$piec[0] = $piec[0] + $data_g['0']['year'];
			}
			if ($action_data['name'] == $data_g['1']['name']) {
				$piec[0] = $piec[0] + $data_g['1']['year'];
			}
			if ($action_data['name'] == $data_g['2']['name']) {
				$piec[0] = $piec[0] + $data_g['2']['year'];
			}


			$d_d = $piec[0] . '-' . $piec[1] . '-' . $piec[2];

			$done_d = explode("-", $d_d);
			$d_d_1 = $done_d[1] . '/' . $done_d[2] . '/' . $done_d[0];

			$date_up = explode(",", $data['licenceDate']);

			if ($action_data['actionDescription'] == $data_g['0']['name']) {
				$date_up['0'] = $d_d_1;
			}
			if ($action_data['actionDescription'] == $data_g['1']['name']) {
				$date_up['1'] = $d_d_1;
			}
			if ($action_data['actionDescription'] == $data_g['2']['name']) {
				$date_up['2'] = $d_d_1;
			}
			$done_act = implode(",", $date_up);

			$sql99 = sprintf("UPDATE %s.vehicle
				SET
				licenceDate = '" . $done_act . "' WHERE ID =" . $resultSet['vID'], _DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql99);
			$stmt->execute();

			$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,dueDate,whoAU,status) VALUES('" . $action_data['moduleName'] . "','" . $action_data['name'] . "'," . $action_data['who'] . ",'" . $d_d . "'," . $action_data['whoAU'] . ",1)", _DB_OBJ_FULL);

			$pStatement = $this->dbHand->prepare($sql);
			if ($pStatement->execute()) {

				$lastId = customLastInsertId($this->dbHand, 'actions', 'ID');
				//$lastId = $this->dbHand->lastInsertId();

				$sql = sprintf("INSERT INTO %s.vehicle_document_action (vID,actionID,documentID) VALUES(" . $resultSet['vID'] . "," . $lastId . "," . $resultSet['documentID'] . ")", _DB_OBJ_FULL);

				$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();
				//return $lastId;
			} else {
				/* dump_array($pStatement->errorInfo());
				  exit; */
			}

			//dump_array($action_data);
			//exit;
		}
	}

	public function getActionsForActionTrackerDue() {
	

        $sql = sprintf("SELECT * FROM %s.actions WHERE  moduleName = 'inspectionDue' ", _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		
		$pStatement->execute();
		
		$re = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		return $re;
	}
	
		public function countDocControl($id) {
		$this->id = $id;
        if ($this->id == 2) {
		
		//dump_array($val);

            $sql = sprintf("SELECT * FROM %s.cms_document_alerts WHERE  alertStatus = 'N' ", _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		
		$pStatement->execute();
		
		$re = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		
		
		return $re;
        } else {
            $sql = sprintf("SELECT * FROM %s.cms_documents WHERE  initiatedByParticipant =" . $this->id, _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$c = 0;
            foreach ($resultSet as $val) {
		
		//dump_array($val);

                $sql = sprintf("SELECT * FROM %s.cms_document_alerts WHERE  alertStatus = 'N' AND cmsdocID =" . $val['cmsdocID'], _DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		
		$pStatement->execute();
		
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$c = 0;
                foreach ($result as $v) {
		//echo $c = count($result);
		
		
		$re[$c] = $v;
			$c++;
		}
		}
		//dump_array($re);
		return $re;
		}
		}
	
    public function sendEquipmentAUemail($p_id, $type, $reference, $title) {

			$emailObj = new actionEmailHelper($p_id);

			$whoAU = $emailObj->getAUDetails();
				
				if ($type == 'Maintenance') {
            $description = "<strong>Summary</strong><BR>Equipment Maintenance has been be carried out on " . $title;
					$sentence = array('sentence' => array("You have an action to approve the following Equipment Maintenance Action"));
            $tracker = "equipment_main.php";
        } else {
            $description = "<strong>Summary</strong><BR>Equipment Calibration has been carried out on " . $title;
					$sentence = array('sentence' => array("You have an action to approve the following Equipment Calibration Action"));	
            $tracker = "equipment_cali.php";
			}
			
				$emailObj->appendInfo($sentence);


				$data1 = array(
					'singleColData' => array(
                'click-here-url' => '<BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $tracker . '">CLICK</a> here to approve ' . $type . ' Action',
                'summary' => $description
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $reference
							)
					)
			);
				$emailObj->appendInfo($data1);
        $emailObj->sendEmail('An Equipment ' . $type . ' Action To Be Approved', $whoAU, array(), array(), 'me_completed', '', 'grey');
		}
		
		public function trainRecordCount($p_id) {
        if (isAdministrator())
            $sql = sprintf("SELECT count(*) as trainCount FROM %s.actions WHERE moduleName like '%s' AND doneDate is NULL", _DB_OBJ_FULL, "train%");
			else
            $sql = sprintf("SELECT count(*) as trainCount FROM %s.actions WHERE moduleName like '%s' AND who = %d AND doneDate is NULL", _DB_OBJ_FULL, "train%", $p_id);

			$pStatement = $this->dbHand->prepare($sql);


			$pStatement->execute();
			$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
			
			return $resultSet["trainCount"];
    }

    public function saveActionInformation2($p_actionId, $p_doneDate, $p_comment, $actionx, $action_str, $not_complete,$action='Actioned') {

        
        $manObj = SetupGeneric::useModule('Participant');


       $sql = sprintf("select * from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $p_actionId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $data = $manObj->getManagerDetails($result["who"]);
        if ($data["participantID"] == 0)
            $data = $manObj->getAdminDetails();

        if ((int) $result["addapprover"] > 0) {
            $currentuser = $result["addapprover"];
        } else {
            $currentuser = $data["participantID"];
		}

        if ($not_complete == "2")
            $p_value = "This action has been rejected for the following reason<BR><BR>" . str_replace("'", "`", $p_comment);
        elseif ($not_complete == "1")
            $p_value = "This action has not been completed for the following reason<BR><BR>" . str_replace("'", "`", $p_comment);
        else
            $p_value = str_replace("'", "`", $p_comment);
	

       $sql = sprintf("UPDATE %s.actions
				SET
				doneDate = '%s',
				doneDescription = '%s',
                                currentWho=%d,
                                whoAU=%d,
                                last_action='%s',
                                timechanged=getdate()
				WHERE ID = %d", _DB_OBJ_FULL, $p_doneDate, $p_value, $currentuser, $data["participantID"],$action, $p_actionId);


        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $emailObj = new actionEmailHelper($p_actionId);

        $whoAU = $emailObj->getAUDetails();
        $refData = $this->getRecordData($p_actionId);
        if ($not_complete == "2") {
            $description = "<strong></strong><BR>" . $p_value;
            $app_view = "View ";
        }
        elseif ($not_complete == "1") {
            $description = "<strong></strong><BR>" . $p_value;
            $app_view = "View ";
        } else {
            $description = "<strong></strong><BR>The action has been completed and needs to be approved";
            $app_view = "Approve ";
}

        $data1 = array(
            'singleColData' => array(
                'summary1' => $description,
                'click-here-url' => '<BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $action_str . '?id='.$p_actionId.'">CLICK</a> here to ' . $app_view . $type . ' Action',
                
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $refData["reference"]
                )
            )
        );
       
        if (isset($refData["problem"])) {
    $data1['twoColData']['problem']['left'] = '<strong>Problem</strong>';
    $data1['twoColData']['problem']['right'] = $refData["problem"];
        }
        
        $emailObj->appendInfo($data1);

        if ($not_complete == "1" || $not_complete == "2" )
            $emailObj->sendEmail($actionx . ' Action To Be Reviewed', $whoAU, array(), array(), 'me_completed', '', 'grey');
        else
            $emailObj->sendEmail($actionx . ' Action To Be Approved', $whoAU, array(), array(), 'me_completed', '', 'grey');

        if ((int) $result["addapprover"] > 0 && $not_complete == "0") {
            $who = $emailObj->getwhoDetails();
            $description = "<strong></strong><BR>The action has been completed and sent to the Second Approver";
            $data1 = array(
                'singleColData' => array(
                    'summary1' => $description
                )
            );
            $emailObj->appendInfo($data1);
            $emailObj->sendEmail($actionx . ' Action Has been Sent for Second Approval  ', $who, array(), array(), 'me_completed', '', 'grey');
        }
    }

    public function getRecordData($action) {
        $this->action = $action;
       $sql = sprintf("SELECT record,moduleElement FROM %s.actions where ID=%d ", _DB_OBJ_FULL, $this->action);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $res = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($res['moduleElement']=='smart_action_list'){
           $sqla = sprintf("select S.Uniquereference as reference from %s.smart_action_list L  left join %s.smart_action S on L.a_id=S.ID  where L.ID=%d", _DB_OBJ_FULL,_DB_OBJ_FULL, $res['record']);
        }
        else if ($res['moduleElement']=='smartlaw_review'){
           $sqla = sprintf("select S.ref_no as reference from %s.smartlaw_review R  left join %s.smartlaw_sections S on R.smartlawID=S.slsID where R.ID=%d",  _DB_OBJ_FULL,_DB_OBJ_FULL, $res['record']);
        }
        else if ($res['moduleElement']=='smartlaw_sections'){
           $sqla = sprintf("select ref_no as reference from %s.smartlaw_sections where slsID=%d",_DB_OBJ_FULL, $res['record']);
        }

        else if ($res['moduleElement']=='compliance_answer'){
          $sqla = sprintf("select * from %s.compliance_answer A inner join %s.compliance_master M on A.complianceID=M.reviewid   where A.ID=%d", _DB_OBJ_FULL,_DB_OBJ_FULL, $res['record']);
           
        }
        else{
     
    $sqla = sprintf("SELECT * FROM %s.%s where ID=%d ", _DB_OBJ_FULL, $res['moduleElement'], $res['record']);
        }
   
        $pStatement = $this->dbHand->prepare($sqla);
        $pStatement->execute();
        $resData = $pStatement->fetch(PDO::FETCH_ASSOC);
if ($res['moduleElement']=='risk')
     $resData["reference"]=$resData['processReference'];
if ($res['moduleElement']=='nhp')
     $resData["problem"]=$resData['problemDescription'];
if ($res['moduleElement']=='assestmangement')
     $resData["reference"]=$resData[ref];

        return $resData;
    }
    public function getComments($action) {
        $this->action = $action;
        $sql = sprintf("SELECT actionDescription,doneDescription,approve2Comment,approveComment FROM %s.actions where ID=%d ", _DB_OBJ_FULL, $this->action);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $res = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $res;
    }
    
    public function saveActionInformationAdmin($p_actionId, $p_doneDate, $p_comment, $action, $action_str, $not_complete) {

        $manObj = SetupGeneric::useModule('Participant');


       $sql = sprintf("select * from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $p_actionId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

  
            $p_value = "This action has been closed By the Administrator<BR><BR>" . str_replace("'", "`", $p_comment);
	

       $sql = sprintf("UPDATE %s.actions
				SET
				doneDate = '%s',
				doneDescription = '%s',
                                approveComment = 'Closed by the Administrator',
                                approveAU = 1 
				WHERE ID = %d", _DB_OBJ_FULL, $p_doneDate, $p_value,  $p_actionId);


        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

$actObj->updatehistory($actionId);
$updater= getLoggedInUserId();
        $sql = sprintf("UPDATE %s.actions
				SET
				
			        last_action='Completed',
                                updater=%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $emailObj = new actionEmailHelper($p_actionId);

        $who = $emailObj->getwhoDetails();
        $refData = $this->getRecordData($p_actionId);

            $description = "<strong></strong><BR>The action has been completed and approved by the administrator";
            $app_view = "Approve ";


        $data1 = array(
            'singleColData' => array(
                'summary1' => $description,
                'click-here-url' => '<BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $action_str . '?id='.$p_actionId.'">CLICK</a> here to ' . $app_view . $type . ' Action',
                
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $refData["reference"]
                )
            )
        );
       
        if (isset($refData["problem"])) {
    $data1['twoColData']['problem']['left'] = '<strong>Problem</strong>';
    $data1['twoColData']['problem']['right'] = $refData["problem"];
        }
        
        $emailObj->appendInfo($data1);


            $emailObj->sendEmail($action . ' Action Has Been Closed', $who, array(), array(), 'me_completed', '', 'grey');

            
            
            $recordData = $this->getRecordData($action_id);


        		$participantObj = SetupGeneric::useModule('Participant');
	
		
			$participantObj->setItemInfo(array('id'=>$recordData["whoID"]));
	
			$details = $participantObj->displayItemById();
			$who = array(
				'displayname' => ucwords($details['forename'].' '.$details['surname']),
				'email' => $details['emailAddress'],
				'ID' => $details['participantID']
			);

            
 

            $description = "<strong></strong><BR>The Action Has Been Closed By the Administrator";
            $data1 = array(
                'singleColData' => array(
                    'summary1' => $description
                )
            );
            
            $emailObj->appendInfo($data1);
            $emailObj->sendEmail('A ' . $action . ' has been completed and approved by the Administrator ', $who, array(), array(), 'me_completed', '', 'grey');
       
       
    }
     public function updateCancelled($action_id, $date, $reason, $who, $action, $action_str) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
$this->actionHandler->updatehistory($this->action_id);
     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
                           
                                currentwho = who,
				doneDate = getdate(),
				doneDescription= 'This action has been Cancelled',
			        last_action='Cancelled',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	
		
			$emailObj = new actionEmailHelper($action_id);
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Reason Cancelled</strong>', 
								'right' => 'This action has been Cancelled for the following reason.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The '.$action.' Action has been Cancelled', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('The '.$action.' Action has been Cancelled', $who, array(), array(), 'me_completed', '', 'grey');

			
        
                                                                                                       $partObj = SetupGeneric::useModule('Participant');
                        						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
        	$emailObj->sendEmail('The '.$action.' Action has been Cancelled', $who, array(), array(), 'me_completed', '', 'grey');
}
         public function updateDelayed($action_id, $date, $reason, $who, $action, $action_str) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
$this->actionHandler->updatehistory($this->action_id);
     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
				last_action='Delayed',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	
		
			$emailObj = new actionEmailHelper($action_id);
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Reason Delayed</strong>', 
								'right' => 'This action has been Delayed for the following reason.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The '.$action.' Action has been Delayed', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('The '.$action.' Action has been Delayed', $who, array(), array(), 'me_completed', '', 'grey');

			
        
                                                                                               $partObj = SetupGeneric::useModule('Participant');
             						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
        	$emailObj->sendEmail('The '.$action.' Action has been Delayed', $who, array(), array(), 'me_completed', '', 'grey');
    }
    public function updateOnHold($action_id, $date, $reason, $who, $action, $actionstatus) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
$this->actionHandler->updatehistory($this->action_id);
     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
				last_action='On Hold',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	$emailObj = new actionEmailHelper($action_id);
	if ( $actionstatus == 1){	
                        
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Reason On Hold</strong>', 
								'right' => 'This action is On Hold for the following reason.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The Action is On Hold', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('The Action is On Hold', $who, array(), array(), 'me_completed', '', 'grey');

	       
        } 
                                                                                        $partObj = SetupGeneric::useModule('Participant');
                      						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
        	$emailObj->sendEmail('The Action is On Hold', $who, array(), array(), 'me_completed', '', 'grey');
    }
        public function updateWFR($action_id, $date, $reason, $who, $action, $actionstatus) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
$this->actionHandler->updatehistory($this->action_id);
     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
				last_action='Waiting for Resources',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	$emailObj = new actionEmailHelper($action_id);
	if($actionstatus == 1)	{
                        
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Waiting for Resources</strong>', 
								'right' => 'This action is Waiting for Resources for the following reason.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The Action is Waiting for Resources', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('The Action is Waiting for Resources', $who, array(), array(), 'me_completed', '', 'grey');
                        $partObj = SetupGeneric::useModule('Participant');
                       						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
			$emailObj->sendEmail('The Action is Waiting for Resources', $who, array(), array(), 'me_completed', '', 'grey');
        }  
        
    }
    
            public function updateChangeDate($action_id, $date, $reason, $who, $action, $actionstatus) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
$this->actionHandler->updatehistory($this->action_id);
     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
				last_action='Change Due Date',
                                updater =%d,
                                dueDate='%s',
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater,$date);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
$emailObj = new actionEmailHelper($action_id);
 	if ($actionstatus == 1){
		
                        
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Change Due Date</strong>', 
								'right' => 'This action due date has been changed for the following reason.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The Action Due Date', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('The Action Due Date', $who, array(), array(), 'me_completed', '', 'grey');
        
    }
                                                                        $partObj = SetupGeneric::useModule('Participant');
                    						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
        	$emailObj->sendEmail('The Action Due Date', $who, array(), array(), 'me_completed', '', 'grey');
            }
    public function UpdateVerified($action_id, $date, $reason,$action,$action_str) {

        $this->action_id = $action_id;
        $this->date = $date;
        $this->reason = $reason;
       $updater= getLoggedInUserId();
        $sql = sprintf("UPDATE %s.actions
				SET
				approve2comment = '" . $this->reason . "',
                                currentWho = whoAU,
                                app2date = '" . $this->date . "'  ,
                                last_action='Action Verified',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
      

        $stmt->execute();
        
        $emailObj = new actionEmailHelper($action_id);
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Verified</strong>', 
								'right' => 'This action has been verified.<BR>'
							),
                                            		'comment' => array(
								'left' => '<strong>Comment</strong>', 
								'right' =>  $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			

			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('The Action has been Verifed', $who, array(), array(), 'me_completed', '', 'grey');
                                                                    $partObj = SetupGeneric::useModule('Participant');
                       						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
        	$emailObj->sendEmail('The Action has been Verifed', $who, array(), array(), 'me_completed', '', 'grey');
        
    }
          public function UpdateActioned($p_actionId, $p_doneDate, $p_comment, $actionx, $action_str, $not_complete,$action='changed') {

        
        $manObj = SetupGeneric::useModule('Participant');


       $sql = sprintf("select * from %s.actions WHERE ID = %d", _DB_OBJ_FULL, $p_actionId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $data = $manObj->getManagerDetails($result["who"]);
        if ($data["participantID"] == 0)
            $data = $manObj->getAdminDetails();

        if ((int) $result["addapprover"] > 0) {
            $currentuser = $result["addapprover"];
        } else {
            $currentuser = $data["participantID"];
		}

        if ($not_complete == "2")
            $p_value = "This action has been rejected for the following reason<BR><BR>" . str_replace("'", "`", $p_comment);
        elseif ($not_complete == "1")
            $p_value = "This action has not been completed for the following reason<BR><BR>" . str_replace("'", "`", $p_comment);
        else
            $p_value = str_replace("'", "`", $p_comment);
	
$updater= getLoggedInUserId();

       $sql = sprintf("UPDATE %s.actions
				SET
				doneDate = '%s',
				doneDescription = '%s',
                                currentWho=%d,
                                whoAU=%d,
                                last_action='%s',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID = %d", _DB_OBJ_FULL, $p_doneDate, $p_value, $currentuser, $data["participantID"],$action,$updater, $p_actionId);


        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $emailObj = new actionEmailHelper($p_actionId);

        $whoAU = $emailObj->getAUDetails();
        $refData = $this->getRecordData($p_actionId);
        if ($not_complete == "2") {
            $description = "<strong></strong><BR>" . $p_value;
            $app_view = "View ";
        }
        elseif ($not_complete == "1") {
            $description = "<strong></strong><BR>" . $p_value;
            $app_view = "View ";
        } else {
            $description = "<strong></strong><BR>The action has been completed and needs to be approved";
            $app_view = "Approve ";
}

        $data1 = array(
            'singleColData' => array(
                'summary1' => $description,
                'click-here-url' => '<BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $action_str . '?id='.$p_actionId.'">CLICK</a> here to ' . $app_view . $type . ' Action',
                
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $refData["reference"]
                )
            )
        );
       
        if (isset($refData["problem"])) {
    $data1['twoColData']['problem']['left'] = '<strong>Problem</strong>';
    $data1['twoColData']['problem']['right'] = $refData["problem"];
        }
        
        $emailObj->appendInfo($data1);

        if ($not_complete == "1" || $not_complete == "2" )
            $emailObj->sendEmail($actionx . ' Action To Be Reviewed', $whoAU, array(), array(), 'me_completed', '', 'grey');
        else
            $emailObj->sendEmail($actionx . ' Action To Be Approved', $whoAU, array(), array(), 'me_completed', '', 'grey');

        if ((int) $result["addapprover"] > 0 && $not_complete == "0") {
            $who = $emailObj->getwhoDetails();
            $description = "<strong></strong><BR>The action has been completed and sent to the Second Approver";
            $data1 = array(
                'singleColData' => array(
                    'summary1' => $description
                )
            );
            $emailObj->appendInfo($data1);
            $emailObj->sendEmail($actionx . ' Action Has been Sent for Second Approval  ', $who, array(), array(), 'me_completed', '', 'grey');
        }
                                                                    $partObj = SetupGeneric::useModule('Participant');
          
						                        $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
                      
         $emailObj->sendEmail($actionx . ' Action Has been Sent for Second Approval  ', $who, array(), array(), 'me_completed', '', 'grey');
    
        
    }
  
     public function UpdateCompleted($action_id, $date, $reason,$action) {

        $this->action_id = $action_id;
        $this->date = $date;
        $this->who = $who;
        $this->reason = $reason;
$updater= getLoggedInUserId();
        $sql = sprintf("UPDATE %s.actions
				SET
				approvecomment = '" . $this->reason . "',
                                approveAU = 1,
                                approvedate = '" . $this->date . "'  ,
                                last_action='Completed',
                                updater=%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    

    }
     public function updateReject($action_id, $date, $reason, $action, $action_str) {

        $this->action_id = $action_id;
        $this->date_due = $date;

        $this->reason = $reason;
$updater= getLoggedInUserId();
        $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
				doneDate = NULL,
                                currentwho = who,
				doneDescription= '',
			        last_action='Rejected',
                                updater=%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
 
        $emailObj = new actionEmailHelper($action_id);

        $who = $emailObj->getwhoDetails();

        $recordData = $this->getRecordData($action_id);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/'.$action_str.'?id='.$action_id.'">CLICK</a> Here to View ' . $module . ' Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $recordData['reference']
                ),
                'reason' => array(
                    'left' => '<strong>Reason Rejected</strong>',
                    'right' => 'This action has been rejected for the following reason.<BR>' . $comment
                )
            )
        );

        $emailObj->appendInfo($data);

        $emailObj->sendEmail('A ' . $action . ' Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                                                            $partObj = SetupGeneric::useModule('Participant');
                                               $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
       
         $emailObj->sendEmail('A ' . $action . ' Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
       
    }

    public function updateReassigned($action_id, $date, $reason, $who, $action, $action_str) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
$updater= getLoggedInUserId();
       $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
                                who = " . $this->who . ",
                                currentwho = " . $this->who . ",
				doneDate = NULL,
				doneDescription= '',
			        last_action='Action Reassigned',
                                updater=%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	
		
			$emailObj = new actionEmailHelper($action_id);
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/'.$action_str.'?id='.$action_id.'">CLICK</a> Here to View '.$module.' Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Reason Reassigned</strong>', 
								'right' => 'This action has been reassigned for the following reason.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('A '.$action.' Action To Be Carried Out(Reassigned)', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();
			$emailObj->sendEmail('A '.$action.' Action To Be Approved(Reassigned)', $who, array(), $cto, 'me_completed', '', 'grey');

			
                                                     $partObj = SetupGeneric::useModule('Participant');
                                                $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
        
          $emailObj->sendEmail('A '.$action.' Action To Be Approved(Reassigned)', $who, array(), $cto, 'me_completed', '', 'grey');
        
    }
    
            public function updateInProgress($action_id, $date, $reason) {
                    $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
            $sql = "select N.* from %s.nhp N inner join  %s.actions A on N.ID=A.record where A.ID=%d";
					
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $action_id);

            $stmt = $this->dbHand->prepare($psql);

            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);




  $updater= getLoggedInUserId();
      $sql = sprintf("UPDATE %s.actions
				SET
                                status=1,
                                rejectreason = '" . $this->reason . "',
				doneDate = NULL,
				doneDescription= '',
			        last_action='In Progress',
                                updater=%d,
                                timechanged=getdate()
				WHERE ID =" . $action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        
        
        $emailObj = new actionEmailHelper($action_id);
        $who = $emailObj->getWhoDetails();
        $sentence = array('sentence' => array("You have an action to carry out the following NCR Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_nhp.php?id=' . $action_id . '">CLICK</a> Here to View a NCR Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/nhp/add_edit_nhp_details.php?id=' . $result["ID"] . '&c=1">CLICK</a> Here to Carry out a NCR Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $result["reference"]
                ),
                'actionid1' => array(
                    'left' => '<strong>Problem Description</strong>',
                    'right' => $result["problemDescription"]
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An NCR Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
 
                                             $partObj = SetupGeneric::useModule('Participant');
                                             $admin=$partObj->getAdminDetails();
               			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);

          $emailObj->sendEmail('An NCR Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
          
        
        }
        
         public function updateEditAction($action_id, $date, $reason, $action,$actionstatus) {
            $this->nhpId = $id;
            $sql = "select N.* from %s.nhp N inner join  %s.actions A on N.ID=A.record where A.ID=%d";
					
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $action_id);

            $stmt = $this->dbHand->prepare($psql);

            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);




  $updater= getLoggedInUserId();
     $sql = sprintf("UPDATE %s.actions
				SET
                                actionDescription='%s',
			        last_action='Edit Action',
                                updater=%d,
                                timechanged=getdate()
				WHERE ID =" . $action_id, _DB_OBJ_FULL,$reason,$updater);

       
       
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
         $emailObj = new actionEmailHelper($action_id); 
     if ($actionstatus == 1){
        
        $who = $emailObj->getWhoDetails();
        $sentence = array('sentence' => array("You have an action to carry out the following NCR Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_nhp.php?id=' . $action_id . '">CLICK</a> Here to View a NCR Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/nhp/add_edit_nhp_details.php?id=' . $result["ID"] . '&c=1">CLICK</a> Here to Carry out a NCR Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $result["reference"]
                ),
                'actionid1' => array(
                    'left' => '<strong>Problem Description</strong>',
                    'right' => $result["problemDescription"]
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An  Action Has been changed', $who, array(), array(), 'me_completed', '', 'grey');
 
     }
                                             $partObj = SetupGeneric::useModule('Participant');
                                                $admin=$partObj->getAdminDetails();
                			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
                      
        $emailObj->sendEmail('An  Action Has been changed', $who, array(), array(), 'me_completed', '', 'grey');
        
      
        }
        
         public function updateComment($action_id, $date, $reason, $who, $action, $actionstatus) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
$this->actionHandler->updatehistory($this->action_id);
     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
				last_action='Comment',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 				$emailObj = new actionEmailHelper($action_id);
	if ( $actionstatus == 1){	
                        
                        
			$who = $emailObj->getwhoDetails();

                        $recordData=$this->getRecordData($action_id);
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Comment</strong>', 
								'right' => 'The following comment has been added.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The Action has had a Comment added', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();

	       
	       
        } 
                                        $partObj = SetupGeneric::useModule('Participant');
                        $admin=$partObj->getAdminDetails();
                			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
                      
        $emailObj->sendEmail('The Action has had a Comments added', $who, array(), array(), 'me_completed', '', 'grey');
       
    }
       public function updateEscalated($action_id, $date, $reason, $who, $action, $actionstatus) {

        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;
        $updater= getLoggedInUserId();
       $actionData=$this->actionHandler->viewAction3($action_id); 
        $count=$this->getEscalateCount($this->action_id)+1;
        
        
        	$participantObj = SetupGeneric::useModule('Participant');
                $participantObj->setItemInfo(array('id' => $who));
		$participantData = $participantObj->displayItemById();
		$mail_address = $participantData['emailAddress'];
        	$name = $participantData['forename'] . ' ' . $participantData['surname'];
		$manager_data['displayname'] = $participantData['forename'] . ' ' . $participantData['surname'];
		$manager_data['email'] = $participantData['emailAddress'];
                $manager_data['ID'] = $who;

$this->actionHandler->updatehistory($this->action_id);


$sql = sprintf("INSERT INTO %s.action_escalation (sent_to,module,record,escalation_count,reason,actionID)
     VALUES
           (%d,'%s',%d,%d,'%s',%d)", _DB_OBJ_FULL,$who,$actionData['moduleElement'],$actionData['record'],$count,$this->reason,$this->action_id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();


     $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "<BR>Sent to ".$manager_data['displayname']."',
				last_action='Escalated',
                                updater =%d,
                                timechanged=getdate()
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL,$updater);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

 	$emailObj = new actionEmailHelper($action_id);
	if ( $actionstatus == 1){	
 	
                        $recordData=$this->getRecordData($action_id);
			$who = $emailObj->getwhoDetails();

                        
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => ''
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $recordData['reference']
							),
							'reason' => array(
								'left' => '<strong>Escalation</strong>', 
								'right' => 'The following comment has been added.<BR>'. $reason
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('The Action has been Escalated', $manager_data, array(), array(), 'me_completed', '', 'grey');
			
			

	   
        } 
                                $partObj = SetupGeneric::useModule('Participant');
   
 $admin=$partObj->getAdminDetails();
                			$who = array(
				'displayname' => ucwords($admin['forename'].' '.$admin['surname']),
				'email' => $admin['emailAddress'],
				'ID' => $admin['participantID']
			);
				//		 $who["displayname"]= $admin["forename"]." ".$admin["surname"]; 

                      
                       $emailObj->sendEmail('The Action has been Escalated', $who, array(), array(), 'me_completed', '', 'grey');
       }
       
       public function getEscalateCount($action_id) {
            $sql = sprintf("select COUNT(ID) as escalate_count from %s.action_escalation where actionID = %d" , _DB_OBJ_FULL,$action_id);
            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
            $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
            return $resultSet['escalate_count'];
       }
}