<?php


class Selections {

   /**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;


	/**
	 * Constructor for initializing Vehicle object
	 * @access public
	 */
	public function __construct() {
	 
$this->dbHand 			= DB::connect(_DB_TYPE);

	}

		public function getSelection() {
	            $sql = sprintf("SELECT *
				FROM %s.selections 
                                WHERE context='All'
				ORDER BY ordering DESC
				", _DB_OBJ_FULL);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;

	}
	
	public function getDropDown1() {
	          $data=$this->getSelection();
                  $drop_down="<UL >";
                  foreach($data as $row){
                   //$class="class='company'";
                $style = "style='float:left;width:100px;padding-left:5px;color:".$row["textcolour"].";background-color:".$row["colour1"]."; border:5px solid ".$row["colour2"].";outline:white solid 2px'";
            if ($row["value"]==1)
            $drop_down .= "<LI id='" . $row["value"] . "' " . $sel . "' style='width:150px;float:left;' ><INPUT type='radio' class=rad1 style='float:left;' id=rad". $row["value"] ." name='answer'><DIV " . $style . ">" . $row["title"] . "</DIV></LI>\n";
          else
                 $drop_down .= "<LI id='" . $row["value"] . "' " . $sel . "' style='width:150px;float:left;' ><INPUT type='radio' class='rad1 nos' value=". $row["value"] ." style='float:left;' id=rad". $row["value"] ." name='answer'><DIV " . $style . ">" . $row["title"] . "</DIV></LI>\n";
        
              
                  }
                  $drop_down.="</UL>";
       
	
return $drop_down;
	}
        
        public function getDropDown($answer=4) {
	          $data=$this->getSelection();
                  $drop_down="<UL >";
                  foreach($data as $row){
               $sel=   $row["value"] == $answer ? "checked='checked'" : "";
                   //$class="class='company'";
                $style = "style='float:left;width:100px;padding-left:5px;color:".$row["textcolour"].";background-color:".$row["colour1"]."; border:5px solid ".$row["colour2"].";outline:white solid 2px'";

                $drop_down .= "<LI id='" . $row["value"] . "' " . $sel . "' style='width:150px;float:left;' ><INPUT type='radio' class='rad1 nos' value=". $row["value"] ." style='float:left;' id=rad". $row["value"] ." name='answer' " . $sel . "><DIV " . $style . ">" . $row["title"] . "</DIV></LI>\n";
        
              
                  }
                   $sel=   $answer == 0 ? "checked='checked'" : "";
                   $style = "style='float:left;width:100px;padding-left:5px;color:black;background-color:transparent;border:5px solid transparent; outline:white solid 2px'";
 $drop_down .= "<LI id='0'  style='width:150px;float:left;' ><INPUT type='radio' class='rad1 nos' value=0 style='float:left;' id=rad0 name='answer' " . $sel . "><DIV " . $style . ">N/A</DIV></LI>\n";
        
                  $drop_down.="</UL>";
       
	
return $drop_down;
	}
        
        	public function getGroup1Data($value=4) {

		$sql = sprintf("SELECT *
				FROM %s.selections 
                                WHERE ID=%d
				ORDER BY ordering DESC
				", _DB_OBJ_FULL,$value);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;

	}
}
?>
