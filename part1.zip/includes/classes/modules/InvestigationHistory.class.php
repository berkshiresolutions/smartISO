<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class InvestigationHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {
 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'investigation';
		$this->tables[] 		= 'investigation_inadequacies';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _investigation() {

		$tablename 				= 'investigation';
		$tablename_historical 	= $tablename.'_historical';

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (
						ID
						,incID
						,reference
						,uniqueReference
						,incidentAnalysis
						,incidentAnalysisDescription
						,immediateCauses
						,immediateCausesDescription
						,basicCauses
						,basicCausesDescription
						,inadequacyOrgDescription
						,inadequacyRiskDescription
						,inadequacyTrgDescription
						,inadequacyInspDescription
						,inadequacyNoncDescription
						,inadequacyEmerDescription
						,inadequacyHlthDescription
						,inadequacyDesgDescription
						,actionsID
						,processID
						,isRiskValid
						,archive
						,status
						,whoID
						,subReference
                                                ,process_change_reason
					   )
						SELECT
						ID
						,incID
						,reference
						,uniqueReference
						,incidentAnalysis
						,incidentAnalysisDescription
						,immediateCauses
						,immediateCausesDescription
						,basicCauses
						,basicCausesDescription
						,inadequacyOrgDescription
						,inadequacyRiskDescription
						,inadequacyTrgDescription
						,inadequacyInspDescription
						,inadequacyNoncDescription
						,inadequacyEmerDescription
						,inadequacyHlthDescription
						,inadequacyDesgDescription
						,actionsID
						,processID
						,isRiskValid
						,archive
						,status
						,whoID
						,subReference
                                                ,process_change_reason
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$sql = sprintf("SELECT subReference FROM %s.investigation
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$this->subReference = $pStatement->fetchColumn();

		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
	}

	private function _investigation_inadequacies() {

		$tablename 				= 'investigation_inadequacies';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from investigation_inadequacies
		 */
		$sql = sprintf("SELECT * FROM %s.".$tablename."
						WHERE invID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$inadequacies_data = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( !empty($participant_data) ) {

			$sql = sprintf("INSERT INTO %s.".$tablename_historical."
						   (
							ID,
							invID,
							section,
							inadequacyID,
							inadequacySelectedValues,
							inadequacyReason,
							subReference
						   ) VALUES (%d,%d,'%s','%s','%s','%s','%d','%s','%s',%d)",
							_DB_OBJ_FULL,
							$inadequacies_data['ID'],
							$inadequacies_data['invID'],
							$inadequacies_data['section'],
							$inadequacies_data['inadequacyID'],
							$inadequacies_data['inadequacySelectedValues'],
							$inadequacies_data['inadequacyReason'],
							$this->subReference);

			$pStatement2 = $this->dbHand->prepare($sql);
			$pStatement2->execute();
		}
	}
}
?>