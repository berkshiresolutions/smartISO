<?php
 /**
  $Id: Training.int.php,v 3.30 Saturday, November 27, 2010 6:35:03 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage training object
  *
  * This interface will declare the various methods performed
  * by the training object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface TrainingInterface
{
	/*
	 * to set trainee information for performing various operations with the training object
	 */
	public function setTraineeInfo($p_traineeId,$p_traineeInfo);

	/*
	 * to set personal record information for performing various operations with the training object
	 */
	public function setPersonalRecordCardInfo($p_traineeId,$p_recordInfo);

	/*
	 * This method is used to assign a course to the trainee
	 */
	public function addTraineeToCourse();

	/*
	 * This method is used to view the trainee information.
	 */
	public function viewCourseAssignedToTrainee();

	/*
	 * This method is used to edit the trainee
	 */
	public function editCourseAssignedTrainee();

	/*
	 * This method is used to delete the trainee
	 */
	public function deleteCourseAssignedTrainee();

	/*
	 * This method is used to archive the trainee
	 */
	public function archiveCourseAssignTrainee();

	/*
	 * This method is used to remove the trainee
	 */
	public function purgeCourseAssignTrainee();


	/*
	 * This method is used to get the list of courses which are assigned to atleast one trainee
	 */
	public function getCourseAssigned();

	/*
	 * This method is used to get the list of courses which are planned
	 */
	public function getCoursePlanned();

	/*
	 * This method is used to get the list of courses which are confirmed
	 */
	public function getCourseConfirmed();

	/*
	 * This method is used to get the list of trainees who has completed training grouped by course
	 */
	public function getCourseCompleted();

	/*
	 * This method is used to get trainees by course
	 */
	public function getTraineesByCourse();

	/*
	 * This method is used to get trainee metadata
	 */
	public function getTraineeMetaData();

	/*
	 * This method is used to save trainee metadata
	 */
	public function saveTraineeMetaData();

	/*
	 * This method is used to get trainee personal record card
	 */
	public function getPersonalRecordCards();

	/*
	 * This method is used to view trainee personal record card
	 */
	public function viewPersonalRecordCard();

	/*
	 * This method is used to remove trainee personal record card
	 */
	public function deletePersonalRecordCard();

	/*
	 * This method is used to get scheduled courses list
	 */
	public function getScheduledCourses();

	/*
	 * This method is used to add training certificate
	 */
	public function addTraineeCertificate();

}