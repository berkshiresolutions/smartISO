<?php

/**
  $Id: RiskAssessment.class.php,v 4.89 Friday, February 04, 2011 3:27:36 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Friday, October 29, 2010 4:00:58 PM>
 */
require_once "RiskAssessment.int.php";

require_once "Action.class.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class RiskAssessment implements RiskAssessmentInterface {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold Risk Id
     * @access private
     */
    private $RiskId;

    /**
     * Property to hold Risk Info
     * @access private
     */
    private $RiskInfo;

    /**
     * Constructor for initializing Risk object
     * @access public
     */
    public function __construct() {

       
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * to set risk assessment information for performing various operations with an risk assessment object
     */

    public function setRiskInfo($p_RiskAssessmentId, $p_RiskAssessmentInfo) {

        $this->RiskId = $p_RiskAssessmentId;
        $this->RiskInfo = $p_RiskAssessmentInfo;
    }

    /*
     * This method is used to get list of process for risk assessment.
     */

    public function getRiskAssessmentProcesses() {

        $archive_flag = (int) Session::getSessionField('ARCHIVE_RECORDS');

        if ($archive_flag) {
            $sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID WHERE  S.riskarchive=1
				ORDER BY swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL);
        } else {
            $sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID WHERE (isnull(S.archive,'0') = '0' or S.archive = '2') and S.riskarchive='0'
				ORDER BY swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL);
        }




        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getRiskAssessmentProcesses33($buId) {
        $this->buid = $buId;
        $archive_flag = (int) Session::getSessionField('ARCHIVE_RECORDS');

        if ($archive_flag) {
            $sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID WHERE  S.archive = '1' AND S.buID = " . $this->buid . "
				ORDER BY swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL);
        } else {
            $sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID WHERE S.buID = " . $this->buid . " AND (S.archive = '0' OR S.archive IS NULL ) 
				ORDER BY swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL);
        }




        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get list of steps by process
     */

    public function getStepsByProcess() {

        $sql = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d and not type in ('D','B')
				ORDER BY altPathIndex, stepLevel,ID ASC", _DB_OBJ_FULL, $this->RiskInfo['process_id']);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        $this->steps_resultset = $result;

        return $result;
    }

    public function getFirstHazardWhoByProcess($p_processID) {

        $sql = sprintf("SELECT TOP 1 * FROM %s.risk WHERE processID = %d ORDER BY ID ASC", _DB_OBJ_FULL, $p_processID);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getStatus($p_processID) {
        $this->id = $p_processID;
        $sql = sprintf("SELECT  * FROM %s.swimlane WHERE swimID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getStatus3399($p_processID) {
        $this->id = $p_processID;
        $sql = sprintf("SELECT  * FROM %s.risk WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function addMainRefd($p_processID) {
        $this->id = $p_processID;
        $sql = sprintf("SELECT  stepLevel FROM %s.swimlane_data WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addMainRef($p_processID) {
        $this->id = $p_processID;
        $sql = sprintf("SELECT  * FROM %s.swimlane WHERE swimID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result['mainSubRef'] == 'NULL' || $result['mainSubRef'] == '0') {
            $r = 1;
            $sql = sprintf("UPDATE  %s.swimlane SET mainSubRef =" . $r . " WHERE swimID =" . $this->id, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
        } else {
            $r = $result['mainSubRef'] + 1;
            $sql = sprintf("UPDATE  %s.swimlane SET mainSubRef =" . $r . " WHERE swimID =" . $this->id, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
        }

        // return $result;
    }

    public function addMainRef1($p_processID) {
        $this->id = $p_processID;
        $sql = sprintf("UPDATE  %s.swimlane SET done = 1 WHERE swimID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function addMainRef1CC($p_processID) {
        $this->id = $p_processID;
        $sql = sprintf("SELECT  done FROM %s.swimlane WHERE swimID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addMainRef2($p_processID, $step) {
        $this->id = $p_processID;
        $this->step = $step;
        $sql33 = sprintf("SELECT  * FROM %s.swimlane_data WHERE swimID =" . $this->id . " AND stepLevel = " . $this->step, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql33);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result['subRef'] == 'NULL' || $result['subRef'] == '0' || $result['subRef'] == '') {
            $r = 1;
            $sql = sprintf("UPDATE  %s.swimlane_data SET subRef =" . $r . " ,done =1  WHERE swimID =" . $this->id . " AND stepLevel = " . $this->step, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
        } else {
            $s = 1;
            $r = $result['subRef'] + $s;
            $sql = sprintf("UPDATE  %s.swimlane_data SET subRef =" . $r . " WHERE swimID =" . $this->id . " AND stepLevel = " . $this->step, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
        }
    }

    public function getStepsByStatus() {

        $old_value = $this->RiskInfo['archive'];

        $this->RiskInfo['archive'] = 1;
        $archived_hazards = count($this->getHazardsByProcessStep());

        $this->RiskInfo['archive'] = 0;
        $active_hazards = count($this->getHazardsByProcessStep());

        $this->RiskInfo['archive'] = $old_value;

        return array(
            'archived_hazards' => $archived_hazards,
            'active_hazards' => $active_hazards,
            'total_hazards' => $active_hazards + $archived_hazards,
        );
    }

    /*
     * This method is used to get hazards by process step
     */

    public function getHazardsByProcessStep() {

        if ($this->RiskInfo['step_id'] == 0 || $this->RiskInfo['step_id'] == null) {

            $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d and isnull(archive,0)=%d ORDER BY ID DESC"
                    , _DB_OBJ_FULL
                    , $this->RiskInfo['process_id'], $this->RiskInfo['archive']);
        } else {


            $sql = sprintf("SELECT A.*,A.whoID,dateTimestamp FROM %s.risk A
				LEFT OUTER JOIN (
					SELECT B.*,C.swimID
					FROM %s.module_tracker B
					INNER JOIN %s.swimlane C
					ON B.reference = C.reference
					WHERE module = 'RISK'
					AND action = 'add'
				) D
				ON swimID = processID
				WHERE processID = %d AND processStepID = %d and isnull(A.archive,0)=%d ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->RiskInfo['process_id'], $this->RiskInfo['step_id'], $this->RiskInfo['archive']);
        }

        $pStatement = $this->dbHand->prepare($sql);



        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_improvement_actions1($p_improvement_id) {
        $this->id = $p_improvement_id;



        $sql = "SELECT * FROM %s.actions WHERE ID = %d ";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $this->id);

        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        $improvements = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $improvements;
    }

        public function getStepActions($id) {
        
        $sql = " select * from %s.actions where record=%d and moduleElement='risk' ";
       $sql_p = sprintf($sql, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        $actions = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $actions;
    }
   
    /*
     * This method is used to get hazards by process step
     */

    public function getHazardsByProcessStepLogDate() {

        $date_filter = '';

        if ($this->RiskInfo['start_date'] != '' && $this->RiskInfo['end_date'] != '') {
            $date_filter = " AND (dateTimestamp IS NULL OR dateTimestamp BETWEEN '" . $this->RiskInfo['start_date'] . "' AND '" . $this->RiskInfo['end_date'] . "')";
        }


        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.risk A
				LEFT OUTER JOIN (
					SELECT B.*,C.swimID
					FROM %s.recordTracking B
					INNER JOIN %s.[swimlane] C
					ON B.recordRef = C.reference
					WHERE moduleName = 'RA'
					AND action = 'add'
				) D
				ON swimID = processID
				WHERE processID = %d AND processStepID = %d
				AND A.archive = '%s'
				$date_filter
				ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->RiskInfo['process_id'], $this->RiskInfo['step_id'], $this->RiskInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to get hazards by process step
     */

    public function archiveRisk() {

        $sql = sprintf("UPDATE %s.risk SET archive = '%s' WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->RiskInfo['archive']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to get step Details
     */
    public function getProcessStepDetails() {

        $sql = sprintf("SELECT * FROM %s.swimlane_data
				WHERE swimID = %d
				AND ID = %d"
                , _DB_OBJ_FULL
                , $this->RiskInfo['process_id']
                , $this->RiskInfo['step_id']);

        $stmt = $this->dbHand->prepare($sql);


        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /*
     * This method is used to add new hazard for a risk process assessment
     * process_id,process_step_id,hazard_classification,hazards,secondary_hazard,hazard_symbol,hazard_summary
     */

    public function addHazardAssessment() {

       $sql = sprintf("INSERT INTO %s.risk (processID,processStepID,hazardClassificationID,hazardsID,secondaryHazardID,hazardSymbols,
						hazardSummary,status,dseAssessment,
							archive,whoID,buID,processReference,hazardfiles,origin,reportedby,reported_date)
								VALUES (%d, %d, %d,'%s','%s','%s','%s','0','%s','0',%d,%d,'%s','%s',%d,%d,'%s') "
                , _DB_OBJ_FULL
                , $this->RiskInfo['process_id']
                , $this->RiskInfo['process_step_id']
                , $this->RiskInfo['hazard_classification']
                , $this->RiskInfo['hazards']
                , $this->RiskInfo['secondary_hazard']
                , $this->RiskInfo['hazard_symbol']
                , $this->RiskInfo['hazard_summary']
                , $this->RiskInfo['dse_assessments']
                , $this->RiskInfo['owner']
                , $this->RiskInfo['process_bu_id']
                , $this->RiskInfo['process_reference']
                , $this->RiskInfo['file']
		, getLoggedInUserId()
                ,$this->RiskInfo['reporter']
                ,$this->RiskInfo['reportDate']
               );

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();


        $this->RiskId = customLastInsertId($this->dbHand, 'risk', 'ID');

       // $this->moveFiles('hazard');
    }

    /*
     * This method is used to edit hazard for a risk process assessment
     */

    public function editHazardAssessment() {

       $sql = sprintf("UPDATE %s.risk SET hazardClassificationID = %d,
									hazardsID = '%s',
									secondaryHazardID = '%s',
									hazardSymbols = '%s',
									hazardSummary = '%s',
									dseAssessment = '%s',
									hazardfiles = '%s',
									whoID = %d
                                                                        
								WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->RiskInfo['hazard_classification']
                , $this->RiskInfo['hazards']
                , $this->RiskInfo['secondary_hazard']
                , $this->RiskInfo['hazard_symbol']
                , $this->RiskInfo['hazard_summary']
                , $this->RiskInfo['dse_assessments']
				, $this->RiskInfo['file']
                , $this->RiskInfo['who_id']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        if ($this->RiskInfo['cia'] !=1){
               $sql = sprintf("UPDATE %s.risk SET ciaConfidentiality = null  WHERE ID = %d", _DB_OBJ_FULL , $this->RiskId);

        
        
                $sql = sprintf("UPDATE %s.swimlane
				SET
					buID = %d,
                                        location='%s'
				WHERE
					swimID = %d"
                , _DB_OBJ_FULL
                , $this->businessUnitID
                , $this->location
                , $this->swimlaneId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    }
        public function editRiskAssessment() {

    $sql = sprintf("UPDATE %s.risk SET reportedby = %d,
									reported_date = '%s',
									buID = '%d',
                                                                       whoid = '%d' 
								WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->RiskInfo['reporter']
                , $this->RiskInfo['reportDate']
                , $this->RiskInfo['process_bu_id']
          , $this->RiskInfo['owner']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
	$sql = sprintf("UPDATE %s.swimlane SET description = '%s',buID = %d,
                                        location='%s'  WHERE swimID = %d", _DB_OBJ_FULL ,$this->RiskInfo['description'],$this->RiskInfo['process_bu_id'],$this->RiskInfo['location'], $this->RiskInfo['process_id']);

        $pStatement = $this->dbHand->prepare($sql);

      $pStatement->execute();
        
      $sql = sprintf("UPDATE %s.swimlane_data SET descQues ='%s'  WHERE ID = %d", _DB_OBJ_FULL , $this->RiskInfo['step'],$this->RiskInfo[process_step_id]);

        $pStatement = $this->dbHand->prepare($sql);

       $pStatement->execute();
		


    }
    /**
     * This method is used to manage Control Tab data
     */
    public function updateControl() {

      $sql = sprintf("UPDATE %s.risk SET controlAlongPath = '%s',
									controlAtWorker = '%s',
									controlAtSource = '%s',
									controlSymbols = '%s',
									controlSummary = '%s',
									controlfiles = '%s'
								WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['along_path']
                , $this->RiskInfo['at_worker']
                , $this->RiskInfo['at_source']
                , $this->RiskInfo['control_symbol']
                , $this->RiskInfo['control_summary']
				, $this->RiskInfo['file']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
       // $this->moveFiles('control');
	   
	  
    }

    /**
     * This method is used to manage Risk Rating 1
     *
     * Array Variables : likelihood,impact,risk_rating,risk_rating_color
     */
    public function manageRiskRating1() {

        $sql = sprintf("UPDATE %s.risk SET likelihood1 = %d ,
									impact1 = %d,
									riskRating1 = '%s',
									riskRatingColor1 = '%s'
									WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['likelihood']
                , $this->RiskInfo['impact']
                , $this->RiskInfo['risk_rating']
                , $this->RiskInfo['risk_rating_color']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage improvement
     *
     * Array Variables : source,path,worker,no_improvement,improvement_reason,improvement_ids = array(),
     * improvement = array()
     */
    public function manageImprovement() {

         $sql = sprintf("UPDATE %s.risk SET improvementAtSource = '%s' ,
									improvementAlongPath = '%s',
									improvementAtWorker = '%s',
									noImprovement = '%s',
									improvementReason = '%s',
                                                                        noImprovementFiles = '%s',
									eliminateHazard = '%s',
									overwriteControl = %d,
                                                                        origin  = %d,
									improvement_d = '%s',
                                                                        RCA = '%s'
									WHERE ID = %d "
        , _DB_OBJ_FULL
        , $this->RiskInfo['source']
        , $this->RiskInfo['path']
        , $this->RiskInfo['worker']
        , $this->RiskInfo['no_improvement']
        , $this->RiskInfo['improvement_reason']
        , trim($this->RiskInfo['file'],",")
        , $this->RiskInfo['eliminate_hazard']
        , $this->RiskInfo['overwrite_control']
        , getLoggedInUserId()
        , $this->RiskInfo['improvement']
        , $this->RiskInfo['RCA']
        , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        if (count($this->RiskInfo['improvement_ids'])) {
            $improvement_ids = "";
            foreach ($this->RiskInfo['improvement_ids'] as $key => $value) {


                $imp_desc = smartisoAddslashes($this->RiskInfo['improvement'][$key]);


                if (!$value) {
                    // add action
                    $this->actionData = array('module_name' => 'risk', 'description' => '', 'who' => 0, 'due_date' => '01/01/1900');
                    $this->actionHandling->setActionDetails(0, $this->actionData);
                    $action_id = $this->actionHandling->addAction();
                    $improvements .= $action_id . ',';
                } else {

                    // update action
                    //echo $value;
                    $this->actionHandling->setActionDetails($value, "");
                    $actionHandler = new Action();
                    $action_dat = $actionHandler->viewActionSelectDetail($value);

                    $res = $actionHandler->viewRiskSelectDetail($value);
                    $res['reference'] = str_replace("PF", "PR", $res['reference']);

                    $organoObj = SetupGeneric::useModule('Organigram');
                    $organoObj->setItemInfo(array('id' => $res['buID']));
                    $business_unit_arr = $organoObj->displayItemByIdForMSR();

                    $improvement = $this->actionHandling->viewAction();
                    $improvement['dueDate'];

                    $imp_date = $improvement['dueDate'] == '1900-01-01' ? '01/01/1900' : format_date($improvement['dueDate']);

                    $improvements .= $value . ',';
                }
            }

            $improvements = rtrim($improvements, ',');
        }

        if ($this->RiskInfo['no_improvement']) {
            $risk_data = $this->viewHazardAssessment();


            if ($risk_data['improvements'] != "" || $risk_data['improvements'] != 0) {

                $improvements_arr = explode(',', $risk_data['improvements']);
                if (count($improvements_arr)) {
                    foreach ($improvements_arr as $value) {
                        $this->actionHandling->setActionDetails($value, "");
                        $improvement = $this->actionHandling->deleteAction();
                    }
                }
            }

            $improvements = 0;
        } else {

            $improvements_reason = "";

            $sql = sprintf("UPDATE %s.risk SET improvementReason = '%s'
									WHERE ID = %d "
                    , _DB_OBJ_FULL
                    , $improvements_reason
                    , $this->RiskId);

            $pStatement = $this->dbHand->prepare($sql);


            $pStatement->execute();
        }
        if ($improvements) {
            //$this->RiskInfo['improvement_ids'] = explode(',', $this->RiskInfo['improvement_ids']);

            $sql = sprintf("UPDATE %s.risk SET improvements = '%s',improvement_d = '%s'
						WHERE ID = %d "
                    , _DB_OBJ_FULL
                    , $improvements
                    , $this->RiskInfo['improvement']
                    , $this->RiskId);

            $pStatement = $this->dbHand->prepare($sql);


            $pStatement->execute();

            //$this->moveFiles('improvement');
        } else {
            $this->RiskInfo['improvement_ids'] = implode(',', $this->RiskInfo['improvement_ids']);
            $sql = sprintf("UPDATE %s.risk SET improvements = '%s',improvement_d = '%s'
						WHERE ID = %d "
                    , _DB_OBJ_FULL
                    , $this->RiskInfo['improvement_ids']
                    , $this->RiskInfo['improvement']
                    , $this->RiskId);

            $pStatement = $this->dbHand->prepare($sql);


            $pStatement->execute();

            //$this->moveFiles('improvement');
        }
    }

    /**
     * This method is used to manage risk rating 2
     *
     * Array Variables : likelihood,impact,risk_rating,risk_rating_color
     */
    public function manageRiskRating2() {

        $sql = sprintf("UPDATE %s.risk SET likelihood2 = '%s' ,
						impact2 = '%s',
						riskRating2 = '%s',
						riskRatingColor2 = '%s'
						WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['likelihood']
                , $this->RiskInfo['impact']
                , $this->RiskInfo['risk_rating']
                , $this->RiskInfo['risk_rating_color']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
    }

    /**
     * This method is used to manage priority
     *
     * Array Variables : time_trouble,net_impact,priority
     */
    public function managePriority() {

        $sql = sprintf("UPDATE %s.risk SET timeTrouble = '%s' ,
					netImpact = '%s',
					priority = '%s'
					WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['time_trouble']
                , $this->RiskInfo['net_impact']
                , $this->RiskInfo['priority']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
    }

    public function updateOverruleReason() {

        $sql = sprintf("UPDATE %s.risk SET overrulereason = '%s'
								WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['overrulereason']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage action
     *
     * Array Variables : improvement,who,when,improvement_id
     */
    public function manageAction() {

        $this->actionData = array('description' => $this->RiskInfo['action_d'],
            'who' => $this->RiskInfo['who'], 
            'whoAU' => $this->RiskInfo['manager'], 
            'who2AU' => $this->RiskInfo['who2AU'],
            'module_name' => "risk",
            'record' => $this->RiskInfo['record_id'],
            'status' => 0,
            'buname' => 0,
            'element' => "risk",
            'currentwho' => $this->RiskInfo['who'], 
            'due_date' => $this->RiskInfo['when'],
            'overrulereason' => $this->RiskInfo['overrulereason'], 
            'record_id' => $this->RiskInfo['improvement_id']);


        $this->actionHandling->setActionDetails((int)$this->RiskInfo['improvement_id'], $this->actionData);

        $save_finish = (int) $_POST['save_finish'];
         $update_save = (int) $_POST['update_save'];


        $actionHandler = new Action();
        $action_dat = $actionHandler->viewActionSelectDetail($this->RiskInfo['improvement_id']);

        $whenCheck = date('Y-m-d', strtotime($this->RiskInfo['when']));
        $when = date('m/d/Y', strtotime($this->RiskInfo['when']));

        $res = $actionHandler->viewRiskSelectDetail($this->RiskInfo['record_id']);

        $organoObj = SetupGeneric::useModule('Organigram');
        $organoObj->setItemInfo(array('id' => $res['buID']));
        $business_unit_arr = $organoObj->displayItemByIdForMSR();
        if ($this->RiskInfo['noimprovement'] == 1 && $this->RiskInfo['improvement_id'] == 0){
        $this->RiskInfo['improvement_id']= $this->actionHandling->addAction2015($this->actionData);
        $sql = sprintf("UPDATE %s.risk SET improvements = '%s' WHERE ID = %d ", _DB_OBJ_FULL, $this->RiskInfo['improvement_id'], $this->RiskInfo['record_id']);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        }
        else
        $this->updateAction($this->actionData);

        if ($save_finish == 1) {
            $this->actionHandling->updateStatus($this->RiskInfo['improvement_id']);
            //}	
            $emailObj = new actionEmailHelper($this->RiskInfo['improvement_id']);
            $who = $emailObj->getwhoDetails();

            $sentence = array('sentence' => array("You have an action to carry out the following risk Action"));
            $emailObj->appendInfo($sentence);

            $data = array('singleColData' => array('click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?id='.$this->RiskInfo['improvement_id'].'">CLICK</a> Here to View Risk Action<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/process_risk_assessment/r1ReportPdf.php?cid=' . $res['processID'] . '&back=1">CLICK</a> Here to View Risk PDF'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $res['reference'])));


            $emailObj->appendInfo($data);
            $emailObj->sendEmail('A Risk Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

            $whoAU = $emailObj->getAUDetails();

            //$slawdata = $this->getActionsbyID($action_id);

            $sentence = array('sentence' => array("You have an action to approve the following risk Action"));
            $emailObj->appendInfo($sentence);

            $data = array('singleColData' => array('click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk_assessment.php?id='.$this->RiskInfo['improvement_id'].'">CLICK</a> Here to View Risk Action<BR><BR>Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/process_risk_assessment/r1ReportPdf.php?cid=' . $res['processID'] . '&back=1">CLICK</a> Here to View Risk PDF'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $res['reference'])));


            $emailObj->appendInfo($data);
            $emailObj->sendEmail('A Risk Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

            if ($this->RiskInfo['who2AU'] > 0) {
                $who2AU = $emailObj->getSecondApproverDetails();
                $emailObj->sendEmail('A Risk Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
            }
        }

    }

    /**
     * This method is used to manage action
     *
     * Array Variables : status
     */
    public function updateStatus() {
        $sql = sprintf("UPDATE %s.risk SET status = '1' WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function checkAction($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.actions WHERE ID = %d", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result[approveAU] == '1') {

            $this->actionData = array('module_name' => 'risk', 'description' => '', 'who' => 0, 'due_date' => '01/01/1900');
            $this->actionHandling->setActionDetails(0, $this->actionData);
            $action_id = $this->actionHandling->addAction();

            $improvements .= $action_id;
            return $improvements;
        }
    }

    public function subUpdate33($id) {
        $this->id = $id;
        $sql = sprintf("UPDATE %s.risk SET improvements = '" . $this->id . "' WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function subUpdate3333() {


        $sql = sprintf("UPDATE %s.risk SET newAction = 2 WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function subUpdate77($sub) {
        $this->sub = $sub;
        if ($this->sub) {
            $sql = sprintf("UPDATE %s.risk SET newAction = 2 WHERE ID = %d "
                    , _DB_OBJ_FULL
                    , $this->RiskId);

            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
        } else {
            $sql = sprintf("UPDATE %s.risk SET newAction = 1 WHERE ID = %d "
                    , _DB_OBJ_FULL
                    , $this->RiskId);

            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
        }
    }

    /*
     * This method is used to view hazard assessment
     */

    public function viewHazardAssessment() {

        $sql = sprintf("SELECT * FROM %s.risk WHERE ID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        return $pStatement->fetch(PDO::FETCH_ASSOC);
    }

    public function checkFinish() {

        $sql = sprintf("SELECT * FROM %s.risk WHERE ID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->RiskId); */

        $pStatement->execute();

        return $pStatement->fetch(PDO::FETCH_ASSOC);
    }

    public function viewHazardAssessmentD($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.swimlane WHERE swimID =" . $this->id, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        return $pStatement->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * This method is used to view the improvement Risk information.
     */
    public function viewImprovementRisk() {

        $sql = sprintf("SELECT improvementAtSource,improvementAlongPath,improvementAtWorker,improvements,noImprovement,noImprovementFiles,improvementReason
					   FROM %s.risk WHERE ID = %d ", _DB_OBJ_FULL, $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($resultSet)) {

            if ($resultSet[0]['improvements'] != "") {

                $improvement_arr = explode(',', $resultSet[0]['improvements']);

                if (count($improvement_arr)) {
                    foreach ($improvement_arr as $value) {
                        $this->actionHandling->setActionDetails($value, "");
                        $improvement = $this->actionHandling->viewAction();
                        $riskImprovements[$value] = $improvement;
                    }
                }

                $resultSet[0]['improvements'] = $riskImprovements;
            }
        }
        return $resultSet[0];
    }

    public function secondaryHazardCount($p_archive_flag = 0) {

        $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d AND archive = '%s'"
                , _DB_OBJ_FULL
                , $this->RiskInfo['process_id']
                , $this->RiskInfo['step_id']
                , $p_archive_flag);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $num_rows = (int) $pStatement->rowCount();
        $sec_hazard_count = 0;

        if ($num_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                $sec_hazards = 0;
                if ($row['secondaryHazardID'] != '') {
                    $sec_hazards = explode(',', $row['secondaryHazardID']);
                    $sec_hazard_count += count($sec_hazards);
                }
            }
        }

        return $sec_hazard_count;
    }

    public function completedActions() {

        $sql = sprintf("SELECT * FROM %s.risk
					   WHERE processID = %d AND processStepID = %d AND status = '%s' "
                , _DB_OBJ_FULL
                , $this->RiskInfo['process_id']
                , $this->RiskInfo['step_id']
                , $this->RiskInfo['status']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        return count($pStatement->fetchAll(PDO::FETCH_ASSOC));
    }

    public function openOverdueActions() {

        $recordOpen = 0;
        $recordOverdue = 0;

        $sql = sprintf("SELECT improvements
					FROM %s.risk
					WHERE processID = %d AND processStepID = %d"
                , _DB_OBJ_FULL
                , $this->RiskInfo['process_id']
                , $this->RiskInfo['step_id']);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetchALL(PDO::FETCH_ASSOC);

        foreach ($record as $record_ele) {

            if (!is_null($record_ele['improvements'])) {

                $sql = sprintf("
					SELECT count(*) FROM %s.actions
					WHERE moduleName = 'risk'
					
					AND approveAU = '0'
					AND ID IN (%s)"
                        , _DB_OBJ_FULL
                        , $record_ele['improvements']);

                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();

                $recordOpen += (int) $pStatement->fetchColumn();

                $sql = sprintf("
					SELECT count(*) FROM %s.actions
					WHERE moduleName = 'risk'
					AND dueDate < " . customCurrentDate() . "
					AND approve = '0'
					AND ID IN (%s)"
                        , _DB_OBJ_FULL
                        , $record_ele['improvements']);

                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();

                $recordOverdue = $pStatement->fetchColumn();
            }
        }

        return array('open' => $recordOpen, 'overdue' => $recordOverdue);
    }

    public function getNotStartedRisks() {

        $sql = sprintf("SELECT * FROM %s.risk  WHERE processID = %d AND processStepID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['process_id']
                , $this->RiskInfo['step_id']);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result) {

            $sql = sprintf("SELECT count(*) as riskcount FROM %s.actions where who=0 and  
					ID IN (%s)"
                    , _DB_OBJ_FULL
                    , $result['improvements']);

            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();

            $resultData = $pStatement->fetch(PDO::FETCH_ASSOC);

            if ($resultData['riskcount'] == 0)
                return true;
            else
                return false;
        } else
            return false;
    }

    public function lastRecordid() {
        return $this->RiskId;
    }

    public function getNextId() {

       if ( _DB_TYPE != 'mysql' ) {
            $new_id = customLastInsertId($this->dbHand, 'risk', 'ID');

            return ($new_id + 1);
        } else {
            $sql = sprintf("SHOW TABLE STATUS LIKE %s.risk", _DB_OBJ_FULL);
            $pStatement = $this->dbHand->prepare($sql);
            $pStatement->execute();
            $result_set = $pStatement->fetch(PDO::FETCH_ASSOC);
            return $result_set['Auto_increment'];
        }
    }

    public function addRiskFiles() {

        $sql = sprintf("INSERT INTO %s.risk_files (riskID,section,uploadedFileID) VALUES (%d,'%s',%d)"
                , _DB_OBJ_FULL
                , $this->RiskId
                , $this->RiskInfo['identifier']
                , $this->RiskInfo['file_id']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to get risk files
     * equip id, identifier
     */
    public function getRiskFile() {

       $sql = sprintf("SELECT * FROM %s.risk_files WHERE riskID = %d AND section = '%s'"
                , _DB_OBJ_FULL
                , $this->RiskId
                , $this->RiskInfo['identifier']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $resultSet;
    }

    public function deleteRiskFiles() {

        $sql = sprintf("DELETE FROM %s.risk_files WHERE riskID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to get risk files
     * file id
     */
    public function getRiskFileDetails() {

        $sql = sprintf("SELECT * FROM %s.risk_files WHERE ID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet[0];
    }

    public function deleteRiskFile() {

        $sql = sprintf("DELETE FROM %s.risk_files WHERE ID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getControlHazardSummary($p_risk_id, $p_step_id) {

        $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d ", _DB_OBJ_FULL, $p_risk_id, $p_step_id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet[0];
    }

    /*
     * This method is used to get list of process for process dropdown.
     */

    public function getProcessesForDropdown1($buid) {
        $this->buid = $buid;
        $sql = sprintf("SELECT S.* FROM %s.swimlane S
				INNER JOIN %s.business_units B
					ON S.buID = B.buID
				WHERE (S.archive = 0 OR S.archive is NULL) ", _DB_OBJ_FULL, _DB_OBJ_FULL);
//WHERE (S.archive = 0 OR S.archive is NULL) AND  S.buID = " . $this->buid, _DB_OBJ_FULL, _DB_OBJ_FULL);
//altered for candw better version in process flow master  call from ajax_get_processlist.php        
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($result_all)) {
            $i = 0;
            foreach ($result_all as $result) {

                $row[$i]['id'] = $result['swimID'];
                $row[$i]['reference'] = $result['reference'];
                $row[$i]['description'] = $result['description'];

               if ( _DB_TYPE != 'mysql' ) {
                    $sql1 = sprintf("SELECT TOP 1 riskRating1,riskRatingColor1 FROM %s.risk WHERE riskRating1 != '' AND riskRatingColor1 != '' AND processID = %d", _DB_OBJ_FULL, $result['swimID']);
                } else {
                    $sql1 = sprintf("SELECT riskRating1,riskRatingColor1 FROM %s.risk WHERE riskRating1 != '' AND riskRatingColor1 != '' AND processID = %d LIMIT 0,1", _DB_OBJ_FULL, $result['swimID']);
                }


                $pStatement1 = $this->dbHand->prepare($sql1);

                $pStatement1->execute();

                $risk_result = $pStatement1->fetchAll(PDO::FETCH_ASSOC);

                if (count($risk_result)) {
                    $row[$i]['risk_value'] = $risk_result[0]['riskRating1'] == "" ? '#' : $risk_result[0]['riskRating1'];
                    $row[$i]['risk_color'] = $risk_result[0]['riskRatingColor1'] == "" ? '#ccc' : $risk_result[0]['riskRatingColor1'];
                } else {
                    $row[$i]['risk_value'] = '#';
                    $row[$i]['risk_color'] = '#ccc';
                }

                $i++;
            }
        }


        return $row;
    }

    public function getProcessesForDropdown() {

        $sql = sprintf("SELECT S.* FROM %s.swimlane S
				INNER JOIN %s.business_units B
					ON S.buID = B.buID
				ORDER BY reference,uniqueReference ASC", _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result_all = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($result_all)) {
            $i = 0;
            foreach ($result_all as $result) {

                $row[$i]['id'] = $result['swimID'];
                $row[$i]['reference'] = $result['reference'];
                $row[$i]['description'] = $result['description'];

                if ( _DB_TYPE != 'mysql' ) {
                    $sql1 = sprintf("SELECT TOP 1 riskRating1,riskRatingColor1 FROM %s.risk WHERE riskRating1 != '' AND riskRatingColor1 != '' AND processID = %d", _DB_OBJ_FULL, $result['swimID']);
                } else {
                    $sql1 = sprintf("SELECT riskRating1,riskRatingColor1 FROM %s.risk WHERE riskRating1 != '' AND riskRatingColor1 != '' AND processID = %d LIMIT 0,1", _DB_OBJ_FULL, $result['swimID']);
                }


                $pStatement1 = $this->dbHand->prepare($sql1);

                $pStatement1->execute();

                $risk_result = $pStatement1->fetchAll(PDO::FETCH_ASSOC);

                if (count($risk_result)) {
                    $row[$i]['risk_value'] = $risk_result[0]['riskRating1'] == "" ? '#' : $risk_result[0]['riskRating1'];
                    $row[$i]['risk_color'] = $risk_result[0]['riskRatingColor1'] == "" ? '#ccc' : $risk_result[0]['riskRatingColor1'];
                } else {
                    $row[$i]['risk_value'] = '#';
                    $row[$i]['risk_color'] = '#ccc';
                }

                $i++;
            }
        }


        return $row;
    }

    public function getOutstandingActionsdeprciated($p_overdue) {

        if ($p_overdue) {
            $data = $this->actionHandling->viewOverdueActions('risk');
        } else {
            $data = $this->actionHandling->viewAllActionByModule('risk');
        }


//dump_array($data);
        if (count($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT I.reference,I.buID,M.ID AS risk_id FROM %s.swimlane I
								INNER JOIN %s.risk M
									ON M.processID=I.swimID
								WHERE M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' "
                        , _DB_OBJ_FULL, _DB_OBJ_FULL, $search_value1
                        , $search_value2
                        , $search_value3
                        , $search_value4);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
                //dump_array($action_data);
                if (count($action_data)) {

                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['buID'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['whoAU'] = $value['whoAU'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                        $new_data[$i]['risk_id'] = $value2['risk_id'];
                    }
                    $i++;
                }
            }
        }

        return $new_data;
    }

    public function addOutstandingAction() {

        $sql = sprintf("SELECT improvements FROM %s.risk WHERE ID = %d ", _DB_OBJ_FULL, $this->RiskId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $improvements = $pStatement->fetchColumn();
        $new_improvements = $improvements . ',' . $this->RiskInfo['new_improvement'];

        $sql2 = sprintf("UPDATE risk SET improvements = '%s' WHERE ID = %d ", $new_improvements, $this->RiskId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function sendActionAlerts($p_record_id) {

        $this->RiskId = $p_record_id;


        $record_data = $this->viewHazardAssessment();


        $improvement_data = $this->viewImprovementRisk();



        $objProcessMaster = new ProcessFlowMaster();
        $process_data = $objProcessMaster->displayProcessFlowById($record_data['processID']);

        $process_details['process_title'] = getRiskReferenceFromProcessFlow($process_data['reference']);
        $process_details['description'] = $process_data['description'];



        if (count($improvement_data['improvements'])) {
            $i = 0;
            foreach ($improvement_data['improvements'] as $value) {

                $email_data[$i] = $process_details;
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];
                $email_data[$i]['hazard_summary'] = $record_data['hazardSummary'];
                $email_data[$i]['control_summary'] = $record_data['controlSummary'];

                $this->actionHandling->updateStatus($value['ID']);
                $i++;
            }
        }

        return $email_data;
    }

    public function sendInvalidAssessmentAlert($p_record_id) {

        $pfObj = new ProcessFlowMaster();
        $process_data = $pfObj->displayProcessFlowById($p_record_id);

        $email_data['process_id'] = $process_data['swimID'];
        $email_data['process_ref'] = getRiskReferenceFromProcessFlow($process_data['reference']);
        $email_data['process_desc'] = $process_data['description'];
        $email_data['process_bu'] = $process_data['buName'];
        $email_data['who'] = $process_data['whoID'];

        $email_data_final[0] = $email_data;

        return $email_data_final;
    }

    public function getRiskRecordsDse() {

        $sql = sprintf("SELECT * FROM %s.risk ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($records)) {
            foreach ($records as $value) {
                if ($value['dseAssessment'] != '' && $value['dseAssessment'] != 0) {
                    $process_no = $value['processID'];
                    $graph_data[$process_no] = $value['dseAssessment'];
                }
            }
        }

        return $graph_data;
    }

    public function deleteStepAssessment() {
        $step_data = $this->viewHazardAssessment();
        $files = $this->getRiskFileDetails();

        if ($step_data['improvements'] != '') {
            $action_arr = explode(',', $step_data['improvements']);
            if (count($action_arr)) {
                foreach ($action_arr as $value) {
                    $this->actionHandling->setActionDetails($value, "");
                    $this->actionHandling->deleteAction();
                }
            }
        }

        if (count($files)) {
            $objFile = new Upload();
            foreach ($files as $value) {
                $objFile->setFileInfo('process_risk_assessment', array('id' => $value['uploadedFileID'], 'destination' => 'process_risk_assessment'));
                $objFile->delete_file();
            }
        }

        $sql1 = sprintf("DELETE FROM %s.risk_files WHERE riskID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement1 = $this->dbHand->prepare($sql1);

        $pStatement1->execute();

        $sql2 = sprintf("DELETE FROM %s.risk WHERE ID = %d", _DB_OBJ_FULL, $this->RiskId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    private function moveFiles($p_identifier) {
        $rec_id = $this->RiskId;

        $module = 'process_risk_assessment';

        $path = _MYROOT . 'tmp/' . $module . '/' . $p_identifier;
        //exit;

        $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();
            //$this = new RiskAssessment();

            if (count($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);

                            $file_details = array('user_file_name' => $file_details_arr[2], 'file_type' => $file_type);
                            $objFile->setFileInfo($module, $file_details);
                            $objFile->setBogusDetails($file_details);
                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
                            //	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);
                                    $this->setRiskInfo($rec_id, $data_array);
                                    $this->addRiskFiles();
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }

    public function copyRiskAssessmentByBu($source_process, $sel_business_unit) {

        $procObj = new ProcessFlowMaster();

        if (is_array($sel_business_unit)) {

            $process_data = $procObj->displayProcessFlowById($source_process);

            $process_mapping = array();

            // create processes
            foreach ($sel_business_unit as $business_unit_ele) {
				$uniqueRef = new UniqueReference();
                $unique_reference_number = $uniqueRef->getUniqueNumber('PROCESSFLOW');

                $procObj->setProcessMasterInfo(0, $business_unit_ele, $unique_reference_number, $unique_reference_number, $process_data['description'], $process_data['processType'], $process_data['whoID'], $source_process);
                $process_id = $procObj->addProcessMaster(true);
                $process_mapping[$business_unit_ele] = $process_id;

                $procObj->addProcessCopyLog($source_process, $process_id);
            }

            $tables = array();

            $tables[] = 'risk';
            $tables[] = 'risk_files';

            foreach ($tables as $table_ele) {

                $table_ele_arr = explode("_", $table_ele);

                $method_name = '';

                foreach ($table_ele_arr as $table_ele_arr_ele) {
                    $method_name .= ucfirst($table_ele_arr_ele);
                }

                $method_name = 'copyRA' . $method_name;

                foreach ($process_mapping as $p_dest_process) {

                    //echo "call $method_name $source_process $p_dest_process<br/>";
                    $this->$method_name($source_process, $p_dest_process);
                }
            }

            $proObj = null;
        }
    }

    public function copyRiskAssessmentByBuDeprecatedjan($p_sourceBuID, $p_destinationBuID, $p_sel_processes) {

        $procObj = new ProcessFlowMaster();

        if (is_array($p_sel_processes)) {
            $process_data = $procObj->getProcessBySelProcess($p_sel_processes);
        } else {
            $process_data = $procObj->getProcessByBuID($p_sourceBuID);
        }
$uniqueRef= new UniqueReference();
        $unique_reference_number = $uniqueRef->getUniqueNumber('PROCESSFLOW');

        $process_mapping = array();

        // create processes
        foreach ($process_data as $process_data_ele) {
            $procObj->setProcessMasterInfo(0, $p_destinationBuID, $unique_reference_number, $unique_reference_number, $process_data_ele['description'], $process_data_ele['swimID'], $process_data_ele['parentSwimID']);
            $process_id = $procObj->addProcessMaster(true);
            $process_mapping[$process_data_ele['swimID']] = $process_id;
        }

        $tables = array();

        $tables[] = 'risk';
        $tables[] = 'risk_files';

        foreach ($tables as $table_ele) {
            $method_name_arr = explode('_', $table_ele);

            $method_name = '';

            foreach ($method_name_arr as $method_name_ele) {
                $method_name .= ucfirst($method_name_ele);
            }

            $method_name = 'copyRA' . $method_name;

            foreach ($process_mapping as $p_src_process => $p_dest_process) {
                $this->$method_name($p_src_process, $p_dest_process);
            }
        }

        $proObj = null;
    }

    private function copyRARisk($p_src_process, $p_dest_process) {

        $sql = sprintf("SELECT * FROM %s.risk
				WHERE processID = %d
				ORDER BY ID ASC", _DB_OBJ_FULL, $p_src_process);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $new_risk_steps_arr = array();

        foreach ($result as $result_ele) {

            $ins = sprintf("INSERT %s.risk (processID,
							processStepID,
							hazardClassificationID,
							dseAssessment,
							hazardsID,
							secondaryHazardID,
							hazardSymbols,
							hazardSummary,
							controlAtSource,
							controlAlongPath,
							controlAtWorker,
							controlSymbols,
							controlSummary,
							likelihood1,
							impact1,
							riskRating1,
							riskRatingColor1,
							improvementAtSource,
							improvementAlongPath,
							improvementAtWorker,
							improvements,
							noImprovement,
							improvementReason,
							likelihood2,
							impact2,
							riskRating2,
							riskRatingColor2,
							timeTrouble,
							netImpact,
							priority,
							status,
							archive,
							whoID,
							buID,
							processReference,
							eliminateHazard,
							subReference,
							overrulereason,
							overwriteControl
							)
							VALUES(%d, %d, %d, '%s', '%s',
							'%s', '%s', '%s','%s', '%s', '%s',
							'%s', '%s', %d, %d, '%s',
							'%s', '%s', '%s', '%s', '%s',
							'%s', '%s', '%s', '%s', '%s',
							'%s', '%s', '%s', '%s', '%s',
							'%s', %d, %d, '%s','%s',
							%d,'%s',%d)", _DB_OBJ_FULL, $p_dest_process, $result_ele['processStepID'], $result_ele['hazardClassificationID'], $result_ele['dseAssessment'], $result_ele['hazardsID'], $result_ele['secondaryHazardID'], $result_ele['hazardSymbols'], $result_ele['hazardSummary'], $result_ele['controlAtSource'], $result_ele['controlAlongPath'], $result_ele['controlAtWorker'], $result_ele['controlSymbols'], $result_ele['controlSummary'], $result_ele['likelihood1'], $result_ele['impact1'], $result_ele['riskRating1'], $result_ele['riskRatingColor1'], $result_ele['improvementAtSource'], $result_ele['improvementAlongPath'], $result_ele['improvementAtWorker'], $result_ele['improvements'], $result_ele['noImprovement'], $result_ele['improvementReason'], $result_ele['likelihood2'], $result_ele['impact2'], $result_ele['riskRating2'], $result_ele['riskRatingColor2'], $result_ele['timeTrouble'], $result_ele['netImpact'], $result_ele['priority'], $result_ele['status'], $result_ele['archive'], $result_ele['whoID'], $result_ele['buID'], $result_ele['processReference'], $result_ele['eliminateHazard'], $result_ele['subReference'], $result_ele['overrulereason'], $result_ele['overwriteControl']);


            $stmt_ins = $this->dbHand->prepare($ins);

            $stmt_ins->execute();

            $this->correct_steps_ids($p_src_process, $p_dest_process);
        }
    }

    private function correct_steps_ids($p_src_process, $p_dest_process) {
        //$new_risk_steps_arr

        $sql = sprintf("SELECT ID,stepLevel,swimID FROM %s.swimlane_data WHERE swimID IN (%d,%d) AND stepLevel IN (
							SELECT stepLevel FROM %s.swimlane_data WHERE ID IN (
								SELECT DISTINCT processStepID FROM %s.risk WHERE processID = %d
						 ) AND swimID = %d
						) ORDER By stepLevel,swimID ASC", _DB_OBJ_FULL, $p_src_process, $p_dest_process, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_src_process, $p_src_process);

        $stmt_sql = $this->dbHand->prepare($sql);
        $stmt_sql->execute();
        $result_stepsdata = $stmt_sql->fetchAll(PDO::FETCH_ASSOC);

        $result = array();

        for ($i = 0; $i < count($result_stepsdata); $i = $i + 2) {
            $result[$result_stepsdata[$i]['ID']] = $result_stepsdata[$i + 1]['ID'];
        }

        if (count($result)) {
            foreach ($result as $result_ele_key => $result_ele_val) {

                $upd .= sprintf("UPDATE %s.risk
						SET processStepID = %d
						WHERE processID = %d AND processStepID = %d;", _DB_OBJ_FULL, $result_ele_val, $p_dest_process, $result_ele_key);
            }

            $stmt_upd = $this->dbHand->prepare($upd);
            $stmt_upd->execute();
        }
    }

    private function copyRARiskFiles() {

        $sql = sprintf("SELECT * FROM %s.risk_files
				WHERE riskID = %d
				ORDER BY ID ASC", _DB_OBJ_FULL, $p_src_process);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $result_ele) {

            $ins = sprintf("INSERT %s.risk_files (
						    riskID,
							section,
							uploadedFileID)
							VALUES(%d, '%s', %d)", _DB_OBJ_FULL, $result_ele['riskID'], $result_ele['section'], $result_ele['uploadedFileID']);

            $stmt_ins = $this->dbHand->prepare($ins);
            $stmt_ins->execute();
        }
    }

    public function getListingforExport($p_identifier) {

        $p_identifier_arr = explode('#', $p_identifier);
        $p_identifier = $p_identifier_arr[0];

        switch ($p_identifier) {
            case 1 : $reportdata = $this->exportMainList();
                break;
            case 2 : $reportdata = $this->exportProcessSetp();
                break;
            case 3 : $reportdata = $this->exportAssessments();
                break;
            case 4 : $reportdata = $this->exportAssessmentsFull();
                break;
        }

        return $reportdata;
    }

    public function exportMainList() {

        $participantObj = SetupGeneric::useModule('Participant');

        $heading = array(array('ref' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Owner', 'type' => 'Type', 'desc' => 'Description','loc_name' => 'Location'));

        $RiskData = $this->getRiskAssessmentProcesses();
        
    
        $processFlowCount = count($RiskData);

        if ($processFlowCount) {
            $i = 0;
            foreach ($RiskData as $RiskDataEle) {

                $raData = $this->getFirstHazardWhoByProcess($RiskDataEle['swimID']);

                $participant_id = $raData['whoID'];
                //$participant_id = $RiskDataEle['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();
                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
            $loc_name = $this->get_location_name($RiskDataEle['location']);
                if ($RiskDataEle['criticalProcess'] == 1)
                    $type = "C";
                elseif ($RiskDataEle['keyProcess'] == 1)
                    $type = "K";
                else
                    $type = " ";

                $process_ref = preg_replace('/PF/', 'PR', $RiskDataEle['reference']);

                $result[$i]['ref'] = $process_ref;
                $result[$i]['bu'] = $RiskDataEle['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['type'] = $type;
                $result[$i]['desc'] = str_replace(',', '', $RiskDataEle['description']);
$result[$i]['loc_name']= str_replace("&amp;","&",$loc_name) ;
                $i++;
            }
        }
if(is_array($result)){
        $result = array_merge($heading, $result);
        return $result;
    }else{
         return $heading;
    }
    }
    
       public function exportMainFullList() {
    global $likelihood_arr;
        $participantObj = SetupGeneric::useModule('Participant');

        $heading = array(array('ref' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Owner', 'type' => 'Type', 'desc' => 'Description', 'loc_name' => 'Location','step'=>'Step','descQues'=>'Step Detail','psource'=>'Primary Source','source'=>'Source','ssource'=>'Secondary Source','hazardSummary'=>'Source Summary','threats'=>'Threats','tcomment'=>'Threat Comments','vuln'=>'Vulnerability','vcomment'=>'Vulnerability Comments','ciac'=>'CIA Confidentiality','ciai'=>'CIA Integrity','ciaa'=>'CIA Availibility','alongp1'=>'Along Path','atwork1'=>'At Worker','controlSummary'=>'Control Summary','riskRating1'=>'Risk Rating','likelihood1'=>'Likelihood','impact1'=>'Impact','improvement'=>'Improvement','likelihood2'=>'Improved Likelihood','impact2'=>'Improved Impact','atsource2'=>'Improved At Source','alongp2'=>'Improved Along Path','atwork2'=>'Improved At Worker','riskRating2'=>'Risk Rating2','improvementr'=>'Improvement Reason','time'=>'Time/Trouble','netimpact'=>'Net Impact','priority'=>'Priority','actionDesc'=>'Action Description','duedate'=>'Due date','starttime'=>'Start Time','enteredby'=>'Entered By','rca'=>'RCA','reportedby'=>'Reported By','reportdate'=>'Reported Date'));

        
      $sql_main = sprintf("select  S.reference,S.whoID,S.criticalProcess ,B.buName,S.description,S.location,D.steplevel,D.descQues,R.* "
                . "from %s.swimlane S "
                . "left join %s.swimlane_data D on S.swimID=D.swimid "
                . "left join %s.risk R on D.id=R.processStepID "
                . "left join %s.business_units B on D.buid=B.buID where not isnull(S.archive,0)=1 and isnull(R.archive,0)=0"
                . "order by S.swimID desc,D.steplevel", _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql_main);
        $pStatement->execute();
        $RiskData = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        
         
       // $RiskData = $this->getRiskAssessmentProcesses();

        //$processFlowCount = count($RiskData);

        if (is_array($RiskData)) {
            $i = 0;
            foreach ($RiskData as $RiskDataEle) {

              //  $raData = $this->getFirstHazardWhoByProcess($RiskDataEle['swimID']);

                $participant_id = $RiskDataEle['whoID'];
                //$participant_id = $RiskDataEle['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();
                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $loc_name = $this->get_location_name($RiskDataEle['location']);
                if ($RiskDataEle['criticalProcess'] == 1)
                    $type = "C";
                elseif ($RiskDataEle['keyProcess'] == 1)
                    $type = "K";
                else
                    $type = " ";

                $process_ref = preg_replace('/PF/', 'PR', $RiskDataEle['reference']);

                $arrRisk1=explode(",",$RiskDataEle['improvements']);
                $arrRisk2=explode(",",$RiskDataEle['priority']);
                $arrRisk3=explode(",#,",$RiskDataEle['improvement_d']);
                $arrRisk4=explode(",",$RiskDataEle['riskRating2']);
                
                foreach($arrRisk4 as $key=>$value){

                $result[$i]['ref'] = $process_ref;
                $result[$i]['bu'] = $RiskDataEle['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['type'] = $type;
                $result[$i]['loc_name'] = str_replace("&amp;","&",$loc_name) ;
                $result[$i]['priority'] = $RiskDataEle['priority'];
                $result[$i]['desc'] = str_replace(',', '', $RiskDataEle['description']);
                $result[$i]['riskRating1'] =  $RiskDataEle['riskRating1'];
                $result[$i]['descQues'] = str_replace(',', '', $RiskDataEle['descQues']);
                $result[$i]['step'] = $RiskDataEle['steplevel'];
                $result[$i]['hazardSummary'] = str_replace(',', '', $RiskDataEle['hazardSummary']);
                $result[$i]['controlSummary'] = str_replace(',', '', $RiskDataEle['controlSummary']);
                $result[$i]['action'] = $arrRisk1[$key];
                $actionData=$this->get_improvement_actions1($result[$i]['action']);
   
                 switch (strtolower($arrRisk2[$key])) {
                                case '#ff0000':$result[$i]['priority'] = "I";
                                    break;
                                case '#ffbf00': $result[$i]['priority'] = "M";
                                    break;
                                case '#008000': $result[$i]['priority'] = "L";
                                    break;
                                case '#800080': $result[$i]['priority'] = "T";
                                    break;
                                case '#ffffff': $result[$i]['priority'] = " ";
                                    break;
                            }
      
                $result[$i]['improvement'] =  $arrRisk3[$key];
                $result[$i]['riskRating2'] =  $arrRisk4[$key];
                $result[$i]['actionDesc']=$actionData["actionDescription"];                
                $result[$i]['duedate']=$actionData["dueDate"]=='' ? " " : format_date($actionData["dueDate"]);

                $result[$i]['psource']= $this->get_main_hazard($RiskDataEle['hazardClassificationID']);
                $result[$i]['source']=$this->get_hazards($RiskDataEle['hazardsID']);
                $result[$i]['ssource']=$this->get_main_hazard($RiskDataEle['secondaryHazardID']);
                $result[$i]['threats']=$this->get_threats($RiskDataEle['threats']);
                $result[$i]['tcomment']=$RiskDataEle['threat_comment'];
                $result[$i]['vuln']=$this->get_vuln($RiskDataEle['vulnerability']);
                $result[$i]['vcomment']=$RiskDataEle['vuln_comment'];
                $result[$i]['ciac']=$RiskDataEle['ciaConfidentiality'];
                $result[$i]['ciai']=$RiskDataEle['ciaIntegrity'];
                $result[$i]['ciaa']=$RiskDataEle['ciaAvailability'];
                $result[$i]['alongp1']=$this->get_control_measures($RiskDataEle['controlAlongPath']);
                $result[$i]['atwork1']=$this->get_control_measures($RiskDataEle['controlAtWorker']);
                
                
                $result[$i]['likelihood1']=$likelihood_arr[$RiskDataEle['likelihood1']];
                $result[$i]['impact1']=$this->get_impact($RiskDataEle['impact1']);
               $likelihood2_arr = '';
                            $likelihood2 = explode(',', $RiskDataEle['likelihood2']);
                            if (count($likelihood2)) {
                                foreach ($likelihood2 as $valLklhd) {
                                    $likelihood2_arr .= $likelihood_arr[$valLklhd]." - ";
                                }
                            }
                $result[$i]['likelihood2']=trim($likelihood2_arr," - ");
                $result[$i]['impact2']= $RiskDataEle['impact2'] == null? " " :  $this->get_impact($RiskDataEle['impact2']);
                $result[$i]['atsource2']=$this->get_control_measures($RiskDataEle['improvementAtSource']);
                $result[$i]['alongp2']=$this->get_control_measures($RiskDataEle['improvementAlongPath']);
                $result[$i]['atwork2']=$this->get_control_measures($RiskDataEle['improvementAtWorker']);
                $result[$i]['riskRating2']=$RiskDataEle['riskRating2'];
                $result[$i]['improvementr']=$RiskDataEle['improvementReason'];
                
                                            $time_arr = '';
                            $time = explode(',', $RiskDataEle['timeTrouble']);
                            if (is_array($time)) {
                                foreach ($time as $valTime) {
                                    $time_arr .= $likelihood_arr[$valTime]." - ";
                                }
                            }
                $result[$i]['time']=trim($time_arr," - ");
                $result[$i]['netimpact']=$this->get_net_impact($RiskDataEle['netImpact']);
                $result[$i]['priority']=$RiskDataEle['priority'];
                
                $result[$i]['starttime']=$RiskDataEle['starttime'];
                             $participantObj->setItemInfo(array('id' =>$RiskDataEle['origin']));
                $partcipantData = $participantObj->displayItemById();
                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['enteredby']= $participant_name;
                $result[$i]['rca']=$RiskDataEle['RCA'];
                 $participantObj->setItemInfo(array('id' =>$RiskDataEle['reportedby']));
                $partcipantData = $participantObj->displayItemById();
                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['reportedby']=$participant_name;
                $result[$i]['reportdate']=format_date($RiskDataEle['reported_date']);
                
                
                
                
                $i++;
                }
            }
        }

        $result = array_merge($heading, $result);

        return $result;
    }
    private function exportProcessSetp() {

        $heading = array(array('Step' => 'Step', 'desc' => 'Description', 'ph' => 'Primary Sources', 'sh' => 'Secondary Sources', 'cr' => 'Completed RA',
                'oa' => 'Open Actions', 'ova' => 'Overdue Actions'));


        $p_process = $_GET['process_id'];

        $this->setRiskInfo(0, array('process_id' => $p_process));
        $RiskData = $this->getStepsByProcess();
        $processFlowCount = count($RiskData);

        if ($processFlowCount) {
            $i = 0;
            foreach ($RiskData as $RiskDataEle) {

                $this->setRiskInfo(0, array('process_id' => $p_process, 'step_id' => $RiskDataEle['ID'], 'archive' => '0'));
                $data = $this->getHazardsByProcessStep();

                $step_assessment_counts = (int) count($data);

                $secondary_hazards = $this->secondaryHazardCount();

                $this->setRiskInfo(0, array('process_id' => $p_process, 'step_id' => $RiskDataEle['ID'], 'status' => 0));
                $open_actions = $this->openActions();

                $this->setRiskInfo(0, array('process_id' => $p_process, 'step_id' => $RiskDataEle['ID'], 'status' => 1));
                $completed_actions = $this->openActions();



                $result[$i]['step'] = ($i + 1);
                $result[$i]['desc'] = str_replace(',', '', $RiskDataEle['descQues']);
                $result[$i]['ph'] = $step_assessment_counts;
                $result[$i]['sh'] = $secondary_hazards;
                $result[$i]['cr'] = $completed_actions;
                $result[$i]['oa'] = $open_actions;
                $result[$i]['ova'] = '0';

                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
    }

    public function getaname($id) {
        $this->id = $id;
        $sql = sprintf("SELECT hazardName FROM %s.control_measures_hazard WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getrname($id) {
        $this->id = $id;
        $sql = sprintf("SELECT name FROM %s.impact_measure WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    private function exportAssessmentsFull() {

        $heading = array(array('Step' => 'S. No.', 'hzd' => 'Primary Source', 'who' => 'Who', 'hs' => 'Source Summary', '1' => 'Source', '2' => 'Secondary Source class ', '3' => 'Along the path', '4' => 'At the worker', '5' => 'Control Measures Summary', '6' => 'Likelihood1', '7' => 'Impact1', '8' => 'Risk Rating1', '9' => 'Risk Rating color1', '10' => 'At the source', '11' => 'Along the path', '12' => 'At the worker', '13' => 'No Improvement is Possible', '14' => 'Improved Control Measures ', '15' => 'Likelihood2', '16' => 'Impact2', '17' => 'Risk Rating2', '18' => 'Risk Rating color2', '19' => 'Net Impact', '20' => 'Priority', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'adue' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.'));


        $p_process = $_GET['process_id'];
        $step_id = $_GET['step_id'];

        $participantObj = SetupGeneric::useModule('Participant');
        $hazardClass = SetupGeneric::useModule('HazardClassification');

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setRiskInfo(0, array('process_id' => $p_process, 'step_id' => $step_id, 'archive' => $archive_session));
        $data = $this->getHazardsByProcessStep();

        if (count($data)) {
            $i = 0;
            foreach ($data as $value) {

                $hazardClass->setItemInfo(array(
                    'id' => $value['hazardClassificationID']
                ));
                $dataPrimaryHazard = $hazardClass->displayCategoryById();

                $participant_id = $value['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];



                $result[$i]['step'] = ($i + 1);
                $result[$i]['hzd'] = $dataPrimaryHazard['primaryHazard'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['hs'] = str_replace(',', '', $value['hazardSummary']);

                $hazardClass->setItemInfo(array(
                    'id' => $value['secondaryHazardID']
                ));
                $dataPrimaryHazard1 = $hazardClass->displayCategoryById();

                $pieces = explode(",", $value['hazardsID']);
                $a = 0;
                foreach ($pieces as $val) {

                    $hazardClass->setItemInfo(array(
                        'id' => $val
                    ));
                    $haz = $hazardClass->displayCategoryById77();
                    $haz_val[$a] = $haz['secondaryHazard'];
                    $a++;
                }
                $haz_val1 = implode(",", $haz_val);
                $result[$i]['1'] = $haz_val1;
                $result[$i]['2'] = $dataPrimaryHazard1['primaryHazard'];
                $al = explode(',', $value['controlAlongPath']);

                $e = 0;
                foreach ($al as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $al_val[$e] = $t['hazardName'];
                    $e++;
                }
                $al_val1 = implode(",", $al_val);

                $aw = explode(',', $value['controlAtWorker']);

                $e = 0;
                foreach ($aw as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $aw_val[$e] = $t['hazardName'];
                    $e++;
                }
                $aw_val1 = implode(",", $aw_val);
                $result[$i]['3'] = $al_val1;
                $result[$i]['4'] = $aw_val1;
                $result[$i]['5'] = $value['controlSummary'];
                if ($value['likelihood1'] == '1') {
                    $r1 = 'Virtually Certain';
                }
                if ($value['likelihood1'] == '2') {
                    $r1 = 'Very Likely';
                }
                if ($value['likelihood1'] == '3') {
                    $r1 = 'Likely';
                }
                if ($value['likelihood1'] == '4') {
                    $r1 = 'Unlikely';
                }
                if ($value['likelihood1'] == '5') {
                    $r1 = 'Very Unlikely';
                }
                if ($value['likelihood1'] == '6') {
                    $r1 = 'Almost Impossible';
                }
                $result[$i]['6'] = $r1;
                $rimp1 = $this->getrname($value['impact1']);
                $result[$i]['7'] = $rimp1;
                $result[$i]['8'] = $value['riskRating1'];
                $result[$i]['9'] = $value['riskRatingColor1'];

                $at = explode(',', $value['improvementAlongPath']);

                $e = 0;
                foreach ($at as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $at_val[$e] = $t['hazardName'];
                    $e++;
                }
                $at_val1 = implode(",", $at_val);

                $as = explode(',', $value['improvementAtSource']);

                $e = 0;
                foreach ($as as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $as_val[$e] = $t['hazardName'];
                    $e++;
                }
                $as_val1 = implode(",", $as_val);

                $atw = explode(',', $value['improvementAtWorker']);

                $e = 0;
                foreach ($atw as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $atw_val[$e] = $t['hazardName'];
                    $e++;
                }
                $atw_val1 = implode(",", $atw_val);
                $result[$i]['10'] = $as_val1;
                $result[$i]['11'] = $at_val1;
                $result[$i]['12'] = $atw_val1;
                if ($value['noImprovement'] == '1') {
                    $noi = 'Yes';
                } else {
                    $noi = 'No';
                }
                $result[$i]['13'] = $noi;
                $result[$i]['14'] = $value['improvementReason'];
                if ($value['likelihood2'] == '1') {
                    $r2 = 'Virtually Certain';
                }
                if ($value['likelihood2'] == '2') {
                    $r2 = 'Very Likely';
                }
                if ($value['likelihood2'] == '3') {
                    $r2 = 'Likely';
                }
                if ($value['likelihood2'] == '4') {
                    $r2 = 'Unlikely';
                }
                if ($value['likelihood2'] == '5') {
                    $r2 = 'Very Unlikely';
                }
                if ($value['likelihood2'] == '6') {
                    $r2 = 'Almost Impossible';
                }
                $result[$i]['15'] = $r2;
                $rimp2 = $this->getrname($value['impact2']);
                $result[$i]['16'] = $rimp2;
                $result[$i]['17'] = $value['riskRating2'];
                $result[$i]['18'] = $value['riskRatingColor2'];
                $rimp3 = $this->getrname($value['netImpact']);
                $result[$i]['19'] = $rimp3;
                $result[$i]['20'] = $value['priority'];
                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $value['improvements'],
                ));

                $data_records7 = $type->displayItemById5();
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];
                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
    }

    private function exportAssessments() {

        $heading = array(array('Step' => 'S. No.', 'hzd' => 'Primary Source', 'hz' => 'Secondary Source', 'who' => 'Who', 'hs' => 'Source Summary'));


        $p_process = $_GET['process_id'];
        $step_id = $_GET['step_id'];

        $participantObj = SetupGeneric::useModule('Participant');
        $hazardClass = SetupGeneric::useModule('HazardClassification');

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setRiskInfo(0, array('process_id' => $p_process, 'step_id' => $step_id, 'archive' => $archive_session));
        $data = $this->getHazardsByProcessStep();

        if (count($data)) {
            $i = 0;
            foreach ($data as $value) {

                $hazardClass->setItemInfo(array(
                    'id' => $value['hazardClassificationID']
                ));
                $dataPrimaryHazard = $hazardClass->displayCategoryById();

                $hazardClass->setItemInfo(array(
                    'id' => $value['secondaryHazardID']
                ));
                $dataPrimaryHazard1 = $hazardClass->displayCategoryById();

                $participant_id = $value['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];



                $result[$i]['step'] = ($i + 1);
                $result[$i]['hzd'] = $dataPrimaryHazard['primaryHazard'];
                $result[$i]['hz'] = $dataPrimaryHazard1['primaryHazard'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['hs'] = str_replace(',', '', $value['hazardSummary']);

                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
    }

    public function getAllRiskAssessments() {
        $sql = sprintf("SELECT * FROM %s.risk ORDER By ID DESC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $records;
    }

    public function getEmailData($p_record_id) {

        $sql = sprintf("SELECT * FROM %s.risk ", _DB_OBJ_FULL);
        $sql = $sql . " WHERE improvements LIKE '" . $p_record_id . "' OR improvements LIKE '%," . $p_record_id . "' OR improvements LIKE '" . $p_record_id . ",%' OR improvements LIKE '%," . $p_record_id . ",%' ";

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result) {

            $mail_data['bu_id'] = $result['buID'];
            $mail_data['process_no'] = $result['processReference'];
            $mail_data['hazard'] = $result['hazardSummary'];
        }

        return $mail_data;
    }

    public function updateStepStatus() {
        $sql = sprintf("UPDATE %s.swimlane_data SET assessmentDone='%s',assessmentReason = '%s' WHERE ID = %d", _DB_OBJ_FULL, $this->RiskInfo['done'], $this->RiskInfo['reason'], $this->RiskInfo['step_id']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function eliminateHazard() {

        $sql = sprintf("SELECT * FROM %s.risk WHERE ", _DB_OBJ_FULL);

        $sql .= " improvements LIKE '" . $this->RiskInfo['action_id'] . "' OR improvements LIKE '" . $this->RiskInfo['action_id'] . ",%' OR
		improvements LIKE '%," . $this->RiskInfo['action_id'] . "' OR improvements LIKE '%," . $this->RiskInfo['action_id'] . ",%'";

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($data)) {
            $this->setRiskInfo($data[0]['ID'], array('archive' => '1'));
            $this->archiveRisk();
        }
    }

    public function getStepPrimaryHazardWho() {

        $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d", _DB_OBJ_FULL, $this->RiskId);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function finishStepAssesments() {


        $sql1 = sprintf("SELECT * FROM %s.risk WHERE status = '0' AND processID = %d", _DB_OBJ_FULL, $this->RiskId);

        $stmt = $this->dbHand->prepare($sql1);
        $stmt->execute();

        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (count($data)) {

            $objPro = new ProcessFlowMaster();
            $objPro->sendActionMail($this->RiskInfo['process_id']);
            $objPro = null;
        }

        $sql = sprintf("UPDATE %s.risk SET status = '1' WHERE status = '0' AND processID = %d", _DB_OBJ_FULL, $this->RiskInfo['process_id']);

        $stmt = $this->dbHand->prepare($sql);

        if ($stmt->execute()) {
            $objPro = new ProcessFlowMaster();
            //$objPro->sendActionMail($this->RiskInfo['process_id']);
            $objPro->setProcessesAssessmentDone($this->RiskInfo['process_id']);
            $objPro = null;
            return true;
        } else {
            return false;
        }
    }

    public function processAssessmentMetadata() {

        $assessment_done_process_steps = 0;

        if ($this->steps_resultset) {
            foreach ($this->steps_resultset as $RiskDataEle) {
                $assessment_done = (int) $RiskDataEle['assessmentDone'];
                if ($assessment_done) {
                    $assessment_done_process_steps++;
                }
            }
        }
        return array('total_process_steps' => count($this->steps_resultset),
            'assessment_done_process_steps' => $assessment_done_process_steps);
    }

    public function getCountUnfinishedActions() {

        $sql = sprintf("select improvements from %s.risk WHERE processID = %d", _DB_OBJ_FULL, $this->RiskInfo['process_id']);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $counter = "0";
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($data)) {
            $counter = "0";
            foreach ($data as $value) { {
                    if ($value["improvements"])
                        $counter.="," . $value["improvements"];
                }
            }
        }
        if ($counter == "0")
            return 0;
        else {
            $sql = sprintf("select COUNT(*) as cnt from  %s.actions where not approveAU =1 and ID in (%s)", _DB_OBJ_FULL, $counter);
            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            return $data["cnt"];
        }
    }

    public function updateAction($value) {

        $sql = sprintf("UPDATE %s.actions SET 
										actionDescription = '%s',
										who = %d,
										whoAU =%d,
										dueDate = '%s'
										,addapprover=%d
										,currentwho=%d
                                                                                ,record=%d
                                                                                ,moduleelement='risk' 
									WHERE ID = %d", _DB_OBJ_FULL, $value['description'], $value['who'], $value['whoAU'], format_date_for_mysql($value['due_date']), $value['who2AU'], $value['who'], $value['record'], $value['record_id']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getOverDueActions($buStr, $date) {
        $this->sql_query = sprintf("select A.id,R.processReference,R.improvements,R.improvement_d,R.hazardSummary,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID left join %s.participant_database P on A.currentWho=P.participantID where modulename = 'risk' and B.buID in(%s) and approveAU=0 and duedate < '%s'
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $date);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getOutstandingActions($buStr, $fdate) {

        $insp_out = SetupGeneric::useModule('InspectionOutstandingAction');
        $outstanding_duration = explode(':', $insp_out->displayItems());

        switch ($outstanding_duration[1]) {
            case 'M' : $interval = '+' . $outstanding_duration[0] . ' MONTH';
                break;
            case 'Y' : $interval = '+' . $outstanding_duration[0] . ' YEAR';
                break;
        }

                $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");

        $this->sql_query = sprintf("select A.id,R.processReference,R.improvements,R.improvement_d,R.hazardSummary,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID left join %s.participant_database P on A.currentWho=P.participantID where modulename = 'risk' and B.buID in(%s) and approveAU=0 and duedate >=  '%s'
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $outstandingDate);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function wordreport($id) {

        $this->id = $id;

        global $likelihood_arr;

        $sql = "SELECT * FROM %s.swimlane WHERE swimID = %d ";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql_p);
        //$pStatement->bindParam(1,$this->filters['id']);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($data);
        if (count($data)) {
            $risk_data = $data[0];
            //$risk_data['bu_name'] = $this->get_bu_name($data[0]['buID']);

            $sql2 = "SELECT * FROM %s.swimlane_data WHERE swimID = %d and [type] != 'D' order by altPathIndex, stepLevel,ID ASC";

            $sql2_p = sprintf($sql2, _DB_OBJ_FULL, $risk_data['swimID']);
            $pStatement2 = $this->dbHand->prepare($sql2_p);
            //$pStatement2->bindParam(1,$risk_data['swimID']);
            $pStatement2->execute();
            $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);


            if (count($data_steps)) {
                $i = 0;
                foreach ($data_steps as $value_step) {
                    $risk_data['steps'][$i]['id'] = $value_step['ID'];
                    $risk_data['steps'][$i]['desc'] = $value_step['descQues'];
                    $risk_data['steps'][$i]['assessment_done'] = $value_step['assessmentDone'];
                    $risk_data['steps'][$i]['assessment_done_reason'] = $value_step['assessmentReason'];

                    $sql3 = "SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d ";

                    $sql3_p = sprintf($sql3, _DB_OBJ_FULL, $risk_data['swimID'], $value_step['ID']);
                    $pStatement3 = $this->dbHand->prepare($sql3_p);
                    /* $pStatement3->bindParam(1,$risk_data['swimID']);
                      $pStatement3->bindParam(2,$value_step['ID']); */
                    $pStatement3->execute();
                    $data_risk = $pStatement3->fetchAll(PDO::FETCH_ASSOC);
                    if ($data_risk) {
                        $risk_data['steps'][$i]['assessment_done'] = '1';
                    }


                    if (count($data_risk)) {
                        $j = 0;
                        foreach ($data_risk as $value_risk) {
                            //dump_array($value_risk);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['primary_hazard'] = $this->get_main_hazard($value_risk['hazardClassificationID']) != '' ? $this->get_main_hazard($value_risk['hazardClassificationID']) : '-';
                            $risk_data['steps'][$i]['risk_assessment'][$j]['hazardSummary'] = $value_risk['hazardSummary'] != '' ? $value_risk['hazardSummary'] : '-';
                            $risk_data['steps'][$i]['risk_assessment'][$j]['controlSummary'] = $value_risk['controlSummary'] != '' ? $value_risk['controlSummary'] : '-';
                            $risk_data['steps'][$i]['risk_assessment'][$j]['riskRating'] = $value_risk['riskRating1'] != '' ? $value_risk['riskRating1'] : '-';
                            $risk_data['steps'][$i]['risk_assessment'][$j]['riskRatingColor'] = $value_risk['riskRatingColor1'] != '' ? $value_risk['riskRatingColor1'] : '-';

                            if ($value_risk['hazardSymbols']) {
                                $symbols = explode(',', $value_risk['hazardSymbols']);
                                if (count($symbols)) {
                                    $risk_data['steps'][$i]['hazardSymbolsCount'] = count($symbols);
                                    foreach ($symbols as $sym_ele) {
                                        if ($sym_ele != '')
                                            $risk_data['steps'][$i]['hazardSymbols'][] = $sym_ele;
                                    }
                                }
                            }

                            if (is_array($risk_data['steps'][$i]['hazardSymbols'])) {
                                $risk_data['steps'][$i]['hazardSymbols'] = array_unique($risk_data['steps'][$i]['hazardSymbols']);
                            }

                            if ($value_risk['controlSymbols']) {
                                $symbols_control = explode(',', $value_risk['controlSymbols']);
                                if (count($symbols_control)) {
                                    $risk_data['steps'][$i]['controlSymbolsCount'] = count($symbols_control);
                                    foreach ($symbols_control as $sym_control_ele) {
                                        if ($sym_control_ele != '')
                                            $risk_data['steps'][$i]['controlSymbols'][] = $sym_control_ele;
                                    }
                                }
                            }

                            if (is_array($risk_data['steps'][$i]['controlSymbols'])) {
                                $risk_data['steps'][$i]['controlSymbols'] = array_unique($risk_data['steps'][$i]['controlSymbols']);
                            }
                            //	$check = $this->get_improvement_actions($value_risk['improvements']);
                            //dump_array($check);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['approveAU'] = $check[$j]['approveAU'];
                            $risk_data['steps'][$i]['risk_assessment'][$j]['eliminateHazard'] = $value_risk['eliminateHazard'];
                            $improvement_d = explode(",#,", $value_risk['improvement_d']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvement_d'] = $improvement_d['0'];

                            $files = "";
                            //echo '...'.$this->get_uploaded_files($value_risk['ID'],'hazard').'...';
                            //	$files = $risk_data['steps'][$i]['files'].','.$this->get_uploaded_files($value_risk['ID'],'hazard').','.$this->get_uploaded_files($value_risk['ID'],'control');


                            $j++;
                        }
                    }

                    $file = trim($files, ',');
                    $risk_data['steps'][$i]['files'] = $file == '' ? '-' : $file;


                    $i++;
                }
            }
            //dump_array($risk_data);
        }

        return $risk_data;
    }

    public function wordreportr2() {

        //$sql = "SELECT * FROM %s.swimlane WHERE swimID = %d ";
        //	$b_unit = $this->filters['bu'];
        //if ( $b_unit == 0 ) {
        $sql = "SELECT * FROM %s.swimlane ORDER By swimID ASC";
        $sql_p = sprintf($sql, _DB_OBJ_FULL);
        /* } else {

          $this->objOrg->setItemInfo(array('id'=>$b_unit));
          $orgdata = $this->objOrg->getAllChilds($b_unit);

          if ( is_array($orgdata) ) {
          $all_bus = implode(',',$orgdata);
          } else {
          $all_bus = $b_unit;
          }

          $sql = "SELECT * FROM %s.swimlane WHERE buID IN (%s) ORDER By swimID ASC";
          $sql_p = sprintf($sql,_DB_OBJ_FULL,$all_bus);
          } */

        $pStatement = $this->dbHand->prepare($sql_p);
        //$pStatement->bindParam(1,$this->filters['id']);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($data);exit;

        /* if ( count($data) ) {
          $risk_data = $data[0];
          $risk_data['bu_name'] = $this->get_bu_name($data[0]['buID']);
          } */



        $sql2 = "SELECT * FROM %s.risk WHERE processID = %d ";

        if (count($data)) {

            foreach ($data as $element) {

                $process_id = $element['swimID'];

                $sql2_p = sprintf($sql2, _DB_OBJ_FULL, $process_id);
                $pStatement2 = $this->dbHand->prepare($sql2_p);
                $pStatement2->execute();
                $risk_data_db = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

                //dump_array($risk_data_db);

                if (count($risk_data_db)) {
                    foreach ($risk_data_db as $riskEle) {

                        if ($riskEle['hazardClassificationID']) {

                            $primary_hazard = $this->get_main_hazard($riskEle['hazardClassificationID']);
                            $risk_data['risk_assessment']['primary_hazards'][$primary_hazard] ++;

                            if ($riskEle['secondaryHazardID']) {
                                $sec_hazards = explode(',', $riskEle['secondaryHazardID']);
                                if (count($sec_hazards)) {
                                    foreach ($sec_hazards as $value_sec_risk) {
                                        $secondary_hazard = $this->get_main_hazard($value_sec_risk);
                                        $risk_data['risk_assessment']['secondary'][$secondary_hazard] ++;
                                    }
                                }
                            }



                            if ($riskEle['controlAlongPath']) {

                                $controls = explode(',', $riskEle['controlAlongPath']);
                                if (count($controls)) {
                                    foreach ($controls as $valueSrc) {

                                        $imrv = $this->get_control_measures_with_initials($valueSrc);
                                        ;
                                        $risk_data['risk_assessment']['control'][$imrv] ++;
                                    }
                                }
                            }

                            if ($riskEle['controlAtSource']) {
                                $controls = explode(',', $riskEle['controlSource']);
                                if (count($controls)) {
                                    foreach ($controls as $valueSrc) {
                                        $imrv = $this->get_control_measures_with_initials($valueSrc);
                                        ;
                                        $risk_data['risk_assessment']['control'][$imrv] ++;
                                    }
                                }
                            }

                            if ($riskEle['controlAtWorker']) {
                                $controls = explode(',', $riskEle['controlAtWorker']);
                                if (count($controls)) {
                                    foreach ($controls as $valueSrc) {
                                        $imrv = $this->get_control_measures_with_initials($valueSrc);
                                        ;
                                        $risk_data['risk_assessment']['control'][$imrv] ++;
                                    }
                                }
                            }



                            if ($riskEle['improvementAtSource']) {
                                $improvements = explode(',', $riskEle['improvementAtSource']);
                                if (count($improvements)) {
                                    foreach ($improvements as $valueSrc) {
                                        $imrv = $this->get_control_measures_with_initials($valueSrc);
                                        ;
                                        $risk_data['risk_assessment']['improvement'][$imrv] ++;
                                    }
                                }
                            }

                            if ($riskEle['improvementAlongPath']) {
                                $improvements = explode(',', $riskEle['improvementAlongPath']);
                                if (count($improvements)) {
                                    foreach ($improvements as $valueSrc) {
                                        $imrv = $this->get_control_measures_with_initials($valueSrc);
                                        ;
                                        $risk_data['risk_assessment']['improvement'][$imrv] ++;
                                    }
                                }
                            }

                            if ($riskEle['improvementAtWorker']) {
                                $improvements = explode(',', $riskEle['improvementAtWorker']);
                                if (count($improvements)) {
                                    foreach ($improvements as $valueSrc) {
                                        $imrv = $this->get_control_measures_with_initials($valueSrc);
                                        ;
                                        $risk_data['risk_assessment']['improvement'][$imrv] ++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        //dump_array($risk_data['risk_assessment']);
        //exit;


        if (is_array($risk_data['risk_assessment']['primary_hazards'])) {
            ksort($risk_data['risk_assessment']['primary_hazards']);
        }
        if (is_array($risk_data['risk_assessment']['secondary'])) {
            ksort($risk_data['risk_assessment']['secondary']);
        }
        if (is_array($risk_data['risk_assessment']['control'])) {
            ksort($risk_data['risk_assessment']['control']);
        }
        if (is_array($risk_data['risk_assessment']['improvement'])) {
            ksort($risk_data['risk_assessment']['improvement']);
        }

        //	$risk_data['report_head'] = false;
        //	if ( $this->filters['heading'] ) {
        //		$risk_data['report_head'] = true;
        //	}
        //if ( $b_unit == 0 ) {

        $bu_name = 'All Business Units';

        //} else {
        //	$this->objOrg->setItemInfo(array('id'=>$b_unit));
        //$bu_data = $this->objOrg->displayItemById();
        //dump_array($bu_data);exit;
        //$bu_name = $bu_data['buName'];
        //	}
        //$business_units = $this->objOrg->getBusinessUnits($b_unit);
        //$business_units = str_replace('-- Select --','All Business Units',$business_units);
        //$risk_data['bu'] = $business_units;
        //$risk_data['bu_name'] = $bu_name;
        //dump_array($risk_data);exit;

        return $risk_data;
    }

    public function wordreportr3() {

        // $b_unit = $this->filters['bu'];
        $j = 0;
        //if ( $b_unit == 0 ) {
        $sql = "SELECT * FROM %s.swimlane ORDER By swimID ASC";
        $sql_main = sprintf($sql, _DB_OBJ_FULL);
        /* } else {

          $this->objOrg->setItemInfo(array('id'=>$b_unit));
          $orgdata = $this->objOrg->getAllChilds($b_unit);

          if ( is_array($orgdata) ) {
          $all_bus = implode(',',$orgdata);
          $all_bus = $all_bus.','.$b_unit;
          } else {
          $all_bus = $b_unit;
          }

          $sql = "SELECT * FROM %s.swimlane WHERE buID IN (%s) ORDER By swimID ASC";
          $sql_main = sprintf($sql,_DB_OBJ_FULL,$all_bus);
          } */

        //$sql = sprintf("SELECT * FROM %s.swimlane ORDER BY swimID ASC ",_DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql_main);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        //dump_array($data);

        if (count($data)) {
            foreach ($data as $valueProcess) {

                $sql_step = "SELECT * FROM %s.swimlane_data WHERE swimID = %d ORDER BY ID ASC";
                $sql_step_p = sprintf($sql_step, _DB_OBJ_FULL, $valueProcess['swimID']);
                //echo "<br/>";
                $pStatement2 = $this->dbHand->prepare($sql_step_p);
                //$pStatement2->bindParam(1,$valueProcess['swimID']);
                $pStatement2->execute();
                $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);
                //dump_array($data_steps);

                if (count($data_steps)) {

                    $process_id = $valueProcess['swimID'];

                    $i = 1;
                    //$j=0;

                    foreach ($data_steps as $valueStep) {

                        $sql_risk = "SELECT ID,improvements,hazardSummary,controlSummary,riskRating1,riskRatingColor1
											FROM %s.risk WHERE processID = %d AND processStepID = %d ORDER BY ID ASC";

                        $sql_risk_p = sprintf($sql_risk, _DB_OBJ_FULL, $valueProcess['swimID'], $valueStep['ID']);

                        $pStatement3 = $this->dbHand->prepare($sql_risk_p);

                        $pStatement3->execute();
                        $data_risk = $pStatement3->fetchAll(PDO::FETCH_ASSOC);
                        //dump_array($data_risk);

                        if (count($data_risk)) {

                            foreach ($data_risk as $valueRisk) {
                                //echo $valueRisk['riskRatingColor1']."<br/>";

                                switch (strtolower($valueRisk['riskRatingColor1'])) {
                                    case '#ffa500': $colororder = 0;
                                        break;
                                    case '#ff0000': $colororder = 0;
                                        break;
                                    case '#ffbf00': $colororder = 1;
                                        break;
                                    case '#00ff00': $colororder = 2;
                                        break;
                                    case '#684398': $colororder = 3;
                                        break;
                                    case '#ffffff': $colororder = 4;
                                        break;
                                }

                                if ($valueRisk['improvements'] != '') {

                                    $sql_impr = "SELECT actionDescription
                                                FROM %s.actions WHERE ID IN (%s)";

                                    $sql_impr_p = sprintf($sql_impr, _DB_OBJ_FULL, $valueRisk['improvements']);

                                    $pStatement4 = $this->dbHand->prepare($sql_impr_p);

                                    $pStatement4->execute();
                                    $data_risk_impr = $pStatement4->fetchALL(PDO::FETCH_ASSOC);

                                    $data_risk_impr_count = count($data_risk_impr);

                                    if ($data_risk_impr_count) {
                                        foreach ($data_risk_impr as $data_risk_impr_ele) {
                                            $report_data[$colororder][$j]['improvement_summary'] .= $data_risk_impr_ele['actionDescription'] . "<br/><br/>";
                                        }
                                    }
                                } else {
                                    $report_data[$colororder][$j]['improvement_summary'] = $valueRisk['improvements'] == '' ? '-' : $valueRisk['improvements'];
                                }


                                $report_data[$colororder][$j]['bu_name'] = $this->get_bu_name($valueProcess['buID']);
                                $report_data[$colororder][$j]['reference'] = preg_replace('/PF/', 'PR', $valueProcess['reference']);
                                $report_data[$colororder][$j]['description'] = $valueProcess['description'];

                                $report_data[$colororder][$j]['step_no'] = $i;
                                $report_data[$colororder][$j]['description1'] = $valueStep['descQues'] == '' ? '-' : $valueStep['descQues'];
                                $report_data[$colororder][$j]['hazard_summary'] = $valueRisk['hazardSummary'] == '' ? '-' : $valueRisk['hazardSummary'];
                                $report_data[$colororder][$j]['control_summary'] = $valueRisk['controlSummary'] == '' ? '-' : $valueRisk['controlSummary'];
                                $report_data[$colororder][$j]['risk_rating'] = $valueRisk['riskRating1'];
                                $report_data[$colororder][$j]['risk_rating_color'] = $valueRisk['riskRatingColor1'];

                                $j++;
                            }
                        }

                        $i++;
                    }
                } // end if
            }
        }

        if (count($report_data)) {
            ksort($report_data);
        }


        $report_data_new['report_data'] = $report_data;
        //if ( $this->filters['type'] == 'html' ) {
        //	$report_data_new['report_type'] = 'html';
        //}
        //if ( $b_unit == 0 ) {

        $bu_name = 'All Business Units';

        //} else {
        //	$this->objOrg->setItemInfo(array('id'=>$b_unit));
        //$bu_data = $this->objOrg->displayItemById();
        //dump_array($bu_data);exit;
        //$bu_name = $bu_data['buName'];
        //}
        //$business_units = $this->objOrg->getBusinessUnits($b_unit);
        //$business_units = str_replace('-- Select --','All Business Units',$business_units);
        //$report_data_new['bu'] = $business_units;
        //$report_data_new['bu_name'] = $bu_name;
        //dump_array($report_data_new);

        return $report_data_new;
    }

    private function get_child_hazards($p_hazard_id) {


        $sql = "SELECT * FROM %s.hazard_classification WHERE hpcID = %d ";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_hazard_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        //$pStatement->bindParam(1,$value_id);
        $pStatement->execute();
        $hazards = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $hazards;
    }

    private function get_hazards($p_hazard_id) {

        $hazards_id_arr = explode(',', $p_hazard_id);
        $sql = "SELECT secondaryHazard FROM %s.hazard_classification WHERE ID = %d ";

        if (count($hazards_id_arr)) {
            foreach ($hazards_id_arr as $value_id) {

                $sql_p = sprintf($sql, _DB_OBJ_FULL, $value_id);
                //echo "<br/>";
                $pStatement = $this->dbHand->prepare($sql_p);
                $pStatement->bindParam(1, $value_id);
                $pStatement->execute();
                $hazards .= $pStatement->fetchColumn() . ', ';
            }
        }
        return rtrim($hazards, ', ');
    }

    public function wordreportr4() {

        $sql = sprintf("SELECT * FROM %s.swimlane ORDER BY swimID ASC ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($data);exit;
        if (count($data)) {
            foreach ($data as $valueProcess) {

                $process_id = $valueProcess['swimID'];

                //echo $valueProcess['reference'];
                $sql_step = "SELECT * FROM %s.swimlane_data WHERE swimID = %d ORDER BY ID ASC";
                $sql_step_p = sprintf($sql_step, _DB_OBJ_FULL, $valueProcess['swimID']);
                $pStatement2 = $this->dbHand->prepare($sql_step_p);

                $pStatement2->execute();
                $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);
                //dump_array($data_steps);
                if (count($data_steps)) {

                    $i = 1;
                    $j = 0;
                    $id_val = 1;
                    //$id_value = 0;
                    foreach ($data_steps as $valueStep) {

                        $sql_risk = "SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d
											ORDER BY ID ASC";

                        $sql_risk_p = sprintf($sql_risk, _DB_OBJ_FULL, $valueProcess['swimID'], $valueStep['ID']);

                        $pStatement3 = $this->dbHand->prepare($sql_risk_p);
                        $pStatement3->execute();
                        $data_risk = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

                        //dump_array($data_risk);
                        //exit;

                        if (count($data_risk)) {

                            foreach ($data_risk as $valueRisk) {

                                $hazards = explode(',', $valueRisk['hazardsID']);

                                $primary_hazard = $valueRisk['hazardClassificationID'];

                                $hz_ids = array();
                                $all_child_hazards = $this->get_child_hazards($primary_hazard);

                                if (count($all_child_hazards)) {
                                    foreach ($all_child_hazards as $hz_id) {
                                        $hz_ids[] = $hz_id['ID'];
                                    }
                                }

                                $matching_hz_ids = array_intersect($hz_ids, $hazards);

                                /* if ( $primary_hazard == 7 ) {
                                  dump_array($hz_ids);
                                  dump_array($hazards);
                                  dump_array($matching_hz_ids);
                                  } */
                                //echo $primary_hazard.',';

                                if (( $primary_hazard == 11 ) || ( $primary_hazard == 11 && in_array(9, $hazards) ) || ( $primary_hazard == 3 && in_array(58, $hazards) ) || ( $primary_hazard == 7 && count($matching_hz_ids) )) {

                                    //$report_data[$Id: riskModReport.class.php,v 3.86 Friday, January 28, 2011 5:41:52 PM ehsindia Exp $valueProcess['reference'];
                                    //$process_id = $valueProcess['reference'];

                                    $sub_hzd = '';
                                    switch ($primary_hazard) {
                                        case 3 : $sub_hzd = 58;
                                            break;
                                        case 11 : $sub_hzd = 91;
                                            break;
                                        //case 11 : $sub_hzd = 9; break;
                                    }


                                    $report_data[$process_id]['description'] = ucfirst($valueProcess['description']);
                                    $report_data[$process_id]['ref'] = preg_replace('/PF/', 'PR', $valueProcess['reference']);

                                    $report_data[$process_id]['hazard'][] = $this->get_main_hazard($primary_hazard);
                                    if ($primary_hazard != 7) {
                                        $report_data[$process_id]['sub_hazard'][] = $sub_hzd == '' ? '-' : $this->get_hazards($sub_hzd);
                                    } else {
                                        //dump_array($hazards);
                                        $hazards_str = implode(',', $hazards);
                                        $report_data[$process_id]['sub_hazard'][] = $this->get_hazards($hazards_str);
                                    }

                                    $report_data[$process_id]['hazard_summary'][] = $valueRisk['hazardSummary'] == '' ? '-' : ucfirst($valueRisk['hazardSummary']);
                                    $report_data[$process_id]['control_summary'][] = $valueRisk['controlSummary'] == '' ? '-' : ucfirst($valueRisk['controlSummary']);
                                    $j++;
                                }
                            }
                        }
                        $id_val++;
                        //$id_value++;
                        $i++;
                    }
                } // end if
            }

            /* dump_array($report_data);
              exit; */
        }


        //ksort($report_data);

        $report_data['report_data'] = $report_data;
        //if ( $this->filters['type'] == 'html' ) {
        //	$report_data['report_type'] = 'html';
        //}
        //dump_array($report_data);

        return $report_data;
    }

    private function get_bu_name($p_bu_id) {

        $sql = "SELECT buName FROM %s.business_units WHERE buID = %d ";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);

        $pStatement->bindParam(1, $p_bu_id);
        $pStatement->execute();
        return $pStatement->fetchColumn();
    }

    private function get_main_hazard($p_hazard_id) {

        $hazards_id_arr = explode(',', $p_hazard_id);
        $sql = "SELECT primaryHazard FROM %s.hazard_parent_classification WHERE ID = %d ";

        if (count($hazards_id_arr)) {
            foreach ($hazards_id_arr as $value_id) {

                $sql_p = sprintf($sql, _DB_OBJ_FULL, $value_id);
                $pStatement = $this->dbHand->prepare($sql_p);
                //$pStatement->bindParam(1,$value_id);
                $pStatement->execute();
                $hazards .= $pStatement->fetchColumn() . ', ';
            }
        }
        return rtrim($hazards, ', ');
    }

    private function get_control_measures($p_control_id) {

        $control_id_arr = explode(',', $p_control_id);
        $sql = "SELECT hazardName FROM %s.control_measures_hazard WHERE ID = %d ";
        //$pStatement = $this->db_handle->prepare($sql);
        if (count($control_id_arr)) {
            foreach ($control_id_arr as $value_id) {

                $sql_p = sprintf($sql, _DB_OBJ_FULL, $value_id);
                $pStatement = $this->dbHand->prepare($sql_p);
                //$pStatement->bindParam(1,$value_id);
                $pStatement->execute();
                $control = $pStatement->fetchColumn();
                if ($control != '') {
                    $controls .= $control . ', ';
                }
            }
        }
        return rtrim($controls, ', ');
    }

    public function wordreportr5($id) {

        $this->id = $id;
        global $likelihood_arr;

        $sql = "SELECT * FROM %s.swimlane WHERE swimID = %d ";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql_p);
        //$pStatement->bindParam(1,$this->filters['id']);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($data)) {
            $risk_data = $data[0];
            $risk_data['bu_name'] = $this->get_bu_name($data[0]['buID']);

            //$sql2 = "SELECT * FROM %s.swimlane_data WHERE swimID = %d ";
            $sql2 = "SELECT * FROM %s.swimlane_data WHERE swimID = %d and [type] != 'D' order by altPathIndex, stepLevel,ID ASC";

            $sql2_p = sprintf($sql2, _DB_OBJ_FULL, $risk_data['swimID']);
            $pStatement2 = $this->dbHand->prepare($sql2_p);
            //$pStatement2->bindParam(1,$risk_data['swimID']);
            $pStatement2->execute();
            $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);


            if (count($data_steps)) {
                $i = 0;
                foreach ($data_steps as $value_step) {
                    $risk_data['steps'][$i]['id'] = $value_step['ID'];
                    $risk_data['steps'][$i]['desc'] = $value_step['descQues'];

                    $sql3 = "SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d ";

                    $sql3_p = sprintf($sql3, _DB_OBJ_FULL, $risk_data['swimID'], $value_step['ID']);
                    $pStatement3 = $this->dbHand->prepare($sql3_p);
                    /* $pStatement3->bindParam(1,$risk_data['swimID']);
                      $pStatement3->bindParam(2,$value_step['ID']); */
                    $pStatement3->execute();
                    $data_risk = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

                    $risk_data['steps'][$i]['assessmentDone'] = $value_step['assessmentDone'];
                    $risk_data['steps'][$i]['assessmentReason'] = $value_step['assessmentReason'];

                    if (count($data_risk)) {
                        $j = 0;
                        foreach ($data_risk as $value_risk) {
                            $risk_data['steps'][$i]['risk_assessment'][$j]['primary_hazard'] = $this->get_main_hazard($value_risk['hazardClassificationID']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['hazards'] = $this->get_hazards($value_risk['hazardsID']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['secondary_hazard'] = $this->get_main_hazard($value_risk['secondaryHazardID']);
                            $hazSymbols = substr($value_risk['hazardSymbols'], 0, -1);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['hazardSymbols'] = explode(',', $hazSymbols);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['hazardSummary'] = $value_risk['hazardSummary'];
                            //$risk_data['steps'][$i]['risk_assessment'][$j]['hazard_files'] = $this->get_uploaded_files($value_risk['ID'],'hazard');

                            $risk_data['steps'][$i]['risk_assessment'][$j]['control_source'] = $this->get_control_measures($value_risk['controlAtSource']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['control_path'] = $this->get_control_measures($value_risk['controlAlongPath']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['control_worker'] = $this->get_control_measures($value_risk['controlAtWorker']);
                            $controlSymbols = substr($value_risk['controlSymbols'], 0, -1);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['controlSymbols'] = explode(',', $controlSymbols);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['controlSummary'] = $value_risk['controlSummary'];
                            //$risk_data['steps'][$i]['risk_assessment'][$j]['control_files'] = $this->get_uploaded_files($value_risk['ID'],'control');

                            $risk_data['steps'][$i]['risk_assessment'][$j]['likelihood1'] = $likelihood_arr[$value_risk['likelihood1']];
                            //$risk_data['steps'][$i]['risk_assessment'][$j]['impact1'] = $this->get_impact($value_risk['impact1']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['riskRating1'] = $value_risk['riskRating1'];
                            $risk_data['steps'][$i]['risk_assessment'][$j]['riskRatingColor1'] = $value_risk['riskRatingColor1'];

                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvementAtSource'] = $this->get_control_measures($value_risk['improvementAtSource']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvementAlongPath'] = $this->get_control_measures($value_risk['improvementAlongPath']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvementAtWorker'] = $this->get_control_measures($value_risk['improvementAtWorker']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['noImprovement'] = $value_risk['noImprovement'];
                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvementReason'] = $value_risk['improvementReason'];

                            $actions = $this->get_improvement_actions($value_risk['improvements']);
                            $improvements_new_risk_priority = '';
                            $improvements = "";
                            if (count($actions)) {
                                foreach ($actions as $value) {
                                    $improvements .= $value['actionDescription'] . '<br/>';
                                    if (strlen($value['actionDescription']) > 50) {
                                        $improvements_new_risk_priority[] = ucfirst(substr($value['actionDescription'], 0, 50) . '..');
                                    } else {
                                        $improvements_new_risk_priority[] = ucfirst($value['actionDescription']);
                                    }
                                }
                            }

                            $likelihood2_arr = '';
                            $likelihood2 = explode(',', $value_risk['likelihood2']);
                            if (count($likelihood2)) {
                                foreach ($likelihood2 as $valLklhd) {
                                    $likelihood2_arr[] = $likelihood_arr[$valLklhd];
                                }
                            }

                            $time_arr = '';
                            $time = explode(',', $value_risk['timeTrouble']);
                            if (count($time)) {
                                foreach ($time as $valTime) {
                                    $time_arr[] = $likelihood_arr[$valTime];
                                }
                            }

                            $impact_arr = '';
                            $impact2 = explode(',', $value_risk['impact2']);
                            if (count($impact2)) {
                                foreach ($impact2 as $valimpact) {
                                    //$impact_arr[] = $this->get_impact($valimpact);
                                }
                            }

                            $net_arr = '';
                            $net = explode(',', $value_risk['netImpact']);
                            if (count($net)) {
                                foreach ($net as $valnet) {
                                    //$net_arr[] = $this->get_net_impact($valnet);
                                }
                            }

                            //dump_array($net_arr);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvements'] = $improvements;
                            $risk_data['steps'][$i]['risk_assessment'][$j]['actions'] = $actions;

                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvements_new'] = $improvements_new_risk_priority;
                            $risk_data['steps'][$i]['risk_assessment'][$j]['improvements_new_count'] = count($improvements_new_risk_priority);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['likelihood2'] = $likelihood2_arr;
                            $risk_data['steps'][$i]['risk_assessment'][$j]['impact2'] = $impact_arr;
                            $risk_data['steps'][$i]['risk_assessment'][$j]['riskRating2'] = explode(',', $value_risk['riskRating2']);
                            $risk_data['steps'][$i]['risk_assessment'][$j]['riskRatingColor2'] = explode(',', $value_risk['riskRatingColor2']);

                            $risk_data['steps'][$i]['risk_assessment'][$j]['timeTrouble'] = $time_arr;
                            $risk_data['steps'][$i]['risk_assessment'][$j]['netImpact'] = $net_arr;
                            $risk_data['steps'][$i]['risk_assessment'][$j]['priority'] = explode(',', $value_risk['priority']);

                            //$this->get_main_hazard(32);
                            $j++;
                        }
                    }

                    $i++;
                }
            }
            //dump_array($risk_data);
        }

        return $risk_data;
    }

    public function uploadDefault($record_id, $default) {

        $sql = "SELECT * FROM %s.risk_defaults WHERE ID = %d ";

        $psql = sprintf($sql, _DB_OBJ_FULL, $default);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $ins = sprintf("Update %s.risk set 
        controlAlongPath='%s',
        controlAtWorker='%s',
        controlSummary='%s',
        improvements='%s',
        likelihood1='%s',
        impact1='%s',
        improvementAtSource='%s',
        improvementAlongPath='%s',
        improvementAtWorker='%s',
        likelihood2='%s',
        impact2='%s',
        timeTrouble='%s',
        netImpact='%s',
        improvement_d='%s'  
where ID=%s		", _DB_OBJ_FULL, $result['controlAtSource'], $result['controlAtWorker'], $result['controlSummary'], $result['improvements'], $result['likelihood1'], $result['impact1'], $result['improvementAtSource'], $result['improvementAlongPath'], $result['improvementAtWorker'], $result['likelihood2'], $result['impact2'], $result['timeTrouble'], $result['netImpact'], $result['improvements'], $record_id
        );

        $stmt = $this->dbHand->prepare($ins);
        $stmt->execute();

        $this->actionData = array('module_name' => 'risk', 'description' => '', 'who' => 0, 'due_date' => '01/01/1900');
        $this->actionHandling->setActionDetails(0, $this->actionData);
        $improvements = $this->actionHandling->addAction();

        $sql = sprintf("UPDATE %s.risk SET improvements = '%s' WHERE ID = %d ", _DB_OBJ_FULL, $improvements, $record_id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }
     public function manageCia() {
 
if (is_array($this->RiskInfo['threat']))
    $threat=implode(",",$this->RiskInfo['threat']);
else
    $threat='';

if (is_array($this->RiskInfo['vuln']))
    $vuln=implode(",",$this->RiskInfo['vuln']);
else
    $vuln='';
        $sql = sprintf("UPDATE %s.risk SET ciaConfidentiality = %d ,
						ciaIntegrity = %d,
						ciaAvailability = %d,
						threats = '%s',
						vulnerability= '%s',
						threat_Comment = '%s',
						vuln_comment = '%s'
						WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->RiskInfo['cia_confidentiality']
                , $this->RiskInfo['cia_integrity']
                , $this->RiskInfo['cia_availability']
				, $threat
				, $vuln
				, $this->RiskInfo['t_comment']
				, $this->RiskInfo['v_comment']
                , $this->RiskId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
}
        public function displayThreats() {


        $sql = "SELECT * FROM %s.hazard_classification WHERE CIA_Required = 1 ORDER BY CAST([secondaryhazard] AS VARCHAR(8000)) ASC";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
    
            public function displayVuln() {


   
$sql = "SELECT * FROM %s.asset_vulnerability where isnull(archive,0)=0 ORDER BY CAST([vulnerability] AS VARCHAR(8000)) ASC ";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
    
                    public function get_vuln($ids) {


   
$sql = "SELECT * FROM %s.asset_vulnerability where id in (%s)";
    $psql = sprintf($sql, _DB_OBJ_FULL,$ids);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
$v='';
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
foreach($result as $row){
	
	$v .= $row["vulnerability"].", ";
}
        return trim($v,", ");
    }

            public function get_threats($ids) {


        $sql = "SELECT * FROM %s.hazard_classification WHERE id in (%s)";

        $psql = sprintf($sql, _DB_OBJ_FULL,$ids);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

   $t='';
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
	$t .= $row["secondaryHazard"].", ";
}

        return trim($t,", ");
    }
        private function get_impact($p_impact_id) {
$i='"';
if(is_null($p_impact_id))
    return '';
        $sql = "SELECT name FROM %s.impact_measure WHERE ID in (%s) ";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_impact_id);
        $pStatement = $this->dbHand->prepare($sql_p);

        //$pStatement->bindParam(1,$p_impact_id);
        $pStatement->execute();
         $result =$pStatement->fetchAll(PDO::FETCH_ASSOC);
         if(is_array($result)){
         foreach($result as $row){
	$i .= $row["name"].", ";
}
         }
         $iret = trim($i,", ").'"';
          
        return $iret;
    }
         


    private function get_net_impact($p_impact_id) {

        $sql = "SELECT description FROM %s.net_impact_options WHERE ID = %d ";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_impact_id);
        $pStatement = $this->dbHand->prepare($sql_p);

        //$pStatement->bindParam(1,$p_impact_id);
        $pStatement->execute();
        return $pStatement->fetchColumn();
    }
        private function get_location_name($p_loc_id) {

        $sql = "SELECT name FROM %s.locationgram WHERE locID = %d ";
      $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_loc_id);
        $pStatement = $this->dbHand->prepare($sql_p);

        $pStatement->execute();
        return $pStatement->fetchColumn();
}
}

?>