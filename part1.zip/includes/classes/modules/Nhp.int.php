<?php
 /**
  $Id: Nhp.int.php,v 3.05 Monday, November 08, 2010 9:51:54 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Nhp object
  *
  * This Nhp will declare the various methods performed
  * by Nhp object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 8:11:58 PM>
  */

interface Nhp
{
	/*
	 * This method is used to set Nhp information for the respective object
	 */
	public function setNhpInfo($p_NhpId,$p_NhpInfo);

	/*
	 * This method is used to add new Nhp
	 */
	public function addNhp();

	/*
	 * This method is used to edit Nhp record
	 */
	public function editNhp();

	/*
	 * This method is used to delete Nhp record
	 */
	public function deleteNhp();

	/*
	 * This method is used to archive Nhp record
	 */
	public function archiveNhp();

	/*
	 * This method is used to completely delete Nhp record
	 */
	public function purgeNhp();

}
