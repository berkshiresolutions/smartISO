<?php
 /**
  $Id: Contractor.int.php,v 3.07 Friday, October 08, 2010 1:15:54 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Contractor object
  *
  * This interface will declare the various methods performed
  * by the contractor object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface ContractInterface
{
	/*
	 * to set contractor information for performing various operations with the Contractor object
	 */
	public function setContractInfo($p_contractorId,$p_currentTab,$p_contractorInfo);

	/*
	 * This method is used to add a new contractor
	 */
	public function addContract();

	/*
	 * This method is used to view the contractor information.
	 */
	public function viewContract();

	/*
	 * This method is used to edit the contractor
	 */
	public function editContract();

	/*
	 * This method is used to delete the contractor
	 */
	public function deleteContract();

	/*
	 * This method is used to archive the contractor
	 */
	public function archiveContract();

	/*
	 * This method is used to remove the contractor
	 */
	public function purgeContract();
	
	/*
	 *  This method is used to retrieve contract based on short term Tender or Tender and contractor id
	 */
	
	public function getContracts($isShortTerm , $contractorId);
	
	
	/*
	 *  This method is used to retrieve contract based on short term Tender or Tender 
	*/
	
	public function getAllContracts($isShortTermOrTender);

}