<?php
/**
  $Id: ActionTracker.class.php,v 4.29 Monday, May 01, 2018 4:40:01 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Interface to manage Organigram object
 *
 * This interface will declare the various methods performed
 * by organigram object for operations like add, edit, delete, archive, purge.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Interface
 * @since  Thursday, September 09, 2010 6:29:33 PM>
 */

require_once(_MYCLASSES . '/graph/GraphModuleData.int.php');
require_once(_MYCLASSES . '/graph/GraphData.abs.php');
class DashboardModulesCompleteAction extends DashboardParent {
     /**
     * Constructor for initializing Action Tracker object
     * @access public
     */
    public $filter_query, $filters, $data_set;

    public function __construct() {
        $this->data_format = new GraphData();
        parent::__construct();
    }

    public function getContractReviewsActions() {

        $selected_bu=$this->filter['selected_bu'];
        $bu_list = $this->getAllBUs();
        $data_stat_type = strip_tags($_GET['data_stat_type']);
        
        
        $fdty = new DateTime(date('Y-m-d'));
        $fdty->modify('First day of January');
        $fdtq = date('Y').'-'.((ceil(date('m')/3)*3)-2).'-01'; 
        $module_name = 'Contract Reviews';
        $quartersCoveredG = array(); 
        $times = array(
                'Q'=>array(
                        date('Y-m-d'),//date('Y-m',strtotime($fdtq)).'-01',
                        date('Y-m',strtotime('+3 Months',strtotime($fdtq))).'-01',
                        date('Y-m',strtotime('+6 Months',strtotime($fdtq))).'-01',
                        date('Y-m',strtotime('+9 Months',strtotime($fdtq))).'-01'
                ),
                'M'=>array(
                        date('Y-m-d'),
                        date('Y-m-d',strtotime('+1 Months',strtotime('this month'))),
                        date('Y-m-d',strtotime('+2 Months',strtotime('this month'))),
                        date('Y-m-d',strtotime('+3 Months',strtotime('this month')))
                ),
                'W'=>array(
                        date('Y-m-d'),
                        date('Y-m-d',strtotime('+1 Week',strtotime('this week'))),
                        date('Y-m-d',strtotime('+2 Weeks',strtotime('this week'))),
                        date('Y-m-d',strtotime('+3 Weeks',strtotime('this week')))
                ),
        );
        
        
        
        

        $contractObj = new Contract();       

        if ($selected_bu) {
            $BUs = si_getAllBUs($selected_bu, _DB_OBJ_FULL, 10);
            $selected_bu = implode(',', $BUs);
        }
       
        $records = array(
            $contractObj->getActiveContractsInBuID($times[$data_stat_type][0], $selected_bu, $data_stat_type),
            $contractObj->getActiveContractsInBuID($times[$data_stat_type][1], $selected_bu, $data_stat_type),
            $contractObj->getActiveContractsInBuID($times[$data_stat_type][2], $selected_bu, $data_stat_type),
            $contractObj->getActiveContractsInBuID($times[$data_stat_type][3], $selected_bu, $data_stat_type)
        );
        $periodArr = array('Q' => 'qq', 'M' => 'mm', 'W' => 'ww');
        $thisperiodArr = array('Q' => $quarter, 'M' => $month, 'W' => $week);
        $thisAddHelperArr = array(
            'Q' => array('M', 3),
            'M' => array('M', 1),
            'W' => array('W', 1)
        );

        $grid_data = array(
            'q1' => array(
                'A' => 0,
                'D' => 0,
                'P' => 0,
            ), 'q2' => array(
                'A' => 0,
                'D' => 0,
                'P' => 0,
            ), 'q3' => array(
                'A' => 0,
                'D' => 0,
                'P' => 0,
            ), 'q4' => array(
                'A' => 0,
                'D' => 0,
                'P' => 0,
            ), 'q5' => array(
                'A' => 0,
                'D' => 0,
                'P' => 0,
            ), 'q6' => array(
                'A' => 0,
                'D' => 0,
                'P' => 0,
            ),
        );


        $processedReviews = array();
        for ($z = 0; $z < 4; $z++) {           
            $endTmp = new DateTime($times[$data_stat_type][$z]);
            $endTmp->add(new DateInterval('P' . $thisAddHelperArr[$data_stat_type][1] . $thisAddHelperArr[$data_stat_type][0]))->sub(new DateInterval('P1D'));
           
            $quarterBegin = $contractObj->getquarter(
                    date('Y', strtotime($times[$data_stat_type][$z])), date('m', strtotime($times[$data_stat_type][$z])), date('d', strtotime($times[$data_stat_type][$z]))
            );

            $quarterEnd = $contractObj->getquarter(
                    date('Y', strtotime($endTmp->format('Y-m-d'))), date('m', strtotime($endTmp->format('Y-m-d'))), date('d', strtotime($endTmp->format('Y-m-d')))
            ); 

            $morethanonequarter = ($quarterEnd['quarter'] != $quarterBegin['quarter']);
            if ($morethanonequarter) { // MORE THAN ONE QUARTER COVERED
                $beginExists = (array_key_exists($quarterBegin['quarter'] . '-' . $quarterBegin['year'], $quartersCoveredG));
                $endExists = (array_key_exists($quarterEnd['quarter'] . '-' . $quarterEnd['year'], $quartersCoveredG));
                if ($beginExists && $endExists) { // IF BOTH SET SKIP
                    continue;
                } else {
                    if (!$beginExists) {
                        $quartersCoveredG[$quarterBegin['quarter'] . '-' . $quarterBegin['year']] = $blocks[$data_stat_type]['q' . ($z + 1)];
                    }
                    if (!$endExists) {
                        $quartersCoveredG[$quarterBegin['quarter'] . '-' . $quarterEnd['year']] = $blocks[$data_stat_type]['q' . ($z + 1)];
                    }
                }
            } else { // ONE QUARTER COVERED
                if (!array_key_exists($quarterEnd['quarter'] . '-' . $quarterEnd['year'], $quartersCoveredG)) {
                    $quartersCoveredG[$quarterEnd['quarter'] . '-' . $quarterEnd['year']] = $blocks[$data_stat_type]['q' . ($z + 1)];
                } else {
                    continue;
                }
            }
           
            foreach ($records[$z] as $record) {
                $recordStart = new DateTime($record['startDate']);
                $fdrqStartDate = new DateTime($recordStart->format('Y') . '-' . ((ceil($recordStart->format('m') / 3) * 3) - 2) . '-01'); // first day of this quarter
                $offset = $recordStart->diff($fdrqStartDate, true)->format('%a');

                $dueDateTmp = new DateTime($times[$data_stat_type][$z]);
                $fdtqStartDate = new DateTime($dueDateTmp->format('Y') . '-' . ((ceil($dueDateTmp->format('m') / 3) * 3) - 2) . '-01'); // first day of this quarter
                $reviewDueDate = $fdtqStartDate->add(new DateInterval('P' . $offset . 'D'))->format('Y-m-d');

                  $status = array();
                if ($morethanonequarter) {
                    $status1 = $contractObj->contractReviewStatus($record['ID'], $quarterBegin['quarter'], $quarterBegin['year'], ($quarterBegin['quarter'] < 4 ? 1 : 2));
                    $status2 = $contractObj->contractReviewStatus($record['ID'], $quarterEnd['quarter'], $quarterEnd['year'], ($quarterEnd['quarter'] < 4 ? 1 : 2));

                    if (!$status1)
                        $status1 = array();
                    if (!$status2)
                        $status2 = array();
                    $status = array_merge($status1, $status2);
                } else {
                    $status = $contractObj->contractReviewStatus($record['ID'], $quarterBegin['quarter'], $quarterBegin['year'], ($quarterBegin['quarter'] < 4 ? 1 : 2));
                }

                // hack and slash horror
                if ((is_array(current($status)) && ( array_key_exists('status', current($status)) ))) { // more than one review for quarter
                    $status = current($status);
                } // we only want the latest contract review following the logic that a valid one would not have an invalid one carried out after the fact within the same month

                if (array_key_exists('status', $status)) { // one review for quarter
                    if (!array_key_exists($record['ID'] . $reviewDueDate, $processedReviews)) { // do not count the same review twice
                        $processedReviews[$record['ID'] . $reviewDueDate] = true;

                        if (($status['status'] == 'Done') && ($z == 0)) { // we can only be done in the present not the future
                            $grid_data['q5']['D'] ++;
                            $grid_data['q1']['D'] ++; // We can only ever be done for quarter 1 ( .($i+1) ) concat removed
                        } else {
                            echo 'q' . (1 + $z) . "<br/>";
                            $grid_data['q6']['P'] ++;
                            $grid_data['q' . (1 + $z)]['P'] ++;
                        }
                    }
                } else { // review does not exist
                    if (!array_key_exists($record['ID'] . $reviewDueDate, $processedReviews)) { // do not count the same review twice
                        $processedReviews[$record['ID'] . $reviewDueDate] = true;
                        if ($z > 0) {
                            $grid_data['q5']['P'] ++;
                            $grid_data['q' . (1 + $z)]['P'] ++;
                        } else {
                            // Fix as Items can only be overdue after they are due for review...
                            if (strtotime($reviewDueDate) > strtotime($times[$data_stat_type][$z])) {
                                $grid_data['q5']['P'] ++;
                                $grid_data['q' . (1 + $z)]['P'] ++;
                            } else {
                                $grid_data['q6']['A'] ++; // OVERDUE
                            }
                            /*
                              $grid_data['q1']['D']++; // DONE (THIS)
                              $grid_data['q5']['D']++; // DONE (OVERALL)
                             */
                        }
                    }
                }
                /*
                  echo $record['ID']." { <br/>";
                  echo "\t".$status['status']."<br>";
                  echo "}<br>";
                 */
            }
            //$data_stat_type;
        }

// NOW DEAL WITH PAST OVERDUE DATES
        $dateBack = new DateTime(/* $times[$data_stat_type][0] */$fdtq);
        $dateBack->sub(new DateInterval('P3M')); //.$thisAddHelperArr[$data_stat_type][1].$thisAddHelperArr[$data_stat_type][0]) ); // take off 3 months to get to last quarter as 12/4 = 3
//echo $dateBack->format('Y-m-d');
        $lastQuarter = $contractObj->getquarter(
                date('Y', strtotime($dateBack->format('Y-m-d'))), date('m', strtotime($dateBack->format('Y-m-d'))), date('d', strtotime($dateBack->format('Y-m-d')))
        );
        if (!array_key_exists($lastQuarter['quarter'] . '-' . $lastQuarter['year'], $quartersCoveredG)) {
            $quartersCoveredG[$lastQuarter['quarter'] . '-' . $lastQuarter['year']] = 'lastQ';

            $lastMonthsContracts = $contractObj->getActiveContractsInBuID($dateBack->format('Y-m-d'), $selected_bu, $data_stat_type);
            foreach ($lastMonthsContracts as $contract) {
                //echo $lastQuarter['quarter'].','.$lastQuarter['year'].$contract['ID']."<br>";
                //var_dump($contract);
                $reviewStart = new DateTime($contract['startDate']);
                $fdrqStartDate = new DateTime($reviewStart->format('Y') . '-' . ((ceil($reviewStart->format('m') / 3) * 3) - 2) . '-01'); // first day of this quarter
                $offset = $reviewStart->diff($fdrqStartDate, true)->format('%a');

                $dueDateTmp = new DateTime($times[$data_stat_type][$z]);
                $fdtqStartDate = new DateTime($dueDateTmp->format('Y') . '-' . ((ceil($dueDateTmp->format('m') / 3) * 3) - 2) . '-01'); // first day of this quarter
                $reviewDueDate = $fdtqStartDate->add(new DateInterval('P' . $offset . 'D'))->format('Y-m-d');

                $pastReview = $contractObj->contractReviewStatus($contract['ID'], $lastQuarter['quarter'], $lastQuarter['year'], ($lastQuarter < 4 ? 1 : 2));
                // hack and slash horror
                if ((is_array($pastReview) && ( array_key_exists('status', current($pastReview)) ))) { // more than one review for quarter
                    $pastReview = current($pastReview);
                } // we only want the latest contract review following the logic that a valid one would not have an invalid one carried out after the fact within the same month
                if (!$pastReview)
                    $pastReview = array();
                if (array_key_exists('status', $pastReview)) { // one review for quarter
                    $contract['ID'] . " exists with status:" . $contract['status'] . "<br>";
                    if (!array_key_exists($contract['ID'] . $reviewDueDate, $processedReviews)) { // do not count the same review twice
                        $processedReviews[$contract['ID'] . $reviewDueDate] = true;

                        if (($status['status'] != 'Done')) { // we can only be done in the present not the future
                            $grid_data['q6']['A'] ++; // OVERDUE
                        }
                    }
                } else { // review does not exist
                    $processedReviews[$contract['ID'] . $reviewDueDate] = true;
                    $grid_data['q6']['A'] ++; // OVERDUE
                    /* } else {
                      echo "Processed Already!<br>";
                      } */
                }
            }
        }
        
        return $grid_data;
        
    }

    public function get_percentage($percentage, $of)
    {   
        if ($of != 0)
        $percent = $percentage / $of;
        else
        $percent =0;
        return  number_format( $percent * 100, 2 ) . '%';;
       
    }
    
    public function getGraphData() {

        $bu_list = array();
        $hlist = array();
        $dlist = array();

        $q1_sr = $this->qtrsRange['q1_sr'];
        $q1_er = $this->qtrsRange['q1_er'];
        $q2_sr = $this->qtrsRange['q2_sr'];
        $q2_er = $this->qtrsRange['q2_er'];
        $q3_sr = $this->qtrsRange['q3_sr'];
        $q3_er = $this->qtrsRange['q3_er'];
        $q4_sr = $this->qtrsRange['q4_sr'];
        $q4_er = $this->qtrsRange['q4_er'];
        $q5_sr = $this->qtrsRange['q5_sr'];
        $q5_er = $this->qtrsRange['q5_er'];
        $cqtr = $this->qtrsRange['cqtr'];


        $data_stat_type = strip_tags($_GET['data_stat_type']);

        $module_name = 'Contract';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $contract_data = $dashObj->getData();        
        $total_contract_done = $contract_data['q5']['D'];
        $total_contract_p = $contract_data['q5']['P'];
        $total_contract = $contract_data['q6']['A']+$total_contract_p+$total_contract_done;
        
        
        $module_name = 'Contract';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $contract_data = $dashObj->getData();        
        $total_contract_done = $contract_data['q5']['D'];
        $total_contract_p = $contract_data['q5']['P'];
        $total_contract = $contract_data['q6']['A']+$total_contract_p+$total_contract_done;

        
       
        
        $contract_reviews=$this->getContractReviewsActions();
        $total_contract_reviews_done = $contract_reviews['q6']['D'];
        $total_contract_reviews_p = $contract_reviews['q6']['P'];
        $total_contract_reviews = $contract_data['q6']['A']+$total_contract_reviews_p+$total_contract_reviews_done;
        
        
        
        $module_name2 = 'EquipmentC';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name2);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $equipmentC_data = $dashObj->getData();        
        $total_equipmentC_done = $equipmentC_data['q5']['D'];
        $total_equipmentC_p = $equipmentC_data['q5']['P'];
        $total_equipmentC = $equipmentC_data['q6']['A']+$total_equipmentC_p+$total_equipmentC_done;
        
     
        
        $module_name3 = 'EquipmentM';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name3);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $equipmentM_data = $dashObj->getData();        
        $total_equipmentM_done = $equipmentM_data['q5']['D'];
        $total_equipmentM_p = $equipmentM_data['q5']['P'];
        $total_equipmentM = $equipmentM_data['q6']['A']+$total_equipmentM_p+$total_equipmentM_done;
        
        
        
        $module_name4 = 'context';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name4);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $context_data = $dashObj->getData();        
        $total_context_done = $context_data['q5']['D'];
        $total_context_p = $context_data['q5']['P'];
        $total_context = $context_data['q6']['A']+$total_context_p+$total_context_done;
        
       
        $module_name4 = 'DSE';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name4);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $DSE_data = $dashObj->getData();        
        $total_DSE_done = $DSE_data['q5']['D'];
        $total_DSE_p = $DSE_data['q5']['P'];
        $total_DSE = $DSE_data['q6']['A']+$total_DSE_p+$total_DSE_done;
        
        
        
        $module_name5 = 'load';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name5);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $load_data = $dashObj->getData();        
        $total_load_done = $load_data['q5']['D'];
        $total_load_p = $load_data['q5']['P'];
        $total_load = $load_data['q6']['A']+$total_load_p+$total_load_done;
        
        
        $module_name6 = 'task';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name6);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $task_data = $dashObj->getData();        
        $total_task_done = $task_data['q5']['D'];
        $total_task_p = $task_data['q5']['P'];
        $total_task = $task_data['q6']['A']+$total_task_p+$total_task_done;
       
        
        $module_name7 = 'service';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name7);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $service_data = $dashObj->getData();        
        $total_service_done = $service_data['q5']['D'];
        $total_service_p = $service_data['q5']['P'];
        $total_service = $service_data['q6']['A']+$total_service_p+$total_service_done;
       
        $module_name8 = 'Individual';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name8);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $individual_data = $dashObj->getData();        
        $total_individual_done = $individual['q5']['D'];
        $total_individual_p = $individual['q5']['P'];
        $total_individual = $individual['q6']['A']+$total_individual_p+$total_individual_done;
      
        $module_name9 = 'Ins';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name9);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $ins_data = $dashObj->getData();        
        $total_ins_done = $ins_data['q5']['D'];
        $total_ins_p = $ins_data['q5']['P'];
        $total_ins = $ins_data['q6']['A']+$total_individual_p+$total_individual_done;
       
        
        $module_name10 = 'Environment';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name10);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $environment_data = $dashObj->getData();        
        $total_environment_done = $environment_data['q5']['D'];
        $total_environment_p = $environment_data['q5']['P'];
        $total_environment = $environment_data['q6']['A']+$total_environment_p+$total_environment_done;
      
        $module_name11 = 'Man';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name11);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $man_data = $dashObj->getData();        
        $total_man_done = $man_data['q5']['D'];
        $total_man_p = $man_data['q5']['P'];
        $total_man = $man_data['q6']['A']+$total_man_p+$total_man_done;
      
        
        
        

        $contract_percentage =$this->get_percentage($total_contract_done,$total_contract);
        $contract_reviews =$this->get_percentage($total_contract_reviews_done,$total_contract_reviews);
        $equipmentC_percentage =$this->get_percentage($total_equipmentC_done,$total_equipmentC);
        $equipmentM_percentage =$this->get_percentage($total_equipmentM_done,$total_equipmentM);
        $context_percentage =$this->get_percentage($total_context_done,$total_context);
        $DSE_percentage =$this->get_percentage($total_DSE_done,$total_DSE);
        $load_percentage =$this->get_percentage($total_load_done,$total_load);
        $task_percentage =$this->get_percentage($total_task_done,$total_task);
        $service_percentage =$this->get_percentage($total_service_data_done,$total_service);
        $individual_percentage =$this->get_percentage($total_individual_done,$total_individual);
        $ins_percentage =$this->get_percentage($total_ins_done,$total_ins);
        $environment_percentage =$this->get_percentage($total_environment_done,$total_environment);
        $man_percentage =$this->get_percentage($total_man_done,$total_man);
       
        
        
        $this->data_format->addData('Contract', $contract_percentage);        
        $this->data_format->addData('Contract Reviews', $contract_reviews);
        $this->data_format->addData('Equipment Calibration', $equipmentC_percentage);
        $this->data_format->addData('Equipment Maintenance', $equipmentM_percentage);
        $this->data_format->addData('Context', $context_percentage);
        $this->data_format->addData('DSE', $DSE_percentage);
        $this->data_format->addData('Manual Handling', $load_percentage);
        $this->data_format->addData('Task', $task_percentage);
        $this->data_format->addData('smart Fleet - Service', $service_percentage);
        $this->data_format->addData('Individual', $individual_percentage);
        $this->data_format->addData('smart Fleet - Inspection', $ins_percentage);
        $this->data_format->addData('Environment', $environment_percentage);
        $this->data_format->addData('Library Manager', $man_percentage);
        
        $this->data_format->getGraphData();

        $this->data_set['chart_data'][] = $this->data_format->graph_data;
        $this->data_set['heading'] = 'Module Completed Action';
        $this->data_set['xaxis_text'] = "Actions";
        $this->data_set['yaxis_text'] = "% age  of Completed Action";       
        return $this->data_set;
        
    }

}
