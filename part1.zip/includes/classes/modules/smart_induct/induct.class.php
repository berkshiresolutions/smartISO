<?php

/*
 * CORE INCLUDES
 */
 error_reporting(E_ERROR | E_PARSE);
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/functions.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/Db.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/Session.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/Action.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/Documents.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/ProcessFlowMaster.class.php';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/Setup.class.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/setup/TrainingCourseSetup.class.php';
error_reporting(E_ERROR | E_PARSE);
class Induct {
	
	const NEED_TRAIN = 'Acknowledged needs training in ';
	const CERT_REQ = 'Requires certificate for ';
    /*
     * This is a SMART-INDUCT Method designed to retrieve a specific action for a 
     * user (we use these for R&U) for the docs, process flows and process risk
     * area is nesecarry to ensure that R&U for Process-Flows do not spill over to
     * Process-Risk or Documents or Vica Versa
     */
    public static function getInductActionForUserByArea($area,$rsrcID,$user_id=null) {
        $rsrc_len = strlen($rsrcID."");
        $area_len = strlen($area."");
        //echo "Area Length: ".$area_len.", $area<br>";
        //echo "RSRC Length: ".$rsrc_len.", $rsrcID<br>";
        if($user_id == null) { // We may wish to provision for participants of certain 
                               // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }
         
		$dbHand = DB::connect(_DB_TYPE);

        // AS WE STORE THE ID OF THE ELEMENT REFERENCED SERIALIZED BY DELIMITER :|: 
        // IN THE ARRAY, WE NEED TO RETRIEVE THE PORTION OF THE STRING THAT CONTAINS 
        // THE RESOURCE ID.
        $sql = sprintf(
            " SELECT ID, moduleName , actionDescription , who , whoAU , ".
            "dueDate , approve , outstanding , status , approveAU, doneDate ".
            " FROM %s.actions WHERE moduleName = 'INDUCT' ".
            " AND who = %d ".
            " AND ( LEFT( CAST(actionDescription as varchar(100) ), %d ) = '%s' ".
            " AND RIGHT( CAST(actionDescription as varchar(100) ), %d ) = '%d' ) "
            ,_DB_OBJ_FULL
            ,$user_id
            ,$area_len
            ,$area
            ,$rsrc_len
            ,$rsrcID
        );
        //echo $sql."<br>";
        $stmt = $dbHand->prepare( $sql );
        $stmt->execute();

        if($stmt->errorCode() == 0) {
            $ret = $stmt->fetchAll(PDO::FETCH_ASSOC);
            //echo "<pre>".var_export($ret,true)."</pre>";
            return $ret;
        } else {
            //echo "<pre>Error!\r\n".var_export($stmt->errorInfo(),true)."</pre>";
            return array();
        }
    }

    /*
     * This is a SMART-INDUCT Method designed to retrieve all actions for a given 
     * user (we use these for R&U) for the docs, process flows and process risk
     */
    public static function getInductActionsForUserByArea($area,$user_id=null) {
        $area_len = strlen($area."");
        if($user_id == null) { // We may wish to provision for participants of certain 
                               // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }
        
		$dbHand = DB::connect(_DB_TYPE);

        // AS WE STORE THE ID OF THE ELEMENT REFERENCED SERIALIZED BY DELIMITER :|: 
        // IN THE ARRAY, WE NEED TO RETRIEVE THE PORTION OF THE STRING THAT CONTAINS 
        // THE RESOURCE ID.
        $stmt = $dbHand->prepare( 
            sprintf(
                " SELECT ID, moduleName , actionDescription , who , whoAU ".
                ", dueDate , approve , outstanding , status , approveAU, doneDate ".
                " FROM %s.actions WHERE moduleName = 'INDUCT' ".
                " AND who = %d AND LEFT( CAST(actionDescription as varchar(100) ), %d) = '%s' "
                ,_DB_OBJ_FULL
                ,$user_id
                ,$area_len
                ,$area
            ) 
        );
        $stmt->execute();

        if($stmt->errorCode() == 0) {
            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } else {
            return array();//var_dump($stmt->errorInfo());
        }
    }


    /*
     * This is a SMART-INDUCT Method designed to update a new RandU record for Docs, PF's and PR's
     */
    public static function setInductRandUForUser($area,$rsrcID,$user_id=null) {
        $rsrc_len = strlen($rsrcID."");
        $area_len = strlen($area."");
        if($user_id == null) { // We may wish to provision for participants of certain 
                               // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }

        // now lets check for existing
        $results = self::getInductActionForUserByArea($area,$rsrcID,$user_id);

        $acDBid = 0; // needed to store actions dbid
        $acDesc = '';
        // if not we create
        if( count($results) <= 0) { // some db systems return 0 & some return -1
            $acDBid = self::createRandUForUser($area,$rsrcID,$user_id); // returned on create
            $results = self::getInductActionForUserByArea($area,$rsrcID,$user_id);
        } else { $acDBid = (int)$results[0]['ID']; }
        $date = ( ($results[0]['doneDate'] != '1900-01-01') && ($results[0]['doneDate'] != NULL) ) ? '01/01/1900' : date('d/m/Y');
        // now we set RandU

        // create temporary action object
        $actionTMP = new Action();

        // update action
        $actionData = array(
            'description'=>$results[0]['actionDescription']
            ,'who'=>$user_id
            ,'done_date'=>$date
            ,'outstanding'=>($results['doneDate'] == '01/01/1900' ? 1 : 0)// very important can only be set on update (we modified code to add this & outstanding)
        );
        $actionTMP->setActionDetails((int)$acDBid, $actionData);
        $action_id = $actionTMP->updateActionWithDoneOutstanding();
        return $action_id;
    }

    /*
     * This is a SMART-INDUCT Method designed to create a new RandU record for Docs, PF's and PR's
     */
    public static function createRandUForUser($area,$rsrcID,$user_id=null) {
        $rsrc_len = strlen($rsrcID."");
        $area_len = strlen($area."");

        $descStr = self::genItemDescStr($area,$rsrcID);
        if($descStr == "") { //empty description is invalid
            errorOut("This is an invalid $area object");
        }
        $actionDesc = "$area:|:$descStr:|:$rsrcID";

        if($user_id == null) { // We may wish to provision for participants of certain 
                             // levels setting R&U for other participants
            $user_id = Session::getSessionField('SESS_USER_REC_ID');
        }

        // create temporary action object
        $actionTMP = new Action();
        $actionData = array(
            'module_name'=>'INDUCT'
            ,'description'=>$actionDesc
            ,'who'=>$user_id // actually this is known in smart as a Participant
            ,'due_date'=>'01/01/1900'
        );
        $actionTMP->setActionDetails(0,$actionData);
        $action_id = $actionTMP->addAction(/* true */); //Physical Act of Adding an Action
        return $action_id;
    }

    /*
     * Generates a description of the resource using the area
     */
    public static function genItemDescStr($area,$rsrcID) {

        $descStr = '';
        //echo $area." Generating Item Desc... for PF ".$rsrcID;
        switch($area) {
            case 'pf':
                $objProcessMaster = new ProcessFlowMaster();
                $res = $objProcessMaster->displayProcessFlowById((int)$rsrcID);
                $descStr = compact_ra_description($res['description'],30);
                // echo var_dump($res);
            break;
            case 'pr':
                // the above may be put into process risk as displayProcessRiskById($id) // Bob to confirm
              
		$dbHand = DB::connect(_DB_TYPE);
                    $sql = sprintf(
                        " SELECT S.*,B.buName FROM %s.swimlane S ".
                        " INNER JOIN %s.business_units B ".
                        " ON S.buID = B.buID ".
                        " WHERE S.swimID = %d ".
                        " ORDER BY S.swimID DESC "
                        ,_DB_OBJ_FULL
                        ,_DB_OBJ_FULL
                        ,(int)$rsrcID
                    );

                    $pStatement = $dbHand->prepare($sql);
                    $pStatement->execute();
                    $res = $pStatement->fetchAll(PDO::FETCH_ASSOC); // would be return not $res = for func

                $descStr = compact_ra_description($res[0]['description'],30);
            break;
            case 'doc':
                // Note this is the cmsDocID not the documentID for rsrc
                $objDoc = new Documents();
                $DocData = $objDoc ->getDocumentInformation($rsrcID);
                $descStr =  $DocData['title'];
                // var_dump($DocData);
            break;
			case 'trainack':
			case 'traincert':
				$trngObj = SetupGeneric::useModule('TrainingCourse');
				$trngObj->setItemInfo(array('id'=>$rsrcID));
				$courseData = $trngObj->displayItemById();
				$descStr = (($area == 'trainack') ? self::NEED_TRAIN : self::CERT_REQ );
				$descStr .= $courseData['title'];
			break;
        }
        // echo $descStr; //debugging only
        return $descStr;
    }
}