<?php

/**
  $Id: BCPMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, November 03, 2010 12:25:00 PM>
 */
require_once "BCP.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class BCPMain implements BCP {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * property contains witness data
     * @access private
     */
    private $witnessData;

    /**
     * Property to hold BCP Id
     * @access private
     */
    private $BCPId;

    /**
     * Property to hold BCP Info
     * @access private
     */
    private $BCPInfo;

    /**
     * Constructor for initializing BCP object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set incidence information for the respective object
     */

    public function setBCPInfo($p_BCPId, $p_BCPInfo) {
        $this->BCPId = $p_BCPId;
        $this->BCPInfo = $p_BCPInfo;
    }

    /*
     * This method is used to add new incidence
     * reference,unique_reference,incidence_date,incidence_date_time,location,business_unit
     */

    public function getLastInsertID() {
        return $this->BCPId;
    }

    public function purgeBCP() {
        
    }

    public function deleteBCP() {
        
    }

    public function archiveBCP() {
        
    }

    public function getBCP11() {
        $sql = sprintf("SELECT * FROM %s.smart_bcp WHERE archive is NULL OR archive = 0  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCP11a() {
        $sql = sprintf("SELECT * FROM %s.smart_bcp WHERE  archive = 1  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCPAll877cric($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_cric WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPAll877desi($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_desi WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPAll8779($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_bir WHERE bia_id = '$this->id' AND (archive is NULL OR archive = 0)";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCP($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_bcp WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getDesi() {

        $sql = "SELECT * FROM %s.smart_desi WHERE archive is NULL OR archive =0 ORDER BY name ASC";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getRat() {

        $sql = "SELECT * FROM %s.smart_rat WHERE archive is NULL OR archive = 0";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getNature() {

        $sql = "SELECT * FROM %s.smart_nature WHERE archive is NULL OR archive =0 ORDER BY name ASC";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getCric() {

        $sql = "SELECT * FROM %s.smart_cric ";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPActive() {
        $sql = sprintf("SELECT * FROM %s.smart_new_bcp WHERE (active = 1 OR active = 3) AND  (archive = 0 OR archive is NULL)   ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCP1177aaa() {
        $sql = sprintf("SELECT * FROM %s.smart_new_bcp WHERE (active = 1 OR active= 3) AND   archive = 1  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCPStage2() {
        $sql = sprintf("SELECT * FROM %s.smart_new_bcp WHERE active= 2 AND   isnull(archive,0) = 0  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCPStage2a() {
        $sql = sprintf("SELECT * FROM %s.smart_new_bcp WHERE active= 2 AND   archive = 1  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCPnambu($ID) {
        $this->ID = $ID;

        $sql = "SELECT * FROM %s.business_units WHERE buID = " . $this->ID;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrsref($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_standard WHERE uniqueReference = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrssref($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_serious WHERE uniqueReference = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        //	dump_array($result);
        return $result;
    }

    public function getBCPerrsvref($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_severe WHERE uniqueReference = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        //	dump_array($result);
        return $result;
    }

    public function getBCPerrsprref($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.swimlane WHERE reference = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPview($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_new_bcp WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPviewNew($id) {
        $this->id = $id;

        $sql = "SELECT N.*,P.forename+ ' '+ P.surname as displayname,B.buName,B.acc FROM %s.smart_action_new N left join %s.participant_database P on N.who=P.participantID left join %s.business_units B on N.bu=B.buID WHERE  a_id =" . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPviewNew_bu($id) {
        $this->id = $id;

        $sql = "SELECT N.*,P.forename+ ' '+ P.surname as displayname,B.buName FROM %s.smart_action_new N left join %s.participant_database P on N.who=P.participantID left join %s.business_units B on N.bu=B.buID WHERE  bu =" . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPviewTest($id) {
        $this->id = $id;

        $sql = "SELECT N.*,P.forename+ ' '+ P.surname as displayname,B.buName FROM %s.smart_action_new N left join %s.participant_database P on N.who=P.participantID left join %s.business_units B on N.bu=B.buID WHERE  a_id =" . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $i = 0;
        foreach ($result as $row) {
            $resultnew[$i] = $row;
            $resultnew[$i]["backup"] = $this->getbackupPerson($row["ref"], $row["who"]);
            $i++;
        }
        return $resultnew;
    }

    public function getBCPviewNew77d($id) {
        $this->id = $id;
        $sql = "SELECT count(time) as tot,ref FROM %s.smart_action_new WHERE  a_id = " . $this->id . "AND list = 'Days' Group by ref";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPviewNew77h($id) {
        $this->id = $id;
        $sql = "SELECT count(time) as tot,ref FROM %s.smart_action_new WHERE  a_id = " . $this->id . "AND list = 'Hours' Group by ref";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addBCPactionNew($id, $act, $who, $ref, $time, $list, $file, $group, $bu='') {
        $this->id = $id;
        $this->act = $act;
        $this->who = $who;
        $this->ref = $ref;
        $this->time1 = $time;
        $this->list1 = $list;
        $this->file = $file;
        $this->group = $group;
        $this->bu = $bu;


        $sql2 = sprintf("INSERT INTO %s.smart_action_new(
							a_id,action,who,ref,time,list,file_name,group_a,bu)
							VALUES($this->id,'$this->act','$this->who','$this->ref'
							,'$this->time1','$this->list1','$this->file','$this->group','$this->bu'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_action_new', 'ID');
        //$pStatement2->errorInfo();

        return $this->BCPId;
    }

    public function getBCPAllstepRef($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.swimlane WHERE reference = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrspjjjm1($id) {
        $this->id = $id;
       $sql = "SELECT * FROM %s.uploaded_files WHERE fileID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPAll78e($id) {
        $this->id = $id;

        $sql = "SELECT * FROM %s.smart_bcp_action WHERE r_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPAll788e($id) {
        $this->id = $id;

        $sql = "SELECT * FROM %s.smart_bri_action WHERE r_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addNewTestAction($id, $ref, $descp) {
        $this->id = $id;
        $this->ref = $ref;
        $this->descp = $descp;



        $sql2 = sprintf("INSERT INTO %s.smart_action(
							b_id,uniqueReference,desc_t)
							VALUES($this->id,'$this->ref','$this->descp'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_action', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function addBCPactionNew1777TestAction($id, $act, $who, $ref, $active, $time, $list, $file, $group, $bu, $a_id_link = 0) {
        $this->id = $id;
        $this->act = $act;
        $this->who = $who;
        $this->ref = $ref;
        $this->active = $active;
        $this->time1 = $time;
        $this->list1 = $list;
        $this->file = $file;
        $this->group = $group;
        $this->bu = $bu;
        $this->a_id_link = $a_id_link;

       $sql2 = sprintf("INSERT INTO %s.smart_action_list(
							a_id,action,who,ref,active,time,list,file_name,group_a,bu,a_id_link)
							VALUES($this->id,'$this->act','$this->who','$this->ref','$this->active'
							,'$this->time1','$this->list1','$this->file','$this->group','$this->bu','$this->a_id_link'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_action_list', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function editBCPactiveNew($id) {


        $this->id = $id;

        $sql2 = sprintf(" UPDATE %s.smart_new_bcp SET
						
					
						active = 1
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function deleteBCPactionNew($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_action_new WHERE a_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function addBCPactionNew1($id, $act, $who, $ref, $active, $time, $list, $file, $group, $bu) {
        $this->id = $id;
        $this->act = $act;
        $this->who = $who;
        $this->ref = $ref;
        $this->active = $active;
        $this->time1 = $time;
        $this->list1 = $list;
        $this->file = $file;
        $this->group = $group;
        $this->bu = $bu;


        $sql2 = sprintf("INSERT INTO %s.smart_action_new(
							a_id,action,who,ref,active,time,list,file_name,group_a)
							VALUES($this->id,'$this->act','$this->who','$this->ref','$this->active'
							,'$this->time1','$this->list1','$this->file','$this->group','$this->bu'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_action_new', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function getBCPview6789Action($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_action WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPviewNewA($id) {
        $this->id = $id;

        $sql = "SELECT N.*,P.forename+ ' '+ P.surname as displayname,B.buName FROM %s.smart_action_list N left join %s.participant_database P on N.who=P.participantID left join %s.business_units B on N.bu=B.buID WHERE  a_id =" . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCP1177aTestAction($archive) {
        $sql = sprintf("SELECT * FROM %s.smart_action where isnull(archive,0)=%d ORDER BY ID DESC", _DB_OBJ_FULL,$archive);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCPAll78ref1($id) {
        $this->id = $id;

        $sql = "SELECT * FROM %s.smart_bir WHERE bia_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCP1177ssa() {
        $sql = sprintf("SELECT * FROM %s.smart_standard WHERE archive= 1   ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCP1177ssa787() {
        $sql = sprintf("SELECT * FROM %s.smart_severe WHERE archive= 1   ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCP1177ss() {
        $sql = sprintf("SELECT * FROM %s.smart_serious WHERE archive = 0 OR archive is NULL   ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function updateRisk($emp_id) {
        $this->emp_id = $emp_id;


        $sql2 = sprintf(" UPDATE %s.smart_bcp SET later = '0'
									
									WHERE ID =" . $this->emp_id, _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->incidenceInfo['archive']);
          $pStatement2->bindParam(2,$this->incidenceId); */

        $pStatement2->execute();
    }

    public function getBCPerrs($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_standard WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getbcpStand() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $sql = "SELECT * FROM %s.smart_standard WHERE isnull(archive,0) = %d order by ID desc";
        $psql = sprintf($sql, _DB_OBJ_FULL,$archive);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

	    public function getbcpStandFull() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
        //$sql = "SELECT * FROM %s.smart_standard WHERE archive = 0 OR  archive is NULL order by ID asc";
    $sql = sprintf("select S.*,A.action as action1,P.forename+' '+P.surname as who1 from %s.smart_standard_action A inner join %s.smart_standard S on A.s_id=S.ID left join %s.participant_database P on A.who=P.participantID where isnull(S.archive,0)=%d order by S.ID desc" , _DB_OBJ_FULL , _DB_OBJ_FULL, _DB_OBJ_FULL,$archive);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
	
	    public function getbcpSeverFull() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
        //$sql = "SELECT * FROM %s.smart_standard WHERE archive = 0 OR  archive is NULL order by ID asc";
          $sql = sprintf("select S.*,A.action as action1,P.forename+' '+P.surname as who1,B.buName,C.name as crit from %s.smart_severe_action A inner join %s.smart_severe S on A.s_id=S.ID left join %s.participant_database P on A.who=P.participantID left join %s.business_units B on S.bu=B.buID left join %s.smart_cric C on S.obj=C.ID where isnull(S.archive,0)=%d order by S.ID desc" , _DB_OBJ_FULL , _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$archive);
      
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

		    public function getbcpSeriousFull() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
        //$sql = "SELECT * FROM %s.smart_standard WHERE archive = 0 OR  archive is NULL order by ID asc";
        $sql = sprintf("select S.*,A.action as action1,P.forename+' '+P.surname as who1 from %s.smart_serious_action A inner join %s.smart_serious S on A.s_id=S.ID left join %s.participant_database P on A.who=P.participantID where isnull(S.archive,0)=%d order by S.ID desc" , _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$archive );
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
    public function getBCPerrsv($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_severe WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrss($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_serious WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPservere($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_new_process WHERE p_ID  = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrsp($id) {
        $this->id = $id;
        $sql = "SELECT D.*,B.buName FROM %s.swimlane_data D left join %s.business_units B on D.buID=B.buID WHERE type != 'D' AND swimID = " . $this->id . "ORDER BY altPathIndex, stepLevel,ID ASC";

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrspe($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_new_process WHERE p_ID  = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrspr($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.swimlane WHERE swimID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrspjjjm($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.swimlane_documents WHERE stepID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addNewBCP($ref_b, $id, $action, $stand, $serious, $severe, $des) {
        $this->ref_b = $ref_b;
        $this->id = $id;
        $this->action = $action;
        $this->stand = $stand;
        $this->serious = $serious;
        $this->severe = $severe;
        $this->des = $des;



        $sql2 = sprintf("INSERT INTO %s.smart_new_bcp(
							uniqueReference,bia_id,action,stand,serious,severe,des)
							VALUES('$this->ref_b','$this->id','$this->action','$this->stand',
							'$this->serious','$this->severe','$this->des'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_new_bcp', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function editBCPactiveNew3($id) {


        $this->id = $id;

        $sql2 = sprintf(" UPDATE %s.smart_new_bcp SET
						
					
						active = 3
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function getBCPAllstep($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.swimlane_data WHERE type='A' AND swimID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP11chh($id) {
        $this->id = $id;
        $sql1 = "SELECT * FROM %s.smart_new_bcp WHERE ID = " . $this->id;

        $psql = sprintf($sql1, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result6 = $stmt->fetch(PDO::FETCH_ASSOC);


        $r = $result6['subRef'];
        $r_a = $r + 1;


        $this->save = $save;

        $this->ref_id = $ref_id;
        $this->n = $n;
        $this->group = $group;


        $sql2 = sprintf(" UPDATE %s.smart_new_bcp SET
						
						
						
						subRef = '$r_a'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editBCP11cjjjj($id) {


        $this->id = $id;

        $sql2 = sprintf(" UPDATE %s.smart_new_bcp SET
						
						
						test = 'T'
						
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function getBCPAll877nat($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_nature WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCP78($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.actions WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP113($record_id, $likelihood_data, $impact_data, $risk_value, $risk_background_color) {

        $this->likelihood_data = $likelihood_data;

        $this->impact_data = $impact_data;
        $this->risk_value = $risk_value;
        $this->risk_background_color = $risk_background_color;

        $this->id = $record_id;

        $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						
						like2 = '$this->likelihood_data',
						
						impact2 = '$this->impact_data',
						risk2 = '$this->risk_value',
						color2 = '$this->risk_background_color'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editBCP115($record_id, $likelihood_data, $impact_data, $risk_value, $risk_background_color) {

        $this->likelihood_data = $likelihood_data;

        $this->impact_data = $impact_data;
        $this->risk_value = $risk_value;
        $this->risk_background_color = $risk_background_color;

        $this->id = $record_id;

        $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						
						like_a = '$this->likelihood_data',
						
						impact = '$this->impact_data',
						risk = '$this->risk_value',
						color = '$this->risk_background_color'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editBCP112($record_id, $at_source, $along_path, $at_worker, $no_improvement, $improvement_reason, $summary_improvement, $eliminate_hazard, $overwrite_control) {
        $this->at_source = $at_source;
        $this->along_path = $along_path;

        $this->at_worker = $at_worker;
        $this->no_improvement = $no_improvement;
        $this->improvement_reason = $improvement_reason;

        $this->summary_improvement = $summary_improvement;
        $this->eliminate_hazard = $eliminate_hazard;
        $this->overwrite_control = $overwrite_control;

        $this->id = $record_id;



        $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						source = '$this->at_source',
						path = '$this->along_path',
						
						worker = '$this->at_worker',
						no_improvement = '$this->no_improvement',
						improvement_reason = '$this->improvement_reason',
						improvement = '$this->summary_improvement',
						eliminate_hazard = '$this->eliminate_hazard',
						overwrite_control = '$this->overwrite_control'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editBCP1136($record_id, $likelihood_data, $impact_data, $risk_background_color) {

        $this->likelihood_data = $likelihood_data;

        $this->impact_data = $impact_data;

        $this->risk_background_color = $risk_background_color;

        $this->id = $record_id;

        $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						
						time_t = '$this->likelihood_data',
						
						net = '$this->impact_data',
						
						pri_color = '$this->risk_background_color'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function getBCPerrsAction($id) {
        $this->id = $id;
       $sql = "SELECT A.*,P.forename+ ' ' +P.surname as fullname,B.buID,B.buname FROM %s.smart_standard_action A left join %s.participant_database  P on A.who=P.participantID left join %s.business_units  B on A.bu=B.buID WHERE s_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrsvAction($id) {
        $this->id = $id;
        $sql = "SELECT A.*,P.forename+ ' ' +P.surname as fullname,B.buname  FROM %s.smart_severe_action A left join %s.participant_database  P on A.who=P.participantID left join %s.business_units B on A.bu=B.buID WHERE s_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPerrsAction1($id) {
        $this->id = $id;
        $sql = "SELECT A.*,P.forename+ ' ' +P.surname as fullname,B.buname  FROM %s.smart_serious_action A left join %s.participant_database  P on A.who=P.participantID left join %s.business_units B on A.bu=B.buID WHERE s_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addBCPa($ref_bia, $id, $c) {
        $this->ref_bia = $ref_bia;
        $this->id = $id;
        $this->c = $c;




        $sql2 = sprintf("INSERT INTO %s.smart_bcpa(
							uniqueReference,s_id,check_t)
							VALUES('$this->ref_bia',$this->id,'$this->c'
							
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_bcpa', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function getBCP1177ssb() {
        $sql = sprintf("SELECT * FROM %s.smart_new_bcp WHERE (active is NULL OR active = 2) AND  (archive = 0 OR archive is NULL)   ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCP1177aTest($archive) {
       $sql = sprintf("SELECT * FROM %s.smart_test where isnull(archive,0)=%d  ORDER BY ID DESC", _DB_OBJ_FULL,$archive);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getBCPview6789($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_test WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPviewNewT($id) {
        $this->id = $id;

        $sql = "SELECT T.*,P.forename+ ' '+ P.surname as displayname,B.buName,B.acc FROM %s.smart_action_test T left join %s.participant_database P on T.who=P.participantID left join %s.business_units B on T.bu=B.buID WHERE  a_id =" . $this->id;

        //  $sql = "SELECT * FROM %s.smart_action_test WHERE  a_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPAll78ref1778($id) {
        $this->id = $id;

        $sql = "SELECT * FROM %s.actions WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP1145589898($id) {


        $this->id = $id;

        $sql2 = sprintf(" UPDATE %s.smart_action_list SET
						
					
						active = 1
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function addStandard($ref, $bu, $cn, $time, $sl, $step, $action, $who, $list, $sen, $name1, $sName, $reason, $obj, $obj1, $file, $group, $swimlane = 0, $actiontime, $actionlist, $bu_hidden, $resourcegroup) {
        $this->ref = $ref;
        $this->bu = $bu;
        $this->cn = $cn;
        $this->time1 = $time;
        $this->sl = $sl;
        $this->step = $step;
        $this->action = $action;
        $this->who = $who;
        $this->bu_hidden = $bu_hidden;
        $this->list1 = $list;
        $this->sen = $sen;
        $this->name1 = $name1;
        $this->sName = $sName;
        $this->reason = $reason;
        $this->obj = $obj;
        $this->obj1 = $obj1;
        $this->file = $file;
        $this->group = $group;
        $this->resourcegroup = $resourcegroup;
        $this->swimlane = $swimlane;
        $this->actiontime = $actiontime;
        $this->actionlist = $actionlist;

        $sql2 = sprintf("INSERT INTO %s.smart_standard(
							uniqueReference,bu,name,time,level_s,step,action,who,list,sen,des,sName,reason,obj,obj1,file_name,group_a,swimid,actiontime,actionlist,bulist,resource_group)
							VALUES('$this->ref','$this->bu','$this->cn','$this->time1',
							'$this->sl','$this->step','$this->action','$this->who','$this->list1','$this->sen','$this->name1'
							,'$this->sName','$this->reason','$this->obj','$this->obj1','$this->file','$this->group','$this->swimlane','$this->actiontime','$this->actionlist','$this->bu_hidden','$this->resourcegroup'
							)", _DB_OBJ_FULL
        );
        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_standard', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function addSevere($ref, $bu, $cn, $time, $sl, $step, $action, $who, $list, $sen, $name1, $sName, $reason, $obj, $obj1, $file, $group, $swimlane = 0, $actiontime, $actionlist, $bu_hidden, $resourcegroup) {
        $this->ref = $ref;
        $this->bu = $bu;
        $this->cn = $cn;
        $this->time1 = $time;
        $this->sl = $sl;
        $this->step = $step;
        $this->action = $action;
        $this->who = $who;
        $this->bu_hidden = $bu_hidden;
        $this->list1 = $list;
        $this->sen = $sen;
        $this->name1 = $name1;
        $this->sName = $sName;
        $this->reason = $reason;
        $this->obj = $obj;
        $this->obj1 = $obj1;
        $this->file = $file;
        $this->group = $group;
        $this->resourcegroup = $resourcegroup;
        $this->swimlane = $swimlane;
        $this->actiontime = $actiontime;
        $this->actionlist = $actionlist;

        $sql2 = sprintf("INSERT INTO %s.smart_severe(
							uniqueReference,bu,name,time,level_s,step,action,who,list,sen,des,sName,reason,obj,obj1,file_name,group_a,swimid,actiontime,actionlist,bulist,resource_group)
							VALUES('$this->ref','$this->bu','$this->cn','$this->time1',
							'$this->sl','$this->step','$this->action','$this->who','$this->list1','$this->sen','$this->name1'
							,'$this->sName','$this->reason','$this->obj','$this->obj1','$this->file','$this->group','$this->swimlane','$this->actiontime','$this->actionlist','$this->bu_hidden','$this->resourcegroup'
							)", _DB_OBJ_FULL
        );
        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_severe', 'ID');

        return $this->BCPId;
    }

    public function addStandardActionDELETE($id) {

        $this->id = $id;

        $sql = sprintf("DELETE FROM %s.smart_standard_action WHERE s_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function addSevereActionDELETE($id) {

        $this->id = $id;

        $sql = sprintf("DELETE FROM %s.smart_severe_action WHERE s_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function addStandardAction($id, $va, $who, $file, $actiontime, $actionlist, $bu) {
        $this->id = $id;
        $this->va = str_replace("\'", "`", $va);
        $this->who = $who;
        $this->file = $file;
        $this->actionlist = $actionlist;
        $this->actiontime = $actiontime;
        $this->bu = $bu;




        $sql2 = sprintf("INSERT INTO %s.smart_standard_action(
							s_id,action,who,file_name,time,list,bu)
							VALUES($this->id,'$this->va','$this->who','$this->file','$this->actiontime','$this->actionlist','$this->bu'
						
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function addSevereAction($id, $va, $who, $file, $actiontime, $actionlist, $bu) {
        $this->id = $id;
        $this->va = str_replace("\'", "`", $va);
        $this->who = $who;
        $this->file = $file;
        $this->actionlist = $actionlist;
        $this->actiontime = $actiontime;
        $this->bu = $bu;



        $sql2 = sprintf("INSERT INTO %s.smart_severe_action(
							s_id,action,who,file_name,time,list,bu)
							VALUES($this->id,'$this->va','$this->who','$this->file','$this->actiontime','$this->actionlist','$this->bu'
						
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function editstandard($id, $ref, $bu, $cn, $time, $sl, $step, $action, $who, $list, $sen, $name1, $sName, $reason, $obj, $obj1, $file, $group, $actiontime, $actionlist,$bulist,$resourcegroup) {

        $this->ref = $ref;

        $this->bu = $bu;
        $this->cn = $cn;
        $this->time1 = $time;

        $this->sl = $sl;

        $this->step = $step;
        $this->action = $action;
        $this->who = $who;

        $this->list1 = $list;
        $this->sen = $sen;
        $this->name1 = $name1;

        $this->sName = $sName;
        $this->reason = $reason;
        $this->obj = $obj;
        $this->obj1 = $obj1;
        $this->file = $file;
        $this->group = $group;
        $this->id = $id;
        $this->actionlist = $actionlist;
        $this->actiontime = $actiontime;
$this->resourcegroup = $resourcegroup;
      $sql2 = sprintf(" UPDATE %s.smart_standard SET
						
						uniqueReference = '$this->ref',
						
						bu = '$this->bu',
						name = '$this->cn',
						time = '$this->time1',
						level_s = '$this->sl',
						
						step = '$this->step',
						action = '$this->action',
						who = '$this->who',
						list = '$this->list1',
						sen = '$this->sen',
						des = '$this->name1',
						sName = '$this->sName',
						reason = '$this->reason',
						obj = '$this->obj',
						obj1 = '$this->obj1',
						file_name = '$this->file',
						group_a = '$this->group',
						actionlist = '$this->actionlist',
						actiontime = '$this->actiontime',
                                                    resource_group= '$this->resourcegroup'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
   
    }

    public function editsevere($id, $ref, $bu, $cn, $time, $sl, $step, $action, $who, $list, $sen, $name1, $sName, $reason, $obj, $obj1, $file, $group, $actiontime, $actionlist, $bu_hidden, $resourcegroup) {

        $this->ref = $ref;

        $this->bu = $bu;
        $this->cn = $cn;
        $this->time1 = $time;

        $this->sl = $sl;

        $this->step = $step;
        $this->action = $action;
        $this->who = $who;

        $this->list1 = $list;
        $this->sen = $sen;
        $this->name1 = $name1;

        $this->sName = $sName;
        $this->reason = $reason;
        $this->obj = $obj;
        $this->obj1 = $obj1;
        $this->file = $file;
        $this->group = $group;
        $this->resourcegroup = $resourcegroup;
        $this->id = $id;
        $this->actionlist = $actionlist;
        $this->actiontime = $actiontime;
        $this->bu_hidden = $bu_hidden;

        $sql2 = sprintf(" UPDATE %s.smart_severe SET
						
						uniqueReference = '$this->ref',
						
						bu = '$this->bu',
						name = '$this->cn',
						time = '$this->time1',
						level_s = '$this->sl',
						
						step = '$this->step',
						action = '$this->action',
						who = '$this->who',
						list = '$this->list1',
						sen = '$this->sen',
						des = '$this->name1',
						sName = '$this->sName',
						reason = '$this->reason',
						obj = '$this->obj',
						obj1 = '$this->obj1',
						file_name = '$this->file',
						group_a = '$this->group',
                                                resource_group = $this->resourcegroup,
                                                bulist = '$this->bu_hidden',
						actionlist = '$this->actionlist',
						actiontime = '$this->actiontime'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'stand') {
            return $this->getBCPExportDataStand();
        } else if ($type == 'stand1') {
            return $this->getBCPExportDataStandFull();
        } else if ($type == 'app') {
            return $this->getBCPExportDataApps();
        } else if ($type == 'ser1') {
            return $this->getBCPExportDataFull182();
        } else if ($type == 'ser') {
            return $this->getBCPExportDataFull181();
        } else if ($type == 'sev') {
            return $this->getBCPExportDataFull191();
        } else if ($type == 'sev1') {
            return $this->getBCPExportDataFull192();
        } else if ($type == 'bia') {
            return $this->getExportDataBIA();
        } else if ($type == 'bia1') {
            return $this->getExportDataBIAFull();
        } else if ($type == 'bcp_new') {
            return $this->getExportDataBCP();
        } else if ($type == 'bcp1') {
            return $this->getExportDataBCPFULL();
        }
    }

    public function getBCPExportDataStand() {

        $heading = array(array(0 => 'Reference', 1 => 'Description',2 => 'Business Unit', 3 => 'System Name', 4 => 'Recovery Time'));

        $bcp_data = $this->getbcpStand();
     //   dump_array($bcp_data);exit;


        if (is_array($bcp_data)) {

            foreach ($bcp_data as $key => $value) {

                $b = $this->getBCPnambu($value['bu']);


                $r = $value['time'] . '' . $value['list'];

                $result1[$key] = array($value['uniqueReference'],$value['des'], $b['buName'], $value['sName'], $r);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

    public function getBCPExportDataStandFull() {

        $heading = array(array(0 => 'Reference', 1 => 'Business Unit', 2 => 'System Name', 3 => 'Recovery Time', 4 => 'Location', 5 => 'Title', 6 => 'Component Name', 7 => 'Scenario', 8 => 'Description', 9 => 'Reason', 10 => 'Criticality', 11 => 'Objective', 12 => 'Security Level', 13 => 'Action', 14 => 'who', 15 => 'File Name'));

        $bcp_data = $this->getbcpStandFull();
        //dump_array($equipment_data);exit;


        if (is_array($bcp_data)) {

            foreach ($bcp_data as $key => $value) {

                $b = $this->getBCPnambu($value['bu']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $value['step']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();

                $na = $this->getBCPAll877cric($value['obj']);




                $r = $value['time'] . '' . $value['list'];

                $result1[$key] = array($value['uniqueReference'], $b['buName'], $value['sName'], $r, $location['name'], $value['group_a'], $value['name'], $value['sen'], $value['des'], $value['reason'], $na['name'], $value['obj1'], $value['level_s'], $value['action1'], $value['who1'], $value['file_name']);
            }
            //dump_array($bu_name);exit;
        }

if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;


        return $result_new;
    }

    public function archiveBCPstand() {

        $sql = "UPDATE %s.smart_standard SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function getBCP1177ssaar() {
        $sql = sprintf("SELECT * FROM %s.smart_serious WHERE archive = 1  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function addSerious($ref, $list, $name, $action, $who, $bu, $step, $file, $time, $listtt, $group, $swimlane = 0, $actiontime, $actionlist, $bu_hidden, $resourcegroup) {
        $this->ref = $ref;
        $this->list1 = $list;
        $this->name = $name;
        $this->action = $action;
        $this->who = $who;
        $this->bu_hidden = $bu_hidden;
        $this->bu = $bu;
        $this->step = $step;
        $this->file = $file;
        $this->time1 = $time;
        $this->list2 = $listtt;
        $this->actiontime = $actiontime;
        $this->actionlist = $actionlist;
        $this->group = $group;
        $this->resourcegroup = $resourcegroup;
        $this->swimlane = $swimlane;


        $sql2 = sprintf("INSERT INTO %s.smart_serious(
							uniqueReference,inc,descp,action,who,bu,loc,file_name,time,list,group_a,swimid,actiontime,actionlist,bulist,resource_group)
							VALUES('$this->ref','$this->list1','$this->name',
							'$this->action','$this->who','$this->bu','$this->step','$this->file'
							,'$this->time1','$this->list2','$this->group','$this->swimlane','$this->actiontime','$this->actionlist','$this->bu_hidden','$this->resourcegroup'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_serious', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function addSeriousActionDELETE($id) {

        $this->id = $id;

        $sql = sprintf("DELETE FROM %s.smart_serious_action WHERE s_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function addSeriousAction($id, $va, $who, $file, $actiontime, $actionlist, $bu) {
        $this->id = $id;
        $this->va = str_replace("\'", "`", $va);
        $this->who = $who;
        $this->file = $file;
        $this->actionlist = $actionlist;
        $this->actiontime = $actiontime;
        $this->bu = $bu;




        $sql2 = sprintf("INSERT INTO %s.smart_serious_action(
							s_id,action,who,file_name,time,list,bu)
							VALUES($this->id,'$this->va','$this->who','$this->file','$this->actiontime','$this->actionlist','$this->bu'
						
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function editserious($id, $ref, $list, $name, $action, $who, $bu, $step, $file, $time, $listtt, $group, $actiontime, $actionlist, $bu_hidden,$resourcegroup) {

        $this->ref = $ref;

        $this->list1 = $list;
        $this->name = $name;

        $this->action = $action;
        $this->who = $who;
        $this->bu = $bu;
        $this->step = $step;
        $this->file = $file;
        $this->time1 = $time;
        $this->listtt = $listtt;
        $this->group = $group;
        $this->actiontime = $actiontime;
        $this->actionlist = $actionlist;
        $this->resourcegroup = $resourcegroup;
        $this->id = $id;


       $sql2 = sprintf(" UPDATE %s.smart_serious SET
						
						uniqueReference = '$this->ref',
						
						inc = '$this->list1',
						descp = '$this->name',
						action = '$this->action',
						who = '$this->who',
						bu = '$this->bu',
						loc = '$this->step',
						file_name = '$this->file',
						time = '$this->time1',
						list = '$this->listtt',
                                                actiontime = '$this->actiontime',
						actionlist = '$this->actionlist',
                                                resource_group = '$this->resourcegroup',
						group_a = '$this->group'
						
						
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function deleteBCPactionN($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_action_new WHERE ID = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionNAction($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_action_list WHERE ID = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionNStan($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_standard_action WHERE ID = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionNSer($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_serious_action WHERE ID = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPaction($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_bcp_action WHERE r_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionNewbb($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_new_action_back WHERE a_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionNewAction($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_action_list WHERE a_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionNewstage2($ref, $id) {
        $this->ref = $ref;
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_action_new WHERE a_id = " . $this->id . " AND  ID = " . $this->ref, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPactionbr($id, $name) {
        $this->id = $id;
        $this->name = $name;

        $sql = sprintf("DELETE FROM %s.smart_bcp_action WHERE name='$this->name' AND  r_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPaction1($id) {
        $this->id = $id;


        $sql = sprintf("DELETE FROM %s.smart_bri_action WHERE r_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPaction7($id, $name) {
        $this->id = $id;
        $this->name = $name;

        $sql = sprintf("DELETE FROM %s.smart_bri_action WHERE name='$this->name' AND r_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPaction7process($id, $name) {
        $this->id = $id;
        $this->name = $name;

        $sql = sprintf("DELETE FROM %s.smart_process_action WHERE name='$this->name' AND r_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function deleteBCPaction7process1($id, $name) {
        $this->id = $id;
        $this->name = $name;

        $sql = sprintf("DELETE FROM %s.smart_brp_process WHERE name='$this->name' AND r_id = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function getBCPFile1() {
        $sql = sprintf("SELECT file_name FROM %s.smart_bcp_action WHERE ID = %d", _DB_OBJ_FULL, $this->BCPId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchColumn();


        return $resultSet;
    }

    public function getBCP1177a() {
        $sql = sprintf("SELECT * FROM %s.smart_new_bcp WHERE (active is NULL OR active= 2) AND   archive = 1  ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function archiveSmartbcpNew() {

        $sql = "UPDATE %s.smart_new_bcp SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

	public function getExportDataBCPStage1Full() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'BIA Description', 5 => 'Location Reviewed', 6 => 'Business Affected', 7 => 'Process Affected', 8 => 'Standard Reference', 9 => 'Serious Reference', 10 => 'Severe Reference'));

       $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
       if($archive_session){
$bcp_data = $this->getBCPStage2a();
}else{

$bcp_data = $this->getBCPStage2();
}


        if (is_array($bcp_data)) {

            foreach ($bcp_data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }


                $data4 = $this->getBCP($value['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data4['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp'], $location['name'], $b['buName'], $data4['process'], $value['stand'], $value['serious'], $value['severe']);
            }
        }

                if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        return $result_new;
    }
	
    public function getExportDataBCPStage2Full() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'BIA Description', 5 => 'Location Reviewed', 6 => 'Business Affected', 7 => 'Process Affected', 8 => 'Standard Reference', 9 => 'Serious Reference', 10 => 'Severe Reference'));
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
       if($archive_session){
$bcp_data = $this->getBCPStage2a();
}else{

$bcp_data = $this->getBCPStage2();
}


        if (is_array($bcp_data)) {

            foreach ($bcp_data as $key => $value) {

                if ($value['active'] != '2') {
                    continue;
                }
                    $stage = 'Stage2';


                $data4 = $this->getBCP($value['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data4['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp'], $location['name'], $b['buName'], $data4['process'], $value['stand'], $value['serious'], $value['severe']);
            }
        }

                if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        return $result_new;
    }

      public function getExportDataBCPFULL() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description', 6 => 'Location Reviewed', 7 => 'Business Affected', 9 => 'Process Affected', 10 => 'Standard Reference', 11 => 'Serious Reference', 12 => 'Severe Reference'));

        $bcp_data = $this->getbcpBCP();


        if (is_array($bcp_data)) {

            foreach ($bcp_data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }


                $data4 = $this->getBCP($value['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data4['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp'], $location['name'], $b['buName'], $data4['process'], $value['stand'], $value['serious'], $value['severe']);
            }
        }

if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;

        return $result_new;
    }
    
    public function getBCPerrsprbu($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.participant_meta_data WHERE reportToBuID = '" . $this->id . "' AND isManager = 1";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPview44($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_action_new WHERE a_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCP11gh() {
        $sql = sprintf("SELECT * FROM %s.smart_bcp WHERE archive is NULL OR archive = 0  ORDER BY risk ASC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function archiveSmartbcp() {

        $sql = "UPDATE %s.smart_bcp SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function archiveSmartbcpb() {

        $sql = "UPDATE %s.smart_standard SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function archiveSmartbcpbs() {

        $sql = "UPDATE %s.smart_serious SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function archiveSmartbcpbs33() {

        $sql = "UPDATE %s.smart_severe SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

        public function archiveSmartbcptest() {

        $sql = "UPDATE %s.smart_test SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }
            public function archiveSmartbcpaction() {

        $sql = "UPDATE %s.smart_action SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }
    
    public function archiveSmartbir() {

        $sql = "UPDATE %s.smart_bir SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function archiveSmartbrp() {

        $sql = "UPDATE %s.smart_brp SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function getExportDataBIAFull() {

        $heading = array(array(0 => 'Reference', 1 => 'Location', 2 => 'Event', 3 => 'Criticality', 4 => 'Business Affected', 5 => 'Process Affected', 6 => 'Disturbance', 7 => 'Description of Disruption', 8 => 'Criticality Description', 9 => 'Can Action be taken to reduce Risk ?', 10 => 'Likelihood', 11 => 'Impact', 12 => 'Risk Rating', 13 => 'Is BIR Required?', 14 => 'Along the path', 15 => 'At the worker', 16 => 'Control Measures Summary ', 17 => 'At the source', 18 => 'Along the path', 19 => 'At the worker', 20 => 'Improved Control Measures ', 21 => 'Likelihood', 22 => 'Impact', 23 => 'Risk Rating'));
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
if($archive_session){
$data1 = $this->getBCP11a();
}else{
$data1 = $this->getBCP11();
}
        //dump_array($data);exit;

        if (is_array($data)) {

            foreach ($data as $key => $value) {


                $de = $de = explode(",", $value['critical']);
                $i = 0;
                $de1 = array();
                foreach ($de as $val) {
                    $na = $this->getBCPAll877cric($val);

                    $de1[$i] = $na['name'];
                    $i++;
                }
                $cric = implode(",", $de1);

                $na1 = explode(",", $value['desi']);
                //dump_array();
                if ($na1) {
                    $j = 0;
                    $dedd = array();
                    foreach ($na1 as $val) {
                        $nah = $this->getBCPAll877desi($val);

                        $dedd[$j] = $nah['name'];
                        $j++;
                    }
                    //dump_array($dedd);
                    $nat = implode(",", $dedd);
                } else {
                    $nat = '-';
                }
                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $value['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $result1[$key] = array($value['uniqueReference'], $location['name'], $nat, $cric, $value['bu'], $value['process'], $desi, $value['descp'], $value['cDescp'], $value['r_check'], $value['like_a'], $value['impact'], $value['risk'], $value['is_bir'], $value['along_path'], $value['at_worker'], $value['summary'], $value['source'], $value['path'], $value['worker'], $value['improvement'], $value['like2'], $value['impact2'], $value['risk2']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

    public function getExportDataBIA() {

        $heading = array(array(0 => 'Reference', 1 => 'Location', 2 => 'Event', 3 => 'Criticality'));
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
if($archive_session){
$data1 = $this->getBCP11a();
}else{
$data1 = $this->getBCP11();
}
   
        //dump_array($data);exit;

        if (is_array($data)) {

            foreach ($data as $key => $value) {

                $de = $de = explode(",", $value['critical']);
                $i = 0;
                $de1 = array();
                foreach ($de as $val) {
                    $na = $this->getBCPAll877cric($val);

                    $de1[$i] = $na['name'];
                    $i++;
                }
                $cric = implode(",", $de1);

                $na1 = explode(",", $value['desi']);
                //dump_array();
                if ($na1) {
                    $j = 0;
                    $dedd = array();
                    foreach ($na1 as $val) {
                        $nah = $this->getBCPAll877desi($val);

                        $dedd[$j] = $nah['name'];
                        $j++;
                    }
                    //dump_array($dedd);
                    $nat = implode(",", $dedd);
                } else {
                    $nat = '-';
                }

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $value['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $result1[$key] = array($value['uniqueReference'], $location['name'], $nat, $cric);
            }
            //dump_array($bu_name);exit;
        }
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

    public function addBCP($loc, $nature, $descp, $bu, $pu, $c, $r, $ref, $desi, $like, $risk, $color, $impact, $risk_c, $i_bir, $c_d, $action, $later_c,$rdesc) {
        $this->loc = $loc;
        $this->nature = $nature;
        $this->descp = $descp;
        $this->bu = $bu;
        $this->pu = $pu;
        $this->c = $c;
        $this->r = $r;
        $this->ref = $ref;
        $this->desi = $desi;
        $this->like = $like;
        $this->risk = $risk;
        $this->color = $color;
        $this->impact = $impact;
        $this->risk_c = $risk_c;
		$this->rdesc = $rdesc;
        $this->i_bir = $i_bir;
        $this->c_d = $c_d;
        $this->action = $action;
        $this->later_c = $later_c;
        $sql2 = sprintf("INSERT INTO %s.smart_bcp(
							loc,nature,descp,bu,process,
							critical,recovery,uniqueReference,desi,like_a,risk,color,
							impact,r_check,is_bir,cDescp,d_r,later,rdesc)
							VALUES($this->loc,'$this->nature','$this->descp','$this->bu',
							'$this->pu','$this->c',$this->r,'$this->ref','$this->desi',
							'$this->like','$this->risk','$this->color','$this->impact',
							'$this->risk_c','$this->i_bir','$this->c_d','$this->action','$this->later_c','$this->rdesc'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_bcp', 'ID');
        //$pStatement2->errorInfo();
        return $this->BCPId;
    }

    public function editBCP111($record_id, $along_path, $at_worker, $control_measures, $control_symbols) {

        $this->along_path = $along_path;

        $this->at_worker = $at_worker;
        $this->control_measures = $control_measures;
        $this->control_symbols = $control_symbols;

        $this->id = $record_id;

        $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						
						along_path = '$this->along_path',
						
						at_worker = '$this->at_worker',
						summary = '$this->control_measures',
						sym = '$this->control_symbols'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editBCP($id, $loc, $nature, $descp, $bu, $pu, $c, $r, $ref, $desi, $like, $risk, $color, $impact, $risk_c, $c_d, $action, $later_c,$rdesc) {
        $this->loc = $loc;
        $this->nature = $nature;
        $this->descp = $descp;
        $this->bu = $bu;
        $this->pu = $pu;
        $this->c = $c;
        $this->r = $r;
        $this->ref = $ref;
        $this->desi = $desi;
        $this->like = $like;
        $this->risk = $risk;
        $this->color = $color;
        $this->impact = $impact;
        $this->risk_c = $risk_c;
		$this->rdesc = $rdesc;
        $this->c_d = $c_d;
        $this->action = $action;
        $this->later_c = $later_c;
        $this->id = $id;

     $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						loc = $this->loc,
						nature = '$this->nature',
						descp = '$this->descp',
						bu = '$this->bu',
						process = '$this->pu',
						critical = '$this->c',
						recovery = $this->r,
						uniqueReference = '$this->ref',
						desi = '$this->desi',
						like_a = '$this->like',
						risk = '$this->risk',
						color = '$this->color',
						impact = '$this->impact',
						r_check = '$this->risk_c',
						rdesc = '$this->rdesc',
						cDescp = '$this->c_d',
						d_r = '$this->action',
						later = '$this->later_c'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function getxxExportDataBCPFULL() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description', 6 => 'Location Reviewed', 7 => 'Business Affected', 9 => 'Process Affected', 10 => 'Standard Reference', 11 => 'Serious Reference', 12 => 'Severe Reference'));

        $_data = $this->getbcpBCP();


        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }


                $data4 = $this->getBCP($value['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data4['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp'], $location['name'], $b['buName'], $data4['process'], $value['stand'], $value['serious'], $value['severe']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

    public function getExportDataBCPFULLActive() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description', 5 => 'Location Reviewed', 6 => 'Business Affected', 7 => 'Process Affected', 8 => 'Standard Reference', 9 => 'Serious Reference', 10 => 'Severe Reference'));

  //      $data = $this->getBCPActive();
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
if($archive_session ==1){
$data = $this->getBCP1177aaa();
}else{
$data = $this->getBCPActive();
}
        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }


                $data4 = $this->getBCP($value['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data4['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp'], $location['name'], $b['buName'], $data4['process'], $value['stand'], $value['serious'], $value['severe']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

    public function getExportDataBCPActive() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description'));

$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
if($archive_session ==1){
$data = $this->getBCP1177aaa();
}else{
$data = $this->getBCPActive();
}
        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }


                $data4 = $this->getBCP($value['bia_id']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
              if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

     public function getExportDataBCPTest() {

        $heading = array(array(0 => 'Reference', 1 => 'BCP Reference', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description'));

        $data = $this->getBCP1177aTest();

        if (is_array($data)) {

            foreach ($data as $key => $value) {
		

				
				
                $data4 = $this->getBCPview($value['b_id']);
$data7 = $this->getBCP($data4['bia_id']);
                $result1[$key] = array($value['uniqueReference'], $data4['uniqueReference'], $data4['des'], $data7['uniqueReference'], $data7['descp']);
            }
            //dump_array($bu_name);exit;
        }
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }
   
    
         public function getExportDataBCPTestFull() {
 $heading = array(array(0 => 'Reference', 1 => 'BCP Reference', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description', 5 => 'Location Reviewed', 6 => 'Business Affected', 7 => 'Process Affected', 8 => 'Standard Reference', 9 => 'Serious Reference', 10 => 'Severe Reference'));
      

        $data = $this->getBCP1177aTest();

        if (is_array($data)) {

            foreach ($data as $key => $value) {


				
				
                $data4 = $this->getBCPview($value['b_id']);
$data7 = $this->getBCP($data4['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data7['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);
                $result1[$key] = array($value['uniqueReference'], $data4['uniqueReference'], $data4['des'], $data7['uniqueReference'], $data7['descp'], $location['name'], $b['buName'], $data7['process'], $data4['stand'], $data4['serious'],$data4['severe']);
            }
            //dump_array($bu_name);exit;
        }
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }
    
         public function getExportDataBCPInitiate() {

        $heading = array(array(0 => 'Reference', 1 => 'BCP Reference', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description'));
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
 if($archive_session==1){
$data = $this->getBCP1177aTestAction(1);
}else{

$data = $this->getBCP1177aTestAction(0);
}

        if (is_array($data)) {

            foreach ($data as $key => $value) {
		

				
				
                $data4 = $this->getBCPview($value['b_id']);
$data7 = $this->getBCP($data4['bia_id']);
                $result1[$key] = array($value['uniqueReference'], $data4['uniqueReference'], $data4['des'], $data7['uniqueReference'], $data7['descp']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
         if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }
   
    
         public function getExportDataBCPInitiateFull() {
 $heading = array(array(0 => 'Reference', 1 => 'BCP Reference', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description', 5 => 'Location Reviewed', 6 => 'Business Affected', 7 => 'Process Affected', 8 => 'Standard Reference', 9 => 'Serious Reference', 10 => 'Severe Reference'));
      

$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
 if($archive_session==1){
$data = $this->getBCP1177aTestAction(1);
}else{

$data = $this->getBCP1177aTestAction(0);
}

        if (is_array($data)) {

            foreach ($data as $key => $value) {


				
				
                $data4 = $this->getBCPview($value['b_id']);
$data7 = $this->getBCP($data4['bia_id']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $data7['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();
                $b = $this->getBCPnambu($data4['bu']);
                $result1[$key] = array($value['uniqueReference'], $data4['uniqueReference'], $data4['des'], $data7['uniqueReference'], $data7['descp'], $location['name'], $b['buName'], $data7['process'], $data4['stand'], $data4['serious'],$data4['severe']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;
        //dump_array($result_new);exit;
        return $result_new;
    }
    
    public function getExportDataBCP() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'Description'));

        $data = $this->getbcpBCP();

        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }


                $data4 = $this->getBCP($value['bia_id']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

	 public function getExportDataBCPStage1() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'BIA Description'));

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
       if($archive_session){
$data = $this->getBCPStage2a();
}else{

$data = $this->getBCPStage2();
}

        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if ($value['active'] == '2') {
                    $stage = 'Stage2';
                } else if ($value['c_s']) {
                    $stage = 'Stage1';
                } else {
                    $stage = '-';
                }

                $data4 = $this->getBCP($value['bia_id']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp']);
            }
            //dump_array($bu_name);exit;
        }
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }
        public function getExportDataBCPStage2() {

        $heading = array(array(0 => 'Reference', 1 => 'Stage', 2 => 'Description', 3 => 'BIA Reference', 4 => 'BIA Description'));

 //       $data = $this->getbcpBCP();
$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');



if($archive_session){
$data = $this->getBCPStage2a();
}else{

$data = $this->getBCPStage2();
}
        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if ($value['active'] != '2') {
                    continue;
                }
                    $stage = 'Stage2';

                $data4 = $this->getBCP($value['bia_id']);

                $result1[$key] = array($value['uniqueReference'], $stage, $value['des'], $data4['uniqueReference'], $data4['descp']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        //dump_array($result_new);exit;
        return $result_new;
    }
    
            
    public function getbcpBCP() {

        $sql = "SELECT * FROM %s.smart_new_bcp WHERE (archive = 0 OR  archive is NULL) AND (active = '2'  OR active is NULL ) ORDER BY ID DESC";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function addNewTest($id, $ref, $descp, $type) {
        $this->id = $id;
        $this->ref = $ref;
        $this->descp = $descp;
        $this->type = $type;



        $sql2 = sprintf("INSERT INTO %s.smart_test(
							b_id,uniqueReference,desc_t,test_type)
							VALUES($this->id,'$this->ref','$this->descp','$this->type'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->bctId = customLastInsertId($this->dbHand, 'smart_test', 'ID');

        return $this->bctId;
    }

    public function addBCPactionNew1777Test($id, $act, $who, $ref, $active, $time, $list, $file, $group, $comment, $bu) {
        $this->id = $id;
        $this->act = $act;
        $this->who = $who;
        $this->bu = $bu;
        $this->ref = $ref;
        $this->active = $active;
        $this->time1 = $time;
        $this->list1 = $list;
        $this->file = $file;
        $this->group = $group;
        $this->comment = $comment;


        $sql2 = sprintf("INSERT INTO %s.smart_action_test(
							a_id,action,who,ref,comment,active,time,list,file_name,group_a,bu)
							VALUES($this->id,'$this->act','$this->who','$this->ref','$this->comment','$this->active'
							,'$this->time1','$this->list1','$this->file','$this->group','$this->bu'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->incidenceId = customLastInsertId($this->dbHand, 'smart_action_test', 'ID');
        //$pStatement2->errorInfo();
        return $this->incidenceId;
    }

    public function editBCPactiveNew2($id) {


        $this->id = $id;

        $sql2 = sprintf(" UPDATE %s.smart_new_bcp SET
						
					
						active = 2
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editBCP119984($id, $who, $act, $ref, $time, $list, $BCPref, $BIRef, $comment) {

        $this->who = $who;
        $pieces = explode(" ", $this->who);
        //$data = $this->getBCPnam($pieces['0'], $pieces['1']);
        //dump_array($data);
        //exit;
        // $w = $data['participantID'];

        $this->act = $act;
        $this->ref = $ref;
        $this->id = $id;

        $Date = date('Y-m-d');
        if ($list == 'Hours' || $list == 'Hour' ) {

            $due_date = date('Y-m-d', strtotime($Date . ' + 1 days'));
        }
        elseif ($list == 'Days' || $list == 'Day') {
            $due_date = date('Y-m-d', strtotime($Date . ' + ' . $time . ' days'));
        }
        elseif ($list == 'Month' || $list == 'Months') {
            $due_date = date('Y-m-d', strtotime($Date . ' + ' . $time . ' months'));
        }
else
    $due_date = date('Y-m-d');

        $sql2 = sprintf("INSERT INTO %s.actions(
                              				moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
							VALUES('bcp','$this->act','$this->who','$due_date','$this->who',1,'$this->who',$this->id,'smart_action_list'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'actions', 'ID');

        $sql2 = sprintf(" UPDATE %s.smart_action_list SET
						
						actionID = '$this->BCPId'
						
				
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $sql = "SELECT * FROM %s.smart_action_list WHERE actionID = '" . $this->BCPId . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql1 = "SELECT * FROM %s.smart_action WHERE ID = " . $result['a_id'];

        $psql = sprintf($sql1, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result1 = $stmt->fetch(PDO::FETCH_ASSOC);


        $emailObj = new actionEmailHelper($this->BCPId);
        $who = $emailObj->getwhoDetails();
//bobchanges
        $data = array(
            'singleColData' => array(
                'comment' => '<strong>Comment</strong><BR>' . $comment . '<BR><BR>'
                ,
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/bcp.php?filter_date=">CLICK</a> Here to View BIA Action<BR><BR>
                Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/get_test6.php?eid=' . $result['a_id'] . '">CLICK</a> here to view the actions<BR><BR>                
                Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyBI.php?aid=' . $this->id . '">CLICK</a> here to confirm receipt of the action',
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $BIRef
                ),
                'actionid1' => array(
                    'left' => '<strong>BCP Reference:</strong>',
                    'right' => $BCPref
                ),
                'actionid2' => array(
                    'left' => '<strong>Recovery Time</strong>',
                    'right' => $time . ' ' . $list
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An BCP Initiate Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'red');
       
    }

    public function editBCP114($record_id, $who, $whoAU, $whoAU2, $action_d, $due_date) {
        $this->record_id = $record_id;
        $this->who = $who;
        $this->whoAU = $whoAU;
        $this->whoAU2 = $whoAU2;
        $this->action_d = $action_d;
        $this->due_date = $due_date;

        $sql2 = sprintf("INSERT INTO %s.actions(
							moduleName,actionDescription,who,dueDate,whoAU,status,currentwho,record,moduleElement,addaprover)
							VALUES('bia','$this->action_d',$this->who,'$this->due_date',$this->whoAU,1,$this->who,$this->record_id,'smart-bcp',$this->whoAU2
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'actions', 'ID');

        $sql2 = sprintf(" UPDATE %s.smart_bcp SET
						
						actionID = '$this->BCPId'
						
				
						WHERE ID = $this->record_id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $sql = "SELECT * FROM %s.smart_bcp WHERE ID = " . $this->record_id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        $emailObj = new actionEmailHelper($this->incidenceId);
        $who = $emailObj->getwhoDetails();

        $sentence = array('sentence' => array("You have an action to carry out the following BCP Risk Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/smart_bcp_risk.php?filter_date=">CLICK</a> Here to View BCP Risk Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $result['uniqueReference']
                )
            )
        );


        $emailObj->appendInfo($data);


        $emailObj->sendEmail('An BCP Risk Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

        $who = $emailObj->getAUDetails();


        $sentence = array('sentence' => "You have an action to approve the following BCP Risk Action");
        $emailObj->appendInfo($sentence);
        $who = $emailObj->getAUDetails();
    }

    public function editBCP119984ttyy($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_action_list WHERE actionID = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP119984ttyybcp($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_bcp WHERE actionID = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP119984ttyybcppci($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.pci_answer WHERE actionID = '" . $this->id . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP119984ttyybcppci2($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.pciReview WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP119984ttyybcppci2q($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.pci_question_new WHERE ID = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP119984tt($id) {
        $this->id = $id;
        $sql1 = "SELECT uniqueReference FROM %s.smart_action WHERE ID = " . $id;

        $psql = sprintf($sql1, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result6 = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result6;
    }

    public function editBCP119984ttbhb($id) {
        $this->id = $id;
        $sql1 = "SELECT uniqueReference FROM %s.smart_bcpa WHERE ID = " . $id;

        $psql = sprintf($sql1, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result6 = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result6;
    }

    public function editBCP119984ttbhb1($id) {
        $this->id = $id;
        $sql1 = "SELECT * FROM %s.smart_bcpa_action WHERE action_id = " . $id;

        $psql = sprintf($sql1, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result6 = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result6;
    }

    public function editBCP119984aaaaa($id, $who, $act, $ref, $time, $list, $c) {

        $this->who = $who;
        $pieces = explode(" ", $this->who);
        $data = $this->getBCPnam($pieces['0'], $pieces['1']);

        $w = $data['participantID'];

        $this->act = $act;
        $this->ref = $ref;
        $this->id = $id;
        $this->c = $c;
        $Date = date('Y-m-d');
        if ($list == 'Hours') {

            $due_date = date('Y-m-d', strtotime($Date . ' + 1 days'));
        }
        elseif ($list == 'Days') {
            $due_date = date('Y-m-d', strtotime($Date . ' + ' . $time . ' days'));
        }
        elseif ($list == 'Month') {
            $due_date = date('Y-m-d', strtotime($Date . ' + ' . $time . ' months'));
        }
        else
$due_date = date('Y-m-d');
        
        $sql2 = sprintf("INSERT INTO %s.actions(
                                                        moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
							VALUES('bcpa','$this->act','$w','$due_date','$w',1,'$w',$this->id,'smart_bcpa_action'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'actions', 'ID');

        $sql3 = sprintf("INSERT INTO %s.smart_bcpa_action(
							ref_id,action_id,check_t)
							VALUES($this->id,$this->BCPId,'$this->c'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql3);

        $pStatement2->execute();




        $emailObj = new actionEmailHelper($this->incidenceId);
        $who = $emailObj->getwhoDetails();

        $sentence = array('sentence' => array("You have an action to carry out the following BCP Alert Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/smart_bcpa.php?filter_date=">CLICK</a> Here to View BCP Alert Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $this->ref
                )
            )
        );


        $emailObj->appendInfo($data);


        $emailObj->sendEmail('A BCP Alert Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

        $who = $emailObj->getAUDetails();


        $sentence = array('sentence' => "You have an action to approve the following BCP Alert Action");
        $emailObj->appendInfo($sentence);
        $who = $emailObj->getAUDetails();
    }

    public function getBCPnamxxxx($nam, $sur) {
        $this->nam = $nam;
        $this->sur = $sur;
        $sql = "SELECT * FROM %s.participant_database WHERE forename = '" . $this->nam . "' AND surname = '" . $this->sur . "'";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editBCP11c($id, $save, $ref_id, $n, $group) {

        $this->save = $save;

        $this->ref_id = $ref_id;
        $this->n = $n;
        $this->group = $group;
        $this->id = $id;

        $sql2 = sprintf(" UPDATE %s.smart_new_bcp SET
						
						
						c_s = '$this->save',
						n = '$this->n',
						id_r = '$this->ref_id',
						group_a = '$this->group'
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function getBCPviewNewEdit($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_new_action_back WHERE  a_id = " . $this->id;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addBCPactionNewEdit77($id, $act, $who, $ref, $time, $list, $file, $group, $eid, $bu = 0) {
        $this->id = $id;
        $this->act = $act;
        $this->who = $who;
        $this->ref = $ref;
        $this->time1 = $time;
        $this->list1 = $list;
        $this->file = $file;
        $this->group = $group;
        $this->eid = $eid;
        $this->bu = $bu;

        $sql2 = sprintf("INSERT INTO %s.smart_new_action_back(
							a_id,action,who,ref,time,list,file_name,group_a,eid,bu)
							VALUES($this->id,'$this->act','$this->who','$this->ref'
							,'$this->time1','$this->list1','$this->file','$this->group',$this->eid,'$this->bu'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function getBCPa() {

        $sql = "SELECT * FROM %s.smart_bcp";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPExportDataFull191() {

        $heading = array(array(0 => 'Reference', 1 => 'Business Unit', 2 => 'Who', 3 => 'Type', 4 => 'Description'));

        $objProcessMaster = new ProcessFlowMaster();
        $processFlowData = $objProcessMaster->displayProcessFlowsByID7();



        if (is_array($processFlowData)) {

            foreach ($processFlowData as $key => $value) {

                $b = $this->getBCPnambu($value['bu']);

                $participant_id = $value['whoID'];

                $participantObj = SetupGeneric::useModule('Participant');
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                if ($value['criticalProcess'] == 1)
                    $type = "C";
                elseif ($value['keyProcess'] == 1)
                    $type = "K";
                else
                    $type = " ";


                $result1[$key] = array($value['reference'], $value['buName'], $participant_name, $type, $value['description']);
            }
            //dump_array($bu_name);exit;
        }
        //dump_array($result1);exit;
if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;

        //dump_array($result_new);exit;
        return $result_new;
    }

    public function addProcessList($id, $action, $who, $who1, $time, $list, $file_name) {
        $this->id = $id;
        $this->action = $action;
        $this->who = $who;
        $this->who1 = $who1;
        $this->time1 = $time;
        $this->list1 = $list;
        $this->file_name = $file_name;
        $sql = sprintf("DELETE FROM %s.smart_new_process WHERE p_id = '" . $this->id . "'", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();




        $sql2 = sprintf("INSERT INTO %s.smart_new_process(
							p_id,type,descp,who,time,list,file_name)
							VALUES('$this->id','$this->action','$this->who'
							,'$this->who1','$this->time1','$this->list1','$this->file_name'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BCPId = customLastInsertId($this->dbHand, 'smart_bir', 'ID');

        return $this->BCPId;
    }

    public function addProcessList1($id, $action, $desc, $who1, $time, $list, $group, $file_name, $slID) {

        $this->id = $id;
        $this->action = $action;
        $this->desc = $desc;
        $this->who1 = $who1;
        $this->time1 = $time;
        $this->list = $list;
        $this->slID = $slID;
        $this->group = $group;
        $this->file_name = $file_name;

        $sql = sprintf("DELETE FROM %s.smart_new_process WHERE p_id = '" . $this->id . "'", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();


        for ($x = 0; $x < count($this->action); $x++) {
            $action = $this->action[$x];
            $desc = $this->desc[$x];
            $who1 = $this->who1[$x];
            $time1 = $this->time1[$x];
            $list = $this->list[$x];
            $group = $group[$x];
            $file_name = $this->file_name[$x];
            $slID = $this->slID[$x];

            $sql2 = sprintf("INSERT INTO %s.smart_new_process(
							p_id,type,descp,who,time,list,group_a,file_name,s_id)
							VALUES($this->id,'$action','$desc','$who1'
							,'$time1','$list','$group','$file_name',$slID
							)", _DB_OBJ_FULL
            );

            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();
        }
    }

    public function getBCPExportDataFull192() {

        $heading = array(array(0 => 'Reference', 1 => 'Business Unit', 2 => 'Who', 3 => 'Type', 4 => 'Description', 5 => 'Action', 6 => 'Who'));

        $objProcessMaster = new ProcessFlowMaster();
        $processFlowData = $objProcessMaster->displayProcessFlowsByID7();


        if (is_array($processFlowData)) {

            foreach ($processFlowData as $key => $value) {

                $dataa = $this->getBCPerrsp($value['swimID']);
                $k = 0;
                $des = array();
                foreach ($dataa as $v) {

                    $des[$k] = $v['descQues'];
                    $k++;
                }

                $act = implode(",", $des);


                $b = $this->getBCPnambu($value['bu']);

                $participant_id = $value['whoID'];

                $participantObj = SetupGeneric::useModule('Participant');
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                if ($value['criticalProcess'] == 1)
                    $type = "C";
                elseif ($value['keyProcess'] == 1)
                    $type = "K";
                else
                    $type = " ";


                $result1[$key] = array($value['reference'], $value['buName'], $participant_name, $type, $value['description'], $act);
            }
        }


        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;

        return $result_new;
    }

    public function getBCPExportDataFull181() {

        $heading = array(array(0 => 'Reference', 1 => 'Business Unit', 2 => 'Incidence Title', 3 => 'Description'));

        $data = $this->getbcpSerious();




        if (is_array($data)) {

            foreach ($data as $key => $value) {

                $b = $this->getBCPnambu($value['bu']);





                $result1[$key] = array($value['uniqueReference'], $b['buName'], $value['group_a'], $value['descp']);
            }
        }

        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;
        return $result_new;
    }

    public function getBCPExportDataFull182() {

        $heading = array(array(0 => 'Reference', 1 => 'Business Unit', 2 => 'Incidence Title', 3 => 'Description', 4 => 'Location', 5 => 'Recovery Time', 6 => 'Action', 7 => 'who', 8 => 'File Name'));

        $data = $this->getbcpSeriousFull();



        if (is_array($data)) {

            foreach ($data as $key => $value) {

                $action = $this->getbcpSeriousAction($value['ID']);
                //$act = implode(",", $action['action']);
                //$who = implode(",", $action['who']);
                //$file_name = implode(",", $action['file_name']);



                $b = $this->getBCPnambu($value['bu']);

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $value['loc']));
                $location_data = "";
                $location = $locObj->displaylocationByPid();






                $r = $value['time'] . '' . $value['list'];

                $result1[$key] = array($value['uniqueReference'], $b['buName'], $value['group_a'], $value['descp'], $location['name'], $r, $value['action1'], $value['who1'], $value['file_name']);
            }
        }

        if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
    $result_new = $heading;


        return $result_new;
    }

    public function getbcpSerious() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $sql = "SELECT * FROM %s.smart_serious WHERE isnull(archive,0)=%d order by ID desc";
        $psql = sprintf($sql, _DB_OBJ_FULL,$archive);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpSeriousAction($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_serious_action WHERE s_id = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpSevere() {
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $sql = "SELECT * FROM %s.smart_severe WHERE isnull(archive,0)=%d order by ID desc";
        $psql = sprintf($sql, _DB_OBJ_FULL,$archive);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getbcpSevereAction($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.smart_severe_action WHERE s_id = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getBCPerrspr1() {

        $sql = "SELECT * FROM %s.swimlane WHERE bcp = 1";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function editstandard1($id, $action, $who, $file) {

        $this->action = $action;
        $this->who = $who;
        $this->file = $file;

        $this->id = $id;


        $sql2 = sprintf(" UPDATE %s.smart_standard SET
						
					
						action = '$this->action',
						who = '$this->who',
						file_name = '$this->file'
						
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editsevere1($id, $action, $who, $file) {

        $this->action = $action;
        $this->who = $who;
        $this->file = $file;

        $this->id = $id;


        $sql2 = sprintf(" UPDATE %s.smart_severe SET
						
					
						action = '$this->action',
						who = '$this->who',
						file_name = '$this->file'
						
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function editserious1($id, $action, $who, $file) {



        $this->action = $action;
        $this->who = $who;
        $this->file = $file;

        $this->id = $id;


        $sql2 = sprintf(" UPDATE %s.smart_serious SET
						
						
						action = '$this->action',
						who = '$this->who',
						file_name = '$this->file'
						
						
						WHERE ID = $this->id", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function addApps($title, $bus) {
        $this->title = $title;
        $this->bus = $bus;

        $sql2 = sprintf("INSERT INTO %s.smart_bcp_apps (title,bus)	VALUES('%s','%s'	)", _DB_OBJ_FULL, $this->title, $this->bus);
        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function editApps($id, $title, $bus) {
        $this->title = $title;
        $this->bus = $bus;
        $this->id = $id;

        $sql2 = sprintf("Update %s.smart_bcp_apps set title='%s',bus='%s' where ID=%d", _DB_OBJ_FULL, $this->title, $this->bus, $this->id);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function displayBCPApps() {

        $sql = sprintf("select * from %s.smart_bcp_apps where isnull(archive,0)=0", _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function displayBCPAppsa() {

        $sql = sprintf("select * from %s.smart_bcp_apps where isnull(archive,0)=1", _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getBCPApps($id) {

        $sql = sprintf("select * from %s.smart_bcp_apps where ID=%d", _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function archiveBCPapps() {

        $sql = "UPDATE %s.smart_bcp_apps SET archive = %d WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPInfo['archive'], $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function getBCPExportDataApps() {
        $objOrg = SetupGeneric::useModule('Organigram');
        $heading = array(array(0 => 'Title', 1 => 'Business Unit'));
$archive = (int) Session::getSessionField('ARCHIVE_RECORDS');
if ($archive ==1)
        $bcp_data = $this->displayBCPAppsa();
else
 $bcp_data = $this->displayBCPApps();
        //dump_array($equipment_data);exit;


        if (is_array($bcp_data)) {

            foreach ($bcp_data as $key => $value) {

                $b = $objOrg->getLawCoNames($value['bus']);
                $title = $value['title'];

                $result1[$key] = array($title, $b);
            }
            //dump_array($bu_name);exit;
        }
if(is_array($result1))
        $result_new = array_merge($heading, $result1);
else
 $result_new =$heading;

        return $result_new;
    }

    public function getCascadeRootData($id) {

      $sql = "select * from %s.smart_bcp_cascade WHERE parentID =0 and archive=0 and groupid=%d";

     $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getRole($id) {

        $sql = "select * from %s.smart_bcp_cascade WHERE ID =%d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getCascadeChildData($id) {

        $sql = "select * from %s.smart_bcp_cascade WHERE parentID =%d and archive=0";

        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $resultc = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultc;
    }

    public function getCascadeRoles($link) {

        $sql = "select T.*,P1.forename + ' '+P1.surname as p1name from %s.smart_bcp_cascade_team T left join %s.participant_database P1 on T.part_ID=P1.participantID  where T.archive=0 and link=%d order by parent_partID,backup_type";

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $link);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);


        return $results;
    }

    public function getCascadePerson($id) {

        $sql = "select T.*,P1.forename + ' '+P1.surname as p1name from %s.smart_bcp_cascade_team T left join %s.participant_database P1 on T.part_ID=P1.participantID  where id=%d ";

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function addrole($id, $role, $shortrole, $group) {

        $sql = "insert into %s.smart_bcp_cascade (role,parentid,short_role,groupID) values ('%s',%d,'%s',%d) ";

        $psql = sprintf($sql, _DB_OBJ_FULL, $role, $id, $shortrole, $group);

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function editrole($id, $role, $shortrole) {

        $sql = "update %s.smart_bcp_cascade set role='%s',short_role='%s' where ID=%d ";

        $psql = sprintf($sql, _DB_OBJ_FULL, $role, $shortrole, $id);
        $stmt = $this->dbHand->prepare($psql);
       $stmt->execute();
    }

    public function addperson($id, $data) {

        $sql = "insert into  %s.smart_bcp_cascade_team (link,role,tel,mobile,part_ID,backup_type) VALUES (%d,'%s','%s','%s',%d,%d)";

        $psql = sprintf($sql, _DB_OBJ_FULL, $id, $data["title"], $data["tel"], $data["mobile"], $data["partID"], $data["type"]);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();
        $this->BCPId = customLastInsertId($this->dbHand, 'smart_bcp_cascade_team', 'ID');

        $sql = "update %s.smart_bcp_cascade_team set parent_partID='%d' where ID=%d ";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->BCPId, $this->BCPId);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();
    }

    public function addbackup($id, $data) {

        $sql = "insert into  %s.smart_bcp_cascade_team (link,role,tel,mobile,part_ID,backup_type,parent_partID) VALUES (%d,'%s','%s','%s',%d,%d,%d)";

        $psql = sprintf($sql, _DB_OBJ_FULL, $data["link"], $data["title"], $data["tel"], $data["mobile"], $data["partID"], $data["type"], $id);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();
    }

    public function editperson($id, $data) {

      $sql = "update %s.smart_bcp_cascade_team set role='%s',tel='%s',mobile='%s',part_ID='%d' where ID=%d ";

       $psql = sprintf($sql, _DB_OBJ_FULL, $data["title"], $data["tel"], $data["mobile"], $data["partID"], $id);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();
    }

    public function display_it() {

        $sql = "select * from %s.smart_bcp_it where archive=0";

        $sql_p = sprintf($sql, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $data;
    }

    public function getResource($id) {

        $sql = "select * from %s.smart_bcp_it where archive=0 and buid=%d";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $data;
    }

    public function addResource($id, $bu, $pc, $laptops, $ipphone, $mobile, $printer, $information) {

        $sql = "update %s.smart_bcp_it set archive = 1 where buid = %d";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $bu);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        $sql = "insert into %s.smart_bcp_it (buID, pcs, laptops, IPPhone, mobile, printer, Information) values (%d,%d,%d,%d,%d,%d,'%s')";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $bu, $pc, $laptops, $ipphone, $mobile, $printer, $information);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();
    }

    public function getResourceGroups() {

        $sql = "select * from %s.smart_bcp_group";
        $sql_p = sprintf($sql, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $data;
    }

    public function getUsedResource() {

        $sql = "select bu from %s.smart_serious_action union select bu from %s.smart_severe_action union select bu from %s.smart_standard_action union select buID from %s.business_units where isBCP=1";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $data;
    }

    private function getChildrenNew($p_section_data) {

        $tree_html = "";

        foreach ($p_section_data as $section_data_elenew) {
            $id = $section_data_elenew["ID"];
            $group = $section_data_elenew["groupID"];
            $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'] . "<span class='expandable'>";
            $tree_html .= "&nbsp;" . $section_data_elenew['short_role'] . " " . $section_data_elenew['role'] . "&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";

            //  $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('archive_document.php?id=" . $id . "','Archive','width=600,height=300,scrollbars=yes').focus()\">Archive</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('add_role.php?id=" . $id . "&group=" . $group . "','Add','width=500,height=300,scrollbars=yes').focus()\">Add </a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_role.php?id=" . $id . "','edit_doc','width=700,height=300,scrollbars=yes').focus()\">Edit</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('add_person.php?id=" . $id . "','add_person','width=700,height=600,scrollbars=yes').focus()\">Add Person</a>  ";


            $roles = $this->getCascadeRoles($section_data_elenew["ID"]);
            //dump_array($roles);
            if (is_array($roles)) {
                foreach ($roles as $role) {


                    $rel = $role["ID"];
                    if ($role["backup_type"] == 1)
                        $style = "style='padding-left:100px'";
                    else
                        $style = "style='padding-left:60px'";

                    $tree_html .= "<P><SPAN " . $style . ">" . $role["role"] . "&nbsp;" . $role["p1name"] . "&nbsp;" . $role["mobile"] . "&nbsp;" . $role["tel"] . "&nbsp;|&nbsp;</SPAN>";

                    if ($role["backup_type"] == 1)
                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_backup.php?id=" .$role["ID"] . "','edit_doc','width=700,height=600,scrollbars=yes')\">Edit Backup Person</a> | ";

                    else {
                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_person.php?id=" . $rel . "','edit_doc','width=700,height=600,scrollbars=yes')\">Edit Person</a> | ";
                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('add_backup.php?id=" . $rel . "&link=" . $role["link"] . "','edit_doc','width=700,height=600,scrollbars=yes')\">Add Backup Person</a> | ";
                    }
                    //$tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";
                    //$tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";


                    $tree_html .= "</SPAN></P>";
                }
            }
            $tree_html .= "</span><ul>";


            $section_dataNew = $this->getCascadeChildData($section_data_elenew["ID"]);
            $count = count($section_dataNew);

            if ($count) {
                $tree_html .= $this->getChildrenNew($section_dataNew);
            }

            $tree_html .= "</ul>";
            $tree_html .= "</li>";
        }

        return $tree_html;
    }

    public function getTreeNew($id) {

        $cas_data = $this->getCascadeRootData($id);
        

        $tree_html = "<div id='sidetree' class='filetree'>";

        $tree_html .= "<div id='sidetreecontroller' style='text-align: center'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

        $tree_html .= "<DIV id='graph_container'><ul class='treeview' id='dmstree'>";


        foreach ($cas_data as $section_data) {
            $id = $section_data["ID"];
            $group = $section_data["groupID"];
            $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            $tree_html .= "<span id='loader_block_" . $id . "' >" . $section_data['short_role'] . " " . $section_data['role'] . "</span> | ";

            //$tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('archive_document.php?id=" . $id . "','Archive','width=600,height=300,scrollbars=yes').focus()\">Archive</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('add_role.php?id=" . $id . "&group=" . $group . "','Add','width=500,height=300,scrollbars=yes').focus()\">Add </a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_role.php?id=" . $id . "','edit_doc','width=700,height=300,scrollbars=yes').focus()\">Edit</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('add_person.php?id=" . $id . "','add_person','width=700,height=600,scrollbars=yes').focus()\">Add Person</a>  ";


            $roles = $this->getCascadeRoles($section_data["ID"]);
            
            if (is_array($roles)) {
                foreach ($roles as $role) {


                    $relID = $role["ID"];

                    $rel = $section_data['short_role'] . " " . $section_data['role'];
                    if ($role["backup_type"] == 1)
                        $style = "style='padding-left:100px'";
                    else
                        $style = "style='padding-left:60px'";

                    $tree_html .= "<P><SPAN " . $style . ">" . $role["role"] . "&nbsp;" . $role["p1name"] . "&nbsp;" . $role["mobile"] . "&nbsp;" . $role["tel"] . "&nbsp;|&nbsp;</SPAN>";

                    $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                    $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";

                    // $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                    // $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                    if ($role["backup_type"] == 1)
                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_backup.php?id=" . $role["ID"] . "','edit_doc','width=700,height=300,scrollbars=yes')\">Edit Backup Person</a> | ";

                    else {
                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_person.php?id=" . $relID . "','edit_doc','width=700,height=600,scrollbars=yes')\">Edit Person</a> | ";

                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('add_backup.php?id=" . $role["ID"] . "&link=" . $role['link'] . "','edit_doc','width=700,height=600,scrollbars=yes')\">Add Backup Person</a> | ";
                    }
                    // $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";
                    // $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                }
            }

            $tree_html .= "</SPAN></P>";

            $tree_html .= "</span><ul>";


            $section_dataNew = $this->getCascadeChildData($section_data["ID"]);


            if (is_array($section_dataNew)) {
                $tree_html .= $this->getChildrenNew($section_dataNew);
            }

            $tree_html .= "</ul>";
            $tree_html .= "</li>";
        }

        $tree_html .= "</ul></DIV></div>";



        return $tree_html;
    }

    public function getBCPCascadeTeam($group, $str) {

        $search = $str . "%";

        $sql = sprintf("select P.participantID,P.worksNumber,P.forename,P.surname+' ('+C.short_role+')' as surname from %s.smart_bcp_cascade_team T left join %s.smart_bcp_cascade C on T.link=C.ID inner join %s.participant_database P on T.part_ID=P.participantID where T.backup_type=0 and groupID=%d and P.archive=0 and forename LIKE '%s'", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $group, $search);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


        if (is_array($result)) {
            return 0;
        } else {
            return 0;
        }
    }

    public function getBCPCascadeBackupTeam($aid, $pid, $str) {
        $auObj = SetupGeneric::useModule('Participant');
        $search = $str . "%";

        $sql = sprintf("select * from %s.smart_action_new  where ID=%d", _DB_OBJ_FULL, $aid);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        //find       
        $sql = sprintf("select resource_group from %s.smart_severe where uniquereference='%s' 
            union select resource_group from %s.smart_standard where uniquereference='%s' 
            union select resource_group from %s.smart_severe where uniquereference='%s'"
                , _DB_OBJ_FULL, $result["ref"], _DB_OBJ_FULL, $result["ref"], _DB_OBJ_FULL, $result["ref"]);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!isset($result["resource_group"])) {


            $auObj->setItemInfo(array('id' => 1, 'forename' => $str));
            $result = $auObj->displayBCPByForename();
        } else {
            $result = $this->getBCPBackups($result["resource_group"], $pid);
        }


        if (is_array($result)) {
            return $result;
        } else {
            return $auObj->displayBCPByForename();
        }
    }

        public function getIinitiateTeam($group) {

        $sql = sprintf("select P.participantID,P.worksNumber,P.forename,P.surname+' ('+C.short_role+')' as surname from %s.smart_bcp_cascade_team T left join %s.smart_bcp_cascade C on T.link=C.ID inner join %s.participant_database P on T.part_ID=P.participantID where groupID=%d ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $group);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


        if (is_array($result)) {
            return $result;
        } else {
            return 0;
        }
    }
    
    public function getBCPBackups($link, $pid) {

        $sql = sprintf("select T.ID from %s.smart_bcp_cascade_team T inner join %s.smart_bcp_cascade C on T.link=C.ID where groupid=%d and part_ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $link, $pid);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result1 = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf(" select P.forename,P.participantID,P.worksNumber,P.surname+' *' as surname from %s.smart_bcp_cascade_team T left join %s.participant_database P on T.part_id=P.participantID where not part_ID=%d and parent_partID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $pid, $result1["ID"]);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultBackup = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $sql = sprintf("select P.forename,P.participantID,P.worksNumber,P.surname from %s.smart_bcp_cascade_team T inner join %s.smart_bcp_cascade C on T.link=C.ID left join %s.participant_database P on T.part_id=P.participantID where groupid=%d ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $link);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultMain = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($resultMain as $row) {
            $resultBackup[] = $row;
        }



        return $resultBackup;
    }

    public function notifytest1($aid, $pid) {
        $sql = sprintf("update %s.smart_action_test set endtime=getdate() where a_id=%d and who =%d and isnull(endtime,0)=0", _DB_OBJ_FULL, $aid, $pid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function notifyBI($aid) {
     $sql = sprintf("update %s.smart_action_list set responsetime=getdate() where ID=%d and isnull(responsetime,0)=0", _DB_OBJ_FULL, $aid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

        public function notifyBIAlert($aid) {
     $sql = sprintf("update %s.smart_action_list set responsetime=getdate() where a_id_link=%d and isnull(responsetime,0)=0", _DB_OBJ_FULL, $aid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }
    
    public function notifyE($aid) {
        $sql = sprintf("update %s.smart_bcp_init_emails set responsetime=getdate() where ID=%d and isnull(responsetime,0)=0", _DB_OBJ_FULL, $aid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function sendPreBIEmails($id, $who, $act, $ref, $time, $list, $bu, $BCPid, $BIRef, $comment, $file, $group) {

        $this->who = $who;
        $this->act = $act;
        $this->ref = $ref;
        $this->id = $id;
        $this->BCPid = $BCPid;
        $this->time = $time;
        $this->list = $list;
        $this->bu = $bu;
        $this->file = $file;
        $this->group = $group;
        $due_date = date('Y-m-d');


        $sql2 = sprintf("INSERT INTO %s.smart_action_list(
							a_id,action,who,ref,active,time,list,file_name,group_a,bu,a_id_link)
							VALUES($this->BCPid,'$this->act','$this->who','$this->ref','1'
							,'$this->time','$this->list','$this->file','$this->group','$this->bu','$this->id'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->BIId = customLastInsertId($this->dbHand, 'smart_action_list', 'ID');

        $sql2 = sprintf("INSERT INTO %s.actions(
                              				moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
							VALUES('bcp','$this->act','$this->who','$due_date','$this->who',1,'$this->who',$this->BIId ,'smart_action_list'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $this->BCPAId = customLastInsertId($this->dbHand, 'actions', 'ID');


        $sql2 = sprintf("update  %s.smart_action_list set actionID=$this->BCPAId where ID=$this->BIId", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $sql2 = sprintf("select * from  %s.smart_new_bcp where ID=$this->BCPid", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $result1 = $pStatement2->fetch(PDO::FETCH_ASSOC);

        $emailObj = new actionEmailHelper($this->BCPAId);
        $who = $emailObj->getwhoDetails();

        $data = array(
            'singleColData' => array(
                'comment' => '<strong>Comment</strong><BR>' . $comment . '<BR><BR>'
                ,
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/bcp.php?filter_date=">CLICK</a> Here to View BCP Initiate Action<BR><BR>
                Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyBI.php?aid=' . $this->BCPAId . '">CLICK</a> here to confirm receipt of the action',
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $BIRef
                ),
                'actionid1' => array(
                    'left' => '<strong>BCP Reference:</strong>',
                    'right' => $result1['uniqueReference']
                ),
                'actionid2' => array(
                    'left' => '<strong>Recovery Time</strong>',
                    'right' => $time . ' ' . $list
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An BCP Initiate Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'red');

        return $this->BCPAId;
    }

    public function sendBIEmails($id, $who, $act, $ref, $time, $list, $bu, $BCPid, $BIRef, $comment, $file, $group) {

        $this->who = $who;
        $this->act = $act;
        $this->ref = $ref;
        $this->id = $id;
        $this->BCPid = $BCPid;
        $this->time = $time;
        $this->list = $list;
        $this->bu = $bu;
        $this->file = $file;
        $this->group = $group;
        $due_date = date('Y-m-d');


        $this->BIId = $this->id;

        $sql2 = sprintf("INSERT INTO %s.actions(
                              				moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
							VALUES('bcp','$this->act','$this->who','$due_date','$this->who',1,'$this->who',$this->BIId ,'smart_action_list'
							)", _DB_OBJ_FULL
        );

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $this->BCPAId = customLastInsertId($this->dbHand, 'actions', 'ID');


        $sql2 = sprintf("update  %s.smart_action_list set actionID=$this->BCPAId where ID=$this->BIId", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $sql2 = sprintf("select * from  %s.smart_new_bcp where ID=$this->BCPid", _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $result1 = $pStatement2->fetch(PDO::FETCH_ASSOC);

        $emailObj = new actionEmailHelper($this->BCPAId);
        $who = $emailObj->getwhoDetails();

        $data = array(
            'singleColData' => array(
                'comment' => '<strong>Comment</strong><BR>' . $comment . '<BR><BR>'
                ,
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/bcp.php?filter_date=">CLICK</a> Here to View BCP Initiate Action<BR><BR>
                Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyBI.php?aid=' . $this->BIId . '">CLICK</a> here to confirm receipt of the action',
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $BIRef
                ),
                'actionid1' => array(
                    'left' => '<strong>BCP Reference:</strong>',
                    'right' => $result1['uniqueReference']
                ),
                'actionid2' => array(
                    'left' => '<strong>Recovery Time</strong>',
                    'right' => $time . ' ' . $list
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An BCP Initiate Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'red');

        return $this->BCPAId;
    }

    public function updateBCPInitiate($rid, $aid) {
        $sql = sprintf("update %s.smart_action_list set a_id=%d where actionID=%d ", _DB_OBJ_FULL, $rid, $aid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function updateReassign($action_id, $date, $reason, $who, $action, $action_str) {

        $atObj = new ActionTracker();
        $this->action_id = $action_id;
        $this->date_due = $date;
        $this->who = $who;
        $this->reason = $reason;

        $sql = sprintf("select * from %s.actions WHERE ID =" . $this->action_id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $resultA = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf("UPDATE %s.actions
				SET
				rejectreason = '" . $this->reason . "',
                                doneDescription='This action has been reassigned',
                                doneDate='" . date("Y-m-d") . "',
                                approveAU=1
				WHERE ID =" . $this->action_id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();


        $emailObj = new actionEmailHelper($action_id);

        $who = $emailObj->getwhoDetails();

        $recordData = $atObj->getRecordData($action_id);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/bcp.php?filter_date=">CLICK</a> Here to View ' . $module . ' Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $recordData['reference']
                ),
                'reason' => array(
                    'left' => '<strong>Reason Reassigned</strong>',
                    'right' => 'This action has been reassigned for the following reason.<BR>' . $reason
                )
            )
        );

        $emailObj->appendInfo($data);

        $emailObj->sendEmail('BCP Action has Been Reassigned', $who, array(), array(), 'me_completed', '', 'grey');



        $sql2 = sprintf("INSERT INTO %s.actions(moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
							VALUES('bcp','%s','%s','%s','%s',1,'%s',%d ,'smart_action_list'
							)", _DB_OBJ_FULL, $resultA["actionDescription"], $this->who, $this->date_due, $this->who, $this->who, $resultA["record"]
        );

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $this->BCPAId = customLastInsertId($this->dbHand, 'actions', 'ID');


        $sql2 = sprintf("update  %s.smart_action_list set actionID=$this->BCPAId,who=%d where ID=%d", _DB_OBJ_FULL, $this->who, $resultA['record']);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        //  $sql2 = sprintf("select * from  %s.smart_new_bcp where ID=%d", _DB_OBJ_FULL,$resultA['record']);
        $sql2 = sprintf("select * from %s.smart_action_list L  left join %s.smart_action S on L.a_id=S.ID  where L.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $resultA['record']);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $result1 = $pStatement2->fetch(PDO::FETCH_ASSOC);

        $emailObj = new actionEmailHelper($this->BCPAId);
        $who = $emailObj->getwhoDetails();

        $data = array(
            'singleColData' => array(
                'comment' => '<strong>Comment</strong><BR>' . $comment . '<BR><BR>'
                ,
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/bcp.php?filter_date=">CLICK</a> Here to View BCP Initiate Action<BR><BR>
                Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyBI.php?aid=' . $this->BCPAId . '">CLICK</a> here to confirm receipt of the action',
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $result1['uniqueReference']
                ),
                'actionid2' => array(
                    'left' => '<strong>Recovery Time</strong>',
                    'right' => $result1['time'] . ' ' . $result1['list']
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An BCP Initiate Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'red');
    }

    public function checkInitiate($bcp_id, $initiate_id) {

        $sql2 = sprintf("select * from  %s.smart_action_new N where N.a_id =%d and not ID in  (select  a_id_link from %s.smart_action_list where a_id=%d)", _DB_OBJ_FULL, $bcp_id, _DB_OBJ_FULL, $initiate_id);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        $result1 = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result1 as $row) {

            $sql2 = sprintf("INSERT INTO %s.smart_action_list(
							a_id,action,who,ref,active,time,list,file_name,group_a,bu,a_id_link)
							VALUES(%d,'%s','%s','%s','1','%s','%s','%s','%s','%s','%d'
							)", _DB_OBJ_FULL, $initiate_id, $row["action"], $row["who"], $row["ref"], $row["time"], $row["list"], $row["file"], $row["group_a"], $row["bu"], $row["ID"]
            );

            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();
        }
    }

    public function get_apps($p_bu_id) {

        $sql = "select * from %s.smart_bcp_apps where ','+bus+',' like '%s'";
        $buStr = "%," . $p_bu_id . ",%";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $buStr);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 0;

        foreach ($data as $row) {


            $rowStr .= "<TD width=150px>" . $row["title"] . "</TD>";
            $i++;
            if ($i % 8 == 0)
                $rowStr .= "</TR><TR>";
        }

        return $rowStr;
    }

    public function get_apps1($p_bu_id) {

        $sql = "select * from %s.smart_bcp_apps where ','+bus+',' like '%s'";
        $buStr = "%," . $p_bu_id . ",%";
        $sql_p = sprintf($sql, _DB_OBJ_FULL, $buStr);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 0;

        foreach ($data as $row) {


            $rowStr .= "\$table->addCell(8000)->addText('" . $row["title"] . "',array('color'=>'black','size' =>9));";
            $i++;
            if ($i % 8 == 0)
                $rowStr .= "$table->addRow();";
        }

        return $data;
    }

    public function get_it($p_bu_id) {

        $sql = "select * from %s.smart_bcp_it where buID= %d";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $data;
    }

    public function get_participant_name($p_participant_id) {

        $sql = sprintf("SELECT forename,surname FROM %s.participant_database WHERE participantID = %d ", _DB_OBJ_FULL, $p_participant_id);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$p_participant_id);
        $pStatement->execute();
        list($first_name, $last_name) = $pStatement->fetch();
        return $first_name . ' ' . $last_name;
    }

    public function get_bu_name($p_bu_id) {

        $sql = 'SELECT acc FROM %s.business_units WHERE buID = %d';

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        return $pStatement->fetchColumn();
    }

    public function get_bu_name_1_2($p_bu_id) {

        $sql = 'SELECT buName FROM %s.business_units WHERE buID = %d';

        $sql_p = sprintf($sql, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        return $pStatement->fetchColumn();
    }

    public function getReportDataNEWSEVERE2A_N($id) {
        $this->id = $id;
        $bcpObj = new BCPMain();
        $datab = $bcpObj->getBCPerrsv($this->id);
        $dataa = $bcpObj->getbcpSevereAction($this->id);

        $k = 1;
        foreach ($dataa as $rows) {

            if (!$outData[bu][$rows["bu"]]) {
                //$outData[bu][$rows["bu"]]["apps"] = $this->get_apps($rows["bu"]);
                $report_data["apps"][$rows["bu"]] = $this->get_apps($rows["bu"]);
                $report_data["it"][$rows["bu"]] = $this->get_it($rows["bu"]);
            }
            $outData[bu][$rows["bu"]][$k] = $rows;
            $outData[bu][$rows["bu"]][$k]["buName"] = $this->get_bu_name($rows["bu"]);
            $outData[bu][$rows["bu"]][$k]["whoName"] = $this->get_participant_name($rows["who"]);
            $outData[bu][$rows["bu"]][$k]["whoBackup"] = $this->get_participant_name($rows["who"]);

            $k++;
        }
        $report_data['report_data'] = $outData;
//dump_array($report_data["report_data"]);
        //$report_data['report_head'] = false;
        // if ($this->filters['heading']) {
        //$report_data['report_head'] = true;
        //  }
        //var_dump($report_data);
        return $outData;
    }

    public function get_severe_bu($p_bu_id) {

        $sql = "select A.*,S.uniqueReference as ref,S.des,P.forename+ ' '+ P.surname as displayname from %s.smart_severe_action A inner join %s.smart_severe S on A.s_id=S.ID left join %s.participant_database P on A.who=P.participantID where isnull(S.archive,0)=0 and A.bu=%d";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_standard_bu($p_bu_id) {

        $sql = "select A.*,S.uniqueReference as ref,S.des,P.forename+ ' '+ P.surname as displayname from %s.smart_standard_action A inner join %s.smart_standard S on A.s_id=S.ID left join %s.participant_database P on A.who=P.participantID where isnull(S.archive,0)=0 and A.bu=%d";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_serious_bu($p_bu_id) {

        $sql = "select A.*,S.uniqueReference as ref,S.des,P.forename+ ' '+ P.surname as displayname from %s.smart_serious_action A inner join %s.smart_serious S on A.s_id=S.ID left join %s.participant_database P on A.who=P.participantID where isnull(S.archive,0)=0 and A.bu=%d";

        $sql_p = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql_p);
        $pStatement->execute();

        return $pStatement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getBIAEventString($idStr) {

        $sql = "SELECT * FROM %s.smart_desi WHERE ID in (%s)";

        $psql = sprintf($sql, _DB_OBJ_FULL, $idStr);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $row)
            $eventStr .= $row["name"] . ", ";
        return substr($eventStr, 0, -2);
    }

    public function saveAlertData() {
        $participantObj = SetupGeneric::useModule('Participant');
        $sql2 = sprintf("INSERT INTO %s.smart_bcp_initiate(
							description,reason,who_reported,first_emails)
							VALUES('%s','%s',%d,'%s'
							)", _DB_OBJ_FULL, $this->BCPInfo["descript"], $this->BCPInfo["reason"], $this->BCPInfo["who"], $this->BCPInfo["emails"]
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $this->ID = customLastInsertId($this->dbHand, 'smart_bcp_Initiate', 'ID');

        /*     $sql2 = sprintf("INSERT INTO %s.actions(
          moduleName,actionDescription,who,dueDate,whoAU,status,currentWho,record,moduleElement)
          VALUES('bcp','$this->act','$this->who','$due_date','$this->who',1,'$this->who',$this->BIId ,'smart_action_list'
          )", _DB_OBJ_FULL
          );

          $pStatement2 = $this->dbHand->prepare($sql2);
          $pStatement2->execute();
          $this->BCPAId = customLastInsertId($this->dbHand, 'actions', 'ID');


          $sql2 = sprintf("update  %s.smart_action_list set actionID=$this->BCPAId where ID=$this->BIId", _DB_OBJ_FULL);

          $pStatement2 = $this->dbHand->prepare($sql2);
          $pStatement2->execute();

          $sql2 = sprintf("select * from  %s.smart_new_bcp where ID=$this->BCPid", _DB_OBJ_FULL);

          $pStatement2 = $this->dbHand->prepare($sql2);
          $pStatement2->execute();

          $result1 = $pStatement2->fetch(PDO::FETCH_ASSOC);
         */
        $emailObj = new actionEmailHelper(0);
        $emailArr = explode(",", $this->BCPInfo["emails"]);

        $participantObj->setItemInfo(array('id' => $this->BCPInfo["who"]));
        $partcipantData = $participantObj->displayItemById();

        $whosender = array(
            'displayname' => ucwords($partcipantData['forename'] . ' ' . $partcipantData['surname']),
            'email' => $partcipantData['emailAddress']
        );
        foreach ($emailArr as $value) {

            $participantObj->setItemInfo(array('id' => $value));
            $partcipantData = $participantObj->displayItemById();


            $who = array(
                'displayname' => ucwords($partcipantData['forename'] . ' ' . $partcipantData['surname']),
                'email' => $partcipantData['emailAddress']
            );

            $data = array(
                'singleColData' => array(
                    'comment' => ' '
                    ,
                    'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/start_initiate.php?id=' . $this->ID . '">CLICK</a> here to Initiate a BCP',
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Description:</strong>',
                        'right' => $this->BCPInfo["descript"]
                    ),
                    'assignedto' => array(
                        'left' => '<strong>Assigned to:</strong>',
                        'right' => $who["displayname"]
                    ),
                    'due' => array(
                        'left' => '<strong>Due Date:</strong>',
                        'right' => date("m/d/Y")
                    ),
                    'actionid1' => array(
                        'left' => '<strong>Reason:</strong>',
                        'right' => $this->BCPInfo["reason"]
                    ),
                    'actionid2' => array(
                        'left' => '<strong>Sender:</strong>',
                        'right' => $whosender["displayname"]
                    )
                )
            );


            $emailObj->appendInfo($data);

            $emailObj->sendEmail('A BCP Initiate Alert To Be Carried Out', $who, array(), array(), 'me_completed', '', 'red');
        }
    }

    public function getAlertData($id) {

        $sql2 = sprintf("SELECT * FROM  %s.smart_bcp_initiate where ID=%d", _DB_OBJ_FULL, $id);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
        $result = $pStatement2->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getChildrenRolesNew($p_section_data) {


        foreach ($p_section_data as $section_data_elenew) {

            $roles1 = $this->getCascadeRoles($section_data_elenew["ID"]);

            $section_dataNew = $this->getCascadeChildData($section_data_elenew["ID"]);
            $count = count($section_dataNew);

            if ($count) {
                $roles2 = $this->getChildrenRolesNew($section_dataNew);
                if ($roles2)
                    $roles = array_merge($roles1, $roles2);
                else
                    $roles = $roles1;
            }
        }

        return $roles;
    }



function execInBackground($cmd) { 
    if (substr(php_uname(), 0, 7) == "Windows"){ 
        pclose(popen("start /B " . $cmd, "r")); 
       
    } 
    else { 
        exec($cmd . " > /dev/null &");   
       
    } 
   
}

    
    public function beginInitiate() {

        $sql2 = sprintf("update %s.smart_bcp_initiate set 
 person_avail=%d
,equip_avail=%d
,recovery_time=%d
,valid=%d
,who_initiated=%d
,email_message='%s'
where id=%d ", _DB_OBJ_FULL
                , $this->BCPInfo["person_avail"]
                , $this->BCPInfo["equip_avail"]
                , $this->BCPInfo["recovery_time"]
                , $this->BCPInfo["valid"]
                , $this->BCPInfo["who"]
                , $this->BCPInfo["email"]
                , $this->BCPId
        );
        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
      //$sendStr= $_SERVER['DOCUMENT_ROOT'] . "/cron/phpbciemails.bat ".$_SERVER["HTTP_HOST"]." ".$this->BCPId." 2>&1 & echo $!";

      //  exec($sendStr, $output);
      //  $this->sendWarningInitiateEmails($this->BCPId);

    }

    public function prepareInitiateEmails($id) {
        $wget="C:\php\wget.exe ";
        $srv="https://" . $_SERVER['HTTP_HOST'];
        $cmd = $wget.$srv. '/cron/bcpemails.php?id='.$id." &";
        $this->execInBackground($cmd);    
        
    }
    public function sendWarningInitiateEmails($id) {
        require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/infoEmail.php';
       // $sql = sprintf("insert into  %s.smart_bcp_init_emails (pID,initid) select participantID,%d from %s.participant_database where archive=0", _DB_OBJ_FULL, $id, _DB_OBJ_FULL);
         $sql = sprintf("insert into  %s.smart_bcp_init_emails (pID,initid) select top(3) participantID,%d from %s.participant_database where archive=0", _DB_OBJ_FULL, $id, _DB_OBJ_FULL);
       
		$pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $sql = sprintf("select surname,forename,emailaddress,E.ID from  %s.smart_bcp_init_emails E inner join %s.participant_database P on 
E.pid=P.participantID where initid= %d ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        $dataInitiate = $this->getAlertData($id);

        $emailObj = new infoEmailHelper();


        //redo links             
        //'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyE.php?aid=' . $this->id . '">CLICK</a> here to respond to this email',
        $subject = "smart-ISO BCP Warning Email";

        foreach ($result as $row) {
            $mergeData = array(
                'twoColData' => array(
                    'actionid' => array('left' => '<strong></strong>', 'right' => ''),
                    'assignedto' => array('left' => '', 'right' => ''),
                    'authorizing1' => array('left' => '', 'right' => '')
                ),
                'singleColData' => array(
                    'summary' => '<p><STRONG>Reason:</STRONG><BR><BR>An BCP is being Initated<BR><BR><STRONG>Comment:</STRONG><BR><BR>' . $this->BCPInfo["email"] . '<BR><BR></p>',
                    'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyE.php?aid=' . $row["ID"] . '">CLICK</a> here to confirm receipt of the email'),
            );
            $who = array('displayname' => ucwords($row["forename"]) . " " . ucwords($row["surname"]), 'email' => $row["emailaddress"]);
            $emailObj->appendInfo($mergeData);


            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'purple');
        }
    }

    public function getbackupPerson($ref, $who) {
        $sql = sprintf("select resource_group from %s.smart_severe where uniqueReference= '%s'
union
select resource_group from %s.smart_standard where uniqueReference= '%s'
union
select resource_group from %s.smart_serious where uniqueReference= '%s'", _DB_OBJ_FULL, $ref, _DB_OBJ_FULL, $ref, _DB_OBJ_FULL, $ref);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        $sql = sprintf("select parent_partid from %s.smart_bcp_cascade_team T inner join %s.smart_bcp_cascade C on T.link=C.ID  where part_ID=%d and groupID=%d  and backup_type=0
", _DB_OBJ_FULL, _DB_OBJ_FULL, $who, $result["resource_group"]);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

       $sql = sprintf("select T.part_ID,surname,forename from %s.smart_bcp_cascade_team T inner join %s.participant_database P on T.part_ID=P.participantID where parent_partID=%d and backup_type=1
  
", _DB_OBJ_FULL, _DB_OBJ_FULL, $result['parent_partid']);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }
 public function updateBCPi($p_id) {
        $sql = sprintf("update %s.smart_action_list set endtime=getdate()  where actionID=%d ", _DB_OBJ_FULL,$p_id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

    }

      public function sendWarningInitiateTestEmails($id) {
        require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/infoEmail.php';
  //      $sql = sprintf("insert into  %s.smart_bcp_init_emails (pID,initid) select participantID,%d from %s.participant_database", _DB_OBJ_FULL, $id, _DB_OBJ_FULL);
  //      $pStatement = $this->dbHand->prepare($sql);
  //      $pStatement->execute();

        $sql = sprintf("select surname,forename,emailaddress,E.ID from  %s.smart_bcp_init_emails E inner join %s.participant_database P on 
E.pid=P.participantID where initid= %d ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        $dataInitiate = $this->getAlertData($id);

        $emailObj = new infoEmailHelper();


        //redo links             
        //'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/smart_bcp/notifyE.php?aid=' . $this->id . '">CLICK</a> here to respond to this email',
        $subject = "smart-ISO BCP Test Warning Email";

        foreach ($result as $row) {
            $mergeData = array(
                'twoColData' => array(
                    'actionid' => array('left' => '<strong></strong>', 'right' => ''),
                    'assignedto' => array('left' => '', 'right' => ''),
                    'authorizing1' => array('left' => '', 'right' => '')
                ),
                'singleColData' => array(
                    'summary' => '<p><STRONG>Reason:</STRONG><BR><BR>An BCP is being Tested<BR><BR><STRONG>Comment:</STRONG><BR><BR>' . $this->BCPInfo["email"] . '<BR><BR></p>')
            );
            $who = array('displayname' => ucwords($row["forename"]) . " " . ucwords($row["surname"]), 'email' => $row["emailaddress"]);
            $emailObj->appendInfo($mergeData);


            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'purple');
        }
    }
public function displayFileListing($fileids) {
    $objFile = new Upload();
    $file1Arr = explode(",", $fileids);
 $filestr="";
 if (is_array($file1Arr)){
  foreach($file1Arr as $filerow1){  
     
    $objFile->setFileInfo('BCP',array('id'=>$filerow1));
    $file_detail = $objFile->getFileDetails();
    $filestr.='<a href="/download.php?id='.$filerow1.'">'.$file_detail['usrFilename'].'</a><BR>';
 }
 }
 return $filestr;   
}
public function displayFileListingPDF($fileids) {
    $objFile = new Upload();
    $file1Arr = explode(",", $fileids);
 $filestr="";
 if (is_array($file1Arr)){
  foreach($file1Arr as $filerow1){  
     
    $objFile->setFileInfo('BCP',array('id'=>$filerow1));
    $file_detail = $objFile->getFileDetails();
    $filestr.=$file_detail['usrFilename']."\n\r";
 }
 }
 return $filestr;   
}
}

?>