<?php
 /**
  $Id: ActionTrackerNonconformanceNhp.class.php,v 3.47 Wednesday, January 26, 2011 7:29:34 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerRTA extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;
        
            public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
     $this->sql_query = sprintf("select A.id,R.reference,R.problem,R.owner,L.name,R.dateentered,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,R.ID from %s.actions A  inner join %s.RTA R on a.record=R.ID left join %s.locationgram L on R.location=L.locID where modulename='RTA'  and currentWho=%d and approveAU=0 and A.status=1
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);

        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
		$this->sql_query = sprintf("select A.id,R.reference,R.problem,R.owner,L.name,R.dateentered,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,R.ID from %s.actions A  inner join %s.RTA R left join %s.locationgram L on R.location=L.locID  on a.record=R.ID where modulename='RTA' and A.wWho=%d and approveAU=1 and A.status=1
       					ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();


        if (isAdministrator()) {
			  $this->sql_query = sprintf("select A.id,R.reference,R.problem,R.owner,L.name,R.dateentered,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,R.ID from %s.actions A  inner join %s.RTA R on a.record=R.ID left join %s.locationgram L on R.location=L.locID   where modulename='RTA'  and approveAU=0 and not currentWho=%d and A.status=1
							ORDER BY   R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
		      $this->sql_query = sprintf("select A.id,R.reference,R.problem,R.owner,L.name,R.dateentered,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,R.ID from %s.actions A  inner join %s.RTA R on a.record=R.ID left join %s.locationgram L on R.location=L.locID  where modulename='RTA'  and approveAU=0 and whoAU=%d and A.status=1
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {
                       $this->sql_query = sprintf("select A.id,R.reference,R.problem,R.owner,L.name,R.dateentered,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,A.whoAU,R.ID from %s.actions A  inner join %s.RTA R on a.record=R.ID left join %s.locationgram L on R.location=L.locID  where modulename='RTA'  and approveAU=1 and not A.who=%d and A.status=1
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {

        			 $this->sql_query = sprintf("select A.id,R.reference,R.problem,R.owner,L.name,R.dateentered,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,A.whoAU,R.ID from %s.actions A  inner join %s.RTA R on a.record=R.ID left join %s.locationgram L on R.location=L.locID  where modulename='RTA'  and approveAU=1 and whoAU=%d and A.status=1
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }
       
        return $this->getActionsByFilter(__METHOD__);
    }

    private function getActionsByFilter($p_callingMethod) {

        $USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
        //echo $calling_method;

        $pStatement = $this->dbHand->prepare($this->sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
}