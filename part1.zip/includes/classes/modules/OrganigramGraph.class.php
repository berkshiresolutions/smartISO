<?php
 /**
  $Id: OrganigramGraph.class.php,v 3.25 Monday, January 17, 2011 3:56:44 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, September 13, 2010 5:30:32 PM>
  */

class OrganigramGraph
{
	public static function initializeGraph($p_type,$p_graph_type,$p_filename='',$p_debug=false) {

		if ( empty($p_type) || $p_type == 'V' ) {
			$p_type = 'Vertical';
			$classname = 'OrganigramGraph'.$p_type;
		} else if ( $p_type == 'H' ) {
			$p_type = 'Horizontal';
			$classname = 'OrganigramGraph'.$p_type;
		}else if ( $p_type == 'I' ) {
			$p_type = 'Image';
			$classname = 'OrganigramNew'.$p_type;
		}else if ( $p_type == 'T' ) {
			$p_type = 'Image';
			$classname = 'OrganigramVert';
		}

		

		if ( $p_graph_type == '' ) {
			$p_graph_type = 'N';
		}

		return new $classname($p_graph_type,$p_filename,$p_debug);
	}
}
?>