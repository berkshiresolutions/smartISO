<?php
 /**
  $Id: SOAMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, November 04, 2010 8:32:17 AM>
  */
require_once "Action.class.php";

class SOAActionExport
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold SOA Id
	 *@access private
	 */
	private $soaId;

	/**
	 *Property to hold SOA Info
	 *@access private
	 */
	private $soaInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing SOA object
	 * @access public
	 */
	public function __construct() {

	 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setSOAInfo($p_soaId,$p_soaInfo) {

		$this->soaId		=	$p_soaId;
		$this->soaInfo	=	$p_soaInfo;
	}

	public function getListingforExport() {
		
		$is_admin = false;
		$show_participant_name = false;
		
		
		if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
				$is_admin = false;
	
			} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
				$show_participant_name = true;
		}

				
		$heading = array(array('bu'=>'Location','refrence'=>'Reference No.','hazards'=>'Control Question','clause'=>'Control Ref No.','action'=>'Action','dueDate'=>'Due Date','assigned'=>'Assigned To','done'=>'Done Date'));
		$p_moduleName = 'risk';
		
		$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
		//echo $tab_type;
	    $actTrackObj = new ActionTracker();
	
		$actTrackObj->setActionTrackerInfo('soa',$tab_type,$p_dateFilter='');
		$resultset = $actTrackObj->getActionsForActionTracker();
		
		
		if(!empty($resultset)){
			
			foreach($resultset as $resultElement){
			
			$ac_id = $resultElement['ID'];
			$action_description 		= compact_action_tracker_description($resultElement['actionDescription']);
			$action_description_full 	= javascript_safe_string($resultElement['actionDescription']);
			$hazard_summary 			= ($resultElement['hazardSummary']);
			
			$result[$i]['bu'] = $resultElement['name'];
			$result[$i]['refrence'] = $resultElement['Reference'];
			$result[$i]['hazards'] = $resultElement['summary'];
			$result[$i]['clause'] = $resultElement['con'];
			$result[$i]['action'] = $resultElement['actionDescription'];
			if($resultElement['dueDate']){
			$result[$i]['dueDate'] = format_date($resultElement['dueDate']);
			}else{
			
			$result[$i]['dueDate'] = '-';
			}
			//$result[$i]['due'] = format_datetime($resultElement['dueDate']);
			  $participantObj = SetupGeneric::useModule('Participant');

            $participantObj->setItemInfo(array('id' => $resultElement["who"]));
            $partcipantData = $participantObj->displayItemById();
            $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
			$result[$i]['assigned'] = $contributor_name;
			if($resultElement['doneDate']){
			$result[$i]['done'] = format_date($resultElement['doneDate']);
			}else{
			
			$result[$i]['done'] = '-';
			}
			
			$i++;
			
		}
		$result = array_merge($heading,$result);
		return $result;
			
		}
		
	}


	
}
?>