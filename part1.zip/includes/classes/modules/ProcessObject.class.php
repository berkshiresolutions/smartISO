<?php
 /**
  $Id: ProcessObject.class.php,v 3.17 Tuesday, February 01, 2011 4:26:12 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 2:58:08 PM>
  */

class ProcessObject
{
	private $obj;

	public function getClass($p_class) {

		$p_class = ucfirst(strtolower($p_class));
		$classname = 'Process'.$p_class;

		if ( strtoupper($p_class) == 'INPROCESS' || strtoupper($p_class) == 'OUTPROCESS' || strtoupper($p_class) == 'EXINPROCESS' || strtoupper($p_class) == 'EXOUTPROCESS' ) {
			require_once "ProcessObjectOutsideProcess.class.php";
		} else {
			require_once "ProcessObject$p_class.class.php";
		}
return new $classname();
	/*	if ( $this->obj instanceof $classname ) {
			return $this->obj;
		} else {
			return new $classname();
		}
*/

	}

    public function DrawObject($p_objectType,$p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info,$p_out_type='N') {

		if ( empty($p_objectType) ) {

			throw new ErrorException('No object Type defined',10);

		} else {

			$this->obj = self::getClass($p_objectType);

			switch ($p_objectType) {

				case 'ACTION':		$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'DECISION':	$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'SUPPORT':		$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'LOZENGE':		$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'INPROCESS':	$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'OUTPROCESS':	$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'EXINPROCESS':	$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info,$p_out_type);
									break;

				case 'EXOUTPROCESS':	$this->obj->draw($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info,$p_out_type);
									break;

				default: 	throw new ErrorException('Invalid object Type : '+$p_objectType,11);
							break;
			}
		}
	}



	public function DrawShadowObject($p_objectType,$p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info) {

		if ( empty($p_objectType) ) {

			throw new ErrorException('No object Type defined',10);

		} else {

			$this->obj = self::getClass($p_objectType);

			switch ($p_objectType) {

				case 'ACTION':		$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'DECISION':	$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'SUPPORT':		$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'LOZENGE':		$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'INPROCESS':	$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'OUTPROCESS':	$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'EXINPROCESS':	$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				case 'EXOUTPROCESS':	$this->obj->drawShadow($p_this,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
									break;

				default: 	throw new ErrorException('Invalid object Type : '+$p_objectType,11);
							break;
			}
		}
	}

	public function DrawPath($p_objectType,$p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {

		if (!empty($p_objectType) ) {
			$this->obj = self::getClass('DECISION');
			$this->obj->drawLink($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge);
		}
	}

	public function DrawSupportPath($p_objectType,$p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {

		if (!empty($p_objectType) ) {
			$this->obj = self::getClass('DECISION');
			$this->obj->drawSupportLink($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge);
		}
	}

	public function DrawNewCrossPath($p_this,$p_path_info,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0,$type_output='N') {

		$this->obj = self::getClass('DECISION');
		$this->obj->drawNewCrossLink($p_this,$p_path_info,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset,$type_output);
	}

	public function DrawStartCrossPath($p_this,$p_path_info,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0) {

		$this->obj = self::getClass('DECISION');
		$this->obj->drawStartCrossLink($p_this,$p_path_info,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset);
	}

	public function DrawStartAltPath($classObj,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0,$direction,$crossover=0) {

		$this->obj = self::getClass('DECISION');
		$this->obj->drawStartAltLink($classObj,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset,$direction,$crossover);
	}

	public function DrawNewExternalPath($p_this,$p_path_info,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {

		$this->obj = self::getClass('DECISION');
		$this->obj->drawNewExternalLink($p_this,$p_path_info,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge);
	}

	public function DrawExternalPath($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawExternalLink($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge);
	}
	
		public function DrawInternalPath($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawInternalLink($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge);
	}
	
	public function DrawCrossPath($p_objectType,$p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawCrossLink($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset);
	}

	public function DrawHorizontalPath($p_objectType,$p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawHorizontalLink($p_objectType,$p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge);
	}
	
	public function DrawAltPath($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0,$direction=1) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawAltLink($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset,$direction);
		}
			public function DrawAltStop($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawAltStop($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset);
		}
	
		public function DrawAltEnd($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset=0,$direction=1) {

		$this->obj = self::getClass('DECISION');

		$this->obj->drawAltEnd($p_this,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_y_offset,$direction);
		}
	
}
?>