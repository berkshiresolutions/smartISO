<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class FactoryHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $sectionName;
	private $element;

	private function getInstance() {

		$classname 		= ucfirst($this->sectionName).'History';
		$classnameFile 	= realpath("..").'/includes/classes/modules/'.$classname.'.class.php';

		if ( file_exists($classnameFile) ) {
			return new $classname();
		} else {
			throw new Exception('Invalid Section Name',102);
		}
	}

	public function __construct($p_section) {
		
		//echo $p_section;

		$this->dbHand 			= DB::connect(_DB_TYPE);
         
		if ( !empty($p_section) ) {
			$this->sectionName		= trim($p_section);
			$this->element			= $this->getInstance();
		} else {
			throw new Exception('Missing Section Name',101);
		}
	}

	public function setItemInfo($p_record_id,$p_process_id=0) {

		$this->element->setItemInfo($p_record_id);

		if ($p_process_id) {
			$this->element->setItemInfoAddn($p_process_id);
		}
	}

	public function sendToHistory() {
		$this->element->sendToHistory();
	}
}
?>