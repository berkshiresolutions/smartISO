<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */

require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class Risk27kHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {

		 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'risk27k';
	//	$this->tables[] 		= 'dse_assessment_sections';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _risk27k() {

		$tablename 				= 'risk27k';
		$tablename_historical 	= $tablename.'_historical';

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (
						ID
						,reference
						,uniqueReference
						,description
						,locID
						,who
						,businessunit
						,whenDate
						
						,threats
						,threasSummary
						,subReference
					   )
						SELECT
						ID
						,reference
						,uniqueReference
						,description
						,locID
						,who
						,businessunit
						,whenDate
						
						,threats
						,threatsSummary
						,subReference
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		
	$sql = sprintf("SELECT subReference FROM %s.risk27k WHERE  ID = %d",_DB_OBJ_FULL,$this->recordId);

		//echo $sql;

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

	
		$result = $pStatement->fetchColumn();
	$this->subReference = $result;
	if($result == '' || $result == null){
		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = '1'
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
	}else{
	echo	$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
		
	}
	 
	}

}