<?php

/**
  $Id: Action.class.php,v 3.84 Saturday, January 29, 2011 5:04:35 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Thursday, October 07, 2010 12:46:05 PM>
 */
class ActionExports {

    /**
     * Property to hold database
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold record Id
     * @access private
     */

    /**
     * Constructor for initializing Action object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
    }

    public function getExportActionContrib($who, $start, $end, $completed) {
            if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
        if ($completed == 0)
    $sql_query = sprintf("SELECT *,P.forename+' '+P.surname as displayname   FROM %s.cms_documents_contributors C left join %s.cms_documents  D on C.cmsdocID=D.cmsdocID left join %s.participant_database P on C.authParticipantID=P.participantId WHERE passed = 0 ",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);
    else    
$sql_query = sprintf("SELECT *,P.forename+' '+P.surname as displayname   FROM %s.cms_documents_contributors C left join %s.cms_documents  D on C.cmsdocID=D.cmsdocID left join %s.participant_database P on C.authParticipantID=P.participantId WHERE not passed = 0 ",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);
				
				
     
             $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
   
        return $result;
    }
    
        public function getExportActionDocuments($who, $start, $end, $completed) {
            if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
                   $sql_query = sprintf("SELECT *,C.cmsdocID as cmsdocID FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID 
					where C.isArchive=0 and status in ('U','D') and documentID > 0  
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL);				
				
     
             $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
   
        return $result;
    }

        public function getExportActionDocumentActions($who, $start, $end, $completed) {
            if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
  $sql_query = sprintf("select * from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N'  ", _DB_OBJ_FULL, _DB_OBJ_FULL);
			
				
     
             $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
   
        return $result;
    }
    
    public function getExportActionDocumentReview($who, $start, $end, $completed) {
            if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
  $sql_query = sprintf("SELECT R.*,D.*,P.forename+' '+P.surname as pname from %s.cms_document_reviews R left join %s.cms_documents D on R.cmsdocid=D.cmsdocid left join %s.participant_database P  on R.currentwho=P.participantID  where R.reviewstatus in (0,1)", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
 			
				
     
             $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
   
        return $result;
    }

     public function getExportActionsMSR($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
    $sql_query = sprintf("select A.id,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,P.forename+' '+P.surname as displayname  from %s.actions A  inner join %s.review_master R on a.record=R.reviewID left join %s.business_units B on R.buid=B.buID inner join %s.participant_database P on A.who=P.participantId  where modulename='MSR_reviews'  and A.status=1  %s %s %s and approveAU=%d
							ORDER BY R.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);
                            
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
        public function getExportActionsICR($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
        $sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,R.reviewID,M.reference,P.forename+' '+P.surname as displayname from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID inner join %s.participant_database P on A.who=P.participantId  where modulename='ICR_action' and A.status=1  %s %s %s and approveAU=%d
 							ORDER BY R.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);
   
                         
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
         public function getExportActionsISA($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
  echo  $sql_query = sprintf("select A.id,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,P.forename+' '+P.surname as displayname  from %s.actions A  inner join %s.review_master R on a.record=R.reviewID left join %s.business_units B on R.buid=B.buID inner join %s.participant_database P on A.who=P.participantId  where modulename='ISA_Actions'  and A.status=1  %s %s %s and approveAU=%d
							ORDER BY R.reviewID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);
   
                         
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
      public function getExportActionsRisk($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
        
   $sql_query = sprintf("select A.id,R.processReference,B.buName,R.hazardSummary,R.riskrating1,R.whoID,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,A.whoAU,R.processID,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID inner join %s.participant_database P on A.who=P.participantId  where modulename='risk'   and A.status=1  %s %s %s and approveAU=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);
  
                         
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getExportActionsPF($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";


        $sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,S.swimID,A.currentWho ,P.forename+' '+P.surname as displayname from %s.actions A  left join %s.swimlane S on A.record=S.swimID left join %s.business_units B on S.buid=B.buID inner join %s.participant_database P on A.who=P.participantId  where modulename='pf'  %s %s %s and approveAU=%d
							ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);



        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
      public function getExportActionsInspectionPhy($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
           $sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on A.locID=L.locID inner join %s.participant_database P on A.who=P.participantId  where modulename='inspectionH'   %s %s %s and approveAU=%d
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);


        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
        public function getExportActionsInspectionCCP($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
           $sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on A.locID=L.locID inner join %s.participant_database P on A.who=P.participantId  where modulename='inspectionC'   %s %s %s and approveAU=%d
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);


        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
    public function getExportActionsInspectionRisk($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
          $sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on A.locID=L.locID inner join %s.participant_database P on A.who=P.participantId  where modulename='inspectionR'   %s %s %s and approveAU=%d
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);


        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
     public function getExportActionsInspectionNA($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
           $sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on A.locID=L.locID inner join %s.participant_database P on A.who=P.participantId  where modulename='inspectionN'   %s %s %s and approveAU=%d
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);


        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    
  public function getExportActionsInspectionDue($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
        $sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentwho,I.ID,P.forename+' '+P.surname as displayname from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on A.locID=L.locID inner join %s.participant_database P on A.who=P.participantId  where modulename='inspectionDue'  %s %s %s and approveAU=%d
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);


        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

      public function getExportActionsLaw($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
     
 $sql_query = sprintf("select A.id,A.moduleName,S.slsLegislation,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,R.smartlawID,S.ref_No,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.smartlaw_review R on a.record=R.ID left join %s.smartlaw_sections S on R.smartlawID=S.slsID inner join %s.participant_database P on A.who=P.participantId  where modulename like '%s'   and A.status=1   %s %s %s and approveAU=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,'smartlaw_', $whoStr, $startStr, $endStr, $completed);
   
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
          public function getExportActionsLawReview($who, $start, $end, $completed) {
        if ($who > 0)
            $whoStr = " and who=" . $who;
        else {
            $whoStr = "";
        }
        if ($start != "")
            $startStr = " and dueDate >= '" . $start . "'";
        else
            $startStr = "";

        if ($end != "")
            $endStr = " and dueDate =< '" . $end . "'";
        else
            $endStr = "";
     
 $sql_query = sprintf("select A.id,A.moduleName,S.slsLegislation,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,R.smartlawID,S.ref_No,P.forename+' '+P.surname as displayname  from %s.actions A  left join %s.smartlaw_review R on a.record=R.ID left join %s.smartlaw_sections S on R.smartlawID=S.slsID inner join %s.participant_database P on A.who=P.participantId  where modulename ='smartlawreview'  and A.status=1   %s %s %s and approveAU=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $whoStr, $startStr, $endStr, $completed);
   
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
}

?>