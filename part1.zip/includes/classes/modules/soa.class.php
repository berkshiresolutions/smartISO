<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class SOA {

    const AU_EMAIL = 2;
    const PARTICIPANT_EMAIL = 4;
    const INITIAL_EMAIL_TEXT = 'You have an action to carry out the following SOA Action';
    const SECONDARY_EMAIL_TEXT = 'An action requires authorization to because the following SOA Action was carried out';
    const INITIAL_EMAIL_SUBJECT = 'An SOA Action To Be Carried Out';
    const AU_EMAIL_SUBJECT = 'An SOA Action is awaiting Approval';

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold Risk 27k Id
     * @access private
     */
    private $SOAId;
    private $locID;

    /**
     * Property to hold Risk 27k Info
     * @access private
     */
    private $SOAInfo;

    /**
     * Constructor for initializing Risk 27k object
     * @access public
     */
    public function __construct($id = 0) {

		$this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
        $this->SOAInfo = array('reviewID' => $id);
    }

    public function setSOAInfo($p_SOAId, $p_SOAInfo) {
//dump_array($p_SOAInfo);
        $this->SOAId = $p_SOAId;
        $this->SOAInfo = $p_SOAInfo;
    }

    public function addSoaData() {


        $sql = sprintf("INSERT INTO %s.soaAnswerData(questionID ,answer,ref,detail,reviewID,isAction,summary,date,who, doc27K,docIS, lib27K,libIS,controller,lead_control,pflist,comment)
						VALUES ( %d ,'%s' ,'%s','%s',%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s')"
                , _DB_OBJ_FULL
                , $this->SOAInfo['question_id']
                , $this->SOAInfo['answer']
                , $this->SOAInfo['ref']
                , $this->SOAInfo['detail']
                , $this->SOAInfo['reviewID']
                , $this->SOAInfo['action']
                , $this->SOAInfo['summary']
                , $this->SOAInfo['date']
                , $this->SOAInfo['who']
                , $this->SOAInfo['code27K_list']
                , $this->SOAInfo['IS_list']
                , $this->SOAInfo['lib27K_list']
                , $this->SOAInfo['libIS_list']
                , $this->SOAInfo['controller']
                , $this->SOAInfo['lead']
                , $this->SOAInfo['pflist']
                , $this->SOAInfo['comment']
        );

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function listSOA($p_open_closed = 0, $p_archive_val = 0) {
        $completeStmt = $p_open_closed == 0 ? ' (complete IS NULL OR complete != 1) ' : ' complete = 1 ';
        $sql = sprintf("SELECT * FROM %s.soaReview WHERE archived = %s AND %s ORDER BY ID DESC", _DB_OBJ_FULL, $p_archive_val, $completeStmt); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getSOAReview($id) {
        $sql = sprintf("SELECT * FROM %s.soaReview WHERE ID = %d", _DB_OBJ_FULL, $id); // startTime
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function listClosedSoa($p_archive_val = 0) {
        return $this->listSOA(1, $p_archive_val);
    }

    public function listOpenSoa($p_archive_val = 1) {
        return $this->listSOA(0, $p_archive_val);
    }

    public function getOutstandingActions($p_overdue) {

        if ($p_overdue) {
            $data = $this->actionHandling->viewOverdueActions('SOA');
        } else {
            $data = $this->actionHandling->viewAllActionByModule('SOA');
        }

        if (is_array($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT M.reference,M.businessUnit,M.ID AS risk_id FROM %s.SOA M
								WHERE M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' "
                        , _DB_OBJ_FULL
                        , $search_value1
                        , $search_value2
                        , $search_value3
                        , $search_value4);

                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$search_value1);
                  $pStatement->bindParam(2,$search_value2);
                  $pStatement->bindParam(3,$search_value3);
                  $pStatement->bindParam(4,$search_value4); */

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (is_array($action_data)) {

                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['businessUnit'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                        $new_data[$i]['risk_id'] = $value2['risk_id'];
                    }
                    $i++;
                }
            }
        }
        return $new_data;
    }

    public function updateSoaData($id) {

       $sql = sprintf("UPDATE %s.soaAnswerData
						SET questionID = %d, 
						answer='%s', 
						ref='%s',
						detail='%s',
						reviewID=%d,
						isAction='%s',
						summary='%s',
						date='%s',
						who='%s',
                                                doc27K='%s',
                                                docIS='%s',
                                                lib27K='%s',
                                                libIS='%s',
                                                controller='%s',
                                               lead_control='%d',
                                               pflist='%s',
						comment='%s' WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->SOAInfo['question_id']
                , $this->SOAInfo['answer']
                , $this->SOAInfo['ref']
                , $this->SOAInfo['detail']
                , $this->SOAInfo['reviewID']
                , $this->SOAInfo['action']
                , $this->SOAInfo['summary']
                , $this->SOAInfo['date']
                , $this->SOAInfo['who']
                , $this->SOAInfo['code27K_list']
                , $this->SOAInfo['IS_list']
                , $this->SOAInfo['lib27K_list']
                , $this->SOAInfo['lib_IS_list']
                , $this->SOAInfo['controller']
               , $this->SOAInfo['lead']
               , $this->SOAInfo['pflist']
                , $this->SOAInfo['comment'], $id
        );
 
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }
	
	  

    public function addSoaReview() {
        $this->locID = $this->SOAInfo['location'];
        $oldreviedID = $this->isSimilarReviewDone();
     $version=1;
        // buIDs have been removed from the below as if added in future they should be attached to the review rather than stored delimited
      $sql = sprintf("INSERT INTO %s.soaReview(soaName,startDate,location,archived,complete,uniqueReference,reference,finalDate,grouptype,reportVersion) 
			OUTPUT INSERTED.ID
			VALUES ('%s' ,'%s' ,%d,0,0,'%s','%s','%s',%d,%d)"
                , _DB_OBJ_FULL
                , $this->SOAInfo['name']
                , date('Y-m-d')
                , $this->SOAInfo['location']
                , $this->SOAInfo['uref']
                , $this->SOAInfo['ref']
                , date('Y-m-d')
                , $this->SOAInfo['review_type']
                , $version
              
        );

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $res = $pStatement->fetch(PDO::FETCH_ASSOC);
        $this->SOAId = $res['ID'];


        if ($oldreviedID > 0) {
            $this->cloneReview($oldreviedID, $this->SOAId);
        }

    }

    public function deleteAnswer() {

        $sql = "DELETE FROM %s.soaAnswerData WHERE questionID = %d AND reviewID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->SOAInfo['question_id'], $this->SOAInfo['reviewID']);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
    }

    public function getAnswers() {

        $sql = sprintf("SELECT * FROM %s.soaAnswerData WHERE reviewID = %d ", _DB_OBJ_FULL, $this->SOAInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $rec;
    }

    public function getPendingQuestion() {

        $sql = sprintf(
                "SELECT questionID FROM %s.soaAnswerData WHERE reviewID = %d ", _DB_OBJ_FULL, $this->SOAInfo['reviewID']
        );

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $sql = sprintf("SELECT *
				FROM %s.soa_data ", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getAnswer() {

       $sql = sprintf("SELECT *
				FROM %s.soaAnswerData WHERE questionID = %d AND reviewID = %d ", _DB_OBJ_FULL, $this->SOAId, $this->SOAInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        return $rec;
    }

    public function getAnswer27002Data($code) {

       $sql = sprintf("SELECT *
				FROM %s.msr_departments WHERE code = '%s' AND sid = 51 ", _DB_OBJ_FULL, $code);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        return $rec;
    }

    public function finishSoa() {

        $this->sendActions($this->SOAInfo['reviewID']);
      $sql = sprintf(
                "UPDATE %s.soaReview SET complete=1,finalDate='%s' WHERE ID = %d ", _DB_OBJ_FULL,date('Y-m-d'), $this->SOAInfo['reviewID']
        );

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function isArchived() {
        $sql = sprintf("SELECT archived FROM %s.soaReview WHERE ID = %d ", _DB_OBJ_FULL, $this->SOAInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
if($rec)
        return $rec["archived"];
else
    return 0;
    }

    public function toggleArchived($archive = 0) {
        $sql = sprintf("UPDATE %s.soaReview SET archived=%d WHERE ID = %d ", _DB_OBJ_FULL, $archive, $this->SOAInfo['reviewID']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

        public function search($searchStr="A.1%") {
      $sql = sprintf("select question from %s.soa_data WHERE con like '%s' ", _DB_OBJ_FULL, $searchStr);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        
        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($rec)
        return $rec["question"];
    else 
        return 1;
    }
    
    public function lastRecordId() {
        return $this->SOAId;
    }

    public function getEmailData($answerID) {
        //error_reporting(E_ALL);
        //ini_set('display_errors',1);
        $stmt1 = $this->dbHand->prepare(sprintf("SELECT * FROM %s.%s WHERE %s = %d", _DB_OBJ_FULL, 'soaAnswerData', 'ID', $answerID));
        $stmt1->execute();
        $soaAnswer = $stmt1->fetch(PDO::FETCH_ASSOC);

        $soaSetup = SetupGeneric::useModule('SOA'); // WAS HazardClassification
        $soaSetup->setItemInfo(array('id' => $soaAnswer['questionID']));
        $questionInfo = $soaSetup->getQuestion();

        $soaModuleCls = new SOA($soaAnswer['reviewID']);
        $data_array = array('reviewID' => $soaAnswer['reviewID']);
        $soaModuleCls->setSOAInfo($soaAnswer['questionID'], $data_array);
        $answerInfo = $soaModuleCls->getAnswer();

        $reviewData = $soaModuleCls->getSOAReview($soaAnswer['reviewID']);

        $stmt2 = $this->dbHand->prepare(sprintf("SELECT name FROM %s.locationgram WHERE locID = %d", _DB_OBJ_FULL, $reviewData['location']));
        $stmt2->execute();
        $locationData = $stmt2->fetch(PDO::FETCH_ASSOC);

        $location_name = $locationData['name'];
        $reference = $reviewData['soaName'] . ' - ' . $questionInfo['clause'];
        $threat_summary = $questionInfo['sectionDescription'];
        $threat_summary_full = $questionInfo['sectionDescription'] . "\r\n" . $questionInfo['controlQuestion'];
        return array_merge($questionInfo, array('location' => $location_name));
    }

    public function sendInitialEmail(
    $action_id = 0, $details = '', $choosewho = self::PARTICIPANT_EMAIL, $sentencetext = self::INITIAL_EMAIL_TEXT, $subject = self::INITIAL_EMAIL_SUBJECT
    ) {
        //
        // Participant Details
        //
		$emailObj = new actionEmailHelper($action_id);

        //
        // setup email
        //
		$who = $emailObj->getwhoDetails();
        if ($choosewho == self::AU_EMAIL) {
            $who = $emailObj->getAUDetails();
        }

        $sentence = array('sentence' => array($sentencetext));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/SOA_assessment.php?filter_date=">CLICK</a> Here to View SOA Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Description:</strong>',
                    'right' => $details['sectionDescription']
                ),
                'section' => array(
                    'left' => '<strong>Section:</strong>',
                    'right' => $details['controlDescription']
                ),
                'reference' => array(
                    'left' => '<strong>Reference:</strong>',
                    'right' => $details['clause']
                ),
                'question' => array(
                    'left' => '<strong>Question #' . $details['question'] . ':</strong>',
                    'right' => $details['controlQuestion']
                )
            )
        );

        $emailObj->appendInfo($data);
        //die(print_r($who));
        //mail('lewis-cowles@codesign2.co.uk','SOA',print_r($who));
        //$cto = array('displayname'=>'Lewis-Cowles','email'=>'lewis-cowles@codesign2.co.uk');
        return $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');
    }

    private function cloneReview($p_sourceReviewId, $p_destinationReviewId) {

        /* for extra protection */
        $p_sourceReviewId = (int) $p_sourceReviewId;
        $p_destinationReviewId = (int) $p_destinationReviewId;
        
                $sql = sprintf("SELECT * FROM %s.soaReview
				WHERE ID = %d", _DB_OBJ_FULL, $p_sourceReviewId);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_sourceReviewId); */
        $stmt->execute();

        $resultV = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf("SELECT * FROM %s.soaanswerdata
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_sourceReviewId);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$p_sourceReviewId); */
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $resultSet) {

        
            if ($resultV["version"] ==0){
            $ins = sprintf("INSERT INTO %s.soaanswerdata (reviewID,questionID,answer,ref,detail,isAction,summary,date,who,comment,status,doc27K,docIS,lib27K,libIS,lead_control,controller,PFList)
				VALUES (%d, %d, %d, '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')"
                    , _DB_OBJ_FULL
                    , $p_destinationReviewId
                    , $resultSet['questionID']
                    , $resultSet['answer']
                    , $resultSet['ref']
                    , $resultSet['detail']
                    , 0
                    , ''
                    , ''
                    , 0
                    , $resultSet['comment']."\n\r".$resultSet['detail']."\n\r".$resultSet['summary']
                    , $resultSet['status']
					, $resultSet['doc27K']
					, $resultSet['docIS']
					, $resultSet['lib27K']
					, $resultSet['libIS']
					, $resultSet['lead_control']
					, $resultSet['controller']
                    , $resultSet['PFList']);
            }else{
                            $ins = sprintf("INSERT INTO %s.soaanswerdata (reviewID,questionID,answer,ref,detail,isAction,summary,date,who,comment,status,doc27K,docIS,lib27K,libIS,lead_control,controller,PFList)
				VALUES (%d, %d, %d, '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')"
                    , _DB_OBJ_FULL
                    , $p_destinationReviewId
                    , $resultSet['questionID']
                    , $resultSet['answer']
                    , $resultSet['ref']
                    , $resultSet['detail']
                    , 0
                    , ''
                    , ''
                    , 0
					, $resultSet['comment']
                    , $resultSet['status']
					, $resultSet['doc27K']
					, $resultSet['docIS']
					, $resultSet['lib27K']
					, $resultSet['libIS']
					, $resultSet['lead_control']
					, $resultSet['controller']
                    , $resultSet['PFList']);
            }
            $stmt_ins = $this->dbHand->prepare($ins);

            $stmt_ins->execute();
        } // end foreach
        
        $sql = sprintf("update %s.soareview set parentID=%d 
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_sourceReviewId,$p_destinationReviewId);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    private function isSimilarReviewDone() {

        $sql = sprintf("SELECT ID
				FROM %s.soareview
				WHERE location = %d and complete =1
				ORDER BY ID DESC"
                , _DB_OBJ_FULL
                , $this->locID);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $count = count($result);

        if ($count) {
            return $result['ID'];
        } else {
            return 0;
        }
    }

    public function sendActions($id) {
        $sql = sprintf("select A.*,S.sectionDescription,S.controlDescription,S.clause,S.controlQuestion from %s.actions A  inner join %s.soaanswerdata D on A.record=D.id inner join %s.soa_data S on D.questionID=S.ID where moduleName ='SOA' and D.reviewID=%d"
                , _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $details) {

            $emailObj = new actionEmailHelper($details["ID"]);

            //
            // setup email
            //
		$who = $emailObj->getwhoDetails();
//dump_array($who);
            $sentence = array('sentence' => array($sentencetext));
            $emailObj->appendInfo($sentence);

            $data = array(
                'singleColData' => array(
                    'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/SOA_assessment.php?filter_date=">CLICK</a> Here to View SOA Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/SOA/report.php?aid=' . $id . '">CLICK</a> Here to View SOA Report'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Description:</strong>',
                        'right' => $details['sectionDescription']
                    ),
                    'section' => array(
                        'left' => '<strong>Section:</strong>',
                        'right' => $details['controlDescription']
                    ),
                    'reference' => array(
                        'left' => '<strong>Reference:</strong>',
                        'right' => $details['clause']
                    ),
                    'question' => array(
                        'left' => '<strong>Question #' . $details['question'] . ':</strong>',
                        'right' => $details['controlQuestion']
                    )
                )
            );

            $emailObj->appendInfo($data);
            $subject = self::INITIAL_EMAIL_SUBJECT;


            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');

            $whoAU = $emailObj->getAUDetails();

            //$emailObj->sendEmail('A SOA Action To Be Approved', $whoAU, array(), array(), 'me_completed', '', 'grey');

            $who2AU = $emailObj->getSecondApproverDetails();
            if ($who2AU['ID'] > 0) {
                $emailObj->sendEmail('A SOA Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
            }
        }
    }

    public function getListingforExport() {

        return $this->getOpenReviewsExportData();
    }

    public function getOpenReviewsExportData() {
        $locObj = SetupGeneric::useModule('Locationgram');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $openReview = $this->listOpenSoa($archive_session);

        $heading = array(array('Reference', 'Name', 'Location', 'Start Date'));

        $result = array();

        if (is_array($openReview)) {

            foreach ($openReview as $element) {


                $reference = rtrim($element['Reference']);
                $locObj->setItemInfo(array('id' => $element['location']));
                $locArr=explode(', ', $locObj->getFUllLocation());
                $location = end($locArr); 
				$name = $element['soaName'];
                $start_date = format_date($element['startDate']);

                $result[] = array($reference, $name, $location, $start_date);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }
 public function getClosedReviewsExportData() {
        $locObj = SetupGeneric::useModule('Locationgram');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $openReview = $this->listClosedSoa($archive_session);

        $heading = array(array('Reference', 'Name', 'Location', 'Start Date'));

        $result = array();

        if (is_array($openReview)) {

            foreach ($openReview as $element) {


                $reference = rtrim($element['Reference']);
                $locObj->setItemInfo(array('id' => $element['location']));
                $locArr=explode(', ', $locObj->getFUllLocation());
                $location = end($locArr); 
				$name = $element['soaName'];
                $start_date = format_date($element['startDate']);

                $result[] = array($reference, $name, $location, $start_date);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }
    
         public function getQuestionSearch($search) {
         
	$sql = sprintf("select id from %s.soa_data where con like '%s' order by ID", _DB_OBJ_FULL,$search."%");
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        return $rec['id'];
    }
    
        public function getCompleteActionData($actionID) {
   
       $sql =   sprintf("select A.id,R.Reference,L.name as lname,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,Q.controlQuestion as problem,Q.clause from %s.actions A  inner join %s.soaanswerdata S on A.record=S.ID  left join %s.soareview R on S.reviewid=R.ID  left join %s.locationgram L on R.location=L.locID left join %s.soa_data Q on S.questionID=Q.ID where modulename='SOA' and approveAU=0 and A.ID=%d", _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $actionID);
   
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    
           public function getActionsDatabyQuestion($questID) {
   
       $sql =   sprintf("select * from %s.actions where modulename='SOA' and record=%d", _DB_OBJ_FULL, $questID);
   
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
   
    
     public function get27Kdocs() {
   
       $sql =   sprintf(" select D.*,M.code from %s.cms_documents D inner join msr_departments M on D.code27002=M.ID where isnull(D.isArchive,0)=0 and isnull(code27002,0)>0 order by M.ID,D.title",_DB_OBJ_FULL, _DB_OBJ_FULL);
   
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
         public function getISdocs() {
   
       $sql =   sprintf(" select * from %s.cms_documents D  where isnull(D.isArchive,0)=0 and isnull(code27002,0)=0 and isIS=1 order by D.title",_DB_OBJ_FULL);
   
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    
         public function getlib27Kdocs() {
   
       $sql =   sprintf(" select D.*,M.code from %s.comms_mangement D inner join msr_departments M on D.code27002=M.ID where isnull(D.archive,0)=0 and isnull(code27002,0)>0 order by M.ID,D.title",_DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
         public function getlibISdocs() {
   
       $sql =   sprintf(" select * from %s.comms_mangement D  where isnull(D.archive,0)=0 and isnull(code27002,0)=0 and isIS=1 order by D.title",_DB_OBJ_FULL);
   
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
}
