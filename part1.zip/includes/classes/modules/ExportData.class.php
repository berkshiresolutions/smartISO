<?php

/**
  $Id: ExportData.class.php,v 3.62 Monday, January 31, 2011 12:04:24 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2011 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @since  Thursday, January 13, 2011 3:23:19 PM>
 */
class ExportData {

    private $fileName;
    private $modulename;
    private $exportType;
    private $allowedExportTypes;
    private $exportObject;
    public $exportData;

    public function __construct($p_modulename, $p_exportType = 'csv', $p_fileName = 'temporary') {

        $this->dbHand = DB::connect(_DB_TYPE);

        $this->allowedExportTypes = array('csv', 'pdf');

        $this->fileName = $p_fileName . "." . strtolower($p_exportType);
        $this->modulename = $p_modulename;
        $this->exportType = $p_exportType;

        $classname = 'ExportData' . ucfirst($p_exportType);
        $this->exportObject = new $classname($p_modulename);
    }

    private function getModuleObject() {

        switch ($this->modulename) {
            case 'employementtype': return new EmploymentTypeSetup();
                break;
            case 'participanttitles': return new ParticipantTitleSetup();
                break;
            case 'participants': return new ParticipantSetup();
                break;
            case 'participantsFull': return new ParticipantSetup();
                break;
            case 'docClassification': return new DocClassificationSetup();
                break;
            case 'equipClassification': return new EquipmentClassificationSetup();
                break;
            case 'managementElements': return new ManagementElementSetup();
                break;
            case 'smartlaw': return new SmartLawSetup();
                break;
            case 'smartlawFull': return new SmartLawSetup();
                break;
            case 'smartlawnature': return new SmartLawNatureSetup();
                break;
            case 'smartlawlevel': return new SmartLawLevelSetup();
                break;
            case 'smartlawsubject': return new SmartLawSubjectSetup();
                break;
            case 'smartlawActions': return new SmartLawactions();
                break;
            case 'smartlawReviews': return new SmartLawreviews();
                break;
            case 'trainingcourse': return new TrainingCourseSetup();
                break;
            case 'traininginstructor': return new TrainingInstructorSetup();
                break;
            case 'trainingroom': return new TrainingRoomSetup();
                break;
            case 'authoriseduser': return new AuthorizedUserSetup();
                break;
            case 'equipmentsetup': return SetupGeneric::useModule('Equipment');
                break;
            case 'ConsumablesType': return SetupGeneric::useModule('Equipment');
                break;
            case 'ParticipantListing': return SetupGeneric::useModule('Equipment');
                break;
            case 'vehicle': return SetupGeneric::useModule('Equipment');
                break;

            case 'vehicleFrequency': return SetupGeneric::useModule('Equipment');
                break;
            case 'Frequency': return SetupGeneric::useModule('Equipment');
                break;
            case 'Service': return SetupGeneric::useModule('Equipment');
                break;
            case 'desigination': return SetupGeneric::useModule('BCPDetail');
                break;
            case 'Rating': return SetupGeneric::useModule('Equipment');
                break;
            case 'nature1': return SetupGeneric::useModule('BCPDetail');
                break;
            case 'Criticality': return SetupGeneric::useModule('BCPDetail');
                break;
            case 'Recovery': return SetupGeneric::useModule('Equipment');
                break;
              case 'Inspection1': return SetupGeneric::useModule('Equipment');
                break;
            case 'EquipmentType': return SetupGeneric::useModule('Equipment');
                break;
            case 'EquipmentConsumables': return SetupGeneric::useModule('Equipment');
                break;
            case 'control': return SetupGeneric::useModule('ControlMeasure');
                break;
            case 'hazards': return SetupGeneric::useModule('HazardClassification');
                break;
            case 'Asset': return SetupGeneric::useModule('AssetsClassification');
                break;
            case 'AssetType': return SetupGeneric::useModule('AssetType');
                break;
            case 'AssetMan': return SetupGeneric::useModule('AssetMan');
                break;
			case 'AssetModel': return SetupGeneric::useModule('AssetModel');
                break;
			case 'AssetDesc': return SetupGeneric::useModule('AssetDesc');
                break;
            case 'hazardlists': return SetupGeneric::useModule('Hazard');
                break;
            case 'impact': return SetupGeneric::useModule('ImpactMeasure');
                break;
            case 'typetreatment': return SetupGeneric::useModule('IncidenceDetail');
                break;
            case 'accidentoccured': return SetupGeneric::useModule('IncidenceDetail');
                break;
            case 'partbody': return SetupGeneric::useModule('IncidenceDetail');
                break;
            case 'nature': return SetupGeneric::useModule('IncidenceDetail');
                break;
            case 'additionalfactor': return SetupGeneric::useModule('IncidenceDetail');
                break;
            case 'incidentanalysis': return SetupGeneric::useModule('Investigation');
                break;
            case 'immediatecauses': return SetupGeneric::useModule('Investigation');
                break;
            case 'basiccauses': return SetupGeneric::useModule('Investigation');
                break;
            case 'netimpact': return SetupGeneric::useModule('NetImpact');
                break;
            case 'timetrouble': return SetupGeneric::useModule('TimeTrouble');
                break;
            case 'enviornmentaltype': return SetupGeneric::useModule('NhpOption');
                break;
            case 'enviornmentalscale': return SetupGeneric::useModule('NhpOption');
                break;
            case 'disposition': return SetupGeneric::useModule('NhpOption');
                break;
            case 'ncr_type': return SetupGeneric::useModule('NCR');
                break;
            case 'contractors': return new Contractor();
                break;

            case 'contracts': return new Contract();
                break;
            case 'ContractFull': return new Contract();
                break;
            case 'dseAssessment': return new DseAssessment();
                break;
            case 'dseAssessmentFull': return new DseAssessment();
                break;
            case 'equipment': return new Equipment();
                break;
            case 'otherAssetIndex': return new Asset();
                break;
            case 'otherAsset': return new Asset();
                break;
            case 'manualHandling': return new ManualHandling();
                break;
            case 'manualHandlingfull': return new ManualHandling();
                break;
            case 'trainingMod': return new Training();
                break;
            case 'Inspection': return new InspectionMain();
                break;
            case 'InspectionIndex': return new InspectionMain();
                break;
            case 'incidence': return new IncidenceMain();
                break;
            case 'incidenceIndex': return new IncidenceMain();
                break;
            case 'investigation': return new InvestigationMain();
                break;
            case 'investigationIndex': return new InvestigationMain();
                break;
            case 'nhp': return new NhpMain();
                break;
            case 'ncr': return new NhpMain();
                break;
            case 'ncrIndex': return new NhpMain();
                break;
            case 'risk27k': return new Risk27k();
                break;
            case 'risk27kIndex': return new Risk27k();
                break;
            case 'soaactionexport': return new SOAActionExport();
                break;
			case 'soaactionexport1': return new SOAActionExportDetail();
                break;
			case 'allexport': return new AllExport();
                break;
			case 'allexport_p': return new AllExportP();
                break;
            case 'risk27kactionexport': return new risk27kActionExport();
                break;
            case 'risk': return new RiskAssessment();
                break;
            case 'processFlow': return new ProcessFlowMaster();
                break;
            case 'systemReviews': return new ReviewMain();
                break;
            case 'ReviewFull': return new ReviewMain();
                break;
            case 'SOAReviews': return new SOA();
                break;
            case 'nhcInvestigation': return new NhcInvestigationMain();
                break;
            case 'nhcInvestigationIndex': return new NhcInvestigationMain();
                break;
            case 'gapFilling': return new ReviewGap();
                break;
            case 'msr': return new msrAction();
                break;
            case 'inspectionrm': return new inspectionRM();
                break;
            case 'inspectionhz': return new inspectionPHY();
                break;
            case 'inspectionccp': return new inspectionCCP();
                break;
            case 'manualhandlingload': return new ManualHandlingLoad();
                break;
            case 'manualhandlingenv': return new ManualHandlingEnv();
                break;
            case 'manualhandlingind': return new ManualHandlingInd();
                break;
            case 'manualhandlingtask': return new ManualHandlingTask();
                break;
            case 'incidenceactionexport': return new IncidenceActionExport();
                break;
            case 'incidenceinvestigationactionexport': return new IncidenceIvestigationActionExport();
                break;
            case 'nhpactionexport': return new NhpActionExport();
                break;
            case 'nhcinvestigationactionexport': return new NhcInvestigationActionExport();
                break;
            case 'contributoractionexport': return new ContributorActionExport();
                break;
            case 'documentactionexport': return new DocumentActionExport();
                break;
            case 'gapfillingactionexport': return new GapFillingActionExport();
                break;
            case 'riskactionexport': return new RiskActionExport();
                break;
            case 'dseactionexport': return new DseActionExport();
                break;
            case 'contractactionexport': return new ContractActionExport();
                break;
            case 'ims': return new MSRSetup();
                break;
            case 'imsFull': return new MSRSetup();
                break;
            case 'isa': return new ISRSetup();
                break;
            case 'isaFull': return new ISRSetup();
                break;
            case 'asset_vuln': return new AssetVulnerabilitySetup();
                break;
            case 'equipmentIndex': return new Vehicle();
                break;
            case 'vehicleIndex': return new Vehicle();
                break;
            case 'equipmentIndex': return new Vehicle();
                break;
            case 'vehicle1': return new Vehicle();
                break;
            case 'BIA': return new BCPMain();
                break;
            case 'BIAFull': return new BCPMain();
                break;
            case 'Standard': return new BCPMain();
                break;
            case 'Apps': return new BCPMain();
                break;
            case 'StandardFull': return new BCPMain();
                break;
            case 'BCP': return new BCPMain();
                break;
            case 'BCPFull': return new BCPMain();
                break;
            case 'ActiveBCP': return new BCPMain();
                break;
            case 'ActiveBCPFULL': return new BCPMain();
                break;
            case 'Serious': return new BCPMain();
                break;
            case 'SeriousFull': return new BCPMain();
                break;
            case 'Severe': return new BCPMain();
                break;
            case 'SevereFull': return new BCPMain();
                break;
            case 'BIR': return new BCPMain();
                break;
            case 'BIRFULL': return new BCPMain();
                break;
            case 'BRP': return new BCPMain();
                break;
            case 'BRPFULL': return new BCPMain();
                break;
           case 'corrtype': return SetupGeneric::useModule('CommMan');
                break;
            case 'client': return SetupGeneric::useModule('CommManClient');
                break;
            case 'Context': return new Question();
                break;
            case 'ContextOpenFull': return new Question();
                break;
            case 'ContextClosed': return new Question();
                break;
            case 'ContextClosedFull': return new Question();
                break;
            case 'recdfrom': return SetupGeneric::useModule('RecdFrom');
                break;
            case 'comm_criteria': return SetupGeneric::useModule('CommCriteria');
                break;
			case 'calitype': return new Asset();
                break;
		   case 'mainttype': return new Asset();
                break;
            case 'RTA': return new RTA();
                break;
            case 'defaults': return SetupGeneric::useModule('Risk');
                break;
        }
    }

    private function getListingData() {
        //echo $this->modulename();
        //	exit;
        $obj = $this->getModuleObject();
        //$this->exportData = $obj->getListingData();

        $list = (int) $_GET['list'];

        if ($list) {
            $this->exportData = $obj->getListingforExport($list);
        } else {
            $this->exportData = $obj->getListingforExport();
        }

        //dump_array($this->exportData);
        //$listing_data = $this->exportData;
        //return $listing_data;
    }

    public function downloadFile() {

        $this->fileName;

        $this->getListingData();
        //dump_array($this);
        $this->exportObject->downloadFile($this);
    }

    
    public function downloadFileMultiArray() {

        $this->fileName;

        $this->getListingData();
        //dump_array($this);
        $this->exportObject->downloadFileMulitArray($this);
}

    

}

?>