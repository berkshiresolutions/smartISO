<?php
 /**
  $Id: ManualHandling.class.php,v 3.48 Thursday, February 03, 2011 3:14:58 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, October 08, 2010 2:07:54 PM>
  */

require_once "ManualHandling.int.php";
require_once "Action.class.php";

class ManualHandling implements ManualHandlingInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Manual Handling Id
	 *@access private
	 */
	private $manualHandlingId;

	/**
	 *Property to hold Manual Handling Info
	 *@access private
	 */
	private $manualHandlingInfo;


	/**
	 * Constructor for initializing Manual Handling object
	 * @access public
	 */
	public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/**
	 * to set manual handling information for performing various operations with the manual handling object
	 * @param integer This parameter holds the manual Handling Id
	 * @param array This parameter holds the the Manual hanlding Info
	 */
	public function setManualHandlingInfo($p_manualHandlingId,$p_manualHandlingInfo) {

		$this->manualHandlingId 	= $p_manualHandlingId;
		$this->manualHandlingInfo 	= $p_manualHandlingInfo;
	}

	/**
	 * This method is used to add a new manual handling
	 * reference,unique_reference,who,business_unit,location,date,review_date,persons_affected
	 */
	public function addManualHandling() {
		
		//allow_call_time_pass_reference = 'on';

		$sql = sprintf("SELECT * FROM %s.manual_handling WHERE reference = '%s'",_DB_OBJ_FULL,$this->manualHandlingInfo['reference']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->manualHandlingInfo['reference']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( is_array($resultSet) ) {
			throw new ErrorException('Manual Handling with this Reference # already exists.');
		} else {

	
                    $sql2 = sprintf("INSERT INTO %s.manual_handling (reference,uniqueReference,who,businessUnit,location,date,personsAffected,status,archive,nonBuPersonsAffected)
													VALUES ('%s','%s',%d,%d,%d,'%s','%s','0','0','%s') ",_DB_OBJ_FULL,
													$this->manualHandlingInfo['reference'],$this->manualHandlingInfo['unique_reference'],
													$this->manualHandlingInfo['who'],$this->manualHandlingInfo['business_unit'],
													$this->manualHandlingInfo['location'],format_date_for_mysql($this->manualHandlingInfo['date']),
													$this->manualHandlingInfo['persons_affected_bu'],$this->manualHandlingInfo['persons_affected_non_bu']);

			$pStatement = $this->dbHand->prepare($sql2);

			$pStatement->execute();
			$this->manualHandlingId = customLastInsertId($this->dbHand,'manual_handling','ID');
		}
	}

	/**
	 * This method is used to manage a manual handling operational assessment data
	 * operation_involve,operation_action
	 */
	public function manageOperationalAssessment() {

		$sql = sprintf("UPDATE %s.manual_handling SET operationalInvolve = '%s',
											operationalInvolveAction = '%s'
										WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingInfo['operation_involve'],smartisoAddslashes($this->manualHandlingInfo['operation_action']),
										$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->manualHandlingInfo['operation_involve']);
		$pStatement->bindParam(2,$this->manualHandlingInfo['operation_action']);
		$pStatement->bindParam(3,$this->manualHandlingId);*/

		$pStatement->execute();

		//dump_array($this);
	}

	/**
	 * This method is used to manage a manual handling operational assessment data
	 * operation_involve,operation_action
	 */
	public function managemechanizeOperation() {

		$sql = sprintf("UPDATE %s.manual_handling SET mechanizeOperation = '%s',
											mechanizeOperationAction = '%s'
										WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingInfo['mechanize_operation'],$this->manualHandlingInfo['operation_action'],
										$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->manualHandlingInfo['mechanize_operation']);
		$pStatement->bindParam(2,$this->manualHandlingInfo['operation_action']);
		$pStatement->bindParam(3,$this->manualHandlingId);*/

		$pStatement->execute();

		//dump_array($this);
	}

	/**
	 * This method is used to manage a manual handling operational assessment data
	 * likelihood,impact,risk_rating,risk_color
	 */
	public function manageRiskSummary() {

		$sql = sprintf("UPDATE %s.manual_handling SET likelihood = %d,
											impact = %d,
											riskRating = '%s',
											reviewDate = '%s',
											riskRatingColor = '%s'
										WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingInfo['likelihood'],$this->manualHandlingInfo['impact'],
										$this->manualHandlingInfo['risk_rating'],format_date_for_mysql($this->manualHandlingInfo['review_date']),$this->manualHandlingInfo['risk_color'],
										$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->manualHandlingInfo['likelihood']);
		$pStatement->bindParam(2,$this->manualHandlingInfo['impact']);
		$pStatement->bindParam(3,$this->manualHandlingInfo['risk_rating']);
		$pStatement->bindParam(4,$this->manualHandlingInfo['risk_color']);
		$pStatement->bindParam(5,$this->manualHandlingId);*/

		$pStatement->execute();


		/*dump_array($this);*/
	}

	/**
	 * This method is used to manage a manual handling operational assessment data
	 * process_number,risk_valid
	 */
	public function manageProcess() {

		$sql = sprintf("UPDATE %s.manual_handling SET processNo = %d,
											isRiskValid = '%s'
										WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingInfo['process_number'],$this->manualHandlingInfo['risk_valid'],
										$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);


		$pStatement->execute();


		/*dump_array($this);*/
	}

	/**
	 * This method is used to view the manual handling information.
	 */
	public function viewManualHandling() {

		$sql = sprintf("SELECT * FROM %s.manual_handling WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->manualHandlingId);

		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to edit the manual handling
	 */
	public function editManualHandling() {

		$sql = sprintf("UPDATE %s.manual_handling SET who = %d,
											businessUnit = %d,
											location = %d,
											date = '%s',
											personsAffected = '%s',
											nonBuPersonsAffected= '%s'
										WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingInfo['who'],$this->manualHandlingInfo['business_unit'],
										$this->manualHandlingInfo['location'],format_date_for_mysql($this->manualHandlingInfo['date']),
										$this->manualHandlingInfo['persons_affected_bu'],$this->manualHandlingInfo['persons_affected_non_bu'],$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);


		$pStatement->execute();
	}

	/**
	 * This method is used to manage the manual handling Sections
	 */
	public function manageManualHandlingSection() {

		switch ( $this->manualHandlingInfo['section'] ) {

			case 3: $module_identifier = "manual_handlingT"; break;
			case 4: $module_identifier = "manual_handlingL"; break;
			case 5: $module_identifier = "manual_handlingE"; break;
			case 6: $module_identifier = "manual_handlingI"; break;
		}

		$this->actionData = array('module_name'=>$module_identifier,'description'=>smartisoAddslashes($this->manualHandlingInfo['action']),
								  'who'=>$this->manualHandlingInfo['who'],'whoAU'=>$this->manualHandlingInfo['whoAU'],'who2AU'=>$this->manualHandlingInfo['who2AU'],'due_date'=>$this->manualHandlingInfo['when']);

		if ( $this->manualHandlingInfo['section_record_id'] ) {
			if ( $this->manualHandlingInfo['question_checked'] ) {
				// update record and add action
				$this->editSectionData($this->manualHandlingInfo['section_record_id']);
			} else {
				// delete record and action
				$this->deleteSectionData($this->manualHandlingInfo['section_record_id']);
			}
		} else {
			if ( $this->manualHandlingInfo['question_checked'] ) {
				// add record action
				$this->addSectionData();
			}
		}
	}

	private function addSectionData() {

		$sql = sprintf("INSERT INTO %s.manual_handling_actions (manualID,sectionId,questionId,problem,actionID)
												VALUES (%d,%d,%d,'%s',NULL)",_DB_OBJ_FULL,$this->manualHandlingId,
												$this->manualHandlingInfo['section'],$this->manualHandlingInfo['question_id'],smartisoAddslashes($this->manualHandlingInfo['problem']));
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->manualHandlingId);
		$pStatement->bindParam(2,$this->manualHandlingInfo['section']);
		$pStatement->bindParam(3,$this->manualHandlingInfo['question_id']);
		$pStatement->bindParam(4,$this->manualHandlingInfo['problem']);*/

		$pStatement->execute();
		//dump_array($pStatement->errorInfo());
		$sectionLastrecordId = customLastInsertId($this->dbHand,'manual_handling_actions','ID');
                $this->actionData['record']=$sectionLastrecordId;
                $this->actionData['element']="manual_handling_actions";
		$this->actionHandling->setActionDetails(0,$this->actionData);
		$action_id = $this->actionHandling->addAction2015();

		$sql1 = sprintf("UPDATE %s.manual_handling_actions SET actionID = %d WHERE ID= %d ",_DB_OBJ_FULL,$action_id,$sectionLastrecordId);
		$pStatement1 = $this->dbHand->prepare($sql1);

		$pStatement1->execute();

	}

	private function editSectionData($p_sectionID) {

		$sectionData = $this->viewSectionDataById($p_sectionID);
		$this->actionHandling->setActionDetails($sectionData['actionID'],$this->actionData);
		$this->actionHandling->updateAction2015();

		$sql = sprintf("UPDATE %s.manual_handling_actions SET problem  = '%s' WHERE ID = %d",
					   _DB_OBJ_FULL,smartisoAddslashes($this->manualHandlingInfo['problem']),$p_sectionID);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
	}

	private function deleteSectionData($p_sectionID) {

		$sectionData = $this->viewSectionDataById($p_sectionID);

		$this->actionHandling->setActionDetails($sectionData['actionID'],"");
		$this->actionHandling->deleteAction();

		$sql = sprintf("DELETE FROM %s.manual_handling_actions WHERE ID = %d ",_DB_OBJ_FULL,$p_sectionID);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$p_sectionID);

		$pStatement->execute();
	}

	private function viewSectionDataById($p_sectionID) {

		$sql = sprintf("SELECT * FROM %s.manual_handling_actions WHERE ID = %d ",_DB_OBJ_FULL,$p_sectionID);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$p_sectionID);

		$pStatement->execute();
		$result = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function viewSectionData() {
		$sql = sprintf("SELECT * FROM %s.manual_handling_actions WHERE manualID = %d AND sectionId = %d ",_DB_OBJ_FULL,$this->manualHandlingId,
					   $this->manualHandlingInfo['section']);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->manualHandlingId);
		$pStatement->bindParam(2,$this->manualHandlingInfo['section']);*/

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $value ) {
			$question_id = $value['questionId'];

			$sectionData[$question_id]['id'] = $value['ID'];
			$sectionData[$question_id]['problem'] = $value['problem'];
			$sectionData[$question_id]['question'] = $value['questionId'];

			$this->actionHandling->setActionDetails($value['actionID'],"");
			$action_data = $this->actionHandling->viewAction();

			$sectionData[$question_id]['actionId'] = $value['actionID'];
			$sectionData[$question_id]['action'] = $action_data['actionDescription'];
			$sectionData[$question_id]['who'] = $action_data['who'];
			$sectionData[$question_id]['whoAU'] = $action_data['whoAU'];
                        $sectionData[$question_id]['whoAU2'] = $action_data['addapprover'];
			$sectionData[$question_id]['when'] = $action_data['dueDate'];
		}

		return $sectionData;
	}

	/**
	 * This method is used to view the All manual handling information.
	 */
	public function viewAllManualHandling() {

		$sql = sprintf("SELECT * FROM %s.manual_handling WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->manualHandlingInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->manualHandlingInfo['archive']);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to delete the manual handling
	 */
	public function deleteManualHandling() {
		$section = array(3,4,5,6);
		$sql2 = "SELECT * FROM %s.manual_handling_actions WHERE manualID = %d AND sectionId = %d ";

		/*$pStatement = $this->dbHand->prepare($sql);
		$pStatement->bindParam(1,$this->manualHandlingId);*/

		foreach ( $section as $value ) {

			$sql = sprintf($sql2,_DB_OBJ_FULL,$this->manualHandlingId,$value);
			$pStatement = $this->dbHand->prepare($sql);
			//$pStatement->bindParam(2,$value);

			$pStatement->execute();
			$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
			if ( is_array($result) ) {
				foreach($result as $value ) {
					$this->deleteSectionData($value['ID']);
				}
			}
		}

		$sql = sprintf("DELETE FROM %s.manual_handling WHERE ID = %d ",_DB_OBJ_FULL,$this->manualHandlingId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->manualHandlingId);
		$pStatement->execute();
	}

	/**
	 * This method is used to archive the manual handling
	 */

	public function archiveManualHandling() {

		$sql = sprintf("UPDATE %s.manual_handling SET archive = '%s'
										WHERE ID = %d",_DB_OBJ_FULL,$this->manualHandlingInfo['archive'],$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->manualHandlingInfo['archive']);
		$pStatement->bindParam(2,$this->manualHandlingId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to remove the manual handling
	 */
	public function purgeManualHandling() {}

	/**
	 * This method is used to get last record insert Id
	 */
	public function lastInsertID() {
		return $this->manualHandlingId;
	}

	public function getOutstandingActionsDeprec($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('manual_handling%');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('manual_handling%');
		}

		if ( is_array($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT M.reference,M.businessUnit,M.ID AS manual_id FROM %s.manual_handling M
												INNER JOIN %s.manual_handling_actions A
												ON A.manualID = M.ID
											WHERE A.actionID = %d ",_DB_OBJ_FULL,_DB_OBJ_FULL,$search_value1);

				$pStatement = $this->dbHand->prepare($sql);

				//$pStatement->bindParam(1,$search_value1);

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( is_array($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['businessUnit'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['whoAU']			 = $value['whoAU'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['manual_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function updateStatus() {

		$sql = sprintf("UPDATE %s.manual_handling SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->manualHandlingId);
		$pStatement->execute();

	}

	public function sendActionAlerts($p_record_id) {

		$this->manualHandlingId = $p_record_id;

		$manual_details = $this->viewManualHandling();

		$sql = sprintf("SELECT * FROM %s.manual_handling_actions WHERE manualID = %d ORDER BY sectionId,questionId ASC",_DB_OBJ_FULL,$this->manualHandlingId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->manualHandlingId);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($records);

		if ( is_array($records) ) {
			$i = 0;
			foreach ( $records as $value ) {

				if ( $value['actionID'] ) {

					$this->actionHandling->setActionDetails($value['actionID'],"");
					$action = $this->actionHandling->viewAction();

					if ( is_array($action) ) {

						$dse_action = $action;
						$email_data[$i]['reference']	 = $manual_details['reference'];
						$email_data[$i]['summary']		 = $action['actionDescription'];
						$email_data[$i]['due_date']		 = format_date($action['dueDate']);
						$email_data[$i]['who']			 = $action['who'];

						$this->actionHandling->updateStatus($action['ID']);
						$i++;
					}

				}
			}
		}
		return $email_data;
	}
	
	public function getListingforExport() {

		  $type = $_GET['type'];

		if ( $type  =='full') {

			return $this->getEquipementExportDataFull();

		} else {

			return $this->getEquipementExportData();
		}
	}
	
	public function getEquipementExportDataFull() {

		$type = $_GET['type'];
		$data_array['likelihood']	= $_GET['likelihood'];
		$data_array['impact']		= $_GET['impact'];

		$orgObj				= SetupGeneric::useModule('Organigram');
		$locObj				= SetupGeneric::useModule('Locationgram');
		$participantObj		= SetupGeneric::useModule('Participant');

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		if ( $type ) {

			$this->setManualHandlingInfo(1,$data_array);
			$manual_handling_data = $this->searchRecords();
			//dump_array($manual_handling_data);exit;

		} else {

			$this->setManualHandlingInfo(1,array('archive'=>$archive_session));
			$manual_handling_data = $this->viewAllManualHandling();
		}
			//dump_array($manual_handling_data);exit;
		$heading = array(array('Reference #', 'Business Unit', 'Who', 'Location','Date','Does the operation involve a significant risk of injury?*If "No" proceed to Risk Summary','Task','Load','Environment','Individaul','Mechanize Operation','Risk Summary'));
		$result = array();

		if ( is_array($manual_handling_data) ) {

			foreach ( $manual_handling_data as $element ) {
			$record_id = $_GET['ID'];
			$arguments = array('section'=>3);
$this->setManualHandlingInfo($record_id,$arguments);
$data = $this->viewSectionData();

				$orgObj->setItemInfo(array('id'=>$element['businessUnit']));
				$bu_details = $orgObj->displayItemById();
				$business_unit = $bu_details['buName'];

				$participant_id = $element['who'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$locObj->setItemInfo(array('id'=>$element['location']));
				$location_data = '';
				$location = $locObj->getFUllLocation();
				$location = str_replace(',', '-', $location);
				
				if($element['operationalInvolve']){
				$element['operationalInvolve'] = 'Yes';
				
				}else{
				$element['operationalInvolve'] = 'No';
				}

				$result[] = array($element['reference'], $business_unit, $participant_name, $location,$element['date'],$element['operationalInvolve']);
			}

			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}

	public function getEquipementExportData() {

		$type = $_GET['type'];
		$data_array['likelihood']	= $_GET['likelihood'];
		$data_array['impact']		= $_GET['impact'];

		$orgObj				= SetupGeneric::useModule('Organigram');
		$locObj				= SetupGeneric::useModule('Locationgram');
		$participantObj		= SetupGeneric::useModule('Participant');

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		if ( $type ) {

			$this->setManualHandlingInfo(1,$data_array);
			$manual_handling_data = $this->searchRecords();
			//dump_array($manual_handling_data);exit;

		} else {

			$this->setManualHandlingInfo(1,array('archive'=>$archive_session));
			$manual_handling_data = $this->viewAllManualHandling();
		}

		$heading = array(array('Reference #', 'Business Unit', 'Who', 'Location'));
		$result = array();

		if ( is_array($manual_handling_data) ) {

			foreach ( $manual_handling_data as $element ) {

				$orgObj->setItemInfo(array('id'=>$element['businessUnit']));
				$bu_details = $orgObj->displayItemById();
				$business_unit = $bu_details['buName'];

				$participant_id = $element['who'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$locObj->setItemInfo(array('id'=>$element['location']));
				$location_data = '';
				$location = $locObj->getFUllLocation();
				$location = str_replace(',', '-', $location);

				$result[] = array($element['reference'], $business_unit, $participant_name, $location);
			}

			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}

	public function searchRecords() {

		$filter = "";

		if ( $this->manualHandlingInfo['likelihood'] ) {
			$filter .= "AND likelihood = ".$this->manualHandlingInfo['likelihood'];
		}

		if ( $this->manualHandlingInfo['impact'] ) {
			$filter .= " AND impact = ".$this->manualHandlingInfo['impact'];
		}

		$sql = sprintf("SELECT * FROM %s.manual_handling WHERE archive = '0'",_DB_OBJ_FULL);

		$sql = $sql.$filter;

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->manualHandlingInfo['archive']);
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/* function is used to send mail to manager of approved record */

	public function getActionTrackerEmailData($p_record_id) {
		$sql2 = sprintf("SELECT N.*,M.sectionId FROM %s.manual_handling_actions M
						INNER JOIN %s.manual_handling N ON N.ID=M.manualID WHERE M.actionID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_record_id);

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();
		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);


		switch($result[0]['sectionId']) {
			case 3 : $tab = 'Task'; break;
			case 4 : $tab = 'Load'; break;
			case 5 : $tab = 'Environment'; break;
			case 6 : $tab = 'Individual'; break;
		}


		$email_data['reference']		 	= $result[0]['reference'];
		$email_data['dueDate']		 		= $result[0]['date'];
		$email_data['who_id']		 		= $result[0]['who'];
		$email_data['bu_id']		 		= $result[0]['businessUnit'];
		$email_data['tab']		 			= $tab;


		return $email_data;
	}
	
	public function displayReportBybu($business_unit_id) {
		
		$this->bu_id = $business_unit_id;

		$sql = "SELECT ID FROM %s.dse_assessment WHERE participantBusinessUnit = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->bu_id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		$colcount = $stmt->rowCount();

		if ( $colcount ) {
			return $result;
		} else {
			return 0;
		}
	}
	public function displayNameBybu($business_unit_id) {
		
		$this->bu_id = $business_unit_id;

		$sql = "SELECT buName FROM %s.business_units WHERE buID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->bu_id);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchcolumn();
		return $result;
		
	}
	
	                 	public function getOverDueActions($buStr,$date) {
     $sql_query = sprintf("select A.id,M.reference,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,MHA.problem,B.buName,(P.forename +' '+P.surname) as who_name   from %s.actions A  inner join %s.manual_handling_actions MHA on A.record=MHA.ID left join %s.manual_handling M on MHA.manualID=M.ID left join %s.business_units B on M.businessunit=B.buID  left join %s.participant_database P on A.currentWho=P.participantID  where modulename like '%s' and B.buID in(%s) and approveAU=0 and duedate < '%s'
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, "manual_handling%",$buStr,$date);
			
		$pStatement = $this->dbHand->prepare($sql_query);


		$pStatement->execute();
		$data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $data;
	}
        
        	                 	public function getOutStandingActions($buStr,$fdate) {
									
$insp_out 			= SetupGeneric::useModule('InspectionOutstandingAction');
$outstanding_duration = explode(':',$insp_out->displayItems());

switch($outstanding_duration[1]) {
	case 'M' : $interval = '+'.$outstanding_duration[0].' MONTH'; break;
	case 'Y' : $interval = '+'.$outstanding_duration[0].' YEAR'; break;
}

        $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");
                                   
                                            
  $sql_query = sprintf("select A.id,M.reference,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,MHA.problem,B.buName,(P.forename +' '+P.surname) as who_name   from %s.actions A  inner join %s.manual_handling_actions MHA on A.record=MHA.ID left join %s.manual_handling M on MHA.manualID=M.ID left join %s.business_units B on M.businessunit=B.buID  left join %s.participant_database P on A.currentWho=P.participantID  where modulename like '%s' and B.buID in(%s) and approveAU=0 and duedate >=  '%s'
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, "manual_handling%",$buStr,$outstandingDate);
			
		$pStatement = $this->dbHand->prepare($sql_query);


		$pStatement->execute();
		$data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $data;
	}
        	public function getActionEmailData($p_record_id) {
		$sql2 = sprintf("SELECT N.*,M.sectionId,M.actionID FROM %s.manual_handling_actions M
						INNER JOIN %s.manual_handling N ON N.ID=M.manualID WHERE M.manualID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_record_id);

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();
		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);


		return $result;
	}

}
?>