<?php
 /**
  $Id: InvestigationMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, November 04, 2010 8:32:17 AM>
  */
require_once "Action.class.php";

class smartlawReviews
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Investigation Id
	 *@access private
	 */
	private $investigationId;

	/**
	 *Property to hold Investigation Info
	 *@access private
	 */
	private $investigationInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing Investigation object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setInvestigationInfo($p_investigationId,$p_investigationInfo) {

		$this->investigationId		=	$p_investigationId;
		$this->investigationInfo	=	$p_investigationInfo;
	}

	public function getListingforExport() {
		
		$is_admin = false;
		$show_participant_name = false;

		
		if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
				$is_admin = false;
	
			} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
				$show_participant_name = true;
		}

		$heading = array(array('reference'=>'Title #','modulename'=>'Type','action'=>'Action','due'=>'Due Date','assigned'=>'Assigned To','done'=>'Done Date'));
		$p_moduleName = 'smartlawreview';
		$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
		//echo $tab_type;
	    $actTrackObj = new ActionTracker();
	
		$actTrackObj->setActionTrackerInfo('smartlawreview',$tab_type,$p_dateFilter='');
		$resultset = $actTrackObj->getActionsForActionTracker();

                if(!empty($resultset)){
			
			foreach($resultset as $resultElement){
			
			$ac_id = $resultElement['ID'];
			$action_description 		= compact_action_tracker_description($resultElement['actionDescription']);
			$action_description_full 	= javascript_safe_string($resultElement['actionDescription']);
			
 
			$result[$i]['reference'] = $resultElement['reference'];
			$result[$i]['modulename'] = "Review";
			$result[$i]['action'] = $action_description_full;
			$result[$i]['due'] = format_datetime($resultElement['dueDate']);
			$result[$i]['assigned'] = $resultElement['who_name'];
			$result[$i]['done'] = format_datetime($resultElement['doneDate']);
			$i++;
			
		}
		$result = array_merge($heading,$result);
		return $result;
			
		}
		
	}


	
}
?>