<?php
 /**
  $Id: Contractor.class.php,v 3.60 Thursday, February 03, 2011 3:17:03 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage ContractorEvaluation object
  *
  * This interface will declare the various methods performed
  * by the contractor object for operations like add, edit, delete, archive, purge.
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */



class ContractorEval
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;



	/**
	 * Property to hold contractor ID
	 * @access private
	 */
	private $contractorEvalId;

	/**
	 * Property to hold contractor ID
	 * @access private
	 */
	private $newcontractorEvalId;
	
	/**
	 * Property to hold contractor Data
	 * @access private
	 */
	private $contractorInfo;



	/**
	 * Property to hold upper range value
	 * @access private
	 */
	private $lowerValue;

	/**
	 * Property to hold lower range value
	 * @access private
	 */
	private $upperValue;

	/**
	 * Constructor for initializing Contractor object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 				= DB::connect(_DB_TYPE);

	}

	/**
	 * to set contractor information for performing various operations with the Contractor object
	 * @param integer $p_contractorId 	This parameter is used to set contractor id for adding, editing, archiving, restoring, delete
	 * @param integer $p_currentTab 	This parameter is used to define current working tab
	 * @param array $p_contractorInfo	This array is used to pass set of parameters for each tab. This is Optional
	 */
	public function setContractorEvalInfo($p_contractorId,$p_contractorInfo,$p_lowerValue=40,$p_upperValue=60) {

		$this->contractorEvalId 		= $p_contractorEvalId;
		$this->contractorInfo 		= $p_contractorInfo;
		$this->lowerValue 			= $p_lowerValue;
		$this->upperValue 			= $p_upperValue;
	}


	/**
	 * This method is used to add a new contractor
	 *
	 *
	 *  unique_reference,reference,email,company_name,location,address,contact_person,date,telephone_number,fax,business unit id
	 *
	 *
	 * @access public
	 */
	public function addContractorEval() {
	//	$USER_ID = getLoggedInUserId();

		$sql = sprintf("INSERT INTO %s.contractor_evaluation (contractorID,whoID,dateAdded,task,rating)
		VALUES (%d,'%s','%s','%s','%d')",_DB_OBJ_FULL,$this->contractorInfo['contractorid'],
		$this->contractorInfo['whoID'],$this->contractorInfo['dateAdded'],smartisoAddslashes($this->contractorInfo['task']),
		$this->contractorInfo['rating']);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

				$this->newcontractorEvalId = customLastInsertId($this->dbHand,'contractor_evaluation','ID');
		
	}

		public function addContractorEvalProblems() {
	//	$USER_ID = getLoggedInUserId();

		$sql = sprintf("INSERT INTO %s.contract_eval_problem (celink,problem,action)
		VALUES (%d,'%s','%s')",_DB_OBJ_FULL,$this->newcontractorEvalId,$this->contractorInfo['problems'],
		$this->contractorInfo['suggested_action']);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

	}


}