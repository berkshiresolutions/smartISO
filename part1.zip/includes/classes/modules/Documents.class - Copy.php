<?php

/**
  $Id: Documents.class.php,v 9.67 Monday, January 31, 2011 9:54:24 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Interface to manage Manage Document object
 *
 * This class will define the various methods performed
 * by document object for operations like add, edit, delete, archive, purge.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Interface
 * @since  Friday, September 10, 2010 8:17:06 PM>
 */
require_once "Documents.int.php";

define("_STD_ID", 52);

class Documents implements DocumentsInterface {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;
    private $xmlobj;
    private $xmlDocumentName;
    private $documentInformation;
    private $documentId;
    private $participantObj;
    private $fileObj;
    private $logged_user_name;
    private $file_data;
    private $form_data;
    private $alert_data;
    private $checkArr;
    private $version_type;
    private $country;

    /**
     * Constructor for initializing Dse Assessment object
     * @access public
     */
    public function __construct() {
        $this->dbHand = DB::connect(_DB_TYPE);
        $this->xmlDocumentName = 'documents.xml';

        $this->participantObj = SetupGeneric::useModule('Participant');
        $this->fileObj = new Upload();
        $optObj = new Option();
        $this->version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
        $this->country = $optObj->getOption('_SU_DOCCONTROL_ALLOW_COUNTRY');
        $this->logged_user_name = Session::getSessionField('SESS_FULLNAME');

        $this->form_data = array('P' => array('class' => 'filePr', 'str' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Pr] '), 'W' => array('class' => 'fileDo', 'str' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[WI] '), 'D' => array('class' => 'fileDo', 'str' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Do] '), 'E' => array('class' => 'classex', 'str' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Ex] '), 'F' => array('class' => 'fileFo', 'str' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Fo] '), 'G' => array('class' => 'fileDo', 'str' => '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[GP] '));
    }

    /**
     * This method is used to set document information before uploading and edit operation.
     */
    public function setDocumentInfo($p_doc_info) {
        $this->documentInformation = $p_doc_info;
    }

    public function uploadDocument3($p_recordSep = 0) {

        $p_recordSep_org = $p_recordSep;

        try {

            $this->uploadDocumentFile();




            $optObj = null;

            return $this->documentId;
        } catch (ErrorException $e) {
            $objFile = null;
            // maybe needed later
            //   throw new ErrorException('Invalid File format', 11);
        }
    }

    /**
     * This method is used to upload the document
     */
    public function uploadDocument($p_recordSep = 0, $status = 'U') {
        $this->errorStr = 'ok';
        $p_recordSep_org = $p_recordSep;

        try {

            $this->uploadDocumentFile();

            $standard_id = _STD_ID;

            if ($this->documentInformation['gap_document']) {
                $is_gap_document = 1;
            } else {
                $is_gap_document = 0;
            }

            $default_status = $status;

            $optObj = new Option();
            $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

            if ($version_type == 'version') {
                $version_type = 'V';
            } else if ($version_type == 'revision') {
                $version_type = 'R';
            } else {
                $version_type = 'M';
            }

            $optObj = null;

            if ($this->documentInformation['version_old'] == '') {
                $this->documentInformation['version_old'] = '-';
            }

            if ($p_recordSep == 0) {

                if (_DB_TYPE != 'mysql') {
                    $sql = sprintf("SELECT TOP 1 recordSep FROM %s.cms_documents
							   WHERE fileReference LIKE '%s'
							   ORDER BY recordSep DESC", _DB_OBJ_FULL, $this->documentInformation['file_reference']);
                } else {
                    $sql = sprintf("SELECT recordSep FROM %s.cms_documents
							   WHERE fileReference LIKE '%s'
							   ORDER BY recordSep DESC LIMIT 1", _DB_OBJ_FULL, $this->documentInformation['file_reference']);
                }

                $stmt = $this->dbHand->prepare($sql);

                $stmt->execute();
                $record_sep_result = $stmt->fetch(PDO::FETCH_ASSOC);
                $p_recordSep = $record_sep_result['recordSep'] + 1;
            }
            if ($this->documentId == '0') {

                $this->documentId = $this->documentInformation['path_id'];
                $default_status = 'D';
            }

            if ($this->documentInformation['comingF'] == 'review') {

                $default_status = 'g';
            }

            $sql88 = sprintf("SELECT documentID FROM %s.cms_documents
							  	WHERE cmsdocID=" . $this->documentInformation['fileid'] . "", _DB_OBJ_FULL);
            $stmt = $this->dbHand->prepare($sql88);

            $stmt->execute();
            $part = $stmt->fetch(PDO::FETCH_ASSOC);

            //dump_array($this->documentInformation);
            if ($this->documentInformation['fileid'] == 0)
                $this->documentInformation['fileid'] = $this->documentId;

            $sql = sprintf("INSERT INTO %s.cms_documents (documentID,versionOld,versionNew,fileReference,title,description,
					documentType,documentSubType,dateInitiated,initiatedByParticipant,actionSummary,pages,
					standardID,buID,isGapDocument,status,classification,docControl,versionMinor,isArchive, reasonForUpdate, recordSep,alertType,parent_id,docIssuer,immediate_summary,scope,audit,induct,isIS,affected_bus,reviewdate,location,code27002)
					VALUES (%d,'%s', '%s' ,'%s' ,'%s' ,'%s', '%s', '%s', '%s', %d, '%s', %d, %d, %d, %d, '%s', '%s', '%s','%s',%d,'%s',%d,'%s',%d,%d,'%s',%d,%d,%d,%d,'%s','%s',%d,%d)"
                    , _DB_OBJ_FULL
                    , $this->documentInformation['fileid']
                    , $this->documentInformation['version_old']
                    , $this->documentInformation['version']
                    , $this->documentInformation['file_reference']
                    , $this->documentInformation['document_name']
                    , $this->documentInformation['document_description']
                    , $this->documentInformation['document_type']
                    , $this->documentInformation['check_document']
                    , $this->documentInformation['date_initiated']
                    , $this->documentInformation['initiated_by']
                    , $this->documentInformation['action_summary']
                    , $this->documentInformation['pages']
                    , $standard_id
                    , $this->documentInformation['business_unit']
                    , $is_gap_document
                    , $default_status
                    , $this->documentInformation['document_class']
                    , $version_type
                    , $this->documentInformation['version_minor']
                    , 0
                    , $this->documentInformation['reason_for_update']
                    , $p_recordSep
                    , $this->documentInformation['check_type']
                    , $this->documentInformation['path_id']
                    , getLoggedInUserId()
                    , $this->documentInformation['action_imm']
                    , $this->documentInformation['scope']
                    , $this->documentInformation['ia']
                    , $this->documentInformation['id']
                    , $this->documentInformation['is']
                    , $this->documentInformation['slr_bu']
                    , $this->documentInformation['reviewdate']
                    , $this->documentInformation['location']
                    , $this->documentInformation['code51']);

            $stmt = $this->dbHand->prepare($sql);


            $stmt->execute();

            $last_insert_id = customLastInsertId($this->dbHand, 'cms_documents', 'cmsdocID');

            $versionComment = '';
            $allocatedTo = 0;
            $gapDocID = (int) $this->documentInformation['doc_id'];
            $authorizerComment = '';
            $uploadedBy = 0;
            $dateApproved = '1900-01-01';
            $approvedBy = 0;

            $sql_sec = sprintf("INSERT INTO %s.cms_documents_metadata
					(cmsdocID,versionComment,allocatedTo,gapDocID,authorizerComment,uploadedBy,dateApproved,approvedBy)
					VALUES (%d, '%s', %d, %d, '%s', %d, '%s', %d)"
                    , _DB_OBJ_FULL
                    , $last_insert_id
                    , $versionComment
                    , $allocatedTo
                    , $gapDocID
                    , $authorizerComment
                    , $uploadedBy
                    , $dateApproved
                    , $approvedBy);

            $stmt_sec = $this->dbHand->prepare($sql_sec);

            $stmt_sec->execute();

            if ($this->documentInformation['STOWcode']) {
                $sql = sprintf("INSERT INTO %s.cms_doc_std_links(cmsid,sid,code)
				VALUES(%d, %d,'%s')"
                        , _DB_OBJ_FULL
                        , $last_insert_id
                        , $this->documentInformation['altStd']
                        , $this->documentInformation['STOWcode']);


                $stmt = $this->dbHand->prepare($sql);

                $stmt->execute();
            }



            if ($p_recordSep_org == 0) {
                $message = "Uploaded document '" . $this->documentInformation['document_name'] . "' for " . $this->documentInformation['file_reference'] . " - " . $this->documentInformation['document_name'] . " by " . $this->logged_user_name;
                $this->saveDocumentLog($last_insert_id, $message, $this->documentInformation['reason_for_update']);
            }
            $p_approved_by = getLoggedInUserId();
            $participantObj = SetupGeneric::useModule('Participant');
            $participantObj->setItemInfo(array('id' => $p_approved_by));
            $partcipantData = $participantObj->displayItemById();

            $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

            $message = "Document has been updated by " . $contributor_name;
            $this->saveDocumentLog($last_insert_id, $message, $this->documentInformation['reason_for_update']);
            if ($this->documentInformation['pi']) {
                $this->authorizeDocument1($last_insert_id, date('m/d/Y'), $p_approved_by);
                $message = "Document has been published by " . $contributor_name;
                $this->saveDocumentLog($last_insert_id, $message, $this->documentInformation['action_imm']);
            }
            $participantObj = null;


            return $last_insert_id;
        } catch (ErrorException $e) {
            $objFile = null;
            throw new ErrorException($e->getMessage(), 11);
        }
    }

    public function displayItemMaininfoById($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.participant_database
				WHERE
					participantID =" . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function documentReplaceFrontEnd() {

        //dump_array($this->documentInformation);
        //exit;
        $p_recordSep_org = $p_recordSep;

        try {

            $this->uploadDocumentFile();

            $standard_id = _STD_ID;

            if ($this->documentInformation['gap_document']) {
                $is_gap_document = 1;
            } else {
                $is_gap_document = 0;
            }

            $default_status = 'U';

            $optObj = new Option();
            $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

            if ($version_type == 'version') {
                $version_type = 'V';
            } else if ($version_type == 'revision') {
                $version_type = 'R';
            } else {
                $version_type = 'M';
            }

            $optObj = null;


            if ($this->documentInformation['version_old'] == '') {
                $this->documentInformation['version_old'] = '-';
            }

            if ($p_recordSep == 0) {

                if (_DB_TYPE != 'mysql') {
                    $sql = sprintf("SELECT TOP 1 recordSep FROM %s.cms_documents
							   WHERE fileReference LIKE '%s'
							   ORDER BY recordSep DESC", _DB_OBJ_FULL, $this->documentInformation['file_reference']);
                } else {
                    $sql = sprintf("SELECT recordSep FROM %s.cms_documents
							   WHERE fileReference LIKE '%s'
							   ORDER BY recordSep DESC LIMIT 1", _DB_OBJ_FULL, $this->documentInformation['file_reference']);
                }


                $stmt = $this->dbHand->prepare($sql);

                $stmt->execute();
                $record_sep_result = $stmt->fetch(PDO::FETCH_ASSOC);
                $p_recordSep = $record_sep_result['recordSep'] + 1;
            }

            $sql88 = sprintf("SELECT documentID FROM %s.cms_documents
							  	WHERE cmsdocID=" . $this->documentInformation['doc_id'] . "", _DB_OBJ_FULL);
            $stmt = $this->dbHand->prepare($sql88);

            $stmt->execute();
            $part = $stmt->fetch(PDO::FETCH_ASSOC);


            $sql = sprintf("UPDATE %s.cms_documents SET documentID=" . $this->documentId . ",versionOld='" . $this->documentInformation['version_old'] . "',versionNew=" . $this->documentInformation['version'] . ",fileReference='" . $this->documentInformation['file_reference'] . "',title='" . $this->documentInformation['document_name'] . "',description='" . $this->documentInformation['document_description'] . "',
					parent_id=" . $part['documentID'] . ",documentType='" . $this->documentInformation['document_type'] . "',documentSubType='" . $this->documentInformation['check_document'] . "',dateInitiated='" . $this->documentInformation['date_initiated'] . "',initiatedByParticipant='" . $this->documentInformation['initiated_by'] . "',actionSummary='" . $this->documentInformation['action_summary'] . "',pages=" . $this->documentInformation['pages'] . ",reasonForUpdate='" . $this->documentInformation['reason_for_update'] . "'
					WHERE cmsdocID=" . $this->documentInformation['doc_id'] . "", _DB_OBJ_FULL);




            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $last_insert_id = $this->documentInformation['doc_id'];

            $versionComment = '';
            $allocatedTo = 0;
            $gapDocID = (int) $this->documentInformation['doc_id'];
            $authorizerComment = '';
            $uploadedBy = 0;
            $dateApproved = '1900-01-01';
            $approvedBy = 0;

            if ($p_recordSep_org == 0) {
                $message = "Uploaded document '" . $this->documentInformation['document_name'] . "' for " . $this->documentInformation['file_reference'] . " - " . $this->documentInformation['document_name'] . " by " . $this->logged_user_name;
                $this->saveDocumentLog($this->documentInformation['doc_id'], $message, $this->documentInformation['reason_for_update']);
            }
            $p_approved_by = getLoggedInUserId();
            $participantObj = SetupGeneric::useModule('Participant');
            $participantObj->setItemInfo(array('id' => $p_approved_by));
            $partcipantData = $participantObj->displayItemById();

            $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

            $message = "Document has been replaced by " . $contributor_name;
            $this->saveDocumentLog($this->documentInformation['doc_id'], $message, $this->documentInformation['reason_for_update']);
            $participantObj = null;

            return $this->documentId;
        } catch (ErrorException $e) {
            $objFile = null;
            throw new ErrorException('Invalid File format', 11);
        }
    }

    /**
     * This method is used to upload the document
     */
    public function replaceDocument() {

        $document_information = $this->getDocumentInformation($this->documentInformation['doc_id']);

        $this->uploadDocument($document_information['recordSep']);

        $p_approved_by = getLoggedInUserId();
        $participantObj = SetupGeneric::useModule('Participant');
        $participantObj->setItemInfo(array('id' => $p_approved_by));
        $partcipantData = $participantObj->displayItemById();

        $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
        $reason = '-----';
        $message = "Document has been Uploaded by " . $contributor_name;
        $this->saveDocumentLog($this->documentInformation['doc_id'], $message, $reason);
        $participantObj = null;

        $message = "Document Replaced '" . $this->documentInformation['document_name'] . "' for " . $this->documentInformation['file_reference'] . " - " . $this->documentInformation['document_name'] . " by " . $this->logged_user_name;

        $this->saveDocumentLog($this->documentInformation['doc_id'], $message, $reason);
    }

    /**
     * This method is used to upload the document
     */
    public function replaceDocumentDeprecated() {

        $document_information = $this->getDocumentInformation($this->documentInformation['doc_id']);

        $old_document_id = $document_information['documentID'];

        $this->updDocReplaceInfo($this->documentInformation['doc_id'], $old_document_id, '0', true);
        $this->uploadDocumentFile();

        $sql_sec = sprintf("UPDATE %s.cms_documents_metadata
				SET versionComment = ?
				WHERE cmsdocID = ?", _DB_OBJ_FULL, $this->documentInformation['version_notes'], $this->documentInformation['doc_id']);


        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $standard_id = _STD_ID;
        $is_gap_document = 0;
        $default_status = 'U';

        $optObj = new Option();
        $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

        if ($version_type == 'version') {
            $version_type = 'V';
        } else {
            $version_type = 'R';
        }

        $optObj = null;

        $sql = sprintf("UPDATE %s.cms_documents
				SET documentID = %d,
					versionOld = '%s',
					versionNew = '%s',
					pages = %d,
					buID = %d,
					classification = '%s',
					docControl = '%s',
					versionMinor = '%s'
				WHERE cmsdocID = '%s'"
                , _DB_OBJ_FULL
                , $this->documentId
                , $this->documentInformation['version_old']
                , $this->documentInformation['version_new']
                , $this->documentInformation['pages']
                , $this->documentInformation['business_unit']
                , $this->documentInformation['document_class']
                , $version_type
                , $this->documentInformation['version_minor']
                , $this->documentInformation['doc_id']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $stmt_sec->execute();

        $this->addDocReplicateInfo($this->documentInformation['doc_id']); // add new uploaded file details
    }

    private function deleteDocumentAlldata($p_document_id) {

        $tables = array('cms_documents', 'cms_documents_metadata', 'cms_document_alerts');

        foreach ($tables as $table) {

            $del = sprintf("DELETE FROM %s." . $table . "
					WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

            $stmt = $this->dbHand->prepare($del);

            $stmt->execute();
        }




        // Document has  by Claire Boulley.
    }

    public function deleteDocumentFrontEnd($p_document_id) {

        $tables = array('cms_documents', 'cms_document_alerts');

        foreach ($tables as $table) {

            $del = sprintf("DELETE FROM %s." . $table . "
					WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

            $stmt = $this->dbHand->prepare($del);

            $stmt->execute();
        }


        // Document has  by Claire Boulley.
    }

    public function updateArchive($p_document_id, $reason) {





        $sql = sprintf("UPDATE %s.cms_documents
				SET isArchive = 1
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $p_approved_by = getLoggedInUserId();
        $participantObj = SetupGeneric::useModule('Participant');
        $participantObj->setItemInfo(array('id' => $p_approved_by));
        $partcipantData = $participantObj->displayItemById();

        $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $message = "Document has been archived by " . $contributor_name;
        $this->saveDocumentLog($p_document_id, $message, $reason);
        $participantObj = null;



        // Document has  by Claire Boulley.
    }

    public function veiwRejectDocument($p_document_id) {

        $tables = array('cms_documents', 'cms_documents_metadata', 'cms_document_alerts');

        foreach ($tables as $table) {

            $del = sprintf("SELECT * FROM %s." . $table . "
					WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

            $stmt = $this->dbHand->prepare($del);

            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        }


        // Document has  by Claire Boulley.
    }

    private function uploadDocumentFile() {

        $objFile = new Upload();

        $this->documentInformation['file_info']['destination'] = 'documents';


        $objFile->setFileInfo($this->documentInformation['file_info']['destination'], $this->documentInformation['file_info']);

        try {
            $objFile->add_file();
            $this->documentId = $objFile->getLastFileId();


            $objFile = null;
        } catch (ErrorException $e) {
            $objFile = null;
            echo $e->getMessage();
            throw new ErrorException($e->getMessage(), 11);
        }
    }

    private function removeDocumentFile($p_file_id) {

        $p_file_id = (int) $p_file_id;

        $objFile = new Upload();

        $objFile->setFileInfo('documents', array('id' => $p_file_id, 'destination' => 'documents'));
        $objFile->delete_file();

        $objFile = null;
    }

    /**
     * This method is used to delete the document.
     */
    public function deleteDocument($p_doc_id, $p_reject = false) {

        $p_doc_id = (int) $p_doc_id;

        $document_information = $this->getDocumentInformation($p_doc_id);
        $this->removeDocumentFile($document_information['documentID']);
        $this->deleteDocumentAlldata($p_doc_id);

        if ($p_reject) {
            $message = "Document has been rejected by " . $this->logged_user_name;
        } else {
            $message = "Document has been deleted by " . $this->logged_user_name;
        }
        $reason = '------';
        $this->saveDocumentLog($p_doc_id, $message, $reason);
    }

    public function authorizeDocument($p_document_id, $p_date_approved, $p_approved_by) {

        $sql = sprintf("UPDATE %s.cms_documents
				SET status = 'A' 
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

        $sql_sec = sprintf("UPDATE %s.cms_documents_metadata
				SET dateApproved = '%s',
				approvedBy = %d
				WHERE cmsdocID = %d"
                , _DB_OBJ_FULL
                , format_date_for_mysql($p_date_approved)
                , $p_approved_by
                , $p_document_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_sec->execute();

        $document_information = $this->getDocumentInformation($p_document_id);

        $iData = new inductData();
        $iData->updatePublishedList($p_document_id, $document_information["affected_Bus"], $document_information["classification"]);


        $del = sprintf("SELECT * FROM %s.cms_documents
					WHERE cmsdocID != %d
				AND fileReference LIKE '%s'
				AND documentID = %d"
                , _DB_OBJ_FULL
                , $p_document_id
                , $document_information['fileReference']
                , $document_information['parent_id']);

        $stmt = $this->dbHand->prepare($del);

        $stmt->execute();

        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        $sql_sec1 = sprintf("UPDATE %s.cms_documents SET isArchive = 0 WHERE fileReference LIKE '%s' AND cmsdocID = %d ", _DB_OBJ_FULL, $document_information['fileReference'], $document_information['parent_id']);

        $sql = sprintf("UPDATE %s.cms_documents
				SET isArchive = 1
				WHERE cmsdocID != %d
				AND fileReference LIKE '%s'
				AND documentID = %d"
                , _DB_OBJ_FULL
                , $p_document_id
                , $document_information['fileReference']
                , $document_information['parent_id']);


        $dataArr = explode("|", $document_information["alertType"]);

        $document_informationOld = $this->getDocumentInformation($dataArr[1]);


        $sql = sprintf("UPDATE %s.cms_documents
				SET isArchive = 1
				WHERE cmsdocID = %d"
                , _DB_OBJ_FULL
                , $dataArr[1]);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $participantObj = SetupGeneric::useModule('Participant');
        $participantObj->setItemInfo(array('id' => $p_approved_by));
        $partcipantData = $participantObj->displayItemById();
        $this->documentRecordHistory($p_document_id, 'Authorised');
        $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];


        $reason = '-----';
        $message = "Document Replaces " . $document_informationOld['title'];
        $this->saveDocumentLog($p_document_id, $message, $reason);
        $message = "Document has been authorized by " . $contributor_name;
        $this->saveDocumentLog($p_document_id, $message, $reason);




        $reason = '-------';
        $message = "Document has  Replaced  '" . $data['title'] . " Version:" . $data['versionNew'] . "'  by " . $contributor_name;

        $this->saveDocumentLog($p_document_id, $message, $reason);
        $participantObj = null;
    }

    public function authorizeDocumentold($p_document_id, $p_date_approved, $p_approved_by) {

        $sql = sprintf("UPDATE %s.cms_documents
				SET status = 'A' 
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

        $sql_sec = sprintf("UPDATE %s.cms_documents_metadata
				SET dateApproved = '%s',
				approvedBy = %d
				WHERE cmsdocID = %d"
                , _DB_OBJ_FULL
                , format_date_for_mysql($p_date_approved)
                , $p_approved_by
                , $p_document_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_sec->execute();

        $document_information = $this->getDocumentInformation($p_document_id);



        $sql = sprintf("UPDATE %s.cms_documents
				SET isArchive = 1
				WHERE cmsdocID != %d
				AND fileReference LIKE '%s'
				AND recordSep = %d"
                , _DB_OBJ_FULL
                , $p_document_id
                , $document_information['fileReference']
                , $document_information['recordSep']);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $participantObj = SetupGeneric::useModule('Participant');
        $participantObj->setItemInfo(array('id' => $p_approved_by));
        $partcipantData = $participantObj->displayItemById();

        $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
        $reason = '-----';
        $message = "Document has been authorised by " . $contributor_name;
        $this->saveDocumentLog($p_document_id, $message, $reason);
        $participantObj = null;
    }

    public function authorizeDocument1($p_document_id, $p_date_approved, $p_approved_by) {
        $emailObj = new infoEmailHelper();
        $miscObj = new Misc();
        $sql = sprintf("UPDATE %s.cms_documents
				SET status = 'A' 
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

        $sql_sec = sprintf("UPDATE %s.cms_documents_metadata
				SET dateApproved = '%s',
				approvedBy = %d
				WHERE cmsdocID = %d"
                , _DB_OBJ_FULL
                , format_date_for_mysql($p_date_approved)
                , $p_approved_by
                , $p_document_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_sec->execute();

        $document_information = $this->getDocumentInformation($p_document_id);

        $sql_sec1 = sprintf("UPDATE %s.cms_documents SET isArchive = 0 WHERE fileReference LIKE '%s' AND cmsdocID = %d ", _DB_OBJ_FULL, $document_information['fileReference'], $document_information['parent_id']);


        $stmt_sec1 = $this->dbHand->prepare($sql_sec1);


        $stmt_sec1->execute();

        $participantObj = SetupGeneric::useModule('Participant');
        $participantObj->setItemInfo(array('id' => $p_approved_by));
        $partcipantData = $participantObj->displayItemById();

        $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
        $reason = '-----';
        $message = "Document has been uploaded by " . $contributor_name;
        $this->saveDocumentLog($p_document_id, $message, $reason);
        $document_info = $this->getDocData($p_document_id);

        $document_types = $miscObj->getDocumentTypes();
        $document_info['type'] = $document_types[$document_info['documentType']];

        $participantObj->setItemInfo(array('id' => $document_info['initiatedByParticipant']));
        $partcipantData = $participantObj->displayItemById();

        $created_by = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $participantObj->setItemInfo(array('id' => $document_info['approvedBy']));
        $partcipantData = $participantObj->displayItemById();

        $approved_by = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
        if (!$this->documentInformation["pi"] == 1) {
            $reason = '-----';
            $message = "Document has been authorized by " . $contributor_name;
            $this->saveDocumentLog($p_document_id, $message, $reason);
        }


        $iData = new inductData();
        $iData->updatePublishedList($p_document_id, $document_info["affected_Bus"], $document_info["classification"]);


        if ($document_info["fileReference"] == '1.2' || $document_info["documentSubType"] == 'G' || $document_info["documentSubType"] == "Y") {


            $who = array(
                'displayname' => "John Moffat",
                'email' => 'jrm@smart-iso.com'
            );

            $subject = "smart-ISO Policy Email";

            $mergeData = array(
                'twoColData' => array(
                    'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $document_info['fileReference']),
                    'assignedto' => array('left' => '<strong>Document Name:</strong>', 'right' => $document_info['title']),
                    'authorizing1' => array('left' => '<strong>Document Description:</strong>', 'right' => $document_info['description'])
                ),
                'singleColData' => array(
                    'summary' => '<p><BR>The attached Policy Document has been published.<BR><BR></p>')
            );

            $emailObj->appendInfo($mergeData);
            $objFile = new Upload();
            $objFile->setFileInfo('documents', array('id' => $document_info['documentID']));
            $file_detail = $objFile->getFileDetails();
            $file = _PATH_PUB . 'documents/' . $file_detail['sysFilename'];
            //$emailObj->addAttachment($file);
            $attachment = array('name' => $file_detail['usrFilename'], 'file' => $file);

            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey', $attachment);
        }

        $participantObj->setItemInfo(array('id' => $document_info['docIssuer']));
        $partcipantData = $participantObj->displayItemById();
        $name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $who = array(
            'displayname' => ucwords($name),
            'email' => $partcipantData['emailAddress']
        );

        $subject = "smart-ISO Published Document.";


        $mergeData = array(
            'twoColData' => array(
                'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $document_info['fileReference']),
                'assignedto' => array('left' => '<strong>Document Name:</strong>', 'right' => $document_info['title']),
                'authorizing1' => array('left' => '<strong>Document Description:</strong>', 'right' => $document_info['description']),
                'due' => array('left' => '<strong>Document Type:</strong>', 'right' => $document_info['type']),
                'initBy' => array('left' => '<strong>Initiated By:</strong>', 'right' => $created_by),
                'version' => array('left' => '<strong>Version:</strong>', 'right' => $document_info['versionNew']),
                'dateIssued' => array('left' => '<strong>Date Published/Approved:</strong>', 'right' => format_date($document_info['dateInitiated'])),
                'issued' => array('left' => '<strong>Published/Approved By:</strong>', 'right' => $approved_by),
                'page' => array('left' => '<strong>Pages:</strong>', 'right' => $document_info['pages'])
            ),
            'singleColData' => array(
                'url' => '<p>Please <a href= "https://' . $_SERVER['HTTP_HOST'] . '/download.php?id=' . $document_info['documentID'] . ' ">CLICK</a> Here to view this document</p>')
        );

        $emailObj->appendInfo($mergeData);



        $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');

        $document_contributors = $this->getDocumentContributors($document_info['cmsdocID']);
        $subject = "smart-ISO Document has been Published.";

        if ($document_contributors) {
            foreach ($document_contributors as $doc_cont) {
                if ($doc_cont['passed'] == 1 || $doc_cont['passed'] == 1) {
                    $participantObj->setItemInfo(array('id' => $doc_cont['authParticipantID']));
                    $partcipantData = $participantObj->displayItemById();
                    $name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                    $who = array(
                        'displayname' => ucwords($name),
                        'email' => $partcipantData['emailAddress']
                    );
                    $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'purple');
                }
            }
        }




        if ($document_info["documentSubType"] == 'G') {
            $this->sendPolicyChangeReminder($document_info["cmsdocID"]);
        }

        $participantObj = null;
    }

    public function getDropContributors($p_document_id) {

        $sql = sprintf("SELECT * from %s.cms_documents_contributors
				 
				WHERE passed=0 and cmsdocID = %d", _DB_OBJ_FULL, $p_document_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function updateDropContributors($p_document_id, $reply) {

        $sql = sprintf("UPDATE %s.cms_documents_contributors
				 set passed=3,
                                 reply='%s'
				WHERE passed=0 and cmsdocID = %d", _DB_OBJ_FULL, $reply, $p_document_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    /**
     * This method is used to view already uploaded document.
     */
    public function viewDocument($p_doc_id) {
        
    }

    /**
     * This method is used to list all the alerts related with the document
     */
    public function listDocumentAlerts() {
        
    }

    /**
     * This method is used to view the document alert details.
     */
    public function viewDocumentAlertDetails() {
        
    }

    /**
     * This method is used to store the agreement of alert raised by others
     */
    public function agreeDocumentAlert() {

        $sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				alertStatus = 'I',
				reply = '%s'
				WHERE alertID = %d", _DB_OBJ_FULL, $this->documentInformation['docissuer_comment'], $this->documentInformation['alert_id']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    public function agreeDocumentAlertbyID($p_id) {

        $sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				alertStatus = 'A' 
				WHERE alertID = %d", _DB_OBJ_FULL, $p_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    public function doneDocumentAlert() {

        $sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				alertStatus = 'A',
				doneStatus = 'L',
				reply = '%s'
				WHERE alertID = %d", _DB_OBJ_FULL, $this->documentInformation['docissuer_comment'], $this->documentInformation['alert_id']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    public function preDocumentAlert() {

        $sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				reply = '%s'
				WHERE alertID = %d", _DB_OBJ_FULL, $this->documentInformation['docissuer_comment'], $this->documentInformation['alert_id']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    /**
     * This method is used to store the disagreement of alert raised by others
     */
    public function disagreeDocumentAlert() {

        $sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				alertStatus = 'D',
				reply = '%s'
				WHERE alertID = %d", _DB_OBJ_FULL, $this->documentInformation['docissuer_comment'], $this->documentInformation['alert_id']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    /**
     * This method is used to view document history
     */
    public function viewDocumentHistory() {
        
    }

    /**
     * This method is used to raise new alert for document.
     */
    public function raiseDocumentAlert() {

        //if ($this->documentInformation['file_info']['size'] > 0) {
        //    $this->uploadDocumentFile();
        //} else {
        //    $this->documentId = 0;
        //}

        $this->documentInformation['alert_raised_by'] = getLoggedInUserId();
        $alert_status = 'N';
        $reply = '';

        $sql = sprintf("INSERT INTO %s.cms_document_alerts(cmsdocID,alertRaisedBy,alertComment,documentID,alertWhen,alertStatus,reply)
				VALUES(%d, %d,'%s',%d," . customCurrentDate() . ",'%s','%s')"
                , _DB_OBJ_FULL
                , $this->documentInformation['doc_id']
                , $this->documentInformation['alert_raised_by']
                , $this->documentInformation['document_comment']
                , $this->documentInformation['file_id']
                , $alert_status
                , $reply);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $docId = customLastInsertId($this->dbHand, 'cms_document_alerts', 'alertID');
        return $docId;
    }

    /**
     * This method is used to get document information
     */
    public function getDocumentInformation($p_doc_id) {

        $p_doc_id = (int) $p_doc_id;

        $sql = sprintf("SELECT * FROM %s.cms_documents
				WHERE cmsdocID = %d
				ORDER BY cmsdocID", _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getDocumentInformationCon($p_doc_id) {

        $p_doc_id = (int) $p_doc_id;

        $sql = sprintf("SELECT * FROM %s.cms_documents
				WHERE documentID = %d
				", _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getDocumentInformationMetaData($p_doc_id) {

        $p_doc_id = (int) $p_doc_id;

        $sql = sprintf("SELECT * FROM %s.cms_documents_metadata
				WHERE cmsdocID = %d
				ORDER BY cmsdocID", _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     *
     *
     */
    public function getDocumentContributors($p_doc_id) {
        return $this->getDocumentAdditionalInfo($p_doc_id, 'cms_documents_contributors', 'contributorID');
    }

    public function getDocumentCountAlert($p_doc_id) {
        return $this->getDocumentCount($p_doc_id, 'cms_documents', 'alertID');
    }

    public function getDocumentCountAlert1($p_doc_id) {
        return $this->getDocumentCount1($p_doc_id, 'cms_document_alerts', 'alertID');
    }

    public function getDocumentCountAlertAgree($p_doc_id) {
        return $this->getDocumentCountAgree($p_doc_id, 'cms_document_alerts', 'alertID');
    }

    public function getDocumentCountDone($p_doc_id) {
        return $this->getDocumentCountDoneAlert($p_doc_id, 'cms_document_alerts', 'alertID');
    }

    /**
     *
     */
    public function getDocumentAlerts($p_doc_id) {
        $sql = sprintf("SELECT A.*,P.forename+' '+P.surname as name,F.usrFilename FROM %s.cms_document_alerts A
	 	     	LEFT JOIN %s.participant_database P on A.alertraisedby=P.participantID 
	 	     	LEFT JOIN %s.uploaded_files F on A.documentID=F.fileID
				WHERE cmsdocID = %d 
				ORDER BY alertID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();



        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     *
     */
    public function getDocumentHistoryLog($p_doc_id) {
        return $this->getDocumentAdditionalInfo($p_doc_id, 'cms_document_log', 'logID');
    }

    public function getDocumentHistoryLogTotal($p_doc_id) {
        $sql = sprintf("SELECT L.*,D.* FROM %s.cms_document_log L left join %s.cms_documents D on L.cmsdocID=D.cmsdocID
				WHERE L.cmsdocID = %d
				ORDER BY logID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($data) > 0) {
            $id = $data[0]["parent_id"];
            while ($id > 0) {
                $sql = sprintf("SELECT L.*,D.* FROM %s.cms_document_log L left join %s.cms_documents D on L.cmsdocID=D.cmsdocID
				WHERE D.documentID = %d
				ORDER BY logID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

                $stmt = $this->dbHand->prepare($sql);

                $stmt->execute();

                $data1 = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $data = array_merge($data, $data1);
                $id = $data1[0]["parent_id"];
            }
        }
        return $data;
    }

    public function getDocumentHistoryLogTotalxx($p_doc_id) {
        $sql = sprintf("SELECT L.*,D.parent_id,D.classification FROM %s.cms_document_log L left join %s.cms_documents D on L.cmsdocID=D.cmsdocID
				WHERE L.cmsdocID = %d
				ORDER BY logID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($data) > 0) {
            $id = $data[0]["parent_id"];
            while ($id > 0) {
                $sql = sprintf("SELECT L.*,D.parent_id,D.classification FROM %s.cms_document_log L left join %s.cms_documents D on L.cmsdocID=D.cmsdocID
				WHERE D.documentID = %d
				ORDER BY logID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

                $stmt = $this->dbHand->prepare($sql);

                $stmt->execute();

                $data1 = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $data = array_merge($data, $data1);
                $id = $data1[0]["parent_id"];
            }
        }
        return $data;
    }

    private function getDocumentAdditionalInfo($p_doc_id, $p_module, $p_orderby) {

        $p_doc_id = (int) $p_doc_id;
        if ($p_module == 'cms_document_alerts') {

            $sql = sprintf("SELECT * FROM %s." . $p_module . "
				WHERE cmsdocID = %d 
				ORDER BY " . $p_orderby . " ASC", _DB_OBJ_FULL, $p_doc_id);
        } else {

            $sql = sprintf("SELECT * FROM %s." . $p_module . "
				WHERE cmsdocID = %d
				ORDER BY " . $p_orderby . " ASC", _DB_OBJ_FULL, $p_doc_id);
        }


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     *
     */
    public function getDocumentCount($p_doc_id, $p_module, $p_orderby) {



        $sql = sprintf("SELECT * FROM %s.cms_documents
				WHERE cmsdocID = 
				" . $p_doc_id, _DB_OBJ_FULL);



        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        return $res['cmsdocID'];
    }

    public function getDocumentCount1($p_doc_id, $p_module, $p_orderby) {
        $sql33 = sprintf("SELECT * FROM %s.cms_documents
				WHERE cmsdocID = %d AND isArchive = 0
				", _DB_OBJ_FULL, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql33);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($result) {

            $sql = sprintf("SELECT * FROM %s." . $p_module . "
				WHERE cmsdocID = %d AND alertStatus = 'N' 
				ORDER BY " . $p_orderby . " ASC", _DB_OBJ_FULL, $p_doc_id);



            $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function getDocumentCountAgree($p_doc_id, $p_module, $p_orderby) {



        $sql = sprintf("SELECT * FROM %s." . $p_module . "
				WHERE cmsdocID = %d AND alertStatus = 'N' 
				ORDER BY " . $p_orderby . " ASC", _DB_OBJ_FULL, $p_doc_id);



        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDocumentCountDoneAlert($p_doc_id, $p_module, $p_orderby) {



        $sql = sprintf("SELECT * FROM %s." . $p_module . "
				WHERE cmsdocID = %d AND alertStatus = 'N'  AND doneStatus ='L'
				ORDER BY " . $p_orderby . " ASC", _DB_OBJ_FULL, $p_doc_id);



        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    //cms_document_log

    /**
     * This method is used to draw document tree
     */
    public function drawDocumentTree() {
        
    }

    /**
     * This method is used to generate document tree xml from database
     */
    public function generateDocumentTreeXml() {

        $standards = $this->getDocumentStandards();
        $xmlstr = "<cmsdocuments></cmsdocuments>";

        $this->xmlobj = new SimpleXMLElement($xmlstr);

        $standards_node = $this->xmlobj->addChild('standards');

        foreach ($standards as $standard_ele) {


            $std_node = $standards_node->addChild('standard');
            $std_node->addAttribute('standard_id', $standard_ele['sID']);

            $root_sections_data = $this->getRootDocumentsByStdCode($standard_ele['sID'], 0);

            foreach ($root_sections_data as $root_sections_ele) {

                $section_node = $std_node->addChild('section');
                $section_node->addAttribute('code', $root_sections_ele['code']);
                $label_name = str_replace('&', ' and ', $root_sections_ele['name']);
                $section_node->addChild('label', $label_name);

                $this->getChildSections($section_node, $standard_ele['sID'], $root_sections_ele['ID']);
            }
        }

        $this->xmlobj->asXML(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);
    }

    private function getChildSections($p_context_node, $p_standard_id, $p_id) {

        $node_sections_data = $this->getRootDocumentsByStdCode($p_standard_id, $p_id);

        $node_sections_data_count = count($node_sections_data);

        if ($node_sections_data_count) {

            $inner_section_node = $p_context_node->addChild('sections');

            foreach ($node_sections_data as $node_sections_ele) {

                $section_block = $inner_section_node->addChild('section');
                $section_block->addAttribute('code', $node_sections_ele['code']);
                $label_name = str_replace('&', ' and ', $node_sections_ele['name']);
                $section_block->addChild('label', $label_name);

                $this->getChildSections($section_block, $p_standard_id, $node_sections_ele['ID']);
            }
        }
    }

    /**
     * This method is used to generate document nodes data from database
     */
    public function generateDocumentDataXml() {

        $standards = $this->getDocumentStandards();
        $xmlstr = "<cmsdocuments></cmsdocuments>";

        $this->xmlobj = new SimpleXMLElement($xmlstr);

        $standards_node = $this->xmlobj->addChild('standards');

        $docclassObj = SetupGeneric::useModule('DocClassification');
        $optObj = new Option();
        $miscObj = new Misc();

        $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
        $document_types = $miscObj->getDocumentTypes();
        $document_classification = $docclassObj->displayItems();

        foreach ($standards as $standard_ele) {


            $std_node = $standards_node->addChild('standard');
            $std_node->addAttribute('standard_id', $standard_ele['sID']);

            $root_sections_data = $this->getRootDocumentsByStdCode($standard_ele['sID'], 0);

            foreach ($root_sections_data as $root_sections_ele) {

                $uploaded_document_list = $this->getDocumentsByStandardAndCode($standard_ele['sID'], $root_sections_ele['code']);

                $section_node = $std_node->addChild('section');
                $section_node->addAttribute('code', $root_sections_ele['code']);
                $label_name = str_replace('&', ' and ', $root_sections_ele['name']);

                $documents_section = $section_node->addChild('documents');

                if (count($uploaded_document_list)) {

                    foreach ($uploaded_document_list as $uploaded_document_element) {

                        $document_node = $documents_section->addChild('document');

                        $cmsdocID = $uploaded_document_element['cmsdocID'];

                        $document_node->addAttribute('id', $cmsdocID);
                        $document_node->addAttribute('path', $uploaded_document_element['documentID']);
                        $document_node->addAttribute('name', addslashes($uploaded_document_element['title']));

                        $document_info = $document_node->addChild('information');

                        $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
                        $document_types = $miscObj->getDocumentTypes();
                        $document_classification = $docclassObj->displayItems();

                        $doc_class = $this->getUserClass();

                        $document_info->addChild('file_reference', $uploaded_document_element['fileReference']);
                        $document_info->addChild('title', addslashes(ucfirst($uploaded_document_element['title'])));
                        $document_info->addChild('description', addslashes(ucfirst($uploaded_document_element['description'])));
                        $document_info->addChild('type', $document_types[$uploaded_document_element['documentType']]);
                        $document_info->addChild('type_code', ucfirst(substr($document_types[$uploaded_document_element['documentType']], 0, 2)));

                        switch ($uploaded_document_element['documentSubType']) {
                            case 'P': $subtype = 'Procedure';
                                break;
                            case 'R': $subtype = 'Process';
                                break;
                            case 'Y': $subtype = 'Policy';
                                break;
                            case 'W': $subtype = 'Work Instructions';
                                break;
                        }

                        $document_info->addChild('subtype', $subtype);

                        $participant_id = $uploaded_document_element['initiatedByParticipant'];
                        $this->participantObj->setItemInfo(array('id' => $participant_id));
                        $partcipantData = $this->participantObj->displayItemById();

                        $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                        $initiated_by = $participant_name == ' ' ? '-' : $participant_name;

                        $document_info->addChild('initiated', format_date($uploaded_document_element['dateInitiated']));
                        $document_info->addChild('initiated_by', $initiated_by);

                        $document_info->addChild('version_old', $uploaded_document_element['versionOld']);
                        $document_info->addChild('version_revision', $uploaded_document_element['docControl']);
                        $document_info->addChild('version_new', $uploaded_document_element['versionNew']);
                        $document_info->addChild('version_extended', $uploaded_document_element['versionMinor']);
                        $document_info->addChild('classification', $uploaded_document_element['classification']);
                        $document_info->addChild('class', $doc_class);
                        $document_info->addChild('action_summary', addslashes(ucfirst($uploaded_document_element['actionSummary'])));
                        $document_info->addChild('pages', $uploaded_document_element['pages']);
                        $document_info->addChild('id_p', $uploaded_document_element['initiatedByParticipant']);

                        $document_info->addChild('businessID', $uploaded_document_element['buID']);
                        $document_info->addChild('standardID', $uploaded_document_element['standardID']);
                        $document_info->addChild('is_gap_document', $uploaded_document_element['isGapDocument']);
                        $document_info->addChild('status', $uploaded_document_element['status']);
                        //$type ='alert';
                        //$document_info->addChild('ale',$type);
                        $document_info->addChild('doc_control', $uploaded_document_element['docControl']);

                        $document_info->addChild('allocated_to', $uploaded_document_element['allocatedTo']);
                        $document_info->addChild('gap_document_id', $uploaded_document_element['gapDocID']);
                        $document_info->addChild('authorizer_comment', ucfirst($uploaded_document_element['authorizerComment']));
                        $document_info->addChild('uploaded_by', $uploaded_document_element['uploadedBy']);
                        $document_info->addChild('date_approved', format_date($uploaded_document_element['dateApproved']));
                        $document_info->addChild('is_archive', $uploaded_document_element['isArchive']);
                        $document_info->addChild('record_sep', $uploaded_document_element['recordSep']);

                        $apprv_participant_id = $uploaded_document_element['approvedBy'];
                        $this->participantObj->setItemInfo(array('id' => $apprv_participant_id));
                        $partcipantData = $this->participantObj->displayItemById();

                        $apprv_participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                        $apprv_initiated_by = $apprv_participant_name == ' ' ? '-' : $apprv_participant_name;

                        $document_info->addChild('approved_by', $apprv_initiated_by);

                        $alert_block = $document_info->addChild('alerts');

                        $new_alerts_count = 0;

                        $document_alerts_list = $this->getDocumentAlerts($cmsdocID);
                        $document_historylog_list = $this->getDocumentHistoryLog($cmsdocID);
                        $document_contributors_list = $this->getDocumentContributors($cmsdocID);
                        $document_count_alert = $this->getDocumentCountAlert($cmsdocID);

                        if (count($document_alerts_list)) {
                            foreach ($document_alerts_list as $document_alert_element) {

                                $alert_node = $alert_block->addChild('alert');

                                $alert_participant_id = $document_alert_element['alertRaisedBy'];
                                $this->participantObj->setItemInfo(array('id' => $alert_participant_id));
                                $partcipantData = $this->participantObj->displayItemById();

                                $alert_initiated_by = '';
                                $alert_participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                                $alert_initiated_by = $alert_participant_name == ' ' ? '-' : $alert_participant_name;
                                /*                                 * ****************** */

                                switch ($document_alert_element['alertStatus']) {
                                    case 'A' : $status = 'Agree';
                                        break;
                                    case 'D' : $status = 'Reject';
                                        break;
                                    case 'N' : $status = 'New';
                                        break;
                                }



                                $this->fileObj->setFileInfo('contributors', array('id' => $document_alert_element['documentID']));
                                $file_detail = $this->fileObj->getFileDetails();
                                $file_name = $file_detail['usrFilename'] == '' ? '-' : $file_detail['usrFilename'];

                                if ($document_alert_element['alertStatus'] != '') {

                                    $alert_node->addChild('id', $document_alert_element['alertID']);
                                    $alert_node->addChild('raised_by', $alert_initiated_by);
                                    $alert_node->addChild('comment', $document_alert_element['alertComment']);
                                    $alert_node->addChild('document_id', $file_name);
                                    $alert_node->addChild('when_raise', format_date($document_alert_element['alertWhen']));
                                    $alert_node->addChild('status', $status);
                                    $alert_node->addChild('cmsID', $document_alert_element['cmsdocID']);
                                    $alert_node->addChild('docID', $document_alert_element['cmsdocID']);
                                    $alert_node->addChild('done', $document_alert_element['doneStatus']);
                                }


                                if ($document_alert_element['reply'] != '') {
                                    $alert_node->addChild('reply', $document_alert_element['reply']);
                                } else {
                                    $alert_node->addChild('reply', '-');
                                }

                                if (!$new_alerts_count && $document_alert_element['alertStatus'] == 'N') {
                                    $new_alerts_count = 1;
                                }
                            }
                        }

                        if ($new_alerts_count) {
                            $alert_block->addAttribute('new', 1);
                        } else {
                            $alert_block->addAttribute('new', 0);
                        }

                        if ($document_alert_element['cmsdocID']) {
                            $alert_block->addAttribute('tot', $document_alert_element['cmsdocID']);
                        } else {
                            $alert_block->addAttribute('tot', 0);
                        }

                        $history_block = $document_info->addChild('history');

                        if (count($document_historylog_list)) {
                            foreach ($document_historylog_list as $document_historylog_element) {
                                $date = substr($document_historylog_element['whenDate'], 0, 19);
                                $history_node = $history_block->addChild('log');

                                $history_node->addChild('logID', $document_historylog_element['logID']);
                                $history_node->addChild('message', $document_historylog_element['message']);
                                $history_node->addChild('when_logged', $date);
                                $history_node->addChild('reason', $document_historylog_element['reason']);
                            }
                        }

                        $contributor_block = $document_info->addChild('contributors');
                        $contributor_count = 0;
                        $contributor_replied = 0;
                        $contributor_replied_na = 0; // not approved
                        $contributor_replied_a = 0; // approved
                        $contributor_count = count($document_contributors_list);

                        if ($contributor_count) {
                            foreach ($document_contributors_list as $document_contributor_element) {

                                $contributor_node = $contributor_block->addChild('contributor');

                                $passed_literal = '';

                                switch ($document_contributor_element['passed']) {
                                    case 0: $passed_literal = 'pending';
                                        break;
                                    case 1: $passed_literal = 'approved';
                                        $contributor_replied_a++;
                                        $contributor_replied++;
                                        break;
                                    case 2: $passed_literal = 'not approved';
                                        $contributor_replied_na++;
                                        $contributor_replied++;
                                        break;
                                }

                                $id1 = $document_contributor_element['authParticipantID'];
                                $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".participant_database
										WHERE participantID = " . $id1;

                                $stmt = $this->dbHand->prepare($sql);

                                $stmt->execute();
                                $res = $stmt->fetch(PDO::FETCH_ASSOC);
                                $name = $res['forename'] . " " . $res['surname'];
                                $contributor_node->addChild('name', $name);

                                $contributor_node->addChild('contributorID', $document_contributor_element['contributorID']);
                                $contributor_node->addChild('authParticipantID', $name);
                                $contributor_node->addChild('date', $document_contributor_element['date']);
                                $contributor_node->addChild('passed', $passed_literal);
                                $contributor_node->addChild('comments', $document_contributor_element['comments']);
                                $contributor_node->addChild('docIssuerAuth', $document_contributor_element['docIssuerAuth']);
                                $contributor_node->addChild('contributorAssign', $document_contributor_element['contributorAssign']);
                                $contributor_node->addChild('documentID', $document_contributor_element['documentID']);
                                $contributor_node->addChild('contribDueDate', $document_contributor_element['contribDueDate']);
                                $contributor_node->addChild('check', $document_contributor_element['cmsdocID']);
                            }
                        }

                        if ($contributor_count > 0 && $contributor_replied == 0) {

                            $document_status = "Wait for Contributors's response";
                        } else if ($contributor_count > 0 && $contributor_replied < $contributor_count) {

                            $document_status = "Sent to contributors";
                        } else if ($contributor_count > 0 && $contributor_replied == $contributor_replied_a) {

                            $document_status = "Approved by contributors";
                        } else if ($contributor_count > 0 && $contributor_replied == $contributor_replied_na) {

                            $document_status = "Not approved by contributors";
                        } else {
                            $document_status = "";
                        }

                        $document_info->addChild('document_status', $document_status);
                    } // end foreach $uploaded_document_list
                } // end if

                $this->getChildSectionsData($std_node, $standard_ele['sID'], $root_sections_ele['ID']);
            }
        }

        $optObj = null;
        $miscObj = null;
        $docclassObj = null;
        $this->xmlobj->asXML(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);
    }

    public function getUserClass() {

        $id = getLoggedInUserId();

        $sql = "SELECT docClassification FROM " . _DB_OBJ_FULL . ".participant_meta_data
				WHERE participantID = " . $id;

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result)
            return $result['docClassification'];
        else
            return 'U';
    }

    private function getChildSectionsData($p_context_node, $p_standard_id, $p_id) {

        $docclassObj = SetupGeneric::useModule('DocClassification');
        $optObj = new Option();
        $miscObj = new Misc();

        $root_sections_data = $this->getRootDocumentsByStdCode($p_standard_id, $p_id);

        foreach ($root_sections_data as $root_sections_ele) {

            $uploaded_document_list = $this->getDocumentsByStandardAndCode($p_standard_id, $root_sections_ele['code']);

            $section_node = $p_context_node->addChild('section');
            $section_node->addAttribute('code', $root_sections_ele['code']);
            $label_name = str_replace('&', ' and ', $root_sections_ele['name']);

            $documents_section = $section_node->addChild('documents');

            if (count($uploaded_document_list)) {
                foreach ($uploaded_document_list as $uploaded_document_element) {

                    $document_node = $documents_section->addChild('document');

                    $cmsdocID = $uploaded_document_element['cmsdocID'];

                    $document_node->addAttribute('id', $cmsdocID);
                    $document_node->addAttribute('path', $uploaded_document_element['documentID']);
                    $document_node->addAttribute('name', addslashes($uploaded_document_element['title']));

                    $document_info = $document_node->addChild('information');

                    $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
                    $document_types = $miscObj->getDocumentTypes();
                    $document_classification = $docclassObj->displayItems();

                    $doc_class = $this->getUserClass();

                    $document_info->addChild('file_reference', $uploaded_document_element['fileReference']);
                    $document_info->addChild('title', addslashes(ucfirst($uploaded_document_element['title'])));
                    $document_info->addChild('description', addslashes(ucfirst($uploaded_document_element['description'])));
                    $document_info->addChild('type', $document_types[$uploaded_document_element['documentType']]);
                    $document_info->addChild('type_code', ucfirst(substr($document_types[$uploaded_document_element['documentType']], 0, 2)));

                    switch ($uploaded_document_element['documentSubType']) {
                        case 'P': $subtype = 'Procedure';
                            break;
                        case 'R': $subtype = 'Process';
                            break;
                        case 'Y': $subtype = 'Policy';
                            break;
                        case 'W': $subtype = 'Work Instructions';
                            break;
                    }

                    $document_info->addChild('subtype', $subtype);


                    $participant_id = $uploaded_document_element['initiatedByParticipant'];
                    $this->participantObj->setItemInfo(array('id' => $participant_id));
                    $partcipantData = $this->participantObj->displayItemById();

                    $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                    $initiated_by = $participant_name == ' ' ? '-' : $participant_name;

                    $document_info->addChild('initiated', format_date($uploaded_document_element['dateInitiated']));
                    $document_info->addChild('initiated_by', $initiated_by);

                    $document_info->addChild('version_old', $uploaded_document_element['versionOld']);
                    $document_info->addChild('version_revision', $uploaded_document_element['docControl']);
                    $document_info->addChild('version_new', $uploaded_document_element['versionNew']);
                    $document_info->addChild('version_extended', $uploaded_document_element['versionMinor']);
                    $document_info->addChild('classification', $uploaded_document_element['classification']);
                    $document_info->addChild('class', $doc_class);
                    $document_info->addChild('action_summary', addslashes(ucfirst($uploaded_document_element['actionSummary'])));
                    $document_info->addChild('pages', $uploaded_document_element['pages']);
                    $document_info->addChild('id_p', $uploaded_document_element['initiatedByParticipant']);

                    $document_info->addChild('businessID', $uploaded_document_element['buID']);
                    $document_info->addChild('standardID', $uploaded_document_element['standardID']);
                    $document_info->addChild('is_gap_document', $uploaded_document_element['isGapDocument']);
                    $document_info->addChild('status', $uploaded_document_element['status']);

                    $document_info->addChild('doc_control', $uploaded_document_element['docControl']);

                    $document_info->addChild('allocated_to', $uploaded_document_element['allocatedTo']);
                    $document_info->addChild('gap_document_id', $uploaded_document_element['gapDocID']);
                    $document_info->addChild('authorizer_comment', ucfirst($uploaded_document_element['authorizerComment']));
                    $document_info->addChild('uploaded_by', $uploaded_document_element['uploadedBy']);
                    $document_info->addChild('date_approved', format_date($uploaded_document_element['dateApproved']));
                    $document_info->addChild('is_archive', $uploaded_document_element['isArchive']);
                    $document_info->addChild('record_sep', $uploaded_document_element['recordSep']);

                    $apprv_participant_id = $uploaded_document_element['approvedBy'];
                    $this->participantObj->setItemInfo(array('id' => $apprv_participant_id));
                    $partcipantData = $this->participantObj->displayItemById();

                    $apprv_participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                    $apprv_initiated_by = $apprv_participant_name == ' ' ? '-' : $apprv_participant_name;

                    $document_info->addChild('approved_by', $apprv_initiated_by);

                    $alert_block = $document_info->addChild('alerts');

                    $new_alerts_count = 0;

                    $document_alerts_list = $this->getDocumentAlerts($cmsdocID);
                    $document_historylog_list = $this->getDocumentHistoryLog($cmsdocID);
                    $document_contributors_list = $this->getDocumentContributors($cmsdocID);
                    $document_count_alert = $this->getDocumentCountAlert($cmsdocID);

                    if (count($document_alerts_list)) {
                        foreach ($document_alerts_list as $document_alert_element) {

                            $alert_node = $alert_block->addChild('alert');

                            /* alert raised by */
                            $alert_participant_id = $document_alert_element['alertRaisedBy'];
                            $this->participantObj->setItemInfo(array('id' => $alert_participant_id));
                            $partcipantData = $this->participantObj->displayItemById();

                            $alert_initiated_by = '';
                            $alert_participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                            $alert_initiated_by = $alert_participant_name == ' ' ? '-' : $alert_participant_name;

                            switch ($document_alert_element['alertStatus']) {
                                case 'A' : $status = 'Agree';
                                    break;
                                case 'D' : $status = 'Reject';
                                    break;
                                case 'N' : $status = 'New';
                                    break;
                            }

                            $this->fileObj->setFileInfo('contributors', array('id' => $document_alert_element['documentID']));
                            $file_detail = $this->fileObj->getFileDetails();
                            $file_name = $file_detail['usrFilename'] == '' ? '-' : $file_detail['usrFilename'];

                            $alert_node->addChild('id', $document_alert_element['alertID']);
                            $alert_node->addChild('raised_by', $alert_initiated_by);
                            $alert_node->addChild('comment', $document_alert_element['alertComment']);
                            $alert_node->addChild('document_id', $file_name);
                            $alert_node->addChild('when_raise', format_date($document_alert_element['alertWhen']));
                            $alert_node->addChild('status', $status);
                            $alert_node->addChild('cmsID', $document_alert_element['cmsdocID']);
                            $alert_node->addChild('docID', $document_alert_element['cmsdocID']);
                            $alert_node->addChild('done', $document_alert_element['doneStatus']);


                            if ($document_alert_element['reply'] != '') {
                                $alert_node->addChild('reply', $document_alert_element['reply']);
                            } else {
                                $alert_node->addChild('reply', '-');
                            }

                            if (!$new_alerts_count && $document_alert_element['alertStatus'] == 'N') {
                                $new_alerts_count = 1;
                            }
                        }
                    }

                    if ($new_alerts_count) {
                        $alert_block->addAttribute('new', 1);
                    } else {
                        $alert_block->addAttribute('new', 0);
                    }

                    if ($document_alert_element['cmsdocID']) {
                        $alert_block->addAttribute('tot', $document_alert_element['cmsdocID']);
                    } else {
                        $alert_block->addAttribute('tot', 0);
                    }



                    $history_block = $document_info->addChild('history');

                    if (count($document_historylog_list)) {
                        foreach ($document_historylog_list as $document_historylog_element) {

                            $history_node = $history_block->addChild('log');
                            $date = substr($document_historylog_element['whenDate'], 0, 19);
                            $history_node->addChild('logID', $document_historylog_element['logID']);
                            $history_node->addChild('message', $document_historylog_element['message']);
                            $history_node->addChild('when_logged', $date);
                            $history_node->addChild('reason', $document_historylog_element['reason']);
                        }
                    }

                    $contributor_block = $document_info->addChild('contributors');
                    $contributor_count = 0;
                    $contributor_replied = 0;
                    $contributor_replied_na = 0; // not approved
                    $contributor_replied_a = 0; // approved
                    $contributor_count = count($document_contributors_list);

                    if ($contributor_count) {
                        foreach ($document_contributors_list as $document_contributor_element) {

                            $contributor_node = $contributor_block->addChild('contributor');

                            $passed_literal = '';

                            switch ($document_contributor_element['passed']) {
                                case 0: $passed_literal = 'pending';
                                    break;
                                case 1: $passed_literal = 'approved';
                                    $contributor_replied_a++;
                                    $contributor_replied++;
                                    break;
                                case 2: $passed_literal = 'not approved';
                                    $contributor_replied_na++;
                                    $contributor_replied++;
                                    break;
                            }
                            $id1 = $document_contributor_element['authParticipantID'];
                            $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".participant_database
										WHERE participantID = " . $id1;

                            $stmt = $this->dbHand->prepare($sql);

                            $stmt->execute();
                            $res = $stmt->fetch(PDO::FETCH_ASSOC);
                            $name = $res['forename'] . " " . $res['surname'];
                            $contributor_node->addChild('name', $name);
                            $contributor_node->addChild('contributorID', $document_contributor_element['contributorID']);
                            $contributor_node->addChild('authParticipantID', $document_contributor_element['authParticipantID']);
                            $contributor_node->addChild('date', $document_contributor_element['date']);
                            $contributor_node->addChild('passed', $passed_literal);

                            $contributor_node->addChild('comments', $document_contributor_element['comments']);
                            $contributor_node->addChild('docIssuerAuth', $document_contributor_element['docIssuerAuth']);
                            $contributor_node->addChild('contributorAssign', $document_contributor_element['contributorAssign']);
                            $contributor_node->addChild('documentID', $document_contributor_element['documentID']);
                            $contributor_node->addChild('contribDueDate', $document_contributor_element['contribDueDate']);
                        }
                    }

                    if ($contributor_count > 0 && $contributor_replied == 0) {

                        $document_status = "Wait for Contributors's response";
                    } else if ($contributor_count > 0 && $contributor_replied < $contributor_count) {

                        $document_status = "Sent to contributors";
                    } else if ($contributor_count > 0 && $contributor_replied == $contributor_replied_a) {

                        $document_status = "Approved by contributors";
                    } else if ($contributor_count > 0 && $contributor_replied_na > 0) {

                        $document_status = "Not approved by contributors";
                    } else {
                        $document_status = "";
                    }

                    $document_info->addChild('document_status', $document_status);
                } // end foreach $uploaded_document_list
            } // end if

            $this->getChildSectionsData($p_context_node, $p_standard_id, $root_sections_ele['ID']);
        }

        $optObj = null;
        $miscObj = null;
        $docclassObj = null;
    }

// end method

    /**
     *
     *
     */
    public function changeXmlDocumentFilename($p_filename) {
        $this->xmlDocumentName = $p_filename;
    }

    /**
     * This method is used to get document tree data from xml file
     */
    public function getDocumentTree($p_standard_id, $p_context = 'documents') {

        $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);

        $tree_html = "";

        foreach ($xmldata->standards->standard as $standard_xml_data) {

            $att = $standard_xml_data->attributes();

            if ($att['standard_id'] == $p_standard_id) {

                $tree_html = "<div id='sidetree' class='filetree'>";

                //if ( $context == 'documents' ) {
                $tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";
                //}

                $tree_html .= "<ul class='treeview' id='dmstree'>";

                foreach ($standard_xml_data as $section_data) {

                    $section_attr = $section_data->attributes();

                    $escaped_code = str_replace('.', '_', $section_data['code']);
                    $document_name = urlencode($section_data->label);

                    $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";
                    $id = getLoggedInUserId();
                    //$id =552;



                    $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".participant_authorization_stats
				WHERE participantID = " . $id . " AND sectionName = 'perm_doc' AND sectionActive=1 ";

                    $stmt = $this->dbHand->prepare($sql);

                    $stmt->execute();
                    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if ($res) {

                        foreach ($res as $key1 => $value1) {
                            foreach ($res as $key2 => $value2) {

                                if ($res[$key1]['participantID'] == $res[$key2]['participantID'] && $key1 != $key2) {

                                    $res[$key2]['value'] += $res[$key1]['value'];
                                    $key2 = $key1;

                                    unset($res[$key1]);
                                }
                            }
                        }
                    }

                    foreach ($res as $value) {
                        $val = $value['sectionActive'];
                    }

                    $toggle_class = "";
                    $upload_link = "";

                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }

                    if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
                    } else {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
                    }

                    $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><SPAN class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
                    $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";

                    if ($p_context != 'process_flow') {
                        $tree_html .= "<span class='loader_class' id='loader_block_" . $escaped_code . "' style='margin-left:20px'><img src='/images/ajax-loader.gif'></span>";
                        $tree_html .= $upload_link;
                        $tree_html .= $doc_detail_block;
                    } else {
                        $tree_html .= $select_reference_link;
                    }

                    $tree_html .= "</span><ul>";

                    $count = 0;

                    $count = count($section_data->sections->section);
                    //			}

                    if ($count) {
                        $tree_html .= $this->getSectionChildren($section_data->sections->section, $p_standard_id, $p_context);
                    }

                    $tree_html .= "</ul>";
                    $tree_html .= "</li>";
                }

                $tree_html .= "</ul></div>";
            }
        } // end foreach

        return $tree_html;
    }

    /**
     * This method is used to get document meta data from xml file
     */
    public function getDocumentMetadata($p_standard_id) {

        $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);

        $json_data = array();

        foreach ($xmldata->standards->standard as $standard_xml_data) {

            $att = $standard_xml_data->attributes();

            if ($att['standard_id'] == $p_standard_id) {

                foreach ($standard_xml_data as $section_data) {

                    $document_data = $section_data->attributes();
                    $document_data_code = (string) $document_data['code'];

                    $documents_list = $section_data->children()->children();

                    $count = 0;

                    $count = count($documents_list);

                    $document_array = array(0);

                    if ($documents_list) {

                        $document_index = 0;

                        foreach ($documents_list as $documents_list_record) {

                            $specific_document_attr = $documents_list_record->attributes();
                            $document_metadata = $documents_list_record->children()->children();



                            foreach ($specific_document_attr as $attr_ele_key => $attr_ele_val) {
                                $json_data[$document_data_code][$document_index]['attributes'][$attr_ele_key] = (string) $attr_ele_val;
                            }

                            foreach ($document_metadata as $metadata_ele => $metadata_val) {

                                if ($metadata_ele == 'alerts' || $metadata_ele == 'history') {
                                    continue;
                                }

                                $json_data[$document_data_code][$document_index]['information'][$metadata_ele] = (string) $metadata_val;
                            }

                            $document_alert = $document_metadata->alerts;
                            $document_history = $document_metadata->history;
                            $document_contributors = $document_metadata->contributors;

                            $alert_attr = $document_alert->attributes();
                            $new_alerts = 0;
                            $new_alerts = $alert_attr['new'];

                            $alerts_count1 = 0;
                            $document_count_alert = $this->getDocumentCountAlert($alert_attr['tot']);
                            $document_count_alert1 = $this->getDocumentCountAlert1($alert_attr['tot']);

                            $document_count_agree = $this->getDocumentCountAlertAgree($alert_attr['tot']);

                            $document_done = $this->getDocumentCountDone($alert_attr['tot']);

                            $alerts_count = $document_count_alert;
                            $alerts_count1 = count($document_count_alert1);
                            $alerts_agree = count($document_count_agree);
                            $alerts_done = count($document_done);

                            $total = $alerts_agree - $alerts_done;

                            $alerts_array = $document_alert->children();
                            $history_array = $document_history->children();
                            $contributors_array = $document_contributors->children();

                            $json_data[$document_data_code][$document_index]['alerts']['new'] = (int) $new_alerts;
                            $json_data[$document_data_code][$document_index]['alerts']['total'] = $alerts_count;

                            $json_data[$document_data_code][$document_index]['alerts']['total1'] = $alerts_count1;
                            $json_data[$document_data_code][$document_index]['alerts']['total_agree'] = $total;


                            foreach ($alerts_array as $alerts_ele) {


                                $json_data[$document_data_code][$document_index]['alerts_list'][] = (array) $alerts_ele;
                            }

                            foreach ($history_array as $history_ele) {
                                $json_data[$document_data_code][$document_index]['history'][] = (array) $history_ele;
                            }

                            foreach ($contributors_array as $contributor_ele) {
                                $json_data[$document_data_code][$document_index]['contributors'][] = (array) $contributor_ele;
                            }

                            $document_index++;
                        }
                    }
                }
            } // end if
        } // end foreach

        return $json_data;
    }

    private function getSectionChildren($p_section_data, $p_standard_id, $p_context) {

        $tree_html = "";

        foreach ($p_section_data as $section_data_ele) {

            $escaped_code = str_replace('.', '_', $section_data_ele['code']);
            $document_name = urlencode($section_data_ele->label);

            $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

            $id = getLoggedInUserId();

            $sql = "SELECT * FROM " . _DB_OBJ_FULL . ".participant_authorization_stats
				WHERE participantID = " . $id . " AND sectionName = 'perm_doc' AND sectionActive=1 ";

            $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();
            $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($res) {

                foreach ($res as $key1 => $value1) {
                    foreach ($res as $key2 => $value2) {

                        if ($res[$key1]['participantID'] == $res[$key2]['participantID'] && $key1 != $key2) {

                            $res[$key2]['value'] += $res[$key1]['value'];
                            $key2 = $key1;

                            unset($res[$key1]);
                        }
                    }
                }
            }

            foreach ($res as $value) {
                $val = $value['sectionActive'];
            }

            // 11 is id for CMS 9k

            $toggle_class = "";
            $upload_link = "";

            if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                $toggle_class = " class='toggle_upload_link'";
                $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";

                $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
            }

            $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'] . "<span class='expandable'>";
            $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";

            if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
            } else {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
            }

            if ($p_context != 'process_flow') {
                $tree_html .= "<span class='loader_class' id='loader_block_" . $escaped_code . "' style='margin-left:20px'><img src='/images/ajax-loader.gif'></span>";
                $tree_html .= $upload_link;
                $tree_html .= $doc_detail_block;
            } else {
                $tree_html .= $select_reference_link;
            }

            $tree_html .= "</span><ul>";

            $count = 0;

            $count = count($section_data_ele->sections->section);


            if ($count) {
                $tree_html .= $this->getSectionChildren($section_data_ele->sections->section, $p_standard_id, $p_context);
            }

            $tree_html .= "</ul>";
            $tree_html .= "</li>";
        }

        return $tree_html;
    }

    private function getDocumentStandards() {

        $sql = sprintf("SELECT DISTINCT sID FROM %s.msr_departments
				ORDER BY sID ASC", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    private function getRootDocumentsByStdCode($p_standard_id, $p_id) {

        if ($p_id == 0) {
            $sql = sprintf("SELECT ID,code,name,pID,sID FROM %s.msr_departments
				WHERE 
				sID = %d
				AND pID = %d
				ORDER BY code ASC", _DB_OBJ_FULL, $p_standard_id, $p_id);
        } else {
            $sql = sprintf("SELECT ID,code,name,pID,sID FROM %s.msr_departments
				WHERE sID = %d
				AND pID = %d
				ORDER BY code ASC", _DB_OBJ_FULL, $p_standard_id, $p_id);
        }

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $resultCount = count($result);

        $new_result = array();

        if ($resultCount) {
            foreach ($result as $resultEle) {
                $new_result[] = $resultEle;
            }
        }

        return $new_result;
    }

    private function getDocumentsByStandardAndCode($p_standard_id, $p_code) {

        if ($p_standard_id == _STD_ID) {

            $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID
					WHERE fileReference = '%s'
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_code);


            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {

            $new_code = $this->getLinkingCode($p_standard_id, $p_code);

            if ($new_code != '') {

                $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID
					WHERE fileReference = '%s' AND standardID = %d
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $new_code, _STD_ID);

                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();

                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (count($result)) {
                    $result[0]['fileReference'] = $p_code;
                }
            }
        }

        return $result;
    }

    private function getLinkingCode($p_standard_id, $p_code) {

        $sql2 = sprintf("SELECT code FROM %s.review_question_metadata
								WHERE questionID IN (SELECT questionID FROM %s.review_question_metadata WHERE standardID = %d AND code = '%s')
								AND standardID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_standard_id, $p_code, _STD_ID);

        $stmt2 = $this->dbHand->prepare($sql2);
        $stmt2->execute();
        $code = $stmt2->fetchColumn();

        return $code;
    }

    public function getSectionByStandardAndCode($p_standard_id, $p_code) {

        $sql = sprintf("SELECT * FROM %s.msr_departments
				WHERE code = '%s'
				AND sID = %d", _DB_OBJ_FULL, $p_code, $p_standard_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function downloadDocument($p_doc_id, $p_document_title = '') {

        $updObj = new Upload();
        $updObj->setFileInfo('documents', array('id' => $p_doc_id));
        $file_details = $updObj->getFileDetails();

        $file = _PATH_PUB . 'documents/' . $file_details['sysFilename'];
        $file_name_ext = substr($file_details['sysFilename'], -4, 4);

        $download_file_name = $file_details['usrFilename'];

        if (!$file) {

            die('file not found');
        } else {
            // Set headers
            header('Content-type: application/download');
            header('Content-Description: File Transfer');
            header('Content-Disposition: attachment; filename="' . $download_file_name . '" ');
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header('Content-Transfer-Encoding: binary');

            // Read the file from disk
            readfile($file);
        }

        $updObj = null;
    }

    /**
     * This method is used to store the disagreement of alert raised by others
     */
    public function getAlertDetails() {

        $sql = sprintf("SELECT * FROM  %s.cms_document_alerts WHERE alertID = %d", _DB_OBJ_FULL, $this->documentInformation['alert_id']);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getLatestDoc($id) {

        $sql = sprintf("SELECT TOP 1 *, %d AS 'doc_id' FROM %s.cms_documents WHERE parent_id = %d AND status = 'A' ORDER BY cmsdocID DESC", _DB_OBJ_FULL, $id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultSet = $stmt->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getDocRegisterData() {

        $userID = getLoggedInUserID();
        $orgObj = SetupGeneric::useModule('Organigram');
        $orgObj->setItemInfo(array('id' => 0, 'participant_id' => $userID));
        $userData = $orgObj->getBuByParticipant();

        $userlevel = getUserAccessLevel();
        // $bustr=$orgObj->getBUstr($userData[0]["buID"]);
        //$buArr=explode(",",$bustr);

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        $sql = sprintf("SELECT D.*,C.approvedBy,C.dateApproved,C.authorizerComment FROM  %s.cms_documents D
					   INNER JOIN %s.cms_documents_metadata C ON C.cmsdocID = D.cmsdocID
					   WHERE D.status = 'A' AND D.isArchive = 0 and classification in (%s)  ORDER By D.fileReference ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($resultSet as $data) {

            $search = false;
            $buArr = explode(",", $data['affected_Bus']);
            //checking bus
            if (trim($data['affected_Bus']) == '')
                $search = true;
            elseif (in_array($userData[0]["buID"], $buArr))
                $search = true;


            if ($userlevel == 1 || $search == true) {
                $result[] = $data;
            }
        }
        return $result;
    }

    public function getDocHistoryData() {

        $sql = sprintf("SELECT D.*,C.* FROM  %s.cms_documents D
					   INNER JOIN %s.document_record_history C ON C.cmsdocID = D.cmsdocID
					   WHERE D.status = 'A' ORDER By D.fileReference ASC", _DB_OBJ_FULL, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getDocRef($p_code, $p_sid) {

        $sql = sprintf("SELECT name FROM  %s.msr_departments D
					   WHERE D.code = '%s' AND sID='%s' ", _DB_OBJ_FULL, $p_code, $p_sid);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultSet = $stmt->fetchColumn();

        return $resultSet;
    }

    private function updDocReplaceInfo($p_cms_doc_id, $p_doc_id, $p_status, $comment_upd = false) {
        $sql = sprintf("UPDATE %s.cms_document_replace SET is_active = '%s' WHERE cmsdocID = %d  AND documentID = %d ", _DB_OBJ_FULL, $p_status, $p_cms_doc_id, $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        if ($comment_upd) {
            $sql_sec = sprintf("UPDATE %s.cms_document_replace SET comment = '%s' WHERE cmsdocID = %d AND documentID = %d ", _DB_OBJ_FULL, $this->documentInformation['reason_replace'], $p_cms_doc_id, $p_doc_id);

            $stmt_sec = $this->dbHand->prepare($sql_sec);

            $stmt_sec->execute();
        }
    }

    private function addDocReplicateInfo($dms_doc_id) {
        $sql_doc_active = sprintf("INSERT INTO %s.cms_document_replace (cmsdocID,documentID,is_active,uploaded_on) VALUES (%d,%d,'1'," . customCurrentDate() . ")", _DB_OBJ_FULL, $dms_doc_id, $this->documentId);
        $stmt_doc_active = $this->dbHand->prepare($sql_doc_active);
        $stmt_doc_active->execute();
    }

    public function getDocHistory($p_file_ref, $p_sep) {

        $sql_sec = sprintf("SELECT * FROM %s.cms_documents
						   WHERE
						   fileReference LIKE '%s'
						   AND recordSep = %d
						   AND isArchive = 1 ORDER BY cmsdocID ASC", _DB_OBJ_FULL, $p_file_ref, $p_sep);

        $stmt_sec = $this->dbHand->prepare($sql_sec);
        $stmt_sec->execute();

        $result = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getDocArchive($p_file_ref, $p_sep) {

        $sql_sec = sprintf("SELECT * FROM %s.cms_documents
						   WHERE
						   fileReference LIKE '%s'
						
						   AND not status  ='X' and isArchive = 1 ORDER BY cmsdocID ASC", _DB_OBJ_FULL, $p_file_ref);

        $stmt_sec = $this->dbHand->prepare($sql_sec);
        $stmt_sec->execute();

        $result = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getDocArchive1($id) {

        $sql_sec = sprintf("SELECT * FROM %s.cms_document_log
						   WHERE
						  cmsdocID =" . $id, _DB_OBJ_FULL);

        $stmt_sec = $this->dbHand->prepare($sql_sec);
        $stmt_sec->execute();

        $result = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function changeDocument($p_fr, $p_cdid, $p_sep) {

        $sql = sprintf("UPDATE %s.cms_documents SET isArchive = 1 WHERE fileReference LIKE '%s' AND cmsdocID != %d AND recordSep = %d", _DB_OBJ_FULL, $p_fr, $p_cdid, $p_sep);

        $sql_sec = sprintf("UPDATE %s.cms_documents SET isArchive = 0 WHERE fileReference LIKE '%s' AND cmsdocID = %d AND recordSep = %d", _DB_OBJ_FULL, $p_fr, $p_cdid, $p_sep);

        $stmt = $this->dbHand->prepare($sql);
        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_sec->execute();
    }

    public function changeArchive($p_fr, $p_cdid, $p_sep, $status = '') {

        $sql = sprintf("UPDATE %s.cms_documents SET isArchive = 1 WHERE fileReference LIKE '%s' AND cmsdocID = %d ", _DB_OBJ_FULL, $p_fr, $p_cdid);

        if ($status == 'R')
            $statStr = ",status='U'";
        else
            $statStr = "";

        $sql_sec = sprintf("UPDATE %s.cms_documents SET isArchive = 0%s WHERE fileReference LIKE '%s' AND cmsdocID = %d AND recordSep = %d", _DB_OBJ_FULL, $statStr, $p_fr, $p_cdid, $p_sep);

        $stmt = $this->dbHand->prepare($sql);
        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_sec->execute();
    }

    public function deleteArchive($p_fr, $p_cdid, $p_sep, $status = '') {

        $sql_sec = sprintf("UPDATE %s.cms_documents SET status='X' WHERE fileReference LIKE '%s' AND cmsdocID = %d AND recordSep = %d", _DB_OBJ_FULL, $p_fr, $p_cdid, $p_sep);
        $stmt_sec = $this->dbHand->prepare($sql_sec);
        $stmt_sec->execute();


        //unlink('test.html');
        exit();
    }

    public function saveDocumentLog($p_doc_id, $p_message, $p_reason) {

        $message = smartisoAddslashes($p_message);
        if ($p_reason == 'NULL' || $p_reason == '') {
            $p_reason = '------';
        }
        $date_year = date("Y-m-d H:i:s");

        $sql = sprintf(" INSERT INTO %s.cms_document_log (cmsdocID,message,whenDate,reason) VALUES (%d,'%s','%s','%s')", _DB_OBJ_FULL, $p_doc_id, $message, $date_year, $p_reason);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        //dump_array_and_exit($stmt->errorInfo());
    }

    public function documentRecordHistory($p_doc_id, $action) {

        //$message = smartisoAddslashes($p_message);
        $this->documentId = $p_doc_id;
        $sql = sprintf(" INSERT INTO %s.document_record_history (cmsdocID,action) VALUES (%d,'%s')", _DB_OBJ_FULL, $p_doc_id, $action);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        //dump_array_and_exit($stmt->errorInfo());
    }

    public function updateArchiveA($p_doc_id) {

        $sql = sprintf(" UPDATE  %s.cms_documents SET isArchive = '1' WHERE cmsdocID =" . $p_doc_id, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function updateStatusA($p_doc_id) {

        $sql = sprintf(" UPDATE  %s.cms_documents SET status = 'A' WHERE documentID =" . $p_doc_id, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function getIDbyFile($p_doc_id) {

        $sql = sprintf(" select * from  %s.cms_documents  WHERE documentID =" . $p_doc_id . " order by cmsdocID desc", _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        return $res;
    }

    public function documentDeleteAlertAction($p_doc_id) {

        $sql = sprintf("DELETE %s.cms_document_alerts WHERE cmsdocID = %d", _DB_OBJ_FULL, $p_doc_id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function documentDeleteAlertAction1($p_doc_id) {

        $sql = sprintf("UPDATE %s.cms_document_alerts
				SET
				
				doneStatus = 'L',
				doneComment = '%s'
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $this->documentInformation['docissuer_comment'], $p_doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    /**
     * This method is used to get document tree data from xml file
     */
    public function getDocumentTreeNewzz($p_standard_id, $p_context = 'documents', $alerts = false, $country = '-1', $mp = 0, $type = 0, $search = '') {


        echo $this->getMSETree($p_standard_id, $p_context, $alerts, $country, $mp, $type, $search);
    }

    public function getDocumentTreeNewqq($p_standard_id, $p_context = 'documents', $alerts = false, $country = '-1', $mp = 0, $type = 0, $search = '') {
        $id = getLoggedInUserId();
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }

        if ($p_standard_id == 51) {
            $tree_html = "<div id='sidetree' class='filetree'>";

            $tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

            $tree_html .= "<ul class='treeview' id='dmstree'>";
            $this->file_data = $this->get51fileline();

            $tree_html .= $this->get51data(51);
            return str_replace("<ul></ul>", "", $tree_html);
            exit(); //bob
        }

        if ($p_context == "action_tracker") {
            $this->file_data = $this->getDocumentListActionTracker();
        } else {
            $this->file_data = $this->getDocumentListByStandard($p_standard_id, $alerts, $country, $mp, $type, $search);

            $this->alert_data = $this->getDocAlertsCount();
        }

        $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);

        $tree_html = "";

        $sql = "SELECT distinct sectionActive FROM " . _DB_OBJ_FULL . ".participant_authorization_stats
				WHERE participantID = " . $id . " AND sectionName = 'perm_doc' AND sectionActive=1 ";

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($res) {

            $val = $res['sectionActive'];
        }

        foreach ($xmldata->standards->standard as $standard_xml_data) {

            $att = $standard_xml_data->attributes();

            if ($att['standard_id'] == $p_standard_id) {

                $tree_html = "<div id='sidetree' class='filetree'>";

                $tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

                $tree_html .= "<ul class='treeview' id='dmstree'>";

                foreach ($standard_xml_data as $section_data) {

                    $section_attr = $section_data->attributes();

                    $link = str_replace('.', '.', $section_data['code']);

                    $escaped_code = str_replace('.', '_', $section_data['code']);
                    $document_name = urlencode($section_data->label);

                    $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

                    $toggle_class = "";
                    $upload_link = "";

                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }

                    if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
                    } else {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
                    }

                    $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
                    $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";

                    $tree_html .= $upload_link;

                    if ($p_context != 'process_flow') {
                        $tree_html .= "<span id='loader_block_" . $escaped_code . "' style='margin-left:20px'>	</span>";

                        if ($this->file_data && array_key_exists($link, $this->file_data)) {

                            foreach ($this->file_data[$link] as $fileLine) {
                                $rel = $fileLine['cmsdocID'];

                                if ($alerts && $this->alert_data[$rel] < 1)
                                    continue;
                                if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                                $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";



                                $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }

                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }
                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }

                                $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                                if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
                                    if ($fileLine['alertType'] == 'change')
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                                    else
                                        $tree_html .= "Replace | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                                    $contributors = $this->getDocumentContributors($rel);
                                    $document_status = "";
                                    if ($contributors) {

                                        $contributor_replied_a = 0;
                                        $contributor_replied_na = 0;
                                        $contributor_replied = 0;
                                        $contributor_count = count($contributors);

                                        foreach ($contributors as $contributor) {
                                            switch ($contributor['passed']) {
                                                case 1: $contributor_replied_a++;
                                                    $contributor_replied++;
                                                    break;
                                                case 2: $contributor_replied_na++;
                                                    $contributor_replied++;
                                                    break;
                                            }
                                        }

                                        if ($contributor_replied == 0) {

                                            $document_status = "Wait for Contributors's response";
                                        } else if ($contributor_replied < $contributor_count) {

                                            $document_status = "Sent to contributors";
                                        } else if ($contributor_replied == $contributor_replied_a) {

                                            $document_status = "Approved by contributors";
                                        } else if ($contributor_replied == $contributor_replied_na) {

                                            $document_status = "Not approved by contributors";
                                        }


                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                                    } else {
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                                    }





                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                                    $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                                    $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                                }
                                //alerts
                                elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                                    $tree_html .= $this->alert_data[$rel];

                                    $tree_html .= "</SPAN>)</a>  ";
                                } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


                                    $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                                    //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                                    if (_ALLOW_GRP_POLICY == 1)
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";

                                    $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }
                                //everyone else
                                else {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }

                                $tree_html .= "</SPAN></P>";
                            }
                        }



                        $tree_html .= $doc_detail_block;
                    } else {
                        $tree_html .= $select_reference_link;
                    }

                    //$tree_html .= "</span>";

                    $count = 0;

                    $count = count($section_data->sections->section);


                    if ($count) {
                        //		$tree_html .= $this->getMSETree2($section_data['ID']);
                        $tree_html .= $this->getMSETree2($section_data['ID']);
                        //   $tree_html .= $this->getSectionChildrenNew($section_data->sections->section, $p_standard_id, $p_context, $val, $alerts);
                    }


                    $tree_html .= "</li>";
                }

                $tree_html .= "</ul></div>";
            }
        } // end foreach

        return str_replace("<ul></ul>", "", $tree_html);
    }

    private function getSectionChildrenNew($p_section_data, $p_standard_id, $p_context, $sectionActive, $alerts) {
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }
        $tree_html = "";

        foreach ($p_section_data as $section_data_ele) {

            $link = str_replace('.', '.', $section_data_ele['code']);
            $escaped_code = str_replace('.', '_', $section_data_ele['code']);
            $document_name = urlencode($section_data_ele->label);

            $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

            $val = $sectionActive;

            $toggle_class = "";
            $upload_link = "";

            if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                $toggle_class = " class='toggle_upload_link'";
                $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";

                $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
            }

            $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'] . "<span class='expandable'>";
            $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";
            $tree_html .= $upload_link;
            /*
              if (($section_data_ele['code'] == '4.5' && $p_standard_id == 52) || ($section_data_ele['code'] == '4.4' && $p_standard_id == 58)) {
              $tree_html .= "<UL>";
              $tree_html .= $this->get51data($p_standard_id);
              $tree_html .= "</UL>";
             */
            if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
            } else {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
            }

            if ($p_context != 'process_flow') {
                $tree_html .= "<span id='loader_block_" . $escaped_code . "' style='margin-left:20px'></span>";
                if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
                    foreach ($this->file_data[$link] as $fileLine) {
                        $rel = $fileLine['cmsdocID'];
                        if ($alerts && $this->alert_data[$rel] < 1)
                            continue;
                        if ($fileLine['documentSubType'] == "W")
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                        elseif ($fileLine['documentSubType'] == "G")
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                        else
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                        $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
                        if ($this->country == "1") {
                            $tree_html .= "&nbsp;-&nbsp;<B>";
                            $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                            $tree_html .= "&nbsp;</B>";
                        }
                        $iaStr = '';
                        if ($fileLine['audit'] == "1")
                            $iaStr = "[Audit]";
                        if ($fileLine['induct'] == "1")
                            $iaStr .= " [Induct]";
                        if ($fileLine['isIS'] == "1")
                            $iaStr .= " [Information Security]";
                        if ($iaStr != '') {
                            $iaStr .= " | ";
                        }



                        $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";

                        if ($this->version_type == 'minor_version') {
                            $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                        } else if ($this->version_type == 'version') {
                            $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            ;
                        } else {
                            $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            ;
                        }


                        $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                        //actiontracker

                        if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {

                            if (substr($fileLine['alertType'], 0, 6) == 'change')
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                            else
                                $tree_html .= "Replace | ";

                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                            $contributors = $this->getDocumentContributors($rel);
                            $document_status = "";
                            if ($contributors) {

                                $contributor_replied_a = 0;
                                $contributor_replied_na = 0;
                                $contributor_replied = 0;
                                $contributor_count = count($contributors);

                                foreach ($contributors as $contributor) {
                                    switch ($contributor['passed']) {
                                        case 1: $contributor_replied_a++;
                                            $contributor_replied++;
                                            break;
                                        case 2: $contributor_replied_na++;
                                            $contributor_replied++;
                                            break;
                                    }
                                }

                                if ($contributor_replied == 0) {

                                    $document_status = "Wait for Contributors's response";
                                } else if ($contributor_replied < $contributor_count) {

                                    $document_status = "Sent to contributors";
                                } else if ($contributor_replied == $contributor_replied_a) {

                                    $document_status = "Approved by contributors";
                                } else if ($contributor_replied == $contributor_replied_na) {

                                    $document_status = "Not approved by contributors";
                                }


                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                            } else {
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                            }





                            $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";

                            $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                            $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                            $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                        }
                        //alerts
                        elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                            $tree_html .= $this->alert_data[$rel];

                            $tree_html .= "</SPAN>)</a>  ";
                        } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                            $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                            //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                            if (_ALLOW_GRP_POLICY == 1)
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                            if ($this->alert_data[$rel])
                                $tree_html .= $this->alert_data[$rel];
                            else
                                $tree_html .= '0';
                            $tree_html .= ")</a> | ";

                            $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                        }
                        //everyone else
                        else {
                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                            if ($this->alert_data[$rel])
                                $tree_html .= $this->alert_data[$rel];
                            else
                                $tree_html .= '0';
                            $tree_html .= ")</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                        }

                        $tree_html .= "</SPAN></P>";
                    }
                }

                $tree_html .= $doc_detail_block;
            } else {
                $tree_html .= $select_reference_link;
            }

            $tree_html .= "</span><ul>";

            $count = 0;

            // $count = count($section_data_ele->sections->section);

            if ($count > 0) {
                $tree_html .= $this->getSectionChildrenNew($section_data_ele->sections->section, $p_standard_id, $p_context, $val, $alerts);
            }

            $tree_html .= "</li>";
            $tree_html .= "</ul>";


            $tree_html .= "</LI>";
        }
        $tree_html .= "</UL>";



        return $tree_html;
    }

    public function getDocumentListByStandard($p_standard_id, $alerts = false, $country = '-1', $mp = 0, $type = '', $search = '') {

        $userID = getLoggedInUserID();
        $orgObj = SetupGeneric::useModule('Organigram');
        $orgObj->setItemInfo(array('id' => 0, 'participant_id' => $userID));
        $userData = $orgObj->getBuByParticipant();
        $userlevel = getUserAccessLevel();
        // $bustr=$orgObj->getBUstr($userData[0]["buID"]);
        //$buArr=explode(",",$bustr);

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";
        if ($alerts)
            $archive = "";
        else
            $archive = "C.isArchive=0 and status in ('A','I') and ";

        if ($country == -1 || $country == '')
            $countryStr = "";
        else
            $countryStr = " and location in ($country) ";

        if ($mp == 1)
            $mpStr = " and audit =1";
        elseif ($mp == 2)
            $mpStr = " and induct =1";
        elseif ($mp == 3)
            $mpStr = " and isIS =1";
        else
            $mpStr = " ";

        if ($type == '')
            $typeStr = " ";
        else
            $typeStr = " and documentType='" . $type . "'";

        if ($search == '')
            $searchStr = " ";
        else
            $searchStr = " and (title like '%" . $search . "%' or description like '%" . $search . "%')";

        if ($p_standard_id == _STD_ID) {

            $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID,L.name FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID 
                                        LEFT OUTER JOIN %s.locationgram L
					ON C.location = L.locID 
					where %s documentID > 0  and isnull(code27002,0)=0  and classification in (%s)  %s %s %s %s
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $archive, $classStr, $countryStr, $mpStr, $typeStr, $searchStr);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($result as $data) {


                $search = false;
                $buArr = explode(",", $data['affected_Bus']);
                //checking bus
                if (trim($data['affected_Bus']) == '')
                    $search = true;
                elseif (in_array($userData[0]["buID"], $buArr))
                    $search = true;
                if ($userlevel == 1 || $search == true)
                //    if ( $userlevel == 1 || $data["classification"]=='U' || in_array($data[buID], $buArr) )
                    $retData[$data['fileReference']][] = $data;
            }
        } elseif ($p_standard_id == 9) {


            $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID,S.matrixcode,L.code as codestow,LOC.name FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M ON C.cmsdocID = M.cmsdocID 
                                        LEFT OUTER JOIN %s.locationgram LOC ON C.location = LOC.locID 
					left JOIN %s.std_doc_matrix S ON C.filereference=S.code  and S.standard= %d 
                              LEFT JOIN %s.cms_doc_std_links L ON C.cmsdocID=L.cmsid and L.sid=%d  
					where  isnull(code27002,0)=0 and  C.isArchive=0 and status in ('A','I') and documentID > 0 and classification in (%s) %s %s %s %s
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_standard_id, _DB_OBJ_FULL, $p_standard_id, $classStr, $countryStr, $mpStr, $typeStr, $searchStr);


            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($result) {
                foreach ($result as $data) {
                    $search = false;
                    $buArr = explode(",", $data['affected_Bus']);
                    //checking bus
                    if (trim($data['affected_Bus']) == '')
                        $search = true;
                    elseif (in_array($userData[0]["buID"], $buArr))
                        $search = true;
                    if ($userlevel == 1 || $search == true) {
                        // if ( $userlevel == 1 || $data["classification"]=='U' || in_array($data[buID], $buArr) ){
                        if ($data['codestow'])
                            $retData[$data['codestow']][] = $data;
                        else if ($data['matrixcode'])
                            $retData[$data['matrixcode']][] = $data;
                    }
                }
            }
        } else {


            $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID,S.matrixcode,LOC.name FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M ON C.cmsdocID = M.cmsdocID 
					INNER JOIN %s.std_doc_matrix S ON C.filereference=S.code
                                        LEFT OUTER JOIN %s.locationgram LOC ON C.location = LOC.locID 
					where isnull(code27002,0)=0 and C.isArchive=0 and status in ('A','I') and documentID > 0 and classification in (%s)  and S.standard= %d %s %s %s %s
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr, $p_standard_id, $countryStr, $mpStr, $typeStr, $searchStr);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($result) {
                foreach ($result as $data) {
                    $search = false;
                    $buArr = explode(",", $data['affected_Bus']);
                    //checking bus
                    if (trim($data['affected_Bus']) == '')
                        $search = true;
                    elseif (in_array($userData[0]["buID"], $buArr))
                        $search = true;
                    if ($userlevel == 1 || $search == true)
                    //          if ( $userlevel == 1 || $data["classification"]=='U' || in_array($data[buID], $buArr) )
                        $retData[$data['matrixcode']][] = $data;
                }
            }
        }


        return $retData;
    }

    public function getDocData($p_id) {

        $sql = sprintf("SELECT D.*,C.approvedBy,C.dateApproved,C.authorizerComment FROM  %s.cms_documents D
					   INNER JOIN %s.cms_documents_metadata C ON C.cmsdocID = D.cmsdocID
					   WHERE D.cmsdocID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $resultSet = $stmt->fetch(PDO::FETCH_ASSOC);


        $sql = sprintf("SELECT forename+' '+surname as name1 FROM %s.participant_database where participantID =%d", _DB_OBJ_FULL, $resultSet["initiatedByParticipant"]);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result1 = $stmt->fetch(PDO::FETCH_ASSOC);


        $resultSet["name1"] = $result1['name1'];

        $sql = sprintf("SELECT forename+' '+surname as name2 FROM %s.participant_database where participantID =%d", _DB_OBJ_FULL, $resultSet["approvedBy"]);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result2 = $stmt->fetch(PDO::FETCH_ASSOC);
        $resultSet["name2"] = $result2['name2'];
        return $resultSet;
    }

    public function getDocAlertsCount() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        $sql = sprintf("select count(*) as cnt,A.cmsdocID from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' and D.classification in (%s) group by A.cmsdocID", _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        foreach ($results as $data) {
            $resultset[$data['cmsdocID']] = $data['cnt'];
        }
        return $resultset;
    }

    public function getDocAlerts() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        $sql = sprintf("select * from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' and D.classification in (%s) ", _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
        return $results;
    }

    public function getDocAlert() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        $sql = sprintf("select * from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus = 'I' and   D.classification in (%s) ", _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getDocumentListActionTracker() {
        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";
        $id = getLoggedInUserId();
        if (isAdministrator())
            $idStr = "";
        else
        // $idStr = " initiatedByParticipant=" . $id . " and  "; so that all dis can see the files
            $idStr = "";
        $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M
					ON C.cmsdocID = M.cmsdocID 
					where C.isArchive=0 and %s status in ('U','D') and documentID > 0 and classification in (%s)  
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $idStr, $classStr);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $data) {
            $retData[$data['fileReference']][] = $data;
        }

        return $retData;
    }

    public function saveReject($p_file_id) {

        $sql = sprintf("update %s.cms_documents set status='R',isArchive=1 where cmsdocID=%d ", _DB_OBJ_FULL, $p_file_id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function saveChange($p_file_id, $comment) {

        $sql = sprintf("update %s.cms_document_alerts set alertstatus='A',doneComment='%s' where alertID=%d ", _DB_OBJ_FULL, $comment, $p_file_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    public function saveDisagree($p_file_id, $comment) {

        $sql = sprintf("update %s.cms_document_alerts set alertstatus='D',doneComment='%s' where alertID=%d ", _DB_OBJ_FULL, $comment, $p_file_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
    }

    public function saveApprove($p_file_id) {

        $sql = sprintf("update %s.cms_documents set status='A' where documentID=%d ", _DB_OBJ_FULL, $p_file_id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function getDocumentTreenew2old($p_standard_id, $alerts, $country = '-1', $mp = 0, $type = '', $search = '') {

        $id = getLoggedInUserId();
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();
        $toggle_class = "";
        $upload_link = "";
        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }

        if ($p_standard_id == 51) {
            $tree_html = "<div id='sidetree' class='filetree'>";

            $tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

            $tree_html .= "<ul class='treeview' id='dmstree'>";
            $this->file_data = $this->get51fileline();

            $tree_html .= $this->get51data(51);
            return $tree_html;
            exit(); //bob
        }
        $this->file_data = $this->getDocumentListByStandard($p_standard_id, $alerts, $country, $mp, $type, $search);

        $this->alert_data = $this->getDocAlertsCount();
        if ($this->file_data) {
            foreach ($this->file_data as $filedata) {
                foreach ($filedata as $filedata1) {
                    $filearr = explode(".", $filedata1["fileReference"]);
                    $arrStr = "";
                    foreach ($filearr as $key => $value) {
                        $arrStr .= $value;
                        $result[] = $arrStr;
                        $arrStr .= ".";
                    }
                }
            }


            $this->checkArr = array_unique($result);

            $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);

            $tree_html = "";
            foreach ($xmldata->standards->standard as $standard_xml_data) {

                $att = $standard_xml_data->attributes();

                if ($att['standard_id'] == $p_standard_id) {

                    $tree_html = "<DIV id='sidetree' class='filetree'>";

                    $tree_html .= "<DIV id='sidetreecontrol'><A class='link' href='#'>Collapse All</A> | <A class='link' href='#'>Expand All</A><BR/><BR/></DIV>";


                    $tree_html .= "<UL class='treeview' id='dmstree'>";

                    foreach ($standard_xml_data as $section_data) {

                        $section_attr = $section_data->attributes();
                        if (!is_array($this->checkArr))
                            $this->checkArr = array();
                        if (!in_array($section_data['code'], $this->checkArr))
                            continue;

                        $link = trim($section_data['code']);
                        $escaped_code = str_replace('.', '_', $section_data['code']);

                        $document_name = urlencode($section_data->label);

                        $doc_detail_block = "<DIV class='abc' id='doclist_" . $link . "' style='margin-left:20px'></DIV>";
                        $tree_html .= "<LI class='expandable'><DIV class='hitarea expandable-hitarea'></DIV><SPAN class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
                        $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";

                        $tree_html .= "<SPAN id='loader_block_" . $escaped_code . "' style='margin-left:20px'>	</SPAN>";
                        if (array_key_exists($link, $this->file_data)) {
                            foreach ($this->file_data[$link] as $fileLine) {
                                $rel = $fileLine['cmsdocID'];
                                if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<P><SPAN class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                $tree_html .= "<A href='javascript: void(0)' class='download_file'";
                                $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }
                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }

                                $tree_html .= "&nbsp;<A href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";

                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }

                                $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                                $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                if ($this->alert_data[$rel])
                                    $tree_html .= $this->alert_data[$rel];
                                else
                                    $tree_html .= '0';
                                $tree_html .= ")</a> | ";


                                $tree_html .= "<A href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</A>";

                                $tree_html .= "</SPAN></P>";
                            }
                        }



                        $tree_html .= $doc_detail_block;

                        $count = 0;

                        $count = count($section_data->sections->section);


                        if ($count) {
                            $tree_html .= "<UL>";
                            $tree_html .= $this->getSectionChildrenNew2($section_data->sections->section, $p_standard_id, $val, $alerts);
                            $tree_html .= "</UL>";
                        }


                        $tree_html .= "</LI>";
                    }
                    $tree_html .= "</UL>";
                }
                $tree_html .= "</DIV>";
            }

            return $tree_html;
        } else {
            return "<DIV id='sidetreecontrol'><H1>There are no documents available to be viewed at the moment</H1></DIV>";
        }
    }

    private function getSectionChildrenNew2($p_section_data, $p_standard_id, $sectionActive) {
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }
        $tree_html = "";

        foreach ($p_section_data as $section_data_ele) {
            $link = str_replace('.', '.', $section_data_ele['code']);
            if (!in_array($section_data_ele['code'], $this->checkArr))
                continue;

            $escaped_code = str_replace('.', '_', $section_data_ele['code']);
            $document_name = urlencode($section_data_ele->label);

            $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

            $val = $sectionActive;

            $tree_html .= "<LI class='expandable'><div class='hitarea expandable-hitarea'></div><SPAN class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'] . "<SPAN class='expandable'>";
            $tree_html .= "&nbsp;-&nbsp;<A" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";


            $tree_html .= "<SPAN id='loader_block_" . $escaped_code . "' style='margin-left:20px'></SPAN>";
            /*
              if (($section_data_ele['code'] == '4.5' && $p_standard_id == 52) || ($section_data_ele['code'] == '4.4' && $p_standard_id == 58)) {
              $tree_html .= "<UL>";
              $tree_html .= $this->get51data($p_standard_id);
              $tree_html .= "</UL>";
              } else { */
            if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
            } else {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
            }


            if (array_key_exists($link, $this->file_data)) {    //starts reading through results
                foreach ($this->file_data[$link] as $fileLine) {
                    $rel = $fileLine['cmsdocID'];
                    if ($alerts && $this->alert_data[$rel] < 1)
                        continue;
                    if ($fileLine['documentSubType'] == "W")
                        $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                    elseif ($fileLine['documentSubType'] == "G")
                        $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                    else
                        $tree_html .= "<P><SPAN class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $document . $scope[$fileLine['scope']] . "</SPAN>";

                    $tree_html .= "<A href='javascript: void(0)' class='download_file'";
                    $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";



                    $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                    if ($this->country == "1") {
                        $tree_html .= "&nbsp;-&nbsp;<B>";
                        $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                        $tree_html .= "&nbsp;</B>";
                    }
                    $iaStr = '';
                    if ($fileLine['audit'] == "1")
                        $iaStr = "[Audit]";
                    if ($fileLine['induct'] == "1")
                        $iaStr .= " [Induct]";
                    if ($fileLine['isIS'] == "1")
                        $iaStr .= " [Information Security]";
                    if ($iaStr != '') {
                        $iaStr .= " | ";
                    }

                    if ($this->version_type == 'minor_version') {
                        $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                    } else if ($this->version_type == 'version') {
                        $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                    } else {
                        $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                    }


                    $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                    if ($this->alert_data[$rel])
                        $tree_html .= $this->alert_data[$rel];
                    else
                        $tree_html .= '0';
                    $tree_html .= ")</a> | ";
                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";


                    $tree_html .= "</SPAN></P>";
                }

                $tree_html .= $doc_detail_block;


                $tree_html .= "</SPAN>";

                $count = 0;

                // $count = count($section_data_ele->sections->section);

                if ($count > 0) {
                    $tree_html .= "<UL>";
                    $tree_html .= $this->getSectionChildrenNew2($section_data_ele->sections->section, $p_standard_id, $p_context, $val, $alerts);
                    $tree_html .= "</UL>";
                }

                $tree_html .= "</LI>";
            }
        }
        return $tree_html;
    }

    public function getSTOWList($reference, $code = '') {
        if ($code == '') {
            $sql = sprintf("SELECT * FROM %s.std_doc_matrix	where code='%s'", _DB_OBJ_FULL, $reference);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $code1 = $result['matrixcode'];
        } else
            $code1 = $code;
        $sql1 = sprintf("SELECT code,name FROM %s.msr_departments where pid>=0 and sid=9 ", _DB_OBJ_FULL); //get stow data

        $stmt = $this->dbHand->prepare($sql1);
        $stmt->execute();

        $resultstow = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $retData = "";
        foreach ($resultstow as $data) {

            $sel = $code1 == $data["code"] ? "selected" : "";

            if (substr($data["code"], 0, 2) == '11.')
                $retData1 .= "<OPTION VALUE='" . $data["code"] . "' " . $sel . " >" . $data["code"] . " - " . $data["name"] . "</OPTION>";
            else
                $retData .= "<OPTION VALUE='" . $data["code"] . "' " . $sel . " >" . $data["code"] . " - " . $data["name"] . "</OPTION>";
        }




        return $retData . $retData1;
    }

    public function getMSRList($p_code) {


        $sql1 = sprintf("SELECT code,name FROM %s.msr_departments where pid>0 and sid=52 order by code", _DB_OBJ_FULL); //get stow data

        $stmt = $this->dbHand->prepare($sql1);
        $stmt->execute();

        $resultstow = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $retData = "";

        foreach ($resultstow as $data) {
            $sel = $data["code"] == $p_code ? "selected " : " ";

            $retData .= "<OPTION VALUE='" . $data["code"] . "' " . $sel . " >" . $data["code"] . " - " . $data["name"] . "</OPTION>";
        }




        return $retData;
    }

    public function getLinkedCode($p_sid, $p_docID) {
        $sql = sprintf("SELECT code FROM %s.cms_doc_std_links where cmsid=%d and sid=%d ", _DB_OBJ_FULL, $p_docID, $p_sid); //get stow data

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result)
            return $result["code"];
        else
            return "";
    }

    public function moveDocument($p_document_id, $newcode, $p_reply, $newSTOW, $oldcode, $sid, $code51) {

        $sql = sprintf("UPDATE %s.cms_documents
				SET filereference = '%s' , code27002 = '%d'
				
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $newcode, $code51, $p_document_id);

        $sql_del = sprintf("delete from %s.cms_doc_std_links
				WHERE cmsid = %d and sid=%d"
                , _DB_OBJ_FULL
                , $p_document_id
                , $sid);

        $sql_sec = sprintf("insert into  %s.cms_doc_std_links (code,cmsid,sid) values ('%s',%d,%d)"
                , _DB_OBJ_FULL
                , $newSTOW
                , $p_document_id
                , $sid);

        $stmt = $this->dbHand->prepare($sql);
        $stmt_del = $this->dbHand->prepare($sql_del);
        $stmt_sec = $this->dbHand->prepare($sql_sec);

        $stmt->execute();
        $stmt_del->execute();
        $stmt_sec->execute();



        $participantObj = SetupGeneric::useModule('Participant');
        $participantObj->setItemInfo(array('id' => getLoggedInUserId()));
        $partcipantData = $participantObj->displayItemById();
        $mover_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];


        $message = "Document has been moved from " . $oldcode . " to " . $newcode . " by " . $mover_name;
        $this->saveDocumentLog($p_document_id, $message, $p_reply);

        $emailObj = new infoEmailHelper();



        $subject = "smart-ISO Moved Document.";

        $document_info = $this->getDocData($p_document_id);

        $miscObj = new Misc();
        $document_types = $miscObj->getDocumentTypes();
        $document_info['type'] = $document_types[$document_info['documentType']];

        $participantObj->setItemInfo(array('id' => $document_info['initiatedByParticipant']));
        $partcipantData = $participantObj->displayItemById();

        $created_by = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $who1 = array(
            'displayname' => ucwords($created_by),
            'email' => $partcipantData['emailAddress']
        );
        $participantObj->setItemInfo(array('id' => $document_info['approvedBy']));
        $partcipantData = $participantObj->displayItemById();
        $name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $who = array(
            'displayname' => ucwords($name),
            'email' => $partcipantData['emailAddress']
        );

        $who1 = array(
            'displayname' => ucwords($created_by),
            'email' => $partcipantData['emailAddress']
        );

        $mergeData = array(
            'twoColData' => array(
                'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $document_info['fileReference']),
                'assignedto' => array('left' => '<strong>Document Name:</strong>', 'right' => $document_info['title']),
                'authorizing1' => array('left' => '<strong>Document Description:</strong>', 'right' => $document_info['description']),
                'due' => array('left' => '<strong>Document Type:</strong>', 'right' => $document_info['type']),
                'initBy' => array('left' => '<strong>Initiated By:</strong>', 'right' => $created_by),
                'version' => array('left' => '<strong>Version:</strong>', 'right' => $document_info['versionNew']),
                'dateIssued' => array('left' => '<strong>Date Published/Approved:</strong>', 'right' => format_date($document_info['dateInitiated'])),
                'issued' => array('left' => '<strong>Published/Approved By:</strong>', 'right' => $name),
                'page' => array('left' => '<strong>Pages:</strong>', 'right' => $document_info['pages']),
                'movedfrom' => array('left' => '<strong>Moved from:</strong>', 'right' => $oldcode),
                'movedto' => array('left' => '<strong>Moved to:</strong>', 'right' => $newcode),
                'movedby' => array('left' => '<strong>Moved by:</strong>', 'right' => $mover_name)
            ),
            'singleColData' => array(
                'url' => '<p>Please <a href= "https://' . $_SERVER['HTTP_HOST'] . '/download.php?id=' . $document_info['documentID'] . ' ">CLICK</a> Here to view this document</p>')
        );

        $emailObj->appendInfo($mergeData);


        if (getLoggedInUserId() != $document_info['approvedBy'])
            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'purple');

        $emailObj->sendEmail($subject, $who1, array(), array(), 'me_completed', '', 'purple');

        $participantObj = null;
    }

    public function getGPPolicyDocs() {
        $sql = sprintf("SELECT * FROM %s.cms_documents where status='A' and documentSubType ='G'  order by fileReference,title", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getSelectedGPPolicyDocs($doc_id) {

        $sql = sprintf("SELECT * FROM %s.document_policy_links where GPDocument=%d", _DB_OBJ_FULL, $doc_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getNoneGPPolicyDocs() {
        $sql = sprintf("SELECT * FROM %s.cms_documents where not documentSubType ='G' and status='A' and (documentSubType='Y'  or filereference='1.2')  order by fileReference,title", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getSelectedNoneGPPolicyDocs($doc_id) {

        $sql = sprintf("SELECT * FROM %s.document_policy_links where PolicyDoc=%d", _DB_OBJ_FULL, $doc_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function updatePolicyLinks($doc_id, $doclinks, $policytype) {

        if ($policytype == "G") {
            $fld1 = GPDocument;
            $fld2 = PolicyDoc;
        } else {
            $fld2 = GPDocument;
            $fld1 = PolicyDoc;
        }
        $sql = sprintf("delete from %s.document_policy_links where %s=%d", _DB_OBJ_FULL, $fld1, $doc_id);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        foreach ($doclinks as $data) {
            $sql = sprintf("insert into %s.document_policy_links (%s,%s) values (%d,%d)", _DB_OBJ_FULL, $fld2, $fld1, $data, $doc_id);

            $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();
            $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
        }
    }

    public function sendPolicyChangeReminder($docID) {
        $sql = sprintf("select * from $s.document_policy_links where GPDocument=%d", _DB_OBJ_FULL, $docID);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        foreach ($results as $data) {
            $docdata = $this->getDocumentInformation($data);
        }
    }

    public function getAuditDocuments($bus = '') {
        $sql = sprintf("select * from %s.cms_documents where audit=1 and isnull(isarchive,0)=0 order by filereference", _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        return $results;
    }

    public function editDocument($p_document_id, $document, $classification, $buStr) {

        $sql = sprintf("UPDATE %s.cms_documents
				SET audit = %d ,induct = %d,isIS = %d,classification = '%s',affected_bus = '%s'
				WHERE cmsdocID = %d", _DB_OBJ_FULL, $document["ia"], $document["id"], $document["is"], $classification, $buStr, $p_document_id);



        $stmt = $this->dbHand->prepare($sql);


        $stmt->execute();
    }

    public function getDocumentTree52($pid) {
        $id = getLoggedInUserId();


        $sql = sprintf("select * from %s.msr_departments where sid=52 and pid=%d", _DB_OBJ_FULL, $pid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDocument51() {

        $sql = sprintf("select * from %s.msr_departments where sID=51 and pID=0  and ID> 1927 order by  ID", _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        return $result;
    }

    public function get51data($p_std) {

        $codes = $this->getDocument51();



        foreach ($codes as $code) {
            $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div>";
                  $tree_html .="<span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A" . $code['code'] . "&nbsp;-&nbsp;" . $code['name'] . "</span>";


            if ($this->file_data[$code["ID"]]) {
              
                foreach ($this->file_data[$code["ID"]] as $fileData) {

                    $tree_html .= $this->get51dataline($fileData);
                }
               
            }
        }
        //    $tree_html .= "<li class='expandable'><div class='hitarea expandable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Others<span class='expandable'>";

        return $tree_html;
    }

    public function get51dataline($fileLine) {
        $rel = $fileLine['cmsdocID'];
        $p_context = "documents";
        $p_standard_id = _STD_ID;
        if ($alerts && $this->alert_data[$rel] < 1)
            return;
        $tree_html .= "<UL >";
         $tree_html .=  "<li class='expandable'><div class='hitarea expandable-hitarea'></div>";
        if ($fileLine['documentSubType'] == "W")
            $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
        elseif ($fileLine['documentSubType'] == "G")
            $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
        else
            $tree_html .= "<span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

        $tree_html .= "<a href='javascript: void(0)' class='download_file'";
        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";



        $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
        if ($this->country == "1") {
            $tree_html .= "&nbsp;-&nbsp;<B>";
            $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
            $tree_html .= "&nbsp;</B>";
        }

        $iaStr = '';
        if ($fileLine['audit'] == "1")
            $iaStr = "[Audit]";
        if ($fileLine['induct'] == "1")
            $iaStr .= " [Induct]";
        if ($fileLine['isIS'] == "1")
            $iaStr .= " [Information Security]";
        if ($iaStr != '') {
            $iaStr .= " | ";
        }
        if ($this->version_type == 'minor_version') {
            $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
        } else if ($this->version_type == 'version') {
            $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
        } else {
            $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
        }

        $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

        if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
            if ($fileLine['alertType'] == 'change')
                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
            else
                $tree_html .= "Replace | ";


            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
            $contributors = $this->getDocumentContributors($rel);
            $document_status = "";
            if ($contributors) {

                $contributor_replied_a = 0;
                $contributor_replied_na = 0;
                $contributor_replied = 0;
                $contributor_count = count($contributors);

                foreach ($contributors as $contributor) {
                    switch ($contributor['passed']) {
                        case 1: $contributor_replied_a++;
                            $contributor_replied++;
                            break;
                        case 2: $contributor_replied_na++;
                            $contributor_replied++;
                            break;
                    }
                }

                if ($contributor_replied == 0) {

                    $document_status = "Wait for Contributors's response";
                } else if ($contributor_replied < $contributor_count) {

                    $document_status = "Sent to contributors";
                } else if ($contributor_replied == $contributor_replied_a) {

                    $document_status = "Approved by contributors";
                } else if ($contributor_replied == $contributor_replied_na) {

                    $document_status = "Not approved by contributors";
                }


                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
            } else {
                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
            }





            $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
            $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



            $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

            $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
        }
        //alerts
        elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

            $tree_html .= $this->alert_data[$rel];

            $tree_html .= "</SPAN>)</a>  ";
        } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


            $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
            //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
            if (_ALLOW_GRP_POLICY == 1)
                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
            if ($this->alert_data[$rel])
                $tree_html .= $this->alert_data[$rel];
            else
                $tree_html .= '0';
            $tree_html .= ")</a> | ";

            $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
        }
        //everyone else
        else {
            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
            if ($this->alert_data[$rel])
                $tree_html .= $this->alert_data[$rel];
            else
                $tree_html .= '0';
            $tree_html .= ")</a> | ";
            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
        }

        $tree_html .= "</SPAN>";
        $tree_html .= "</UL>";
        return($tree_html );
    }

    public function get51fileline() {
        $userlevel = getUserAccessLevel();
        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";
        if ($alerts)
            $archive = "";
        else
            $archive = "C.isArchive=0 and status in ('A','I') and ";

        if ($country == -1 || $country == '')
            $countryStr = "";
        else
            $countryStr = " and location in ($country) ";

        if ($mp == 1)
            $mpStr = " and audit =1";
        elseif ($mp == 2)
            $mpStr = " and induct =1";
        elseif ($mp == 3)
            $mpStr = " and isIS =1";
        else
            $mpStr = " ";

        if ($type == '')
            $typeStr = " ";
        else
            $typeStr = " and documentType='" . $type . "'";

        if ($search == '')
            $searchStr = " ";
        else
            $searchStr = " and (title like '%" . $search . "%' or description like '%" . $search . "%')";

        $sql = sprintf("SELECT *,C.cmsdocID as cmsdocID,LOC.name FROM %s.cms_documents C
					LEFT OUTER JOIN %s.cms_documents_metadata M ON C.cmsdocID = M.cmsdocID 
					LEFT OUTER JOIN %s.locationgram LOC ON C.location = LOC.locID 
					where C.code27002>0 and C.isArchive=0 and status in ('A','I') and documentID > 0 and classification in (%s)   %s %s %s %s
					ORDER BY C.cmsdocID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr, $p_standard_id, $countryStr, $mpStr, $typeStr, $searchStr);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            foreach ($result as $data) {
                $search = false;
                $buArr = explode(",", $data['affected_Bus']);
                //checking bus
                if (trim($data['affected_Bus']) == '')
                    $search = true;
                elseif (in_array($userData[0]["buID"], $buArr))
                    $search = true;
                if ($userlevel == 1 || $search == true)
                //          if ( $userlevel == 1 || $data["classification"]=='U' || in_array($data[buID], $buArr) )
                    $retData[$data['code27002']][] = $data;
            }
        }

        return $retData;
    }

    public function getReportDatabySid($sid) {

        //  echo     $sql = sprintf("select * from %s.cms_documents D inner join %s.std_doc_matrix M on D.fileReference=M.code inner join %s.msr_departments MD on M.matrixcode=MD.code where isarchive=0 and M.standard=%d order by MD.ID", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $sid);
        $sql = sprintf("select C.*,D.code ,D.name   from %s.msr_departments D inner join %s.std_doc_matrix M on D.code=M.matrixcode inner join %s.cms_documents C on M.code=C.fileReference  where C.isarchive=0 and C.status='A' and isnull(C.code27002,0)=0 and D.sID=%d and M.standard=%d order by D.ID", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $sid, $sid);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getDocumentTreeNew12($p_standard_id, $p_context = 'documents', $alerts = false, $country = '-1', $mp = 0, $type = 0, $search = '') {

        global $newdatalist;

        $id = getLoggedInUserId();
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }

        if ($p_standard_id == 51) {
            $tree_html = "<div id='sidetree' class='filetree'>";

            $tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

            $tree_html .= "<ul class='treeview' id='doctree'>";
            $this->file_data = $this->get51fileline();

            $tree_html .= $this->get51data(51);
            return $tree_html;
            exit(); //bob
        }
        $this->file_data = $this->getDocumentListByStandard($p_standard_id, $alerts, $country, $mp, $type, $search);

        $this->alert_data = $this->getDocAlertsCount();

        $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);

        $tree_html = "";

        $sql = "SELECT distinct sectionActive FROM " . _DB_OBJ_FULL . ".participant_authorization_stats
				WHERE participantID = " . $id . " AND sectionName = 'perm_doc' AND sectionActive=1 ";

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($res) {

            $val = $res['sectionActive'];
        }






        foreach ($xmldata->standards->standard as $standard_xml_data) {

            $att = $standard_xml_data->attributes();

            if ($att['standard_id'] == $p_standard_id) {
        $tree_html = "<DIV id='sidetree' class='filetree'>";

        $tree_html .= "<DIV id='sidetreecontroller' style='text-align: center'><A class='link' href='#'>Collapse All</A> | <A class='link' href='#'>Expand All</A><BR/><BR/></DIV>";


        $tree_html .= "<UL class='treeview' id='doctree'>";
        
                foreach ($standard_xml_data as $section_data) {

                    $section_attr = $section_data->attributes();

                    $link = str_replace('.', '.', $section_data['code']);

                    $escaped_code = str_replace('.', '_', $section_data['code']);
                    $document_name = urlencode($section_data->label);

                    $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

                    $toggle_class = "";
                    $upload_link = "";

                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }

                    if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
                    } else {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
                    }

                    // $tree_html .= "<LI class='expandable'><DIV class='hitarea expandable-hitarea'></DIV>";

                    $tree_html .= "<li class='collapsable'><div class='hitarea collapsable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
                    $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";
                    $tree_html .= $upload_link . "</SPAN>";
                    $tree_html .= "<span id='loader_block_" . $escaped_code . "' style='margin-left:20px'>	</span>";

                    if ($this->file_data && array_key_exists($link, $this->file_data)) {

                        foreach ($this->file_data[$link] as $fileLine) {
                            $rel = $fileLine['cmsdocID'];

                            if ($alerts && $this->alert_data[$rel] < 1)
                                continue;
                            if ($fileLine['documentSubType'] == "W")
                                $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                            elseif ($fileLine['documentSubType'] == "G")
                                $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                            else
                                $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                            $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                            $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";

                            $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                            if ($this->country == "1") {
                                $tree_html .= "&nbsp;-&nbsp;<B>";
                                $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                $tree_html .= "&nbsp;</B>";
                            }

                            $iaStr = '';
                            if ($fileLine['audit'] == "1")
                                $iaStr = "[Audit]";
                            if ($fileLine['induct'] == "1")
                                $iaStr .= " [Induct]";
                            if ($fileLine['isIS'] == "1")
                                $iaStr .= " [Information Security]";
                            if ($iaStr != '') {
                                $iaStr .= " | ";
                            }

                            if ($this->version_type == 'minor_version') {
                                $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                            } else if ($this->version_type == 'version') {
                                $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            } else {
                                $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            }
                            $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                            if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
                                if ($fileLine['alertType'] == 'change')
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                                else
                                    $tree_html .= "Replace | ";


                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                                $contributors = $this->getDocumentContributors($rel);
                                $document_status = "";
                                if ($contributors) {

                                    $contributor_replied_a = 0;
                                    $contributor_replied_na = 0;
                                    $contributor_replied = 0;
                                    $contributor_count = count($contributors);

                                    foreach ($contributors as $contributor) {
                                        switch ($contributor['passed']) {
                                            case 1: $contributor_replied_a++;
                                                $contributor_replied++;
                                                break;
                                            case 2: $contributor_replied_na++;
                                                $contributor_replied++;
                                                break;
                                        }
                                    }

                                    if ($contributor_replied == 0) {

                                        $document_status = "Wait for Contributors's response";
                                    } else if ($contributor_replied < $contributor_count) {

                                        $document_status = "Sent to contributors";
                                    } else if ($contributor_replied == $contributor_replied_a) {

                                        $document_status = "Approved by contributors";
                                    } else if ($contributor_replied == $contributor_replied_na) {

                                        $document_status = "Not approved by contributors";
                                    }


                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                                } else {
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                                }





                                $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
                                $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                                $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                                $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                            }
                            //alerts
                            elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                                $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                                $tree_html .= $this->alert_data[$rel];

                                $tree_html .= "</SPAN>)</a>  ";
                            } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


                                $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                                //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                                if (_ALLOW_GRP_POLICY == 1)
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                                $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                if ($this->alert_data[$rel])
                                    $tree_html .= $this->alert_data[$rel];
                                else
                                    $tree_html .= '0';
                                $tree_html .= ")</a> | ";

                                $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                            }
                            //everyone else
                            else {
                                $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                if ($this->alert_data[$rel])
                                    $tree_html .= $this->alert_data[$rel];
                                else
                                    $tree_html .= '0';
                                $tree_html .= ")</a> | ";
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                            }
                        }

                        $tree_html .= "</SPAN></P>";
                    }




                    // $tree_html .= $this->getSectionChildrenNew($section_data->sections->section, $p_standard_id, $p_context, $val, $alerts); 
                    $tree_html .= $this->getMSETree2($section_data['ID'], $section_data->sections->section, $p_standard_id, $p_context, $val, $alerts);
                    $tree_html .= "</LI>";
                }
                $tree_html .= "</UL>";
            }
        }

        echo $tree_html;
    }

    public function getMSETree2x($p_link, $p_section_data, $p_standard_id, $p_context, $sectionActive, $alerts) {

        global $newdatalist;

        $sql = sprintf("SELECT * FROM %s.msr_departments 
				WHERE sid = 52 and pid=%d order by code", _DB_OBJ_FULL, $p_link);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $data1 = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }

        $tree_html = "";

        $tree_html .= "<UL>";
        foreach ($p_section_data as $section_data_ele) {

            $link = str_replace('.', '.', $section_data_ele['code']);
            $escaped_code = str_replace('.', '_', $section_data_ele['code']);
            $document_name = urlencode($section_data_ele->label);

            $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

            $val = $sectionActive;

            $toggle_class = "";
            $upload_link = "";

            if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                $toggle_class = " class='toggle_upload_link'";
                $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";

                $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
            }

            $tree_html .= "<li class='collapsable'><div class='hitarea collapsable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'] . "<span class='expandable'>";
            $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";
            $tree_html .= $upload_link;

            if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
            } else {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
            }

            if ($p_context != 'process_flow') {
                $tree_html .= "<span id='loader_block_" . $escaped_code . "' style='margin-left:20px'></span>";
                if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
                    foreach ($this->file_data[$link] as $fileLine) {
                        $rel = $fileLine['cmsdocID'];
                        if ($alerts && $this->alert_data[$rel] < 1)
                            continue;
                        if ($fileLine['documentSubType'] == "W")
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                        elseif ($fileLine['documentSubType'] == "G")
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                        else
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                        $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
                        if ($this->country == "1") {
                            $tree_html .= "&nbsp;-&nbsp;<B>";
                            $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                            $tree_html .= "&nbsp;</B>";
                        }
                        $iaStr = '';
                        if ($fileLine['audit'] == "1")
                            $iaStr = "[Audit]";
                        if ($fileLine['induct'] == "1")
                            $iaStr .= " [Induct]";
                        if ($fileLine['isIS'] == "1")
                            $iaStr .= " [Information Security]";
                        if ($iaStr != '') {
                            $iaStr .= " | ";
                        }



                        $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";

                        if ($this->version_type == 'minor_version') {
                            $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                        } else if ($this->version_type == 'version') {
                            $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            ;
                        } else {
                            $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            ;
                        }


                        $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                        //actiontracker

                        if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {

                            if (substr($fileLine['alertType'], 0, 6) == 'change')
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                            else
                                $tree_html .= "Replace | ";

                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                            $contributors = $this->getDocumentContributors($rel);
                            $document_status = "";
                            if ($contributors) {

                                $contributor_replied_a = 0;
                                $contributor_replied_na = 0;
                                $contributor_replied = 0;
                                $contributor_count = count($contributors);

                                foreach ($contributors as $contributor) {
                                    switch ($contributor['passed']) {
                                        case 1: $contributor_replied_a++;
                                            $contributor_replied++;
                                            break;
                                        case 2: $contributor_replied_na++;
                                            $contributor_replied++;
                                            break;
                                    }
                                }

                                if ($contributor_replied == 0) {

                                    $document_status = "Wait for Contributors's response";
                                } else if ($contributor_replied < $contributor_count) {

                                    $document_status = "Sent to contributors";
                                } else if ($contributor_replied == $contributor_replied_a) {

                                    $document_status = "Approved by contributors";
                                } else if ($contributor_replied == $contributor_replied_na) {

                                    $document_status = "Not approved by contributors";
                                }


                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                            } else {
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                            }





                            $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";

                            $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                            $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                            $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                        }
                        //alerts
                        elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                            $tree_html .= $this->alert_data[$rel];

                            $tree_html .= "</SPAN>)</a>  ";
                        } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                            $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                            //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                            if (_ALLOW_GRP_POLICY == 1)
                                $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                            if ($this->alert_data[$rel])
                                $tree_html .= $this->alert_data[$rel];
                            else
                                $tree_html .= '0';
                            $tree_html .= ")</a> | ";

                            $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                        }
                        //everyone else
                        else {
                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                            if ($this->alert_data[$rel])
                                $tree_html .= $this->alert_data[$rel];
                            else
                                $tree_html .= '0';
                            $tree_html .= ")</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                        }

                        $tree_html .= "</SPAN></P>";
                    }
                }

                $tree_html .= $doc_detail_block;
            } else {
                $tree_html .= $select_reference_link;
            }

            $tree_html .= "</span><ul>";
            //  foreach ($data1 as $section_data1) {
            $count = 0;

            // $count = count($section_data_ele->sections->section);

            if ($count > 0) {
                $tree_html .= $this->getMSETree2(1, $section_data_ele->sections->section, $p_standard_id, $p_context, $val, $alerts);
                //$tree_html .= $this->getMSETree2($section_data_ele->sections->section, $p_standard_id, $p_context, $val, $alerts);
            }
            $tree_html .= "</li>";
            $tree_html .= "</ul>";


            $tree_html .= "</LI>";
        }
        $tree_html .= "</UL>";



        return $tree_html;
    }

    public function getDocumentTreeNew2rr($p_standard_id, $p_context = 'documents', $alerts = false, $country = '-1', $mp = 0, $type = 0, $search = '') {

        global $newdatalist;

        $id = getLoggedInUserId();
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }
        if ($p_standard_id == 51) {
            $tree_html = "<div id='sidetree' class='filetree'>";

            $tree_html .= "<div id='sidetreecontrol'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

            $tree_html .= "<ul class='treeview' id='doctree'>";
            $this->file_data = $this->get51fileline();

            $tree_html .= $this->get51data(51);
            return $tree_html;
            exit(); //bob
        }
        $this->file_data = $this->getDocumentListByStandard($p_standard_id, $alerts, $country, $mp, $type, $search);

        $this->alert_data = $this->getDocAlertsCount();
        if ($this->file_data) {
            foreach ($this->file_data as $filedata) {
                foreach ($filedata as $filedata1) {
                    $filearr = explode(".", $filedata1["fileReference"]);
                    $arrStr = "";
                    foreach ($filearr as $key => $value) {
                        $arrStr .= $value;
                        $result[] = $arrStr;
                        $arrStr .= ".";
                    }
                }
            }


            $this->checkArr = array_unique($result);

            $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);



            foreach ($xmldata->standards->standard as $standard_xml_data) {

                $att = $standard_xml_data->attributes();

                if ($att['standard_id'] == $p_standard_id) {
            $tree_html = "";

            $tree_html = "<DIV id='sidetree' class='filetree'>";

            $tree_html .= "<DIV id='sidetreecontroller' style='text-align: center'><A class='link' href='#'>Collapse All</A> | <A class='link' href='#'>Expand All</A><BR/><BR/></DIV>";



            $tree_html .= "<UL class='treeview' id='doctree'>";
                    foreach ($standard_xml_data as $section_data) {

                        $section_attr = $section_data->attributes();
                        if (!is_array($this->checkArr))
                            $this->checkArr = array();
                        if (!in_array($section_data['code'], $this->checkArr))
                            continue;

                        $link = str_replace('.', '.', $section_data['code']);

                        $escaped_code = str_replace('.', '_', $section_data['code']);
                        $document_name = urlencode($section_data->label);

                        $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

                        $toggle_class = "";
                        $upload_link = "";

                        $tree_html .= "<li class='collapsable'><div class='hitarea collapsable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
                        $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";
                        $tree_html .= $upload_link . "</SPAN>";
                        $tree_html .= "<span id='loader_block_" . $escaped_code . "' style='margin-left:20px'>	</span>";

                        if ($this->file_data && array_key_exists($link, $this->file_data)) {

                            foreach ($this->file_data[$link] as $fileLine) {
                                $rel = $fileLine['cmsdocID'];

                                if ($alerts && $this->alert_data[$rel] < 1)
                                    continue;
                                if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                                $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";

                                $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }

                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }

                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }
                                $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                            
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                               
                            }

                            $tree_html .= "</SPAN></P>";
                        }


 $count = 0;

                        $count = count($section_data->sections->section);


                        if ($count) {

                        // $tree_html .= $this->getSectionChildrenNew($section_data->sections->section, $p_standard_id, $p_context, $val, $alerts); 
                        $tree_html .= $this->getMSETree2a($section_data['ID'], $section_data->sections->section, $p_standard_id, $p_context, $val, $alerts);
                        }
                        $tree_html .= "</LI>";
                    }
                    $tree_html .= "</UL>";
                }
            }

            echo $tree_html;
        } else {
            echo "<DIV id='sidetreecontrol'><H1>There are no documents available to be viewed at the moment</H1></DIV>";
        }
    }

    public function getMSETree2axx($p_link, $p_section_data, $p_standard_id, $p_context, $sectionActive, $alerts) {

        global $newdatalist;

        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }

        $tree_html = "";

        $tree_html .= "<UL class='treeview' id='doctree'>";
        foreach ($p_section_data as $section_data_ele) {

            $link = str_replace('.', '.', $section_data_ele['code']);
                        if (!in_array($section_data_ele['code'], $this->checkArr))
                            continue;
            $escaped_code = str_replace('.', '_', $section_data_ele['code']);
            $document_name = urlencode($section_data_ele->label);

            $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

            $val = $sectionActive;

            $toggle_class = "";
            $upload_link = "";


            $tree_html .= "<li class='collapsable'><div class='hitarea collapsable-hitarea'></div><span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'] . "<span class='expandable'>";
            $tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";
            $tree_html .= $upload_link;

            if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
            } else {
                $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
            }

            if ($p_context != 'process_flow') {
                $tree_html .= "<span id='loader_block_" . $escaped_code . "' style='margin-left:20px'></span>";
                if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
                    foreach ($this->file_data[$link] as $fileLine) {
                        $rel = $fileLine['cmsdocID'];
                        if ($alerts && $this->alert_data[$rel] < 1)
                            continue;
                        if ($fileLine['documentSubType'] == "W")
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                        elseif ($fileLine['documentSubType'] == "G")
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                        else
                            $tree_html .= "<P><span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                        $tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
                        if ($this->country == "1") {
                            $tree_html .= "&nbsp;-&nbsp;<B>";
                            $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                            $tree_html .= "&nbsp;</B>";
                        }
                        $iaStr = '';
                        if ($fileLine['audit'] == "1")
                            $iaStr = "[Audit]";
                        if ($fileLine['induct'] == "1")
                            $iaStr .= " [Induct]";
                        if ($fileLine['isIS'] == "1")
                            $iaStr .= " [Information Security]";
                        if ($iaStr != '') {
                            $iaStr .= " | ";
                        }



                        $tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";

                        if ($this->version_type == 'minor_version') {
                            $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                        } else if ($this->version_type == 'version') {
                            $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            ;
                        } else {
                            $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                            ;
                        }


                            $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                            if ($this->alert_data[$rel])
                                $tree_html .= $this->alert_data[$rel];
                            else
                                $tree_html .= '0';
                            $tree_html .= ")</a> | ";
                            $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                       

                        $tree_html .= "</SPAN></P>";
                    }
                }

                $tree_html .= $doc_detail_block;
            } else {
                $tree_html .= $select_reference_link;
            }

            $tree_html .= "</span><ul>";
            //  foreach ($data1 as $section_data1) {
            $count = 0;

             $count = count($section_data_ele->sections->section);

            if ($count > 0) {
                $tree_html .= $this->getMSETree2a(1, $section_data_ele->sections->section, $p_standard_id, $p_context, $val, $alerts);
                //$tree_html .= $this->getMSETree2($section_data_ele->sections->section, $p_standard_id, $p_context, $val, $alerts);
            }
            $tree_html .= "</li>";
            $tree_html .= "</ul>";


            $tree_html .= "</LI>";
        }
        $tree_html .= "</UL>";



        return $tree_html;
    }
	
	
	    public function getDocumentTreeNew($p_standard_id, $p_context = 'documents', $alerts = false, $country = '-1', $mp = 0, $type = 0, $search = '') {

        global $newdatalist;

        $id = getLoggedInUserId();
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }
	
         if ($p_standard_id == 51) {
            $tree_html = "<div id='sidetree' class='filetree'>";

            $tree_html .= "<DIV id='sidetreecontroller' style='text-align: center'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

            $tree_html .= "<ul class='treeview' id='doctree'>";
            $this->file_data = $this->get51fileline();

            $tree_html .= $this->get51data(51);
            return str_replace("<ul></ul>", "", $tree_html);
            exit(); //bob
        }
		$this->file_data = $this->getDocumentListByStandard($p_standard_id, $alerts, $country, $mp, $type, $search);

        $this->alert_data = $this->getDocAlertsCount();
            
        
        $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);
        
        $tree_html = "";
		      $sql = "SELECT distinct sectionActive FROM " . _DB_OBJ_FULL . ".participant_authorization_stats
				WHERE participantID = " . $id . " AND sectionName = 'perm_doc' AND sectionActive=1 ";

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($res) {

            $val = $res['sectionActive'];
        }

                $tree_html = "<DIV id='sidetree' class='filetree'>";

                $tree_html .= "<DIV id='sidetreecontroller' style='text-align: center'><A class='link' href='#'>Collapse All</A> | <A class='link' href='#'>Expand All</A><BR/><BR/></DIV>";

                $tree_html .= "<UL class='treeview' id='doctree'>";		
		

                        foreach ($xmldata->standards->standard as $standard_xml_data) {

            $att = $standard_xml_data->attributes();
			 if ($att['standard_id'] == $p_standard_id) {
				 
	foreach ($standard_xml_data as $section_data) {
		
						   $section_attr = $section_data->attributes();

                    $link = str_replace('.', '.', $section_data['code']);

                    $escaped_code = str_replace('.', '_', $section_data['code']);
                    $document_name = urlencode($section_data->label);

                    $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

                    $toggle_class = "";
                    $upload_link = "";
					
					                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }

                    if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
                    } else {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
                    }
					
      				$tree_html .= "<li class='collapsable'><div class='hitarea collapsable-hitarea'></div>";
					$tree_html .= "<span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
					$tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";
					$tree_html .= $upload_link."</SPAN>";
					
				
					
                  
                      
                                           

 if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
     $tree_html .= "<UL >";
                      foreach ($this->file_data[$link] as $fileLine) {
                                                          $rel = $fileLine['cmsdocID'];
								
				if ($alerts && $this->alert_data[$rel] < 1)
                                    continue;
			 $tree_html .=  "<li class='expandable'><div class='hitarea expandable-hitarea'></div>";

                         
                          if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                								$tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
			
                         								$tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }
                         
                         
                         								                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }
								
								                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }
								   $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                                                                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
                                    if ($fileLine['alertType'] == 'change')
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                                    else
                                        $tree_html .= "Replace | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                                    $contributors = $this->getDocumentContributors($rel);
                                    $document_status = "";
                                    if ($contributors) {

                                        $contributor_replied_a = 0;
                                        $contributor_replied_na = 0;
                                        $contributor_replied = 0;
                                        $contributor_count = count($contributors);

                                        foreach ($contributors as $contributor) {
                                            switch ($contributor['passed']) {
                                                case 1: $contributor_replied_a++;
                                                    $contributor_replied++;
                                                    break;
                                                case 2: $contributor_replied_na++;
                                                    $contributor_replied++;
                                                    break;
                                            }
                                        }

                                        if ($contributor_replied == 0) {

                                            $document_status = "Wait for Contributors's response";
                                        } else if ($contributor_replied < $contributor_count) {

                                            $document_status = "Sent to contributors";
                                        } else if ($contributor_replied == $contributor_replied_a) {

                                            $document_status = "Approved by contributors";
                                        } else if ($contributor_replied == $contributor_replied_na) {

                                            $document_status = "Not approved by contributors";
                                        }


                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                                    } else {
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                                    }





                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                                    $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                                    $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                                }
                                //alerts
                                elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                                    $tree_html .= $this->alert_data[$rel];

                                    $tree_html .= "</SPAN>)</a>  ";
                                } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


                                    $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                                    //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                                    if (_ALLOW_GRP_POLICY == 1)
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";

                                    $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }
                                //everyone else
                                else {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }

			// $tree_html .=  $fileLine['title']."&nbsp;&nbsp;&nbsp;&nbsp;<A class='edit_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Edit</A>&nbsp;&nbsp;|&nbsp;&nbsp;<A class='archive_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Archive</A>";

		
			                    
			         }
                                  $tree_html .= "</UL >";
                    }
                      
                     
                
                    
                  $tree_html .=   $this->getDMSTree2($section_data->sections->section, $p_standard_id, $p_context, $val, $alerts);
                    $tree_html .= "</LI>";
                }
						}
						}
                $tree_html .= "</UL>";
            
                  
        echo $tree_html;

}

    public function getDMSTree2($p_section_data, $p_standard_id, $p_context, $sectionActive, $alerts) {
          
              
                $tree_html .= "<UL >";

                foreach ($p_section_data as $section_data_ele) {
                   
                $escaped_code = str_replace('.', '_', $section_data_ele['code']);    
                if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }
                   // $document_name = $section_data_ele->label;
                    $tree_html .= "<LI class='expandable'><DIV class='hitarea expandable-hitarea'></DIV>";
                   // $tree_html .="<SPAN>". $section_data_ele['code']."&nbsp;&nbsp;". $document_name."</SPAN>";
                   // $tree_html .=$upload_link;
                    
                    $tree_html .= "<span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'];
					$tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";
					$tree_html .= $upload_link."</SPAN>";
                    
                    if ($p_context != 'process_flow') {
                      $tree_html .= "<UL >";
                     $link = str_replace('.', '.', $section_data_ele['code']);
                       if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
                      foreach ($this->file_data[$link] as $fileLine) {
                                                          $rel = $fileLine['cmsdocID'];
								
				if ($alerts && $this->alert_data[$rel] < 1)
                                    continue;
			 $tree_html .=  "<li class='expandable'><div class='hitarea expandable-hitarea'></div>";

                         
                          if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                								$tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
			
                         								$tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }
                         
                         
                         								                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }
								
								                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }
								   $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                                                                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
                                    if ($fileLine['alertType'] == 'change')
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                                    else
                                        $tree_html .= "Replace | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                                    $contributors = $this->getDocumentContributors($rel);
                                    $document_status = "";
                                    if ($contributors) {

                                        $contributor_replied_a = 0;
                                        $contributor_replied_na = 0;
                                        $contributor_replied = 0;
                                        $contributor_count = count($contributors);

                                        foreach ($contributors as $contributor) {
                                            switch ($contributor['passed']) {
                                                case 1: $contributor_replied_a++;
                                                    $contributor_replied++;
                                                    break;
                                                case 2: $contributor_replied_na++;
                                                    $contributor_replied++;
                                                    break;
                                            }
                                        }

                                        if ($contributor_replied == 0) {

                                            $document_status = "Wait for Contributors's response";
                                        } else if ($contributor_replied < $contributor_count) {

                                            $document_status = "Sent to contributors";
                                        } else if ($contributor_replied == $contributor_replied_a) {

                                            $document_status = "Approved by contributors";
                                        } else if ($contributor_replied == $contributor_replied_na) {

                                            $document_status = "Not approved by contributors";
                                        }


                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                                    } else {
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                                    }





                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                                    $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                                    $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                                }
                                //alerts
                                elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                                    $tree_html .= $this->alert_data[$rel];

                                    $tree_html .= "</SPAN>)</a>  ";
                                } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


                                    $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                                    //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                                    if (_ALLOW_GRP_POLICY == 1)
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";

                                    $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }
                                //everyone else
                                else {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }

			// $tree_html .=  $fileLine['title']."&nbsp;&nbsp;&nbsp;&nbsp;<A class='edit_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Edit</A>&nbsp;&nbsp;|&nbsp;&nbsp;<A class='archive_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Archive</A>";

		
			                    
			         }
                    }
                      $tree_html .= "</UL>";
                    }
                     
                    $tree_html .= "</LI>";
                }
                $tree_html .= "</UL>";
            
		
       
        return $tree_html;
        }
        
        
     	    public function getDocumentTreeNew2($p_standard_id, $p_context = 'documents', $alerts = false, $country = '-1', $mp = 0, $type = 0, $search = '') {

        global $newdatalist;

        $id = getLoggedInUserId();
        $scopeObj = SetupGeneric::useModule('DocScope');
        $scopeArr = $scopeObj->displayItems();

        $scope[0] = "&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele) {

            $scope[$scope_ele["ID"]] = "[" . $scope_ele['code'] . "]";
        }
	
         if ($p_standard_id == 51) {
            $tree_html = "<div id='sidetree' class='filetree'>";

            $tree_html .= "<DIV id='sidetreecontroller' style='text-align: center'><a class='link' href='#'>Collapse All</a> | <a class='link' href='#'>Expand All</a><br/><br/></div>";

            $tree_html .= "<ul class='treeview' id='doctree'>";
            $this->file_data = $this->get51fileline();

            $tree_html .= $this->get51data(51);
            return str_replace("<ul></ul>", "", $tree_html);
            exit(); //bob
        }
		$this->file_data = $this->getDocumentListByStandard($p_standard_id, $alerts, $country, $mp, $type, $search);

        $this->alert_data = $this->getDocAlertsCount();
            if ($this->file_data) {
            foreach ($this->file_data as $filedata) {
                foreach ($filedata as $filedata1) {
                    $filearr = explode(".", $filedata1["fileReference"]);
                    $arrStr = "";
                    foreach ($filearr as $key => $value) {
                        $arrStr .= $value;
                        $result[] = $arrStr;
                        $arrStr .= ".";
                    }
                }
            }


            $this->checkArr = array_unique($result);
            
        $xmldata = simplexml_load_file(realpath(_PATH_PRIVATE_FILES . '../documents') . '/' . $this->xmlDocumentName);
        
        $tree_html = "";
		      $sql = "SELECT distinct sectionActive FROM " . _DB_OBJ_FULL . ".participant_authorization_stats
				WHERE participantID = " . $id . " AND sectionName = 'perm_doc' AND sectionActive=1 ";

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($res) {

            $val = $res['sectionActive'];
        }

                $tree_html = "<DIV id='sidetree' class='filetree'>";

                $tree_html .= "<DIV id='sidetreecontroller' style='text-align: center'><A class='link' href='#'>Collapse All</A> | <A class='link' href='#'>Expand All</A><BR/><BR/></DIV>";

                $tree_html .= "<UL class='treeview' id='doctree'>";		
		

                        foreach ($xmldata->standards->standard as $standard_xml_data) {

            $att = $standard_xml_data->attributes();
			 if ($att['standard_id'] == $p_standard_id) {
				 
	foreach ($standard_xml_data as $section_data) {
		
						   $section_attr = $section_data->attributes();
                        if (!is_array($this->checkArr))
                            $this->checkArr = array();
                        if (!in_array($section_data['code'], $this->checkArr))
                            continue;
                    $link = str_replace('.', '.', $section_data['code']);

                    $escaped_code = str_replace('.', '_', $section_data['code']);
                    $document_name = urlencode($section_data->label);

                    $doc_detail_block = "<div class='abc' id='doclist_" . $escaped_code . "' style='margin-left:20px'></div>";

                    $toggle_class = "";
                    $upload_link = "";
					
					                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }

                    if (is_array($this->documentInformation['sel_cms_refs']) && in_array($escaped_code, $this->documentInformation['sel_cms_refs'])) {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_sel' rel='" . $escaped_code . "'><b>Unselect</b></a>";
                    } else {
                        $select_reference_link = "&nbsp;&nbsp;<a href='javascript: void(0)' id='select_" . $escaped_code . "' class='cms_select state_unsel' rel='" . $escaped_code . "'><b>Select</b></a>";
                    }
					
      				$tree_html .= "<li class='collapsable'><div class='hitarea collapsable-hitarea'></div>";
					$tree_html .= "<span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_attr['code'];
					$tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data->label . "</a>";
					$tree_html .= $upload_link."</SPAN>";
					
				
					
                  
                      
                                           

 if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
     $tree_html .= "<UL >";
                      foreach ($this->file_data[$link] as $fileLine) {
                                                          $rel = $fileLine['cmsdocID'];
								
				if ($alerts && $this->alert_data[$rel] < 1)
                                    continue;
			 $tree_html .=  "<li class='expandable'><div class='hitarea expandable-hitarea'></div>";

                         
                          if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                								$tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
			
                         								$tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }
                         
                         
                         								                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }
								
								                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }
								   $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                                                                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
                                    if ($fileLine['alertType'] == 'change')
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                                    else
                                        $tree_html .= "Replace | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                                    $contributors = $this->getDocumentContributors($rel);
                                    $document_status = "";
                                    if ($contributors) {

                                        $contributor_replied_a = 0;
                                        $contributor_replied_na = 0;
                                        $contributor_replied = 0;
                                        $contributor_count = count($contributors);

                                        foreach ($contributors as $contributor) {
                                            switch ($contributor['passed']) {
                                                case 1: $contributor_replied_a++;
                                                    $contributor_replied++;
                                                    break;
                                                case 2: $contributor_replied_na++;
                                                    $contributor_replied++;
                                                    break;
                                            }
                                        }

                                        if ($contributor_replied == 0) {

                                            $document_status = "Wait for Contributors's response";
                                        } else if ($contributor_replied < $contributor_count) {

                                            $document_status = "Sent to contributors";
                                        } else if ($contributor_replied == $contributor_replied_a) {

                                            $document_status = "Approved by contributors";
                                        } else if ($contributor_replied == $contributor_replied_na) {

                                            $document_status = "Not approved by contributors";
                                        }


                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                                    } else {
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                                    }





                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                                    $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                                    $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                                }
                                //alerts
                                elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                                    $tree_html .= $this->alert_data[$rel];

                                    $tree_html .= "</SPAN>)</a>  ";
                                } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


                                    $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                                    //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                                    if (_ALLOW_GRP_POLICY == 1)
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";

                                    $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }
                                //everyone else
                                else {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }

			// $tree_html .=  $fileLine['title']."&nbsp;&nbsp;&nbsp;&nbsp;<A class='edit_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Edit</A>&nbsp;&nbsp;|&nbsp;&nbsp;<A class='archive_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Archive</A>";

		
			                    
			         }
                                  $tree_html .= "</UL >";
                    }
                      
                     
                
                    
                  $tree_html .=   $this->getDMSTree2a($section_data->sections->section, $p_standard_id, $p_context, $val, $alerts);
                    $tree_html .= "</LI>";
                }
						}
						}
                $tree_html .= "</UL>";
            
                  
        echo $tree_html;
                } else {
            echo "<DIV id='sidetreecontrol'><H1>There are no documents available to be viewed at the moment</H1></DIV>";
        }
}

    public function getDMSTree2a($p_section_data, $p_standard_id, $p_context, $sectionActive, $alerts) {
          
              
                $tree_html .= "<UL >";

                foreach ($p_section_data as $section_data_ele) {
                              $link = str_replace('.', '.', $section_data_ele['code']);
                        if (!in_array($section_data_ele['code'], $this->checkArr))
                            continue; 
                $escaped_code = str_replace('.', '_', $section_data_ele['code']);    
                if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {
                        $toggle_class = " class='toggle_upload_link'";
                        $upload_link = "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('upload_document.php?code=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=1000,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Upload Document</b></a>";
                        $upload_link .= "&nbsp;&nbsp;<a style='display: none' href='javascript: void(0)' onclick=\"window.open('doc_archive.php?document_ref=" . $escaped_code . "&doc_name=" . $document_name . "','upload_document','width=900,height=600,scrollbars=yes')\" class='updl_" . $escaped_code . "'><b>Archived Documents</b></a>";
                    }
                   // $document_name = $section_data_ele->label;
                    $tree_html .= "<LI class='expandable'><DIV class='hitarea expandable-hitarea'></DIV>";
                   // $tree_html .="<SPAN>". $section_data_ele['code']."&nbsp;&nbsp;". $document_name."</SPAN>";
                   // $tree_html .=$upload_link;
                    
                    $tree_html .= "<span class='folder'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $section_data_ele['code'];
					$tree_html .= "&nbsp;-&nbsp;<a" . $toggle_class . " rel='" . $escaped_code . "' href='javascript: void(0)'>" . $section_data_ele->label . "</a>";
					$tree_html .= $upload_link."</SPAN>";
                    
                    if ($p_context != 'process_flow') {
                      $tree_html .= "<UL >";
                     $link = str_replace('.', '.', $section_data_ele['code']);
                       if ($this->file_data && array_key_exists($link, $this->file_data)) {    //starts reading through results
                      foreach ($this->file_data[$link] as $fileLine) {
                                                          $rel = $fileLine['cmsdocID'];
								
				if ($alerts && $this->alert_data[$rel] < 1)
                                    continue;
			 $tree_html .=  "<li class='expandable'><div class='hitarea expandable-hitarea'></div>";

                         
                          if ($fileLine['documentSubType'] == "W")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                elseif ($fileLine['documentSubType'] == "G")
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentSubType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentSubType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";
                                else
                                    $tree_html .= "<span class='" . $this->form_data[$fileLine['documentType']]['class'] . "'><SPAN>" . $this->form_data[$fileLine['documentType']]['str'] . $scope[$fileLine['scope']] . "</SPAN>";

                                								$tree_html .= "<a href='javascript: void(0)' class='download_file'";
                        $tree_html .= "rel='" . $fileLine['documentID'] . "|" . $fileLine['title'] . "'>" . $fileLine['title'] . "</a>";
			
                         								$tree_html .= "&nbsp;<a href='javascript: void(0)' class='view_version' rel='" . $rel . "'>";
                                if ($this->country == "1") {
                                    $tree_html .= "&nbsp;-&nbsp;<B>";
                                    $tree_html .= $fileLine['location'] == 0 ? "Core" : $fileLine['name'];
                                    $tree_html .= "&nbsp;</B>";
                                }
                         
                         
                         								                                $iaStr = '';
                                if ($fileLine['audit'] == "1")
                                    $iaStr = "[Audit]";
                                if ($fileLine['induct'] == "1")
                                    $iaStr .= " [Induct]";
                                if ($fileLine['isIS'] == "1")
                                    $iaStr .= " [Information Security]";
                                if ($iaStr != '') {
                                    $iaStr .= " | ";
                                }
								
								                                if ($this->version_type == 'minor_version') {
                                    $tree_html .= "Ver " . $fileLine['versionNew'] . "." . intval($fileLine['versionMinor']) . " </A> | " . $iaStr;
                                } else if ($this->version_type == 'version') {
                                    $tree_html .= "Ver  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                } else {
                                    $tree_html .= "Rev  " . $fileLine['versionNew'] . "</A> | " . $iaStr;
                                }
								   $tree_html .= "<a href='javascript: void(0)' class='action view_version' rel='" . $rel . "'>Details</A> |";

                                                                    if (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'action_tracker') {
                                    if ($fileLine['alertType'] == 'change')
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Replace</a> | ";
                                    else
                                        $tree_html .= "Replace | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_publish_new.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Publish</a> | ";
                                    $contributors = $this->getDocumentContributors($rel);
                                    $document_status = "";
                                    if ($contributors) {

                                        $contributor_replied_a = 0;
                                        $contributor_replied_na = 0;
                                        $contributor_replied = 0;
                                        $contributor_count = count($contributors);

                                        foreach ($contributors as $contributor) {
                                            switch ($contributor['passed']) {
                                                case 1: $contributor_replied_a++;
                                                    $contributor_replied++;
                                                    break;
                                                case 2: $contributor_replied_na++;
                                                    $contributor_replied++;
                                                    break;
                                            }
                                        }

                                        if ($contributor_replied == 0) {

                                            $document_status = "Wait for Contributors's response";
                                        } else if ($contributor_replied < $contributor_count) {

                                            $document_status = "Sent to contributors";
                                        } else if ($contributor_replied == $contributor_replied_a) {

                                            $document_status = "Approved by contributors";
                                        } else if ($contributor_replied == $contributor_replied_na) {

                                            $document_status = "Not approved by contributors";
                                        }


                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Contribution Status</a> | ";
                                    } else {
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('assign_contributors.php?doc_id=" . $rel . "','assign_contributors','width=700,height=600,scrollbars=yes')\">Send For Contribution</a> | ";
                                    }





                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action replace_document_w'>Re-work</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('replace_doc.php?document_id=" . $rel . "','replace_doc','width=700,height=600,scrollbars=yes')\">Change</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' rel='" . $rel . "' class='action reject_document'>Reject</a>";



                                    $tree_html .= "<a style='padding-left:15px' rel='footnote' class='document_contributor_status' alt='" . $rel . "'  href='#trigger" . $rel . "'><emp>" . $document_status . "</emp></a>";

                                    $tree_html .= "<div id='contri" . $rel . "' rel='" . $rel . "' class='div_contri' style='overflow:auto; display:none; position: absolute; left:63%;width:210px; padding:2px; border: 1px solid #666666; background-color:#eeeeee'></div>";
                                }
                                //alerts
                                elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $alerts) {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (<SPAN id=counter" . $rel . ">";

                                    $tree_html .= $this->alert_data[$rel];

                                    $tree_html .= "</SPAN>)</a>  ";
                                } elseif (( getUserAccessLevel() == 1 || $val == 1 ) && $p_standard_id == _STD_ID && $p_context == 'documents') {


                                    $tree_html .= "<a href='javascript: void(0)'  class='action'  onclick=\"window.open('archive_document.php?doc_id=" . $fileLine['cmsdocID'] . "','Archive Document','width=600,height=300,scrollbars=yes')\">Archive</a> | ";
                                    //$tree_html .="<a href='javascript: void(0)' rel='" . $rel . "' class='action update_document'>Update</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('change_code.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Move</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('edit_doc.php?document_id=" . $fileLine['cmsdocID'] . "','edit_doc','width=600,height=600,scrollbars=yes')\">Edit</a> | ";
                                    if (_ALLOW_GRP_POLICY == 1)
                                        $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('policy_links.php?document_id=" . $fileLine['cmsdocID'] . "','change_code','width=700,height=600,scrollbars=yes')\">Policy Links</a> | ";


                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";

                                    $tree_html .= "<a href='javascript: void(0)' class='action view_history' rel='" . $rel . "'>History</a> | ";



                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }
                                //everyone else
                                else {
                                    $tree_html .= "<a href='javascript: void(0)' class='action view_alerts' rel='" . $rel . "'>View Alerts (";
                                    if ($this->alert_data[$rel])
                                        $tree_html .= $this->alert_data[$rel];
                                    else
                                        $tree_html .= '0';
                                    $tree_html .= ")</a> | ";
                                    $tree_html .= "<a href='javascript: void(0)' class='action' onclick=\"window.open('raise_alert.php?doc_id=" . $fileLine['cmsdocID'] . "','raise_document_alert','width=700,height=600,scrollbars=yes')\">Alert</a>";
                                }

			// $tree_html .=  $fileLine['title']."&nbsp;&nbsp;&nbsp;&nbsp;<A class='edit_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Edit</A>&nbsp;&nbsp;|&nbsp;&nbsp;<A class='archive_record' rel='" .$linedata['eID']."' href='javascript: void(0)'>Archive</A>";

		
			                    
			         }
                    }
                      $tree_html .= "</UL>";
                    }
                     
                    $tree_html .= "</LI>";
                }
                $tree_html .= "</UL>";
            
		
       
        return $tree_html;

        }   
	}
?>