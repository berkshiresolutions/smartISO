<?php

/**
  $Id: ProcessObjectDecision.class.php,v 5.78 Saturday, February 05, 2011 1:14:49 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, October 20, 2010 3:56:15 PM>
 */
require_once "ProcessObjectInterface.int.php";

class ProcessDecision implements ProcessObjectInterface {

    private $p_x1;
    private $p_y1;

    public function printHeadingAndDescription($classObj, $p_x1, $p_y1, $p_heading, $p_content) {

        $this->p_x1 = $p_x1;
        $this->p_y1 = $p_y1;

        $this->printHeading($classObj, $p_heading);
        $this->printDescription($classObj, $p_content);
    }

    private function printHeading($classObj, $p_content) {

        $this->p_x1 = $this->p_x1 + 5;
        $this->p_y1 = $this->p_y1 + 15;

        //$p_content = 'Vehicle Standard';
        //imagefttext($classObj->getResource(), $classObj->getBusinessUnitFontSize(), 0, $p_x1,$p_y1, $path_colour, $classObj->getFontFile(),$p_content);
        $this->wrapText($classObj, $classObj->getBusinessUnitFontSize(), $p_content, 29);
    }

    private function wrapText($classObj, $p_fontsize, $p_content1, $p_wrapStrCnt) {

  $p_content=str_ireplace("<BR>"," - ",$p_content1);
        $p_content_strlen = strlen($p_content);
        $p_content_tokens = ceil($p_content_strlen / $p_wrapStrCnt);

        if ($p_content_strlen > $p_wrapStrCnt) {

            for ($k = 0; $k < 2; $k++) {

                $start_pt = $k * $p_wrapStrCnt;

                if ($k == 1) {
                    $end_pt = $p_content_strlen - $p_wrapStrCnt;
                } else {
                    $end_pt = $p_wrapStrCnt;
                }

                imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1, $this->p_y1, $path_colour, $classObj->getFontFile(), substr($p_content, $start_pt, $end_pt));
                $this->p_y1 = $this->p_y1 + 14;
            }
        } else {
            imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1, $this->p_y1, $path_colour, $classObj->getFontFile(), $p_content);
            $this->p_y1 = $this->p_y1 + 14;
        }
    }

    private function printDescription($classObj, $p_content1) {

        //$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
  $p_content=str_ireplace("<BR>"," - ",$p_content1);
        $p_content_strlen = strlen($p_content);
        $max_string_length = 35;

        $this->p_y1 = $this->p_y1;

        if ($p_content_strlen < $max_string_length) {
            imagefttext($classObj->getResource(), 9, 0, $this->p_x1 - 30, $this->p_y1, $path_colour, $classObj->getFontFile_2(), $p_content);
        } else {

            $strings = wordwrap(substr($p_content, 0, 162) . ' ...', $max_string_length, "#", false);
            $string_arr = explode("#", $strings);

            $cy1 = $this->p_y1;

            foreach ($string_arr as $strele) {
                imagefttext($classObj->getResource(), 9, 0, $this->p_x1 - 30, $cy1, $path_colour, $classObj->getFontFile_2(), $strele);
                $cy1 = $cy1 + 11;
            }
        }
    }

    private function printDoc($classObj, $p_content) {

        //$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

        $p_content_strlen = strlen($p_content);
        $max_string_length = 35;

        $this->p_y1 = $this->p_y1 + 60;

        if ($p_content_strlen < $max_string_length) {
            imagefttext($classObj->getResource(), 9, 0, $this->p_x1 - 30, $this->p_y1, $path_colour, $classObj->getFontFile_2(), $p_content);
        } else {

            $strings = wordwrap(substr($p_content, 0, 150) . ' ...', $max_string_length, "#", true);
            $string_arr = explode("#", $strings);

            $cy1 = $this->p_y1;

            foreach ($string_arr as $strele) {
                imagefttext($classObj->getResource(), 9, 0, $this->p_x1 - 30, $cy1, $path_colour, $classObj->getFontFile_2(), $strele);
                $cy1 = $cy1 + 11;
            }
        }
    }

    public function draw($classObj, $p_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_step_info) {

        //$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
        $blockCord = $p_block;
        $path_no = $blockCord['path_no'];

//		$x = $classObj->argBlockWidth()/2;
//		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

        $x1 = $blockCord['x'] + ($p_width / 2);
        $y1 = $blockCord['y'] - 5;
        $x2 = $x1 + ($p_width / 2) + 10;
        $y2 = $y1 + ($p_height / 2) + 5;

        $x3 = $x1;
        $y3 = $y1 + $p_height + 10;
        $x4 = $x1 - ($p_width / 2) - 10;
        $y4 = $y1 + ($p_height / 2) + 5;


        switch ($path_no) {
            case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                break;

            case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                break;

            case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                break;

            case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                break;

            case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                break;
        }

        $xln1 = $blockCord['x'] + $path_x_offset;
        $xln2 = $blockCord['x'] + $classObj->argBlockWidth() + $path_x_offset;

        $ym = $blockCord['y'] + $classObj->argObjectHeight();

        $points = array(
            $x1, $y1,
            $x2, $y2,
            $x3, $y3,
            $x4, $y4
        );

        $pointsgloss = array(
            $x1, $y1,
            $x3 + 20, $y4 - 5,
            $x4, $y4
        );

        $pointsgloss2 = array(
            $x1, $y1,
            $x3 + 5, $y4 - 8,
            $x4, $y4
        );

        $pointsgloss3 = array(
            $x1, $y1,
            $x3 + 1, $y4 - 12,
            $x4, $y4
        );

        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

        $path_colour = $classObj->getPathcolour($path_no);

        /* switch ($p_lozenge) {
          case 'NA' :		imageline($classObj->getResource(), $xln1, $ym, $xln2, $ym, $path_colour); break;
          case 'STOP' :	imageline($classObj->getResource(),$xln1, $ym, $x2, $ym, $path_colour); break;
          case 'START' :	imageline($classObj->getResource(),$x1, $ym, $xln2, $ym, $path_colour); break;
          } */


        if ($p_step_info['subSwimID'] != 0) {

            imagefilledrectangle($classObj->getResource(), $x4 + 25, $y3 - 8, $x4 + 53, $y3 - 13, $classObj->getColour('sub_process_colour'));
        }

        if ($classObj->getOutputType() == 'N') {

            imagefilledpolygon($classObj->getResource(), $points, 4, $classObj->getColour('decision_colour'));

            // for gloss
            imagefilledpolygon($classObj->getResource(), $pointsgloss, 3, $classObj->getColour('decision_gloss_colour'));
            imagefilledpolygon($classObj->getResource(), $pointsgloss2, 3, $classObj->getColour('decision_gloss2_colour'));
            imagefilledpolygon($classObj->getResource(), $pointsgloss3, 3, $classObj->getColour('white_colour'));

            imagepolygon($classObj->getResource(), $points, 4, $classObj->getColour('text_colour'));
        } else {
            $classObj->showExternalImage($blockCord['x'], $y1 + 5, 'decision');
        }



        // for ccp
        if ($p_step_info['criticalControlPoint'] != '') {

            if ($classObj->getOutputType() == 'N') {
                imagefilledrectangle($classObj->getResource(), $x4 + 5, $y1 + 3, $x4 + 10, $y3 - 3, $classObj->getColour('ccp_colour'));
            } else {
                $classObj->showExternalImage($x2 - 48, $y3 - 15, 'ccp');
            }
        }


        if ($classObj->getResample()) {
            $resamplePercent = $classObj->getResamplePercent();

            $x1_resamp = ceil($x1 * $resamplePercent);
            $y1_resamp = ceil($y1 * $resamplePercent);
            $x2_resamp = ceil($x2 * $resamplePercent);
            $y2_resamp = ceil($y2 * $resamplePercent);
            $x3_resamp = ceil($x3 * $resamplePercent);
            $y3_resamp = ceil($y3 * $resamplePercent);
            $x4_resamp = ceil($x4 * $resamplePercent);
            $y4_resamp = ceil($y4 * $resamplePercent);

            $node_coordinates = $x1_resamp . ',' . $y1_resamp . ',' . $x2_resamp . ',' . $y2_resamp . ',' . $x3_resamp . ',' . $y3_resamp . ',' . $x4_resamp . ',' . $y4_resamp;
        } else {
            $node_coordinates = $x1 . ',' . $y1 . ',' . $x2 . ',' . $y2 . ',' . $x3 . ',' . $y3 . ',' . $x4 . ',' . $y4;
        }


        $classObj->saveNodeCoordinates($p_step_info['ID'], $node_coordinates);

        if ($classObj->getOutputType() == 'H' && $p_step_info['descQues'] != '') {

            $this->printHeadingAndDescription($classObj, $x4 + 35, $y1 + 10, $p_step_info['buName'], $p_step_info['descQues']);

            if (!empty($p_step_info['comments_information']['HORZ'][0])) {
                $this->printDescription($classObj, $x1, $y1 + 40, $p_width, $p_height, $p_step_info['comments_information']['HORZ'][0]);
            }

            $docs = $classObj->getstepDocs();
            if ($docs != '')
                $this->printDoc($classObj, $docs);
        }
    }

    public function drawShadow($classObj, $p_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_step_info) {

//		$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
        $blockCord = $p_block;
//		$path_no 	= $blockCord['path_no'];
//		$x = $classObj->argBlockWidth()/2;
//		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

        $x1 = $blockCord['x'] + ($p_width / 2);
        $y1 = $blockCord['y'] - 5;
        $x2 = $x1 + ($p_width / 2) + 10;
        $y2 = $y1 + ($p_height / 2) + 5;

        $x3 = $x1;
        $y3 = $y1 + $p_height + 10;
        $x4 = $x1 - ($p_width / 2) - 10;
        $y4 = $y1 + ($p_height / 2) + 5;

        if ($classObj->getOutputType() == 'N') {

            $shade_offset = $classObj->getShadeOffset();

            $shadow_offset_points = array(
                $x1 + $shade_offset - 2, $y1 + $shade_offset,
                $x2 + $shade_offset - 2, $y2 + $shade_offset - 2,
                $x3 + $shade_offset - 2, $y3 + $shade_offset,
                $x4 + $shade_offset - 2, $y4 + $shade_offset + 2
            );

            $shadow2_offset_points = array(
                $x1 + $shade_offset - 4, $y1 + $shade_offset - 2,
                $x2 + $shade_offset - 4, $y2 + $shade_offset - 4,
                $x3 + $shade_offset - 6, $y3 + $shade_offset - 2,
                $x4 + $shade_offset - 4, $y4 + $shade_offset
            );

            imagefilledpolygon($classObj->getResource(), $shadow_offset_points, 4, $classObj->getColour('shadow2_colour'));
            imagefilledpolygon($classObj->getResource(), $shadow2_offset_points, 4, $classObj->getColour('shadow_colour'));
        }
    }

    public function drawLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge) {

        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;

        $xPreStart = $blockCordStart['x'];
        $yPreStart = $blockCordStart['y'];

        $xStart = $blockCordStart['x'] + $classObj->argBlockWidth() / 2 - $p_width / 2;
        $yStart = $yPreStart;

        $xPostStart = $xStart;
        $yPostStart = $blockCordEnd['y'];

        $xEnd = $blockCordEnd['x'];
        $yEnd = $blockCordEnd['y'];



        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

        $path_colour = $classObj->getPathcolour($path_no);

        imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
        imageline($classObj->getResource(), $xStart, $yStart, $xPostStart, $yPostStart, $path_colour);
        imageline($classObj->getResource(), $xPostStart, $yPostStart, $xEnd, $yEnd, $path_colour);
        if ($p_lozenge == 'B') {

            imageline($classObj->getResource(), $xEnd, $yEnd, $xEnd + $classObj->argObjectWidth(), $yEnd, $path_colour);
        }
        imagesetthickness($classObj->getResource(), 1);

        $x1_arrow = $xEnd - 8;
        $x2_arrow = $xEnd - 2;
        $x3_arrow = $xEnd - 8;

        $y1_arrow = $yEnd + 8;
        $y2_arrow = $yEnd;
        $y3_arrow = $yEnd - 8;

        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
    }

    public function drawSupportLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge) {

        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;



        if ($classObj->getOutputType() == 'H') {
            $xStart = $blockCordStart['x'] + 75;
            $yStart = $blockCordStart['y'] + 18;
        } else {
            $xStart = $blockCordStart['x'];
            $yStart = $blockCordStart['y'];
        }

        $xEnd = $xStart;


        $yEnd = $blockCordEnd['y'];



        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

        $path_colour = $classObj->getPathcolour($path_no);


        imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour); // -



        $x1_arrow = $xStart + 10;
        $y1_arrow = $yStart + 10;
        $x2_arrow = $xStart - 10;
        $y2_arrow = $yStart + 10;
        $x3_arrow = $xStart;
        $y3_arrow = $yStart;


        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);


        imagesetthickness($classObj->getResource(), 1);

        /* global $a;
          $coord = $p_start_block.' -> '.$p_end_block;
          imagestring($classObj->getResource(), 5, 110, $a,$coord,$path_colour);
          $a = $a + 20; */
    }

    public function drawsCrossLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset) {

        global $process_flow_id;

        $blockCordStart = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
        $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

        if ($p_objectType == 'START' && $p_start_block != $p_end_block) {

            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xPreStart = $classObj->argBlockWidth() / 2 + $blockCordStart['x'];
            $yPreStart = $classObj->argObjectHeight() + $blockCordStart['y'] + $path_y_offset;

            $xStart = $blockCordEnd['x'] + $path_x_offset;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $path_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $xStart;
            $yEnd = $blockCordEnd['y'] + $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2);

            $xPostStart = $classObj->argBlockWidth() / 2 + $blockCordEnd['x'];
            $yPostStart = $classObj->argObjectHeight() - $classObj->argObjectGap() + $blockCordEnd['y'] + ($p_height / 2);

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_colour = $classObj->getPathcolour($path_no);

            imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
            imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
            imageline($classObj->getResource(), $xEnd, $yEnd, $xPostStart, $yPostStart, $path_colour);

            imagesetthickness($classObj->getResource(), 1);
        } else if ($p_objectType == 'END') {

            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xPreStart = $classObj->argBlockWidth() / 2 + $blockCordStart['x'];
            $yPreStart = $classObj->argObjectHeight() + $blockCordStart['y'];

            $xStart = $blockCordEnd['x'] + $path_x_offset;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $path_y_offset - $path_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $xStart;
            $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $path_y_offset + $blockCordEnd['y'];

            $xPostEnd = $blockCordEnd['x'] + $classObj->argBlockWidth() / 2;
            $yPostEnd = $yEnd;

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_colour = $classObj->getPathcolour($path_no);

            imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
            imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
            imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);

            imagesetthickness($classObj->getResource(), 1);
        } else {

            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xPreStart = $classObj->argBlockWidth() / 2 + $blockCordStart['x'];
            $yPreStart = $classObj->argObjectHeight() + $blockCordStart['y'];

            $xStart = $blockCordEnd['x'] + $path_x_offset;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $path_y_offset - $path_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $xStart;
            $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $path_y_offset + $blockCordEnd['y'];

            $xPostEnd = $blockCordEnd['x'] + $classObj->argBlockWidth() / 2;
            $yPostEnd = $yEnd;

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_colour = $classObj->getPathcolour($path_no);

            if ($p_start_block['step_level'] > $p_end_block['step_level']) {

                imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
                imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
                imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);
            } else {

                if ($path_no) {
                    imageline($classObj->getResource(), $xPreStart, $yPreStart + 25, $xStart, $yStart + 25, $path_colour);
                    imageline($classObj->getResource(), $xStart, $yStart + 25, $xEnd, $yEnd, $path_colour);
                    imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);

                    imageline($classObj->getResource(), $xPreStart, $yStart, $xPreStart, $yStart + 25, $path_colour);

                    $x1_arrow = $xEnd + 5;
                    $x2_arrow = $xEnd + 10;
                    $x3_arrow = $xEnd + 5;

                    $y1_arrow = $yEnd + 6;
                    $y2_arrow = $yEnd + 2;
                    $y3_arrow = $yEnd - 2;

                    $arrow_points = array(
                        $x1_arrow, $y1_arrow,
                        $x2_arrow, $y2_arrow,
                        $x3_arrow, $y3_arrow
                    );

                    imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
                }
            }

            imagesetthickness($classObj->getResource(), 1);
        }


        /* $coord = 'hello world';
          global $a;
          imagestring($classObj->getResource(), 5, 810, $a,$path_y_offset,$path_colour);
          $a = $a + 20; */
    }

    public function drawCrossLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset) {

        global $process_flow_id;

        $blockCordStart = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
        $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

        if ($p_objectType == 'START' && $p_start_block != $p_end_block) {

            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xPreStart = $classObj->argBlockWidth() / 2 + $blockCordStart['x'];
            $yPreStart = $classObj->argObjectHeight() + $blockCordStart['y'] + $path_y_offset;

            $xStart = $blockCordEnd['x'] + $path_x_offset;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $path_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $xStart;
            $yEnd = $blockCordEnd['y'] + $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2);

            $xPostStart = $classObj->argBlockWidth() / 2 + $blockCordEnd['x'];
            $yPostStart = $classObj->argObjectHeight() - $classObj->argObjectGap() + $blockCordEnd['y'] + ($p_height / 2);

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_colour = $classObj->getPathcolour($path_no);

            imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
            imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
            imageline($classObj->getResource(), $xEnd, $yEnd, $xPostStart, $yPostStart, $path_colour);

            imagesetthickness($classObj->getResource(), 1);
        } else if ($p_objectType == 'END') {

            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xPreStart = $classObj->argBlockWidth() / 2 + $blockCordStart['x'];
            $yPreStart = $classObj->argObjectHeight() + $blockCordStart['y'];

            $xStart = $blockCordEnd['x'] + $path_x_offset;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $path_y_offset - $path_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $xStart;
            $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $path_y_offset + $blockCordEnd['y'];

            $xPostEnd = $blockCordEnd['x'] + $classObj->argBlockWidth() / 2;
            $yPostEnd = $yEnd;

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_colour = $classObj->getPathcolour($path_no);

            imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
            imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
            imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);

            imagesetthickness($classObj->getResource(), 1);
        } else {
//altpath parts
            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xPreStart = $classObj->argBlockWidth() / 2 + $blockCordStart['x'];
            $yPreStart = $classObj->argObjectHeight() + $blockCordStart['y'];

            $xStart = $blockCordEnd['x'] + $path_x_offset;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $path_y_offset - $path_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $xStart;
            $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $path_y_offset + $blockCordEnd['y'] - 25;

            $xPostEnd = $blockCordEnd['x'] + $classObj->argBlockWidth() / 2;
            $yPostEnd = $yEnd;

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_colour = $classObj->getPathcolour($path_no);
//		$path_colour = $classObj->getPathcolour(5);	
//bob working on alt paths 
//$path_colour = $classObj->getPathcolour(5);
            $start = explode(":", $p_start_block);
            $end = explode(":", $p_end_block);
            /*
              dump_array($start);
              dump_array($end);
              echo $start[1]. "-".$end[1]."-".$start[0]."-".$end[0];
             */
            if ($start[1] > $end[1]) {

                //echo $start[1]. "-".$end[1]."-".$start[0]."-".$end[0];
                if ($start[0] >= $end[0]) {
                    imageline($classObj->getResource(), $xPreStart, $yPreStart, $xPreStart + 60, $yStart, $path_colour); //right
                    imageline($classObj->getResource(), $xPreStart + 60, $yPreStart, $xPreStart + 60, $yStart - 25, $path_colour); //up
                    imageline($classObj->getResource(), $xPreStart + 60, $yStart - 25, $xEnd, $yStart - 25, $path_colour);
                    imageline($classObj->getResource(), $xStart, $yStart - 25, $xEnd, $yEnd, $path_colour);   //left
                    imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour); //down	
                } else {
                    imageline($classObj->getResource(), $xPreStart, $yPreStart, $xPreStart + 60, $yStart, $path_colour); //right
                    imageline($classObj->getResource(), $xPreStart + 60, $yPreStart, $xPreStart + 60, $yStart - 25, $path_colour); //up
                    imageline($classObj->getResource(), $xPreStart + 60, $yStart - 25, $xEnd, $yStart - 25, $path_colour);
                    imageline($classObj->getResource(), $xStart, $yStart - 25, $xEnd, $yEnd, $path_colour);   //left
                    imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour); //down
                }

                //imageline($classObj->getResource(),$xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
                //imageline($classObj->getResource(),$xStart, $yStart, $xEnd, $yEnd, $path_colour);
                //imageline($classObj->getResource(),$xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);
            } else {

                //bob	if ( $path_no ) {
                if ($start[0] >= $end[0]) {
                    if ($start[1] == $end[1]) {
                        if ($yPreStart > $yPostEnd)
                            $yPreStart-=10;
                        else
                            $yPreStart+=10;
                        $yStart = $yPreStart;
                    }
                    imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
                    imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
                    imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);
                }
                else {


                    $yEnd-=25;
                    $yPostEnd = $yEnd;
                    imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
                    imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
                    imageline($classObj->getResource(), $xEnd, $yEnd, $xPostEnd, $yPostEnd, $path_colour);
                }

//}
            }
            //	imageline($classObj->getResource(),$xPreStart, $yStart, $xPreStart, $yStart+25, $path_colour);
            $xEnd = $xEnd - $path_x_offset + 30;
            $x1_arrow = $xEnd + 5;
            $x2_arrow = $xEnd + 10;
            $x3_arrow = $xEnd + 5;

            $y1_arrow = $yEnd + 4;
            $y2_arrow = $yEnd + 0;
            $y3_arrow = $yEnd - 4;

            $arrow_points = array(
                $x1_arrow, $y1_arrow,
                $x2_arrow, $y2_arrow,
                $x3_arrow, $y3_arrow
            );

            imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);



            imagesetthickness($classObj->getResource(), 1);
        }

        /* $coord = $p_start_block.' -> '.$p_end_block.' = '.$classObj->argMaxDepth().' --> '.$p_objectType;
          global $a;
          imagestring($classObj->getResource(), 5, 810, $a,$path_y_offset,$path_colour);
          $a = $a + 20; */
    }

    public function drawNewCrossLink($classObj, $p_pathinfo, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset, $outputType) {
//NEW GOTO
        global $process_flow_id;
//echo $p_pathinfo."<br/>";
        $pathinfo_arr = explode("~#~", $p_pathinfo);

        $pathinfo_start_arr = explode(":", $pathinfo_arr[0]);
        $pathinfo_end_arr = explode(":", $pathinfo_arr[1]);

        if ($pathinfo_start_arr[5] != 'OUT') {
            $tma = $pathinfo_end_arr;
            $pathinfo_end_arr = $pathinfo_start_arr;
            $pathinfo_start_arr = $tma;
        }


        $p_start_block = $pathinfo_start_arr[0] . ":" . $pathinfo_start_arr[1] . ":" . $pathinfo_start_arr[2] . ":" . $pathinfo_start_arr[3];
        $p_end_block = $pathinfo_end_arr[0] . ":" . $pathinfo_end_arr[1] . ":" . $pathinfo_end_arr[2] . ":" . $pathinfo_end_arr[3];

        $getPFdepth = $classObj->getPFdepth();

        $p_start_base_block = chr($getPFdepth - 1 + 64) . ":" . $pathinfo_start_arr[1] . ":" . $pathinfo_start_arr[2] . ":" . $pathinfo_start_arr[3];
        $p_end_base_block = chr($getPFdepth - 1 + 64) . ":" . $pathinfo_end_arr[1] . ":" . $pathinfo_end_arr[2] . ":" . $pathinfo_end_arr[3];

        $blockCordStart = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
        $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);
        $blockCordStartBase = ProcessBlock::getBlockCoordinates($classObj, $p_start_base_block);
        $blockCordEndBase = ProcessBlock::getBlockCoordinates($classObj, $p_end_base_block);

        /* 	dump_array($blockCordStartBase);
          dump_array($blockCordEndBase);
          echo "--------------------------------<br/>"; */

        $xStart = $blockCordStart['x'] + $classObj->argBlockWidth() / 2 + 15;
        $yStart = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $blockCordStart['y'];

        // base
        $xStartBase = $xStart;
        $yStartBase = $classObj->argObjectHeight() - $classObj->argObjectGap() + $blockCordStartBase['y'] + $p_y_offset;

        $xEndBase = $blockCordEndBase['x'] + $classObj->argBlockWidth() / 2 + 15;


        $xEnd = $xEndBase;
        $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $blockCordEnd['y'];

        if ($xStart > $xEnd) {
            $xStart = $xStart - 30;
            $xStartBase = $xStart;
        }

//bob altered to make go upwards
        if ($yStart > $yEnd)
            $p_block_pos = ord(strtoupper($pathinfo_start_arr[0])) - 65;
        else
            $p_block_pos = ord(strtoupper($pathinfo_end_arr[0])) - 64;
        $yStartBase = $classObj->argBlockHeight() * $p_block_pos + 5;


        if ($outputType == 'H')
            $yStartBase+=150;
        $yEndBase = $yStartBase;


        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

        $path_colour = $classObj->getPathcolour($blockCordStart['path_no']);

        imageline($classObj->getResource(), $xStart, $yStart, $xStart, $yStartBase, $path_colour);
        imageline($classObj->getResource(), $xStartBase, $yEndBase, $xEndBase, $yEndBase, $path_colour);
        imageline($classObj->getResource(), $xEndBase, $yEndBase, $xEnd, $yEnd, $path_colour);

//bob puts arrows in the correct places
        if ($yEnd > $yEndBase) {
            $y1_arrow = $yEnd - 25;
            $x1_arrow = $xEnd - 5;

            $x2_arrow = $xEnd + 5;
            $y2_arrow = $y1_arrow;
            $x3_arrow = $xEnd;
            $y3_arrow = $y1_arrow + 10;
        } else {


            $x1_arrow = $xEnd - 5;
            $y1_arrow = $yEnd + 30;
            $x2_arrow = $xEnd + 5;
            $y2_arrow = $y1_arrow;
            $x3_arrow = $xEnd;
            $y3_arrow = $y1_arrow - 10;
        }
        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);

        imagesetthickness($classObj->getResource(), 1);
    }

    public function drawStartAltLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset, $direction, $crossover = 0) {

        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;


        $xStart = $blockCordStart['x'];
        $yStart = $blockCordStart['y'];

        if ($blockCordStart['x'] < $blockCordEnd['x']) {
            $xStart1 = $xStart = $xStart + ($p_alt_path * 2);
        } else {
            $xStart1 = $xStart = $xStart - ($p_alt_path * 2);
        }


        $yStart1 = $blockCordStart['y'] + 25 + ($p_alt_path * 4) + $classObj->argObjectHeight() / 2;
        if ($blockCordEnd['y'] <= $blockCordStart['y'])
            $yStart1 = $yStart1 - $classObj->argBlockHeight();

        $yStart1-=10;

        if ($crossover == -1) {
            $yStart2 = $yStart1;
            $xStart2 = $xStart1 + $classObj->argBlockWidth() / 2;
            $yStart3 = $yStart2 - $classObj->argBlockHeight();
            $xStart3 = $xStart2;
        } else {
            $yStart2 = $yStart1;
            $xStart2 = $xStart1;
            $yStart3 = $yStart2;
            $xStart3 = $xStart2;
        }

        //$yStart1+=($classObj->argBlockHeight())*$crossover;



        if ($yStart3 < 2)
            $yStart3 = 2;

        $xEnd = $blockCordEnd['x'];
        $yEnd = $blockCordEnd['y'];

        $xEnd1 = $xEnd - (($classObj->argBlockWidth() - $classObj->argObjectWidth() - 20) / 2) * $direction;
        $yEnd1 = $yStart3;



        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());



        $path_colour = $classObj->getPathcolour($p_alt_path);

        $path_colour = $classObj->getPathcolour($p_alt_path);

        imageline($classObj->getResource(), $xStart, $yStart, $xStart1, $yStart1, $path_colour);
        imageline($classObj->getResource(), $xStart1, $yStart1, $xStart2, $yStart2, $path_colour);
        imageline($classObj->getResource(), $xStart2, $yStart2, $xStart3, $yStart3, $path_colour);
        imageline($classObj->getResource(), $xStart3, $yStart3, $xEnd1, $yEnd1, $path_colour);
        imageline($classObj->getResource(), $xEnd1, $yEnd1, $xEnd1, $yEnd, $path_colour);
        imageline($classObj->getResource(), $xEnd1, $yEnd, $xEnd, $yEnd, $path_colour);

        if ($direction == 1) {
            $x1_arrow = $xEnd;
            $y1_arrow = $yEnd;
            $x2_arrow = $xEnd - 5;
            $y2_arrow = $y1_arrow - 10;
            $x3_arrow = $xEnd - 5;
            $y3_arrow = $y1_arrow + 10;
        } else {


            $x1_arrow = $xEnd;
            $y1_arrow = $yEnd;
            $x2_arrow = $xEnd + 5;
            $y2_arrow = $y1_arrow - 10;
            $x3_arrow = $xEnd + 5;
            $y3_arrow = $y1_arrow + 10;
        }
        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);

        imagesetthickness($classObj->getResource(), 1);
    }

    public function drawStartCrossLink($classObj, $p_pathinfo, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset) {

        $pathinfo_arr = explode("~#~", $p_pathinfo);

        $pathinfo_start_arr = explode(":", $pathinfo_arr[0]);
        $pathinfo_end_arr = explode(":", $pathinfo_arr[1]);

        $p_start_block = $pathinfo_start_arr[0] . ":" . $pathinfo_start_arr[1] . ":" . $pathinfo_start_arr[2];
        $p_end_block = $pathinfo_end_arr[0] . ":" . $pathinfo_end_arr[1] . ":" . $pathinfo_end_arr[2];

        $blockCordStart = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
        $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

        /* dump_array($blockCordStartBase);
          dump_array($blockCordEndBase);
          echo "--------------------------------<br/>"; */

        $xStart = $blockCordStart['x'] + $classObj->argBlockWidth() / 2;

        switch ($blockCordEnd['path_no']) {
            case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                break;

            case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                break;

            case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                break;

            case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                break;
        }

        $yStart = $classObj->argObjectHeight() - $classObj->argObjectGap() + $blockCordStart['y'];

        // base
        $xStartBase = $blockCordEnd['x'] + $classObj->argBlockWidth() / 2 - $classObj->argObjectWidth() / 2 - 20;
//		$yStartBase 		= $yStart;

        $xEndBase = $xStartBase;
//		$yEndBase 			= $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height/2) + $blockCordEnd['y'];

        $xEnd = $xEndBase + 20;
        $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $blockCordEnd['y'];

        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

        //echo $xStartBase." ".$yStartBase."<br/>";

        $path_colour = $classObj->getPathcolour($blockCordEnd['path_no']);

//draws alt path starts
        if ($blockCordEnd['path_no']) {

            if ($yStart > $yEndBase) {

                imageline($classObj->getResource(), $xStart, $yStart, $xStart, $yEnd, $path_colour);
                imageline($classObj->getResource(), $xStart, $yEnd, $xEnd, $yEnd, $path_colour);
                //  imageline($classObj->getResource(),$xEndBase, $yEndBase, $xEnd, $yEnd, $path_colour);
            } else {
                imageline($classObj->getResource(), $xStart, $yStart, $xStart, $yEnd, $path_colour);
                //    imageline($classObj->getResource(),$xStartBase, $yStartBase, $xEndBase, $yEndBase, $path_colour);
                imageline($classObj->getResource(), $xStart, $yEnd, $xEnd, $yEnd, $path_colour);
            }
        }


        imagesetthickness($classObj->getResource(), 1);
    }

    public function drawNewExternalLink($classObj, $p_pathinfo, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge) {
//bob needs to fix
        global $process_flow_id;

        $pathinfo_arr = explode(":", $p_pathinfo);

        $p_start_block = $pathinfo_arr[0] . ":" . $pathinfo_arr[1] . ":" . $$pathinfo_arr[2] . ":" . $pathinfo_arr[3];
        $p_end_block = chr($classObj->getPFdepth() - 1 + 64) . ":" . $pathinfo_arr[1] . ":" . $pathinfo_arr[2] . ":" . $pathinfo_arr[3];

        $blockCordStart = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
        $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

        $path_no = $blockCordEnd['path_no'];

        /* dump_array($blockCordStart);
          dump_array($blockCordEnd);
          echo "--------------------------------<br/>"; */

        switch ($path_no) {
            case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                $path_y_offset = $classObj->argyOffsetMainPath();
                break;

            case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                $path_y_offset = $classObj->argyOffsetAltFirstPath();
                break;

            case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                $path_y_offset = $classObj->argyOffsetAltSecondPath();
                break;

            case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                $path_y_offset = $classObj->argyOffsetAltThirdPath();
                break;

            case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                $path_y_offset = $classObj->argyOffsetAltFourthPath();
                break;
        }

        $xStart = $blockCordStart['x'] + $classObj->argBlockWidth() / 2 + 28;
        $yStart = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $blockCordStart['y'] - 2 * $path_y_offset;



        $xEnd = $xStart;
        $yEnd = $classObj->argObjectHeight() - $classObj->argObjectGap() + ($p_height / 2) + $blockCordEnd['y'];

        if ($classObj->getOutType() == 'H') {
            //$yStart+=180;
            $yEnd +=240;
        }

        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());
        $path_no = 10;
        $path_colour = $classObj->getPathcolour($path_no);
        imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
        imagesetthickness($classObj->getResource(), 1);
//bob		imagestring($classObj->getResource(), 8, 10, 20,$p_pathinfo,$path_colour);
    }

    public function drawExternalLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge) {



        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;



        $xStart = $blockCordStart['x'];
        $yStart = $blockCordStart['y'];



        $xEnd = $xStart;
        $yEnd = $blockCordEnd['y'];



        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());
        $path_no = 10;
        $path_colour = $classObj->getPathcolour($path_no);
        imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);
        imagesetthickness($classObj->getResource(), 1);

        if ($p_lozenge == 2) {
            $y1_arrow = $yStart;
            $x1_arrow = $xStart;

            $x2_arrow = $xStart + 5;
            $y2_arrow = $y1_arrow + 10;
            $x3_arrow = $xStart - 5;
            $y3_arrow = $y1_arrow + 10;
        } else {


            $x1_arrow = $xEnd;
            $y1_arrow = $yEnd;
            $x2_arrow = $xEnd + 5;
            $y2_arrow = $y1_arrow - 10;
            $x3_arrow = $xEnd - 5;
            $y3_arrow = $y1_arrow - 10;
        }
        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
    }

    public function drawInternalLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge) {

        $offset = ($p_main_path * 3);
        $pos = $classObj->argpathNo() % 8;
        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;


        $yPreStart = $blockCordStart['y'];

        $diff = $blockCordStart['y'] - $blockCordEnd['y'];

        if ($blockCordStart['x'] < $blockCordEnd['x']) {
            $xPreStart = $blockCordStart['x'] + 25;
            $xStart = $xPreStart;
            $yStart = $yPreStart + $classObj->argObjectHeight() + $offset;
            if ($classObj->getOutType() == 'H')
                $xPostStart = $xStart + $classObj->argObjectWidth() - 130;
            else
                $xPostStart = $xStart + $classObj->argObjectWidth();
            $yPostStart = $yStart;
            $xPreEnd = $xPostStart;
            $yPreEnd = $blockCordEnd['y'] + $classObj->argObjectHeight() + $offset;
            $yEnd1 = $yPreEnd;
            $xEnd1 = $blockCordEnd['x'] - 21;
            $endpos = $classObj->getendpos();
            if ($endpos["x"] == $blockCordEnd["x"] && $endpos["y"] == $blockCordEnd["y"]) {
                $xEnd1+=45;
            }


            $yEnd = $yEnd1 - 20;
            //added for end stop
            if ($classObj->getOutType() == 'H' && $endpos["x"] == $blockCordEnd["x"] && $endpos["y"] == $blockCordEnd["y"])
                $yEnd-=50;

            $xEnd = $xEnd1;




            if ($diff * $diff < 20) {
                $yEnd1 = $yPreEnd = $yPostStart = $yStart;
            }




            $x1_arrow = $xEnd;
            $y1_arrow = $yEnd;
            $x2_arrow = $xEnd + 5;
            $y2_arrow = $y1_arrow + 10;
            $x3_arrow = $xEnd - 5;
            $y3_arrow = $y1_arrow + 10;
        } else {
            $xStart = $blockCordStart['x'] - 15;
            $xPreStart = $blockCordStart['x'] - 15;
            $yStart = $yPreStart - $classObj->argObjectHeight() - $offset + 4;
            if ($yStart < 1)
                $yStart = 4;
            $yPostStart = $yStart;
            if ($classObj->getOutType() == 'H')
                $xPostStart = $xStart - $classObj->argObjectWidth() + 120;
            else
                $xPostStart = $xStart - $classObj->argObjectWidth() + 7;
            $yPreEnd = $blockCordEnd['y'] - $classObj->argObjectHeight() / 2 - $offset - 8;
            if ($yPreEnd < 1) {
                $yPreEnd = 4;
                $yEnd1 = 0;
            } else
                $yEnd1 = $yPreEnd;

            $xPreEnd = $xPostStart;
            //$yEnd1= $yPreEnd;
            $xEnd1 = $blockCordEnd['x'] + 25 - $offset;

            if (($diff * $diff) < 20) {
                $yEnd1 = $yPreEnd = $yPostStart = $yStart;
            }

            $xEnd = $blockCordEnd['x'] + 25 - $offset;

            if ($classObj->getOutType() == 'H') {
                if ($blockCordStart['x'] < $blockCordEnd['x']) {
                    $yEnd = $blockCordEnd['y'] + 70;
                } else {
                    $yEnd = $blockCordEnd['y'] - 40;
                }
            } else
                $yEnd = $yEnd1 + 13 + $offset;

            if ($yEnd1 == 0)
                $yEnd = 14;
            $x1_arrow = $xEnd;
            $y1_arrow = $yEnd;
            $x2_arrow = $xEnd + 5;
            $y2_arrow = $y1_arrow - 10;
            $x3_arrow = $xEnd - 5;
            $y3_arrow = $y1_arrow - 10;
        }









        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

        $path_colour = $classObj->getPathcolour($pos);

        $classObj->addpathNo();
//$path_colour = $classObj->colours['goto_colour']
        //imageline($classObj->getResource(),$xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
        //imageline($classObj->getResource(),$xStart, $yStart, $xPostStart, $yPostStart, $path_colour);
        //imageline($classObj->getResource(), $xPostStart, $yPostStart,$xEnd, $yEnd, $path_colour);

        imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
        imageline($classObj->getResource(), $xStart, $yStart, $xPostStart, $yPostStart, $path_colour);
        imageline($classObj->getResource(), $xPostStart, $yPostStart, $xPreEnd, $yPreEnd, $path_colour);
        imageline($classObj->getResource(), $xPreEnd, $yPreEnd, $xEnd1, $yEnd1, $path_colour);
        imageline($classObj->getResource(), $xEnd1, $yEnd1, $xEnd, $yEnd, $path_colour);


        imagesetthickness($classObj->getResource(), 1);





        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
    }

    public function drawHorizontalLink($p_objectType, $classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_y_offset) {

        $blockCordStart = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
        $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

        //echo $p_objectType."<br/>";
        if ($p_objectType == 'INPROCESS' || $p_objectType == 'OUTPROCESS') {

            $blockCord = ProcessBlock::getBlockCoordinates($classObj, $p_start_block);
            $path_no = (int) $blockCord['path_no'];

            switch ($path_no) {
                case 0: $path_x_offset = $classObj->argxOffsetMainPath();
                    $path_y_offset = $classObj->argyOffsetMainPath();
                    break;

                case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
                    $path_y_offset = $classObj->argyOffsetAltFirstPath();
                    break;

                case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
                    $path_y_offset = $classObj->argyOffsetAltSecondPath();
                    break;

                case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
                    $path_y_offset = $classObj->argyOffsetAltThirdPath();
                    break;

                case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
                    $path_y_offset = $classObj->argyOffsetAltFourthPath();
                    break;
            }

            $xStart = $blockCordStart['x'] + $classObj->argBlockWidth() / 2 + 11;
            $yStart = $blockCordStart['y'] + $classObj->argObjectHeight() + $p_y_offset;

            $blockCordEnd = ProcessBlock::getBlockCoordinates($classObj, $p_end_block);

            $xEnd = $blockCordEnd['x'] + $classObj->argBlockWidth() / 2 + 11;
            $yEnd = $yStart;

            imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

            $path_no = 10;
            $path_colour = $classObj->getPathcolour($path_no);
            imageline($classObj->getResource(), $xStart, $yStart, $xEnd, $yEnd, $path_colour);

            imagesetthickness($classObj->getResource(), 1);
        }

        //$coord1 = $p_start_block.' -> '.$p_end_block.' = '.$classObj->argMaxDepth();
        //$coord2 = $xStart.','.$yStart.' -> '.$xEnd.','.$yEnd.' = '.$classObj->argMaxDepth();
        /* global $a;
          imagestring($classObj->getResource(), 5, 210, $a,$p_y_offset,$path_colour);
          $a = $a + 20; */
    }

    public function drawAltLink($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset, $direction = 1) {

        $path_no = (int) $p_alt_path;
        $path_colour = $classObj->getPathcolour($path_no);
        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;
        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());
        if ($blockCordStart['y'] == $blockCordEnd['y']) {
            $xStart = $blockCordStart['x'];
            $yStart = $blockCordStart['y'];
            $xEnd = $blockCordEnd['x'];
            $yEnd = $blockCordEnd['y'];
            imageline($classObj->getResource(), $xStart, $yStart, $xEnd + (60 * $direction), $yEnd, $path_colour);
        } else {
            $xPreStart = $blockCordStart['x'];
            $yPreStart = $blockCordStart['y'];

            $xStart = $blockCordStart['x'] + ($classObj->argBlockWidth() / 2 - ($p_width / 2) + 5) * $direction + $p_y_offset;
            $yStart = $blockCordStart['y'];


            $xPostStart = $xStart;
            $yPostStart = $blockCordEnd['y'];

            $xEnd = $blockCordEnd['x'];
            $yEnd = $blockCordEnd['y'];


            imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
            imageline($classObj->getResource(), $xStart, $yStart, $xPostStart, $yPostStart, $path_colour);

            imageline($classObj->getResource(), $xPostStart, $yPostStart, $xEnd, $yEnd, $path_colour);
            if ($p_lozenge == 'B') {

                imageline($classObj->getResource(), $xEnd, $yEnd, $xEnd + ($classObj->argObjectWidth() * direction), $yEnd, $path_colour);
            }
        }
        imagesetthickness($classObj->getResource(), 1);


        $x1_arrow = $xEnd;
        $y1_arrow = $yEnd;
        $x2_arrow = $xEnd - (5 * $direction);
        $y2_arrow = $y1_arrow + 10;
        $x3_arrow = $xEnd - (5 * $direction);
        $y3_arrow = $y1_arrow - 10;

        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
    }

    public function drawAltStop($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset) {

        $path_no = (int) $p_alt_path;
        $path_colour = $classObj->getPathcolour($path_no);
        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;


        $xPreStart = $blockCordStart['x'];
        $yPreStart = $blockCordStart['y'];

        $xStart = $blockCordStart['x'] + $classObj->argBlockWidth() / 2 - ($p_width / 2) + 5;
        $yStart = $blockCordStart['y'];


        $xPostStart = $xStart;
        /* 		if ($blockCordEnd['y']>$blockCordStart['y'])
          $yPostStart = $yStart+($p_y_offset+$classObj->argBlockHeight())/2 ;
          else
          $yPostStart = $yStart-($p_y_offset+$classObj->argBlockHeight())/2 ;
         */
        $yPostStart = $blockCordStart['y'] + 25 + ($p_alt_path * 4) + $classObj->argObjectHeight() / 2;
        if ($blockCordEnd['y'] < $blockCordStart['y'])
            $yPostStart = $yPostStart - $classObj->argBlockHeight();

        $yPostStart-=10;

        $xPreEnd = $blockCordEnd['x'] - 10;
        $yPreEnd = $yPostStart;

        $xEnd = $blockCordEnd['x'];
        $yEnd = $blockCordEnd['y'];



        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());



        imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
        imageline($classObj->getResource(), $xStart, $yStart, $xPostStart, $yPostStart, $path_colour);
        imageline($classObj->getResource(), $xPostStart, $yPostStart, $xPreEnd, $yPreEnd, $path_colour);
        imageline($classObj->getResource(), $xPreEnd, $yPreEnd, $xEnd, $yEnd, $path_colour);
        imagesetthickness($classObj->getResource(), 1);


        $x1_arrow = $xEnd;
        $y1_arrow = $yEnd;
        $x2_arrow = $xEnd - (5 * $direction);
        $y2_arrow = $y1_arrow + 10;
        $x3_arrow = $xEnd - (5 * $direction);
        $y3_arrow = $y1_arrow - 10;

        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
    }

    public function drawAltEnd($classObj, $p_start_block, $p_end_block, $p_width, $p_height, $p_main_path, $p_alt_path, $p_lozenge, $p_y_offset, $direction) {

        $path_no = (int) $p_alt_path;
        $path_colour = $classObj->getPathcolour($path_no);
        $blockCordStart = $p_start_block;
        $blockCordEnd = $p_end_block;


        $xPreStart = $blockCordStart['x'];
        $yPreStart = $blockCordStart['y'];

        $xStart = $p_y_offset + $blockCordStart['x'] + ($classObj->argBlockWidth() / 2 - ($p_width / 2) + 5) * $direction;
        $yStart = $blockCordStart['y'];


        $xPostStart = $xStart;




        //	if ($blockCordStart['y'] <$blockCordEnd['y'] )
        //		$yPostStart = $p_y_offset+$blockCordEnd['y']-($classObj->argBlockHeight()/2) ;
        //		else
        $yPostStart = $p_y_offset + $blockCordEnd['y'] + ($classObj->argBlockHeight() / 2);

        $yPostStart = $blockCordStart['y'] + 25 + ($p_alt_path * 4) + $classObj->argObjectHeight() / 2;
        if ($blockCordEnd['y'] < $blockCordStart['y'])
            $yPostStart = $yPostStart - $classObj->argBlockHeight();

        $yPostStart-=10;

        $xPreEnd = $blockCordEnd['x'] + 17 + ($p_y_offset);
        $yPreEnd = $yPostStart;

        $xEnd = $blockCordEnd['x'] + 17 + ($p_y_offset);
        if ($blockCordStart['y'] < $blockCordEnd['y'])
            $yEnd = $blockCordEnd['y'] - ($classObj->argObjectHeight() / 2);
        else
            $yEnd = $blockCordEnd['y'] + ($classObj->argObjectHeight() / 2);



        imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());



        imageline($classObj->getResource(), $xPreStart, $yPreStart, $xStart, $yStart, $path_colour);
        imageline($classObj->getResource(), $xStart, $yStart, $xPostStart, $yPostStart, $path_colour);
        imageline($classObj->getResource(), $xPostStart, $yPostStart, $xPreEnd, $yPreEnd, $path_colour);
        imageline($classObj->getResource(), $xPreEnd, $yPreEnd, $xEnd, $yEnd, $path_colour);
        imagesetthickness($classObj->getResource(), 1);


        $x1_arrow = $xEnd;
        $x2_arrow = $xEnd + 10;
        $x3_arrow = $xEnd - 10;


        if ($blockCordStart['y'] < $blockCordEnd['y']) {
            $y1_arrow = $yEnd;
            $y2_arrow = $y1_arrow - 5;
            $y3_arrow = $y1_arrow - 5;
        } else {
            $y1_arrow = $yEnd + 3;
            $y2_arrow = $y1_arrow + 5;
            $y3_arrow = $y1_arrow + 5;
        }


        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );

        imagefilledpolygon($classObj->getResource(), $arrow_points, 3, $path_colour);
    }

}

?>