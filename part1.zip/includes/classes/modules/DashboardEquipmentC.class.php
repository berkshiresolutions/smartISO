<?php
 /**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */
class DashboardEquipmentC extends DashboardParent
{

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {
		parent::__construct();
	}

	public function getImpactMeasures() {

		$sql = "SELECT * FROM %s.impact_measure
				ORDER BY sort ASC";

		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$impact_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $impact_data;

	}

	public function getIncidenceInvestigationData() {

		if ( $this->filter['selected_bu'] ) {

			$bu_list = $this->getAllBUs();
            
			
			$sql = "SELECT R.*,S.* FROM %s.maintenance_calibration_data R
				INNER JOIN %s.equipment S
				ON R.equipId = S.equipID
				WHERE jobType = 'C' AND archive is NULL";

			$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,$bu_list);
		} else {

			$sql = "SELECT * FROM %s.equipment_action";

			$psql = sprintf($sql,_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result_data;
	}
	
	public function setFilter($p_filter) {

		$this->filter = $p_filter;
	}

	public function setBlockRange($p_range) {

		$this->qtrsRange = $p_range;
	}

	public function getData() {
	
		$bu_list 	= array();
		$hlist 		= array();
		$dlist 		= array();

		$q1_sr 		= $this->qtrsRange['q1_sr'];
		$q1_er		= $this->qtrsRange['q1_er'];
		/*$q11_sr 	= $this->qtrsRange['q11_sr'];
		$q11_er 	= $this->qtrsRange['q11_er'];
		$q12_sr 	= $this->qtrsRange['q12_sr'];
		$q12_er 	= $this->qtrsRange['q12_er'];
		$q13_sr 	= $this->qtrsRange['q13_sr'];
		$q13_er	 	= $this->qtrsRange['q13_er'];*/
		$q2_sr 		= $this->qtrsRange['q2_sr'];
		$q2_er 		= $this->qtrsRange['q2_er'];
		$q3_sr 		= $this->qtrsRange['q3_sr'];
		$q3_er 		= $this->qtrsRange['q3_er'];
		$q4_sr 		= $this->qtrsRange['q4_sr'];
		$q4_er 		= $this->qtrsRange['q4_er'];
		$q5_sr 		= $this->qtrsRange['q5_sr'];
		$q5_er 		= $this->qtrsRange['q5_er'];
		$cqtr		= $this->qtrsRange['cqtr'];

		$data_action = $this->getIncidenceInvestigationData();

		if ($impact_measures) {

			foreach ( $impact_measures as $impact_measure_ele ) {
				$impact_measure_ele_name = explode("|",$impact_measure_ele['name']);
				$hlist[$impact_measure_ele['ID']] = trim($impact_measure_ele_name[0]);
			}
		}

		$objEquip			= SetupGeneric::useModule('Equipment');
		
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
$incidence_data = $objEquip->displayItems();

		// Action Object
		//dump_array($incidence_data);
		$actObj = new Action();
		$incidence = array();

		$buObj = SetupGeneric::useModule('organigram');

		foreach ( $data_action as $data ) {
		
		//$objModEquip		= new Equipment();
		//$equip_id	= (int) $element['equipID'];
			//$objModEquip->setEquipmentInfo($equip_id,array('equip_id'=>$equip_id));
			//$equip_mod_data = $objModEquip->displayClientDetailsByEquipId();
			//$result_maintenance_calibration	= $objModEquip->displayMaintenanceCalibrationData();
	//$periodicity_details = $objModEquip->getPeriodicityDates();
	
	//dump_array($periodicity_details['maintenanceDueDate']);

	//dump_array($data);
	
	$sql99 = sprintf("SELECT * FROM %s.equipments
						WHERE equipID =".$data['eID'],
						_DB_OBJ_FULL
						);

		$pStatement = $this->dbHand->prepare($sql99);
		$pStatement->execute();

		$action55 = $pStatement->fetch();
	$piec1 = explode("/",$data['caP']);
	 $che =  strlen($piec1[0]);
	  if($che == '1'){
	  
	  $piec1[0] = '0'.$piec1[0];
	  }
      
  $pending['date'] = $piec1[2].'-'.$piec1[0].'-'.$piec1[1];
 
 $piec2 = explode("/",$data['caD']);
	 $che1 =  strlen($piec2[0]);
	  if($che1 == '1'){
	  
	  $piec2[0] = '0'.$piec2[0];
	  }
      
  $done['date'] = $piec2[2].'-'.$piec2[0].'-'.$piec2[1];
 
  if($action55['archive'] == '0' || $action55['archive'] == ''){
 if($data['done'] == 'yes'){
 if ($done['date'] >= $q1_sr && $done['date'] < $q1_er ) {
								
										$incidence['q1']['D']++;
								
								} else if ($done['date'] >= $q2_sr && $done['date'] < $q2_er ) {
								
										$incidence['q2']['D']++;
									
								} else if ($done['date'] >= $q3_sr && $done['date'] < $q3_er ) {
									
										$incidence['q3']['D']++;
									
								} else if ($done['date'] >= $q4_sr && $done['date'] <= $q4_er ) {
									
										$incidence['q4']['D']++;
									
								} else if ( $done['date'] >= $q5_sr && $done['date'] < $q5_er ) {
									
										$incidence['q5']['D']++;
									
								}else if ($done['date'] < $q1_sr){
								
										$incidence['q6']['A']++;
								}
 
 
 }else{
 
 if ($pending['date'] >= $q1_sr && $pending['date'] < $q1_er ) {
								
										$incidence['q1']['P']++;
								
								} else if ($pending['date'] >= $q2_sr && $pending['date'] < $q2_er ) {
								
										$incidence['q2']['P']++;
									
								} else if ($pending['date'] >= $q3_sr && $pending['date'] < $q3_er ) {
									
										$incidence['q3']['P']++;
									
								} else if ($pending['date'] >= $q4_sr && $pending['date'] <= $q4_er ) {
									
										$incidence['q4']['P']++;
									
								} else if ( $pending['date'] >= $q5_sr && $pending['date'] < $q5_er ) {
									
										$incidence['q5']['P']++;
									
								}else if ($pending['date'] < $q1_sr){
								
										$incidence['q6']['A']++;
								}
 
 
 
 
 }
 //$q1_sr;
		
								
						
		}
}


			return array(
				'hlist' => $hlist,
				'dlist' => $dlist,
				'bu_list' => $bu_list,
				'section_data'=>$incidence
				);

	}

	public function getGraphData() {

		$grid_data 	= $this->getData();

		$dlist 		= $grid_data['dlist'];
		$hlist 		= $grid_data['hlist'];
		$ra 		= $grid_data['section_data'];
	//dump_array($ra);
		$graph = array();

		//foreach( $dlist as $d ) {
			//foreach( $hlist as $hk=>$hv ) {

				/*$ra[$d][$hk]['q1']['P'] = $ra[$d][$hk]['q2']['P'] = $ra[$d][$hk]['q3']['P'] = 10;
				$ra[$d][$hk]['q1']['D'] = $ra[$d][$hk]['q2']['D'] = $ra[$d][$hk]['q3']['D'] = 20;*/

					$graph['q1']['D'] += $ra['q1']['D'];;
				$graph['q2']['D'] +=  $ra['q2']['D'];;
				$graph['q3']['D'] +=  $ra['q3']['D'];;
				$graph['q4']['D'] +=  $ra['q4']['D'];;

				$graph['q5']['D'] += $ra['q1']['D'] +$ra['q2']['D'] + $ra['q3']['D'] + $ra['q4']['D'];

				$graph['q1']['P'] +=  $ra['q1']['P'];;
				$graph['q2']['P'] += $ra['q2']['P'];
				$graph['q3']['P'] += $ra['q3']['P'];
				$graph['q4']['P'] += $ra['q4']['P'];

				$graph['q5']['P'] += $ra['q1']['P'] +$ra['q2']['P'] + $ra['q3']['P'] + $ra['q4']['P'];
				
				$graph['q6']['A'] += $ra['q6']['A'];

			//}
		//}

		return $graph;
	}

}