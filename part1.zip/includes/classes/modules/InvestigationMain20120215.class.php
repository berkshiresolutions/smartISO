<?php
 /**
  $Id: InvestigationMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, November 04, 2010 8:32:17 AM>
  */
require_once "Investigation.int.php";
require_once "Action.class.php";

class InvestigationMain implements Investigation
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Investigation Id
	 *@access private
	 */
	private $investigationId;

	/**
	 *Property to hold Investigation Info
	 *@access private
	 */
	private $investigationInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing Investigation object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setInvestigationInfo($p_investigationId,$p_investigationInfo) {

		$this->investigationId		=	$p_investigationId;
		$this->investigationInfo	=	$p_investigationInfo;
	}

	/*
	 * This method is used to add new investigation
	 * incidence_id,reference,unique_reference
	 */
	public function addInvestigation() {

		$sql = sprintf("SELECT * FROM %s.investigation WHERE reference = '%s'",_DB_OBJ_FULL,$this->investigationInfo['reference']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->investigationInfo['reference']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {
			throw new ErrorException('Investigation with this Reference # already exists.');
		} else {

			$sql2 = sprintf("INSERT INTO %s.investigation (incID,reference,uniqueReference,archive,status,whoID)
											VALUES (%d,'%s','%s','0','0',%d)",_DB_OBJ_FULL,$this->investigationInfo['incidence_id'],
											$this->investigationInfo['reference'],$this->investigationInfo['unique_reference'],$this->investigationInfo['who_id']);
			$pStatement2 = $this->dbHand->prepare($sql2);


			/*$pStatement2->bindParam(1,$this->investigationInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->investigationInfo['reference']);
			$pStatement2->bindParam(3,$this->investigationInfo['unique_reference']);*/

			$pStatement2->execute();
			$this->investigationId = customLastInsertId( $this->dbHand,'investigation','ID');
		}
	}

	/*
	 * This method is used to edit an investigation
	 */
	public function editInvestigation() {

		$sql = sprintf("UPDATE %s.investigation
						SET whoID = %d
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->investigationInfo['who_id'],
						$this->investigationId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
	}

	/**
	 * This method is used to manage Incident Analysis
	 * incident_analysis,description
	 */

	public function manageIncidentAnalysis() {
		$sql2 = sprintf(" UPDATE %s.investigation SET incidentAnalysis = '%s',
										incidentAnalysisDescription = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->investigationInfo['incident_analysis'],$this->investigationInfo['description'],
										$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->investigationInfo['incident_analysis']);
		$pStatement2->bindParam(2,$this->investigationInfo['description']);
		$pStatement2->bindParam(3,$this->investigationId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage Immediate Causes
	 * immediate_causes,description
	 */

	public function manageImmediateCauses() {
		$sql2 = sprintf(" UPDATE %s.investigation SET immediateCauses = '%s',
										immediateCausesDescription = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->investigationInfo['immediate_causes'],$this->investigationInfo['description'],
										$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->investigationInfo['immediate_causes']);
		$pStatement2->bindParam(2,$this->investigationInfo['description']);
		$pStatement2->bindParam(3,$this->investigationId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage Basic Causes
	 * basic_causes,description
	 */

	public function manageBasicCauses() {
		$sql2 = sprintf(" UPDATE %s.investigation SET basicCauses = '%s',
										basicCausesDescription = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->investigationInfo['basic_causes'],$this->investigationInfo['description'],
										$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->investigationInfo['basic_causes']);
		$pStatement2->bindParam(2,$this->investigationInfo['description']);
		$pStatement2->bindParam(3,$this->investigationId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage Inadequacies
	 *
	 */

	public function manageInadequacies() {

		$this->resetInadequacies();

		$sql1 = "SELECT * FROM %s.investigation_inadequacies WHERE invID = %d AND section = '%s' AND inadequacyID = %d";

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->investigationId);
		$pStatement->bindParam(2,$this->investigationInfo['section']);*/

		if ( $this->investigationInfo['section_data'] ) {

			foreach ( $this->investigationInfo['section_data'] as $value ) {

				//$pStatement->bindParam(3,$value['inadequacy_id']);
				$sql = sprintf($sql1,_DB_OBJ_FULL,$this->investigationId,$this->investigationInfo['section'],$value['inadequacy_id']);

				$pStatement->execute();
				$result = $pStatement->fetch(PDO::FETCH_ASSOC);

				$this->inadequacyData	= array(
												'inadequacyId'=>$value['inadequacy_id'],
												'inadequacyValues'=>$value['selected_values'],
												'reason'=>$value['reason']
												);

				if ( $result ) {
					//update data
					$inadId		= $result['ID'];
					$this->updateInadequacy($inadId);
				} else {
					//add data
					$this->addInadequacy();
				}
			}
		}
	}

	private function resetInadequacies() {

		$sql = sprintf("UPDATE %s.investigation_inadequacies SET inadequacySelectedValues = NULL,inadequacyReason = NULL WHERE invID = %d AND section = '%s'",
					   _DB_OBJ_FULL,$this->investigationId,$this->investigationInfo['section']);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->investigationId);
		$pStatement->bindParam(2,$this->investigationInfo['section']);*/

		$pStatement->execute();

	}

	private function addInadequacy() {

		$sql = sprintf("INSERT INTO %s.investigation_inadequacies (invID,section,inadequacyID,inadequacySelectedValues,inadequacyReason)
													VALUES (%d,'%s',%d,'%s','%s') ",_DB_OBJ_FULL,$this->investigationId,
													$this->investigationInfo['section'],$this->inadequacyData['inadequacyId'],$this->inadequacyData['inadequacyValues'],
													$this->inadequacyData['reason']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->investigationId);
		$pStatement->bindParam(2,$this->investigationInfo['section']);

		$pStatement->bindParam(3,$this->inadequacyData['inadequacyId']);
		$pStatement->bindParam(4,$this->inadequacyData['inadequacyValues']);
		$pStatement->bindParam(5,$this->inadequacyData['reason']);*/

		$pStatement->execute();

	}

	private function addInadequacyDeprecated() {

		$sql = sprintf("INSERT INTO %s.investigation_inadequacies (invID,section,inadequacyID,inadequacySelectedValues,inadequacyReason)
													VALUES (%d,'%s',%d,'%s','%s')",_DB_OBJ_FULL,$this->investigationId,
													$this->investigationInfo['section'],$this->investigationInfo['inadequacy_id'],
													$this->investigationInfo['inadequacy_selected_values'],$this->investigationInfo['reason']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->investigationId);
		$pStatement->bindParam(2,$this->investigationInfo['section']);
		$pStatement->bindParam(3,$this->investigationInfo['inadequacy_id']);
		$pStatement->bindParam(4,$this->investigationInfo['inadequacy_selected_values']);
		$pStatement->bindParam(5,$this->investigationInfo['reason']);*/

		$pStatement->execute();
	}

	private function updateInadequacy($p_id) {

		$sql = sprintf("UPDATE %s.investigation_inadequacies SET inadequacySelectedValues = '%s',
														inadequacyReason = '%s'
													WHERE ID = $p_id",_DB_OBJ_FULL,$this->inadequacyData['inadequacyValues'],$this->inadequacyData['reason']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->inadequacyData['inadequacyValues']);
		$pStatement->bindParam(2,$this->inadequacyData['reason']);*/

		$pStatement->execute();

	}

	public function updateInadequacyDescription() {

		$sql2 = sprintf("UPDATE %s.investigation SET inadequacy".ucwords($this->investigationInfo['section'])."Description = '%s' WHERE ID = %d ",_DB_OBJ_FULL,
						$this->investigationInfo['section_description'],$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);
		/*$pStatement2->bindParam(1,$this->investigationInfo['section_description']);
		$pStatement2->bindParam(2,$this->investigationId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage action
	 * actions = array(array('action'=>'dfg','who'=>'gdfg','when'=>'gdfg','action_id'=>23),
	 * 					array('action'=>'dfg','who'=>'gdfg','when'=>'gdfg','action_id'=>23),
	 * 					array('action'=>'dfg','who'=>'gdfg','when'=>'gdfg','action_id'=>23));
	 */
	public function manageActions() {

		//dump_array($this->investigationInfo['actions']);
		//exit;

		if ( count($this->investigationInfo['actions']) ) {
			$action_ids = "";
			foreach( $this->investigationInfo['actions'] as $value ) {

				$this->actionData = array('module_name'=>'investigation','description'=>$value['action'],
								  'who'=>$value['who'],'whoAU'=>$value['whoAU'],'due_date'=>$value['when']);
				if ( $value['action_id'] ) {
					// do update
					$this->actionHandling->setActionDetails($value['action_id'],$this->actionData);

					$actTriggerObj = new ActionEditTriggers();
					$actTriggerObj->setActionTriggerDetails('investigation',$value['action_id'],$this->investigationId,array(
																											'new_who' => $value['who'],
																											'new_whoAU' => $value['whoAU']
																													 ));

					$actTriggerObj->beforeUpdateTrigger();

					// perform update information
					$this->actionHandling->updateAction();

					$actTriggerObj->afterUpdateTrigger();
					$actTriggerObj = null;

					$action_ids .= $value['action_id'].',';
				} else {
					// do add
					$this->actionHandling->setActionDetails(0,$this->actionData);
					$new_action_id = $this->actionHandling->addAction();
					$action_ids .= $new_action_id.',';
				}
			}

			$action_ids = rtrim($action_ids,',');
			$sql2 = sprintf(" UPDATE %s.investigation SET actionsID = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$action_ids,$this->investigationId);

			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$action_ids);
			$pStatement2->bindParam(2,$this->investigationId);*/

			$pStatement2->execute();
		}
	}

	/*
	 * This method is used to update investigation process
	 * process,is_risk
	 */
	public function manageProcess() {

		$sql2 = sprintf(" UPDATE %s.investigation SET processID = %d,
										isRiskValid = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->investigationInfo['process'],$this->investigationInfo['is_risk'],$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->investigationInfo['process']);
		$pStatement2->bindParam(2,$this->investigationInfo['is_risk']);
		$pStatement2->bindParam(3,$this->investigationId);*/

		$pStatement2->execute();
	}

	/*
	 * This method is used to delete an investigation
	 */
	public function deleteInvestigation() {}

	/*
	 * This method is used to archive an investigation record
	 */
	public function archiveInvestigation() {
		$sql2 = sprintf(" UPDATE %s.investigation SET archive = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$this->investigationInfo['archive'],$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->investigationInfo['archive']);
		$pStatement2->bindParam(2,$this->investigationId);*/

		$pStatement2->execute();
	}

	/*
	 * This method is used to completely delete an investigation record
	 */
	public function purgeInvestigation() {

		$rec_details = $this->viewInvestigationById();
		//dump_array($rec_details);
		$action_arr = explode(',',$rec_details['actionsID']);
		//dump_array($action_arr);

		if ( count($action_arr) ) {
			foreach ( $action_arr as $value ) {
				if ( $value != '' ) {
					$this->actionHandling->setActionDetails($value,"");
					$this->actionHandling->deleteAction();
				}
			}
		}

		$sql = sprintf("DELETE FROM %s.investigation_inadequacies WHERE invID = %d",_DB_OBJ_FULL,$this->investigationId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->investigationId);
		$pStatement->execute();

		$sql2 = sprintf("DELETE FROM %s.investigation WHERE ID = %d",_DB_OBJ_FULL,$this->investigationId);

		$pStatement2 = $this->dbHand->prepare($sql2);
		//$pStatement2->bindParam(1,$this->investigationId);
		$pStatement2->execute();
	}

	/**
	 * This method is used to get last insert id
	 */
	public function lastRecordId() {
		return $this->investigationId;
	}

	/*
	 * This method is used to view an investigation record
	 */
	public function viewInvestigationById() {

		$sql = sprintf("SELECT * FROM %s.investigation WHERE ID = %d",_DB_OBJ_FULL,$this->investigationId);
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->investigationId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet[0];
	}

	public function viewInvestigationByIncidence() {

		$sql = sprintf("SELECT * FROM %s.investigation WHERE incID = %d",_DB_OBJ_FULL,$this->investigationInfo['incidence_id']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->investigationInfo['incidence_id']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view investigation records
	 */
	public function viewInvestigations() {

		//$sql = sprintf("SELECT * FROM %s.investigation WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->investigationInfo['archive']);

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.investigation A
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'INVG'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->investigationInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->investigationInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view investigation records by log date
	 */
	public function viewInvestigationsByLogDate() {

		//$sql = sprintf("SELECT * FROM %s.investigation WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->investigationInfo['archive']);

		$date_range = '';

		if ( $this->investigationInfo['start_date'] != '--' &&  $this->investigationInfo['end_date'] != '--' && $this->investigationInfo['start_date'] != '' &&  $this->investigationInfo['end_date'] != '' ) {
			$date_range = " AND (dateTimestamp BETWEEN '".$this->investigationInfo['start_date']." 00:00:00.000' AND '".$this->investigationInfo['end_date']." 23:59:59.000') ";
			$join_type = 'INNER';
			$date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
		} else {
			$date_range = '';
			$join_type = 'LEFT OUTER';
			$date_timestamp_not_null = '';
		}

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.investigation A
				".$join_type." JOIN (
					SELECT recID,
						dateTimestamp,
						whoID as userID,
						reference as recordRef,
						role
					FROM %s.module_tracker
					WHERE module = 'INVG'
					AND action = 'add'
					".$date_timestamp_not_null."
				) B
				ON recordRef = reference
				WHERE A.archive = '%s'
				$date_range
				ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->investigationInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->investigationInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view investigation records
	 */
	public function viewInadequacies() {

		$sql = sprintf(" SELECT * FROM %s.investigation_inadequacies WHERE invID = %d AND section = '%s'",_DB_OBJ_FULL,$this->investigationId,
					   $this->investigationInfo['section']);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->investigationId);
		$pStatement->bindParam(2,$this->investigationInfo['section']);*/
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view action records
	 */
	public function viewActions() {

		$resultSet = $this->viewInvestigationById();

		$actions = $resultSet['actionsID'];

		if ( $actions != '' ) {
			$actions_id_arr = explode(',',$actions);
			if ( count($actions_id_arr) ) {
				$i=0;
				foreach( $actions_id_arr as $value ) {
					$this->actionHandling->setActionDetails($value,"");
					$action_data = $this->actionHandling->viewAction();
					if ( $action_data ) {
						$action_details[$i] = $this->actionHandling->viewAction();
						$action_details[$i]['action_id'] = $value;
						$i++;
					}
				}
				return $action_details;
			}
		}
	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('investigation');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('investigation');
		}

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT M.reference,I.buID,M.ID AS inc_id FROM %s.investigation M
												INNER JOIN %s.incidence I
													ON I.ID = M.incID
											WHERE M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' ",
											_DB_OBJ_FULL,_DB_OBJ_FULL,$search_value1,$search_value2,$search_value3,$search_value4);

				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$search_value1);
				$pStatement->bindParam(2,$search_value2);
				$pStatement->bindParam(3,$search_value3);
				$pStatement->bindParam(4,$search_value4);*/

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['buID'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['inc_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function addOutstandingAction() {

		$sql = sprintf("SELECT actionsID FROM %s.investigation WHERE ID = %d ",_DB_OBJ_FULL,$this->investigationId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->investigationId);
		$pStatement->execute();

		$improvements = $pStatement->fetchColumn();
		$new_improvements = $improvements.','.$this->investigationInfo['new_improvement'];

		$sql2 = sprintf("UPDATE %s.investigation SET actionsID = %d WHERE ID = %d ",_DB_OBJ_FULL,$new_improvements,$this->investigationId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_improvements);
		$pStatement2->bindParam(2,$this->investigationId);*/
		$pStatement2->execute();
	}

	protected function getNoOfInvestigations() {

		$sql = sprintf("SELECT I.* FROM %s.incidence I
									INNER JOIN investigation N
										ON N.incID = I.ID ",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
					$bu_id = $row['buID'];
					$date_time = $row['incidenceDateTime'];
					$year = substr($date_time,0,4);

					$result_set[$year][$bu_id]++;
			}

			return $result_set;
		}
	}

	public function updateStatus() {
		$sql = sprintf("UPDATE %s.investigation SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->investigationId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->investigationId);
		$pStatement->execute();

	}

	public function sendActionAlerts($p_record_id) {

		$this->investigationId = $p_record_id;

		$inv_details = $this->viewInvestigationById();

		$objIncidence		= new IncidenceMain();
		$objIncidence->setIncidenceInfo($inv_details['incID'],array());
		$incidenceData 		= $objIncidence->viewIncidenceById();
		$objIncidence 		= null;

		$record_data = $this->viewActions();

		if ( count($record_data) ) {

			$i = 0;
			foreach ( $record_data as $value ) {

				$email_data[$i]['reference']	 		= $inv_details['reference'];
				$email_data[$i]['summary']		 		= $value['actionDescription'];
				$email_data[$i]['due_date']		 		= format_date($value['dueDate']);
				$email_data[$i]['who']			 		= $value['who'];
				$email_data[$i]['whoAU']			 	= $value['whoAU'];
				$email_data[$i]['problem_description']	= $incidenceData['problemDescription'];

				$this->actionHandling->updateStatus($value['ID']);
				$i++;
			}
		}

		return $email_data;

	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$heading = array(array('refrence'=>'Reference #','inc_refrence'=>'Incidence Reference','bu'=>'Business Unit','who'=>'Who','When'=>'Incidence DAte/Time'));

		$objIncidence		= new IncidenceMain();
		$participantObj	 	= SetupGeneric::useModule('Participant');
		$objBusinessUnit	= SetupGeneric::useModule('Organigram');
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$this->setInvestigationInfo(1,array('archive'=>$archive_session));
		$investigationData = $this->viewInvestigations();

		if ( count($investigationData) ) {
			$i=0;
			foreach ($investigationData as $value ) {

				$record_id		= $value['ID'];
				$reference		= $value['reference'];
				$incidence_id	= $value['incID'];

				//get incidence data from db
				$objIncidence->setIncidenceInfo($incidence_id,"");
				$incidenceRecord = $objIncidence->viewIncidenceById();

				$incidence_ref			= $incidenceRecord['reference'];
				$business_id			= $incidenceRecord['buID'];
				$incidence_date_time	= format_datetime($incidenceRecord['incidenceDateTime']);

				//get business unit from db
				$objBusinessUnit	= SetupGeneric::useModule('Organigram');
				$objBusinessUnit->setItemInfo(array(
													'id'=>$business_id
													));
				$businessUnitData	= $objBusinessUnit->displayItemById();

				$business_unit	= $businessUnitData['buName'];

				$participant_id = $value['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];


				$result[$i]['ref'] = $reference;
				$result[$i]['inc_ref'] = $incidence_ref;
				$result[$i]['bu'] = $business_unit;
				$result[$i]['who'] = $participant_name;
				$result[$i]['when'] = $incidence_date_time;

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
		//return $heading;
	}

	/* function is used to send mail to manager of approved record */

	public function getActionTrackerEmailData($p_record_id) {

		$sql2 = sprintf("SELECT * FROM %s.investigation ",_DB_OBJ_FULL);
		$sql2 = $sql2." WHERE actionsID LIKE '".$p_record_id."' OR actionsID LIKE '%,".$p_record_id."' OR actionsID LIKE '".$p_record_id.",%' OR actionsID LIKE '%,".$p_record_id.",%' ";

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();
		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

		$incidence_id = $result[0]['incID'];

		$sql3 = sprintf("SELECT buID FROM %s.incidence ",_DB_OBJ_FULL);
		$sql3 = $sql3." WHERE ID = ".$incidence_id;

		$pStatement3 = $this->dbHand->prepare($sql3);
		$pStatement3->execute();
		$bu_id = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

		$business_id = $bu_id[0]['buID'];

		$email_data['bu_id']		 		= $business_id;
		$email_data['reference']		 	= $result[0]['reference'];
		$email_data['who_id']		 		= $result[0]['whoID'];

		return $email_data;

	}
}
?>