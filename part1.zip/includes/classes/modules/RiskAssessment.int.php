<?php
 /**
  $Id: RiskAssessment.int.php,v 3.25 Monday, November 01, 2010 9:30:59 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage risk assessmemt object
  *
  * This interface will declare the various methods performed
  * by risk assessment object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface RiskAssessmentInterface
{
	/*
	 * to set risk assessment information for performing various operations with an risk assessment object
	 */
	public function setRiskInfo($p_RiskAssessmentId,$p_RiskAssessmentInfo);

	/*
	 * This method is used to get list of process for risk assessment.
	 */
	public function getRiskAssessmentProcesses();

	/*
	 * This method is used to get list of steps by process
	 */
	public function getStepsByProcess();

	/*
	 * This method is used to get hazards by process step
	 */
	public function getHazardsByProcessStep();

	/*
	 * This method is used to add new hazard for a risk process assessment
	 */
	public function addHazardAssessment();

	/*
	 * This method is used to edit hazard for a risk process assessment
	 */
	public function editHazardAssessment();

	/*
	 * This method is used to view hazard assessment
	 */
	public function viewHazardAssessment();

}