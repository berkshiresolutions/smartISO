<?php
 /**
  $Id: ProcessObjectInterface.int.php,v 3.06 Monday, December 13, 2010 8:28:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Wednesday, October 20, 2010 3:00:48 PM>
  */

interface ProcessObjectInterface
{
	public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info);
}

class ProcessBlock
{
	public static function getBlockCoordinates($classObj,$p_block) {

		$p_block_arr		= explode(':',$p_block);
		$p_block_1 			= strtoupper($p_block_arr[0]);
		$p_block_2 			= (int) $p_block_arr[1];
		$path_no 			= (int) $p_block_arr[2];
		$process_no 		= (int) $p_block_arr[3];

		$p_block_2 			= $p_block_2 - 1;

		// 65 ASCII code for A
		$p_block_1_integer 	= ord($p_block_1) - 64;

		$alt_path_total = $classObj->argAltPathTotal();

		$block['x'] = ($classObj->argLineThickness()*2) + $classObj->argBusinessUnitColumnWidth() + ($p_block_2 * $classObj->argBlockWidth());

		if ( $alt_path_total == 0 ) {

			$block['y'] = ($p_block_1_integer-1) * ($classObj->argLineThickness() + $classObj->argBlockHeight()) + $classObj->argLineThickness();

		} else if ( $alt_path_total == 1 ) {

			if ( $path_no == $alt_path_total ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + $classObj->argLineThickness();
			} else {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			}

		} else if ( $alt_path_total == 2 ) {

			if ( $path_no == $alt_path_total ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + $alt_path_total * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else if ( $path_no == 1 ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + $classObj->argLineThickness();
			} else {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			}

		} else if ( $alt_path_total == 3 ) {

			if ( $path_no == $alt_path_total ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + $alt_path_total * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else if ( $path_no == 2 ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else if ( $path_no == 1 ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + $classObj->argLineThickness();
			} else {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($alt_path_total - 1) * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			}

		} else if ( $alt_path_total == 4 ) {

			if ( $path_no == $alt_path_total ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + $alt_path_total * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else if ( $path_no == 3 ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($alt_path_total - 1) * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else if ( $path_no == 2 ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($alt_path_total - 3) * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else if ( $path_no == 1 ) {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($alt_path_total - 4) * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			} else {
				$block['y'] = ($p_block_1_integer-1) * ($classObj->argBlockHeight() + $classObj->argLineThickness()) + ($alt_path_total - 2) * ($classObj->argObjectHeight() + $classObj->argObjectGap()) + $classObj->argLineThickness();
			}

		}

		$block['path_no'] = $path_no;

		if ( $classObj->argOutputType() == 'H' )  {
			$block['y'] = $classObj->argHeaderHeight() + $block['y'];
		}

		$block['step_level'] = $p_block_arr[1];
		$block['process_no'] = $process_no;

		return $block;
	}
}
?>