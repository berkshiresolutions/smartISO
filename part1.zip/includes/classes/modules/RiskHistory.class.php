<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class RiskHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $processId;
	
	private $subReference;

	public function __construct() {

	 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'risk';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId 	= $p_record_id;
	}
	

	public function setItemInfoAddn($p_process_id) {
		$this->processId 	= $p_process_id;
		
	}
	

	public function sendToHistory() {
	


		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _risk() {

		$tablename 				= 'risk';
		$tablename_historical 	= $tablename.'_historical';
		
			$sql7799 = sprintf("SELECT * FROM %s.risk
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql7799);
		$pStatement->execute();

		$data_t = $pStatement->fetch();
		
			$sql993 = sprintf("SELECT * FROM %s.actions
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$data_t['improvements']);

		$pStatement = $this->dbHand->prepare($sql993);
		$pStatement->execute();

		$action_pp = $pStatement->fetch();
		$sql999 = sprintf("SELECT done FROM %s.swimlane
						WHERE swimID = %d",
						_DB_OBJ_FULL,
						$this->processId);

		$pStatement = $this->dbHand->prepare($sql999);
		$pStatement->execute();

		$this->done = $pStatement->fetchColumn();
		
		if($action_pp['approveAU'] ||  $data_t['newAction'] == '2' || $this->done == '1'){
		
			$upd = sprintf("UPDATE %s.swimlane
					   SET subReference = subReference + 1
					    WHERE swimID = %d",
						_DB_OBJ_FULL,
						$this->processId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();

		$sql = sprintf("SELECT subReference FROM %s.swimlane
						WHERE swimID = %d",
						_DB_OBJ_FULL,
						$this->processId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$this->subReference = $pStatement->fetchColumn();
		
		
		
		
		
		
		

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (
						ID
						,processID
						,processStepID
						,hazardClassificationID
						,dseAssessment
						,hazardsID
						,secondaryHazardID
						,hazardSymbols
						,hazardSummary
						,controlAtSource
						,controlAlongPath
						,controlAtWorker
						,controlSymbols
						,controlSummary
						,likelihood1
						,impact1
						,riskRating1
						,riskRatingColor1
						,improvementAtSource
						,improvementAlongPath
						,improvementAtWorker
						,improvements
						,noImprovement
						,improvementReason
						,likelihood2
						,impact2
						,riskRating2
						,riskRatingColor2
						,timeTrouble
						,netImpact
						,priority
						,status
						,archive
						,whoID
						,buID
						,processReference
						,eliminateHazard
						,subReference
						,overrulereason
						,overwriteControl
						,improvement_d
					   )
						SELECT
						ID
						,processID
						,processStepID
						,hazardClassificationID
						,dseAssessment
						,hazardsID
						,secondaryHazardID
						,hazardSymbols
						,hazardSummary
						,controlAtSource
						,controlAlongPath
						,controlAtWorker
						,controlSymbols
						,controlSummary
						,likelihood1
						,impact1
						,riskRating1
						,riskRatingColor1
						,improvementAtSource
						,improvementAlongPath
						,improvementAtWorker
						,improvements
						,noImprovement
						,improvementReason
						,likelihood2
						,impact2
						,riskRating2
						,riskRatingColor2
						,timeTrouble
						,netImpact
						,priority
						,status
						,archive
						,whoID
						,buID
						,processReference
						,eliminateHazard
						,subReference
						,overrulereason
						,overwriteControl
						,improvement_d
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
		
		$sql77 = sprintf("SELECT * FROM %s.risk
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql77);
		$pStatement->execute();

		$data = $pStatement->fetch();
		//dump_array($data);
		$sql3 = sprintf("SELECT mainSubRef FROM %s.swimlane
						WHERE swimID = %d",
						_DB_OBJ_FULL,
						$this->processId);

		$pStatement = $this->dbHand->prepare($sql3);
		$pStatement->execute();

		$mainSubRef = $pStatement->fetchColumn();
		
		 $sql4 = sprintf("SELECT subRef FROM %s.swimlane_data
						WHERE ID =".$data['processStepID'],
						_DB_OBJ_FULL
						);

		$pStatement = $this->dbHand->prepare($sql4);
		$pStatement->execute();

		$subRef_2 = $pStatement->fetchColumn();
		
		
		$ref = $data['processReference'];
		if( $data['subReference'] == '0'){
		$sub = $data['subReference'];
		}else{
		$sub = $data['subReference'] - 1;
		}
		
		
		//$mainSubRef = $mainSubRef + 1;
		//$subRef_2 = $subRef_2 + 1;
		if($mainSubRef == ''){
		
			$mainSubRef  = '';
		}else{
		if($mainSubRef == '0'){
		$mainSubRef = 0;
		}else{
		$mainSubRef = $mainSubRef - 1;
		}
		
		}
		if($subRef_2 == ''){
		
			$subRef_2  = '';
		}else{
		if($subRef_2 == '0'){
		$subRef_2 = 0;
		}else{
		$subRef_2 = $subRef_2 - 1;
		}
		
		}
		 $upd1 = sprintf("UPDATE %s.".$tablename_historical."
					   SET mainRef = ".$mainSubRef."
					    WHERE processReference = '".$ref."' AND subReference = ".$sub." AND ID =".$data['ID']." AND processStepID = ".$data['processStepID'],
						_DB_OBJ_FULL
						);

		$pStatement2 = $this->dbHand->prepare($upd1);
		$pStatement2->execute();
		
		
		
		
		 $upd2 = sprintf("UPDATE %s.".$tablename_historical."
					   SET subRef = ".$subRef_2."
					    WHERE processReference = '".$ref."' AND subReference = ".$sub." AND ID =".$data['ID']." AND processStepID = ".$data['processStepID'],
						_DB_OBJ_FULL
						);

		$pStatement2 = $this->dbHand->prepare($upd2);
		$pStatement2->execute();
		
		$sql99 = sprintf("SELECT * FROM %s.actions
						WHERE ID = %d",
						_DB_OBJ_FULL,
						$data['improvements']);

		$pStatement = $this->dbHand->prepare($sql99);
		$pStatement->execute();

		$action = $pStatement->fetch();
		//dump_array($action);
		$upd3 = sprintf("UPDATE %s.".$tablename_historical."
					   SET active_revision = 1, aID = ".$action['ID'].",actionD = '".$action['actionDescription']."',whoA = ".$action['who'].",dueDate = '".$action['dueDate']."',whoAU = ".$action['whoAU'].",approveAU = ".$action['approveAU']."
					    WHERE processReference = '".$ref."' AND subReference = ".$sub." AND ID =".$data['ID']." AND processStepID = ".$data['processStepID'],
						_DB_OBJ_FULL
						);

		$pStatement2 = $this->dbHand->prepare($upd3);
		$pStatement2->execute();
		
		if($mainSubRef == '' || $mainSubRef == 'NULL'){
			$action1= 'Update';
			
		}else{
			$action1 = 'Update';
		}
		
		$sql47 = sprintf("SELECT descQues FROM %s.swimlane_data
						WHERE ID =".$data['processStepID'],
						_DB_OBJ_FULL
						);

		$pStatement = $this->dbHand->prepare($sql47);
		$pStatement->execute();

		$step_n = $pStatement->fetchColumn();
		
		//$action = $action.'.'.$step_n;
		$this->miscObj			= new Misc();
		if($mainSubRef || $mainSubRef == '0'){
		
		$mainSubRef = $mainSubRef + 1;
			$ref1 = $ref.'.'.$mainSubRef;
		$current_date_time = $this->miscObj->getCurDate().' '.$this->miscObj->getCurTime();
		$sql7 = sprintf("INSERT INTO %s.module_tracker (recID,module,action,dateTimestamp,reference,whoID,role,whereAction,hazards,hSummary,cPath,cWorker,cSummary,iSource,iPath,iWorker,iSummary) VALUES (".$data['processID'].",'risk_1','".$action1."','".$current_date_time."','".$ref1."',".$data['whoID'].",'0','".$step_n."','".$data['hazardClassificationID']."','".$data['hazardSummary']."','".$data['eliminateHazard']."','".$action['approveAU']."','".$data['improvement_d']."','".$data['processStepID']."','".$data['improvementAlongPath']."','".$data['improvementAtWorker']."','".$action['actionDescription']."')"
					   ,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql7);

		$pStatement->execute();
		
		}
		
		
		if($subRef_2 == '' || $subRef_2 == 'NULL'){
			$action2= 'Update';
			
		}else{
			$action2 = 'Update';
		}
		
		$this->miscObj			= new Misc();
		
		$ref2 = $ref.'.'.$subRef_2;
		$current_date_time = $this->miscObj->getCurDate().' '.$this->miscObj->getCurTime();
		
		$sql7 = sprintf("INSERT INTO %s.module_tracker (recID,module,action,dateTimestamp,reference,whoID,role,whereAction,hazards,hSummary,cPath,cWorker,cSummary,iSource,iPath,iWorker,iSummary) VALUES (".$data['processStepID'].",'risk_2','".$action2."','".$current_date_time."','".$ref2."',".$data['whoID'].",'0','".$step_n."','".$data['hazardClassificationID']."','".$data['hazardSummary']."','".$data['eliminateHazard']."','".$action['approveAU']."','".$data['improvement_d']."','".$data['improvementAtSource']."','".$data['improvementAlongPath']."','".$data['improvementAtWorker']."','".$action['actionDescription']."')"
					   ,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql7);

		$pStatement->execute();
		
	if($sub == '' || $sub == 'NULL'){
			$action3= 'Edit';
			
		}else{
			$action3 = 'Update';
		}
		
		$this->miscObj			= new Misc();
		
		$ref3 = $ref.'.'.$sub;
		$current_date_time = $this->miscObj->getCurDate().' '.$this->miscObj->getCurTime();
		
					   
		$sql7 = sprintf("INSERT INTO %s.module_tracker (recID,module,action,dateTimestamp,reference,whoID,role,whereAction,hazards,hSummary,cPath,cWorker,cSummary,iSource,iPath,iWorker,iSummary) VALUES (".$data['ID'].",'risk_3','".$action3."','".$current_date_time."','".$ref3."',".$data['whoID'].",'0','".$step_n."','".$data['hazardClassificationID']."','".$data['hazardSummary']."','".$data['eliminateHazard']."','".$action['approveAU']."','".$data['controlSummary']."','".$data['improvementAtSource']."','".$data['improvementAlongPath']."','".$data['improvementAtWorker']."','".$action['actionDescription']."')"
					   ,_DB_OBJ_FULL);
		

		$pStatement = $this->dbHand->prepare($sql7);

		$pStatement->execute();
		
		}

		
		
		
	
	}
}
?>