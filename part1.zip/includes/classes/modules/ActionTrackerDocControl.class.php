<?php
 /**
  $Id: ActionTrackerDocControl.class.php,v 3.84 Tuesday, January 18, 2011 5:47:30 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerDocControl extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;

	public function getPendingMeActions() {

		$this->sql_query = sprintf("SELECT * FROM %s.cms_documents
							WHERE status = 'U'
							AND buID != 0
							AND isArchive = 0",_DB_OBJ_FULL);

		return $this->getActionsByFilter();
	}

	private function getActionsByFilter() {

		$USER_ID = getLoggedInUserId();

		$p_callingMethod_arr 	= explode('::',$p_callingMethod);
		$calling_method 		= $p_callingMethod_arr[1];
		//echo $calling_method;

		$pStatement = $this->dbHand->prepare($this->sql_query);
		$pStatement->execute();

		$result =  $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($result);

		return $result;
	}
}