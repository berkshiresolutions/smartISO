<?php

/**
  $Id: Equipment.class.php,v 3.16 Monday, January 17, 2011 1:46:11 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Friday, December 17, 2010 4:27:41 PM>
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class Asset {
    /*
     * property to hold database object
     *
     * access private
     */

    private $dbHand;

    /*
     * property to hold equipment id
     *
     * @access private
     */
    private $assetId;

    /*
     * property to hold equipment info
     */
    private $assetInfo;
    private $lastRecordId;

    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
    }

    public function setAssetInfo($asset_id, $asset_info) {

        $this->assetId = $asset_id;
        $this->assetInfo = $asset_info;
    }

    public function addAsset() {

        $sql = "INSERT INTO %s.assestMangement
				(assest_c,assest_t,descp,loc,flag_v,ref,model,manufacturer,descriptionlink,owner,custodian,maintenance,calibration ,item_req,is_class,class,label,companyID,bu_owner)
				VALUES (%d, %d, '%s',%d,'%s', '%s', %d, %d, %d, %d, %d, %d, %d, %d,  '%s',%d,  '%s',  '%s',%d)";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo['asset_g'], $this->assetInfo['asset_t'], $this->assetInfo['description'], $this->assetInfo['location'], $this->assetInfo['flag'], $this->assetInfo['ref'], $this->assetInfo['asset_mod'], $this->assetInfo['asset_m'], $this->assetInfo['asset_d'], $this->assetInfo['who'], $this->assetInfo['custodian'], $this->assetInfo['maintenance_req'], $this->assetInfo['calib_req'], $this->assetInfo['item_req'], $this->assetInfo['is_class'], $this->assetInfo['asset_c'], $this->assetInfo['label'], $this->assetInfo['companyID'], $this->assetInfo['bu_owner']);

        $stmt = $this->dbHand->prepare($psql);

        $queryExecute = $stmt->execute();
		
		$lastId = customLastInsertId($this->dbHand, 'assestMangement', 'ID');
		return $lastId;
    }

    public function editAsset() {

        $sql = "update %s.assestMangement set assest_c=%d,assest_t=%d,descp='%s',loc=%d,flag_v='%s',model=%d,manufacturer=%d,descriptionlink=%d,owner=%d,custodian=%d,maintenance=%d,calibration=%d ,item_req=%d,is_class='%s',class=%d,label='%s',companyID='%s',bu_owner='%s' where id=%d";


        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo['asset_g'], $this->assetInfo['asset_t'], $this->assetInfo['description'], $this->assetInfo['location'], $this->assetInfo['flag'], $this->assetInfo['asset_mod'], $this->assetInfo['asset_m'], $this->assetInfo['asset_d'], $this->assetInfo['who'], $this->assetInfo['custodian'], $this->assetInfo['maintenance_req'], $this->assetInfo['calib_req'], $this->assetInfo['item_req'], $this->assetInfo['is_class'], $this->assetInfo['asset_c'], $this->assetInfo['label'], $this->assetInfo['companyID'], $this->assetInfo['bu_owner'],  $this->assetId);

        $stmt = $this->dbHand->prepare($psql);

        $queryExecute = $stmt->execute();
    }

    public function displayItemById() {

        $sql = "SELECT * FROM %s.assestMangement WHERE ID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetId);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function displayAsset() {

        $sql = sprintf("SELECT * FROM %s.assest_primary_classification", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getLastInsertedId() {
        return $this->lastRecordId;
    }

    public function displayItemsIndex($sort = 'ORDER BY ID DESC', $search = '') {
$this->vars['archive'] = (int) Session::getSessionField('ARCHIVE_RECORDS');
        if ($this->vars['archive']) {
            $sql = sprintf("SELECT M.*,P.primaryAssest,L.name,T.name as typename,C.secondaryAssest,MO.model,D.name as descript FROM %s.assestMangement M inner join %s.assest_Primary_classification P on M.assest_c=P.ID inner join %s.locationgram L on M.loc=L.locID  left join %s.asset_type T on M.assest_t=T.ID  left join %s.assest_classification C on T.cid=C.ID left join %s.asset_description D on M.descriptionlink=D.ID  left join %s.asset_model MO on D.modelid=MO.ID WHERE M.archive =  1 %s %s",  _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $search, $sort);
        } else {
            $sql = sprintf("SELECT M.*,P.primaryAssest,L.name,T.name as typename,C.secondaryAssest,MO.model,D.name as descript FROM %s.assestMangement M inner join %s.assest_Primary_classification P on M.assest_c=P.ID inner join %s.locationgram L on M.loc=L.locID  left join %s.asset_type T on M.assest_t=T.ID  left join %s.assest_classification C on T.cid=C.ID left join %s.asset_description D on M.descriptionlink=D.ID  left join %s.asset_model MO on D.modelid=MO.ID WHERE isNull(M.archive,0) = 0 %s %s",  _DB_OBJ_FULL, _DB_OBJ_FULL,  _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $search, $sort);
        }

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function displayEquipItems() {


        $sql = "SELECT * FROM %s.assestmangement WHERE assest_t = %d  and item_req=1 AND isnull(archive,0) = 0 ";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetId);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getTypeAssets() {
        $sql = sprintf("SELECT * FROM %s.asset_type where isnull(archive,0)=0 order by cast(name as varchar(200))", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getMaterialAssets($p_loc) {
        $sql = sprintf("SELECT * FROM %s.assestMangement where item_req=1 and loc=%d order by cast(descp as varchar(200))", _DB_OBJ_FULL, $p_loc);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $data) {
            $id = $data["assest_t"];

            $retArray[$id][] = $data;
        }

        return $retArray;
    }

    public function getMainteance() {

        $sql = "SELECT * FROM %s.mainteance_data where isnull(archive,0)=0";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $records = array();

        if (is_array($result)) {
            foreach ($result as $result_ele) {
                $records[$result_ele['ID']] = $result_ele;
            }
        }

        return $records;
    }

    public function getMainteancea() {

        $sql = "SELECT * FROM %s.mainteance_data where archive=1";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $records = array();

        if (is_array($result)) {
            foreach ($result as $result_ele) {
                $records[$result_ele['ID']] = $result_ele;
            }
        }

        return $records;
    }

    public function addMaintItem() {

        $sql = "INSERT INTO %s.mainteance_data (name) VALUES ( '%s')";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo["name"]);
        $stmt = $this->dbHand->prepare($psql);

        return $stmt->execute();
    }

    public function editMaintItem() {

        $sql = "UPDATE %s.mainteance_data SET name = '%s' WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo["name"], $this->assetId);
        $stmt = $this->dbHand->prepare($psql);


        return $stmt->execute();
    }

    public function getCalibration() {

        $sql = "SELECT * FROM %s.calibration_data where isnull(archive,0)=0";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $records = array();

        if (is_array($result)) {
            foreach ($result as $result_ele) {
                $records[$result_ele['ID']] = $result_ele;
            }
        }

        return $records;
    }

    public function getCalibrationa() {

        $sql = "SELECT * FROM %s.calibration_data where archive=1";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $records = array();

        if (is_array($result)) {
            foreach ($result as $result_ele) {
                $records[$result_ele['ID']] = $result_ele;
            }
        }

        return $records;
    }

    public function displayMaintById($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.mainteance_data WHERE ID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getMainteance1($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.mainteance_data WHERE ID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $records = array();

        if (is_array($result)) {
            foreach ($result as $result_ele) {
                $records[$result_ele['ID']] = $result_ele;
            }
        }

        return $result;
    }

    public function displayCalcById($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.calibration_data WHERE ID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function displayMaintCalData() {


        $sql = "SELECT * FROM %s.maintenance_calibration_data WHERE equipId = %d AND jobType = '%s'";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo['equip_id'], $this->assetInfo['job_type']);



        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getListingforExport() {

        $type = $_GET['type'];
        if ($type == 'cali') {

            return $this->getCaliExportData();
        } else if ($type == 'maint') {

            return $this->getMaintExportData();
        } else if ($type == 'assest') {

            return $this->getEquipementExportDataFull();
        } else {

            return $this->getEquipementExportData();
        }
    }

    public function getEquipementExportDataFull() {

        $objEquip = SetupGeneric::useModule('Equipment');
        $objOrg = SetupGeneric::useModule('Organigram');
        $objEquipClass = SetupGeneric::useModule('EquipmentClassification');
        $participantObj = SetupGeneric::useModule('Participant');
        $objModEquip = new Equipment();
        $miscObj = new Misc();
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        //$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
        $equipment_data = $this->displayItems1();
        
 //       dump_array($equipment_data);
   //     exit;
        $heading = array(array('Reference', 'Group', 'Category', 'Type', 'Manufacturer', 'Model', 'Description', 'Location', 'Label/Serial Number', 'Asset', 'Asset Link Code', 'Business Unit', 'Owner', 'Custodian', 'Classification', "Maintenance", " Calibration"));


        if (is_array($equipment_data)) {
            $k = 0;
            foreach ($equipment_data as $element) {

                $equip_id = (int) $element['equipID'];

                $objEquip->setItemInfo(array('id' => $element['assest_c']));
                $equip_class_data = $objEquip->displayItemById_c();
                $type = $objEquip->getEquipmentDetailById22($element['assest_t']);


                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $element['loc']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $loc = SetupGeneric::useModule('Locationgram');
                $bu_id = (int) $element['loc'];
                $loc->setItemInfo(array('id' => $bu_id));
                $loc1 = $loc->displayItemById();

                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $bu_id));
                $locdata = $locObj->displayItemById();


                $business_unit_arr = explode(",", $locdata['businessUnit']);

                $orgObj = SetupGeneric::useModule('Organigram');
                $data = $orgObj->getBusinessUnitsforSelectedIds($business_unit_arr);

                if ($data) {
                    $i = 0;
                    foreach ($data as $data_ele) {

                        $business_unit_list1[$i] = $data_ele['buName'];
                        $i++;
                    }
                }

                if (!$business_unit_list1 == '')
                    $business_unit_list = implode(",", $business_unit_list1);

                $bu_id = (int) $element['bu'];
                $objOrg->setItemInfo(array('id' => $bu_id));
                $business_unit_data = $objOrg->displayItemById();

                $bu_name = $business_unit_data['buName'] != '' ? $business_unit_data['buName'] : '-';

                //$result[$k] = array($element['ref'],$equip_class_data['primaryAssest'],"Category","Type",'Manufacturer','Model','Description', $loc1['name'],$element['descp'],$element['flag_v'],$business_unit_list,'Owner','Custodian','Classification',"Maintenance"," Calibration");
                $result[$k] = array('ID'=>$element['ID'],'Ref'=>$element['ref'],'Group'=> $element['primaryAssest'],'category'=> $element['secondaryAssest'], 'type'=>$element['typename'], 'Manufacturer'=>$element['companyName'],'Model'=> $element['model'],'descript'=> $element['descript'],'location'=> $loc1['name'],'label'=> $element['label'],'companyID'=> $element['companyID'],'descp'=> $element['descp'],'flag'=> $element['flag_v'],'bulist'=> $business_unit_list, 'Owner'=>$element['owner'], 'Custodian'=>$element['custodian'],'Maintenance'=> format_date($element['maintenanceDueDate']),'Calibration'=> format_date($element['calibrationDueDate']));
                 $k++;
            }

//dump_array($result);exit();
          //  $new_result = array_merge($heading, $result);
           // return $new_result;
            return $result;
        } else
            return array();
    }

    public function displayItems1() {
 $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        if ($archive_session ==1) {
                  $sql = sprintf("SELECT M.*,P.primaryAssest,L.name,T.name as typename,C.secondaryAssest,MO.model,D.name as descript FROM %s.assestMangement M inner join %s.assest_Primary_classification P on M.assest_c=P.ID inner join %s.locationgram L on M.loc=L.locID  left join %s.asset_type T on M.assest_t=T.ID  left join %s.assest_classification C on T.cid=C.ID left join %s.asset_description D on M.descriptionlink=D.ID  left join %s.asset_model MO on D.modelid=MO.ID WHERE M.archive = 1 order by P.ID",  _DB_OBJ_FULL, _DB_OBJ_FULL,  _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
 
          //  $sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive = '%s' ORDER BY assest_c ASC", _DB_OBJ_FULL, $this->vars['archive']);
        } else {
               $sql = sprintf("SELECT M.*,P.primaryAssest,L.name,T.name as typename,C.secondaryAssest,MO.model,MA.companyName,P1.forename +' '+ P1.surname as owner,P2.forename +' '+ P2.surname as custodian, D.name as descript FROM %s.assestMangement M inner join %s.assest_Primary_classification P on M.assest_c=P.ID inner join %s.locationgram L on M.loc=L.locID  left join %s.asset_type T on M.assest_t=T.ID  left join %s.assest_classification C on T.cid=C.ID left join %s.asset_description D on M.descriptionlink=D.ID  left join %s.asset_model MO on D.modelid=MO.ID left join %s.asset_manufacturer MA on D.manid=MA.ID left join %s.participant_database P1 on M.owner=P1.participantID left join %s.participant_database P2 on M.custodian=P2.participantID WHERE isNull(M.archive,0) = 0 order by P.ID",  _DB_OBJ_FULL, _DB_OBJ_FULL,  _DB_OBJ_FULL,  _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
 
        //    $sql = sprintf("SELECT * FROM %s.assestMangement WHERE archive IS NULL OR archive = 0 ORDER BY assest_c ASC", _DB_OBJ_FULL);
        }
   
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function addCaliItem() {

        $sql = "INSERT INTO %s.calibration_data (name) VALUES ( '%s')";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo["name"]);
        $stmt = $this->dbHand->prepare($psql);

        return $stmt->execute();
    }

    public function editCaliItem() {

        $sql = "UPDATE %s.calibration_data SET name = '%s' WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->assetInfo["name"], $this->assetId);
        $stmt = $this->dbHand->prepare($psql);


        return $stmt->execute();
    }

    public function updateCali($id) {
        $sql = "UPDATE %s.calibration_data SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function updateMaint($id) {
        $sql = "UPDATE %s.mainteance_data SET archive = 1 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function restoreCali($id) {
        $sql = "UPDATE %s.calibration_data SET archive = 0 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function restoreMaint($id) {
        $sql = "UPDATE %s.mainteance_data SET archive = 0 WHERE ID = %d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $id);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        return 1;
    }

    public function getCaliExportData() {

        $heading = array(array(0 => 'Calibration'));


        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        if ($archive_session == '0') {
            $result = $this->getCalibration();
        } else {
            $result = $this->getCalibrationa();
        }
        if (is_array($result)) {

            foreach ($result as $key => $value) {


                $sl_id = $value['ID'];

                $resulta[$sl_id][0] = str_replace(',', ' ', $value['name']);
            }

            $result_new = array_merge($heading, $resulta);
        } else {

            $result_new = $heading;
        }


        return $result_new;
    }

    public function getMaintExportData() {

        $heading = array(array(0 => 'Maintenance'));


        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        if ($archive_session == '0') {

            $result = $this->getMainteance();  //moved to assets
        } else {
            $result = $this->getMainteancea();  //moved to assets
        }
        if (is_array($result)) {

            foreach ($result as $key => $value) {


                $sl_id = $value['ID'];

                $resulta[$sl_id][0] = str_replace(',', ' ', $value['name']);
            }

            $result_new = array_merge($heading, $resulta);
        } else {

            $result_new = $heading;
        }


        return $result_new;
    }
    public function getMaintDueDate() {
        $sql =  "select equipId,duedate,jobtype from %s.maintenance_calibration_data";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $records = array();

        if (is_array($result)) {
            foreach ($result as $row) {
                $records[$row['jobtype']][$row['equipId']] = $row['duedate'];
            }
        }
        return $records;
    }
    
       public function getTrainingAssets() {

$flag='%TRG%';
        $sql = "SELECT * FROM %s.assestmangement WHERE flag_v like '%s' and isnull(archive,0) = 0 ";

      $psql = sprintf($sql, _DB_OBJ_FULL, $flag);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
}

?>