<?php
 /**
  $Id: Organigram.int.php,v 3.16 Monday, September 13, 2010 5:30:24 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface OrganigramInterface
{
	/*
	 * This method is used to get information regarding post for a business unit in an organigram.
	 */
	public function getBusinessUnitPostInfo();

	/*
	 * This method is used to get information regarding audit for a business unit in an organigram.
	 */
	public function getBusinessUnitAuditInfo();

	/*
	 * This method is used to get list of business units for organigram.
	 */
	public function getBusinessUnitsHierarchy();

	/*
	 * This method is used to draw hierarchy of the organisation.
	 */
	public function drawOrganigram();

}