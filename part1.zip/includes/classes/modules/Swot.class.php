<?php
 /**
  $Id: Swot.class.php,v 3.17 Tuesday, February 01, 2011 4:26:12 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 2:58:08 PM>
  */

class Swot
{
	private $img;
	private $canvasWidth;
	private $canvasHeight;
	private $text_color ;
	private $fontFile;
	private $fontFile_2;
	private $fontFile_3;
	
public function __construct() {

		$this->canvasWidth					= 1000; // in px
		$this->canvasHeight					= 1000; // in px
		$this->fontFile 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arialbd.ttf';
		$this->fontFile_2 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arial.ttf';
		$this->fontFile_3 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/ariblk.ttf';

	}	

public function drawCanvas() {

$this->img = imagecreatetruecolor(1100, 1100)
or die('Cannot Initialize new GD image stream');
$bg_color = imagecolorallocate($this->img, 255,255, 255);
$red_color = imagecolorallocate($this->img, 178,0, 40);
$orange_color = imagecolorallocate($this->img, 255,165, 0);
$green_color = imagecolorallocate($this->img, 50,175, 50);
$blue_color = imagecolorallocate($this->img, 0,0, 210);
$this->text_color = imagecolorallocate($this->img, 0,0, 0);

imagefill($this->img, 0, 0, $bg_color );
imagefilledrectangle($this->img, 50, 50,1050,1050, $red_color);
imagefilledellipse($this->img, 550, 550, 900, 900, $orange_color);
imagefilledellipse($this->img, 550, 550, 500, 500, $green_color);
imagesetthickness($this->img, 2);
imagerectangle($this->img, 50, 50, 540, 540, $blue_color);
imagerectangle($this->img, 560, 50, 1050, 540, $blue_color);
imagerectangle($this->img, 50, 560, 540, 1050, $blue_color);
imagerectangle($this->img, 560, 560, 1050, 1050, $blue_color);
$style = array($blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $blue_color, $bg_color, $bg_color);
imagesetstyle($this->img, $style);
imageline($this->img, 50, 50, 530, 530, IMG_COLOR_STYLED);
imageline($this->img,50, 1050, 530, 570, IMG_COLOR_STYLED);
imageline($this->img, 1050, 50, 570, 530, IMG_COLOR_STYLED);
imageline($this->img,1050, 1050, 570, 570, IMG_COLOR_STYLED);
//arrows
imageline($this->img,573, 582, 570, 570, $blue_color);
imageline($this->img,582, 573,570, 570, $blue_color);
imageline($this->img, 573,518, 570, 530, $blue_color);
imageline($this->img, 582,527, 570, 530, $blue_color);
imageline($this->img,518, 527, 530, 530, $blue_color);
imageline($this->img,527, 518,530, 530, $blue_color);
imageline($this->img, 527,582, 530, 570, $blue_color);
imageline($this->img, 518,573, 530, 570, $blue_color);

//text

$text = 'Strengths';
imagettftext($this->img, 14, 0, 75, 68, $this->text_color, $this->fontFile , $text);
$text = 'Maximise';
imagettftext($this->img, 12, -45, 65, 90, $this->text_color, $this->fontFile , $text);
$text = 'Weaknesses';
imagettftext($this->img, 14, 0, 915, 68, $this->text_color, $this->fontFile , $text);
$text = 'Minimise';
imagettftext($this->img, 12, 45, 995, 135, $this->text_color, $this->fontFile , $text);
$text = 'Opportunites';
imagettftext($this->img, 14, 0, 85, 1038, $this->text_color, $this->fontFile , $text);
$text = 'Manipulate';
imagettftext($this->img, 12, 45, 75, 1005, $this->text_color, $this->fontFile , $text);
$text = 'Threats';
imagettftext($this->img, 14, 0, 945, 1038, $this->text_color, $this->fontFile , $text);
$text = 'Mitigate';
imagettftext($this->img, 12, -45, 985, 970, $this->text_color, $this->fontFile , $text);
	}

public function showImage() {
header ('Content-Type: image/png');

imagepng($this->img);

	}

}
?>