<?php
 /**
  $Id: ReviewGap.class.php,v 7.91 Saturday, January 29, 2011 12:13:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Review object used to manage operation related to review
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, September 13, 2010 5:30:32 PM>
  */

class ReviewGapBob
{

	/*
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/*
	 * This property will hold the value of ID of gap review under process.
	 * @access private
	 */
	private $reviewID;

	private $request_for;
	private $question_index;
	private $question_identifier;
	private $participant_id;
	private $gap_data;

	public function __construct() {

		$this->dbHand = DB::connect(_DB_TYPE);
		$this->reviewID = Session::getSessionField('review_id');
	}

	public function getQuestionList() {

		$standardID = 7;

		$sql = sprintf("SELECT questionID FROM %s.review_answers
				WHERE reviewID = %d
				AND standardID = %d
				AND answer IN ('NA','100')"
				,_DB_OBJ_FULL
				,$this->reviewID
				,$standardID);


		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$this->reviewID);
		$stmt->bindParam(1,$r,PDO::PARAM_INT);
		$stmt->bindParam(2,$standardID);*/
		$stmt->execute();

		$nongap_question_arr = array();

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$nongap_question_arr[] = $rec['questionID'];
		}

		$sql = sprintf("SELECT questions
				FROM %s.review_master
				WHERE reviewID = %d",_DB_OBJ_FULL,$this->reviewID);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$this->reviewID);
		//$stmt->bindParam(1,$r,PDO::PARAM_INT);
		$stmt->execute();

		$rec = $stmt->fetch(PDO::FETCH_ASSOC);
		$questions = explode(',',$rec['questions']);
		$questionsCount = count($questions);

		$questionList = array();

		$m = 1;

		for ($i=0;$i<$questionsCount;$i++) {
			$k = $i + 1;

			if ( !in_array($questions[$i],$nongap_question_arr) ) {
				$questionList[$m++] = $questions[$i];
			}
		} // end for

		return $questionList;
	}

	public function setGapAnswerInfo($p_questionIndex,$p_questionIdentifier,$participant_id, $p_data_arr) {

		$this->question_index			= (int) strip_tags($p_questionIndex);
		$this->question_identifier		= (int) strip_tags($p_questionIdentifier);
		$this->participant_id			= (int) strip_tags($participant_id);
		$this->gap_data					= $p_data_arr;
	}

	public function getQuestionInfo($p_questionIdentifier) {

		$p_questionIdentifier = (int) $p_questionIdentifier;

		$sql = sprintf("SELECT * FROM %s.review_questions
				WHERE ID = %d",_DB_OBJ_FULL,$p_questionIdentifier);

		$sql_sec = sprintf("SELECT standardID,code FROM %s.review_question_metadata
				WHERE questionID = %d",_DB_OBJ_FULL,$p_questionIdentifier);

		$stmt_sec = $this->dbHand->prepare($sql_sec);
		//$stmt_sec->bindParam(1,$p_questionIdentifier);
		$stmt_sec->execute();

		$std_arr = array();

		while ( $rec = $stmt_sec->fetch(PDO::FETCH_ASSOC) ) {

			$code_title			= ucfirst($code_stats['title']);
			$code_description 	= ucfirst($code_stats['description']);

			/* hardcoding done to avoid extra query to database. */
			if ( $rec['standardID'] == 7 ) {
				$std_arr['section_heading_code'] 	= substr($rec['code'],0,1);
				$std_arr['section_heading'] 		= $this->getMsrCodeHeading($std_arr['section_heading_code']);
			}

			// 11 for cms 9k
			if ( $rec['standardID'] == 11 ) {
				$std_arr['section_code'] 			= $rec['code'];
			}

			if ( $code_description == '' ) {
				$std_arr['standard_'.$rec['standardID']] = 'Not Available';
			} else {
				$std_arr['standard_'.$rec['standardID']] = $code_description;
			}
		}

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_questionIdentifier);
		$stmt->execute();

		return array_merge($stmt->fetch(PDO::FETCH_ASSOC),$std_arr);
	}

	private function getMsrCodeHeading($p_code) {

		$sql = sprintf("SELECT description FROM %s.msr_departments
				WHERE SUBSTRING(code,1,1) = '%s'",_DB_OBJ_FULL,$p_code);

		$stmt_sec = $this->dbHand->prepare($sql);
		//$stmt_sec->bindParam(1,$p_code);
		$stmt_sec->execute();

		$rec = $stmt_sec->fetch(PDO::FETCH_ASSOC);

		return $rec['description'];
	}

	public function getGapAnswerInfo($p_questionIdentifier) {

		$p_questionIdentifier = (int) $p_questionIdentifier;
		$standardID = 7;

		$sql = sprintf("SELECT questionId,answer,recommendation,standardID,	fullname FROM %s.review_answers R INNER JOIN %s.quality_standards Q
				ON Q.sID = R.standardID WHERE questionID = %d AND reviewID = %d AND standardID = %d"
				,_DB_OBJ_FULL
				,_DB_OBJ_FULL
				,$p_questionIdentifier
				,$this->reviewID
				,$standardID);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$p_questionIdentifier);
		$stmt->bindParam(2,$this->reviewID);
		$stmt->bindParam(3,$standardID);*/
		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	public function getDocumentType() {

		$sql = sprintf("SELECT ID,docTypeName FROM %s.question_docs_type
				ORDER BY sort ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$document_types = array();

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$document_types[$rec['ID']] = $rec['docTypeName'];
		}

		return $document_types;
	}

	public function getDocuments($p_questionID) {

		$sql = sprintf("SELECT documentID FROM %s.question_docs_mapping
				WHERE questionID = %d",_DB_OBJ_FULL,$p_questionID);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_questionID);
		$stmt->execute();

		$documents = array();

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$documentList[] = $rec['documentID'];
		}

		$documentList = implode("','",$documentList);

		$documentList = "IN ('".$documentList."')";

		$sql = sprintf("SELECT Q.ID,typeID,docTypeName,displayName,filename,opAmSv
				FROM %s.question_docs_type D
				INNER JOIN
				(SELECT * FROM %s.question_docs WHERE ID $documentList ) Q
				ON Q.typeID = D.ID",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$stmt_sec = $this->dbHand->prepare($sql);
		$stmt_sec->execute();

		$documents = null;

		while ( $rec = $stmt_sec->fetch(PDO::FETCH_ASSOC) ) {
			$documents[$rec['docTypeName']][] = $rec;
		}

		return $documents;
	}

	public function getGapInformation($p_questionId,$p_documentId) {

		$standardID = 7;

		$sql = sprintf("SELECT whenDate,participantID,description,siconaOption FROM %s.review_gap_question R
				LEFT OUTER JOIN %s.review_gap_docs_viewed V
				ON
					(R.reviewID = V.reviewID AND R.documentID = V.documentID)
				WHERE R.reviewID  = %d
				AND R.standardID  = %d
				AND R.documentID  = %d"
				,_DB_OBJ_FULL
				,_DB_OBJ_FULL
				,$this->reviewID
				,$standardID
				,$p_documentId);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_questionId,PDO::PARAM_INT);
		/*$stmt->bindParam(1,$this->reviewID);
		$stmt->bindParam(2,$standardID);
		$stmt->bindParam(3,$p_documentId);*/
		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	
	

	public function getGapQuestionActionTracker($p_assignedToMe=true,$p_due_date='') {

		$level 		= getUserAccessLevel();

		if ( $level == 1 ) {
			if ( $p_assignedToMe ) {
				$filter = "participantID = %d";
			} else {
				$filter = "participantID != %d";
			}
		} else {
			$filter = "participantID = %d";
		}

		$c_filter = sprintf($filter,getLoggedInUserId());

		if ( $p_due_date != '' ) {
			$filter_date  = " AND whenDate <= '".$p_due_date."'";
		}

		$sql = sprintf("SELECT * FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description FROM %s.review_gap_question Q
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption = 'SI') V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID
				WHERE $c_filter $filter_date) D2
				ON D1.ID = D2.documentID",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}


	public function getGapTrackerRecord($p_auditId, $p_docId) {

		$sql = sprintf("SELECT questionID FROM %s.gap_tracker
				WHERE docID = %d
				AND reviewID = %d",_DB_OBJ_FULL,$p_docId,$p_auditId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_docId);
		$stmt->bindParam(2,$p_auditId);*/

		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$result_string = array();

		if ( $result ) {

			foreach ( $result as $resultEle ) {
				$result_string[] = $resultEle['questionID'];
			}
		}

		//return implode(',',$result_string);
		return $result_string;
	}

	// standard Id 11
	public function getDocumentCode($p_docID,$p_stdID=11) {

		if ( _DB_TYPE == 'mssql') {

			$sql = sprintf("SELECT TOP 1 code
				FROM %s.review_question_metadata
				WHERE questionID
				IN (
					SELECT questionID
					FROM %s.question_docs_mapping
					WHERE documentID = %d
				)
				AND standardID = %d
				ORDER BY questionID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_docID,$p_stdID);

		} else {

			$sql = sprintf("SELECT code
				FROM %s.review_question_metadata
				WHERE questionID
				IN (
					SELECT questionID
					FROM %s.question_docs_mapping
					WHERE documentID = %d
				)
				AND standardID = %d
				ORDER BY questionID ASC
				LIMIT 0,1",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_docID,$p_stdID);
		}

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_docID);
		$stmt->bindParam(2,$p_stdID);*/

		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result['code'];
	}

	public function getDocumentInfoByID($p_docID) {

		$sql = sprintf("SELECT * FROM %s.question_docs WHERE ID = %d",_DB_OBJ_FULL,$p_docID);

		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1,$p_docID);

		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	public function getQuestionGapInfoByReview($p_reviewID) {
//select * from review_gap_question where reviewID=306 and participantID >0 order by participantID
		$sql = sprintf("SELECT * FROM %s.review_gap_question WHERE participantID >0 and reviewID = %d ",_DB_OBJ_FULL,$p_reviewID);

		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1,$p_docID);

		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);

	}
}
?>