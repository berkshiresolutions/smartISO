<?php
 /**
  $Id: ReviewGraph.class.php,v 3.08 Tuesday, January 11, 2011 12:22:12 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Review Graph
  * @since  Friday, November 26, 2010 5:35:19 PM>
  */

class ReviewGraph
{

	/*
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $optionObj;

	public function __construct() {

		 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->optionObj = new Option();
	}

	public function getReviewdata($p_review_id,$p_std_id) {

		$sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE reviewID = %d ",_DB_OBJ_FULL,$p_review_id);

		$pStatement_rev = $this->dbHand->prepare($sql_rev);
		//$pStatement_rev->bindParam(1,$p_review_id);
		$pStatement_rev->execute();

		$records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($records_rev);
		if ( count($records_rev) ) {

			foreach ( $records_rev as $value ) {
				$answers[$value['questionID']] = $value;
			}
		}

		$standard = $p_std_id == '' ? 11 : $p_std_id;

		$sql = sprintf("SELECT * FROM %s.msr_departments WHERE sID = %d ORDER BY ID",_DB_OBJ_FULL,$standard);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$standard);
		$pStatement->execute();
		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($records);

		if (count($records) ) {
			foreach ( $records as $value ) {

				if ( $standard == 7 ) {

					$main_dep 	= $value['code'];
					$str 		= $value['code'].'%';
					$sql2 		= sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = %d AND code LIKE '%s' ORDER BY questionID ASC"
									,_DB_OBJ_FULL
									,$standard
									,$str);
				} else {

					$main_dep 	= $value['code'];
					$str 		= $value['code'];
					$sql2 		= sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = %d AND code = '%s' ORDER BY questionID ASC"
									,_DB_OBJ_FULL
									,$standard
									,$str);
				}

				$codes_name[$value['code']] = $value['name'];


				$pStatement2 = $this->dbHand->prepare($sql2);

				/*$pStatement2->bindParam(1,$standard);
				$pStatement2->bindParam(2,$str);*/

				$pStatement2->execute();
				$records2 = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

				$main_dep_arr = explode('.',$main_dep);
				$main_dep = $main_dep_arr[0];
				$main_dep = $codes_name[$main_dep];


				if ( count($records2) ) {

					$sql3 = sprintf("SELECT * FROM %s.review_questions WHERE ID = %d ORDER BY ID ASC",_DB_OBJ_FULL,$valueQues['questionID']);
					$pStatement3 = $this->dbHand->prepare($sql3);

					foreach ( $records2 as $valueQues ) {

						//$pStatement3->bindParam(1,$valueQues['questionID']);
						$pStatement3->execute();
						$records3 = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

						//dump_array($records3);

						$question_id = $records3[0]['ID'];

						$answer = $answers[$question_id]['answer'] == '' ? '0' : $answers[$question_id]['answer'];
						$answer = $answer == 'NA' ? '0' : $answer;
							$answer = $answer == 'na' ? '0' : $answer;

						switch($answer) {
							case 0 : $option = 1; break;
							case 20 : $option = 2; break;
							case 80 : $option = 3; break;
							case 100 : $option = 4; break;
						}

						$option_score =  $this->optionObj->getOption('_SU_REVIEW_OPTION'.$option.'_PERCENT');

						$score = ($records3[0]['score']*$option_score)/100;

						//echo $records3[0]['score'].' - '.$option_score.'-'.$score.'<br/>';

						if ( $records3[0]['isStowContractor'] == 1 ) {
							$question['Key Questions']['answered_score'] += $score;
							$question['Key Questions']['actual_score'] += $records3[0]['score'];

						} else {

							$question[$main_dep]['answered_score'] += $score;
							$question[$main_dep]['actual_score'] += $records3[0]['score'];
						}



					}
				}

			}

			//dump_array($question);
			return $question;
		}
	}

}
?>