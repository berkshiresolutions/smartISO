<?php

/**
  $Id: Comm.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, October 09, 2010 12:50:41 PM>
 */
require "Question.int.php";
require_once "Action.class.php";

class Question implements QuestionInterface {

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Comm Id
     * @access private
     */
    private $questId;

    /**
     * Property to hold Comm Info
     * @access private
     */
    private $questInfo;

    /**
     * Constructor for initializing Manual Handling object
     * @access public
     */
    public function __construct() {

       
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /**
     * to set comm information for performing various operations with the comm object
     * @param integer This parameter holds the comm Id
     * @param array This parameter holds the the comm Info
     */
    public function setQuestInfo($p_questId, $p_questInfo) {

        $this->questId = $p_questId;
        $this->questInfo = $p_questInfo;
    }

    public function addQuest() {

      $sql = sprintf("INSERT INTO %s.context ( reference,uniqueReference, title,descp,bu
										)
										VALUES ( '%s','%s','%s','%s','%s') ", _DB_OBJ_FULL, $this->questInfo['reference'], $this->questInfo['uniqueref'], $this->questInfo['title'], $this->questInfo['description'], $this->questInfo['bu']
        );

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();

        $this->questId = customLastInsertId($this->dbHand, 'context', 'ID');

        return $this->questId;
    }

    /*
     * This method is used to view comm information.
     */

    public function viewQuest($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.context WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    /*
     * This method is used to edit a comm
     */

    public function editQuest($id) {

       $sql = sprintf("UPDATE %s.context set title='%s',descp='%s',bu='%s'
										where id=%d
										", _DB_OBJ_FULL, $this->questInfo['title'], $this->questInfo['description'], $this->questInfo['bu'], $id
        );

        $pStatement = $this->dbHand->prepare($sql);



        $pStatement->execute();
    }

    public function viewAll() {

       $sql = sprintf("SELECT * FROM %s.context  where isnull(complete,0)=0 and isnull(archive,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

	    public function viewClosedAll() {

        $sql = sprintf("SELECT * FROM %s.context  where complete=1 and isnull(archive,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
	
	    public function viewAllArchived() {

     $sql = sprintf("SELECT * FROM %s.context  where isnull(complete,0)=0 and archive=1 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

	    public function viewClosedAllArchived() {

        $sql = sprintf("SELECT * FROM %s.context  where complete=1 and archive =1 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
	
    public function lastrecordId() {
        return $this->questId;
    }

    public function archiveRecord() {
	
	$sql = sprintf("UPDATE %s.context SET archive = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->questId);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

	}

    public function restoreRecord() {
       	$sql = sprintf("UPDATE %s.context SET archive = '0' WHERE ID = %d ",_DB_OBJ_FULL,$this->questId);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute(); 
    }

    public function viewcontextaction($id, $name) {
        $this->id = $id;
        $this->name = $name;
       $sql = sprintf("SELECT * FROM context_action C left join actions A on c.actionID=A.ID WHERE C.c_id = %d AND name ='%s' ", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->id, $this->name);

//	 	$sql = sprintf("SELECT * FROM %s.context_action WHERE c_id =".$this->id." AND name ='".$this->name."' ",_DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }

    public function getcontextactionbyquestion($id, $name, $questNo) {
        $this->id = $id;
        $this->name = $name;
        $this->question = $questNo;

     $sql = sprintf("SELECT A.*,C.*,A1.actiondescription as oldaction FROM %s.context_action C left join %s.actions A on C.actionID=A.ID left join %s.actions A1 on C.old_action=A1.ID WHERE C.c_id = %d AND C.name ='%s' and C.question_No=%d order by C.id desc", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->id, $this->name, $this->question);

//	 	$sql = sprintf("SELECT * FROM %s.context_action WHERE c_id =".$this->id." AND name ='".$this->name."' ",_DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    public function addContextAction() {



       $sql = sprintf("INSERT INTO %s.context_action (c_id, name,action,question_No,reason)
										VALUES ( %d,'%s','%s',%d,'%s') ", _DB_OBJ_FULL, $this->questInfo['c_id'], $this->questInfo['name'], $this->questInfo['control'], $this->questInfo['questid'], $this->questInfo['reason']
        );

        $pStatement = $this->dbHand->prepare($sql);



        $pStatement->execute();

        $this->questId = customLastInsertId($this->dbHand, 'context_action', 'ID');


        $this->actionData = array('description' => $this->questInfo['action'],
            'who' => $this->questInfo['who'],
            'whoAU' => $this->questInfo['whoAU'],
            'who2AU' => $this->questInfo['who2AU'],
            'module_name' => "Context",
            'record' => $this->questId,
            'status' => 1,
            'buname' => 0,
            'element' => "context_action",
            'currentwho' => $this->questInfo['who'],
            'due_date' => $this->questInfo['when']);
        $actObj = new Action();
        $actObj->setActionDetails(0, $this->actionData);

        $action_id = $actObj->addAction2015();

        $sql3 = sprintf("UPDATE %s.context_action SET actionID = " . $action_id . " WHERE ID = " . $this->questId, _DB_OBJ_FULL);
        $pStatement3 = $this->dbHand->prepare($sql3);

        $pStatement3->execute();
    }
	
    
        public function editContextAction() {



       $sql = sprintf("update %s.context_action set action ='%s'
                       ,reason ='%s'
         where ID=%d", _DB_OBJ_FULL, $this->questInfo['control'], $this->questInfo['reason'],$this->questId
        );

        $pStatement = $this->dbHand->prepare($sql);



        $pStatement->execute();

        $this->actionData = array('description' => $this->questInfo['action'],
            'who' => $this->questInfo['who'],
            'whoAU' => $this->questInfo['whoAU'],
            'who2AU' => $this->questInfo['who2AU'],
            'module_name' => "Context",
            'record' => $this->questId,
            'status' => 1,
            'buname' => 0,
            'element' => "context_action",
            'currentwho' => $this->questInfo['who'],
            'due_date' => $this->questInfo['when']);



        $sql3 = sprintf("UPDATE %s.actions SET who =%d, currentwho =%d,due_date = '%s',description='%s',$whoAU='%d',addapprover='%d' WHERE ID = %d" , _DB_OBJ_FULL,$this->questInfo['who'],$this->questInfo['who'],$this->questInfo['when'],$this->questInfo['action'],$this->questInfo['whoAU'],$this->questInfo['who2AU'], $this->questId);
        $pStatement3 = $this->dbHand->prepare($sql3);

        $pStatement3->execute();

 
    }
    
    
	 public function sendEmails() {
		 
		 $sql = sprintf("SELECT A.ID,Q.reference FROM %s.actions A inner join %s.context_action C on A.record=C.ID inner join %s.context Q on C.c_id=Q.ID WHERE C.C_ID = %d AND A.moduleelement='context_action'", _DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL, $this->questInfo['c_id']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		if ($result){
		foreach($result as $row){

		$emailObj = new actionEmailHelper($row["ID"]);
             
			$who = $emailObj->getwhoDetails();
                        
			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/context">CLICK</a> Here to View Context Analysis Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $row['reference']
							)
					)
			);

			$emailObj->appendInfo($data);
			
			$emailObj->sendEmail('A '.$action.' Action To Be Carried Out(Reassigned)', $who, array(), array(), 'me_completed', '', 'grey');
			
				
        	
		}
		}
		
	 }
    public function completeAnalysis() {

        $sql3 = sprintf("UPDATE %s.context SET complete = 1 WHERE ID = %d" , _DB_OBJ_FULL,$this->questInfo['c_id']);
        $pStatement3 = $this->dbHand->prepare($sql3);

        $pStatement3->execute();
    }
    
    public function getContextAnalysisOpen() {

        $heading = array(array(0 => 'Reference', 1 => 'Title', 2 => 'Description'));
        $result = $this->viewAll();
            if (count($result)) {
            foreach ($result as $key => $value) {
            $sl_id = $value['ID'];
            $resulta[$sl_id][0] = str_replace(',', ' ', $value['reference']);
            $resulta[$sl_id][1] = str_replace(',', ' ', $value['title']);
            $resulta[$sl_id][2] = str_replace(',', ' ', $value['descp']);
            }

            $result_new = array_merge($heading, $resulta);
            } else {

            $result_new = $heading;
            }


            //dump_array($result_new);exit;
            return $result_new;

     }
    public function getContextAnalysisClosed() {

            $heading = array(array(0 => 'Reference', 1 => 'Title', 2 => 'Description'));
            $result = $this->viewClosedAll();
        if (count($result)) {
            foreach ($result as $key => $value) {
                $sl_id = $value['ID'];
                $resulta[$sl_id][0] = str_replace(',', ' ', $value['reference']);
                $resulta[$sl_id][1] = str_replace(',', ' ', $value['title']);
                $resulta[$sl_id][2] = str_replace(',', ' ', $value['descp']);
            }

            $result_new = array_merge($heading, $resulta);
        } else {

            $result_new = $heading;
        }


        //dump_array($result_new);exit;
        return $result_new;

    }
    
     public function getActions($id) {
        $sql = sprintf("select C.action,C.name,C.question_No,C.reason,P.forename,P.surname,A.actionDescription,A.dueDate,PA.forename as approverforename,PA.surname as approversurname from  %s.context_action C left join %s.actions A on C.ID= A.record left join %s.participant_database P on A.who=P.participantID left join %s.participant_database PA on A.addapprover=PA.participantID where C.c_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data as $row) {
            if ($row["name"] == "internal")
                $key = "i";
            if ($row["name"] == "common")
                $key = "c";
            if ($row["name"] == "external")
                $key = "e";

            $dataOut[$key][$row["question_No"]]["desc"] = $row["actionDescription"];
            $dataOut[$key][$row["question_No"]]["action"] = $row["action"];
            $dataOut[$key][$row["question_No"]]["reason"] = $row["reason"];
            $dataOut[$key][$row["question_No"]]["when"] = format_date($row["dueDate"]);
            $dataOut[$key][$row["question_No"]]["name"] = $row["forename"] . " " . $row["surname"];
            $dataOut[$key][$row["question_No"]]["approver"] = $row["approverforename"] . " " . $row["approversurname"];
        }

        return $dataOut;
    } 
     
     
     
     public function getStatus($status) {
        switch ($status) {
            case '0':
                $out .= 'N/A';
                break;
            case '1':
                $out .= 'Non Existant';
                break;
            case '2':
                $out .= 'Initiated';
                break;
            case '3':
                $out .= 'Limited';
                break;
            case '4':
                $out .= 'Defined';
                break;
            case '5':
                $out .= 'Managed';
                break;
            case '6':
                $out .= 'Optimised';
                break;
            default:
                $out .= '-';
        }
        return $out;
    } 
   public function getBuNameById($buid) { 
    $sql = sprintf("SELECT buName FROM %s.business_units WHERE buID = %d ",_DB_OBJ_FULL,$buid);
    $pStatement = $this->dbHand->prepare($sql);
    $pStatement->execute();
    $buName = $pStatement->fetch(PDO::FETCH_ASSOC);
    return $buName['buName'];
   }
      
    public function getContextAnalysisClosedFull() {
       
        $sql = sprintf("SELECT * FROM %s.context  where complete=1 and isnull(archive,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $contextID= $pStatement->fetchAll(PDO::FETCH_ASSOC);
      

        $i[1]['question'] = "4.1 Resources: Are Resources adequate or limited and what gaps need filling.";
        $i[2]['question'] = "4.2 Functions Are functions clearly defined and appropriate for company success the governance, organizational structure, roles and accountabilities.";
        $i[3]['question'] = "4.3 Infrastructure Are there gaps that should be filled before proceeding or can suitable plans be identified and made.";
        $i[4]['question'] = "4.4 Organization Linked to Functions but is the structure  appropriate or limited- capital, time, processes, people.";
        $i[5]['question'] = "4.5 Plan Although plan follows the previous consideration as the company continues to operate any plans made should regularly be reviewed.";
        $i[6]['question'] = "4.6 Process Are processes in place adequate or what processes must be generated and followed?";
        $i[7]['question'] = "4.7 Products Have the company identified the appropriate product range or will it limit growth.";
        $i[8]['question'] = "4.8 Project Is there project management and is it adequate or do we need to get more control in place.";
        $i[9]['question'] = "4.9 Policy Policies can be a burden yet essential so the context needs to be considered.";
        $i[10]['question'] = "4.10 Scope Is the scope of the context seriously considered against Objectives and Targets.";

        $c[1]['question'] = "5.1 Understanding the organization.  The desire of the leadership will be to create an organization that can deliver the objectives and targets while matching the ethos and vision laid out.  However, leaders will have to understand and consider such factors as social, cultural, economic, natural, competition etc., in crafting the ideal organization.";
        $c[2]['question'] = "5.2 Aspects. The terms aspects is an environmental terms but is a factor the impacts of which on the company must be considered.";
        $c[3]['question'] = "5.3 Culture and values. The impacts of culture can have an external or internal influence on the company and may require action to enhance or defend against.";
        $c[4]['question'] = "5.4 Finance. Finance or lack may impose restrictions internally or be felt externally and so appropriate action be taken to minimize.";
        $c[5]['question'] = "5.5 Hazards. Hazards are often considered to be safety matters but they extend to all aspects of the business operations and can be created by internal processes but can also be imposed by clients or suppliers.";
        $c[6]['question'] = "5.6 Objectives. The Leadership has set Objectives and Targets but reviewing the context is the first check and balance in the process in making sure they are SMART.";
        $c[7]['question'] = "5.7 Risk. Business risk is an imperative to get right and can be affected by internal processes and attitudes and external influences  looking for gap to minimize risks.";
        $c[8]['question'] = "5.8 Threats. Threats are generally considered to be against information security BUT they can also be physical especially from external, competitive  sources.";
        $c[9]['question'] = "5.9 Relationships, The one influence that is likely the most vital to success where everyone is a customer and looking for ways to improve and strengthen relationship internally and externally is vital.";
        $c[10]['question'] = "5.10 Politics. Office and national politics can have positive and negative influences so must be considered and gaps resolved.";
        $c[11]['question'] = "5.11 Media. Internal media can significantly help with communication as can external communication be both a positive or negative influence on the company.";

        $e[1]['question'] = "6.1 Perception. What clients and suppliers think of the company can have a major influence on the companys success and should be taken into consideration when looking to meet Objectives and Targets.";
        $e[2]['question'] = "6.2 Competition. Of course competition has an influence BUT it can also be a great incentive to do better or to see ideas for improvement.";
        $e[3]['question'] = "6.3 Contract(OR)s.  Contracts and Contractors (suppliers) can make or break the companys achievement of its Objectives so must be reviewed and considered.";
        $e[4]['question'] = "6.4 International. International legislation and culture cannot be forgotten especially if the companys market space moves globally";
        $e[5]['question'] = "6.5 Legislation. In most situations there is a time scale to get prepared for legislative changes so keep on top of what is happening that might impact the company";
        $e[6]['question'] = "6.6 Natural. Nature always has the potential to impact the company and so MUST be a consideration to be prepared in terms of ensuring the business can continue.";
        $e[7]['question'] = "6.7 Reputation, Ignoring what people think about the company is dangerous as whilst some comments are irrelevant many will help the company avoid issues and also generate great ideas";
        $e[8]['question'] = "6.8 Technology. Technology considered and used wisely can make a significant impact on achievement of Objectives and Targets within the context of the organization.";
        $e[9]['question'] = "6.9 Market:  The market place will shift regularly and this must be under continual review when considering the context of the organization to meet objectives and targets.";
        $e[10]['question'] = "6.10 Trends. The trends seen in the external world should be considered within the context of the organization.";

        
      
      foreach ($contextID as $Ckey => $contextRes) {
           $id = $contextRes['ID'];           
           $actions = $this->getActions($id);
            foreach ($i as $key => $res) {
               if ($key==1) { 
                $question[$id]["i"][$key]['reference'] = $contextRes['reference'];   
               }else{
                   $question[$id]["i"][$key]['reference'] = ''; 
               }
               
                $question[$id]["i"][$key]['title'] = $contextRes["title"];
                $question[$id]["i"][$key]['descp'] = $contextRes["descp"];
                
                $buIds= explode(',', $contextRes["bu"]);                
                $buNames = '';
                foreach ($buIds as $buid) {
                   if ($buNames) $buNames .= ' | ';
                   $buNames .=$this->getBuNameById($buid);
                }
                
                $question[$id]["i"][$key]['bu'] =$buNames ;
                $question[$id]["i"][$key]['question'] = $res['question'];
                $status = (int) $actions["i"][$key]["action"];
                $question[$id]["i"][$key]['status'] = $this->getStatus($status);                
                $question[$id]["i"][$key]['reason'] = $actions["i"][$key]["reason"];
                $question[$id]["i"][$key]['actionDescription'] = $actions["i"][$key]["desc"];              
                $question[$id]["i"][$key]['name'] = $actions["c"][$key]["name"];                                             
                $question[$id]["i"][$key]['when'] = $actions["i"][$key]["when"];
                $question[$id]["i"][$key]['approver'] = $actions["i"][$key]["approver"];
                
                
            }

            foreach ($c as $key => $res) {
                $question[$id]["c"][$key]['reference'] = '';      
                
                $question[$id]["c"][$key]['title'] = $contextRes["title"];
                $question[$id]["c"][$key]['descp'] = $contextRes["descp"];
              
                $buIds= explode(',', $contextRes["bu"]);                
                $buNames = '';
                foreach ($buIds as $buid) {
                   if ($buNames) $buNames .= ' | ';
                   $buNames .=$this->getBuNameById($buid);
                }
                
                $question[$id]["c"][$key]['bu'] =$buNames ;
                $question[$id]["c"][$key]['question'] = $res['question'];
                $status = (int) $actions["c"][$key]["action"];
                $question[$id]["c"][$key]['status'] = $this->getStatus($status);
                $question[$id]["c"][$key]['reason'] = $actions["i"][$key]["reason"];
                $question[$id]["c"][$key]['actionDescription'] = $actions["i"][$key]["desc"];
                $question[$id]["c"][$key]['name'] = $actions["c"][$key]["name"];
                $question[$id]["c"][$key]['when'] = $actions["c"][$key]["when"];
                $question[$id]["c"][$key]['approver'] = $actions["c"][$key]["approver"];
              
                
            }

            foreach ($e as $key => $res) {
                $question[$id]["e"][$key]['reference'] = ''; 
                $question[$id]["e"][$key]['title'] = $contextRes["title"];
                $question[$id]["e"][$key]['descp'] = $contextRes["descp"];
                
                $buIds= explode(',', $contextRes["bu"]);                
                $buNames = '';
                foreach ($buIds as $buid) {
                   if ($buNames) $buNames .= ' | ';
                   $buNames .=$this->getBuNameById($buid);                
                   
                }
                
                $question[$id]["e"][$key]['bu'] =$buNames ;
                $question[$id]["e"][$key]['question'] = $res['question'];
                $status = (int) $actions["e"][$key]["action"];
                $question[$id]["e"][$key]['status'] = $this->getStatus($status);
                $question[$id]["e"][$key]['actionDescription'] = $actions["i"][$key]["desc"];
                $question[$id]["e"][$key]['reason'] = $actions["i"][$key]["reason"];
                $question[$id]["e"][$key]['name'] = $actions["e"][$key]["name"];               
                $question[$id]["e"][$key]['when'] = $actions["e"][$key]["when"];
                $question[$id]["e"][$key]['approver'] = $actions["e"][$key]["approver"];                
                
            }
        }

       
        $firtsLevel = array();
        foreach ($question as $key => $val) {
            $firtsLevel[] = $val;
        }            
        foreach ($firtsLevel as $data) {
            foreach ((array) $data[i] as $keyI => $valueI) {
                $datas[] = $valueI;
               
            }
            foreach ((array) $data[c] as $keyI => $valueI) {
                $datas[] = $valueI;
               
            }
            foreach ((array) $data[e] as $keyI => $valueI) {
                $datas[] = $valueI;
                
            }
        }
      
        $csvData=array(array(0 =>'Reference',1=>'Title',2=>'Description',3=>'Business Unit',4=>'Question',5=>'Status',6=>'Action Description',7=>'Reason',8=>'Who',9=>'When',10=>'Approver'));
   
        foreach ($datas as $key => $value) {
            $csvData[]=$value;
        }
        
        return $csvData;

     }

    public function getContextAnalysisOpenFull() {
       
        $sql = sprintf("SELECT * FROM %s.context  where isnull(complete,0)=0 and isnull(archive,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $contextID= $pStatement->fetchAll(PDO::FETCH_ASSOC);
      

        $i[1]['question'] = "4.1 Resources: Are Resources adequate or limited and what gaps need filling.";
        $i[2]['question'] = "4.2 Functions Are functions clearly defined and appropriate for company success the governance, organizational structure, roles and accountabilities.";
        $i[3]['question'] = "4.3 Infrastructure Are there gaps that should be filled before proceeding or can suitable plans be identified and made.";
        $i[4]['question'] = "4.4 Organization Linked to Functions but is the structure  appropriate or limited- capital, time, processes, people.";
        $i[5]['question'] = "4.5 Plan Although plan follows the previous consideration as the company continues to operate any plans made should regularly be reviewed.";
        $i[6]['question'] = "4.6 Process Are processes in place adequate or what processes must be generated and followed?";
        $i[7]['question'] = "4.7 Products Have the company identified the appropriate product range or will it limit growth.";
        $i[8]['question'] = "4.8 Project Is there project management and is it adequate or do we need to get more control in place.";
        $i[9]['question'] = "4.9 Policy Policies can be a burden yet essential so the context needs to be considered.";
        $i[10]['question'] = "4.10 Scope Is the scope of the context seriously considered against Objectives and Targets.";

        $c[1]['question'] = "5.1 Understanding the organization.  The desire of the leadership will be to create an organization that can deliver the objectives and targets while matching the ethos and vision laid out.  However, leaders will have to understand and consider such factors as social, cultural, economic, natural, competition etc., in crafting the ideal organization.";
        $c[2]['question'] = "5.2 Aspects. The terms aspects is an environmental terms but is a factor the impacts of which on the company must be considered.";
        $c[3]['question'] = "5.3 Culture and values. The impacts of culture can have an external or internal influence on the company and may require action to enhance or defend against.";
        $c[4]['question'] = "5.4 Finance. Finance or lack may impose restrictions internally or be felt externally and so appropriate action be taken to minimize.";
        $c[5]['question'] = "5.5 Hazards. Hazards are often considered to be safety matters but they extend to all aspects of the business operations and can be created by internal processes but can also be imposed by clients or suppliers.";
        $c[6]['question'] = "5.6 Objectives. The Leadership has set Objectives and Targets but reviewing the context is the first check and balance in the process in making sure they are SMART.";
        $c[7]['question'] = "5.7 Risk. Business risk is an imperative to get right and can be affected by internal processes and attitudes and external influences  looking for gap to minimize risks.";
        $c[8]['question'] = "5.8 Threats. Threats are generally considered to be against information security BUT they can also be physical especially from external, competitive  sources.";
        $c[9]['question'] = "5.9 Relationships, The one influence that is likely the most vital to success where everyone is a customer and looking for ways to improve and strengthen relationship internally and externally is vital.";
        $c[10]['question'] = "5.10 Politics. Office and national politics can have positive and negative influences so must be considered and gaps resolved.";
        $c[11]['question'] = "5.11 Media. Internal media can significantly help with communication as can external communication be both a positive or negative influence on the company.";

        $e[1]['question'] = "6.1 Perception. What clients and suppliers think of the company can have a major influence on the companys success and should be taken into consideration when looking to meet Objectives and Targets.";
        $e[2]['question'] = "6.2 Competition. Of course competition has an influence BUT it can also be a great incentive to do better or to see ideas for improvement.";
        $e[3]['question'] = "6.3 Contract(OR)s.  Contracts and Contractors (suppliers) can make or break the companys achievement of its Objectives so must be reviewed and considered.";
        $e[4]['question'] = "6.4 International. International legislation and culture cannot be forgotten especially if the companys market space moves globally";
        $e[5]['question'] = "6.5 Legislation. In most situations there is a time scale to get prepared for legislative changes so keep on top of what is happening that might impact the company";
        $e[6]['question'] = "6.6 Natural. Nature always has the potential to impact the company and so MUST be a consideration to be prepared in terms of ensuring the business can continue.";
        $e[7]['question'] = "6.7 Reputation, Ignoring what people think about the company is dangerous as whilst some comments are irrelevant many will help the company avoid issues and also generate great ideas";
        $e[8]['question'] = "6.8 Technology. Technology considered and used wisely can make a significant impact on achievement of Objectives and Targets within the context of the organization.";
        $e[9]['question'] = "6.9 Market:  The market place will shift regularly and this must be under continual review when considering the context of the organization to meet objectives and targets.";
        $e[10]['question'] = "6.10 Trends. The trends seen in the external world should be considered within the context of the organization.";

        
      
      foreach ($contextID as $Ckey => $contextRes) {
           $id = $contextRes['ID'];           
           $actions = $this->getActions($id);
            foreach ($i as $key => $res) {
               if ($key==1) { 
                $question[$id]["i"][$key]['reference'] = $contextRes['reference'];   
               }else{
                   $question[$id]["i"][$key]['reference'] = ''; 
               }
               
                $question[$id]["i"][$key]['title'] = $contextRes["title"];
                $question[$id]["i"][$key]['descp'] = $contextRes["descp"];
                
                $buIds= explode(',', $contextRes["bu"]);                
                $buNames = '';
                foreach ($buIds as $buid) {
                   if ($buNames) $buNames .= ' | ';
                   $buNames .=$this->getBuNameById($buid);
                }
                
                $question[$id]["i"][$key]['bu'] =$buNames ;
                $question[$id]["i"][$key]['question'] = $res['question'];
                $status = (int) $actions["i"][$key]["action"];
                $question[$id]["i"][$key]['status'] = $this->getStatus($status);                
                $question[$id]["i"][$key]['reason'] = $actions["i"][$key]["reason"];
                $question[$id]["i"][$key]['actionDescription'] = $actions["i"][$key]["desc"];              
                $question[$id]["i"][$key]['name'] = $actions["c"][$key]["name"];                                             
                $question[$id]["i"][$key]['when'] = $actions["i"][$key]["when"];
                $question[$id]["i"][$key]['approver'] = $actions["i"][$key]["approver"];
                
                
            }

            foreach ($c as $key => $res) {
                $question[$id]["c"][$key]['reference'] = '';      
                
                $question[$id]["c"][$key]['title'] = $contextRes["title"];
                $question[$id]["c"][$key]['descp'] = $contextRes["descp"];
              
                $buIds= explode(',', $contextRes["bu"]);                
                $buNames = '';
                foreach ($buIds as $buid) {
                   if ($buNames) $buNames .= ' | ';
                   $buNames .=$this->getBuNameById($buid);
                }
                
                $question[$id]["c"][$key]['bu'] =$buNames ;
                $question[$id]["c"][$key]['question'] = $res['question'];
                $status = (int) $actions["c"][$key]["action"];
                $question[$id]["c"][$key]['status'] = $this->getStatus($status);
                $question[$id]["c"][$key]['reason'] = $actions["i"][$key]["reason"];
                $question[$id]["c"][$key]['actionDescription'] = $actions["i"][$key]["desc"];
                $question[$id]["c"][$key]['name'] = $actions["c"][$key]["name"];
                $question[$id]["c"][$key]['when'] = $actions["c"][$key]["when"];
                $question[$id]["c"][$key]['approver'] = $actions["c"][$key]["approver"];
              
                
            }

            foreach ($e as $key => $res) {
                $question[$id]["e"][$key]['reference'] = ''; 
                $question[$id]["e"][$key]['title'] = $contextRes["title"];
                $question[$id]["e"][$key]['descp'] = $contextRes["descp"];
                
                $buIds= explode(',', $contextRes["bu"]);                
                $buNames = '';
                foreach ($buIds as $buid) {
                   if ($buNames) $buNames .= ' | ';
                   $buNames .=$this->getBuNameById($buid);                
                   
                }
                
                $question[$id]["e"][$key]['bu'] =$buNames ;
                $question[$id]["e"][$key]['question'] = $res['question'];
                $status = (int) $actions["e"][$key]["action"];
                $question[$id]["e"][$key]['status'] = $this->getStatus($status);
                $question[$id]["e"][$key]['actionDescription'] = $actions["i"][$key]["desc"];
                $question[$id]["e"][$key]['reason'] = $actions["i"][$key]["reason"];
                $question[$id]["e"][$key]['name'] = $actions["e"][$key]["name"];               
                $question[$id]["e"][$key]['when'] = $actions["e"][$key]["when"];
                $question[$id]["e"][$key]['approver'] = $actions["e"][$key]["approver"];                
                
            }
        }

       
        $firtsLevel = array();
        foreach ($question as $key => $val) {
            $firtsLevel[] = $val;
        }            
        foreach ($firtsLevel as $data) {
            foreach ((array) $data[i] as $keyI => $valueI) {
                $datas[] = $valueI;
               
            }
            foreach ((array) $data[c] as $keyI => $valueI) {
                $datas[] = $valueI;
               
            }
            foreach ((array) $data[e] as $keyI => $valueI) {
                $datas[] = $valueI;
                
            }
        }
      
        $csvData=array(array(0 =>'Reference',1=>'Title',2=>'Description',3=>'Business Unit',4=>'Question',5=>'Status',6=>'Action Description',7=>'Reason',8=>'Who',9=>'When',10=>'Approver'));
   
        foreach ($datas as $key => $value) {
            $csvData[]=$value;
        }
        
        return $csvData;

     } 
     
     
     

     public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'closed') {
            return $this->getContextAnalysisClosed();
        } elseif ($type == 'closed1') {
             return $this->getContextAnalysisClosedFull();
        }elseif ($type == 'open1') {
             return $this->getContextAnalysisOpenFull();
        }else {
            return $this->getContextAnalysisOpen();
        }
    }

    public function getCompleteActionData($actionID) {
    	 $sql = sprintf("select A.id,S.reference,S.bu,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,Q.question as problem,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID inner join %s.context_questions Q on (C.name=Q.name and C.question_no=Q.questionID ) where A.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $actionID);
  
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    
    	  public function getGraphData() {
              
              
              

        $sql1 = sprintf("SELECT count(action) as opt FROM %s.context_action WHERE action = 6 ",_DB_OBJ_FULL);
	
      //select COUNT(A.action) as contextcount,S.title from selections S left join context_action A on A.action=S.ID group by S.title,A.action order by A.action

		$pStatement = $this->dbHand->prepare($sql1);
		//$pStatement->bindParam(1,$this->filters['id']);

		$pStatement->execute();
		$cause = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		  $report_data['internal']['Optimised'] = $cause['opt'];
		//  dump_array($report_data);
		
		$sql1 = sprintf("SELECT count(action) as man FROM %s.context_action WHERE action = 5 ",_DB_OBJ_FULL);
	

		$pStatement = $this->dbHand->prepare($sql1);
		//$pStatement->bindParam(1,$this->filters['id']);

		$pStatement->execute();
		$cause1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		  $report_data['internal']['Managed'] = $cause1['man'];
		  
		  $sql1 = sprintf("SELECT count(action) as def FROM %s.context_action WHERE action = 4 ",_DB_OBJ_FULL);
	

		$pStatement = $this->dbHand->prepare($sql1);
		//$pStatement->bindParam(1,$this->filters['id']);

		$pStatement->execute();
		$cause1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		  $report_data['internal']['Defined'] = $cause1['def'];
			
			
			  $sql1 = sprintf("SELECT count(action) as lim FROM %s.context_action WHERE action = 3 ",_DB_OBJ_FULL);
	

		$pStatement = $this->dbHand->prepare($sql1);
		//$pStatement->bindParam(1,$this->filters['id']);

		$pStatement->execute();
		$cause1 = $pStatement->fetch(PDO::FETCH_ASSOC);
		  $report_data['internal']['Limited'] = $cause1['lim'];
			
			
			$sql1 = sprintf("SELECT count(action) as isUnsafeDesign FROM %s.context_action WHERE action = 2 ",_DB_OBJ_FULL);
	

		$pStatement = $this->dbHand->prepare($sql1);
		//$pStatement->bindParam(1,$this->filters['id']);

		$pStatement->execute();
		$cause = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		  $report_data['internal']['Initiated'] = $cause['isUnsafeDesign'];
		  
		  	$sql1 = sprintf("SELECT count(action) as isFaultyConstruction FROM %s.context_action WHERE action = 1",_DB_OBJ_FULL);
	

		$pStatement = $this->dbHand->prepare($sql1);
		//$pStatement->bindParam(1,$this->filters['id']);

		$pStatement->execute();
		$cause = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		  $report_data['internal']['Non-Existent'] = $cause['isFaultyConstruction'];
//dump_array($report_data);
            return $report_data;
        }
    

}

?>