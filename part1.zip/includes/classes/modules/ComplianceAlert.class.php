<?php

/**
  $Id: Complaint.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, October 09, 2010 12:50:41 PM>
 */
require "ComplianceAlert.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class ComplianceAlert implements ComplianceAlertInterface {

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Complaint Id
     * @access private
     */
    private $complianceId;

    /**
     * Property to hold Complaint Info
     * @access private
     */
    private $complianceInfo;

    /**
     * Constructor for initializing Manual Handling object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /**
     * to set complaint information for performing various operations with the complaint object
     * @param integer This parameter holds the complaint Id
     * @param array This parameter holds the the complaint Info
     */
    public function setComplianceInfo($p_complianceId, $p_complianceInfo) {

        $this->complianceId = $p_complianceId;
        $this->complianceInfo = $p_complianceInfo;
    }

    /**
     * This method is used to add a new complaint
     * reference,unique_reference,location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
     * address,phone,email,complaint_nature,likelihood,impact,risk_rating,risk_color,complaint_category,investigation,action,who,when
     */
    public function addComplianceAlert() {
        $userid = getLoggedInUserId();
        $sql = sprintf("INSERT INTO %s.compliance_alert(uniqueReference,location,business_unit,startdate,starttime,issue,type1,type2,descp,violation,planning,who_reported,sendto,companyref ) values ('%s','%d',%d,'%s','%s',%d,%d,%d,'%s','%s','%s',%d,%d,'%s' )"
                , _DB_OBJ_FULL, $this->complianceInfo["unique_reference"], $this->complianceInfo["location"], $this->complianceInfo["business_unit"], $this->complianceInfo["date"], $this->complianceInfo["time"], $this->complianceInfo["issue"], $this->complianceInfo["type1"], $this->complianceInfo["type2"], $this->complianceInfo["descp"], $this->complianceInfo["violation"], $this->complianceInfo["plan"], $userid, $this->complianceInfo["who"], $this->complianceInfo["companyref"]);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $this->complianceId = customLastInsertId($this->dbHand, 'compliance_alert', 'ID');


        return $this->complianceId;
    }

    /**
     * This method is used to delete a complaint
     */
    public function deleteCompliance() {
        
    }

    public function AddAction($record_id) {
        $actObj = new Action();
        $actionData = array('description' => "An Issue has been raised for Compliance ",
            'who' => $this->complianceInfo["who"],
            'who2AU' => 0,
            'module_name' => "ComplianceAlert",
            'record' => $record_id,
            'status' => 1,
            'element' => "ComplianceAlert",
            'currentwho' => $this->complianceInfo["who"],
            'due_date' => $this->complianceInfo["date"]);

        $actObj->setActionDetails(0, $actionData);

        $lastId = $actObj->addAction2015();

        $emailObj = new actionEmailHelper($lastId);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/compliance/add_edit_view_alert.php?id=' . $record_id . '">CLICK</a> here<BR><BR>'
                . '<STRONG>Description</STRONG><BR>' . $this->complianceInfo["descp"] . "<BR><BR>"
                . '<STRONG>Violation</STRONG><BR>' . $this->complianceInfo["violation"] . "<BR><BR>"
                . '<STRONG>Planning</STRONG><BR>' . $this->complianceInfo["plan"] . "<BR><BR>"
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $this->complianceInfo["unique_reference"]
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('smart-ISO Compliance Issue ', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function viewAll() {

        $sql = sprintf("SELECT M.* FROM %s.compliance_alert  M  where archive=0 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewAllArchived() {

        $sql = sprintf("SELECT M.* FROM %s.compliance_alert  M  where archive=1 ORDER BY ID DESC", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function displayId($p_id) {

        $sql = sprintf("SELECT M.*,L.name,B.buName,P.surname,P.forename,P1.surname as surname1,P1.forename as forename1,AL.answerID as link FROM %s.compliance_alert  M left join %s.locationgram L on M.location=L.locID left join %s.business_units B on M.business_unit=B.buID left join %s.participant_database P on M.who_reported=P.participantID left join %s.participant_database P1 on M.sendto=P1.participantID left join %s.compliance_alert_links AL on M.ID=AL.alertID where M.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function archiveCompliance() {
        $sql = sprintf("update %s.compliance_alert set archive=1 WHERE ID = %d", _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function updateComplianceAlert() {

        $sql = sprintf("INSERT %s.compliance_alert_historical (ID, uniqueReference, location, business_unit, startdate, starttime, issue, type1, descp, violation, planning, who_reported, impact, likelihood, resolution_date, resolve_date, register_date, archive, type2, sendto,companyref,status,comment,rejectreason) 
            select ID, uniqueReference, location, business_unit, startdate, starttime, issue, type1, descp, violation, planning, who_reported, impact, likelihood, resolution_date, resolve_date, register_date, archive, type2, sendto,companyref,status,comment,rejectreason from %s.compliance_alert where ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

      $sql = sprintf("UPDATE %s.compliance_alert
             set impact=%d
	     ,likelihood=%d
             ,sendto=%d
             ,resolve_date='%s'
             ,register_date='%s'
              where id=%d"
                , _DB_OBJ_FULL, $this->complianceInfo["impact"], $this->complianceInfo["likelihood"], $this->complianceInfo["name"], str_replace("--","",$this->complianceInfo["resolve_date"]), str_replace("--","",$this->complianceInfo["cr_date"]), $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        
        $pStatement->execute();
    
                if ($this->complianceInfo["name"] != $this->complianceInfo["current_name"]){
               $row=$this->displayId($this->complianceId);

            $sql = sprintf("select * from  %s.actions where record=%d and moduleelement='ComplianceAlert'" , _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        
        $pStatement->execute(); 
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

      $sql = sprintf("update %s.actions set  who=%d,currentwho=%d where ID=%d " , _DB_OBJ_FULL, $this->complianceInfo["name"],$this->complianceInfo["name"],$result["ID"]);

        $pStatement = $this->dbHand->prepare($sql);
        
        $pStatement->execute(); 
        
        
               
        $emailObj = new actionEmailHelper($result[ID]);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/compliance/add_edit_view_alert.php?id=' .$this->complianceId . '">CLICK</a> here<BR><BR>'
                . '<STRONG>Description</STRONG><BR>' . $row["descp"] . "<BR><BR>"
                . '<STRONG>Violation</STRONG><BR>' . $row["violation"] . "<BR><BR>"
                . '<STRONG>Planning</STRONG><BR>' . $row["planning"] . "<BR><BR>"
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $row["uniqueReference"]
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('smart-ISO Compliance Issue Change of Issue Owner', $who, array(), array(), 'me_completed', '', 'grey');
            
        }
    
        
        
    }

	public function updateComplianceAlertC3() {

        $sql = sprintf("INSERT %s.compliance_alert_historical (ID, uniqueReference, location, business_unit, startdate, starttime, issue, type1, descp, violation, planning, who_reported, impact, likelihood, resolution_date, resolve_date, register_date, archive, type2, sendto,companyref,status,comment,rejectreason) 
            select ID, uniqueReference, location, business_unit, startdate, starttime, issue, type1, descp, violation, planning, who_reported, impact, likelihood, resolution_date, resolve_date, register_date, archive, type2, sendto,companyref,status,comment,rejectreason from %s.compliance_alert where ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);
$userid=getLoggedInUserId();
        $pStatement->execute();
if ($this->complianceInfo['r_date']=='--'){
   $sql = sprintf("UPDATE %s.compliance_alert
             set status=3,
             requiredforreport=%d,
             gcuowner=%d,
             reporttext='%s',
             resolution_date='%s'
			 where id=%d"
                , _DB_OBJ_FULL,$this->complianceInfo['rptReqd'],$userid,$this->complianceInfo['rtext'],'',  $this->complianceId);
} else {
          $sql = sprintf("UPDATE %s.compliance_alert
             set status=5,
             requiredforreport=%d,
             gcuowner=%d,
             reporttext='%s',
             resolution_date='%s'
			 where id=%d"
                , _DB_OBJ_FULL,$this->complianceInfo['rptReqd'],$userid,$this->complianceInfo['rtext'],$this->complianceInfo['r_date'],  $this->complianceId); 
    }

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function restoreRecord() {
        $sql = sprintf("update %s.compliance_alert set archive=0 WHERE ID = %d", _DB_OBJ_FULL, $this->complianceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function linktoTemplate($id, $templateid) {
        $sql = sprintf("INSERT INTO %s.compliance_alert_links(alertID,answerID) values ('%d',%d )"
                , _DB_OBJ_FULL, $id, $templateid);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function editActions() {
            $participantObj = SetupGeneric::useModule('Participant');

                      $sql = sprintf("delete from %s.compliance_alert_action_link where alertID=%d"
                    , _DB_OBJ_FULL,$this->complianceId);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
    

        for ($x = 0; $x < count($this->complianceInfo['who']); $x++) {
            $this->actionData = array('description' => $this->complianceInfo['action'][$x],
                'who' => $this->complianceInfo['who'][$x],
                'whoAU' => $this->complianceInfo['whoAU'][$x],
                'who2AU' => $this->complianceInfo['whoAU2'][$x],
                'module_name' => "ComplianceAlert",
                'record' => $this->complianceId,
                'status' => $this->complianceInfo['save_finish'],
                'buname' => 0,
                'element' => "compliance_alert",
                'currentwho' => $this->complianceInfo['who'][$x],
                'due_date' => $this->complianceInfo['when'][$x]);

            if ($this->smartLawInfo['actionID'] > 0) {
                $this->actionHandling->setActionDetails($this->complianceInfo['actionID'], $this->actionData);
                $this->actionHandling->updateAction();
                $this->actionHandling->updateActionDetail('moduleName', $this->complianceInfo['module']); //updates module name as may have been changed bythe user
                $new_action_id = $this->smartLawInfo['actionID'];
            } else {
                $this->actionHandling->setActionDetails(0, $this->actionData);
                $new_action_id = $this->actionHandling->addAction2015();
            }

            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);



            
           $sql = sprintf("INSERT INTO %s.compliance_alert_action_link(alertID,actionID,company,region,alerttype,period) VALUES (%d,%d,%d,%d,'%s',%d) "
                    , _DB_OBJ_FULL
                    , $this->complianceId
                    , $action_id
                    , $this->complianceInfo['company'][$x]
                    , $this->complianceInfo['country'][$x]
                    , $this->complianceInfo['atype'][$x]
                    , $this->complianceInfo['period'][$x]);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();




            if ($this->complianceInfo['save_finish'] == 1) {
                $emailObj = new actionEmailHelper($action_id);

                $who = $emailObj->getwhoDetails();
                $whoAU = $emailObj->getAUDetails();

                $dataC = $this->getActionsbyID($action_id);

                $sentence = array('sentence' => array("You have an action to carry out the following Compliance Issue Action"));
                $emailObj->appendInfo($sentence);

                $data = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/compliancealert.php?filter_date=">CLICK</a> Here to View Compliance Issue Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $dataC['uniqueReference']), 'description' => array('left' => '<strong>Description</strong>', 'right' => $dataC['descp'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Compliance Issue Action has been Raised', $who, array(), array(), 'me_completed', '', 'grey');

                $data = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/compliancealert.php?filter_date=">CLICK</a> Here to View Compliance Issue Action<BR>that has been raised for the above'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $dataC['uniqueReference']), 'description' => array('left' => '<strong>Description</strong>', 'right' => $dataC['descp'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Compliance Issue Action To Be Approved Once Complete', $whoAU, array(), array(), 'me_completed', '', 'grey');
            }
        }


        $sql = sprintf("update %s.compliance_alert set status=%d where ID=%d", _DB_OBJ_FULL, 1, $this->complianceId);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        if ($this->complianceInfo['save_finish'] == 1) {
            $optionObj = new Option();
            $emailObj = new actionEmailHelper(0);
            $ghl = $optionObj->getOption('_SU_GROUP_EMAIL');
             $dataC=$this->displayId($this->complianceId)  ; 
            $userID = getLoggedInUserId();


            $participantObj->setItemInfo(array('id' => $ghl));

            $details = $participantObj->displayItemById();

            $whoGLOC = array(
                'displayname' => 'GHL Group',
                'email' => $ghl,
                'ID' => $details['participantID']
            );

            $participantObj->setItemInfo(array('id' => $userID));

            $details = $participantObj->displayItemById();
            $data = array(
                'singleColData' => array(
                    'comment' => 'The above Compliance Issue has been completed <BR></BR>','click-here-url' => 'Finalise this Issue: <BR/><BR/>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/compliance/add_edit_view_alertc3.php?id=' . $this->complianceId . '">CLICK</a> Here to approve this review'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $dataC["uniqueReference"]
                    ),
                    'assignedto' => array(
                        'left' => '<strong>Assigned To:</strong>',
                        'right' => 'GHL Group'
                    ),
                    'from' => array(
                        'left' => '<strong>From</strong>',
                        'right' => ucwords($details['forename'] . ' ' . $details['surname'])
                    )
                )
            );


            $emailObj->appendInfo($data);

           $emailObj->sendEmail('A Compliance Issue has been Completed', $whoGLOC, array(), array(), 'me_completed', '', 'grey');
        }
     
    }

    public function getActions($p_record_id) {
        $sql = sprintf("select A.*,L.company,L.region,L.alerttype,L.period from  %s.actions A inner join  %s.compliance_alert_action_link L on A.ID=L.actionID where alertID=%d and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }

 public function getOutstandingActions() {
        $sql = sprintf("select L.alertID from  %s.actions A inner join  %s.compliance_alert_action_link L on A.ID=L.actionID where status=1 and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }
	    public function getGCUActions($p_record_id) {
        $sql = sprintf("select A.*,L.company,L.region,L.alerttype,L.period from  %s.actions A inner join  %s.compliance_gcualert_action_link L on A.ID=L.actionID where alertID=%d and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }
	
     public function getOutstandingGCUActions() {
        $sql = sprintf("select L.alertID from  %s.actions A inner join  %s.compliance_gcualert_action_link L on A.ID=L.actionID where status=1 and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }
    public function getActionsbyID($p_record_id) {
        $sql = sprintf("select A.*,C.* from  %s.actions A inner join  %s.compliance_alert_action_link L on A.ID=L.actionID  inner join  %s.compliance_alert C on A.record=C.ID where A.ID=%d and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data;
    }

	    public function getComments($id) {

        $sql = sprintf("SELECT * FROM %s.compliance_alert_comments C left join  %s.participant_database P on C.commentwho=P.participantID  WHERE dataID=%d order by ID desc ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($record) == 0) {
            $html = "No comments";
        } else {
            foreach ($record as $row) {
                $d = strtotime($row["commentdate"]);
                $html .= $row["comments"] . "<BR><BR>Entered on " . date("m/d/Y H:i", $d) . " by " . $row["forename"] . " " . $row["surname"] . "<BR><BR>";
            }
        }

        echo $html;
    }

    public function saveComments($id, $comments) {
        $commentwho = getLoggedInUserId();
        $sql = sprintf("insert into %s.compliance_alert_comments (dataID,comments,commentwho) VALUES (%d,'%s',%d)", _DB_OBJ_FULL, $id, $comments, $commentwho);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    
        public function editGCUActions() {
            $participantObj = SetupGeneric::useModule('Participant');

                      $sql = sprintf("delete from %s.compliance_gcualert_action_link where alertID=%d"
                    , _DB_OBJ_FULL,$this->complianceId);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
    

        for ($x = 0; $x < count($this->complianceInfo['who']); $x++) {
            $this->actionData = array('description' => $this->complianceInfo['action'][$x],
                'who' => $this->complianceInfo['who'][$x],
                'whoAU' => $this->complianceInfo['whoAU'][$x],
                'who2AU' => $this->complianceInfo['whoAU2'][$x],
                'module_name' => "ComplianceAlert",
                'record' => $this->complianceId,
                'status' => $this->complianceInfo['save_finish'],
                'buname' => 0,
                'element' => "compliance_GCUalert",
                'currentwho' => $this->complianceInfo['who'][$x],
                'due_date' => $this->complianceInfo['when'][$x]);

            if ($this->smartLawInfo['actionID'] > 0) {
                $this->actionHandling->setActionDetails($this->complianceInfo['actionID'], $this->actionData);
                $this->actionHandling->updateAction();
                $this->actionHandling->updateActionDetail('moduleName', $this->complianceInfo['module']); //updates module name as may have been changed bythe user
                $new_action_id = $this->smartLawInfo['actionID'];
            } else {
                $this->actionHandling->setActionDetails(0, $this->actionData);
                $new_action_id = $this->actionHandling->addAction2015();
            }

            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);



            
           $sql = sprintf("INSERT INTO %s.compliance_GCUalert_action_link(alertID,actionID,company,region,alerttype,period) VALUES (%d,%d,%d,%d,'%s',%d) "
                    , _DB_OBJ_FULL
                    , $this->complianceId
                    , $action_id
                    , $this->complianceInfo['company'][$x]
                    , $this->complianceInfo['country'][$x]
                    , $this->complianceInfo['atype'][$x]
                    , $this->complianceInfo['period'][$x]);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();




                $emailObj = new actionEmailHelper($action_id);

                $who = $emailObj->getwhoDetails();
                $whoAU = $emailObj->getAUDetails();

                $dataC = $this->getActionsbyID($action_id);

                $sentence = array('sentence' => array("You have an action to carry out the following Compliance GCU Issue Action"));
                $emailObj->appendInfo($sentence);

                $data = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/compliancealert.php?filter_date=">CLICK</a> Here to View GCU Compliance Issue Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $dataC['uniqueReference']), 'description' => array('left' => '<strong>Description</strong>', 'right' => $dataC['descp'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Compliance GCU Issue Action has been Raised', $who, array(), array(), 'me_completed', '', 'grey');

                $data = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/compliancealert.php?filter_date=">CLICK</a> Here to View Compliance Issue Action<BR>that has been raised for the above'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $dataC['uniqueReference']), 'description' => array('left' => '<strong>Description</strong>', 'right' => $dataC['descp'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Compliance GCU Issue Action To Be Approved Once Complete', $whoAU, array(), array(), 'me_completed', '', 'grey');
            }
     


       // $sql = sprintf("update %s.compliance_alert set status=%d where ID=%d", _DB_OBJ_FULL, 1, $this->complianceId);
       // $stmt = $this->dbHand->prepare($sql);
       // $stmt->execute();


     
    }
}

?>