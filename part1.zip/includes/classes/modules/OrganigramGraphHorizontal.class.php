<?php
 /**
  $Id: OrganigramGraphHorizontal.class.php,v 10.0 Monday, January 17, 2011 4:25:50 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, September 13, 2010 5:30:32 PM>
  */


/**
 * renderConnectionsByLevel needs re-engineering
 *
 */

class OrganigramGraphHorizontal
{
	private $debug;
	private $outputFile;
	private $memoryUsageBeforeRendering;
	private $imageType;
	private $canvasHeight;
	private $canvasWidth;
	private $imageRes;
	private $colour;
	private $fontFile;

	private $organogramData;
	private $organogramMetaData;

	private $level;
	private $maximumLevels;
	private $businessUnitCount;

	private $gridBlockWidth;
	private $gridBlockHeight;
	private $graphType;

	private $dbHand;

	public function __construct($p_graph_type,$p_filename='',$p_debug=false) {

		$this->debug 		= $p_debug;
		$this->outputFile 	= $p_filename;
		$this->memoryUsageBeforeRendering = memory_get_usage();

		$this->graphType = $p_graph_type;
 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->visualDebug = false;

		$this->imageType	= 'png'; // png | gif | jpg

		$this->gridBlockWidth = 260;

		$this->gridBlockHeight = 100;

		$this->nodeWidth = $this->gridBlockWidth - 50;

		if ( $this->graphType == 'N' ) {
			$this->nodeHeight = 40;
		} else {
			$this->nodeHeight = 60;
		}

		$this->level = 0;
		$this->maximumLevels = 9;
		$this->businessUnitCount = 0;

		$this->getOrganogramData();

		$this->canvasWidth 	= $this->gridBlockWidth * $this->businessUnitCount;
		$this->canvasHeight = $this->gridBlockHeight * $this->level;

		if (!$this->debug) {
			switch ($this->imageType) {
				case 'png': header('Content-type: image/png'); break;
				case 'gif': header('Content-type: image/gif'); break;
				case 'jpg': header('Content-type: image/jpg'); break;
				default: header('Content-type: image/png'); break;
			}
		}

		// Set the enviroment variable for GD
		//putenv('GDFONTPATH=' . realpath(_PATH_PRIVATE_FILES.'../fonts'));

		$this->fontFile['verdana'] 	= realpath(_PATH_PRIVATE_FILES.'../fonts') . '/verdana.ttf';
		$this->fontFile['verdanai'] = realpath(_PATH_PRIVATE_FILES.'../fonts') . '/verdanai.ttf';
		$this->fontFile['arial'] 	= realpath(_PATH_PRIVATE_FILES.'../fonts') . '/arial.ttf';
		$this->fontFile['arialb'] 	= realpath(_PATH_PRIVATE_FILES.'../fonts') . '/ariblk.ttf';
		$this->fontFile['ariali'] 	= realpath(_PATH_PRIVATE_FILES.'../fonts') . '/arialbd.ttf';

		$this->createImage();

		$this->colour['canvas_background'] 	= $this->generateColour(array(242,242,242));
		$this->colour['level_border']		= $this->generateColour(array(120,120,120));
		$this->colour['connector'] 			= $this->colour['level_border'];
		$this->colour['text'] 				= $this->generateColour(array(0,0,0));
		$this->colour['grid_bars'] 			= $this->generateColour(array(230,230,230));

		$this->colour['level_1'] 			= $this->generateColour(array(171,212,226));
		$this->colour['level_2'] 			= $this->generateColour(array(225,197,235));
		$this->colour['level_3'] 			= $this->generateColour(array(237,230,197));
		$this->colour['level_4'] 			= $this->generateColour(array(198,220,212));
		$this->colour['level_5'] 			= $this->generateColour(array(229,198,198));
		$this->colour['level_6'] 			= $this->generateColour(array(229,198,198));
		$this->colour['level_7'] 			= $this->generateColour(array(229,198,198));
		$this->colour['level_8'] 			= $this->generateColour(array(229,198,198));
		$this->colour['level_9'] 			= $this->generateColour(array(229,198,198));
		$this->colour['level_10'] 			= $this->generateColour(array(229,198,198));

		$this->drawCanvas();
		$this->renderBusinessUnits();
		$this->renderConnections();
		//$this->display();
		$this->saveToFile();
	}

	private function generateColour($arr) {
		if (!$this->debug) {
			return imagecolorallocate($this->imageRes,$arr[0],$arr[1],$arr[2]);
		}
	}

	public function createImage() {

		if (!$this->debug) {
			$this->imageRes = imagecreatetruecolor($this->canvasWidth+1, $this->canvasHeight+1)
							or die('Cannot Initialize new GD image stream');
		}
	}

	public function drawCanvas() {

		if (!$this->debug) {
			imagefilledrectangle($this->imageRes,0 ,0, $this->canvasWidth+1, $this->canvasHeight+1, $this->colour['canvas_background']);
			imagerectangle($this->imageRes,0 ,0, $this->canvasWidth, $this->canvasHeight, $this->colour['grid_bars']);
		}

		//echo $this->level;

		if ( !$this->debug || $this->visualDebug) {
			// horizontal bars
			for ( $k=1; $k<$this->level; $k++ ) {

				$y = $k*$this->gridBlockHeight;

				imageline($this->imageRes, 0, $y, $this->canvasWidth, $y ,$this->colour['grid_bars']);
			}

			// vertical bars
			for ( $k=1; $k<$this->businessUnitCount; $k++ ) {

				$x = $k*$this->gridBlockWidth;

				imageline($this->imageRes, $x, 0, $x, $this->canvasHeight ,$this->colour['grid_bars']);
			}
		}
	}

	private function renderBusinessUnitsByLevel($p_level) {

		$p_level = (int) $p_level;

		if ($p_level) {
			$k = 1;
			foreach ( $this->organogramData['level'.$p_level] as $level_node ) {

				if ( $level_node ) {
					$blockId = chr(65+$p_level).$k;
					$this->addNode($blockId,$level_node,$this->graphType);
				}
				//$this->organogramData[$p_level][1]['block_id'] = $blockId;
				$k++;
			}
		} else {

			$blockId = chr(65).(ceil($this->businessUnitCount/2));
			$this->addNode($blockId,1,$this->graphType);
		}
	}

	private function renderConnectionsByLevel($p_level1,$p_level2) {

		//$level_connections = array();
		$vstatements = array();

		if ( $p_level1 == 0 ) {

			$vstatements = NULL;

			if ( $this->maximumLevels > 3 ) {

				$selects = '';
				$joins = '';

				$vstatements[] = _DB_OBJ_FULL;

				for ($i=2;$i<$this->maximumLevels;$i++) {
					$selects .= ",t".$i.".buID AS level".$i;
					$joins .= "LEFT JOIN %s.business_units AS t".$i." ON t".$i.".parentBuID = t".($i-1).".buID\n";
					$vstatements[] = _DB_OBJ_FULL;
				}

				$sql = vsprintf("SELECT t1.buID AS level1 $selects
					FROM %s.business_units AS t1 $joins
					WHERE t1.parentBuID = 0
					AND t1.buID != 1",$vstatements);

			} else {

				$sql = sprintf("SELECT t1.buID AS level1, t2.buID AS level2
					FROM %s.business_units AS t1
					LEFT JOIN %s.business_units AS t2 ON t2.parentBuID = t1.buID
					WHERE t1.parentBuID = 0
					AND t1.buID != 1",_DB_OBJ_FULL,_DB_OBJ_FULL);
			}

			$result = $this->dbHand->query($sql);

			$resultset = $result->fetchAll(PDO::FETCH_ASSOC);

			$flip_level2 = $this->organogramData['level'.$p_level2];
			$flip_level2 = array_flip($flip_level2);

			//$k = 0;

			$blockCode1 = chr(65).(ceil($this->businessUnitCount/2));

			foreach ( $resultset as $resultsetEle ) {

				if ( $resultsetEle['level'.$p_level2] != '' ) {
					//$level_connections[$k]['start_node'] 	= $flip_level1[$resultsetEle['level'.$p_level1]]+1;
					//$level_connections[$k]['end_node'] 		= $flip_level2[$resultsetEle['level'.$p_level2]]+1;

					if ( ($flip_level2[$resultsetEle['level'.$p_level2]]+1) != 0 ) {

						$blockCode2 = chr(65+$p_level2).($flip_level2[$resultsetEle['level'.$p_level2]]+1);
						$this->linkNode($blockCode1,$blockCode2);
					}
				}
				//$k++;
			}

		} else {

			$vstatements = NULL;

			if ( $this->maximumLevels > 3 ) {

				$sql = "SELECT ";
				$selects = '';
				$joins = '';

				$vstatements[] = _DB_OBJ_FULL;

				for ($i=2;$i<$this->maximumLevels;$i++) {
					$selects .= ",t".$i.".buID AS level".$i;
					$joins .= "LEFT JOIN %s.business_units AS t".$i." ON t".$i.".parentBuID = t".($i-1).".buID\n";
					$vstatements[] = _DB_OBJ_FULL;
				}

				$sql = vsprintf("SELECT t1.buID AS level1 $selects
					FROM %s.business_units AS t1 $joins
					WHERE t1.parentBuID = 0
					AND t1.buID != 1",$vstatements);

			} else {

				$sql = sprintf("SELECT t1.buID AS level1, t2.buID AS level2
					FROM %s.business_units AS t1
					LEFT JOIN %s.business_units AS t2 ON t2.parentBuID = t1.buID
					WHERE t1.parentBuID = 0
					AND t1.buID != 1",_DB_OBJ_FULL,_DB_OBJ_FULL);
			}

			$result = $this->dbHand->query($sql);

			$resultset = $result->fetchAll(PDO::FETCH_ASSOC);

			$flip_level1 = $this->organogramData['level'.$p_level1];
			$flip_level1 = array_flip($flip_level1);

			$flip_level2 = $this->organogramData['level'.$p_level2];
			$flip_level2 = array_flip($flip_level2);

			foreach ( $resultset as $resultsetEle ) {

				if ( $resultsetEle['level'.$p_level1] != '' && $resultsetEle['level'.$p_level2] != '' ) {

					if ( ($flip_level1[$resultsetEle['level'.$p_level1]]+1) != 0 && ($flip_level2[$resultsetEle['level'.$p_level2]]+1) != 0 ) {
						$blockCode1 = chr(65+$p_level1).($flip_level1[$resultsetEle['level'.$p_level1]]+1);
						$blockCode2 = chr(65+$p_level2).($flip_level2[$resultsetEle['level'.$p_level2]]+1);

						$this->linkNode($blockCode1,$blockCode2);
					}
				}
			}
		}
	}

	public function renderBusinessUnits() {

		$this->renderBusinessUnitsByLevel(0);

		for ($k=1;$k<=$this->level;$k++) {
			$this->renderBusinessUnitsByLevel($k);
		}
	}

	public function renderConnections() {

		$this->renderConnectionsByLevel(0,1);

		for ($k=1;$k<($this->level-1);$k++) {
			$this->renderConnectionsByLevel($k,($k+1));
		}
	}

	private function addNode($blockCode,$nodeText='',$tabSel='N') {

		$blockRow 		= ord(strtoupper(substr($blockCode,0,1))) - 64;
		$blockColumn	= (int) substr($blockCode,1);

		$x1 = ($blockColumn - 1) * $this->gridBlockWidth + (($this->gridBlockWidth-$this->nodeWidth)/2);
		$y1 = (($blockRow - 1) * $this->gridBlockHeight) + 1;
		$x2 = (($blockColumn-1) * $this->gridBlockWidth) + $this->nodeWidth + (($this->gridBlockWidth-$this->nodeWidth)/2);
		$y2 = (($blockRow - 1) * $this->gridBlockHeight) + $this->nodeHeight;

		if (!$this->debug) {

			imagefilledrectangle($this->imageRes, $x1, $y1, $x2, $y2, $this->colour['level_'.$blockRow]);
			imagerectangle($this->imageRes, $x1, $y1, $x2, $y2, $this->colour['level_border']);
			imagerectangle($this->imageRes, $x1+1, $y1+1, $x2-1, $y2-1, $this->colour['level_border']);

			switch ($tabSel) {
				case 'N' : 	imagettftext($this->imageRes, 10, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2) - 20, $this->colour['text'], $this->fontFile['arialb'], ucfirst($this->organogramMetaData[$nodeText]['buName'])); break;

				case 'P' : 	imagettftext($this->imageRes, 10, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2) - 30, $this->colour['text'], $this->fontFile['arialb'], $this->organogramMetaData[$nodeText]['manager_name']);
							imagettftext($this->imageRes, 8, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2) - 15, $this->colour['text'], $this->fontFile['verdanai'], $this->organogramMetaData[$nodeText]['position_title']);
							imagettftext($this->imageRes, 9, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2), $this->colour['text'], $this->fontFile['verdana'], ucfirst($this->organogramMetaData[$nodeText]['buName']));
							break;

				case 'R' : 	imagettftext($this->imageRes, 10, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2) - 30, $this->colour['text'], $this->fontFile['arialb'], ucfirst($this->organogramMetaData[$nodeText]['buName']));
							imagettftext($this->imageRes, 8, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2) - 15, $this->colour['text'], $this->fontFile['verdanai'], $this->organogramMetaData[$nodeText]['audit_type']);
							imagettftext($this->imageRes, 9, 0,  ($blockColumn - 1) * $this->gridBlockWidth + 35, (($blockRow - 1) * $this->gridBlockHeight) + ($this->gridBlockHeight/2), $this->colour['text'], $this->fontFile['verdana'], $this->organogramMetaData[$nodeText]['audit_date']);
							break;
			}
		}
	}

	private function linkNode($blockCode1,$blockCode2) {

		if (!$this->debug) {
			imagesetthickness($this->imageRes, 2);

			$blockRow1 			= ord(strtoupper(substr($blockCode1,0,1))) - 64;
			$blockColumn1		= (int) substr($blockCode1,1);

			$blockRow2 			= ord(strtoupper(substr($blockCode2,0,1))) - 64;
			$blockColumn2		= (int) substr($blockCode2,1);


			if ( $this->graphType == 'N' ) {
				$x1 = $blockColumn1 * $this->gridBlockWidth - $this->gridBlockWidth/2;
				$y1 = (($blockRow1) * $this->gridBlockHeight) - 3*$this->nodeHeight/2;
				$y2 = (($blockRow1) * $this->gridBlockHeight) - $this->nodeHeight/2 - 5;
			} else {
				$x1 = $blockColumn1 * $this->gridBlockWidth - $this->gridBlockWidth/2;
				$y1 = (($blockRow1) * $this->gridBlockHeight) + $this->nodeHeight/2 + 20 - 3*$this->nodeHeight/2;
				$y2 = (($blockRow1) * $this->gridBlockHeight) - $this->nodeHeight/2 + 5;
			}

			$x2 = $x1;


			$x3 = $blockColumn2 * $this->gridBlockWidth - $this->gridBlockWidth/2;
			$y3 = (($blockRow1-1) * $this->gridBlockHeight) + $this->gridBlockHeight - $this->gridBlockHeight/4;

			$x4 = $x3;
			$y4 = $y3+$this->gridBlockHeight/4;

			$x5 = ($blockColumn1) * $this->gridBlockWidth - $this->gridBlockWidth/2;
			$y5 = (($blockRow2 - 1) * $this->gridBlockHeight) - ($this->gridBlockHeight/4);

			$x6 = $blockColumn2 * $this->gridBlockWidth - $this->gridBlockWidth/2;
			$y6 = $y5;

			imageline($this->imageRes, $x1, $y1, $x2, $y2, $this->colour['connector']);     //|
			imageline($this->imageRes, $x5, $y5, $x6, $y6, $this->colour['connector']);     // -
			imageline($this->imageRes, $x3, $y3, $x4, $y4, $this->colour['connector']); 	// |

		}
	}

	public function display() {

		if ( $this->visualDebug ) {

			imagettftext($this->imageRes, 8, 0,$this->canvasWidth - 1280, $this->canvasHeight - 100 , $this->colour['text'], $this->fontFile['verdanai'], 'Debug Info : '.$this->level);
			//imagettftext($this->imageRes, 8, 0,$this->canvasWidth - 1280, $this->canvasHeight - 85 , $this->colour['text'], $this->fontFile['verdanai'], substr(serialize($this->organogramData),201,400));
			/*imagettftext($this->imageRes, 8, 0,$this->canvasWidth - 1280, $this->canvasHeight - 70 , $this->colour['text'], $this->fontFile['verdanai'], substr(serialize($this->organogramData),401,600));
			imagettftext($this->imageRes, 8, 0,$this->canvasWidth - 1280, $this->canvasHeight - 55 , $this->colour['text'], $this->fontFile['verdanai'], substr(serialize($this->organogramData),601,800));
			imagettftext($this->imageRes, 8, 0,$this->canvasWidth - 350, $this->canvasHeight - 20 , $this->colour['text'], $this->fontFile['verdanai'], 'Memory Usage before this image rendering : '.$this->get_memory_usage($this->memoryUsageBeforeRendering));
			imagettftext($this->imageRes, 8, 0,$this->canvasWidth - 350, $this->canvasHeight - 10 , $this->colour['text'], $this->fontFile['verdanai'], 'Memory Usage after this image rendering : '.$this->get_memory_usage(memory_get_usage(TRUE)));*/
		}

		if (!$this->debug) {
			imagepng($this->imageRes);
		}

	}

	private function getBusinessUnitPositionManager($p_buID) {

		$sql = sprintf("SELECT positionName,CONCAT(forename,' ',surname) as participant_name
				FROM %s.organisation_positions O
				INNER JOIN %s.participant_database P
				ON O.participantID = P.participantID
				WHERE O.buID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_buID);

		$stmt 		= $this->dbHand->prepare($sql);

		//$stmt->bindParam(1,$p_buID);
		$stmt->execute();

		$resultset	 			= $stmt->fetch(PDO::FETCH_ASSOC);

		return array('position_title'=>ucfirst($resultset['positionName']), 'participant_name'=>ucwords($resultset['participant_name']));

	}

	private function getOrganogramData() {

		$sql = sprintf("SELECT * FROM %s.business_units
				ORDER BY buID ASC",_DB_OBJ_FULL);

		$resultmeta 			= $this->dbHand->query($sql);
		$resultsetmeta 			= $resultmeta->fetchAll(PDO::FETCH_ASSOC);
		$resultsetmetaCount 	= count($resultsetmeta);

		if ( $resultsetmetaCount ) {

			if ( _DB_TYPE != 'mysql' ) {
				$compdate = '1900-01-01';
			} else {
				$compdate = '0000-00-00';
			}


			foreach ( $resultsetmeta as $resultsetmeta_element ) {

				$buID = $resultsetmeta_element['buID'];
				$position_data = $this->getBusinessUnitPositionManager($buID);

				$resultsetmeta_element['position_title'] 	= $position_data['position_title'];
				$resultsetmeta_element['manager_name'] 		= $position_data['participant_name'];

				if ( $resultsetmeta_element['msr'] != 0 ) {
					$resultsetmeta_element['audit_type'] 	= 'MSR';

					if ( $position_data['whenMsr'] != $compdate ) {
						$resultsetmeta_element['audit_date'] 	= format_date($resultsetmeta_element['whenMsr']);
					} else {
						$resultsetmeta_element['audit_date'] 	= '';
					}

				} else if ( $resultsetmeta_element['isr'] != 0 ) {
					$resultsetmeta_element['audit_type'] 	= 'ISR';

					if ( $position_data['whenIsr'] != $compdate ) {
						$resultsetmeta_element['audit_date'] 	= format_date($resultsetmeta_element['whenIsr']);
					} else {
						$resultsetmeta_element['audit_date'] 	= '';
					}
				}

				$this->organogramMetaData[$buID] = $resultsetmeta_element;
			}
		}

		$vstatements = array();

		if ( $this->maximumLevels > 3 ) {

			$sql = "SELECT ";
			$selects = '';
			$joins = '';

			$vstatements[] = _DB_OBJ_FULL;

			for ($i=2;$i<$this->maximumLevels;$i++) {
				$selects .= ",t".$i.".buID AS level".$i;
				$joins .= "LEFT JOIN %s.business_units AS t".$i." ON t".$i.".parentBuID = t".($i-1).".buID\n";
				$vstatements[] = _DB_OBJ_FULL;
			}

			$sql = vsprintf("SELECT t1.buID AS level1 $selects
				FROM %s.business_units AS t1 $joins
				WHERE t1.parentBuID = 0
				AND t1.buID != 1",$vstatements);

		} else {

			$sql = sprintf("SELECT t1.buID AS level1, t2.buID AS level2
				FROM %s.business_units AS t1
				LEFT JOIN %s.business_units AS t2 ON t2.parentBuID = t1.buID
				WHERE t1.parentBuID = 0
				AND t1.buID != 1",_DB_OBJ_FULL,_DB_OBJ_FULL);
		}
$stmt 		= $this->dbHand->prepare($sql);

		$stmt->execute();

		//$result = $this->dbHand->query($sql);

		$resultset = $stmt->fetchAll(PDO::FETCH_ASSOC);

		//$this->organogramData 		= $resultset;
		$this->businessUnitCount 	= count($resultset);

		$this->level = 0;

		if ($this->maximumLevels) {

			for ($i=1;$i<$this->maximumLevels;$i++) {
				$dynname = 'level'.$i.'_allzero';
				$$dynname = 0;
			}

			foreach ( $resultset as $resultsetEle ) {

				for ($i=1;$i<$this->maximumLevels;$i++) {

					if ( !is_null($resultsetEle['level'.$i]) ) {
						$this->organogramData['level'.$i][] = $resultsetEle['level'.$i];
					} else {
						$this->organogramData['level'.$i][] = 0;
					}

					$dynname = 'level'.$i.'_allzero';

					if ( !$$dynname && !is_null($resultsetEle['level'.$i]) ) {
						$$dynname = 1;
					}
				}
			}

			for ($i=1;$i<$this->maximumLevels;$i++) {

				$dynname = 'level'.$i.'_allzero';

				if ($$dynname) {
					$this->level = $i;
				} // end if

				$element_counts = $skip_count  = array();

				$element_counts = array_count_values($this->organogramData['level'.$i]);

				foreach ( $element_counts as $element_count_elek=>$element_count_elev ) {
					$skip_count[$element_count_elek] = floor($element_count_elev/2);
				}

				$this->organogramDataTemp['level'.$i] = $this->organogramData['level'.$i];

				$k = 0;
				$m = 0;
				$old_level_node = 0;
				foreach ( $this->organogramDataTemp['level'.$i] as $level_node ) {

					//echo $level_node.":".$skip_count[$level_node].":".$k." -- $old_level_node != $level_node <br/>";

					if ( $old_level_node > 0 && $old_level_node != $level_node ) {
						$k = 0;
					}

					if ( $old_level_node == 0 ) {
						$k = 0;
					}

					if ( $skip_count[$level_node] == 0 || $skip_count[$level_node] == $k ) {

						$this->organogramData['level'.$i][$m] = $level_node;


						$old_level_node = $level_node;
						$k++; $m++;
						continue;
					} else {
						$this->organogramData['level'.$i][$m] = 0;

						$old_level_node = $level_node;
						$m++;
						$k++;
					}
				}
				//echo "<br/><br/>";

			} // end for
		}

		//dump_array($this->organogramData);
	}

	private function get_memory_usage($memUsage) {

        if ($memUsage < 1024) {
            return $mem_usage." bytes";
        } else if ($memUsage < 1048576) {
            return round($memUsage/1024,2)." kilobytes";
        } else {
            return round($memUsage/1048576,2)." megabytes";
		}
    }

	public function __destruct() {

		if (!$this->imageRes && !$this->debug) {
			imagedestroy($this->imageRes);
		}
	}

	public function saveToFile() {

		$filename = _PATH_TEMP_FILES.$this->outputFile;

		if (!$this->debug) {
			imagepng($this->imageRes,$filename);
		}
	}
}
?>