<?php

/**
  $Id: ActionTracker.class.php,v 4.29 Monday, May 01, 2018 4:40:01 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Interface to manage Organigram object
 *
 * This interface will declare the various methods performed
 * by organigram object for operations like add, edit, delete, archive, purge.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Interface
 * @since  Thursday, September 09, 2010 6:29:33 PM>
 */
require_once(_MYCLASSES . '/graph/GraphModuleData.int.php');
require_once(_MYCLASSES . '/graph/GraphData.abs.php');

class DashboardOperationcompleteaction extends DashboardParent {

    /**
     * Constructor for initializing Action Tracker object
     * @access public
     */
    public $filter_query, $filters, $data_set;

    public function __construct() {
        $this->data_format = new GraphData();
        parent::__construct();
    }

    public function getCompletedMASRActions() {

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk' and approveAU=1";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk' and approveAU=1";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data['0']['complete_action'];
    }

    public function getMASRActionsTotal() {

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data['0']['complete_action'];
    }

    public function getUserClass() {

        $id = getLoggedInUserId();

        $sql = "SELECT docClassification FROM " . _DB_OBJ_FULL . ".participant_meta_data
				WHERE participantID = " . $id;

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['docClassification'];
    }

    public function getDocAlertsActionTotal() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();
            $sql = "select count(A.cmsdocID) as total_document_alert from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' and D.classification in (%s)";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr, $bu_list);
        } else {
            $sql = "select count(A.cmsdocID) as total_document_alert from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' and D.classification in (%s)";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        }


        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
        return $results['0']['total_document_alert'];
    }

    public function getCompletedDocAlertsAction() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();
            $sql = "select count(A.cmsdocID) as total_document_alert_done from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' AND doneStatus ='L'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr, $bu_list);
        } else {
            $sql = "select count(A.cmsdocID) as total_document_alert_done from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' AND doneStatus ='L'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        }


        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
        return $results['0']['total_document_alert_done'];
    }

    public function get_percentage($percentage, $of) {
                if ($of != 0)
        $percent = $percentage / $of;
        else
        $percent =0;
        return number_format($percent * 100, 2) . '%';
        
    }

    public function getGraphData() {
        
        
        $data_stat_type = strip_tags($_GET['data_stat_type']);

        $module_name = 'risk';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $grid_data = $dashObj->getData();        
        $total_risk_done = $grid_data['q5']['D'];
        $total_risk_p = $grid_data['q5']['P'];
        $total_risk = $grid_data['q6']['A']+$total_risk_p+$total_risk_done;

        
        $module_name_soa = 'SOA';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name_soa);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $grid_data_soa = $dashObj->getData();
        $total_soa_done = $grid_data_soa['q5']['D'];
        $total_soa_p = $grid_data_soa['q5']['P'];
        $total_soa = $grid_data_soa['q6']['A']+$total_soa_p+$total_soa_done;



        $risk_percentage = $this->get_percentage($total_risk_done, $total_risk);
        $soa_percentage = $this->get_percentage($total_soa_done, $total_soa);




        $this->data_format->addData('Risk Assessment', $risk_percentage);
        $this->data_format->addData('SOA', $soa_percentage);
        $this->data_format->getGraphData();

        $this->data_set['chart_data'][] = $this->data_format->graph_data;
        $this->data_set['heading'] = 'Operation Completed Action';
        $this->data_set['xaxis_text'] = "Actions";
        $this->data_set['yaxis_text'] = "% age  of Completed Action";
        return $this->data_set;
    }

}
