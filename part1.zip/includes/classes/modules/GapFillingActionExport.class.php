<?php
 /**
  $Id: InvestigationMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, November 04, 2010 8:32:17 AM>
  */
require_once "Action.class.php";
require_once "ReviewGap.class.php";
class GapFillingActionExport 
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Investigation Id
	 *@access private
	 */
	private $investigationId;

	/**
	 *Property to hold Investigation Info
	 *@access private
	 */
	private $investigationInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing Investigation object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setInvestigationInfo($p_investigationId,$p_investigationInfo) {

		$this->investigationId		=	$p_investigationId;
		$this->investigationInfo	=	$p_investigationInfo;
	}

	public function getListingforExport() {

		$heading = array(array('document'=>'Document','bu'=>'Business Unit','comment'=>'Comment','assigned'=>'Assigned To','due'=>'When'));
		$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
		$gapObj = new ReviewGap();
		
		if ( $tab_type == 'me_pending' ) {
			$res	= $gapObj->getGapQuestionActionTracker(true);
		} else {
			$res	= $gapObj->getGapQuestionActionTracker(false);
		}
			
		$orgObj = SetupGeneric::useModule('Organigram');
		$partObj = SetupGeneric::useModule('Participant');

	
		
		if(!empty($res)){
			
		foreach ( $res as $resultEle ) {
			
			$partObj->setItemInfo(array('id'=>$resultEle['participantID']));
			$participant = $partObj->displayItemMaininfoById();
			$participant_name = ucwords($participant['forename'].' '.$participant['surname']);
			
			$orgObj->setItemInfo(array('id'=>$resultEle['buID']));
			$bu_info 		= $orgObj->displayItemById();
				
			

			$description = ucfirst($resultEle['description']);

			
			$result[$i]['document'] =$resultEle['displayName'];
			$result[$i]['bu'] = $bu_info['buName'];
			$result[$i]['comment'] = $description ;
			$result[$i]['assigned'] = $participant_name;
			$result[$i]['when'] = $resultEle['whenDate'];
			$result[$i]['typeID'] = $resultEle['typeID'];
			
			$i++;
			
		   }
		//$result = array_merge($heading,$result);
		return $result;
			
		}

		
	}


	
}
?>