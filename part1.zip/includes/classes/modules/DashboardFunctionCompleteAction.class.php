<?php
/**
  $Id: ActionTracker.class.php,v 4.29 Monday, May 01, 2018 4:40:01 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Interface to manage Organigram object
 *
 * This interface will declare the various methods performed
 * by organigram object for operations like add, edit, delete, archive, purge.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Interface
 * @since  Thursday, September 09, 2010 6:29:33 PM>
 */

require_once(_MYCLASSES . '/graph/GraphModuleData.int.php');
require_once(_MYCLASSES . '/graph/GraphData.abs.php');
class DashboardFunctionCompleteAction extends DashboardParent {
     /**
     * Constructor for initializing Action Tracker object
     * @access public
     */
    public $filter_query, $filters, $data_set;

    public function __construct() {
        $this->data_format = new GraphData();
        parent::__construct();
    }

    public function getCompletedMASRActions() {

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk' and approveAU=1";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk' and approveAU=1";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data['0']['complete_action'];
    }

    public function getMASRActionsTotal() {

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data['0']['complete_action'];
    }

    
   public function get_percentage($percentage, $of)
    {      
               if ($of != 0)
        $percent = $percentage / $of;
        else
        $percent =0;
        return  number_format( $percent * 100, 2 ) . '%';;
    }
    
    public function getGraphData() {

        $bu_list = array();
        $hlist = array();
        $dlist = array();

        $q1_sr = $this->qtrsRange['q1_sr'];
        $q1_er = $this->qtrsRange['q1_er'];
        $q2_sr = $this->qtrsRange['q2_sr'];
        $q2_er = $this->qtrsRange['q2_er'];
        $q3_sr = $this->qtrsRange['q3_sr'];
        $q3_er = $this->qtrsRange['q3_er'];
        $q4_sr = $this->qtrsRange['q4_sr'];
        $q4_er = $this->qtrsRange['q4_er'];
        $q5_sr = $this->qtrsRange['q5_sr'];
        $q5_er = $this->qtrsRange['q5_er'];
        $cqtr = $this->qtrsRange['cqtr'];


       
        
        $data_stat_type = strip_tags($_GET['data_stat_type']);

        $module_name = 'incidence';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $grid_data = $dashObj->getData();        
        $total_incidence_done = $grid_data['q5']['D'];
        $total_incidence_p = $grid_data['q5']['P'];
        $total_incidence = $grid_data['q6']['A']+$total_risk_p+$total_risk_done;
        
        
        
        
        $module_name1 = 'nhp';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name1);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $nhp_data = $dashObj->getData();        
        $total_nhp_done = $nhp_data['q5']['D'];
        $total_nhp_p = $nhp_data['q5']['P'];
        $total_nhp = $nhp_data['q6']['A']+$total_nhp_p+$total_nhp_done;
        
        
        
        $module_name2 = 'incidence_investigation';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name2);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $incident_investigation_data = $dashObj->getData();        
        $total_incident_investigation_done = $incident_investigation_data['q5']['D'];
        $total_incident_investigation_p = $incident_investigation_data['q5']['P'];
        $total_incident_investigation = $incident_investigation_data['q6']['A']+$total_incident_investigation_p+$total_incident_investigation_done;
        
        
        $module_name3 = 'nhp_investigation';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name3);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $nhp_investigation_data = $dashObj->getData();        
        $total_nhp_investigation_done = $nhp_investigation_data['q5']['D'];
        $total_nhp_investigation_p = $nhp_investigation_data['q5']['P'];
        $total_nhp_investigation = $nhp_investigation_data['q6']['A']+$total_nhp_investigation_p+$total_nhp_investigation_done;
       
        $module_name4 = 'inspection';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name4);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $inspection_data = $dashObj->getData();        
        $total_inspection_done = $inspection_data['q5']['D'];
        $total_inspection_p = $inspection_data['q5']['P'];
        $total_inspection= $inspection_data['q6']['A']+$total_inspection_p+$total_inspection_done;
      
        $module_name5 = 'alert';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name5);
        $dashObj->setFilter(array('selected_bu' => $this->filter['selected_bu']));
        $dashObj->setBlockRange($data_stat_type);
        $alert_data = $dashObj->getData();        
        $total_alert_done = $alert_data['q5']['D'];
        $total_alert_p = $alert_data['q5']['P'];
        $total_alert= $alert_data['q6']['A']+$total_alert_p+$total_alert_done;
        
          
       

        $incidence_percentage =$this->get_percentage($total_incidence_done,$total_incidence);
        $nhp_percentage =$this->get_percentage($total_nhp_done,$total_nhp);
        $incident_investigation_percentage =$this->get_percentage($total_incident_investigation_done,$total_incident_investigation);
        $nhp_investigation_percentage =$this->get_percentage($total_nhp_investigation_done,$total_nhp_investigation);
        $inspection_percentage =$this->get_percentage($total_inspection_done,$total_inspection);
        $alert_percentage =$this->get_percentage($total_alert_done,$total_alert);
       
        
        
        $this->data_format->addData('Incident', $incidence_percentage);        
        $this->data_format->addData('NCR', $nhp_percentage);
        $this->data_format->addData('Incident Investigation', $incident_investigation_percentage);
        $this->data_format->addData('NCR Investigation', $incident_investigation_percentage);
        $this->data_format->addData('Inspection', $inspection_percentage);
        $this->data_format->addData('NCR-Non Conformity', $alert_percentage);
        $this->data_format->getGraphData();

        $this->data_set['chart_data'][] = $this->data_format->graph_data;
        $this->data_set['heading'] = 'Function Completed Action';
        $this->data_set['xaxis_text'] = "Actions";
        $this->data_set['yaxis_text'] = "% age  of Completed Action";       
        return $this->data_set;
        
    }

}