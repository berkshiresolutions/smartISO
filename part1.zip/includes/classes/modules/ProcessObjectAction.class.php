<?php
 /**
  $Id: ProcessObjectAction.class.php,v 5.19 Saturday, December 18, 2010 7:10:47 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 3:01:13 PM>
  */
require_once "ProcessObjectInterface.int.php";


class ProcessAction implements ProcessObjectInterface
{
	private $p_x1;
	private $p_y1;

	public function printHeadingAndDescription($classObj,$p_x1,$p_y1,$p_heading,$p_content) {

		$this->p_x1 = $p_x1;
		$this->p_y1 = $p_y1;

		$this->printHeading($classObj,$p_heading);
		$this->printDescription($classObj,$p_content);
                
	}

    private function printHeading($classObj,$p_content) {

        $this->p_x1 = $this->p_x1 + 45;
        $this->p_y1 = $this->p_y1 + 18;

		//$p_content = 'Vehicle Standard';

		//imagefttext($classObj->getResource(), $classObj->getBusinessUnitFontSize(), 0, $p_x1,$p_y1, $path_colour, $classObj->getFontFile(),$p_content);
		$this->wrapText($classObj,$classObj->getBusinessUnitFontSize(),$p_content,29);
    }

	private function wrapText($classObj,$p_fontsize,$p_content1,$p_wrapStrCnt) {

$p_content=str_ireplace("<BR>"," - ",$p_content1);
		$p_content_strlen = strlen($p_content);
		$p_content_tokens = ceil($p_content_strlen/$p_wrapStrCnt);

		if ( $p_content_strlen > $p_wrapStrCnt ) {

			for ($k=0;$k<2;$k++) {

				$start_pt = $k*$p_wrapStrCnt;

				if ( $k == 1 ) {
					$end_pt = $p_content_strlen - $p_wrapStrCnt;
				} else {
					$end_pt = $p_wrapStrCnt;
				}

				imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),substr($p_content,$start_pt,$end_pt));
				$this->p_y1 = $this->p_y1 + 14;
			}
		} else {
			imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),$p_content);
			$this->p_y1 = $this->p_y1 + 14;
		}

	}

    private function printDescription($classObj,$p_content1) {

		//$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
                $p_content=str_ireplace("<BR>"," - ",$p_content1);
		$p_content_strlen = strlen($p_content);
		$max_string_length = 35;

		$this->p_y1 = $this->p_y1;

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$this->p_y1, $path_colour, $classObj->getFontFile_2(),$p_content);
		} else {

			$strings 	= wordwrap(substr($p_content,0,150).' ...', $max_string_length,  "#", true);
			$string_arr = explode("#",$strings);

			$cy1 = $this->p_y1;

			foreach ( $string_arr as $strele ) {
				imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$cy1, $path_colour, $classObj->getFontFile_2(),$strele);
				$cy1 = $cy1 + 11;
			}
		}
	}


    private function printDoc($classObj,$p_content) {

		//$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

		$p_content_strlen = strlen($p_content);
		$max_string_length = 35;

		$this->p_y1 = $this->p_y1+60;

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$this->p_y1, $path_colour, $classObj->getFontFile_2(),$p_content);
		} else {

			$strings 	= wordwrap(substr($p_content,0,150).' ...', $max_string_length,  "#", true);
			$string_arr = explode("#",$strings);

			$cy1 = $this->p_y1;

			foreach ( $string_arr as $strele ) {
				imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$cy1, $path_colour, $classObj->getFontFile_2(),$strele);
				$cy1 = $cy1 + 11;
			}
		}
	}
        
    public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {



	//	$blockCord  = ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$blockCord 	= $p_block;
		$path_no 	= (int) $blockCord['path_no'];

	//	$x = ($classObj->argBlockWidth() - $p_width)/2;
	//	$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

		$x1 =$blockCord['x'];
		$y1 =$blockCord['y'];
		$x2 = $x1 + $p_width;
		$y2 = $y1 + $p_height;



		$xln1 = $blockCord['x'] + $path_x_offset;
		$xln2 = $blockCord['x'] + $classObj->argBlockWidth() + $path_x_offset;


		$ym = $blockCord['y'] + $classObj->argObjectHeight();

		imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

		$path_colour = $classObj->getPathcolour($path_no);



		if ( $classObj->getOutputType() == 'N' ) {
			imagefilledrectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('action_colour'));

			// for gloss
			imagefilledrectangle($classObj->getResource(), $x1+2, $y1+2, $x2-2, $y2-20, $classObj->getColour('action_gloss_colour'));
			imagefilledrectangle($classObj->getResource(), $x1+3, $y1+2, $x2-3, $y2-24, $classObj->getColour('action_gloss2_colour'));
			imagefilledrectangle($classObj->getResource(), $x1+4, $y1+2, $x2-4, $y2-27, $classObj->getColour('white_colour'));

			imagerectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('text_colour'));
		} else {
            $classObj->showExternalImage($x1, $y1-10, 'action');
		}
$ccpcheck=false;
        // for sub process
        if ( $p_step_info['subSwimID'] != 0 ) {
$ccpcheck=$classObj->getccps($p_step_info['subSwimID']);

            if ( $classObj->getOutputType() == 'N' ) {
                $subprocessOffset = $classObj->argSubprocessOffset();

                imagefilledrectangle($classObj->getResource(), $x1+20, $y2-9, $x2-5, $y2-3, $classObj->getColour('sub_process_colour'));
 
			} else {
			 $subref=$classObj->getSbpRef($p_step_info['subSwimID']);

			  $box=imagettfbbox(9,0,$classObj->getFontFile_2(),$subref);
            imagefilledrectangle($classObj->getResource(), $x2-150, $y2, $x2-150+$box[2]+20, $y2+14, $classObj->getColour('sub_process_colour')); 
		imagefttext($classObj->getResource(), 9, 0, $x2-140, $y2+12, $path_colour, $classObj->getFontFile(),$subref);
		
           //     $classObj->showExternalImage( $x2-150, $y2-25, 'sbp');
   	//imagefttext($classObj->getResource(), 9, 0, $x2-150, $y2+35, $path_colour, $classObj->getFontFile(),$subref);
            }
		}
//var_dump($classObj->getstepDocs);
		// for ccp
		$ccp=0;
		if ( $p_step_info['criticalControlPoint'] != '' )
		$ccp+=1;
		if($ccpcheck)
		$ccp+=2;
	
		if ($ccp>0)		
		{

            if ( $classObj->getOutputType() == 'N' ) {
             $y3=($y1+$y2)*0.5;
             if ($ccp==1) {
			 imagefilledrectangle($classObj->getResource(), $x1+5, $y1+3, $x1+11, $y3, $classObj->getColour('ccp_colour'));
             imagefilledrectangle($classObj->getResource(), $x1+5, $y3, $x1+11, $y2-3, $classObj->getColour('ccp_colour')); 
			 }
			              if ($ccp==2) {
			 imagefilledrectangle($classObj->getResource(), $x1+5, $y1+3, $x1+11, $y3, $classObj->getColour('ccp1_colour'));
             imagefilledrectangle($classObj->getResource(), $x1+5, $y3, $x1+11, $y2-3, $classObj->getColour('ccp1_colour')); 
			 }
			                 if ($ccp==3) {
			 imagefilledrectangle($classObj->getResource(), $x1+5, $y1+3, $x1+11, $y3, $classObj->getColour('ccp_colour'));
             imagefilledrectangle($classObj->getResource(), $x1+5, $y3, $x1+11, $y2-3, $classObj->getColour('ccp1_colour')); 
			 }
			     
		   } else {
                $classObj->showExternalImage($x2-180, $y2-20, 'ccp'.$ccp);
            }
		}



		// save node coordinates

		if ( $classObj->getResample() ) {
			$resamplePercent 	= $classObj->getResamplePercent();

			$x1_resamp = ceil($x1 * $resamplePercent);
			$y1_resamp = ceil($y1 * $resamplePercent);
			$x2_resamp = ceil($x2 * $resamplePercent);
			$y2_resamp = ceil($y2 * $resamplePercent);

			$node_coordinates = $x1_resamp.','.$y1_resamp.','.$x2_resamp.','.$y2_resamp;
		} else {
			$node_coordinates = $x1.','.$y1.','.$x2.','.$y2;
		}
		

		$classObj->saveNodeCoordinates($p_step_info['ID'],$node_coordinates);

		if ( $classObj->getOutputType() == 'H' && $p_step_info['descQues'] != '' ) {

			$this->printHeadingAndDescription($classObj,$x1,$y1,$p_step_info['buName'],$p_step_info['descQues']);

				if ( !empty($p_step_info['comments_information']['HORZ'][0]) ) {
								$this->printDescription($classObj,$x1,$y1+40,$p_width,$p_height,$p_step_info['comments_information']['HORZ'][0]);
				}

                              $docs = $classObj->getstepDocs();
            if ($docs != '')
                $this->printDoc($classObj, $docs);
        }
		//}



	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

//		$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$blockCord 	= $p_block;
//		$path_no 	= (int) $blockCord['path_no'];

//		$x = ($classObj->argBlockWidth() - $p_width)/2;
//		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

		$x1 = $blockCord['x'];
		$y1 = $blockCord['y'];
		$x2 = $x1 + $p_width;
		$y2 = $y1 + $p_height;



		if ( $classObj->getOutputType() == 'N' ) {
			$shade_offset = $classObj->getShadeOffset();

			imagefilledrectangle($classObj->getResource(), $x1+$shade_offset, $y1+$shade_offset, $x2+$shade_offset, $y2+$shade_offset, $classObj->getColour('shadow2_colour'));
			imagefilledrectangle($classObj->getResource(), $x1+$shade_offset-2, $y1+$shade_offset-2, $x2+$shade_offset-2, $y2+$shade_offset-2, $classObj->getColour('shadow_colour'));
		}
	}
}
?>