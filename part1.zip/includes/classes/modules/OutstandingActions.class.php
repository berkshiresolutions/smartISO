<?php
 /**
  $Id: OutstandingActions.class.php,v 3.11 Saturday, January 08, 2011 6:27:14 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 12, 2010 3:53:21 PM>
  */

require_once "Action.class.php";

class OutstandingActions
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Constructor for initializing OutstandingActions object
	 * @access public
	 */
	public function __construct() {

		 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	public function getModuleActions($p_module,$p_overdue=false,$p_bu_id=null) {
		$dynamic_function_name = ucwords($p_module);
		
		if($dynamic_function_name == 'Soa'){
			$dynamic_function_name = 'SOA';
		}
$date=date("m/d/Y");
		$class_object = new $dynamic_function_name;
		$data = $class_object->getOutstandingActions($p_bu_id,$date);
		
		//$reformed_data = "";
		if ( count($data) ) {
			$i =0;
			foreach ( $data as $val ) {
				//if ( $p_bu_id == $val['bu'] ) {
					$reformed_data[$i] = $val;
					$i++;
				//}
			}
		}
		
		return $reformed_data;
		//dump_array($data);
	}

	public function updateOutstanding($p_outstanding_flag,$p_action_id) {

		$sql = sprintf("UPDATE %s.actions SET outstanding = '%s' WHERE ID = %d ",_DB_OBJ_FULL,$p_outstanding_flag,$p_action_id);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_outstanding_flag);
		$pStatement->bindParam(2,$p_action_id);*/

		$pStatement->execute();
	}

	public function getAction($p_action_id,$p_action_type,$p_inspID) {


$sql = sprintf("SELECT * FROM %s.inspection_metadata  where subStep = %d and tab=%d and inspectionID=%d",_DB_OBJ_FULL,$p_action_id,$p_action_type,$p_inspID);

$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$resultSet1 = $pStatement->fetch(PDO::FETCH_ASSOC);


	$sql = sprintf("SELECT * FROM %s.actions where ID=%d",_DB_OBJ_FULL,$resultSet1["actionID"]);
$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



$resultSet[expectation]=$resultSet1[expectation];


/*
should work but did not
	$sql = sprintf("SELECT * FROM %s.actions inner join %s.inspection_metadata on %s.actions.ID= actionID WHERE subStep = %d and tab=%d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_action_id,$p_action_type);
echo $sql;
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
*/
		return $resultSet;
	}

}
?>