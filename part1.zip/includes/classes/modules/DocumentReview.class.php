<?php
 /**
  $Id: DocumentAlert.class.php,v 3.68 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This object define the various operations related with Document Alert object
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Document
  * @since  Saturday, September 11, 2010 2:16:06 PM>
  */

class DocumentReview
{
	private $docInfo;
        private $reviewID;
         private $dbHand;
	/*
	 * This method is used to set information to perform various operations.
	 *
	 * @param $p_alertId integer	Unique alert id
	 * @param $p_alertInfo array	Alert information to be used by obect to perform crud operations
	 *
	 * @access public
	 */
        
            public function __construct() {
        $this->dbHand = DB::connect(_DB_TYPE);
           }
           
           
	public function setReviewInfo($p_reviewId,$p_reviewInfo) {
$this->reviewID=$p_reviewId;
$this->docInfo=$p_reviewInfo;
	}

	/*
	 * This method is used to add an alert.
	 *
	 * @access public
	 */
	 

	
	public function addReview() {
		$docObj=new documents();
		
                $userid= getLoggedInUserId();
                
                $docData = $docObj->getDocData($this->docInfo["doc_id"]);

          
  $sql = sprintf("INSERT INTO %s.cms_document_reviews (cmsdocID,reviewRaisedBy,reviewComment,documentID,reviewStatus,reviewWhen,reviewfile)
     VALUES (%d,%d,'%s',%d,%d,'%s','%d')", _DB_OBJ_FULL,$this->docInfo["doc_id"],$userid,$this->docInfo["document_comment"],$docData["documentID"],0, date('Y-m-d'),$this->docInfo["file_id"]);
    
            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
           $review_id = customLastInsertId($this->dbHand, 'cms_document_reviews', 'reviewID'); 
            return $review_id;
	}

	/*
	 * This method is used to edit an alert
	 *
	 * @access public
	 */
	public function editReview() {

	}

	/*
	 * This method is used to delete an alert
	 *
	 * @access public
	 */
	public function deleteReview() {

	}
        
        	public function displayReviewbyID($id) {
  $sql = sprintf("SELECT R.*,D.*,P.forename+' '+P.surname as pname from %s.cms_document_reviews R left join %s.cms_documents D on R.cmsdocid=D.cmsdocid left join %s.participant_database P  on R.currentwho=P.participantID  where R.reviewID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$id);
    
            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
            $results = $stmt->fetch(PDO::FETCH_ASSOC);

        return $results;
	}
                	public function displayReviews() {
                            
 $sql = sprintf("SELECT R.*,D.*,P.forename+' '+P.surname as pname from %s.cms_document_reviews R left join %s.cms_documents D on R.cmsdocid=D.cmsdocid left join %s.participant_database P  on R.currentwho=P.participantID  where R.reviewstatus in (0,1)", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
    
            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
            $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);

        return $results;
	}
        
        		  public function setReviewProgress($id,$status) {    
    		$sql = sprintf("update %s.cms_document_reviews set reviewstatus= %d where reviewID =%d ", _DB_OBJ_FULL , $status,$id);

		    $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
        }
        
                		  public function updateCurrentYou($id,$p_id) {    
    		$sql = sprintf("update %s.cms_document_reviews set currentwho= %d where reviewID =%d ", _DB_OBJ_FULL , $p_id,$id);

		    $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
        }
		
		        		  public function endReview($id,$status,$reviewdate='') {    
    		$sql = sprintf("update %s.cms_document_reviews set reviewstatus= %d ,reviewdate='%s' where reviewID =%d ", _DB_OBJ_FULL , $status,format_date($reviewdate),$id);

		    $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
        }
        

        public function updateReviewer() {    
    		$sql = sprintf("update %s.cms_document_reviews set reviewer= %d,currentwho=%d,publisherComment='%s' ,reviewfile=%d,reviewstatus= 1 where reviewID =%d ", _DB_OBJ_FULL , $this->docInfo["reviewer"], $this->docInfo["reviewer"],$this->docInfo["document_comment"],$this->docInfo["file_id"],$this->reviewID);

		    $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
        }
        
                		        		  public function exporttolist() {    
$retData=$this->displayReviews();

        return $retData;
        }
        
        public function getDocumentListActionTracker() {
$retData=$this->displayReviews();
if(is_array($retData))
        return count($retData);
    else {
    return 0;    
    }
    }
}
?>