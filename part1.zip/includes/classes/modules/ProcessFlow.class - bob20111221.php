<?php
 /**
  $Id: ProcessFlow.class.php,v 10.0 Saturday, February 05, 2011 1:26:07 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 2:57:54 PM>
  */

require_once "ProcessObject.class.php";

class ProcessFlow
{
	private $pfObject;
	private $img;
	private $canvasWidth;
	private $canvasHeight;
	private $lineThickness;
	private $outlineThickness;
	private $noOfAlternatePaths;
	private $processData;
	private $businessUnitColumnWidth;
	private $blockWidth;
	private $blockHeight;
	private $maxLevel;
	private $maxDepth;
	private $colours;
	private $flagShowGrid;
	private $altPathTotal;
	private $objectWidth; // in case of rectangle
	private $objectHeight; // in case of rectangle
	private $objectVertex;  // in case of diamond, traingle
	private $objectGap;

	private $debugMode;

	private $resample;
	private $resamplePercent;

	private $xOffsetAltFirstPath;
	private $xOffsetAltSecondPath;
	private $xOffsetAltThirdPath;
	private $xOffsetAltFourthPath;
	private $subprocessOffset;
	private $businessUnitFontSize;
	private $fontFile;
	private $hasInterProcessReferences;
	private $outputType; // N None, H Horizontal, V Vertical

	private $outputFile; // to save the image
	private $horizontalOffsetPool;
	private $shadeOffset;
	private $hasEndLozenge;

	public function __construct($p_debugMode=false,$p_resample=false,$p_type='N') {

		$this->outputType				= $p_type;
		$this->debugMode 				= $p_debugMode;
		$this->visualdebug 		= false;
		$this->resample 					= (boolean) $p_resample;
		$this->resamplePercent 	= 0.60;

		if (!$this->debugMode) {
			header('Content-type: image/png');
		}

		putenv('GDFONTPATH=' . realpath('.'));
		$this->fontFile 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arialbd.ttf';
		$this->fontFile_2 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arial.ttf';
		$this->fontFile_3 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/ariblk.ttf';

		$this->canvasWidth					= 0; // in px
		$this->canvasHeight					= 0; // in px
		$this->lineThickness				= 1; // in px, Please do not change this property. It is purely used for calculation only.

        if ( $p_type == 'H' ) {
            $this->outlineThickness				= 3; // in px
        } else {
            $this->outlineThickness				= 1; // in px
        }


		$this->maxLevel = 0; // columns
		$this->maxDepth = 6;

		if ( $this->outputType == 'H' )  {
			$this->businessUnitColumnWidth 		= 380; //in px
			$this->businessUnitFontSize			= 11;

			$this->objectWidth 		= 240;
			$this->objectHeight 	= 90;

			$this->objectGap 		= 45; // in px
		} else {
			$this->businessUnitColumnWidth 		= 280; //in px
			$this->businessUnitFontSize			= 9;

			$this->objectWidth 		= 60;
			$this->objectHeight 	= 30;

			$this->objectGap 		= 15; // in px
		}

		$this->flagShowGrid		= true;
		$this->altPathTotal		= 0;

		$this->business_units 	= array();
		$this->block_information;
		$this->block_path_information_expanded;

		$this->xOffsetMainPath 			= 0;
		$this->xOffsetAltFirstPath 		= 30;
		$this->xOffsetAltSecondPath 	= 15;
		//		$this->xOffsetAltSecondPath 	= 30;
		$this->xOffsetAltThirdPath 		= -15;
		$this->xOffsetAltFourthPath 	= -30;

		$this->yOffsetMainPath 			= 0;
		$this->yOffsetAltFirstPath 		= 35;
		$this->yOffsetAltSecondPath 	= 38;
		$this->yOffsetAltThirdPath 		= 42;
		$this->yOffsetAltFourthPath 	= -30;

		$this->subprocessOffset 		= 5;
		$this->headerHeight 			= 140;

		$this->horizontalOffsetPool					= array();
		$this->horizontalOffsetPool[0]['offset']	= 0;
		$this->horizontalOffsetPool[0]['used']		= 0;
		$this->horizontalOffsetPool[0]['steps']		= array();

		$this->horizontalOffsetPool[1]['offset']	= 10;
		$this->horizontalOffsetPool[1]['used']		= 0;
		$this->horizontalOffsetPool[1]['steps']		= array();

		$this->horizontalOffsetPool[2]['offset']	= 20;
		$this->horizontalOffsetPool[2]['used']		= 0;
		$this->horizontalOffsetPool[2]['steps']		= array();

		$this->horizontalOffsetPool[3]['offset']	= -10;
		$this->horizontalOffsetPool[3]['used']		= 0;
		$this->horizontalOffsetPool[3]['steps']		= array();

		$this->horizontalOffsetPool[4]['offset']	= -20;
		$this->horizontalOffsetPool[4]['used']		= 0;
		$this->horizontalOffsetPool[4]['steps']		= array();

		$this->horizontalOffsetPool[5]['offset']	= -30;
		$this->horizontalOffsetPool[5]['used']		= 0;
		$this->horizontalOffsetPool[5]['steps']		= array();

		$this->horizontalOffsetPool[6]['offset']	= 30;
		$this->horizontalOffsetPool[6]['used']		= 0;
		$this->horizontalOffsetPool[6]['steps']		= array();

		$this->horizontalOffsetPool[7]['offset']	= -40;
		$this->horizontalOffsetPool[7]['used']		= 0;
		$this->horizontalOffsetPool[7]['steps']		= array();

		$this->horizontalOffsetPool[8]['offset']	= -40;
		$this->horizontalOffsetPool[8]['used']		= 0;
		$this->horizontalOffsetPool[8]['steps']		= array();

		$this->horizontalOffsetPool[9]['offset']	= -50;
		$this->horizontalOffsetPool[9]['used']		= 0;
		$this->horizontalOffsetPool[9]['steps']		= array();

		$this->shadeOffset = 5;
	}

	private function getMaxLevel() {

		if ( count($this->block_path_information_expanded) ) {
			foreach ( $this->block_path_information_expanded as $block_information_ele ) {

				foreach ( $block_information_ele as $block_information_ele_next ) {
					if ( $block_information_ele_next[1] > $this->maxLevel ) {
						$this->maxLevel = $block_information_ele_next[1];
					}
				}
			}
		}
	}

	private function getMaxdepth() {

		$interProcessAltPath 	= false;

		$this->maxDepth 		= count($this->business_units);

		for ( $i=0;$i<count($this->block_information);$i++) {

			$path_information_arr = explode('~#~',$this->block_information[$i]['path_information']);

			$k = 0;

			if ( count($path_information_arr) ) {
				foreach ( $path_information_arr as $path_information_ele ) {
					$step_data_arr = explode(':',$path_information_ele);

					$this->block_path_information_expanded[$i][$k++] = $step_data_arr;

				} // end foreach loop
			}
		} // end for loop

		if ( $this->hasInterProcessReferences ) {
			$this->maxDepth = $this->maxDepth + 2;
		}
				if ( $this->maxDepth ==1 ) {
			$this->maxDepth =2;
		}
	}

	public function getPFdepth() {
		return $this->maxDepth;
	}

    public function gdecho() {

        $w = 100;
        $h = 100;
        $im = imagecreatetruecolor($w,$h);
        $white = imagecolorallocate($im, 255, 255, 255);

        // Draw a white rectangle
        imagefilledrectangle($im, 4, 4, $w-5, $h-5, $white);

        // Save the image
        imagepng($im);
        imagedestroy($im);
        return true;
    }

	public function setInformation($p_business_units,$p_blocks_information,& $p_procObj) {

        //$this->gdecho(); return false;
        $this->pfObject 					= $p_procObj;

		$this->hasEndLozenge				= $this->pfObject->getEndLozengeCount($this->pfObject->getCurrentProcessFlow());
		$this->hasInterProcessReferences 	= false;

		$p_business_units 					= array_unique($p_business_units);

		if ( count($p_business_units) ) {
			$k = 0;
			foreach ( $p_business_units as $p_business_units_ele ) {
				$business_units[chr(65+$k++)] = $p_business_units_ele;
			}
		}

        $this->business_units				= & $business_units;

		$this->block_information 			= $p_blocks_information;
		$this->altPathTotal					= count($this->block_information) - 1;

		if ( count($this->block_information[0]['step_information']) ) {
			foreach ( $this->block_information[0]['step_information'] as $block_information_step_ele ) {
				if ( $block_information_step_ele['intraProcess'] || $block_information_step_ele['interProcess'] ) {
					$this->hasInterProcessReferences = true;
					break;
				}
			}
		}

		// get maximum depth of the process flow
		$this->getMaxdepth();

        $total_paths 			= $this->altPathTotal + 1;

		if ( $this->outputType == 'H' ) {
			$this->blockWidth		= 300;
		} else {
			$this->blockWidth		= 150;
		}

		$this->blockHeight		= ($total_paths*$this->objectHeight) + (($total_paths+1)*$this->objectGap); // for 15px gap and 30px per object

		/* Get max level from data */
		$this->getMaxLevel();

		if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
			$this->maxLevel++;       // one extra column for end lozenge
		}

		$this->canvasWidth		= $this->businessUnitColumnWidth + ($this->blockWidth * $this->maxLevel) + $this->lineThickness*($this->maxLevel+2);

		if ( $this->outputType == 'N' )  {
			$this->canvasHeight		= ($this->blockHeight * $this->maxDepth) + $this->lineThickness*($this->maxDepth+2);
		} else {
			$this->canvasHeight		= $this->headerHeight + ($this->blockHeight * $this->maxDepth) + $this->lineThickness*($this->maxDepth+2)+250;
		}

        $this->img = imagecreatetruecolor($this->canvasWidth,$this->canvasHeight)
			  or die('Cannot Initialize new GD image stream');

        //$this->img = @imagecreatetruecolor(100,100);


		$bcolour 		= $this->hex2RGB('#0D830D');
		$bglosscolour 	= $this->hex2RGB('#219B21');
		$bgloss2colour 	= $this->hex2RGB('#63C563');
		$boutputcolour 	= $this->hex2RGB('#EDFCC8');

		$dcolour 		= $this->hex2RGB('#EFB31F');
		$dglosscolour 	= $this->hex2RGB('#F4D27E');
		$dgloss2colour 	= $this->hex2RGB('#F8F0DF');
		$doutputcolour 	= $this->hex2RGB('#FCF0C8');

		$shadcolour 	= $this->hex2RGB('#a1a1a1');
		$shadcolour2 	= $this->hex2RGB('#cccccc');
		$scolour 		= $this->hex2RGB('#8DEEEE');
		$lcolour 		= $this->hex2RGB('#9370DB');
		$mpcolour		= $this->hex2RGB('#000000');
		/*		
		$a1pcolour 		= $this->hex2RGB('#8B8B00');
		$a2pcolour 		= $this->hex2RGB('#CDBE70');
		$a3pcolour 		= $this->hex2RGB('#CDAA7D');
		*/
		$a1pcolour 		= $this->hex2RGB('#C73633');
		$a2pcolour 		= $this->hex2RGB('#0265CB');
		$a3pcolour 		= $this->hex2RGB('#A305BA');
		
		$a4pcolour 		= $this->hex2RGB('#CD3700');
		$a5pcolour 		= $this->hex2RGB('#388E8E');
		$a10pcolour 	= $this->hex2RGB('#CD4002');
		
		$gccolour 		= $this->hex2RGB('#dddddd');
		$txcolour 		= $this->hex2RGB('#202020');
		$bgcolour 		= $this->hex2RGB('#F7F7F7');
		$sbpcolour 		= $this->hex2RGB('#Ff0000');

		// colours for CCP and CMS Reference
		$ccpcolour 		= $this->hex2RGB('#Ff0000');
		$ccpsubcolour 	= $this->hex2RGB('#Ff8000');		
		$cmsrcolour 	= $this->hex2RGB('#ff0000');
		$whitecolour 	= $this->hex2RGB('#ffffff');


		$this->colours['shadow_colour'] 			= imagecolorallocate($this->img,$shadcolour['red'], $shadcolour['green'], $shadcolour['blue']);
		$this->colours['shadow2_colour'] 			= imagecolorallocate($this->img,$shadcolour2['red'], $shadcolour2['green'], $shadcolour2['blue']);
		$this->colours['action_colour'] 			= imagecolorallocate($this->img,$bcolour['red'], $bcolour['green'], $bcolour['blue']);
		$this->colours['action_gloss_colour'] 		= imagecolorallocate($this->img,$bglosscolour['red'], $bglosscolour['green'], $bglosscolour['blue']);
		$this->colours['action_gloss2_colour'] 		= imagecolorallocate($this->img,$bgloss2colour['red'], $bgloss2colour['green'], $bgloss2colour['blue']);
		$this->colours['action_output_colour'] 		= imagecolorallocate($this->img,$boutputcolour['red'], $boutputcolour['green'], $boutputcolour['blue']);


		$this->colours['decision_colour']			= imagecolorallocate($this->img,$dcolour['red'], $dcolour['green'], $dcolour['blue']);
		$this->colours['decision_gloss_colour']		= imagecolorallocate($this->img,$dglosscolour['red'], $dglosscolour['green'], $dglosscolour['blue']);
		$this->colours['decision_gloss2_colour']	= imagecolorallocate($this->img,$dgloss2colour['red'], $dgloss2colour['green'], $dgloss2colour['blue']);
		$this->colours['decision_output_colour']	= imagecolorallocate($this->img,$doutputcolour['red'], $doutputcolour['green'], $doutputcolour['blue']);

		$this->colours['support_colour'] 			= imagecolorallocate($this->img,$scolour['red'], $scolour['green'], $scolour['blue']);
		$this->colours['lozenge_colour'] 			= imagecolorallocate($this->img,$lcolour['red'], $lcolour['green'], $lcolour['blue']);
		$this->colours['main_path_colour'] 			= imagecolorallocate($this->img,$mpcolour['red'], $mpcolour['green'], $mpcolour['blue']);
		$this->colours['alt1_path_colour'] 			= imagecolorallocate($this->img,$a1pcolour['red'], $a1pcolour['green'], $a1pcolour['blue']);
		$this->colours['alt2_path_colour'] 			= imagecolorallocate($this->img,$a2pcolour['red'], $a2pcolour['green'], $a2pcolour['blue']);
		$this->colours['alt3_path_colour'] 			= imagecolorallocate($this->img,$a3pcolour['red'], $a3pcolour['green'], $a3pcolour['blue']);
		$this->colours['alt4_path_colour'] 			= imagecolorallocate($this->img,$a4pcolour['red'], $a4pcolour['green'], $a4pcolour['blue']);
		$this->colours['alt5_path_colour'] 			= imagecolorallocate($this->img,$a5pcolour['red'], $a5pcolour['green'], $a5pcolour['blue']);
		$this->colours['alt10_path_colour'] 		= imagecolorallocate($this->img,$a10pcolour['red'], $a10pcolour['green'], $a10pcolour['blue']);

		$this->colours['grid_colour'] 				= imagecolorallocate($this->img,$gccolour['red'], $gccolour['green'], $gccolour['blue']);
		$this->colours['text_colour'] 				= imagecolorallocate($this->img,$txcolour['red'], $txcolour['green'], $txcolour['blue']);
		$this->colours['background_colour'] 		= imagecolorallocate($this->img,$bgcolour['red'], $bgcolour['green'], $bgcolour['blue']);
		$this->colours['sub_process_colour']		= imagecolorallocate($this->img,$sbpcolour['red'], $sbpcolour['green'], $sbpcolour['blue']);

		$this->colours['ccp_colour']				= imagecolorallocate($this->img,$ccpcolour['red'], $ccpcolour['green'], $ccpcolour['blue']);
		$this->colours['ccp_sub_colour']				= imagecolorallocate($this->img,$ccpsubcolour['red'], $ccpsubcolour['green'], $ccpsubcolour['blue']);
		$this->colours['cmsr_colour']				= imagecolorallocate($this->img,$cmsrcolour['red'], $cmsrcolour['green'], $cmsrcolour['blue']);
		$this->colours['white_colour']				= imagecolorallocate($this->img,$whitecolour['red'], $whitecolour['green'], $whitecolour['blue']);

		//imagestring($this->img, 1, 5, 5,  'A Simple Text String',$action_colour);

	}

	private function hex2RGB($hexStr, $returnAsString = false, $seperator = ',') {

		$hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
		$rgbArray = array();

		if (strlen($hexStr) == 6) { //If a proper hex code, convert using bitwise operation. No overhead... faster
			$colorVal = hexdec($hexStr);
			$rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
			$rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
			$rgbArray['blue'] = 0xFF & $colorVal;
		} elseif (strlen($hexStr) == 3) { //if shorthand notation, need some string manipulations
			$rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
			$rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
			$rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
		} else {
			return false; //Invalid hex color code
		}

		return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
	}

    public function showExternalImage($x1, $y1,$type='action') {

        switch ($type) {
            case 'action': $icon_bg_file = _MYROOT.'images/action_bg.png'; break;
            case 'decision': $icon_bg_file = _MYROOT.'images/decision_bg.png'; break;
            case 'support': $icon_bg_file = _MYROOT.'images/support_bg.png'; break;
            case 'ccp': $icon_bg_file = _MYROOT.'images/ccp_icon.png'; break;
            case 'cmsr': $icon_bg_file = _MYROOT.'images/cmsr_icon.png'; break;
            case 'sbp': $icon_bg_file = _MYROOT.'images/cmsr_icon.png';
        }

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefrompng($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, $x1-5, $y1, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }
    }

	public function drawCanvas() {
		imagefilledrectangle($this->img,0,0,$this->canvasWidth,$this->canvasHeight,$this->colours['background_colour']);
		if ( $this->outputType == 'H' )  {
imagerectangle($this->img,0,$this->canvasHeight-200,$this->canvasWidth,$this->colours['background_colour']);
}
		imagerectangle($this->img,0,0,($this->canvasWidth-$this->lineThickness),($this->canvasHeight-$this->lineThickness),$this->colours['grid_colour']);
		


        if ( $this->outputType == 'H' )  {
			$y1 = $this->lineThickness + $this->headerHeight;
		} else {
			$y1 = 0;
		}

		$y2 = $this->canvasHeight - 1;

		// show grid for idea
		if ($this->flagShowGrid) {

			// vertical
			for ($i=0;$i<$this->maxLevel;$i++) {

                $x1 = $x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
                imageline($this->img,$x1-1,$y1,$x2-1,$y2,$this->colours['grid_colour']);
                imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
                imageline($this->img,$x1+1,$y1,$x2+1,$y2,$this->colours['grid_colour']);
			}


			$x1 = 0;
			$x2 = $this->canvasWidth - 1;

			if ( $this->outputType == 'H' )  {

				$y1 = $y2 = $this->headerHeight;
				imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
			}

			// horizontal
			for ($i=0;$i<$this->maxDepth;$i++) {

				//$x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
				if ( $this->outputType == 'H' )  {
                    $y1 = $y2 = $this->headerHeight + $this->lineThickness + ($this->blockHeight * $i);

                    if ( $i == 0 ) {
                        imageline($this->img,$x1,$y1-2,$x2,$y2-2,$this->colours['grid_colour']);
                        imageline($this->img,$x1,$y1-1,$x2,$y2-1,$this->colours['grid_colour']);
                        imageline($this->img,$x1,$y1+1,$x2,$y2+1,$this->colours['grid_colour']);
                        imageline($this->img,$x1,$y1+2,$x2,$y2+2,$this->colours['grid_colour']);
                    }
				} else {
					$y1 = $y2 = $this->lineThickness + ($this->blockHeight * $i);

				}

                imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
			}

		}


		if ($this->visualdebug) {

			// vertical
			for ($i=0;$i<$this->maxLevel;$i++) {

				$x1 = $x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
				$y1 = 0;
				$y2 = $this->canvasHeight - 1;

				// horizontal
				for ($k=0;$k<$this->maxDepth;$k++) {

					$xk1 = 0;
					$xk2 = $this->canvasWidth - 1;

					//$x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
					$yk1 = $yk2 = $this->lineThickness + ($this->blockHeight * $k);

					imagefttext($this->img, 45, 0, $x1+$xk1, $yk1-20, $this->colours['grid_colour'], $this->fontFile,chr($k+64).($i+1));
				}
			}
		}

		// vertical
		$k = 1;
		foreach ( $this->business_units as $business_unit_ele_key=>$business_unit_ele_value ) {

			$x1 = $this->lineThickness + 6;

			if ( $this->outputType == 'H' )  {
				$y1 = $this->headerHeight + $this->lineThickness + $k*($this->lineThickness) + (($k-1)*$this->blockHeight) + 20;
			} else {
				$y1 = $k*($this->lineThickness) + (($k-1)*$this->blockHeight) + 20;
			}


			$k++;

			$business_unit_arr = explode('|',$business_unit_ele_value);
			$business_unit_name = $business_unit_arr[0];
            //$business_unit_name = $business_unit_arr[0].'-'.$business_unit_arr[1];


			if ( strlen($business_unit_name) > 22 ) {

				$strings 	= wordwrap($business_unit_name, 22, "#", false);
				$string_arr = explode("#",$strings);

				$cy1 = $y1 + ($this->blockHeight*0.5)-(18*count($string_arr));

				foreach ( $string_arr as $strele ) {
					//imagestring($this->img, $this->businessUnitFontSize, $x1, $cy1,$strele,$this->colours['text_colour']);
					imagefttext($this->img, $this->businessUnitFontSize,0, $x1, $cy1, $this->colours['text_colour'], $this->fontFile,$strele);
					$cy1 = $cy1 + 18;
				}

			} else {
			
			 $cy1 = $y1 + $this->blockHeight*0.5-6;
				//imagestring($this->img, $this->businessUnitFontSize, $x1, $y1,$business_unit_ele_value,$this->colours['text_colour']);
				imagefttext($this->img, $this->businessUnitFontSize, 0, $x1, $cy1, $this->colours['text_colour'], $this->fontFile,$business_unit_name);
			}
		}
		//dump_array($this);
	}

	public function drawObjects() {

		try {

			$k = 0;
            foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				foreach ( $block_information_arr as $business_unit_ele_value ) {

					$block_record_granules  = explode(':',$business_unit_ele_value);

					$step_information = $block_step_information[$block_record_granules[3]];

					/*echo $step_information['type'];
					dump_array($block_record_granules);*/

					$context_level = $block_record_granules[0];
					$context_code	= $context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

					if (!$k) {

						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$start_context_code = $context_level.':1:0';

						if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
							// start lozenge
							ProcessObject::DrawObject('LOZENGE',$this,$start_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'START',$block_step_information);
						}

						$k++;
					}

					if ( $block_record_granules[2] == 0 ) {
						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$context_code_main_path = $context_code;
					} else {
						$main_path = false;
						$alt_path = true;
						$lozenge = 'NA';
					}

					$intraprocess_goto_link_data = $this->pfObject->intraprocess_goto_link_information();
					$intraprocess_goto_link = true;

					// code block for intra process flow
					if ( $block_record_granules[5] == 'IN' || $block_record_granules[5] == 'OUT' || $block_record_granules[5] == 'EXIN' || $block_record_granules[5] == 'EXOUT' ) {

						$outer_context_code = chr($this->maxDepth+64).':'.$block_record_granules[1].':0';

						//echo $block_record_granules[4].'->'.$outer_context_code;
						if ( $block_record_granules[6] != $this->pfObject->getCurrentProcessFlow() && ( $block_record_granules[5] == 'EXOUT' || $block_record_granules[5] == 'EXIN' ) ) {
							ProcessObject::DrawObject($block_record_granules[5].'PROCESS',$this,$outer_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$block_record_granules[5],$block_step_information[$block_record_granules[3]],$this->outputType);
						}
					}

					switch($step_information['type']) {
						case 'A' : $node_type = 'ACTION'; break;
						case 'D' : $node_type = 'DECISION'; break;
						case 'S' : $node_type = 'SUPPORT'; break;
					}

					ProcessObject::DrawObject($node_type,$this,$context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
				} // end inner foreach

			} // end outer foreach

			if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
				// stop lozenge
				ProcessObject::DrawObject('LOZENGE',$this,$context_code_main_path,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information[$block_record_granules[3]]);
			}

			// repeat loop for support module
			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				if ( $block_information_ele['support_information'] != '' && count($block_support_information_arr) ) {
					foreach ( $block_support_information_arr as $block_support_information_ele ) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_ele);
						$block_record_granules  = explode(':',$block_support_start_end_information_arr[1]);

						$step_information = $block_step_information[$block_record_granules[3]];
						$support_context_level = $block_record_granules[0];
						$support_context_code	= $support_context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

						if ( $block_record_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';

							$context_code_main_path = $context_code;
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						//if ( $this->outputType == 'N' )  {
							$node_type = 'SUPPORT';
							ProcessObject::DrawObject($node_type,$this,$support_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
						//}
					} // end inner foreach 2*/

				} // end outer foreach
			} // end if


		} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}
	}


	public function drawShadowObjects() {

		try {

			$k = 0;
			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				foreach ( $block_information_arr as $business_unit_ele_value ) {

					$block_record_granules  = explode(':',$business_unit_ele_value);

					$step_information = $block_step_information[$block_record_granules[3]];

					/*echo $step_information['type'];
					dump_array($block_record_granules);*/

					$context_level = $block_record_granules[0];
					$context_code	= $context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

					if (!$k) {

						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$start_context_code = $context_level.':1:0';

						if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
							// start lozenge
							ProcessObject::DrawShadowObject('LOZENGE',$this,$start_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'START',$block_step_information);
						}

						$k++;
					}

					if ( $block_record_granules[2] == 0 ) {
						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$context_code_main_path = $context_code;
					} else {
						$main_path = false;
						$alt_path = true;
						$lozenge = 'NA';
					}

					$intraprocess_goto_link_data = $this->pfObject->intraprocess_goto_link_information();
					$intraprocess_goto_link = true;

					// code block for inter process flow
					if ( $block_record_granules[5] == 'IN' || $block_record_granules[5] == 'OUT' || $block_record_granules[5] == 'EXIN' || $block_record_granules[5] == 'EXOUT' ) {

						$outer_context_code = chr($this->maxDepth+64).':'.$block_record_granules[1].':0';

						//echo $block_record_granules[4].'->'.$outer_context_code;
						if ( $this->outputType == 'N' && $block_record_granules[6] != $this->pfObject->getCurrentProcessFlow() && ( $block_record_granules[5] == 'EXOUT' || $block_record_granules[5] == 'EXIN' )  ) {
							ProcessObject::DrawShadowObject($block_record_granules[5].'PROCESS',$this,$outer_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$block_record_granules[5],$block_step_information[$block_record_granules[3]]);
						}
					}

					switch($step_information['type']) {
						case 'A' : $node_type = 'ACTION'; break;
						case 'D' : $node_type = 'DECISION'; break;
						case 'S' : $node_type = 'SUPPORT'; break;
					}

					ProcessObject::DrawShadowObject($node_type,$this,$context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
				} // end inner foreach

			} // end outer foreach

			if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
				// stop lozenge
				ProcessObject::DrawObject('LOZENGE',$this,$context_code_main_path,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information[$block_record_granules[3]]);
			}

			// repeat loop for support module
			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				if ( $block_information_ele['support_information'] != '' && count($block_support_information_arr) ) {
					foreach ( $block_support_information_arr as $block_support_information_ele ) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_ele);
						$block_record_granules  = explode(':',$block_support_start_end_information_arr[1]);

						$step_information = $block_step_information[$block_record_granules[3]];
						$support_context_level = $block_record_granules[0];
						$support_context_code	= $support_context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

						if ( $block_record_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';

							$context_code_main_path = $context_code;
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						//if ( $this->outputType == 'N' )  {
							$node_type = 'SUPPORT';
							ProcessObject::DrawShadowObject($node_type,$this,$support_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
						//}
					} // end inner foreach 2*/

				} // end outer foreach
			} // end if


		} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}
	}

public function drawfooter() {

        /*$logo_file = _MYROOT.'images/logosmall.jpg';

		if ( file_exists($logo_file) ) {

			$src = imagecreatefromjpeg($logo_file);
			$size_information = getimagesize($logo_file);

			// copy
			imagecopy($this->img, $src, 10, 10, 0, 0,$size_information[0], $size_information[1]);

			// free memory
			imagedestroy($src);
		}*/

		$process_information = $this->pfObject->getCurrentProcessFlowInformation();

        $label['business_owner'] 	= 'BU Owner:';
        $label['risk_rating'] 		= 'Risk Rating';
		$label['process_ref'] 		= 'Process Ref. :';
		$label['process_desc'] 		= 'Process Desc. :';
		$label['hazard_symbol'] 	= 'Hazard Symbol :';
		$label['control_symbol'] 	= 'Control Symbol :';


   $icon_bg_file = _MYROOT.'images/legendfooter1.png';
       

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefrompng($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 200, $this->canvasHeight-230, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }
		
		 $icon_bg_file = _MYROOT.'images/legendfooter2.png';
       

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefrompng($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 210, $this->canvasHeight-130, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }
		//imagefttext($this->img, 20, 0, 250, 1220, $this->colours['text_colour'], $this->fontFile,"Dimond");




       /* imagefttext($this->img, 20, 0, 25, 50, $this->colours['text_colour'], $this->fontFile,$label['business_owner']);
		////imagefttext($this->img, $this->businessUnitFontSize, 0, 580, 50, $this->colours['text_colour'], $this->fontFile,$label['risk_rating']);

		imagefttext($this->img, 20, 0, 170, 50, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);*/

}





	public function drawHeader() {

        /*$logo_file = _MYROOT.'images/logosmall.jpg';

		if ( file_exists($logo_file) ) {

			$src = imagecreatefromjpeg($logo_file);
			$size_information = getimagesize($logo_file);

			// copy
			imagecopy($this->img, $src, 10, 10, 0, 0,$size_information[0], $size_information[1]);

			// free memory
			imagedestroy($src);
		}*/

		$process_information = $this->pfObject->getCurrentProcessFlowInformation();

        $label['business_owner'] 	= 'BU Owner:';
        $label['risk_rating'] 		= 'Risk Rating';
		$label['process_ref'] 		= 'Process Ref. :';
		$label['process_desc'] 		= 'Process Desc. :';
		$label['hazard_symbol'] 	= 'Hazard Symbol :';
		$label['control_symbol'] 	= 'Control Symbol :';
$icon_bg_file = _MYROOT.'images/logo.jpg';
       
 if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefromjpeg($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 25, 0, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }


        imagefttext($this->img, $this->businessUnitFontSize, 0, 25, 70, $this->colours['text_colour'], $this->fontFile,$label['business_owner']);
		////imagefttext($this->img, $this->businessUnitFontSize, 0, 580, 50, $this->colours['text_colour'], $this->fontFile,$label['risk_rating']);


		$p_content_strlen = strlen($process_information['buName']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($this->img, $this->businessUnitFontSize, 0, 110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
		} else {

			$strings 	= substr($process_information['buName'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
				
			
			}

		
		
	

		imagefttext($this->img, $this->businessUnitFontSize, 0, 1000, 70, $this->colours['text_colour'], $this->fontFile,$label['process_ref']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 500, 70, $this->colours['text_colour'], $this->fontFile,$label['process_desc']);

		$p_content_strlen = strlen($process_information['description']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);
		} else {

			$strings 	= substr($process_information['description'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$strings);
				
			
			}

		$p_content_strlen = strlen($process_information['reference']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
				imagefttext($this->img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		} else {

			$strings 	= substr($process_information['reference'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
				
			
			}


		//imagefttext($this->img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		//imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);



		imagefttext($this->img, $this->businessUnitFontSize, 0, 25, 105, $this->colours['text_colour'], $this->fontFile,$label['hazard_symbol']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 650, 105, $this->colours['text_colour'], $this->fontFile,$label['control_symbol']);

		$symbols 			= $this->pfObject->getHazardControlSymbols();

		$hazard_symbols		= $symbols['hazard'];
		$control_symbols 	= $symbols['control'];

        ///$hazard_symbols = array('ha2.jpg','ha20.jpg','ha21.jpg','ha22.jpg','ha23.jpg','ha24.jpg','ha25.jpg','ha26.jpg','ha27.jpg');
        ///$control_symbols = array('2.jpg','20.jpg','21.jpg','22.jpg','23.jpg','24.jpg','25.jpg','26.jpg','27.jpg');

		$max_symbol_count 	= 15;
		if ( 1 && count($hazard_symbols) ) {

			$k = 0;
			foreach ( $hazard_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../hazard') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+280)+($k*6);
					imagecopy($this->img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		if ( 1 && count($control_symbols) ) {

			$k = 0;
			foreach ( $control_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../improvement') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+735)+($k*6);
					imagecopy($this->img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		imagefilledrectangle($this->img, $this->canvasWidth - 130, 65, $this->canvasWidth - 106, 100, $this->colours['action_colour']);
		imagefilledrectangle($this->img, $this->canvasWidth - 104, 65, $this->canvasWidth - 86, 100, $this->colours['action_colour']);
		imagefilledrectangle($this->img, $this->canvasWidth - 84, 65, $this->canvasWidth - 55, 100, $this->colours['action_colour']);
		imagefttext($this->img, 24, 0, $this->canvasWidth - 130, 95, $this->colours['white_colour'], $this->fontFile,'C I A');

		$risk_rating 		= $this->pfObject->getRiskRating();

        $risk_rating['riskRating1'] = 'R';
		$risk_rating['riskRatingColor1'] = '#00ff00';

		if ( $risk_rating['riskRating1'] != '' && $risk_rating['riskRating1'] != '#' ) {

			$risk_rating_rgb 	= $this->hex2RGB($risk_rating['riskRatingColor1']);
			$risk_rating_colour = imagecolorallocate($this->img,$risk_rating_rgb['red'], $risk_rating_rgb['green'],$risk_rating_rgb['blue']);

            $x = $this->canvasWidth - 84;

			imagefilledrectangle($this->img, $x, 20, $x+30, 55, $risk_rating_colour);
			imagefttext($this->img, 24, 0, $x+5, 50, $this->colours['white_colour'], $this->fontFile,$risk_rating['riskRating1']);
		}

	}

	public function drawPaths() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';

		try {

			foreach ($this->block_information as $block_information_ele ) {
			
				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				//$k = 0;
				$block_information_elements_count 			= count($block_information_arr);
				$block_support_information_elements_count 	= count($block_support_information_arr);

				$processed_start_node = false;
				$processed_end_node = false;

				if (1) {

					// for ($m=1;$m<=($block_information_elements_count+1);$m++) {
					for ($m=2;$m<=$block_information_elements_count;$m++) {

						$start_block_information_arr 	= $block_information_arr[$m-2];
						$end_block_information_arr 		= $block_information_arr[$m-1];
					

						//echo $block_information_arr[$m-2]." : ".$block_information_arr[$m-1]." == ".$block_information_elements_count."<br/>";

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						//echo $block_information_elements_count." ".$block_record_end_granules[4]."<br/>";

						if ( count($block_step_information) > 2 ) {

							ProcessObject::DrawPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}

						if ( $block_record_end_granules[4] ) {

							$block_information_main_arr = explode('~#~',($this->block_information[0]['path_information']));

							if ( $block_record_end_granules[4] == 'END' ) {

								$block_information_end_arr = explode(':',$block_information_main_arr[count($block_information_main_arr)-1]);
								$block_information_end_arr[1]++;

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';
								$new_end_context = $block_information_end_arr[0].':'.$block_information_end_arr[1].':0';

								ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

							} else {

								$matches = explode(":",$block_information_main_arr[$block_record_end_granules[4]-1]);

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';
								$new_end_context = $matches[0].':'.$matches[1].':0';

								ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
							}
						}

						//echo $start_context_code." => ".$end_context_code." -------> ";
						//echo $start_block_information_arr." => ".$end_block_information_arr."<br/>";
					} // end for loop
				}

				// standalone start and end block
				if (0 && $this->outputType == 'N' ) {
					$alt_node_type = 'START';

					$start_block_information_arr 	= $block_information_arr[0];
					$end_block_information_arr 		= $block_information_arr[1];

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$end_block_information_arr		= $start_block_information_arr;
					$start_block_information_arr	= $this->getMainPathNodeData($block_record_start_granules[4]);

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$start_context_level = $block_record_start_granules[0];
					$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

					$end_context_level = $block_record_end_granules[0];
					$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

					$main_path = false;
					$alt_path = true;
					$lozenge = 'NA';

					ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					if ( $block_record_start_granules[2] || $block_record_end_granules[2] ) {

						$alt_node_type = 'END';

						$start_block_information_arr 	= $block_information_arr[1];
						$end_block_information_arr 		= $block_information_arr[0];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);

						$end_block_information_arr		= $this->getMainPathNodeData($block_record_start_granules[4]);

						// for mid air stop
						if ( $block_record_start_granules[4] ) {

							$block_record_start_granules  	= explode(':',$start_block_information_arr);
							$block_record_end_granules  	= explode(':',$end_block_information_arr);

							$start_context_level = $block_record_start_granules[0];
							$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

							$end_context_level = $block_record_end_granules[0];
							$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';

							///commented by davinder on 2011/02/05
							////ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}


					}

				}

				// support path blocks
				if (1) { // && $this->outputType == 'N' ) {

					for ($m=0;$m<$block_support_information_elements_count;$m++) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_arr[$m]);

						$start_block_information_arr 	= $block_support_start_end_information_arr[0];
						$end_block_information_arr 		= $block_support_start_end_information_arr[1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawSupportPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					} // end for loop
				} // end if block

			} // end outer foreach

			// for start and alt path first node;
			$mainpath_information 		= $this->block_information[0]['path_information'];
			$mainpath_node_information 	= explode("~#~",$mainpath_information);

			for ($k=1;$k<count($this->block_information);$k++) {

				$main_path = false;
				$alt_path = true;
				$lozenge = 'NA';

				$path_information 			= $this->block_information[$k]['path_information'];
				$path_node_information 		= explode("~#~",$path_information);

				$end_block = $path_node_information[0];

				$alt_path_first_node 		= explode(":",$end_block);
				
				
				///bob new marker required
				//$start_block_first_node 	= explode(":",$mainpath_node_information[$alt_path_first_node[4]-1]);
			
$start_block_first_node=$this->getMainPathNodeDatabyLevel($alt_path_first_node[4]);
				$start_node_code = $start_block_first_node[0].":".$start_block_first_node[1].":".$start_block_first_node[2];
				$end_node_code = $alt_path_first_node[0].":".$alt_path_first_node[1].":".$alt_path_first_node[2];

				if ( $alt_path_first_node[2] ) {
					$path_info = $start_node_code.'~#~'.$end_node_code;
					ProcessObject::DrawStartCrossPath($this,$path_info,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
				}
			}

		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}

	public function drawSecondaryPaths() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';


		try {

			$crosspaths = array();
			$secondary_nodes_arr = array();

			foreach ( $this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];



				foreach ( $block_information_arr as $block_information_expr ) {

					if ( !preg_match("/^[A-Z]{1,2}:[\d]+:[\d]+:[\d]+:[\d]+:NONE:[\d]+:[\d]+$/",$block_information_expr) ) {
						$secondary_nodes_arr[] = $block_information_expr;
					}
				}
			} // end outer foreach


			// process secondary nodes
			if ( count($secondary_nodes_arr) ) {

				foreach ( $secondary_nodes_arr as $secondary_node_ele ) {

					$node_arr = explode(":",$secondary_node_ele);

					if ( $node_arr != 'EXOUT' && $node_arr != 'EXIN' ) {
						$left_nodes_arr[] 	= $node_arr[3];
						$right_nodes_arr[] 	= $node_arr[7];
					}


					//echo $secondary_node_ele."<br/>";
				}

				/*dump_array($left_nodes_arr);
				dump_array($right_nodes_arr);*/

				$link_information_arr = array('internal'=>array(),'external'=>array());

				$k = 0;
				$l = 0;
				$m = 0;

				foreach ( $left_nodes_arr as $left_nodes_ele ) {
					$key = array_search($left_nodes_ele,$right_nodes_arr);

					if ( !in_array(($secondary_nodes_arr[$k]."~#~".$secondary_nodes_arr[$key]),$link_information_arr['internal']) && !in_array(($secondary_nodes_arr[$key]."~#~".$secondary_nodes_arr[$k]),$link_information_arr['internal']) ) {

						$node_arr = explode(":",$secondary_nodes_arr[$k]);

						if ( $node_arr[5] != 'EXOUT' && $node_arr[5] != 'EXIN' ) {
							$link_information_arr['internal'][$l++] = $secondary_nodes_arr[$k]."~#~".$secondary_nodes_arr[$key];
						}

						if ( $node_arr[5] == 'EXOUT' || $node_arr[5] == 'EXIN' ) {
							$link_information_arr['external'][$m++] = $secondary_nodes_arr[$k];
						}
					}

					//echo $key."<br/>";
					$k++;
				}

				if ( count($link_information_arr['internal']) ) {
					foreach ( $link_information_arr['internal'] as $link_information_internal ) {

						$link_information_internal_arr = explode("~#~",$link_information_internal);

						if ( preg_match("/^[A-Z]{1,2}:[\d]+:[\d]+:[\d]+:END:NONE:[\d]+:[\d]+$/",$link_information_internal_arr[0]) ) {
							continue;
						}

						$p_y_offset = $this->availableHorizontalOffset();
						ProcessObject::DrawNewCrossPath($this,$link_information_internal,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$p_y_offset,$this->outputType);
					}
				}

				if (  count($link_information_arr['external']) ) {
					foreach ( $link_information_arr['external'] as $link_information_external ) {
						ProcessObject::DrawNewExternalPath($this,$link_information_external,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
					}
				}

				//dump_array($link_information_arr);
			}

		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}

	public function drawPathsDeprecated() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';

		try {

			$crosspaths = array();

			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				//dump_array($block_information_arr);

				//$k = 0;
				$block_information_elements_count 			= count($block_information_arr);
				$block_support_information_elements_count 	= count($block_support_information_arr);

				$processed_start_node = false;
				$processed_end_node = false;

				if (1) {

					// for ($m=1;$m<=($block_information_elements_count+1);$m++) {
					for ($m=2;$m<=$block_information_elements_count;$m++) {

						$start_block_information_arr 	= $block_information_arr[$m-2];
						$end_block_information_arr 		= $block_information_arr[$m-1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

						if ( $block_record_end_granules[4] ) {

							$block_information_main_arr = explode('~#~',($this->block_information[0]['path_information']));

							if ( $block_record_end_granules[4] == 'END' ) {

								$block_information_end_arr = explode(':',$block_information_main_arr[count($block_information_main_arr)-1]);
								$block_information_end_arr[1]++;

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';
								$new_end_context = $block_information_end_arr[0].':'.$block_information_end_arr[1].':0';

								ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

							} else {

								//foreach ( $block_information_main_arr as $block_information_test ) {

									//dump_array($block_information_test);


									/*
									if ( preg_match('/[A-Z]:'.$block_record_end_granules[4].':* /', $block_information_test, $matches) ) {

										if ( $matches[0] != '' ) {

											$main_path = false;
											$alt_path = true;
											$lozenge = 'NA';
											$new_end_context = $matches[0].'0';

											ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
										}
									}*/

									//if ( preg_match('/[A-Z]:'.$block_record_end_granules[4].':*/', $block_information_test, $matches) ) {

										//if ( $matches[0] != '' ) {

											$matches = explode(":",$block_information_main_arr[$block_record_end_granules[4]-1]);

											$main_path = false;
											$alt_path = true;
											$lozenge = 'NA';
											$new_end_context = $matches[0].':'.$matches[1].':0';

											ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
										//}
									//}
								//}
							}


						}

						//echo $start_context_code." => ".$end_context_code." -------> ";
						//echo $start_block_information_arr." => ".$end_block_information_arr."<br/>";
					} // end for loop
				}

				$intraprocess_goto_link_data = $this->pfObject->intraprocess_goto_link_information();

				$intraprocess_goto_link = true;

				if (1) {// && $this->outputType == 'N') {

				//$y_offset = $this->availableHorizontalOffset();

				// loop for inter process process flow
				for ($m=0;$m<=$block_information_elements_count;$m++) {

				if ( $this->outputType == 'N' ) {
								$start_block_information_arr 		= $block_information_arr[$m];
								$end_block_information_arr 			= $block_information_arr[$m];

								//echo $start_block_information_arr." - ".$end_block_information_arr."<br/>";

								$block_record_start_granules  		= explode(':',$start_block_information_arr);
								$block_record_end_granules  		= explode(':',$end_block_information_arr);

								if ( $block_record_end_granules[5] == 'IN' || $block_record_end_granules[5] == 'OUT' || $block_record_end_granules[5] == 'EXIN' || $block_record_end_granules[5] == 'EXOUT' ) {

									$start_context_code 				= chr($this->maxDepth - 1 + 64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];
									$end_context_code 					= $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

													/*dump_array($start_context_code);
													dump_array($end_context_code);
													echo "-----------------<br/>";*/

									$alt_node_type = $block_record_end_granules[5].'PROCESS';

									$main_path = false;
									$alt_path = true;
									$lozenge = 'NA';

									if ( $block_record_start_granules[6] == $this->pfObject->getCurrentProcessFlow() && $block_record_start_granules[5] == 'OUT' ) {
										//ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									} else {
										//ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									}
								}

								if ( $block_record_end_granules[5] == 'EXIN' || $block_record_end_granules[5] == 'EXOUT' ) {

									$start_context_code = chr($this->maxDepth - 1 + 64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];
									$end_context_code 	= $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

									$alt_node_type = $block_record_end_granules[5].'PROCESS';

									$main_path = false;
									$alt_path = true;
									$lozenge = 'NA';

									if ( $block_record_start_granules[6] == $this->pfObject->getCurrentProcessFlow() && $block_record_start_granules[5] == 'EXOUT' ) {
										ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									} else {
										ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									}
								}
				}

						if ( $block_information_arr[$m] != '' ) {
							$crosspaths[] 		= $block_information_arr[$m].":".$y_offset;
						}

					} // end for loop


					// loop for intraprocess inter path

					/*for ($m=0;$m<=$block_information_elements_count;$m++) {

						if ( $block_information_arr[$m] != '' ) {
							$crosspaths[] 		= $block_information_arr[$m];
						}

					}*/ // end for loop


				} // end if

				// standalone start and end block
				if (1 && $this->outputType == 'N' ) {
					$alt_node_type = 'START';

					$start_block_information_arr 	= $block_information_arr[0];
					$end_block_information_arr 		= $block_information_arr[1];

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$end_block_information_arr		= $start_block_information_arr;
					$start_block_information_arr	= $this->getMainPathNodeData($block_record_start_granules[4]);

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$start_context_level = $block_record_start_granules[0];
					$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

					$end_context_level = $block_record_end_granules[0];
					$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

					$main_path = false;
					$alt_path = true;
					$lozenge = 'NA';

					ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					if ( $block_record_start_granules[2] || $block_record_end_granules[2] ) {

						$alt_node_type = 'END';

						$start_block_information_arr 	= $block_information_arr[1];
						$end_block_information_arr 		= $block_information_arr[0];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);

						$end_block_information_arr		= $this->getMainPathNodeData($block_record_start_granules[4]);

						// for mid air stop
						if ( $block_record_start_granules[4] ) {

							$block_record_start_granules  	= explode(':',$start_block_information_arr);
							$block_record_end_granules  	= explode(':',$end_block_information_arr);

							$start_context_level = $block_record_start_granules[0];
							$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

							$end_context_level = $block_record_end_granules[0];
							$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';

							///commented by davinder on 2011/02/05
							////ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}


					}

				}

				// support path blocks
				if (1) { // && $this->outputType == 'N' ) {

					for ($m=0;$m<$block_support_information_elements_count;$m++) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_arr[$m]);

						$start_block_information_arr 	= $block_support_start_end_information_arr[0];
						$end_block_information_arr 		= $block_support_start_end_information_arr[1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawSupportPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					} // end for loop
				} // end if block

			} // end outer foreach

			//dump_array($crosspaths);

			$crosspaths_count = count($crosspaths);
			$processed_crosspaths = array();

			if ( $crosspaths_count ) {

				foreach ( $crosspaths as $crosspath_ele ) {
					foreach ( $crosspaths as $crosspath_ele_two ) {

						$main_path = false;
						$alt_path = true;
						$lozenge = 'NA';

						if ( $crosspath_ele != $crosspath_ele_two && !in_array(($crosspath_ele.$crosspath_ele_two),$processed_crosspaths) && !in_array(($crosspath_ele_two.$crosspath_ele),$processed_crosspaths) ) {

							$processed_crosspaths[] = $crosspath_ele.$crosspath_ele_two;

							$block_record_start_granules	= explode(":",$crosspath_ele);
							$block_record_end_granules		= explode(":",$crosspath_ele_two);

							$alt_node_type = $block_record_end_granules[5].'PROCESS';

							/*if ( $block_record_end_granules[5] == 'IN' ) {
								$y_offset = 0;
							} else {*/

							/*}*/

							if ( $block_record_start_granules[7] == $block_record_end_granules[3] ) {

								$y_offset = $this->availableHorizontalOffset();

								$alt_node_type1 = $block_record_start_granules[5].'PROCESS';
								$alt_node_type2 = $block_record_end_granules[5].'PROCESS';

								/*echo "alt_node_type1 ".$alt_node_type1." -> ";
								echo "alt_node_type2 ".$alt_node_type2;
								echo "<br/>";*/

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';

								$start_context_code	= $block_record_start_granules[0].':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];
								$end_context_code =	 $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];
								$bottom_start_context_code = chr($this->maxDepth-1+64).':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];
								$bottom_end_context_code = chr($this->maxDepth-1+64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

								//echo $alt_node_type1.'-'.$alt_node_type2."<br/>";

								if ( ($alt_node_type1 == 'INPROCESS' && $alt_node_type2 == 'OUTPROCESS') || ($alt_node_type2 == 'INPROCESS' && $alt_node_type1 == 'OUTPROCESS') ) {
									ProcessObject::DrawCrossPath($alt_node_type1,$this,$bottom_start_context_code,$start_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									ProcessObject::DrawCrossPath($alt_node_type2,$this,$bottom_end_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
								}

								ProcessObject::DrawHorizontalPath($alt_node_type2,$this,$bottom_start_context_code,$bottom_end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$y_offset);

//								ProcessObject::DrawHorizontalPath($alt_node_type1,$this,$bottom_start_context_code,$bottom_end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$y_offset);

								/*$str = $crosspath_ele.' - '.$crosspath_ele_two;
								if ( !isset($_SESSION['a']) ) {
									$_SESSION['a'] = 50;
								}

								$_SESSION['a'] = $_SESSION['a'] + 10;
								imagestring($this->img, 2, 5, $_SESSION['a'],$str,$this->colours['text_colour']);*/

								//echo "<br/>";
							}
						}
					}
				}
			}
		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}

	public function showImage() {

        // execute this block if debugMode is disabled.
		if (!$this->debugMode) {

			// if resampling is enabled.
			if ( $this->resample ) {

				// Get new dimensions
				$new_width 	= $this->canvasWidth * $this->resamplePercent;
				$new_height = $this->canvasHeight * $this->resamplePercent;


				// if resampling is enabled.
				$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
					or die('Cannot Initialize new GD image stream');

				imagecopyresampled($this->imgResampled, $this->img, 0, 0, 0, 0, $new_width, $new_height, $this->canvasWidth, $this->canvasHeight);

				// Output
				imagepng($this->imgResampled);

			} else {
                if ( $this->outputType == 'H' ) {
					$this->drawHeader();
					$this->drawfooter();
				}

				imagepng($this->img);
			}
		}
	}

	public function showImagepdf() {

        // execute this block if debugMode is disabled.
		if (!$this->debugMode) {

			// if resampling is enabled.
			if ( $this->resample ) {

				// Get new dimensions
				$new_width 	= $this->canvasWidth * $this->resamplePercent;
				$new_height = $this->canvasHeight * $this->resamplePercent;


				// if resampling is enabled.
				$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
					or die('Cannot Initialize new GD image stream');

				imagecopyresampled($this->imgResampled, $this->img, 0, 0, 0, 0, $new_width, $new_height, $this->canvasWidth, $this->canvasHeight);

				// Output
				imagepng($this->imgResampled);

			} else {
                if ( $this->outputType == 'H' ) {
					$this->drawHeader();
					}

				imagepng($this->img);
			}
		}
	}
	public function saveImage() {

		$process_details = $this->pfObject->getCurrentProcessFlowInformation();
		$this->outputFile = "process_flow_horizontal_".$process_details['swimID'].".png";
		$output_file_path = realpath("../private_files/process_flow")."/".$this->outputFile;

		// if resampling is enabled.
		if (!$this->debugMode) {

			if ( function_exists(imagepng) ) {
				if ( file_exists($output_file_path) ) {
					unlink($output_file_path);
				}
				//
				//imagepng($this->img);
				imagepng($this->img,$output_file_path);
			}

		}
	}

	public function getSavedImageName() {
		return $this->outputFile;
	}

	public function __destruct() {

		if (!$this->debugMode) {
			imagedestroy($this->img);
		}
	}

	public function __call($name,$arguments) {

		$propertyname = strtolower(substr($name,3,1)).substr($name,4);

		return $this->$propertyname;
	}

	public function getColour($p_code) {
		return $this->colours[$p_code];
	}

	public function getOutType() {
		return $this->outputType;
	}
	public function getResource() {
		return $this->img;
	}

	public function getPathcolour($p_pathno) {

		$p_pathno = (int) $p_pathno;

		if (!$p_pathno) {
			return $this->colours['main_path_colour'];
		} else {
			return $this->colours['alt'.$p_pathno.'_path_colour'];
		}
	}

	public function getMainPathNodeData($node) {

		if ( $node < 1 ) {
			$node = 1;
		}

		$block_information_arr 		= explode('~#~',$this->block_information[0]['path_information']);
		$block_step_information 	= $block_information_ele['step_information'];

		return $block_information_arr[$node-1];
	}


	
	
	public function saveNodeCoordinates($p_step_no,$p_coordinates) {
		$this->pfObject->saveNodeCoordinates($p_step_no,$p_coordinates);
	}

	public function saveProcessInOutCoordinates($p_step_no,$p_coordinates) {
		$this->pfObject->saveProcessInOutCoordinates($p_step_no,$p_coordinates);
	}

	
		public function getSbpRef($p_sub) {
	$subarray=$this->pfObject->displayProcessFlowById($p_sub);
	return $subarray["reference"];
	}
	
	public function availableHorizontalOffset() {

		$k = 0;

		foreach ( $this->horizontalOffsetPool as $offset_ele ) {

			if ( !$offset_ele['used'] ) {
				$this->horizontalOffsetPool[$k]['used'] = 1;
				return $offset_ele['offset'];
			}

			$k++;
		}
	}
	
	
		public function getMainPathNodeDatabyLevel($level) {
//picks first level in code
		if ( $level < 1 ) {
			$level = 1;
		}


		$block_information_arr 		= explode('~#~',$this->block_information[0]['path_information']);
		
		foreach ( $block_information_arr as $nodes_ele ) {
					$nodes_arr = explode(':',$nodes_ele);

if ($nodes_arr[1] == $level)	
{
return 	$nodes_arr;
}
		}
		
		return $nodes_arr;
	}
	
}
?>