 <?php
 /**
  $Id: NhpMain.class.php,v 3.38 Monday, January 31, 2011 10:06:22 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, November 08, 2010 9:52:17 AM>
  */
require_once "Nhp.int.php";
require_once "Action.class.php";

class NhpMain implements Nhp
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Nhp Id
	 *@access private
	 */
	private $nhpId;

	/**
	 *Property to hold Nhp Info
	 *@access private
	 */
	private $nhpInfo;


	/**
	 * Constructor for initializing Nhp object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}
	/*
	 * This method is used to set Nhp information for the respective object
	 */
	public function setNhpInfo($p_NhpId,$p_NhpInfo) {
		$this->nhpId	 = $p_NhpId;
		$this->nhpInfo	 = $p_NhpInfo;
	}

	/*
	 * This method is used to add new Nhp
	 */
	public function addNhp() {

		$sql = sprintf("SELECT * FROM %s.nhp WHERE reference = '%s'",_DB_OBJ_FULL,$this->nhpInfo['reference']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpInfo['reference']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {
			throw new ErrorException('Nhp with this Reference # already exists.');
		} else {
			$sql2 = sprintf("INSERT INTO %s.nhp (reference,uniqueReference,whoID,locationID,businessUnitID,date,archive,status,nearmissHazardFlag)
											VALUES ('%s','%s',%d,%d,%d,'%s','0','0','%s')",
											_DB_OBJ_FULL,$this->nhpInfo['reference'],$this->nhpInfo['unique_reference'],$this->nhpInfo['who'],
											$this->nhpInfo['location'],$this->nhpInfo['business_unit'],format_date_for_mysql($this->nhpInfo['date']),
											$this->nhpInfo['near_miss_hazard_flag']);
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->nhpInfo['reference']);
			$pStatement2->bindParam(2,$this->nhpInfo['unique_reference']);
			$pStatement2->bindParam(3,$this->nhpInfo['who']);
			$pStatement2->bindParam(4,$this->nhpInfo['location']);
			$pStatement2->bindParam(5,$this->nhpInfo['business_unit']);
			$pStatement2->bindParam(6,format_date_for_mysql($this->nhpInfo['date']));*/

			$pStatement2->execute();

			$this->nhpId = customLastInsertId( $this->dbHand,'nhp','ID');
		}
	}

	/*
	 * This method is used to edit Nhp record
	 */
	public function editNhp() {

		$sql = sprintf(" UPDATE %s.nhp SET whoID = %d,
								locationID = %d,
								businessUnitID = %d,
								date = '%s',
								nearmissHazardFlag = '%s'
							WHERE ID = %d ",_DB_OBJ_FULL,$this->nhpInfo['who'],$this->nhpInfo['location'],$this->nhpInfo['business_unit'],
							format_date_for_mysql($this->nhpInfo['date']),$this->nhpInfo['near_miss_hazard_flag'],$this->nhpId);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->nhpInfo['who']);
		$pStatement->bindParam(2,$this->nhpInfo['location']);
		$pStatement->bindParam(3,$this->nhpInfo['business_unit']);
		$pStatement->bindParam(4,format_date_for_mysql($this->nhpInfo['date']));
		$pStatement->bindParam(5,$this->nhpId);*/

		$pStatement->execute();

	}

	/**
	 * This method is used to manage Problem
	 * description,risk_impact
	 */

	public function manageProblem() {

		$sql2 = sprintf(" UPDATE %s.nhp SET problemDescription = '%s',
										problemRiskImpact = %d,
										investigationRequired = '%s',
										noInvestigationReqReason = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->nhpInfo['description'],$this->nhpInfo['risk_impact'],
										$this->nhpInfo['inv_req'],$this->nhpInfo['no_di_reason'],$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->nhpInfo['description']);
		$pStatement2->bindParam(2,$this->nhpInfo['risk_impact']);
		$pStatement2->bindParam(3,$this->nhpId);*/

		$pStatement2->execute();
		//dump_array_and_exit($pStatement2->errorInfo());
	}

	/**
	 * This method is used to manage Causes
	 */

	public function manageCauses() {
		$sql = sprintf("SELECT * FROM %s.nhp_causes WHERE nhpID = %d ",_DB_OBJ_FULL,$this->nhpId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {
			// do update
			$this->editCause();
		} else {
			// do insert
			$this->addCause();
		}
	}

	/**
	 * This method is used to add cause
	 * is_unsafe_act,unsafe_act_percent,unsafe_act_description,lack_skill_percent,lack_skill_description,lack_knowledge_percent,lack_knowledge_description,
	 * lack_complaince_percent,lack_complaince_description,is_unsafe_design,unsafe_design_percent,unsafe_design_description,is_faulty_construction,
	 * faulty_construction_percent,faulty_construction_description,is_unsafe_condition,unsafe_condition_percent,unsafe_condition_description,
	 * is_unsafe_method,unsafe_method_percent,unsafe_method_description
	 */
	private function addCause() {
		$sql = sprintf("INSERT INTO %s.nhp_causes (nhpID ,isUnsafeAct ,unsafeActPercent ,UnsafeActDesc ,lackSkillPercent ,lackSkillDesc ,lackKnowledgePercentage ,
										lackKnowledgeDesc ,lackCompliancePercent ,lackComplianceDesc ,isUnsafeDesign ,unsafeDesignPercent ,UnsafeDesignDesc ,
										isFaultyConstruction ,faultyConstructionPercent ,faultyConstructionDesc ,isUnsafeCondition ,unsafeConditionPercent ,
										unsafeConditionDesc ,isUnsafeMethod ,unsafeMethodPercent ,unsafeMethodDesc)
									VALUES (%d,'%s',%f,'%s',%f,'%s',%f,'%s',%f,'%s','%s',%f,'%s','%s',%f,'%s','%s',%f,'%s','%s',%f,'%s') ",
									_DB_OBJ_FULL,$this->nhpId,$this->nhpInfo['is_unsafe_act'],$this->nhpInfo['unsafe_act_percent'],
									$this->nhpInfo['unsafe_act_description'],$this->nhpInfo['lack_skill_percent'],$this->nhpInfo['lack_skill_description'],
									$this->nhpInfo['lack_knowledge_percent'],$this->nhpInfo['lack_knowledge_description'],$this->nhpInfo['lack_complaince_percent'],
									$this->nhpInfo['lack_complaince_description'],$this->nhpInfo['is_unsafe_design'],$this->nhpInfo['unsafe_design_percent'],
									$this->nhpInfo['unsafe_design_description'],$this->nhpInfo['is_faulty_construction'],$this->nhpInfo['faulty_construction_percent'],
									$this->nhpInfo['faulty_construction_description'],$this->nhpInfo['is_unsafe_condition'],$this->nhpInfo['unsafe_condition_percent'],
									$this->nhpInfo['unsafe_condition_description'],$this->nhpInfo['is_unsafe_method'],$this->nhpInfo['unsafe_method_percent'],
									$this->nhpInfo['unsafe_method_description']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->nhpId);
		$pStatement->bindParam(2,$this->nhpInfo['is_unsafe_act']);
		$pStatement->bindParam(3,$this->nhpInfo['unsafe_act_percent']);
		$pStatement->bindParam(4,$this->nhpInfo['unsafe_act_description']);
		$pStatement->bindParam(5,$this->nhpInfo['lack_skill_percent']);
		$pStatement->bindParam(6,$this->nhpInfo['lack_skill_description']);
		$pStatement->bindParam(7,$this->nhpInfo['lack_knowledge_percent']);
		$pStatement->bindParam(8,$this->nhpInfo['lack_knowledge_description']);
		$pStatement->bindParam(9,$this->nhpInfo['lack_complaince_percent']);
		$pStatement->bindParam(10,$this->nhpInfo['lack_complaince_description']);
		$pStatement->bindParam(11,$this->nhpInfo['is_unsafe_design']);
		$pStatement->bindParam(12,$this->nhpInfo['unsafe_design_percent']);
		$pStatement->bindParam(13,$this->nhpInfo['unsafe_design_description']);
		$pStatement->bindParam(14,$this->nhpInfo['is_faulty_construction']);
		$pStatement->bindParam(15,$this->nhpInfo['faulty_construction_percent']);
		$pStatement->bindParam(16,$this->nhpInfo['faulty_construction_description']);
		$pStatement->bindParam(17,$this->nhpInfo['is_unsafe_condition']);
		$pStatement->bindParam(18,$this->nhpInfo['unsafe_condition_percent']);
		$pStatement->bindParam(19,$this->nhpInfo['unsafe_condition_description']);
		$pStatement->bindParam(20,$this->nhpInfo['is_unsafe_method']);
		$pStatement->bindParam(21,$this->nhpInfo['unsafe_method_percent']);
		$pStatement->bindParam(22,$this->nhpInfo['unsafe_method_description']);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to edit cause
	 * is_unsafe_act,unsafe_act_percent,unsafe_act_description,lack_skill_percent,lack_skill_description,lack_knowledge_percent,lack_knowledge_description,
	 * lack_complaince_percent,lack_complaince_description,is_unsafe_design,unsafe_design_percent,unsafe_design_description,is_faulty_construction,
	 * faulty_construction_percent,faulty_construction_description,is_unsafe_condition,unsafe_condition_percent,unsafe_condition_description,
	 * is_unsafe_method,unsafe_method_percent,unsafe_method_description
	 */
	private function editCause() {
		$sql = sprintf("UPDATE %s.nhp_causes SET isUnsafeAct = '%s' ,
										unsafeActPercent = %f ,
										UnsafeActDesc = '%s' ,
										lackSkillPercent = %f ,
										lackSkillDesc = '%s' ,
										lackKnowledgePercentage = %f,
										lackKnowledgeDesc = '%s',
										lackCompliancePercent = %f,
										lackComplianceDesc = '%s',
										isUnsafeDesign = '%s',
										unsafeDesignPercent = %f,
										UnsafeDesignDesc  = '%s',
										isFaultyConstruction = '%s',
										faultyConstructionPercent = %f,
										faultyConstructionDesc = '%s',
										isUnsafeCondition = '%s',
										unsafeConditionPercent = %f,
										unsafeConditionDesc = '%s',
										isUnsafeMethod = '%s',
										unsafeMethodPercent = %f,
										unsafeMethodDesc = '%s'
									WHERE nhpID = %d ",
									_DB_OBJ_FULL,$this->nhpInfo['is_unsafe_act'],$this->nhpInfo['unsafe_act_percent'],
									$this->nhpInfo['unsafe_act_description'],$this->nhpInfo['lack_skill_percent'],$this->nhpInfo['lack_skill_description'],
									$this->nhpInfo['lack_knowledge_percent'],$this->nhpInfo['lack_knowledge_description'],$this->nhpInfo['lack_complaince_percent'],
									$this->nhpInfo['lack_complaince_description'],$this->nhpInfo['is_unsafe_design'],$this->nhpInfo['unsafe_design_percent'],
									$this->nhpInfo['unsafe_design_description'],$this->nhpInfo['is_faulty_construction'],$this->nhpInfo['faulty_construction_percent'],
									$this->nhpInfo['faulty_construction_description'],$this->nhpInfo['is_unsafe_condition'],$this->nhpInfo['unsafe_condition_percent'],
									$this->nhpInfo['unsafe_condition_description'],$this->nhpInfo['is_unsafe_method'],$this->nhpInfo['unsafe_method_percent'],
									$this->nhpInfo['unsafe_method_description'],$this->nhpId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->nhpInfo['is_unsafe_act']);
		$pStatement->bindParam(2,$this->nhpInfo['unsafe_act_percent']);
		$pStatement->bindParam(3,$this->nhpInfo['unsafe_act_description']);
		$pStatement->bindParam(4,$this->nhpInfo['lack_skill_percent']);
		$pStatement->bindParam(5,$this->nhpInfo['lack_skill_description']);
		$pStatement->bindParam(6,$this->nhpInfo['lack_knowledge_percent']);
		$pStatement->bindParam(7,$this->nhpInfo['lack_knowledge_description']);
		$pStatement->bindParam(8,$this->nhpInfo['lack_complaince_percent']);
		$pStatement->bindParam(9,$this->nhpInfo['lack_complaince_description']);
		$pStatement->bindParam(10,$this->nhpInfo['is_unsafe_design']);
		$pStatement->bindParam(11,$this->nhpInfo['unsafe_design_percent']);
		$pStatement->bindParam(12,$this->nhpInfo['unsafe_design_description']);
		$pStatement->bindParam(13,$this->nhpInfo['is_faulty_construction']);
		$pStatement->bindParam(14,$this->nhpInfo['faulty_construction_percent']);
		$pStatement->bindParam(15,$this->nhpInfo['faulty_construction_description']);
		$pStatement->bindParam(16,$this->nhpInfo['is_unsafe_condition']);
		$pStatement->bindParam(17,$this->nhpInfo['unsafe_condition_percent']);
		$pStatement->bindParam(18,$this->nhpInfo['unsafe_condition_description']);
		$pStatement->bindParam(19,$this->nhpInfo['is_unsafe_method']);
		$pStatement->bindParam(20,$this->nhpInfo['unsafe_method_percent']);
		$pStatement->bindParam(21,$this->nhpInfo['unsafe_method_description']);
		$pStatement->bindParam(22,$this->nhpId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage Environment
	 * environmental
	 */

	public function manageEnvironment() {
		$sql2 = sprintf(" UPDATE %s.nhp SET environmental = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$this->nhpInfo['environmental'],$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->nhpInfo['environmental']);
		$pStatement2->bindParam(2,$this->nhpId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage Disposition
	 * disposition
	 */

	public function manageDisposition() {
		$sql2 = sprintf(" UPDATE %s.nhp SET disposition = %d
									WHERE ID = %d",_DB_OBJ_FULL,$this->nhpInfo['disposition'],$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->nhpInfo['disposition']);
		$pStatement2->bindParam(2,$this->nhpId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to manage action
	 * actions = array(array('action'=>'dfg','who'=>'gdfg','due_date'=>'gdfg','action_id'=>23),
	 * 					array('action'=>'dfg','who'=>'gdfg','due_date'=>'gdfg','action_id'=>26),
	 * 					array('action'=>'dfg','who'=>'gdfg','due_date'=>'gdfg','action_id'=>0));
	 */
	public function manageActions() {

		if ( count($this->nhpInfo['actions']) ) {
			$action_ids = "";
			foreach( $this->nhpInfo['actions'] as $value ) {

				$this->actionData = array('module_name'=>'nhp','description'=>$value['action'],
								  'who'=>$value['who'],'whoAU'=>$value['whoAU'],'due_date'=>$value['when']);
				if ( $value['action_id'] ) {
					// do update
					$this->actionHandling->setActionDetails($value['action_id'],$this->actionData);

					$actTriggerObj = new ActionEditTriggers();
					$actTriggerObj->setActionTriggerDetails('nhp',$value['action_id'],$this->nhpId,array(
																											'new_who' => $value['who'],
																											'new_whoAU' => $value['whoAU']
																													 ));

					$actTriggerObj->beforeUpdateTrigger();

					$this->actionHandling->updateAction();

					$actTriggerObj->afterUpdateTrigger();
					$actTriggerObj = null;

					$action_ids .= $value['action_id'].',';

				} else {
					// do add
					$this->actionHandling->setActionDetails(0,$this->actionData);
					$new_action_id = $this->actionHandling->addAction();
					$action_ids .= $new_action_id.',';
				}
			}

			$action_ids = rtrim($action_ids,',');

			 $sql2 = sprintf("UPDATE %s.nhp SET actionsID = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$action_ids,$this->nhpId);

			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$action_ids);
			$pStatement2->bindParam(2,$this->nhpId);*/

			$pStatement2->execute();

		$sql3 = sprintf("UPDATE %s.nhp SET noActionReason = '%s',noAction = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$this->nhpInfo['no_action_reason'],$this->nhpInfo['no_action'],
									$this->nhpId);

			$pStatement3 = $this->dbHand->prepare($sql3);
			$pStatement3->execute();
			/*dump_array($pStatement3->errorInfo());
			exit;*/
		}
	}

	/*
	 * This method is used to update nhp process
	 * process,is_risk
	 */
	public function manageProcess() {

		$sql2 = sprintf(" UPDATE %s.nhp SET processID = %d,
										isRiskValid = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$this->nhpInfo['process'],$this->nhpInfo['is_risk'],$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->nhpInfo['process']);
		$pStatement2->bindParam(2,$this->nhpInfo['is_risk']);
		$pStatement2->bindParam(3,$this->nhpId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to update files id
	 */
	public function addFiles() {

		$record_data = $this->viewNhpById();

		$new_files_id_string = $record_data['uploadFilesID'].','.$this->nhpInfo['file_id'];
		$new_files_id_string = ltrim($new_files_id_string,',');

		$sql2 = sprintf(" UPDATE %s.nhp SET uploadFilesID = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$new_files_id_string,$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_files_id_string);
		$pStatement2->bindParam(2,$this->nhpId);*/

		$pStatement2->execute();
	}

	/**
	 * This method is used to delete file id
	 */
	public function deleteFile() {

		$record_data = $this->viewNhpById();

		$files_id_arr = explode(',',$record_data['uploadFilesID']);

		if ( count($files_id_arr) ) {
			foreach ( $files_id_arr as $value ) {
				if ( $value != $this->nhpInfo['file_id'] ) {
					$new_files_id_string .= $value.',';
				}
			}
			$new_files_id_string = rtrim($new_files_id_string,',');

			$sql2 = sprintf(" UPDATE %s.nhp SET uploadFilesID = '%s'
									WHERE
										ID = %d",_DB_OBJ_FULL,$new_files_id_string,$this->nhpId);

			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$new_files_id_string);
			$pStatement2->bindParam(2,$this->nhpId);*/

			$pStatement2->execute();
		}

	}

	/*
	 * This method is used to delete Nhp record
	 */
	public function deleteNhp() {}

	/*
	 * This method is used to archive Nhp record
	 */
	public function archiveNhp() {
		$sql2 = sprintf(" UPDATE %s.nhp SET archive = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,$this->nhpInfo['archive'],$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->nhpInfo['archive']);
		$pStatement2->bindParam(2,$this->nhpId);*/

		$pStatement2->execute();
	}

	/*
	 * This method is used to completely delete Nhp record
	 */
	public function purgeNhp() {
		$rec_details = $this->viewNhpById();
		//dump_array($rec_details);
		$action_arr = explode(',',$rec_details['actionsID']);
		//dump_array($action_arr);

		if ( count($action_arr) ) {
			foreach ( $action_arr as $value ) {
				if ( $value != '' ) {
					$this->actionHandling->setActionDetails($value,"");
					$this->actionHandling->deleteAction();
				}
			}
		}

		$sql = sprintf("DELETE FROM %s.nhp_causes WHERE nhpID = %d",_DB_OBJ_FULL,$this->nhpId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();

		$sql2 = sprintf("DELETE FROM %s.nhp WHERE ID = %d",_DB_OBJ_FULL,$this->nhpId);

		$pStatement2 = $this->dbHand->prepare($sql2);
		//$pStatement2->bindParam(1,$this->nhpId);
		$pStatement2->execute();
	}

	/**
	 * This method is used to get last insert id
	 */
	public function lastRecordId() {
		return $this->nhpId;
	}

	/*
	 * This method is used to view an nhp record
	 */
	public function viewNhpById() {

		$sql = sprintf("SELECT * FROM %s.nhp WHERE ID = %d",_DB_OBJ_FULL,$this->nhpId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();
		//dump_array($pStatement->errorInfo());
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet[0];
	}

	/**
	 * This method is used to view Causes
	 */

	public function viewCauses() {
		$sql = sprintf("SELECT * FROM %s.nhp_causes WHERE nhpID = %d ",_DB_OBJ_FULL,$this->nhpId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet[0];

	}

	/*
	 * This method is used to view nhp records
	 */
	public function viewNhps() {

		//$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.nhp A
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->nhpInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/*
	 * This method is used to view action records
	 */
	public function viewActions() {

		$resultSet = $this->viewNhpById();
		$actions = $resultSet['actionsID'];
		$action_details = array();

		if ( $actions != '' ) {
			$actions_id_arr = explode(',',$actions);
			if ( count($actions_id_arr) ) {
				$i=0;
				foreach( $actions_id_arr as $value ) {
					$this->actionHandling->setActionDetails($value,"");
					$action_data = $this->actionHandling->viewAction();
					if ( $action_data ) {
						$action_details[$i] = $this->actionHandling->viewAction();
						$action_details[$i]['action_id'] = $value;
						$i++;
					}

				}
			}
		}

		return $action_details;
	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('nhp');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('nhp');
		}

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT M.reference,M.businessUnitID,M.ID AS nhp_id FROM %s.nhp M
											WHERE M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' ",
											_DB_OBJ_FULL,$search_value1,$search_value2,$search_value3,$search_value4);

				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$search_value1);
				$pStatement->bindParam(2,$search_value2);
				$pStatement->bindParam(3,$search_value3);
				$pStatement->bindParam(4,$search_value4);*/

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['businessUnitID'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['nhp_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function addOutstandingAction() {

		$sql = sprintf("SELECT actionsID FROM %s.nhp WHERE ID = %d ",_DB_OBJ_FULL,$this->nhpId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();

		$improvements = $pStatement->fetchColumn();
		$new_improvements = $improvements.','.$this->nhpInfo['new_improvement'];

		$sql2 = sprintf("UPDATE %s.nhp SET actionsID = '%s' WHERE ID = %d ",_DB_OBJ_FULL,$new_improvements,$this->nhpId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_improvements);
		$pStatement2->bindParam(2,$this->nhpId);*/
		$pStatement2->execute();
	}

	protected function getNoOfNhps() {

		$sql = sprintf("SELECT * FROM %s.nhp ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
					$bu_id = $row['businessUnitID'];
					$date_time = $row['date'];
					$year = substr($date_time,0,4);

					$result_set[$year][$bu_id]++;
			}

			return $result_set;
		}
	}

	protected function getGraphDataRisk() {

		$sql = sprintf("SELECT * FROM %s.nhp ",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();

		if ( $no_rows ) {

			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {

				$bu_id 			= $row['businessUnitID'];
				$risk_impact 	= $row['problemRiskImpact'];
				$disposition 	= $row['disposition'];
				$date_time 		= $row['date'];

				$year = substr($date_time,0,4);

				if ( !empty($risk_impact) && $bu_id ) {
					$result_set['risk'][$year][$bu_id][$risk_impact]++;
				}

				if ( !empty($disposition) && $bu_id ) {
					$result_set['disposition'][$year][$bu_id][$disposition]++;
				}

			}

			return $result_set;
		}
	}

	protected function getGraphDataCauses() {

		$sql = sprintf("SELECT C.*,N.businessUnitID,N.date FROM %s.nhp_causes C
												INNER JOIN %s.nhp N
											ON N.ID = C.nhpID",_DB_OBJ_FULL,_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
					$bu_id = $row['businessUnitID'];
					$date_time = $row['date'];

					$year = substr($date_time,0,4);

					$result_set[$year][$bu_id]['unsafe_act'] += (int) $row['unsafeActPercent'];
					$result_set[$year][$bu_id]['unsafe_design'] += (int) $row['unsafeDesignPercent'];
					$result_set[$year][$bu_id]['faulty_construction'] += (int) $row['faultyConstructionPercent'];
					$result_set[$year][$bu_id]['unsafe_condition'] += (int) $row['unsafeConditionPercent'];
					$result_set[$year][$bu_id]['unsafe_method'] += (int) $row['unsafeMethodPercent'];
			}

			return $result_set;
		}
	}

	public function updateStatus() {
		$sql = sprintf("UPDATE %s.nhp SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->nhpId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();

	}

	public function addNhpFile() {
		$files_arr = $this->getNhpFile();
		$files = implode(',',$files_arr);

		$new_files = $files.','.$this->nhpInfo['file_id'];

		$sql = sprintf("UPDATE %s.nhp SET uploadFilesID = '%s' WHERE ID = %d",_DB_OBJ_FULL,$new_files,$this->nhpId);
		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$new_files);
		$pStatement->bindParam(2,$this->nhpId);*/

		$pStatement->execute();
	}

	public function getNhpFile() {

		$sql = sprintf("SELECT uploadFilesID FROM %s.nhp WHERE ID = %d",_DB_OBJ_FULL,$this->nhpId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->nhpId);
		$pStatement->execute();
		$resultSet = $pStatement->fetchColumn();

		$files_list = explode(',',$resultSet);
		return $files_list;
	}

	public function sendActionAlerts($p_record_id) {

		$this->nhpId = $p_record_id;

		$nhp_details = $this->viewNhpById();;

		$record_data = $this->viewActions();

		if ( count($record_data) ) {
			$i = 0;
			foreach ( $record_data as $value ) {

				$email_data[$i]['reference']	 		= $nhp_details['reference'];
				$email_data[$i]['summary']		 		= $value['actionDescription'];
				$email_data[$i]['due_date']		 		= format_date($value['dueDate']);
				$email_data[$i]['who']			 		= $value['who'];
				$email_data[$i]['whoAU']			 		= $value['whoAU'];
				$email_data[$i]['problem_description']	= $nhp_details['problemDescription'];

				//echo $value['ID']; exit;

				$this->actionHandling->updateStatus($value['ID']);
				$i++;
			}
		}

		return $email_data;

	}

	public function searchNhp() {

		$filter = "";

		//$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '0' ",_DB_OBJ_FULL);

		if ( $this->nhpInfo['env_type'] ) {
			$filter .= " AND (A.environmental LIKE '".$this->nhpInfo['env_type']."' OR A.environmental LIKE '".$this->nhpInfo['env_type'].",%' OR ";
			$filter .= " A.environmental LIKE '%,".$this->nhpInfo['env_type']."' OR A.environmental LIKE '%,".$this->nhpInfo['env_type'].",%')";
		}
		if ( $this->nhpInfo['env_scale'] ) {
			$filter .= " AND (A.environmental LIKE '".$this->nhpInfo['env_scale']."' OR A.environmental LIKE '".$this->nhpInfo['env_scale'].",%' OR ";
			$filter .= " A.environmental LIKE '%,".$this->nhpInfo['env_scale']."' OR A.environmental LIKE '%,".$this->nhpInfo['env_scale'].",%')";
		}
		if ( $this->nhpInfo['disposition'] ) {
			$filter .= " AND A.disposition = ".$this->nhpInfo['disposition'];
		}

		if ( $this->nhpInfo['nearmiss_hazard'] == 'N' || $this->nhpInfo['nearmiss_hazard'] == 'H' || $this->nhpInfo['nearmiss_hazard'] == 'O' ) {
			$filter .= " AND A.nearmissHazardFlag = '".$this->nhpInfo['nearmiss_hazard']."'";
		}

		if ( $this->nhpInfo['start_date'] != '' && $this->nhpInfo['end_date'] != '' ) {
			$filter .= " AND (dateTimestamp BETWEEN '".$this->nhpInfo['start_date']." 00:00:00.000' AND '".$this->nhpInfo['end_date']." 23:59:59.000')";
			$join_type = 'INNER';
			$date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
		} else {
			$join_type = 'LEFT OUTER';
			$date_timestamp_not_null = '';
		}

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.nhp A
				".$join_type." JOIN (
					SELECT recID,
						dateTimestamp,
						whoID as userID,
						reference as recordRef,
						role
					FROM %s.module_tracker
					WHERE module = 'NHP'
					AND action = 'add'
					".$date_timestamp_not_null."
				) B
				ON recordRef = reference
				WHERE A.archive = '0'",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->nhpInfo['archive']);

		$sql = $sql.$filter."  ORDER BY A.ID DESC";

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$type = $_GET['type'];

		if ( $type ) {

			return $this->getSearchExportData();

		} else {

			return $this->getNhpExportData();
		}
	}

	public function getNhpExportData() {

		$heading = array(array('refrence'=>'Reference #','bu'=>'Business Unit','who'=>'Who','When'=>'When','loc'=>'Location'));

		$orgObj			 = SetupGeneric::useModule('Organigram');
		$locObj			 = SetupGeneric::useModule('Locationgram');
		$participantObj	 = SetupGeneric::useModule('Participant');

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
		$this->setNhpInfo(1,array('archive'=>$archive_session));
		$nhp_records = $this->viewNhps();

		if ( count($nhp_records) ) {
			$i=0;
			foreach ($nhp_records as $value ) {

				$nhp_id = $value['ID'];
				$orgObj->setItemInfo(array('id'=>$value['businessUnitID']));
				$bu_details = $orgObj->displayItemById();

				$locObj->setItemInfo(array('id'=>$value['locationID']));
				$location_data = "";
				$location = $locObj->getFUllLocation();

				$participant_id = $value['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];


				$result[$i]['ref'] = $value['reference'];
				$result[$i]['bu'] = $bu_details['buName'];
				$result[$i]['who'] = $participant_name;
				$result[$i]['when'] = format_date($value['date']);
				$result[$i]['loc'] = str_replace(',','-',$location);

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
	}

	public function getSearchExportData() {

		$orgObj			 = SetupGeneric::useModule('Organigram');
		$locObj			 = SetupGeneric::useModule('Locationgram');
		$participantObj	 = SetupGeneric::useModule('Participant');

		$data_array['env_type']		 = $_GET['env_type'];
		$data_array['env_scale']	 = $_GET['env_scale'];
		$data_array['disposition']	 = $_GET['disposition'];

		$this->setNhpInfo(1,$data_array);
		$nhp_records = $this->searchNhp();

		$heading = array(array('Reference #', 'Business Unit', 'Who', 'When', 'Location'));

		if ( count($nhp_records) ) {

			foreach ( $nhp_records as $element ) {

				$orgObj->setItemInfo(array('id'=>$element['businessUnitID']));
				$bu_details = $orgObj->displayItemById();
				$business_unit = $bu_details['buName'];

				$locObj->setItemInfo(array('id'=>$element['locationID']));
				$location_data = "";
				$location = $locObj->getFUllLocation();
				$location = str_replace(',','-',$location);

				$participant_id = $element['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$date = format_date($element['date']);

				$result[] = array($element['reference'], $business_unit, $participant_name, $date, $location);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}
	/* function is used to send mail to manger of approved record */

	public function getActionTrackerEmailData($p_record_id) {

		$sql2 = sprintf("SELECT * FROM %s.nhp ",_DB_OBJ_FULL);
		$sql2 = $sql2." WHERE actionsID LIKE '".$p_record_id."' OR actionsID LIKE '%,".$p_record_id."' OR actionsID LIKE '".$p_record_id.",%' OR actionsID LIKE '%,".$p_record_id.",%' ";

		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();
		$result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);





		if ( count($result) ) {

			$email_data['bu_id']		 		= $result[0]['businessUnitID'];
			$email_data['reference']		 	= $result[0]['reference'];
			$email_data['dueDate']		 		= $result[0]['date'];
			$email_data['who_id']		 		= $result[0]['whoID'];


		}


		return $email_data;
	}
}
?>