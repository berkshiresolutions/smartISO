<?php
 /**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */
class DashboardGapFilling extends DashboardParent
{

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {
		parent::__construct();
	}

	public function getImpactMeasures() {

		$sql = "SELECT * FROM %s.impact_measure
				ORDER BY sort ASC";

		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$impact_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $impact_data;

	}

	public function getIncidenceInvestigationData() {

		if ( $this->filter['selected_bu'] ) {

			$bu_list = $this->getAllBUs();

			$sql = "SELECT R.*,S.* FROM %s.maintenance_calibration_data R
				INNER JOIN %s.equipments S
				ON R.equipId = S.equipID
				WHERE jobType = 'M' AND archive is NULL";

			$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,$bu_list);
		} else {

			$sql = "SELECT R.*,S.* FROM %s.maintenance_calibration_data R
				INNER JOIN %s.equipments S
				ON R.equipId = S.equipID
				WHERE jobType = 'M' AND archive is NULL";

			$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result_data;
	}

    public function getGapQuestionActionTrackerWithBUs() {


        $level = getUserAccessLevel();

        if ($level == 1) {
            if ($p_assignedToMe) {
                $filter = "participantID = %d";
            } else {
                $filter = "q.participantID != %d";
            }
        } else {
            $filter = "q.participantID = %d";
        }

        $c_filter = sprintf($filter, getLoggedInUserId());

        if ($p_due_date != '') {
            $filter_date = " AND whenDate <= '" . $p_due_date . "'";
        }


        if ($this->filter['selected_bu']) {

            $bu_list = $this->getAllBUs();

            $psql = sprintf("SELECT * FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description,RM.buID FROM %s.review_gap_question Q
                                INNER JOIN  dbSmartBeta.dbo.review_master RM ON RM.reviewID=Q.reviewID
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption != 'NA' ) V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID
				WHERE $c_filter $filter_date) D2
				ON D1.ID = D2.documentID AND buID IN (%s)", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$bu_list);
        } else {

            $psql = sprintf("SELECT * FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description FROM %s.review_gap_question Q
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption != 'NA' ) V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID
				WHERE $c_filter $filter_date) D2
				ON D1.ID = D2.documentID ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data;
    }

	public function getData() {
	
		$bu_list 	= array();
		$hlist 		= array();
		$dlist 		= array();

		$q1_sr 		= $this->qtrsRange['q1_sr'];
		$q1_er		= $this->qtrsRange['q1_er'];
		/*$q11_sr 	= $this->qtrsRange['q11_sr'];
		$q11_er 	= $this->qtrsRange['q11_er'];
		$q12_sr 	= $this->qtrsRange['q12_sr'];
		$q12_er 	= $this->qtrsRange['q12_er'];
		$q13_sr 	= $this->qtrsRange['q13_sr'];
		$q13_er	 	= $this->qtrsRange['q13_er'];*/
		$q2_sr 		= $this->qtrsRange['q2_sr'];
		$q2_er 		= $this->qtrsRange['q2_er'];
		$q3_sr 		= $this->qtrsRange['q3_sr'];
		$q3_er 		= $this->qtrsRange['q3_er'];
		$q4_sr 		= $this->qtrsRange['q4_sr'];
		$q4_er 		= $this->qtrsRange['q4_er'];
		$q5_sr 		= $this->qtrsRange['q5_sr'];
		$q5_er 		= $this->qtrsRange['q5_er'];
		$cqtr		= $this->qtrsRange['cqtr'];

		$gapObj = new ReviewGap();
		
//        $incidence_data = $gapObj->getGapQuestionActionTracker(false, 0);
        $incidence_data =  $this->getGapQuestionActionTrackerWithBUs();
		
		

        $incidence_data1 = $gapObj->getGapQuestionActionTracker1(false, 0);

        $result = $gapObj->lastInsertID();


        $buObj = SetupGeneric::useModule('organigram');

        



$incidence_data = array_merge($incidence_data, $incidence_data1);
//echo date('Y-m-d', strtotime($result));
		
								
								
								
        foreach ($incidence_data as $element) {
            //dump_array($element);
									
            if ($element['whenDate'] >= $q1_sr && $element['whenDate'] < $q1_er) {
									
                $incidence['q1']['P'] ++;
            } else if ($element['whenDate'] >= $q2_sr && $element['whenDate'] < $q2_er) {
									
                $incidence['q2']['P'] ++;
            } else if ($element['whenDate'] >= $q3_sr && $element['whenDate'] < $q3_er) {
									
                $incidence['q3']['P'] ++;
            } else if ($element['whenDate'] >= $q4_sr && $element['whenDate'] <= $q4_er) {
									
                $incidence['q4']['P'] ++;
            } else if ($element['whenDate'] >= $q5_sr && $element['whenDate'] < $q5_er) {
									
                $incidence['q5']['P'] ++;
            } else if ($element['whenDate'] < $q1_sr) {
									
                $incidence['q6']['A'] ++;
								}
		}

			return array(
				'hlist' => $hlist,
				'dlist' => $dlist,
				'bu_list' => $bu_list,
				'section_data'=>$incidence
				);

	}

	public function getGraphData() {

		$grid_data 	= $this->getData();

		$dlist 		= $grid_data['dlist'];
		$hlist 		= $grid_data['hlist'];
		$ra 		= $grid_data['section_data'];
	//dump_array($ra);
		$graph = array();

		//foreach( $dlist as $d ) {
			//foreach( $hlist as $hk=>$hv ) {

        /* $ra[$d][$hk]['q1']['P'] = $ra[$d][$hk]['q2']['P'] = $ra[$d][$hk]['q3']['P'] = 10;
          $ra[$d][$hk]['q1']['D'] = $ra[$d][$hk]['q2']['D'] = $ra[$d][$hk]['q3']['D'] = 20; */

					$graph['q1']['D'] += $ra['q1']['D'];;
				$graph['q2']['D'] +=  $ra['q2']['D'];;
				$graph['q3']['D'] +=  $ra['q3']['D'];;
				$graph['q4']['D'] +=  $ra['q4']['D'];;

				$graph['q5']['D'] += $ra['q1']['D'] +$ra['q2']['D'] + $ra['q3']['D'] + $ra['q4']['D'];

        $graph['q1']['P'] += $ra['q1']['P'];
				$graph['q2']['P'] += $ra['q2']['P'];
				$graph['q3']['P'] += $ra['q3']['P'];
				$graph['q4']['P'] += $ra['q4']['P'];

				$graph['q5']['P'] += $ra['q1']['P'] +$ra['q2']['P'] + $ra['q3']['P'] + $ra['q4']['P'];
				
				$graph['q6']['A'] += $ra['q6']['A'];

			//}
		//}

		return $graph;
	}

}