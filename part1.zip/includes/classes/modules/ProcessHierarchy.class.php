<?php

/**
  $Id: ProcessFlow.class.php,v 10.0 Saturday, February 05, 2011 1:26:07 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, October 20, 2010 2:57:54 PM>
 */
class ProcessHierarchy {

    private $pfObject;
    private $img;
    private $canvasWidth;
    private $canvasHeight;
    private $colours;
    private $fontFile;
    private $ccps;

    public function __construct() {


        header('Content-type: image/png');

       putenv('GDFONTPATH=' . realpath('.'));
        $this->fontFile = realpath(_PATH_PRIVATE_FILES . '../fonts') . '/arialbd.ttf';
        $objProcessMaster=new ProcessFlowMaster();
        $this->ccps= $objProcessMaster->countCCPs();
    }

    public function setInformation($p_resultSet, $x, $y) {
ini_set('memory_limit','900M');
        $this->pfObject = $p_resultSet;
        $this->canvasWidth = (300 * $x) + 20;
        $this->canvasHeight = 100 * $y;

        $this->img = imagecreatetruecolor($this->canvasWidth, $this->canvasHeight);

        $bgcolour = $this->hex2RGB('#F7F7F7');
        $pcolour = $this->hex2RGB('#DD7032');
        $p2colour = $this->hex2RGB('#449082');
        $textcolour = $this->hex2RGB('#000000');
        $ccpcolour = $this->hex2RGB('#800080');
        $this->colours['background_colour'] = imagecolorallocate($this->img, $bgcolour['red'], $bgcolour['green'], $bgcolour['blue']);
        $this->colours['process_colour'] = imagecolorallocate($this->img, $pcolour['red'], $pcolour['green'], $pcolour['blue']);
        $this->colours['process_colour2'] = imagecolorallocate($this->img, $p2colour['red'], $p2colour['green'], $p2colour['blue']);
        $this->colours['text_colour'] = imagecolorallocate($this->img, $textcolour['red'], $textcolour['green'], $textcolour['blue']);
        $this->colours['ccp_colour'] = imagecolorallocate($this->img, $ccpcolour['red'], $ccpcolour['green'], $ccpcolour['blue']);

    }

    private function wrapText($p_content, $x, $y) {

        $lines = explode('|||', wordwrap($p_content, 30, '|||'));


        foreach ($lines as $line) {
            imagettftext($this->img, 9, 0, $x, $y, $this->colours['text_colour'], $this->fontFile, $line);

            $y += 19;
        }
    }

    private function hex2RGB($hexStr, $returnAsString = false, $seperator = ',') {

        $hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
        $rgbArray = array();

        if (strlen($hexStr) == 6) { //If a proper hex code, convert using bitwise operation. No overhead... faster
            $colorVal = hexdec($hexStr);
            $rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
            $rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
            $rgbArray['blue'] = 0xFF & $colorVal;
        } elseif (strlen($hexStr) == 3) { //if shorthand notation, need some string manipulations
            $rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
            $rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
            $rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
        } else {
            return false; //Invalid hex color code
        }

        return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
    }

    public function drawCanvas() {
        imagefilledrectangle($this->img, 0, 0, $this->canvasWidth, $this->canvasHeight, $this->colours['background_colour']);
    }

    public function drawObjects() {
        foreach ($this->pfObject as $data1) {
            $i = 0;
            foreach ($data1 as $data) {
                $x = (($data["x"] - 1) * 300) + 30;
                $y = (($data["y"] - 1) * 100) + 25;
                if ($i == 0)
                    imagefilledrectangle($this->img, $x, $y, $x + 200, $y + 80, $this->colours['process_colour']);
                else
                    imagefilledrectangle($this->img, $x, $y, $x + 200, $y + 80, $this->colours['process_colour2']);

                if (array_key_exists($data['swimID'],$this->ccps)){
               imagefilledrectangle($this->img, $x, $y, $x + 8, $y + 80, $this->colours['ccp_colour']); 
}
                imagefttext($this->img, 9, 0, $x + 10, $y + 20, $this->colours['text_colour'], $this->fontFile, $data["reference"]);
                //  imagefttext($this->img, 9, 0, $x + 10, $y + 40, $this->colours['text_colour'], $this->fontFile, $data["description"]);
                $this->wrapText($data["description"], $x + 10, $y + 40);

                if ($data["x"] > 1)
                    $this->drawLines($data["linkedID"], $x, $y);

                $i++;
            }
        }
    }

    public function drawLines($data, $x, $y) {

        $x1_arrow = $x;
        $y1_arrow = $y + 40;
        $x2_arrow = $x - 5;
        $y2_arrow = $y1_arrow + 10;
        $x3_arrow = $x - 5;
        $y3_arrow = $y1_arrow - 10;

        $arrow_points = array(
            $x1_arrow, $y1_arrow,
            $x2_arrow, $y2_arrow,
            $x3_arrow, $y3_arrow
        );
//draw arrow
        imagefilledpolygon($this->img, $arrow_points, 3, $this->colours['text_colour']);
        //back towards start
        imageline($this->img, $x, $y + 40, $x - 25, $y + 40, $this->colours['text_colour']);
        //upward towards start
        $data1 = $this->pfObject[$data][0];
        $newy = ($data1["y"] * 100) - 35;
        imageline($this->img, $x - 25, $y + 40, $x - 25, $newy, $this->colours['text_colour']);
        //back towards start
        imageline($this->img, $x - 25, $newy, $x - 100, $newy, $this->colours['text_colour']);
    }

    public function drawfooter() {
        
    }

    public function drawHeader() {
        
    }

    public function showImage() {


        imagepng($this->img);
    }

    public function drawObjectNonLinked($datain, $y1) {

        $y = (($y1 - 1) * 100) - 30;
        $i = 0;

        foreach ($datain as $data) {
            if (($i % 6) == 0)
                $y+=100;
            $x = (($i % 6) * 300) + 30;
            //   $y = (($data["y"] - 1) * 100) + 25;
            imagefilledrectangle($this->img, $x, $y, $x + 200, $y + 80, $this->colours['process_colour']);
if ($this->ccps && array_key_exists($data['swimID'],$this->ccps)){
               imagefilledrectangle($this->img, $x, $y, $x + 8, $y + 80, $this->colours['ccp_colour']); 
}

            
            imagefttext($this->img, 9, 0, $x + 10, $y + 20, $this->colours['text_colour'], $this->fontFile, $data["reference"]);
            $this->wrapText($data["description"], $x + 10, $y + 40);

            $i++;
        }
    }
    
        public function saveImage() {

        $this->outputFile = "process_flow_horizontal_tree.png";
        $output_file_path = realpath("../private_files/process_flow") . "/" . $this->outputFile;

  

            if (function_exists('imagepng')) {
                if (file_exists($output_file_path)) {
                    unlink($output_file_path);
                }

                imagepng($this->img, $output_file_path);
            }
        }
   

}

?>