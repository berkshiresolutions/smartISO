<?php

/**
  $Id: BCPMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, November 03, 2010 12:25:00 PM>
 */
require_once "IAR.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class IARMain implements IAR {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * property contains witness data
     * @access private
     */
    private $reviewIDd;

    /**
     * Property to hold IAR Info
     * @access private
     */
    private $reviewInfo;

    /**
     * Constructor for initializing IAR object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set incidence information for the respective object
     */

    public function setIARInfo($p_IARId, $p_IARInfo) {
        $this->reviewID = $p_IARId;
        $this->reviewInfo = $p_IARInfo;
    }

    /*
     * This method is used to add new incidence
     * reference,unique_reference,incidence_date,incidence_date_time,location,business_unit
     */

    public function getLastInsertID() {
        return $this->reviewID;
    }

    public function purgeIAR() {
        
    }

    public function deleteIAR() {
        
    }

    public function archiveIAR() {
        
    }

    public function getIARpf_id($pos, $auditid) {

        $sql = sprintf("select * from  %s.IAR_pfdata P inner join  %s.swimlane L on P.pf_id=L.swimid where pforder=%d and audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    public function getIARpf_question($IARid) {

        $sql = sprintf("select * from  %s.IAR_pfresults where SLR_ID=%d", _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }

    public function getIARpf_action($IARid) {

        $sql = sprintf("select * from  %s.actions where moduleelement='iar_pfdata' and record=%d", _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    public function getIARdoc_action($IARid) {

        $sql = sprintf("select A.*,D.problem from  %s.actions A inner join %s.iar_doc_action D on A.record=D.ID where moduleelement='iar_doc_action' and D.doc_data_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }

	    public function getIARlib_action($IARid) {

        $sql = sprintf("select A.*,D.problem from  %s.actions A inner join %s.iar_lib_action D on A.record=D.ID where moduleelement='iar_lib_action' and D.lib_data_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }
	
    public function getIARdpf_action($IARid) {

        $sql = sprintf("select A.*,D.problem from  %s.actions A inner join %s.iar_pf_action D on A.record=D.ID where moduleelement='iar_pf_action' and D.pf_data_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }

    public function updateIARpf_id($id, $answer, $comments,$control) {

        $sql = sprintf("update  %s.IAR_pfdata set answer=%d,comments='%s',control=%d where ID=%d", _DB_OBJ_FULL, $answer, $comments,$control, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function removeIARdoc_question($id) {

        $sql = sprintf("delete from  %s.IAR_docresults where SLR_ID=%d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function updateIARdoc_id($id, $answer, $comments,$control) {

       $sql = sprintf("update  %s.IAR_docdata set answer=%d,comments='%s',control=%d where ID=%d", _DB_OBJ_FULL, $answer, $comments, $control, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

	    public function updateIARlib_id($id, $answer, $comments,$control) {

     $sql = sprintf("update  %s.IAR_libdata set answer=%d,comments='%s',control=%d where ID=%d", _DB_OBJ_FULL, $answer, $comments,$control, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    public function add_action($id, $data) {
      $this->aid = $id;
        $this->actionData = $data;
 
          if ($this->actionData['element'] == 'iar_doc_Action'){
                $table = 'iar_doc_Action';
          $col="doc_Data_id";
          }
          elseif ($this->actionData['element'] == 'iar_lib_Action'){
                $table = 'iar_lib_Action';
          $col="lib_Data_id";
          }
            else{
                $table = 'iar_pf_Action';
                $col="pf_Data_id";
            }
        if ($this->aid == 0) {

       $sql = sprintf("insert into %s.%s (problem,%s) VALUES ('%s',%d)", _DB_OBJ_FULL, $table, $col,$this->actionData['problem'], $this->actionData['record']);

            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();

            $last_insert_id = customLastInsertId($this->dbHand, $table, 'ID');
            $this->actionData['record'] = $last_insert_id;
            $this->actionHandling->setActionDetails(0, $this->actionData);
            $new_action_id = $this->actionHandling->addAction2015();
        } else {
            
          $sql = sprintf("UPDATE a SET a.problem = '%s' FROM %s.%s AS a INNER JOIN %s.actions AS b ON a.id = b.record   WHERE b.id = %d", $this->actionData['problem'], _DB_OBJ_FULL, $table, _DB_OBJ_FULL,$this->aid);
            
             $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
            $this->actionHandling->setActionDetails($this->aid, $this->actionData);
            $new_action_id = $this->actionHandling->updateAction2015();
        }
     
    }

    public function updateIARpf_question($id, $question_No, $answer) {

        $sql = sprintf("insert into %s.IAR_pfresults (SLR_ID,question,result) VALUES (%d,%d,'%s')", _DB_OBJ_FULL, $id, $question_No, $answer);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function updateIARdoc_question($id, $question_No, $answer) {

        $sql = sprintf("insert into %s.IAR_docresults (SLR_ID,question,result) VALUES (%d,%d,'%s')", _DB_OBJ_FULL, $id, $question_No, $answer);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    public function updateIARlib_question($id, $question_No, $answer) {

        $sql = sprintf("insert into %s.IAR_libresults (SLR_ID,question,result) VALUES (%d,%d,'%s')", _DB_OBJ_FULL, $id, $question_No, $answer);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
	
    public function getIARdoc_id($pos, $auditid) {

        $sql = sprintf("select * from  %s.IAR_docdata P inner join  %s.cms_documents D on P.doc_id=D.cmsdocid where docorder=%d and audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

	    public function getIARlib_id($pos, $auditid) {

        $sql = sprintf("select P.*,D.title,D.descp,D.document_c,D.d_id from  %s.IAR_libdata P inner join  %s.comms_mangement D on P.lib_id=D.id where liborder=%d and audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $pos, $auditid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }
	
    public function buildIARDoc($auditid, $docs) {
        $i = 1;
        $sql = "insert into %s.iar_docdata (audit_id,doc_id,docorder) values (%d,%d,%d)";


        foreach ($docs as $key=>$doc) {

           $psql = sprintf($sql, _DB_OBJ_FULL, $auditid, $key, $i);
            $pStatement = $this->dbHand->prepare($psql);
            $pStatement->execute();
            $i++;
        }
        
        $sql = sprintf("update  %s.iar_master set doc= %d where reviewid =%d", _DB_OBJ_FULL, ($i-1),$auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        
        }

	    public function buildIARLib($auditid, $docs) {

        $i = 1;
        $sql = "insert into %s.iar_libdata (audit_id,lib_id,liborder) values (%d,%d,%d)";

        foreach ($docs as $key=>$doc) {

           $psql = sprintf($sql, _DB_OBJ_FULL, $auditid, $key, $i);
            $pStatement = $this->dbHand->prepare($psql);
            $pStatement->execute();
            $i++;
        }
        
                $sql = sprintf("update  %s.iar_master set lib= %d where reviewid =%d", _DB_OBJ_FULL, ($i-1),$auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

    }
	
    public function buildIARPf($auditid, $docs) {

        $i = 1;
        $sql = "insert into %s.iar_pfdata (audit_id,pf_id,pforder) values (%d,%d,%d)";


        foreach ($docs as $key=>$doc) {

           $psql = sprintf($sql, _DB_OBJ_FULL, $auditid, $key, $i);
            $pStatement = $this->dbHand->prepare($psql);
            $pStatement->execute();
            $i++;
        }
        
        $sql = sprintf("update  %s.iar_master set pfs= %d where reviewid =%d", _DB_OBJ_FULL, ($i-1),$auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

    }

    public function getTotalDocCount($auditid) {

        $sql = sprintf("select count(*) as docCount from  %s.iar_docdata where audit_id =%d", _DB_OBJ_FULL, $auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["docCount"];
    }

	   public function getTotalLibCount($auditid) {

        $sql = sprintf("select count(*) as libCount from  %s.iar_libdata where audit_id =%d", _DB_OBJ_FULL, $auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["libCount"];
    }
	
    public function getCurrentDocCount($auditid) {

        $sql = sprintf("select count(*) as docCount from  %s.iar_docdata where isnull(answer,0)=0 and audit_id =%d", _DB_OBJ_FULL, $auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["docCount"];
    }

	    public function getCurrentLibCount($auditid) {

        $sql = sprintf("select count(*) as libCount from  %s.iar_libdata where isnull(answer,0)=0 and audit_id =%d", _DB_OBJ_FULL, $auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["libCount"];
    }
	
    public function getTotalPfCount($auditid) {

        $sql = sprintf("select count(*) as pfCount from  %s.iar_pfdata where audit_id =%d", _DB_OBJ_FULL, $auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["pfCount"];
    }

    public function getCurrentPfCount($auditid) {

        $sql = sprintf("select count(*) as pfCount from  %s.iar_pfdata where isnull(answer,0)=0 and audit_id =%d", _DB_OBJ_FULL, $auditid);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result["pfCount"];
    }

    public function listOpenReview2($p_archive_val) {

        $sql = sprintf("SELECT M.* from %s.iar_master M

				WHERE M.isFinish = '0' AND M.archive = '%s' 
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listclosedReview2($p_archive_val) {

        $sql = sprintf("SELECT M.* from %s.iar_master M

				WHERE M.isFinish = '1' AND M.archive = '%s' 
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL, $p_archive_val); // startTime

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function startReview($p_reviewType, $p_businessId, $p_mseListId = 0, $p_ref = "Admin", $audit,$grp,$soalink,$pftype) {

        $this->questionList = '';
        $this->buID = $p_businessId;
        $this->reference = $p_ref;
        $this->audit = $audit;
        $this->grp = $grp;
        $this->pf_type = $pftype;
        $this->soalink = $soalink;
        $default_datetime = '1900-01-01 00:00:00';


        $sql = sprintf("INSERT INTO %s.iar_master (auditorID,buID,startTime,endTime,reviewType,is_complete,current_question,questions,reference,auditlink,grouptype,soalink,pf_type)
				VALUES (%d, '%s'," . customCurrentDate() . ",'%s', '%s','0','1','%s','%s',%d,%d,%d,%d)"
                , _DB_OBJ_FULL
                , $this->auditorID
                , $this->buID
                , $default_datetime
                , $this->reviewType
                , $this->questionList
                , $this->reference
                , $this->audit
                , $this->grp
                , $this->soalink
                , $this->pf_type);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $last_insert_id = customLastInsertId($this->dbHand, 'iar_master', 'reviewID');

        //$this->buildIARDoc($last_insert_id, $this->buID);
        //$this->buildIARPf($last_insert_id, $this->buID);
        //$this->buildIARLib($last_insert_id, $this->buID);
        return $last_insert_id;
    }

    public function editOrganigramDetail() {
        $sql = "update %s.iar_audit_detail set archive=1 where rID=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $sql = "INSERT into %s.iar_audit_detail(plan_d,summary,rID)
            VALUES('%s','%s', %d)";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewInfo['plan'], $this->reviewInfo['summary'], $this->reviewID);

        $stmt = $this->dbHand->prepare($psql);

        return $stmt->execute();
    }

    public function updatePersonDetail() {

        $sql = "update %s.iar_audit_participants set archive=1 where reviewID=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $sql = "INSERT into %s.iar_audit_participants (reviewID,persontype,personid) VALUES (%d,'%s',%d)";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'L', $this->reviewInfo["l_aud"]);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        if ($this->reviewInfo["auditor"]) {
            foreach ($this->reviewInfo["auditor"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'A', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }

        if ($this->reviewInfo["audit"]) {
            foreach ($this->reviewInfo["audit"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'E', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }
        if ($this->reviewInfo["person"]) {
            foreach ($this->reviewInfo["person"] as $p => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->reviewID, 'P', $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }

        return;
    }

        public function moveFiles($p_identifier, $ridA, $rid) {
        $rec_id = $ridA;
        $this->questionId = $rec_id;
        $module = 'review';

        // $this->removeDocFiles(); consider how this would work

      $path = _MYROOT . 'tmp/review' . $p_identifier;


  $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();

            if (is_array($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);


                            $file_details = array('user_file_name' => $file_details_arr[2]
                                , 'name' => ''
                                , 'tmp_name' => ''
                                , 'file_details' => ''
                                , 'size' => 0
                                , 'id' => 0
                                , 'error' => 0
                                , 'destination' => ''
                                , 'file_type' => $file_type
                                , 'type' => $file_type
                            );


                            $objFile->setFileInfo($module, $file_details);

                            $objFile->setBogusDetails($file_details);

                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
//	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);

                                    $this->setIARInfo($rid, $data_array);
                                    $this->addDocFiles();
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }
    
    public function moveDocFiles($p_identifier, $ridA, $rid) {
        $rec_id = $ridA;
        $this->questionId = $rec_id;
        $module = 'review';

        // $this->removeDocFiles(); consider how this would work

        $path = _MYROOT . 'tmp/' . $p_identifier;


        $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();


            if (is_array($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);


                            $file_details = array('user_file_name' => $file_details_arr[2]
                                , 'name' => ''
                                , 'tmp_name' => ''
                                , 'file_details' => ''
                                , 'size' => 0
                                , 'id' => 0
                                , 'error' => 0
                                , 'destination' => ''
                                , 'file_type' => $file_type
                                , 'type' => $file_type
                            );


                            $objFile->setFileInfo($module, $file_details);

                            $objFile->setBogusDetails($file_details);

                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
//	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);

                                    $this->setIARInfo($rid, $data_array);
                                    $this->addDocFiles();
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }

    public function movePfFiles($p_identifier, $ridA, $rid) {
        $rec_id = $ridA;

        $module = 'review';

        $path = _MYROOT . 'tmp/' . $p_identifier;


        $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();


            if (is_array($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);


                            $file_details = array('user_file_name' => $file_details_arr[2]
                                , 'name' => ''
                                , 'tmp_name' => ''
                                , 'file_details' => ''
                                , 'size' => 0
                                , 'id' => 0
                                , 'error' => 0
                                , 'destination' => ''
                                , 'file_type' => $file_type
                                , 'type' => $file_type
                            );


                            $objFile->setFileInfo($module, $file_details);

                            $objFile->setBogusDetails($file_details);

                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
//	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);

                                    $this->setIARInfo($rid, $data_array);
                                    $this->addIARFiles();
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }

	    public function moveLibFiles($p_identifier, $ridA, $rid) {
        $rec_id = $ridA;
        $this->questionId = $rec_id;
        $module = 'review';

        // $this->removeDocFiles(); consider how this would work

        $path = _MYROOT . 'tmp/' . $p_identifier;


        $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();


            if (is_array($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);


                            $file_details = array('user_file_name' => $file_details_arr[2]
                                , 'name' => ''
                                , 'tmp_name' => ''
                                , 'file_details' => ''
                                , 'size' => 0
                                , 'id' => 0
                                , 'error' => 0
                                , 'destination' => ''
                                , 'file_type' => $file_type
                                , 'type' => $file_type
                            );


                            $objFile->setFileInfo($module, $file_details);

                            $objFile->setBogusDetails($file_details);

                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
//	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $data_array = array('file_id' => $file_id, 'identifier' => $p_identifier);

                                    $this->setIARInfo($rid, $data_array);
                                    $this->addLibFiles();
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }
	
    public function addIARFiles() {

        $record_data = $this->reviewDocId;

        $new_files_id_string = $record_data['uploadFilesID'] . ',' . $this->reviewInfo['file_id'];
        $new_files_id_string = ltrim($new_files_id_string, ',');

        $sql2 = sprintf(" insert into %s.iar_files (uploadedFileID,questionID,type) VALUES (%d,%d,2)", _DB_OBJ_FULL, $new_files_id_string, $this->reviewID);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

        public function addIARDetailFiles($did,$rid) {


        $sql2 = sprintf(" insert into %s.iar_detail_files (fileID,rID) VALUES (%d,%d)", _DB_OBJ_FULL, $did, $rid);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }
    
    public function getIARFiles($p_rid) {
        $this->reviewID = $p_rid;
        $sql = sprintf("select * from %s.iar_detail_files where rID=%d"
                , _DB_OBJ_FULL
                , $this->reviewID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

        public function getIARFile($id) {
        $this->reviewID = $id;
        $sql = sprintf("delete from %s.iar_detail_files where ID=%d"
                , _DB_OBJ_FULL
                , $this->reviewID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
    
    public function getReviewInfo($p_reviewID) {

        $sql = sprintf("SELECT M.* FROM %s.iar_master M

				WHERE M.reviewID = %d", _DB_OBJ_FULL, $p_reviewID);

        $stmt = $this->dbHand->prepare($sql);
//$stmt->bindParam(1,$p_doc_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getParticipants($id) {
        $this->id = $id;
        $sql = "SELECT R.persontype,P.forename+' '+P.surname  as name,R.personid FROM %s.iar_audit_participants R inner join %s.participant_database P on R.personid=P.participantid WHERE R.archive=0 and reviewID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDetailOrgan($id) {
        $this->id = $id;
        $sql = "SELECT * FROM %s.iar_audit_detail WHERE archive=0 and rID = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getIAFiles($p_rid) {
        $this->reviewID = $p_rid;
        $sql = sprintf("select * from %s.iar_detail_files where rID=%d"
                , _DB_OBJ_FULL
                , $this->reviewID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function finishReviewOutside($p_review_id) {

        $sql = sprintf("UPDATE %s.iar_master
				SET is_complete = '1',
                                isFinish = '1',
				endTime = " . customCurrentDate() . "
				WHERE reviewID = %d", _DB_OBJ_FULL, $p_review_id);


        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        $this->sendActionEmails($p_review_id);
    }

    public function sendActionEmails($aid) {

        $reviewData = $this->getReviewInfo($aid);
        // $sql = sprintf("select A.* from %s.actions A  where moduleName='ISA_Action' ",_DB_OBJ_FULL,$aid);
       $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.iar_doc_Action R on A.record=R.ID inner join %s.iar_docdata D on R.doc_data_id=D.ID  where moduleName='ISA_Action' and moduleelement='iar_doc_action' and D.audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, $aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);





        if (is_array($result) ) {  //only mse give actions 
            foreach ($result as $value) {

                $emailObj = new actionEmailHelper($value["ID"]);


                $who = $emailObj->getwhoDetails();

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/isa.php">CLICK</a> Here to View ISA - Review Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/iareview/reportiar.php?id=' . $aid . '">CLICK</a> Here to View ISA -Review Report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $reviewData["reference"]
                        ),
                            'problem' => array(
                            'left' => '<strong>Problem</strong>',
                            'right' => $value["problem"]
                        )
                    )
                );
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('An ISA Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $whoAU = $emailObj->getAUDetails();
                $emailObj->sendEmail('An ISA  Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

                if ($value['who2AU'] > 0) {
                    $who2AU = $emailObj->getSecondApproverDetails();
                    $emailObj->sendEmail('An ISA Action Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
                }
            }
        }

        $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.iar_pf_Action R on A.record=R.ID inner join %s.iar_pfdata P on A.record=P.ID  where moduleName='ISA_Action' and moduleelement='iar_pf_Action' and P.audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $aid);
    //    $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.iar_doc_Action R on A.record=R.ID inner join %s.iar_docdata D on R.doc_data_id=D.ID  where moduleName='ISA_Action' and moduleelement='iar_doc_action' and D.audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, $aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);





        if (is_array($result)) {  //only mse give actions 
            foreach ($result as $value) {

                $emailObj = new actionEmailHelper($value["ID"]);


                $who = $emailObj->getwhoDetails();

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/iss.php">CLICK</a> Here to View Stage 1 Review Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/system_review/word2.php?id=' . $aid . '">CLICK</a> Here to View IA -MSE Report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $reviewData["reference"]
                          ),
                            'problem' => array(
                            'left' => '<strong>Problem</strong>',
                            'right' => $value["problem"]
                    )
            )
                );
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('An ISA Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $whoAU = $emailObj->getAUDetails();
                $emailObj->sendEmail('An ISA  Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

                if ($value['who2AU'] > 0) {
                    $who2AU = $emailObj->getSecondApproverDetails();
                    $emailObj->sendEmail('An ISA Action Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
                }
            }
        }
        
	    $sql = sprintf("select A.*,R.problem from %s.actions A inner join %s.iar_doc_Action R on A.record=R.ID inner join %s.iar_libdata D on R.lib_data_id=D.ID  where moduleName='ISA_Action' and moduleelement='iar_lib_action' and D.audit_id=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, $aid);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);





        if (is_array($result) ) {  //only mse give actions 
            foreach ($result as $value) {

                $emailObj = new actionEmailHelper($value["ID"]);


                $who = $emailObj->getwhoDetails();

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/iss.php">CLICK</a> Here to View Stage 1 Review Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/system_review/word2.php?id=' . $aid . '">CLICK</a> Here to View IA -MSE Report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $reviewData["reference"]
                          ),
                            'problem' => array(
                            'left' => '<strong>Problem</strong>',
                            'right' => $value["problem"]
                    )
            )
                );
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('An ISA Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $whoAU = $emailObj->getAUDetails();
                $emailObj->sendEmail('An ISA  Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

                if ($value['who2AU'] > 0) {
                    $who2AU = $emailObj->getSecondApproverDetails();
                    $emailObj->sendEmail('An ISA Action Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
                }
            }
        }
    }

    public function getIARdoc_question($IARid) {

        $sql = sprintf("select * from  %s.IAR_docresults where SLR_ID=%d", _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }
	   public function getIARlib_question($IARid) {

        $sql = sprintf("select * from  %s.IAR_libresults where SLR_ID=%d", _DB_OBJ_FULL, $IARid);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }

    public function removeIARpf_question($id) {

        $sql = sprintf("delete from  %s.IAR_pfresults where SLR_ID=%d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

	    public function removeIARlib_question($id) {

        $sql = sprintf("delete from  %s.IAR_libresults where SLR_ID=%d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    public function archiveReview($p_review_id, $p_archive_val) {

        $sql = sprintf("UPDATE %s.iar_master SET archive = '%s' WHERE reviewID = %d", _DB_OBJ_FULL, $p_archive_val, $p_review_id);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
    }

    public function addDocFiles($p_id,$file_id) {



        $sql2 = sprintf(" insert into %s.iar_files (uploadedFileID,questionID,type) VALUES (%d,%d,1)", _DB_OBJ_FULL, $file_id,$p_id);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

        public function deleteDocFiles($file_str) {



     $sql2 = sprintf(" delete from %s.iar_files where uploadedFileID in (%s) ", _DB_OBJ_FULL, $file_str);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }
    
            public function deletePFsFiles($file_str) {



     $sql2 = sprintf(" delete from %s.iar_files where uploadedFileID in (%s) ", _DB_OBJ_FULL, $file_str);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }
    
            public function deleteLibFiles($file_str) {



     $sql2 = sprintf(" delete from %s.iar_files where uploadedFileID in (%s) ", _DB_OBJ_FULL, $file_str);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }
    
        public function addPfFiles($p_id,$file_id) {



        $sql2 = sprintf(" insert into %s.iar_files (uploadedFileID,questionID,type) VALUES (%d,%d,2)", _DB_OBJ_FULL, $file_id,$p_id);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }
    
	    public function addLibFiles($p_id,$file_id) {
/*
        $record_data = $this->reviewDocId;

        $new_files_id_string = $record_data['uploadFilesID'] . ',' . $this->reviewInfo['file_id'];
        $new_files_id_string = ltrim($new_files_id_string, ',');

        $sql2 = sprintf(" insert into %s.iar_files (uploadedFileID,questionID,type) VALUES (%d,%d,1)", _DB_OBJ_FULL, $new_files_id_string, $this->reviewID);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
 * */
        $sql2 = sprintf(" insert into %s.iar_files (uploadedFileID,questionID,type) VALUES (%d,%d,3)", _DB_OBJ_FULL, $file_id,$p_id);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

    }
	
    public function removeDocFiles() {

        $sql2 = sprintf(" delete from %s.iar_files where type=1 and questionid=%d", _DB_OBJ_FULL, $this->questionId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function getDocFile($id) {

        $sql = sprintf("SELECT * FROM %s.iar_files WHERE questionID = %d and type=1 "
                , _DB_OBJ_FULL
                , $id
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $resultSet;
    }

	    public function getLibFile($id) {

        $sql = sprintf("SELECT * FROM %s.iar_files WHERE questionID = %d and type=3 "
                , _DB_OBJ_FULL
                , $id
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $resultSet;
    }
    public function getPfsFile($id) {

        $sql = sprintf("SELECT * FROM %s.iar_files WHERE questionID = %d and type=2 "
                , _DB_OBJ_FULL
                , $id
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $resultSet;
    }

    
    public function addReason($reviewid,$type,$reason,$recordID) {



    }
     public function createAudit(){
if (is_array($this->reviewInfo["docs"]))
        $this->buildIARDoc($this->reviewID,$this->reviewInfo["docs"]);
        if (is_array($this->reviewInfo["docs_reason"])){      
        foreach($this->reviewInfo["docs_reason"] as $key=>$reason){
          if ($reason !='' )
       $this->addReason($this->reviewID,'DOC',$reason,$key) ;  
        }  
      }
      if (is_array($this->reviewInfo["pfs"]))
             $this->buildIARPf($this->reviewID,$this->reviewInfo["pfs"]);
      if (is_array($this->reviewInfo["pfs_reason"])){
            foreach($this->reviewInfo["pfs_reason"] as $key=>$reason){
          if ($reason !='' )
       $this->addReason($this->reviewID,'PFS',$reason,$key) ;  
          
      }
      }
      if (is_array($this->reviewInfo["libs"]))
       $this->buildIARLib($this->reviewID,$this->reviewInfo["libs"]);
             if (is_array($this->reviewInfo["libs_reason"])){
      foreach($this->reviewInfo["libs_reason"] as $key=>$reason){
          if ($reason !='' )
       $this->addReason($this->reviewID,'LIB',$reason,$key) ;  
          
      }
             }
      
    }
     public function addAuditInterviewees($personid,$reviewid){
                $sql = sprintf("select count(*) as cnt %s.iar_audit_participants where persontype='P' and personid=%d and reviewid=%d  "
                , _DB_OBJ_FULL
                , $personID
                , $reviewid

                
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
        if ($resultSet["cnt"] ==0){
             $sql = sprintf("insert into %s.iar_audit_participants (uploadedFileID,questionID,type) VALUES (%d,%d,3)"  
                , _DB_OBJ_FULL
                , $personID
                , $reviewid

                
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        }
        
        
     }
   
         public function getReqdDocActions() {
//select * from  iar_master M inner join IAR_docdata P on M.reviewID=P.audit_id inner join  iar_doc_Action D on P.ID=D.doc_Data_id inner join actions A on D.id=A.record where A.moduleElement='iar_docdata' and approveAU=1    
        $sql = sprintf("SELECT M.* from %s.iar_master M

				WHERE M.isFinish = '0' and M.is_complete = '1' AND M.archive = '0' 
				ORDER BY M.reviewID DESC", _DB_OBJ_FULL); // startTime
                                //
//SELECT M.reviewID,D.answer,A.id from iar_master M inner join iar_docdata D on M.reviewid=D.audit_id inner join iar_doc_Action A on D.ID=A.doc_Data_id where isnull(M.isFinish,0) = 0 and M.is_complete = 1 AND isnull(M.archive,0) = 0 
 // select * from actions where moduleElement='iar_doc_action'
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
	
	         public function getSOAData($id,$review) {
        $sql = sprintf("select * from %s.msr_departments where id=%d", _DB_OBJ_FULL,$id); 

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
		$res=$stmt->fetch(PDO::FETCH_ASSOC);
		

	$sql = sprintf("select * from %s.soa_data D inner join %s.soaAnswerData A on D.ID=A.questionID where clause='%s' and A.reviewID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,"A.".$res['code'],$review);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>