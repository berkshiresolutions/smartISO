<?php

/**
  $Id: InvestigationMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Thursday, November 04, 2010 8:32:17 AM>
 */
require_once "Investigation.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class NhcInvestigationMain implements Investigation {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold Investigation Id
     * @access private
     */
    private $investigationId;

    /**
     * Property to hold Investigation Info
     * @access private
     */
    private $investigationInfo;
    private $inadequacyData;

    /**
     * Constructor for initializing Investigation object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set investigation information for the respective object
     */

    public function setInvestigationInfo($p_investigationId, $p_investigationInfo) {

        $this->investigationId = $p_investigationId;
        $this->investigationInfo = $p_investigationInfo;
    }

    /*
     * This method is used to add new investigation
     * incidence_id,reference,unique_reference
     */

    public function addInvestigation() {

        $sql = sprintf("SELECT * FROM %s.nhc_investigation WHERE reference = '%s'", _DB_OBJ_FULL, $this->investigationInfo['reference']);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->investigationInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($resultSet)) {
            throw new ErrorException('Investigation with this Reference # already exists.');
        } else {
            $USER_ID = getLoggedInUserId();

            $sql2 = sprintf("INSERT INTO %s.nhc_investigation (incID,reference,uniqueReference,archive,status,whoID)
											VALUES (%d,'%s','%s','0','0',%d)", _DB_OBJ_FULL, $this->investigationInfo['incidence_id'], $this->investigationInfo['reference'], $this->investigationInfo['unique_reference'], $this->investigationInfo['who_id']);
            $pStatement2 = $this->dbHand->prepare($sql2);


            /* $pStatement2->bindParam(1,$this->investigationInfo['incidence_id']);
              $pStatement2->bindParam(2,$this->investigationInfo['reference']);
              $pStatement2->bindParam(3,$this->investigationInfo['unique_reference']); */

            $pStatement2->execute();
            $this->investigationId = customLastInsertId($this->dbHand, 'nhc_investigation', 'ID');
        }
    }

    /*
     * This method is used to edit an investigation
     */

    public function editInvestigation() {

        $sql = sprintf("UPDATE %s.nhc_investigation
						SET whoID = %d
						WHERE ID = %d", _DB_OBJ_FULL, $this->investigationInfo['who_id'], $this->investigationId);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    /**
     * This method is used to manage Incident Analysis
     * incident_analysis,description
     */
    public function manageIncidentAnalysis() {
        $sql2 = sprintf(" UPDATE %s.nhc_investigation SET incidentAnalysis = '%s',
										incidentAnalysisDescription = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->investigationInfo['incident_analysis'], $this->investigationInfo['description'], $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->investigationInfo['incident_analysis']);
          $pStatement2->bindParam(2,$this->investigationInfo['description']);
          $pStatement2->bindParam(3,$this->investigationId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to manage Immediate Causes
     * immediate_causes,description
     */
    public function manageImmediateCauses() {
        $sql2 = sprintf(" UPDATE %s.nhc_investigation SET immediateCauses = '%s',
										immediateCausesDescription = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->investigationInfo['immediate_causes'], $this->investigationInfo['description'], $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->investigationInfo['immediate_causes']);
          $pStatement2->bindParam(2,$this->investigationInfo['description']);
          $pStatement2->bindParam(3,$this->investigationId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to manage Basic Causes
     * basic_causes,description
     */
    public function manageBasicCauses() {
        $sql2 = sprintf(" UPDATE %s.nhc_investigation SET basicCauses = '%s',
										basicCausesDescription = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->investigationInfo['basic_causes'], $this->investigationInfo['description'], $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->investigationInfo['basic_causes']);
          $pStatement2->bindParam(2,$this->investigationInfo['description']);
          $pStatement2->bindParam(3,$this->investigationId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to manage Inadequacies
     *
     */
    public function manageInadequacies() {

        $this->resetInadequacies();

        $sql1 = "SELECT * FROM %s.nhc_investigation_inadequacies WHERE invID = %d AND section = '%s' AND inadequacyID = %d";



        /* $pStatement->bindParam(1,$this->investigationId);
          $pStatement->bindParam(2,$this->investigationInfo['section']); */

        if ($this->investigationInfo['section_data']) {

            foreach ($this->investigationInfo['section_data'] as $value) {

                //$pStatement->bindParam(3,$value['inadequacy_id']);
                $sql = sprintf($sql1, _DB_OBJ_FULL, $this->investigationId, $this->investigationInfo['section'], $value['inadequacy_id']);
                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
                $result = $pStatement->fetch(PDO::FETCH_ASSOC);

                $this->inadequacyData = array(
                    'inadequacyId' => $value['inadequacy_id'],
                    'inadequacyValues' => $value['selected_values'],
                    'reason' => $value['reason']
                );

                if ($result) {
                    //update data
                    $inadId = $result['ID'];
                    $this->updateInadequacy($inadId);
                } else {
                    //add data
                    $this->addInadequacy();
                }
            }
        }
    }

    private function resetInadequacies() {

        $sql = sprintf("UPDATE %s.nhc_investigation_inadequacies SET inadequacySelectedValues = NULL,inadequacyReason = NULL WHERE invID = %d AND section = '%s'", _DB_OBJ_FULL, $this->investigationId, $this->investigationInfo['section']);

        $pStatement = $this->dbHand->prepare($sql);
        /* $pStatement->bindParam(1,$this->investigationId);
          $pStatement->bindParam(2,$this->investigationInfo['section']); */

        $pStatement->execute();
    }

    private function addInadequacy() {

        $sql = sprintf("INSERT INTO %s.nhc_investigation_inadequacies (invID,section,inadequacyID,inadequacySelectedValues,inadequacyReason)
													VALUES (%d,'%s',%d,'%s','%s') ", _DB_OBJ_FULL, $this->investigationId, $this->investigationInfo['section'], $this->inadequacyData['inadequacyId'], $this->inadequacyData['inadequacyValues'], $this->inadequacyData['reason']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->investigationId);
          $pStatement->bindParam(2,$this->investigationInfo['section']);

          $pStatement->bindParam(3,$this->inadequacyData['inadequacyId']);
          $pStatement->bindParam(4,$this->inadequacyData['inadequacyValues']);
          $pStatement->bindParam(5,$this->inadequacyData['reason']); */

        $pStatement->execute();
    }

    private function addInadequacyDeprecated() {

        $sql = sprintf("INSERT INTO %s.nhc_investigation_inadequacies (invID,section,inadequacyID,inadequacySelectedValues,inadequacyReason)
													VALUES (%d,'%s',%d,'%s','%s')", _DB_OBJ_FULL, $this->investigationId, $this->investigationInfo['section'], $this->investigationInfo['inadequacy_id'], $this->investigationInfo['inadequacy_selected_values'], $this->investigationInfo['reason']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->investigationId);
          $pStatement->bindParam(2,$this->investigationInfo['section']);
          $pStatement->bindParam(3,$this->investigationInfo['inadequacy_id']);
          $pStatement->bindParam(4,$this->investigationInfo['inadequacy_selected_values']);
          $pStatement->bindParam(5,$this->investigationInfo['reason']); */

        $pStatement->execute();
    }

    private function updateInadequacy($p_id) {

        $sql = sprintf("UPDATE %s.nhc_investigation_inadequacies SET inadequacySelectedValues = '%s',
														inadequacyReason = '%s'
													WHERE ID = $p_id", _DB_OBJ_FULL, $this->inadequacyData['inadequacyValues'], $this->inadequacyData['reason']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->inadequacyData['inadequacyValues']);
          $pStatement->bindParam(2,$this->inadequacyData['reason']); */

        $pStatement->execute();
    }

    public function updateInadequacyDescription() {

        $sql2 = sprintf("UPDATE %s.nhc_investigation SET inadequacy" . ucwords($this->investigationInfo['section']) . "Description = '%s' WHERE ID = %d ", _DB_OBJ_FULL, $this->investigationInfo['section_description'], $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);
        /* $pStatement2->bindParam(1,$this->investigationInfo['section_description']);
          $pStatement2->bindParam(2,$this->investigationId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to manage action
     * actions = array(array('action'=>'dfg','who'=>'gdfg','when'=>'gdfg','action_id'=>23),
     * 					array('action'=>'dfg','who'=>'gdfg','when'=>'gdfg','action_id'=>23),
     * 					array('action'=>'dfg','who'=>'gdfg','when'=>'gdfg','action_id'=>23));
     */
    public function manageActions() {

        if (count($this->investigationInfo['actions'])) {
            $action_ids = "";
			            $save_finish = (int) $_POST['save_finish'];
            $update_save = (int) $_POST['update_save'];
			 $actionHandler = new Action();
			 
            foreach ($this->investigationInfo['actions'] as $value) {
               

               // $this->actionData = array('module_name' => 'nhcInvestigation', 'description' => $value['action'],
               //     'who' => $value['who'], 'whoAU' => $value['whoAU'], 'whoAU2' => $value['whoAU2'], 'due_date' => $value['when']);

                $this->actionData = array('description' => $value['action'],
            'who' => $value['who'],
            'who2AU' => $value['whoAU2'],
            'whoAU' => $value['whoAU'],
            'module_name' => "nhcInvestigation",
            'record' => $this->investigationId,
            'status' => 0,
            'element' => "nhcInvestigation",
            'currentwho' => $value['who'],
            'due_date' => $value['when']);
                
                if (!$value['action_id']) {
                    $actionHandler->setActionDetails(0, $this->actionData);
                    $value["ID"] = $actionHandler->addAction2015();
					if ($update_save == 1){
                        $this->sendAction($value["ID"]);
                    }
                } else {
                    $actionHandler->setActionDetails($value['action_id'], $this->actionData);
                    $actionHandler->updateAction2015();
                    $value["ID"] = $value['action_id'];
                }
                $action_ids .= $value['ID'] . ',';
	
            }
$action_ids = rtrim($action_ids, ',');
           // $this->actionHandling->updateAction();



            
        }

        $action_ids = rtrim($action_ids, ',');
        $sql2 = sprintf(" UPDATE %s.nhc_investigation SET actionsID = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $action_ids, $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    /*
     * This method is used to update investigation process
     * process,is_risk
     */

    public function manageProcess() {

        $sql2 = sprintf(" UPDATE %s.nhc_investigation SET processID = %d,
										isRiskValid = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->investigationInfo['process'], $this->investigationInfo['is_risk'], $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    /*
     * This method is used to delete an investigation
     */

    public function deleteInvestigation() {
        
    }

    /*
     * This method is used to archive an investigation record
     */

    public function archiveInvestigation() {
        $sql2 = sprintf(" UPDATE %s.nhc_investigation SET archive = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->investigationInfo['archive'], $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->investigationInfo['archive']);
          $pStatement2->bindParam(2,$this->investigationId); */

        $pStatement2->execute();
    }

    /*
     * This method is used to completely delete an investigation record
     */

    public function purgeInvestigation() {

        $rec_details = $this->viewInvestigationById();
        //dump_array($rec_details);
        $action_arr = explode(',', $rec_details['actionsID']);
        //dump_array($action_arr);

        if (count($action_arr)) {
            foreach ($action_arr as $value) {
                if ($value != '') {
                    $this->actionHandling->setActionDetails($value, "");
                    $this->actionHandling->deleteAction();
                }
            }
        }

        $sql = sprintf("DELETE FROM %s.nhc_investigation_inadequacies WHERE invID = %d", _DB_OBJ_FULL, $this->investigationId);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->investigationId);
        $pStatement->execute();

        $sql2 = sprintf("DELETE FROM %s.nhc_investigation WHERE ID = %d", _DB_OBJ_FULL, $this->investigationId);

        $pStatement2 = $this->dbHand->prepare($sql2);
        //$pStatement2->bindParam(1,$this->investigationId);
        $pStatement2->execute();
    }

    /**
     * This method is used to get last insert id
     */
    public function lastRecordId() {
        return $this->investigationId;
    }

    /*
     * This method is used to view an investigation record
     */

    public function viewInvestigationById() {

        $sql = sprintf("SELECT * FROM %s.nhc_investigation WHERE ID = %d", _DB_OBJ_FULL, $this->investigationId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->bindParam(1, $this->investigationId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet[0];
    }

    public function viewInvestigationByIncidence() {

        $sql = sprintf("SELECT * FROM %s.nhc_investigation WHERE incID = %d", _DB_OBJ_FULL, $this->investigationInfo['incidence_id']);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->investigationInfo['incidence_id']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view investigation records
     */

    public function viewInvestigations() {

        //$sql = sprintf("SELECT * FROM %s.nhc_investigation WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->investigationInfo['archive']);

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.nhc_investigation A
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHPINV'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->investigationInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->investigationInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view investigation records by Log Date
     */

    public function viewInvestigationsByLogDate() {

        //$sql = sprintf("SELECT * FROM %s.nhc_investigation WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->investigationInfo['archive']);

        $date_range = '';

        if ($this->investigationInfo['start_date'] != '--' && $this->investigationInfo['end_date'] != '--' && $this->investigationInfo['start_date'] != '' && $this->investigationInfo['end_date'] != '') {
            $date_range = " AND (dateTimestamp BETWEEN '" . $this->investigationInfo['start_date'] . " 00:00:00.000' AND '" . $this->investigationInfo['end_date'] . " 23:59:59.000') ";
            $join_type = 'INNER';
            $date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
        } else {
            $date_range = '';
            $join_type = 'LEFT OUTER';
            $date_timestamp_not_null = '';
        }

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.nhc_investigation A
				" . $join_type . " JOIN (
					SELECT recID,
						dateTimestamp,
						whoID as userID,
						reference as recordRef,
						role
					FROM %s.module_tracker
					WHERE module = 'NHPINV'
					AND action = 'add'
					" . $date_timestamp_not_null . "
				) B
				ON recordRef = reference
				WHERE A.archive = '%s'
				$date_range
				ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->investigationInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->investigationInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view investigation records
     */

    public function viewInadequacies() {

        $sql = sprintf(" SELECT * FROM %s.nhc_investigation_inadequacies WHERE invID = %d AND section = '%s'", _DB_OBJ_FULL, $this->investigationId, $this->investigationInfo['section']);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->investigationId);
          $pStatement->bindParam(2,$this->investigationInfo['section']); */
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewInadequacies44($sec, $id) {

        $this->sec = $sec;
        $this->id = $id;

        $sql = sprintf(" SELECT * FROM %s.nhc_investigation_inadequacies WHERE invID = %d AND section = '%s'", _DB_OBJ_FULL, $this->id, $this->sec);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->investigationId);
          $pStatement->bindParam(2,$this->investigationInfo['section']); */
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view action records
     */

    public function viewActions() {

        $resultSet = $this->viewInvestigationById();

        $actions = $resultSet['actionsID'];

        if ($actions != '') {
            $actions_id_arr = explode(',', $actions);
            if (count($actions_id_arr)) {
                $i = 0;
                foreach ($actions_id_arr as $value) {
                    $this->actionHandling->setActionDetails($value, "");
                    $action_data = $this->actionHandling->viewAction();
                    if ($action_data) {
                        $action_details[$i] = $this->actionHandling->viewAction();
                        $action_details[$i]['action_id'] = $value;
                        $i++;
                    }
                }
                return $action_details;
            }
        }
    }

    public function getOutstandingActionsDepreciated() {

        $data = $this->actionHandling->viewAllActionByModule('investigation');

        if (count($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT M.reference,I.buID,M.ID AS inc_id FROM %s.nhc_investigation M
												INNER JOIN %s.nhp I
													ON I.ID = M.incID
											WHERE M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' ", _DB_OBJ_FULL, _DB_OBJ_FULL, $search_value1, $search_value2, $search_value3, $search_value4);

                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$search_value1);
                  $pStatement->bindParam(2,$search_value2);
                  $pStatement->bindParam(3,$search_value3);
                  $pStatement->bindParam(4,$search_value4); */

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (count($action_data)) {

                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['buID'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['whoAU'] = $value['whoAU'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                        $new_data[$i]['risk_id'] = $value2['inc_id'];
                    }
                    $i++;
                }
            }
        }
        return $new_data;
    }

    public function addOutstandingAction() {

        $sql = sprintf("SELECT actionsID FROM %s.nhc_investigation WHERE ID = %d ", _DB_OBJ_FULL, $this->investigationId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->investigationId);
        $pStatement->execute();

        $improvements = $pStatement->fetchColumn();
        $new_improvements = $improvements . ',' . $this->investigationInfo['new_improvement'];

        $sql2 = sprintf("UPDATE %s.nhc_investigation SET actionsID = %d WHERE ID = %d ", _DB_OBJ_FULL, $new_improvements, $this->investigationId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$new_improvements);
          $pStatement2->bindParam(2,$this->investigationId); */
        $pStatement2->execute();
    }

    protected function getNoOfInvestigations() {

        $sql = sprintf("SELECT I.* FROM %s.nhp I
									INNER JOIN %s.nhc_investigation N
										ON N.incID = I.ID ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $all_rows = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($all_rows);
        if (count($all_rows)) {
            foreach ($all_rows as $row) {

                $bu_id = $row['businessUnitID'];
                $date_time = $row['date'];
                $year = substr($date_time, 0, 4);

                $result_set[$year][$bu_id] ++;
            }

            return $result_set;
        }
    }

    public function updateStatus() {
        $sql = sprintf("UPDATE %s.nhc_investigation SET status = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->investigationId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->investigationId);
        $pStatement->execute();
    }

    public function sendActionAlerts($p_record_id) {

        $this->investigationId = $p_record_id;

        $inv_details = $this->viewInvestigationById();


        $objNHC = new NhpMain();
        $objNHC->setNhpInfo($inv_details['incID'], array());
        $nhpData = $objNHC->viewNhpById();
        $objNHC = null;

        $record_data = $this->viewActions();

        if (count($record_data)) {
            $i = 0;
            $orgObj = SetupGeneric::useModule('Organigram');
            $orgObj->setItemInfo(array('id' => $nhpData['businessUnitID']));
            $org_data = $orgObj->displayItemById();
            $orgObj = null;
            foreach ($record_data as $value) {

                $sql2 = sprintf("UPDATE %s.actions SET status = 1
									WHERE ID = " . $value['ID'], _DB_OBJ_FULL);

                $pStatement2 = $this->dbHand->prepare($sql2);

                /* $pStatement2->bindParam(1,$action_ids);
                  $pStatement2->bindParam(2,$this->incidenceId); */

                $pStatement2->execute();

                $emailObj = new actionEmailHelper($value['ID']);
                $who = $emailObj->getwhoDetails();

                //$slawdata = $this->getActionsbyID($action_id);

                $sentence = array('sentence' => array("You have an action to carry out the following NCR Investigation Action"));
                $emailObj->appendInfo($sentence);

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/nhc_inv.php?id="'.$value['ID'].'>CLICK</a> Here to View NCR Investigation Action'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $inv_details['reference']
                        ),
                        'actionid1' => array(
                            'left' => '<strong>Problem Description</strong>',
                            'right' => $inv_details['incidentAnalysisDescription']
                        )
                    )
                );


                $emailObj->appendInfo($data);

                // http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145

                $emailObj->sendEmail('A NCR Investigation Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $who = $emailObj->getAUDetails();


                $sentence = array('sentence' => "You have an action to approve the following NCR Investigation Action");
                $emailObj->appendInfo($sentence);
                $who = $emailObj->getAUDetails();
                //$emailObj->sendEmail('A NHC Investigation Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
                $email_data[$i]['reference'] = $inv_details['reference'];
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];
                $email_data[$i]['bu'] = $org_data['buName'];

                $email_data[$i]['problemDescription'] = ucfirst($nhpData['problemDescription']);

                $this->actionHandling->updateStatus($value['ID']);
                $i++;
            }
        }

        return $email_data;
    }

    /*     * *
     * * This method is used to get
     * * listing records for Export
     * */

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'full') {
            return $this->getNhpExportDataFull();
        } else {

            return $this->getNhpExportData();
        }
    }

    public function getNhpExportDataFull() {

              $result[0]['ref'] = 'Reference #';  
              $result[0]['inc_ref'] = 'NCR Reference';  
              $result[0]['bu'] = 'Business Unit';  
              $result[0]['who'] = 'Who';  
              $result[0]['when'] = 'NCR Date';  
              $result[0]['log'] = 'Log Date';  
              $result[0]['i'] = 'NCR Analysis';  
              $result[0]['1'] = 'NCR Analysis Desc.';  
              $result[0]['im'] = 'Immideate Cause';  
              $result[0]['2'] = 'Immideate Cause Descp.';  
              $result[0]['bc'] = 'Basic Cause';  
              $result[0]['3'] = 'Basic Cause Descp.';  
              $result[0]['or'] = 'Inadequacy Org';  
              $result[0]['4'] = 'Inadequacy Org Desc.';  
              $result[0]['risk'] = 'Inadequacy Risk';  
              $result[0]['5'] = 'Inadequacy Risk Desc.';  
              $result[0]['trg'] = 'Inadequacy Trg';  
              $result[0]['6'] = 'Inadequacy Trg Desc.';  
              $result[0]['insp'] = 'Inadequacy Insp';  
              $result[0]['7'] = 'Inadequacy Insp Desc.';  
              $result[0]['nonc'] = 'Inadequacy Nonc ';  
              $result[0]['8'] = 'Inadequacy Nonc Desc.';  
              $result[0]['emer'] = 'Inadequacy Emer';  
              $result[0]['9'] = 'Inadequacy Emer Desc.';  
              $result[0]['hlth'] = 'Inadequacy hlth';  
              $result[0]['10'] = 'Inadequacy hlth Desc.';  
              $result[0]['desg'] = 'Inadequacy Desg';  
              $result[0]['11'] = 'Inadequacy Desg Desc.';  
              $result[0]['a'] = 'Action Desc.';  
              $result[0]['aw'] = 'Action Who';  
              $result[0]['awu'] = 'Action WhoAU';  
              $result[0]['adue'] = 'Action Due Date';  
              $result[0]['do'] = 'Action Done Date';  
              $result[0]['dod'] = 'Action Done Descp.';  
              $result[0]['pr'] = 'Process Number';  
              $result[0]['rv'] = 'Risk Rating still valid';

        $objNhc = new NhpMain();
        $participantObj = SetupGeneric::useModule('Participant');
        $objBusinessUnit = SetupGeneric::useModule('Organigram');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setInvestigationInfo(1, array('archive' => $archive_session));
        $investigationData = $this->viewInvestigations();
        //dump_array($investigationData);
        //exit;
        if (count($investigationData)) {
            $i = 1;
            foreach ($investigationData as $value) {

                $record_id = $value['ID'];
                $reference = $value['reference'];
                $incidence_id = $value['incID'];

                $incidentAnalysis = $value['incidentAnalysis'];
                $pieces = explode(",", $incidentAnalysis);
                $pieces = array_filter($pieces);
                //dump_array($pieces);
                if ($pieces) {
                    $objInvestigationClass = SetupGeneric::useModule('Investigation');
                    $j = 0;
                    foreach ($pieces as $val) {
                        $investigationClassData = $objInvestigationClass->displayCategories11($val);
                        if ($investigationClassData['name']) {
                            $name1[$j] = $investigationClassData['name'];
                        }

                        $j++;
                    }
                    if ($name1)
                        $name = implode(",", $name1);
                    else
                        $name = '-';
                } else {

                    $name = '-';
                }

                $incidentAnalysis1 = $value['immediateCauses'];
                $pieces1 = explode(",", $incidentAnalysis1);
                $pieces1 = array_filter($pieces1);
                //dump_array($pieces);
                if ($pieces1) {
                    $objInvestigationClass = SetupGeneric::useModule('Investigation');
                    $k = 0;
                    foreach ($pieces1 as $val) {
                        $investigationClassData = $objInvestigationClass->displayCategories11($val);
                        if ($investigationClassData['name']) {
                            $name2[$k] = $investigationClassData['name'];
                        }

                        $k++;
                    }
                    if (is_array($name2))
                        $name2 = implode(",", $name2);
                    else
                        $name2 = '-';
                } else {

                    $name2 = '-';
                }


                $incidentAnalysis2 = $value['basicCauses'];
                $pieces3 = explode(",", $incidentAnalysis2);
                $pieces3 = array_filter($pieces3);
                //dump_array($pieces);
                if ($pieces3) {
                    $objInvestigationClass = SetupGeneric::useModule('Investigation');
                    $a = 0;
                    foreach ($pieces3 as $val) {
                        $investigationClassData = $objInvestigationClass->displayCategories11($val);
                        if ($investigationClassData['name']) {
                            $name3[$a] = $investigationClassData['name'];
                        }

                        $a++;
                    }
                    if (is_array($name3))
                        $name3 = implode(",", $name3);
                    else
                        $name3 = '-';
                } else {

                    $name3 = '-';
                }

                $risk = $this->viewInadequacies44('risk', $record_id);


                $r = 0;

                foreach ($risk as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $risk_val[$r] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $risk_val[$r] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $risk_val[$r] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $risk_val[$r] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $risk_val[$r] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $risk_val[$r] = 'Not Applicable';
                        }
                        $r++;
                    }
                }

                //dump_array($org_val);
                if ($risk_val)
                    $risk_val1 = implode(",", $risk_val);

                $trg = $this->viewInadequacies44('trg', $record_id);


                $t = 0;

                foreach ($trg as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $trg_val[$t] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $trg_val[$t] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $trg_val[$t] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $trg_val[$t] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $trg_val[$t] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $trg_val[$t] = 'Not Applicable';
                        }
                        $t++;
                    }
                }

                //dump_array($org_val);
                if ($trg_val)
                    $trg_val1 = implode(",", $trg_val);

                $insp = $this->viewInadequacies44('insp', $record_id);


                $ins = 0;

                foreach ($insp as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $insp_val[$ins] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $insp_val[$ins] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $insp_val[$ins] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $insp_val[$ins] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $insp_val[$ins] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $insp_val[$ins] = 'Not Applicable';
                        }
                        $ins++;
                    }
                }

                //dump_array($org_val);
                if ($insp_val)
                    $insp_val1 = implode(",", $insp_val);



                $nonc = $this->viewInadequacies44('nonc', $record_id);


                $n = 0;

                foreach ($nonc as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $nonc_val[$n] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $nonc_val[$n] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $nonc_val[$n] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $nonc_val[$n] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $nonc_val[$n] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $nonc_val[$n] = 'Not Applicable';
                        }
                        $n++;
                    }
                }

                //dump_array($org_val);
                if ($nonc_val)
                    $nonc_val1 = implode(",", $nonc_val);

                $emer = $this->viewInadequacies44('emer', $record_id);


                $e = 0;

                foreach ($emer as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $emer_val[$e] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $emer_val[$e] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $emer_val[$e] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $emer_val[$e] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $emer_val[$e] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $emer_val[$e] = 'Not Applicable';
                        }
                        $e++;
                    }
                }

                //dump_array($org_val);
                if ($emer_val)
                    $emer_val1 = implode(",", $emer_val);


                $hlth = $this->viewInadequacies44('hlth', $record_id);


                $h = 0;

                foreach ($hlth as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $hlth_val[$h] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $hlth_val[$h] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $hlth_val[$h] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $hlth_val[$h] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $hlth_val[$h] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $hlth_val[$h] = 'Not Applicable';
                        }
                        $h++;
                    }
                }

                //dump_array($org_val);
                if ($hlth_val)
                    $hlth_val1 = implode(",", $hlth_val);

                $desg = $this->viewInadequacies44('desg', $record_id);


                $d = 0;

                foreach ($desg as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $desg_val[$d] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $desg_val[$d] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $desg_val[$d] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $desg_val[$d] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $desg_val[$d] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $desg_val[$d] = 'Not Applicable';
                        }
                        $d++;
                    }
                }

                //dump_array($org_val);
                if ($desg_val)
                    $desg_val1 = implode(",", $desg_val);

                $org = $this->viewInadequacies44('org', $record_id);


                $o = 0;

                foreach ($org as $val) {

                    if ($val['inadequacySelectedValues']) {



                        if ($val['inadequacySelectedValues'] == 'S') {
                            $org_val[$o] = 'Standard';
                        }
                        if ($val['inadequacySelectedValues'] == 'S,P') {
                            $org_val[$o] = 'Standard,Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P') {
                            $org_val[$o] = 'Programme';
                        }
                        if ($val['inadequacySelectedValues'] == 'P,C') {
                            $org_val[$o] = 'Programme,Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'c') {
                            $org_val[$o] = 'Compliance';
                        }
                        if ($val['inadequacySelectedValues'] == 'NA') {
                            $org_val[$o] = 'Not Applicable';
                        }
                        $o++;
                    }
                }

                //dump_array($org_val);
                if ($org_val)
                    $org_val1 = implode(",", $org_val);

                //get incidence data from db
                $objNhc->setNhpInfo($incidence_id, "");
                $incidenceRecord = $objNhc->viewNhpById();

                $incidence_ref = $incidenceRecord['reference'];
                $business_id = $incidenceRecord['businessUnitID'];
                $incidence_date_time = format_date($incidenceRecord['date']);

                //get business unit from db
                $objBusinessUnit = SetupGeneric::useModule('Organigram');
                $objBusinessUnit->setItemInfo(array(
                    'id' => $business_id
                ));
                $businessUnitData = $objBusinessUnit->displayItemById();

                $business_unit = $businessUnitData['buName'];

                $participant_id = $value['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];


                $result[$i]['ref'] = $reference;
                $result[$i]['inc_ref'] = $incidence_ref;
                $result[$i]['bu'] = $business_unit;
                $result[$i]['who'] = $participant_name;
                $result[$i]['when'] = $incidence_date_time;
                $result[$i]['log'] = format_datetime($value['dateTimestamp']);
                $result[$i]['i'] = $name;
                $result[$i]['1'] = $value['incidentAnalysisDescription'];
                $result[$i]['im'] = $name2;
                $result[$i]['2'] = $value['immediateCausesDescription'];
                $result[$i]['bc'] = $name3;
                $result[$i]['3'] = $value['basicCausesDescription'];
                $result[$i]['or'] = $org_val1;
                $result[$i]['4'] = $value['inadequacyOrgDescription'];
                $result[$i]['risk'] = $risk_val1;
                $result[$i]['5'] = $value['inadequacyRiskDescription'];
                $result[$i]['trg'] = $trg_val1;
                $result[$i]['6'] = $value['inadequacyTrgDescription'];
                $result[$i]['insp'] = $insp_val1;
                $result[$i]['7'] = $value['inadequacyInspDescription'];
                $result[$i]['nonc'] = $nonc_val1;
                $result[$i]['8'] = $value['inadequacyNoncDescription'];
                $result[$i]['emer'] = $emer_val1;
                $result[$i]['9'] = $value['inadequacyEmerDescription'];
                $result[$i]['hlth'] = $hlth_val1;
                $result[$i]['10'] = $value['inadequacyHlthDescription'];
                $result[$i]['desg'] = $desg_val1;
                $result[$i]['11'] = $value['inadequacyDesgDescription'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $value['actionsID'],
                ));

                $data_records7 = $type->displayItemById5();
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;

                $i++;
            }
        }

      //  $result = array_merge($heading, $result);
        return $result;
        //return $heading;
    }

    public function getNhpExportData() {


            $result[0]['ref'] = 'Reference #'; 
            $result[0]['inc_ref'] = 'NCR Reference'; 
            $result[0]['bu'] = 'Business Unit'; 
            $result[0]['who'] = 'Who'; 
            $result[0]['when'] = 'NCR Date'; 
            $result[0]['log'] = 'Log Date';

        $objNhc = new NhpMain();
        $participantObj = SetupGeneric::useModule('Participant');
        $objBusinessUnit = SetupGeneric::useModule('Organigram');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setInvestigationInfo(1, array('archive' => $archive_session));
        $investigationData = $this->viewInvestigations();

        if (count($investigationData)) {
            $i = 1;
            foreach ($investigationData as $value) {

                $record_id = $value['ID'];
                $reference = $value['reference'];
                $incidence_id = $value['incID'];

                //get incidence data from db
                $objNhc->setNhpInfo($incidence_id, "");
                $incidenceRecord = $objNhc->viewNhpById();

                $incidence_ref = $incidenceRecord['reference'];
                $business_id = $incidenceRecord['businessUnitID'];
                $incidence_date_time = format_date($incidenceRecord['date']);

                //get business unit from db
                $objBusinessUnit = SetupGeneric::useModule('Organigram');
                $objBusinessUnit->setItemInfo(array(
                    'id' => $business_id
                ));
                $businessUnitData = $objBusinessUnit->displayItemById();

                $business_unit = $businessUnitData['buName'];

                $participant_id = $value['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];


                $result[$i]['ref'] = $reference;
                $result[$i]['inc_ref'] = $incidence_ref;
                $result[$i]['bu'] = $business_unit;
                $result[$i]['who'] = $participant_name;
                $result[$i]['when'] = $incidence_date_time;
                $result[$i]['log'] = format_datetime($value['dateTimestamp']);


                $i++;
            }
        }

       //$result = array_merge($heading, $result);
        return $result;
        //return $heading;
    }

    /* function is used to send mail to manager of approved record */

    public function getActionTrackerEmailData($p_record_id) {

        $sql2 = sprintf("SELECT * FROM %s.nhc_investigation ", _DB_OBJ_FULL);
        $sql2 = $sql2 . " WHERE actionsID LIKE '" . $p_record_id . "' OR actionsID LIKE '%," . $p_record_id . "' OR actionsID LIKE '" . $p_record_id . ",%' OR actionsID LIKE '%," . $p_record_id . ",%' ";

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

        $incidence_id = $result[0]['incID'];

        $sql3 = sprintf("SELECT businessUnitID FROM %s.nhp ", _DB_OBJ_FULL);
        $sql3 = $sql3 . " WHERE ID = " . $incidence_id;

        $pStatement3 = $this->dbHand->prepare($sql3);
        $pStatement3->execute();
        $bu_id = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

        $business_id = $bu_id[0]['businessUnitID'];

        $email_data['bu_id'] = $business_id;
        $email_data['reference'] = $result[0]['reference'];
        $email_data['who_id'] = $result[0]['whoID'];

        return $email_data;
    }

    public function getCountIndequaciesEntered($p_record_id) {

        $sql = sprintf("select count(section),section from %s.nhc_investigation_inadequacies where invID=%d group by section", _DB_OBJ_FULL, $p_record_id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        //   checking for 8 tabs
        //return count($result) == 8 ? 1 : 0;
        //only need the count
        return count($result);
    }

    public function getOverDueActions($buStr, $date) {
        $this->sql_query = sprintf("select A.id,I.reference,INV.problemDescription,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,B.buName,(P.forename +' '+P.surname) as who_name  from %s.actions A  inner join %s.nhc_investigation I on A.record=I.ID inner join %s.nhp INV on I.incid=INV.ID  left join %s.business_units B on INV.businessunitid=B.buID  left join %s.participant_database P on A.currentWho=P.participantID where modulename = 'nhcinvestigation' and B.buID in(%s) and approveAU=0 and duedate < '%s'
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $date);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function sendActionEmails($p_actionid, $value_ref) {

        $emailObj = new actionEmailHelper($p_actionid);
        $who = $emailObj->getwhoDetails();
        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/nhc_inv.php?id='.$p_actionid.'">CLICK</a> Here to View Investigation Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $value_ref
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('An NCR Investigation Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
         
        $this->sql_query = sprintf("update %s.actions set status=1 where ID =%d", _DB_OBJ_FULL, $p_actionid);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
       
    }

    public function getActionIds() {

        $sql = sprintf("SELECT * FROM %s.actions WHERE moduleName='nhcInvestigation' and record = %d", _DB_OBJ_FULL, $this->investigationId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getOutstandingActions($buStr, $fdate) {
        $insp_out = SetupGeneric::useModule('InspectionOutstandingAction');
        $outstanding_duration = explode(':', $insp_out->displayItems());

        switch ($outstanding_duration[1]) {
            case 'M' : $interval = '+' . $outstanding_duration[0] . ' MONTH';
                break;
            case 'Y' : $interval = '+' . $outstanding_duration[0] . ' YEAR';
                break;
        }
        $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");

        $this->sql_query = sprintf("select A.id,I.reference,INV.problemDescription,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,B.buName,(P.forename +' '+P.surname) as who_name  from %s.actions A  inner join %s.nhc_investigation I on A.record=I.ID inner join %s.nhp INV on I.incid=INV.ID  left join %s.business_units B on INV.businessunitid=B.buID  left join %s.participant_database P on A.currentWho=P.participantID where modulename = 'nhcinvestigation' and B.buID in(%s) and approveAU=0 and duedate >=  '%s'
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $outstandingDate);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

}

?>