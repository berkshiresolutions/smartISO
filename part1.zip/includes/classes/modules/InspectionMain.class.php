<?php

/**
  $Id: InspectionMain.class.php,v 3.44 Saturday, February 05, 2011 10:31:02 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Thursday, October 28, 2010 4:24:29 PM>
 */
require_once "Inspection.int.php";
require_once "Action.class.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class InspectionMain implements Inspection {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold Inspection Id
     * @access private
     */
    private $InspectionId;

    /**
     * Property to hold Inspection Section Id
     * @access private
     */
    private $inspectionSectionId;

    /**
     * Property to hold Inspection Info
     * @access private
     */
    private $InspectionInfo;

    /**
     * Constructor for initializing Inspection object
     * @access public
     */
    public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set Inspection information for the respective object
     */

    public function setInspectionInfo($p_InspId, $p_InspInfo) {

        $this->InspectionId = $p_InspId;
        $this->InspectionInfo = $p_InspInfo;
    }

    /*
     * This method is used to add new Inspection
     * reference,unique_reference, location,business,participant,when_date
     */

    public function addInspection() {

        $sql = sprintf("SELECT * FROM %s.inspection WHERE reference LIKE '%s'", _DB_OBJ_FULL, $this->InspectionInfo['reference']);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionInfo['reference']);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $exists = count($result);

        if ($exists) {
            //throw new ErrorException('Reference number already exist.');
            return false;
        } else {

            $sql55 = sprintf("SELECT MAX(whenDate)  FROM %s.inspection WHERE locationID = %d ", _DB_OBJ_FULL, $this->InspectionInfo['location']);
            $pStatement = $this->dbHand->prepare($sql55);

//$pStatement->bindParam(1,$this->InspectionInfo['reference']);

            $pStatement->execute();
            $result = $pStatement->fetch(PDO::FETCH_ASSOC);

            $d = $result[''];

            $sql55 = sprintf("SELECT * FROM %s.inspection WHERE locationID =" . $this->InspectionInfo['location'] . " AND whenDate ='" . $d . "' AND archive = 0", _DB_OBJ_FULL);
            $pStatement = $this->dbHand->prepare($sql55);

//$pStatement->bindParam(1,$this->InspectionInfo['reference']);

            $pStatement->execute();
            $re = $pStatement->fetch(PDO::FETCH_ASSOC);

            if ($re['status'] == '1') {
               $sql1 = sprintf("INSERT INTO %s.inspection (reference,uniqueReference,locationID,buID,participantID,whenDate,archive,cDate)
										VALUES ('%s','%s',%d,'%s',%d,'%s','0','%s') ", _DB_OBJ_FULL, $this->InspectionInfo['reference'], $this->InspectionInfo['unique_reference'], $this->InspectionInfo['location'], $this->InspectionInfo['business'], $this->InspectionInfo['participant'], format_date_for_mysql($this->InspectionInfo['when_date']), $d);
            } else {
               $sql1 = sprintf("INSERT INTO %s.inspection (reference,uniqueReference,locationID,buID,participantID,whenDate,archive)
										VALUES ('%s','%s',%d,'%s',%d,'%s','0') ", _DB_OBJ_FULL, $this->InspectionInfo['reference'], $this->InspectionInfo['unique_reference'], $this->InspectionInfo['location'], $this->InspectionInfo['business'], $this->InspectionInfo['participant'], format_date_for_mysql($this->InspectionInfo['when_date']));
            }


            $pStatement1 = $this->dbHand->prepare($sql1);

            $pStatement1->execute();

            $this->InspectionId = customLastInsertId($this->dbHand, 'inspection', 'ID');
        }
    }

    /**
     * This method is used to get last inserted record Id
     */
    public function lastRecordId() {
        return $this->InspectionId;
    }

    /*
     * This method is used to edit an inspection record
     */

    public function editInspection() {


        $sql55 = sprintf("SELECT * FROM %s.inspection WHERE ID = %d AND archive = 0", _DB_OBJ_FULL, $this->InspectionId);
        $pStatement = $this->dbHand->prepare($sql55);

//$pStatement->bindParam(1,$this->InspectionInfo['reference']);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        if ($result['status'] == '1') {
            $sql = sprintf("UPDATE %s.inspection SET locationID = %d,
										participantID = %d,
										whenDate = '%s',
										cDate = '%s'
									WHERE ID = %d ", _DB_OBJ_FULL, $this->InspectionInfo['location'], $this->InspectionInfo['participant'], format_date_for_mysql($this->InspectionInfo['when_date']), $result['whenDate'], $this->InspectionId);
        } else {
            $sql = sprintf("UPDATE %s.inspection SET locationID = %d,
										participantID = %d,
										whenDate = '%s'
										
									WHERE ID = %d ", _DB_OBJ_FULL, $this->InspectionInfo['location'], $this->InspectionInfo['participant'], format_date_for_mysql($this->InspectionInfo['when_date']), $this->InspectionId);
        }


        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionInfo['location']);
          $pStatement->bindParam(2,$this->InspectionInfo['participant']);
          $pStatement->bindParam(3,format_date_for_mysql($this->InspectionInfo['when_date']));
          $pStatement->bindParam(4,$this->InspectionId); */

//dump_array($this);

        $pStatement->execute();
    }

    /*
     * This method is used to manage sectoins
     * section,step,sub_step
     */

    public function manageSections() {

        switch ($this->InspectionInfo['section']) {

            case 2: $module_identifier = "PF";
                $element = "swimlane";
                break;
            case 3: $module_identifier = "Risk";
                $element = "risk";
                break;
            case 4: $module_identifier = "inspectionM";
                $element = "inspection";
                break;
            case 5: $module_identifier = "inspectionH";
                $element = "inspection";
                $this->InspectionInfo['main_process_id'] = $this->InspectionId;
                break;
            case 6: $module_identifier = "inspectionH";
                $element = "inspection";
                $this->InspectionInfo['main_process_id'] = $this->InspectionId;
                break;
            case 7: $module_identifier = "inspectOS";
                $element = "inspection";
                $this->InspectionInfo['main_process_id'] = $this->InspectionId;
                break;
            case 8: $module_identifier = "inspectOD";
                $element = "inspection";
                $this->InspectionInfo['main_process_id'] = $this->InspectionId;
                break;
        }

        $this->actionData = array('module_name' => $module_identifier, 'description' => $this->InspectionInfo['action'],
            'who' => $this->InspectionInfo['who'], 'whoAU' => $this->InspectionInfo['whoAU'], 'due_date' => $this->InspectionInfo['when'], 'who2AU' => $this->InspectionInfo['who2AU'], 'record' => $this->InspectionInfo['main_process_id'], 'element' => $element);

        $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d AND step = %d AND subStep = %d ", _DB_OBJ_FULL, $this->InspectionId, $this->InspectionInfo['section'], $this->InspectionInfo['step'], $this->InspectionInfo['sub_step']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        $exists = count($result);

        $this->inspectionSectionId = $result[0]['ID'];

        if ($exists) {
// do update

            $this->editSection($result[0]['actionID'], $result[0]['ID']);
        } else {
// do insert

            $this->addSection();
        }


//dump_array($who);
//exit;
//echo $res['reference'];


        /*
          if ( $this->InspectionInfo['section'] == 6 ) {

          $upd = sprintf("UPDATE %s.inspection SET status = 1 WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionId);
          $pStatement = $this->dbHand->prepare($upd);
          $pStatement->execute();

          }
         */
    }

    private function addSection() {
        $action_id = 0;

        if ($this->InspectionInfo['expectation'] == 'W' || $this->InspectionInfo['expectation'] == 'B' || $this->InspectionInfo['expectation'] == '') {
            $this->actionHandling->setActionDetails(0, $this->actionData);


            $new_action_id = $this->actionHandling->addAction2015();
            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);
        }
        $sql = sprintf("INSERT INTO %s.inspection_metadata (inspectionID,tab,step,subStep,expectation,problem,actionID,isRiskValid,hazardClassificationID,
													hazardsID,processID,actionDescOld,outstanding,mainProcessID,processStepID,managementHazardID,nareason)
											VALUES (%d,%d,%d,%d,'%s','%s',%d,'%s',%d,'%s',%d,'%s','0',%d,%d,%d,'%s')", _DB_OBJ_FULL, $this->InspectionId, $this->InspectionInfo['section'], $this->InspectionInfo['step'], $this->InspectionInfo['sub_step'], $this->InspectionInfo['expectation'], $this->InspectionInfo['problem'], $action_id, $this->InspectionInfo['risk_valid'], $this->InspectionInfo['hazard_classification'], $this->InspectionInfo['hazards'], $this->InspectionInfo['process_id'], $this->InspectionInfo['action_old'], $this->InspectionInfo['main_process_id'], $this->InspectionInfo['step_id'], $this->InspectionInfo['management_hazard'], $this->InspectionInfo['nareason']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $newId = customLastInsertId($this->dbHand, 'inspection_metadata', 'ID');
//dump_array_and_exit($pStatement->errorInfo());

        $this->actionHandling->insertRequestRecord($action_id, $newId, 'inspection_metadata');
    }

    public function getNameWho($id_au, $nam) {

        $this->name = $id_au;
        $this->nam = $nam;
        $sql = sprintf("SELECT * FROM %s.participant_database WHERE forename = '" . $this->name . "' AND surname = '" . $this->nam . "'", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
//$name = ucwords($result['forename'] . ' ' . $result['surname']);
        return $result;
    }

    private function editSection($p_action_id, $p_table_id) {
        $action_id = 0;

        if ($this->InspectionInfo['expectation'] == 'W' || $this->InspectionInfo['expectation'] == 'B' || $this->InspectionInfo['expectation'] == '') {
            $this->actionHandling->setActionDetails($p_action_id, $this->actionData);
            if ($p_action_id != 0) {
                $this->actionHandling->updateAction2015();
                $this->actionHandling->updateStatus($p_action_id);
                $action_id = $p_action_id;
            } else {
                $new_action_id = $this->actionHandling->addAction2015();
                $action_id = $new_action_id;
                $this->actionHandling->updateStatus($action_id);
            }
        }
        $sql = sprintf("UPDATE %s.inspection_metadata SET expectation = '%s',
												problem = '%s',
												isRiskValid = '%s',
												hazardClassificationID = '%s',
												hazardsID = '%s',
												processID = %d,
												actionID = %d,
												actionDescOld = '%s',
												mainProcessID = %d,
												processStepID = %d,
												managementHazardID = %d,
												nareason = '%s'
											WHERE ID = %d", _DB_OBJ_FULL, $this->InspectionInfo['expectation'], $this->InspectionInfo['problem'], $this->InspectionInfo['risk_valid'], $this->InspectionInfo['hazard_classification'], $this->InspectionInfo['hazards'], $this->InspectionInfo['process_id'], $action_id, $this->InspectionInfo['action_old'], $this->InspectionInfo['main_process_id'], $this->InspectionInfo['step_id'], $this->InspectionInfo['management_hazard'], $this->InspectionInfo['nareason'], $p_table_id);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionInfo['expectation']);
          $pStatement->bindParam(2,$this->InspectionInfo['problem']);
          $pStatement->bindParam(3,$this->InspectionInfo['risk_valid']);
          $pStatement->bindParam(4,$this->InspectionInfo['hazard_classification']);
          $pStatement->bindParam(5,$this->InspectionInfo['hazards']);
          $pStatement->bindParam(6,$this->InspectionInfo['process_id']);
          $pStatement->bindParam(7,$this->InspectionInfo['action_old']);
          $pStatement->bindParam(8,$this->InspectionInfo['main_process_id']);
          $pStatement->bindParam(9,$this->InspectionInfo['step_id']);
          $pStatement->bindParam(10,$this->InspectionInfo['management_hazard']);
          $pStatement->bindParam(11,$p_table_id); */

        $pStatement->execute();
    }

    /**
     * This method is used to get last inserted record Id
     */
    public function lastSectionRecordId() {
        return $this->inspectionSectionId;
    }

    /**/

    public function getSectionDetails() {

        $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d AND step = %d AND subStep = %d", _DB_OBJ_FULL, $this->InspectionId, $this->InspectionInfo['section'], $this->InspectionInfo['step'], $this->InspectionInfo['sub_step']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionId);
          $pStatement->bindParam(2,$this->InspectionInfo['section']);
          $pStatement->bindParam(3,$this->InspectionInfo['step']);
          $pStatement->bindParam(4,$this->InspectionInfo['sub_step']); */

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $section_data = $result[0];

        if ($section_data['actionID'] != '') {
            $this->actionHandling->setActionDetails($section_data['actionID'], "");
            $action_data = $this->actionHandling->viewAction();
            $section_data['action'] = $action_data['actionDescription'];
            $section_data['who'] = $action_data['who'];
            $section_data['whoAU'] = $action_data['whoAU'];
            $section_data['who2AU'] = $action_data['addapprover'];
            $section_data['when'] = $action_data['dueDate'];
        }


        return $section_data;
    }

    /*
     * This method is used to delete an inspection record
     */

    public function deleteInspection() {
        
    }

    /*
     * This method is used to archive an inspection record
     */

    public function archiveInspection() {

        $sql = sprintf("UPDATE %s.inspection SET archive = '%s' WHERE ID = %d", _DB_OBJ_FULL, $this->InspectionInfo['archive'], $this->InspectionId);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionInfo['archive']);
          $pStatement->bindParam(2,$this->InspectionId); */

        $pStatement->execute();
    }

    public function finishInspection($p_Id, $fDate) {
        $this->datet = $fDate;
        $upd = sprintf("UPDATE %s.inspection SET status = 1, fDate ='" . $this->datet . "' WHERE ID = %d", _DB_OBJ_FULL, $p_Id);
        $pStatement = $this->dbHand->prepare($upd);
        $pStatement->execute();
    }

    /*
     * This method is used to completely delete an inspection record
     */

    public function purgeInspection() {

        $sql2 = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d ", _DB_OBJ_FULL, $this->InspectionId);
        $pStatement2 = $this->dbHand->prepare($sql2);

//$pStatement2->bindParam(1,$this->InspectionId);
        $pStatement2->execute();

        $metadata = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

        if (count($metadata)) {
            foreach ($metadata as $value) {
                if ($value['actionID'] != '') {
                    $this->actionHandling->setActionDetails($value['actionID'], "");
                    $this->actionHandling->deleteAction();
                }
            }
        }

        $sql2 = sprintf("DELETE FROM %s.inspection_metadata WHERE inspectionID = %d", _DB_OBJ_FULL, $this->InspectionId);
        $pStatement2 = $this->dbHand->prepare($sql2);

//$pStatement2->bindParam(1,$this->InspectionId);
        $pStatement2->execute();

        $sql3 = sprintf("DELETE FROM %s.inspection WHERE ID = %d", _DB_OBJ_FULL, $this->InspectionId);
        $pStatement3 = $this->dbHand->prepare($sql3);

//$pStatement3->bindParam(1,$this->InspectionId);
        $pStatement3->execute();
    }

    /*
     * This method is used to display an inspection record
     */

    public function viewInspectionById() {

        $sql = sprintf("SELECT * FROM %s.inspection WHERE ID = %d", _DB_OBJ_FULL, $this->InspectionId);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($result)) {
            return $result[0];
        } else {
            return 0;
        }
    }

    public function viewDateBu($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.inspection_frequency WHERE buID = %d AND module = 'C'", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewBuWho($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.participant_authorization_stats WHERE businessUnit = %d AND sectionName='ins'", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewDateBuR($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.inspection_frequency WHERE buID = %d AND module = 'R'", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewDateBuH($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.inspection_frequency WHERE buID = %d AND module = 'H'", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getLocData($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.locationgram WHERE locID = %d ", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getDueactionDate11($locID) {


        $this->locID = $locID;



        $sql = sprintf("SELECT TOP 1 * FROM %s.actions WHERE (field = '' || field is NUll) AND approveAU = 0  AND locID = " . $this->locID, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $result;
        } else {
            return 0;
        }
    }

    public function getDueactionDate($id, $locID) {

        $this->id = $id;
        $this->locID = $locID;



        $sql = sprintf("SELECT TOP 1 * FROM %s.actions WHERE field = '" . $this->id . "' AND approveAU = 0  AND locID = " . $this->locID, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return $result;
        } else {
            return 0;
        }
    }

    public function checkActionFire($id, $locID, $d) {
        $this->id = $id;
        $this->locID = $locID;
        $this->d = $d;
        $sql = sprintf("SELECT * FROM %s.actions WHERE field = '" . $this->id . "'  AND doneDate is NULL AND dueDate <= '" . $this->d . "' AND locID = " . $this->locID, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $result;
        } else {
            return 0;
        }
    }

    public function viewDateBuP($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.inspection_frequency WHERE buID = %d AND module = 'H'", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    public function viewDateBu33($id) {
        $this->id = $id;
        $sql = sprintf("SELECT * FROM %s.inspection WHERE locationID = %d AND fDate != ''", _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionId);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }

    /*
     * This method is used to display an inspection record
     */

    public function viewInspections() {

//$sql = sprintf("SELECT * FROM %s.inspection WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->InspectionInfo['archive']);

       $sql = sprintf("SELECT * FROM %s.inspection 
			
			
			WHERE archive = '%s' ORDER BY ID DESC", _DB_OBJ_FULL, $this->InspectionInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionInfo['archive']);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewInspectionsLOc($loc) {

        $this->loc = $loc;

//$sql = sprintf("SELECT * FROM %s.inspection WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->InspectionInfo['archive']);

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.inspection A
			LEFT OUTER JOIN (
				SELECT *
				FROM %s.recordTracking
				WHERE moduleName = 'INSP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' AND  A.locationID = " . $this->loc . " ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->InspectionInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->InspectionInfo['archive']);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewInspectionsByLogDate() {

//$sql = sprintf("SELECT * FROM %s.inspection WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->InspectionInfo['archive']);

        $date_filter = '';

        if ($this->InspectionInfo['start_date'] != '--' && $this->InspectionInfo['end_date'] != '--' && $this->InspectionInfo['start_date'] != '' && $this->InspectionInfo['end_date'] != '') {
            $date_filter = " AND (dateTimestamp BETWEEN '" . $this->InspectionInfo['start_date'] . " 00:00:00.000' AND '" . $this->InspectionInfo['end_date'] . " 23:59:59.000') ";
            $join_type = 'INNER';
            $date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
        } else {
            $date_filter = '';
            $join_type = 'LEFT OUTER';
            $date_timestamp_not_null = '';
        }

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.inspection A
				" . $join_type . " JOIN (
				SELECT *
				FROM %s.recordTracking
				WHERE moduleName = 'INSP'
				AND action = 'add'
				" . $date_timestamp_not_null . "
			) B
			ON recordRef = reference
			WHERE A.archive = '%s'
			$date_filter
			ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->InspectionInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getCCPs($p_bu_id, $d, $g) {
        $this->d = $d;
        $this->g = $g;
        if ($this->d) {
            $date_t = $this->viewDateBu($p_bu_id);
            $fDate = date("Y-m-d");
//dump_array($date_t);
            if ($date_t['frequency'] == 'W') {
                $dd = '7';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " days"));
            }
            if ($date_t['frequency'] == 'M') {

                $dd = '1';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " months"));
            }
            if ($date_t['frequency'] == 'Q') {
                $dd = '3';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " months"));
            }
            if ($date_t['frequency'] == 'B') {

                $dd = '6';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " months"));
            }
            if ($date_t['frequency'] == 'A') {

                $dd = '1';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " years"));
            }

            if ($f_date > $this->g) {

                return 0;
            } else {
                $sql = sprintf("SELECT M.*,N.criticalControlPoint,N.ID AS step_id,N.stepLevel AS step_level,N.descQues AS step_desc,N.cmsReference AS cms_ref
						FROM %s.swimlane M
						INNER JOIN %s.swimlane_data N  ON N.swimID = M.swimID
						WHERE N.criticalControlPoint!='' AND N.buID = %d and (M.archive=0 or M.archive is null) ORDER BY N.swimID,N.altPathIndex,N.stepLevel,N.type,N.ID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);

                $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_bu_id);

                $pStatement->execute();
                $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


                return $result;
            }
        }



        $sql = sprintf("SELECT M.*,N.criticalControlPoint,N.ID AS step_id,N.stepLevel AS step_level,N.descQues AS step_desc,N.cmsReference AS cms_ref
						FROM %s.swimlane M
						INNER JOIN %s.swimlane_data N  ON N.swimID = M.swimID
						WHERE N.criticalControlPoint!='' AND N.buID = %d and (M.archive=0 or M.archive is null) ORDER BY N.swimID,N.altPathIndex,N.stepLevel,N.type,N.ID ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);

        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_bu_id);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }

    public function getAssessmentDetails($p_process_id, $p_step_id) {

        if ( _DB_TYPE != 'mysql' ) {
            $sql = sprintf("SELECT TOP 1 * FROM %s.risk WHERE processID = %d AND processStepID = %d", _DB_OBJ_FULL, $p_process_id, $p_step_id);
        } else {
            $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d LIMIT 0,1", _DB_OBJ_FULL, $p_process_id, $p_step_id);
        }


        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$p_process_id);
          $pStatement->bindParam(2,$p_step_id); */

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result[0];
    }

    public function getMaxRiskByProcess($p_process_id) {

        if ( _DB_TYPE != 'mysql' ) {
            $sql = sprintf("SELECT TOP 1 *,CHARINDEX(RTRIM(riskRatingColor1),'TLMHI') as riskpos FROM %s.risk WHERE processID = %d order by riskpos asc", _DB_OBJ_FULL, $p_process_id);
        } else {
            $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d  LIMIT 0,1", _DB_OBJ_FULL, $p_process_id);
        }


        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$p_process_id);
          $pStatement->bindParam(2,$p_step_id); */

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result[0];
    }

    public function getRiskManagement($p_bu_id, $d, $g) {
        $this->d = $d;
        $this->g = $g;


        global $RISK_RATING_CODES;

        if ($this->d) {
            $date_t = $this->viewDateBuR($p_bu_id);
            $fDate = date("Y-m-d");
            if ($date_t['frequency'] == 'W') {

                $dd = '7';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " days"));
            }
            if ($date_t['frequency'] == 'M') {

                $dd = '1';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " months"));
            }
            if ($date_t['frequency'] == 'Q') {

                $dd = '3';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " months"));
            }
            if ($date_t['frequency'] == 'B') {

                $dd = '6';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " months"));
            }
            if ($date_t['frequency'] == 'A') {

                $dd = '1';
                $f_date = date('Y-m-d', strtotime($this->d . "+ " . $dd . " years"));
            }
            if ($this->g < $f_date) {
                return 0;
            } else {
                $sql = sprintf("SELECT opValue FROM %s.options WHERE opName='_INSPECTION_RISK_RATING' ", _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();
                $risk_rating = $pStatement->fetch(PDO::FETCH_ASSOC);

                $risk_rating = trim($risk_rating['opValue'], "");

                $risk_ratings_all = '(';
                foreach ($RISK_RATING_CODES as $value) {
                    $risk_ratings_all .= " R.riskRating1 LIKE '" . $value . "' ";
                    if ($risk_rating == $value) {
                        break;
                    }

                    $risk_ratings_all .= " OR ";
                }

                $risk_ratings_all .= ')';

                $risk_ratings_all = trim($risk_ratings_all, ',');

                /* 		$sql2 = sprintf("SELECT R.*,M.description,M.reference FROM %s.risk R
                  INNER JOIN %s.swimlane M
                  ON M.swimID = R.processID
                  WHERE M.buID = %d AND ",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$p_bu_id);
                 */
                $sql2 = sprintf("SELECT R.*,M.description,M.reference,B.descQues FROM %s.swimlane M
								INNER JOIN %s.swimlane_data B
								ON B.swimID = M.swimID
								INNER JOIN %s.risk R
								ON R.processStepID = B.ID
								WHERE B.buID = %d AND R.processID = B.swimID AND (M.archive=0 or m.archive is null) AND ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);

                $sql2 = $sql2 . $risk_ratings_all . "  ORDER BY B.swimID,B.altPathIndex,B.stepLevel,R.ID ASC";

                $pStatement2 = $this->dbHand->prepare($sql2);
                /* $pStatement2->bindParam(1,$risk_rating['opValue']);
                  $pStatement2->bindParam(2,$p_bu_id); */
                $pStatement2->execute();

                $processes = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

                return $processes;
            }
        }

        $sql = sprintf("SELECT opValue FROM %s.options WHERE opName='_INSPECTION_RISK_RATING' ", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $risk_rating = $pStatement->fetch(PDO::FETCH_ASSOC);

        $risk_rating = trim($risk_rating['opValue'], "");

        $risk_ratings_all = '(';
        foreach ($RISK_RATING_CODES as $value) {
            $risk_ratings_all .= " R.riskRating1 LIKE '" . $value . "' ";
            if ($risk_rating == $value) {
                break;
            }

            $risk_ratings_all .= " OR ";
        }

        $risk_ratings_all .= ')';

        $risk_ratings_all = trim($risk_ratings_all, ',');

        /* 		$sql2 = sprintf("SELECT R.*,M.description,M.reference FROM %s.risk R
          INNER JOIN %s.swimlane M
          ON M.swimID = R.processID
          WHERE M.buID = %d AND ",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$p_bu_id);
         */
        $sql2 = sprintf("SELECT R.*,M.description,M.reference,B.descQues FROM %s.swimlane M
								INNER JOIN %s.swimlane_data B
								ON B.swimID = M.swimID
								INNER JOIN %s.risk R
								ON R.processStepID = B.ID
								WHERE B.buID = %d AND R.processID = B.swimID AND (M.archive=0 or m.archive is null) AND ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_bu_id);

        $sql2 = $sql2 . $risk_ratings_all . "  ORDER BY B.swimID,B.altPathIndex,B.stepLevel,R.ID ASC";

        $pStatement2 = $this->dbHand->prepare($sql2);
        /* $pStatement2->bindParam(1,$risk_rating['opValue']);
          $pStatement2->bindParam(2,$p_bu_id); */
        $pStatement2->execute();

        $processes = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

//dump_array($processes);
        return $processes;
    }

    public function getInspectionByBu($p_bu_id) {

       if ( _DB_TYPE != 'mysql' ) {
            $sql = sprintf("SELECT TOP 1 * FROM inspection WHERE buID = %d ORDER BY ID DESC ", _DB_OBJ_FULL, $p_bu_id);
        } else {
            $sql = sprintf("SELECT * FROM inspection WHERE buID = %d ORDER BY ID DESC LIMIT 0,1 ", _DB_OBJ_FULL, $p_bu_id);
        }


        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_bu_id);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result[0];
    }

    public function ispectionFrequencies($p_bu_frequencies, $date) {

        $miscObj = new Misc();

        if (count($p_bu_frequencies)) {
            foreach ($p_bu_frequencies as $value) {

                switch ($value['frequency']) {
                    case 'W' : $duration = 7;
                        $interval = 'DAY';
                        break;
                    case 'M' : $duration = 1;
                        $interval = 'MONTH';
                        break;
                    case 'Q' : $duration = 3;
                        $interval = 'MONTH';
                        break;
                    case 'B' : $duration = 4;
                        $interval = 'MONTH';
                        break;
                    case 'A' : $duration = 1;
                        $interval = 'YEAR';
                        break;
                }

                $check_date = $miscObj->makeCustomDate($date, $duration, $interval);
                $current_date = $miscObj->getCurDate();
//echo "<br/>";
                if ($current_date < $check_date) {
                    $flags[$value['module']] = 1;
                } else {
                    $flags[$value['module']] = 0;
                }
            }
        }

        return $flags;
    }

    public function getAddtionalHazardCount() {

        $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d ", _DB_OBJ_FULL, $this->InspectionId, $this->InspectionInfo['section']);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionId);
          $pStatement->bindParam(2,$this->InspectionInfo['section']); */

        $pStatement->execute();
        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return count($records);
    }

    public function getMaxSubStep() {
        $sql = sprintf("SELECT MAX(subStep) FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d AND step = %d ", _DB_OBJ_FULL, $this->InspectionId, $this->InspectionInfo['section'], $this->InspectionInfo['step']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionId);
          $pStatement->bindParam(2,$this->InspectionInfo['section']);
          $pStatement->bindParam(3,$this->InspectionInfo['step']); */

        $pStatement->execute();

        return $pStatement->fetchColumn();
    }

    public function updateOutstanding() {

        $sql = sprintf("UPDATE %s.inspection_metadata SET outstanding = '%s'
											WHERE ID = %d", _DB_OBJ_FULL, $this->InspectionInfo['outstanding_flag'], $this->InspectionInfo['action_id']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->InspectionInfo['outstanding_flag']);
          $pStatement->bindParam(2,$this->InspectionInfo['action_id']); */

        $pStatement->execute();
    }

    public function getInspectionCountByBu($p_bu_id) {

        $sql = sprintf("SELECT * FROM %s.inspection WHERE buID = %d ", _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_bu_id);

        $pStatement->execute();
        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return count($records);
    }

    public function getFreBu($p_bu_id) {

        $sql = sprintf("SELECT * FROM %s.inspection_frequency WHERE module='C' AND buID = %d ", _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_bu_id);

        $pStatement->execute();
        $records = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $records;
    }

    public function getFreBu1($p_bu_id) {

        $sql = sprintf("SELECT * FROM %s.inspection_frequency WHERE module='R' AND buID = %d ", _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_bu_id);

        $pStatement->execute();
        $records = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $records;
    }

    public function getFrequecy($p_bu_ids,$dates) {

    $sql = sprintf("SELECT distinct frequency FROM %s.inspection_frequency WHERE buID in (%s) order by frequency desc", _DB_OBJ_FULL, $p_bu_ids);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
$chk=1;

$frequencyArr = array("A" => 1,"B" => 2,"Q" => 3,"M" => 4,"W" => 5);

foreach($records as $row){
    if($frequencyArr[$row["frequency"]]>$chk)
        $chk=$frequencyArr[$row["frequency"]];
}

switch($chk){
	case 1: $f_date = date('m/d/Y', strtotime($dates . "+  1  years"));break;
	case 2: $f_date = date('m/d/Y', strtotime($dates . "+  6  months"));break;
	case 3: $f_date = date('m/d/Y', strtotime($dates . "+  3  months"));break;
	case 4: $f_date = date('m/d/Y', strtotime($dates . "+  1  months"));break;
	case 5: $f_date = date('m/d/Y', strtotime($dates . "+  7  days"));break;
	default: $f_date = date('m/d/Y', strtotime($dates . "+  1  years"));break;
}

        return $f_date;
    }

//SELECT frequency FROM inspection_frequency  where buid in (191,192,193,204,206) group by frequency
    public function getAllInspectionActions() {

        $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE outstanding='0' ", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($records)) {
            $i = 0;
            foreach ($records as $value_record) {
                $section_data[$i] = $value_record;

                if ($section_data[$i]['actionID'] != '') {
                    $this->actionHandling->setActionDetails($section_data[$i]['actionID'], "");
                    $action_data = $this->actionHandling->viewAction();
                    $section_data[$i]['action'] = $action_data['actionDescription'];
                    $section_data[$i]['who'] = $action_data['who'];
                    $section_data[$i]['when'] = $action_data['dueDate'];
                    $section_data[$i]['done_date'] = $action_data['doneDate'];
                    $section_data[$i]['approve'] = $action_data['approve'];
                }

                $i++;
            }
        }

        return $section_data;
    }

    public function checkInspectionDone($p_bu_frequencies) {

        if (count($p_bu_frequencies)) {
            foreach ($p_bu_frequencies as $value) {

                $sql = sprintf("SELECT * FROM %s.inspections_done WHERE buID = %d AND module LIKE '%s' ", _DB_OBJ_FULL, $value['buID'], $value['module']);
                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$value['buID']);
                  $pStatement->bindParam(2,$value['module']); */

                $pStatement->execute();
                $results = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (!count($results)) {
// do insert
                    $sql2 = sprintf("INSERT INTO %s.inspections_done (buID,module,whenDate,isDone)
														VALUES (%d,'%s'," . customCurrentDate() . ",'0')", _DB_OBJ_FULL, $value['buID'], $value['module']);
                    $pStatement2 = $this->dbHand->prepare($sql2);

                    /* $pStatement2->bindParam(1,$value['buID']);
                      $pStatement2->bindParam(2,$value['module']) */;

                    $pStatement2->execute();
                } else {

                    $miscObj = new Misc();

                    switch ($value['frequency']) {
                        case 'W' : $duration = 7;
                            $interval = 'DAY';
                            break;
                        case 'M' : $duration = 1;
                            $interval = 'MONTH';
                            break;
                        case 'Q' : $duration = 3;
                            $interval = 'MONTH';
                            break;
                        case 'B' : $duration = 4;
                            $interval = 'MONTH';
                            break;
                        case 'A' : $duration = 1;
                            $interval = 'YEAR';
                            break;
                    }

                    $check_date = $miscObj->makeCustomDate($results[0]['whenDate'], $duration, $interval);
                    $current_date = $miscObj->getCurDate();
//echo "<br/>";
                    if ($current_date > $check_date) {
                        $this->updInspectionDone($value['buID'], $value['module'], $results[0]['whenDate']);
                    }
                }
            }
        }
        return $flags;
    }

    public function updInspectionDone($p_bu_id, $p_module, $p_date, $done_flag = 0) {

        $sql2 = sprintf("UPDATE %s.inspections_done SET isDone = '%s',whenDate = '%s'  WHERE buID = %d AND module LIKE '%s' ", _DB_OBJ_FULL, $done_flag, $p_date, $p_bu_id, $p_module);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$done_flag);
          $pStatement2->bindParam(2,$p_date);
          $pStatement2->bindParam(3,$p_bu_id);
          $pStatement2->bindParam(4,$p_module); */

        $pStatement2->execute();
    }

    public function getInspectionsDone($p_bu_id, $p_module = '') {

        $sql = sprintf("SELECT * FROM %s.inspections_done WHERE buID = %d AND module LIKE '%s' ", _DB_OBJ_FULL, $p_bu_id, $p_module);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$p_bu_id);
          $pStatement->bindParam(2,$p_module); */

        $pStatement->execute();
        $results = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $results;
    }

    public function getOutstandingActionsDepreciated($p_overdue) {

        if ($p_overdue) {
            $data = $this->actionHandling->viewOverdueActions('inspection%');
        } else {
            $data = $this->actionHandling->viewAllActionByModule('inspection%', true);
        }


        if (count($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT I.ID AS insp_id,I.reference,I.buID,M.tab,M.step,M.subStep,M.expectation,M.problem,M.mainProcessID,M.processStepID
							   FROM %s.inspection I
								INNER JOIN %s.inspection_metadata M
								ON M.inspectionID=I.ID
								WHERE M.actionID LIKE '%s' OR M.actionID LIKE '%s' OR M.actionID LIKE '%s' OR M.actionID LIKE '%s' ", _DB_OBJ_FULL, _DB_OBJ_FULL, $search_value1, $search_value2, $search_value3, $search_value4);


                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$search_value1);
                  $pStatement->bindParam(2,$search_value2);
                  $pStatement->bindParam(3,$search_value3);
                  $pStatement->bindParam(4,$search_value4); */

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (count($action_data)) {
                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['buID'];
                        $new_data[$i]['tab'] = $value2['tab'];
                        $new_data[$i]['step'] = $value2['step'];
                        $new_data[$i]['subStep'] = $value2['subStep'];
                        $new_data[$i]['expectation'] = $value2['expectation'];
                        $new_data[$i]['problem'] = $value2['problem'];
                        $new_data[$i]['main_process_id'] = $value2['mainProcessID'];
                        $new_data[$i]['step_id'] = $value2['processStepID'];
                        $new_data[$i]['insp_id'] = $value2['insp_id'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['whoAU'] = $value['whoAU'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                    }
                    $i++;
                }
            }
        }

        return $new_data;
    }

    public function getTotalOutstandingActions($p_flag) {

        $sql = sprintf("SELECT * FROM %s.actions WHERE outstanding = '%s'", _DB_OBJ_FULL, $p_flag);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return count($result);
    }

    public function getActionsData($p_id) {

        $sql = sprintf("SELECT * FROM %s.inspection_metadata M inner join %s.inspection I on M.inspectionID=I.id WHERE inspectionID = %d and actionID>0 ", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        foreach ($result as $value) {

            $url = 'inspection';
            $url1 = '';
            if ($value['tab'] == 2) {
                $sqld = sprintf("SELECT * FROM %s.actions A inner join %s.swimlane S on A.record=S.swimid WHERE ID = %d  ", _DB_OBJ_FULL, _DB_OBJ_FULL, $value["actionID"]);
                $pStatementd = $this->dbHand->prepare($sqld);
                $pStatementd->execute();
                $resultd = $pStatementd->fetch(PDO::FETCH_ASSOC);
                $url = 'pfs';
                $url1 = '<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/process_flow/showlane.php?swid=' . $resultd["swimID"] . '">CLICK</a> Here to View the Process Flow';
            }

            if ($value['tab'] == 3) {

                $sqld = sprintf("SELECT * FROM %s.actions A inner join %s.risk R on a.record=R.ID WHERE A.ID = %d  ", _DB_OBJ_FULL, _DB_OBJ_FULL, $value["actionID"]);
                $pStatementd = $this->dbHand->prepare($sqld);
                $pStatementd->execute();
                $resultd = $pStatementd->fetch(PDO::FETCH_ASSOC);
                $url = 'risk_assessment';
                $url1 = '<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/process_risk_assessment/list_process_steps.php?risk_id=' . $resultd["processID"] . '">CLICK</a> Here to View the Risk Assessment';
            }


            $emailObj = new actionEmailHelper($value["actionID"]);



            $who = $emailObj->getwhoDetails();
            if ($value['tab'] == 2) {
                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $url . '.php">CLICK</a> Here to View Critical Audit Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/inspection/pdfReport.php?id=' . $p_id . '">CLICK</a> Here to View Critical Audit Report' . $url1
                    ),
                    'twoColData' => array(
                        'newref' => array(
                            'left' => '<strong>Process Flow Reference</strong>',
                            'right' => $resultd["reference"]
                        ),
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $value["reference"]
                        ),
                    )
                );
            } else if ($value['tab'] == 3) {
                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $url . '.php">CLICK</a> Here to View Risk Assessment Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/inspection/pdfReport.php?id=' . $p_id . '">CLICK</a> Here to View Critical Audit Report' . $url1
                    ),
                    'twoColData' => array(
                        'newref' => array(
                            'left' => '<strong>Risk Assessment Reference</strong>',
                            'right' => $resultd["processReference"]
                        ),
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $value["reference"]
                        ),
                    )
                );
            } else {
                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/' . $url . '.php">CLICK</a> Here to View Critical Audit Action<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/inspection/pdfReport.php?id=' . $p_id . '">CLICK</a> Here to View Critical Audit Report' . $url1
                    ),
                    'twoColData' => array(
                        'newref' => array(
                            'left' => '<strong>Risk Reference</strong>',
                            'right' => $resultd["reference"]
                        ),
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $value["reference"]
                        ),
                    )
                );
            }
            $emailObj->appendInfo($data);

            //$emailObj->appendInfo($data);      
            $emailObj->sendEmail('An Critical Audit Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

            $whoAU = $emailObj->getAUDetails();
            $emailObj->sendEmail('An Critical Audit Action To Be Approved Once Completed', $whoAU, array(), array(), 'me_completed', '', 'grey');

            if ($value['who2AU'] > 0) {
                $who2AU = $emailObj->getSecondApproverDetails();
                $emailObj->sendEmail('An Critical Audit Action To Be Approved Once Completed', $who2AU, array(), array(), 'me_completed', '', 'grey');
            }
        }
    }

    public function sendNAActionsData($p_id) {
        $partObj = SetupGeneric::useModule('Participant');
        $actObj = new Action();
        $details = $partObj->getAdminDetails();
        $actionData = array('description' => "An N/A was selected for this report. Consider removing the item(s) from the list",
            'who' => $details["participantID"],
            'who2AU' => 0,
            'module_name' => "inspectionN",
            'record' => $p_id,
            'status' => 1,
            'buname' => 0,
            'element' => "inspection",
            'currentwho' => $details["participantID"],
            'due_date' => date('m/d/Y', strtotime("+14 days")));


        $actObj->setActionDetails(0, $actionData);
        $new_action_id = $actObj->addAction2015();

        $this->setInspectionInfo($p_id, "");
        $inspection_data = $this->viewInspectionById();
        //var_dump($inspection_data);
        $emailObj = new actionEmailHelper($new_action_id);
        $who = $emailObj->getwhoDetails();

        $data = array(
            'singleColData' => array(
                'click-here-url' => '<BR><BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/inspection/pdfreport.php?id=' . $inspection_data['ID'] . '">CLICK</a> Here to View Inspection Report'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $inspection_data['reference']
                )
            )
        );


        $emailObj->appendInfo($data);


        $emailObj->sendEmail('An N/A was found during an Inspection', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function sendActionAlerts($p_record_id) {

        $this->inspectionSectionId = $p_record_id;

        $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE ID = %d ", _DB_OBJ_FULL, $this->inspectionSectionId);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$this->inspectionSectionId);

        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $section_data = $result[0];

        $this->InspectionId = $result[0]['inspectionID'];
        $inspection_details = $this->viewInspectionById();

        $orgObj = SetupGeneric::useModule('Organigram');
        $orgObj->setItemInfo(array('id' => $inspection_details['buID']));
        $org_data = $orgObj->displayItemById();
        $orgObj = null;

        $section_data['reference'] = $inspection_details['reference'];
        $section_data['isRiskValid'] = $section_data['isRiskValid'] == 1 ? 'Yes' : 'No';

        $section_data['process_bu'] = $org_data['buName'];

        if ($section_data['actionID'] != '') {
            $this->actionHandling->setActionDetails($section_data['actionID'], "");
            $action_data = $this->actionHandling->viewAction();
            $section_data['action'] = $action_data['actionDescription'];
            $section_data['who'] = $action_data['who'];
            $section_data['whoAU'] = $action_data['whoAU'];
            $section_data['when'] = format_date($action_data['dueDate']);
        }

        if ($section_data['tab'] == 2 || $section_data['tab'] == 3) {

            $sql = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d ", _DB_OBJ_FULL, $section_data['mainProcessID']);
            $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$section_data['mainProcessID']);
            $pStatement->execute();
            $process_metadata = $pStatement->fetchAll(PDO::FETCH_ASSOC);

            $objProcessMaster = new ProcessFlowMaster();
            $process_data = $objProcessMaster->displayProcessFlowById($section_data['mainProcessID']);

            $objRisk = new RiskAssessment();
            $rsk_details = $objRisk->getControlHazardSummary($section_data['mainProcessID'], $section_data['processStepID']);

            $section_data['process_title'] = $process_data['reference'];
            $section_data['description'] = $process_data['description'];

            $section_data['hazard_summary'] = $rsk_details['hazardSummary'];
            $section_data['control_summary'] = $rsk_details['controlSummary'];
            $section_data['risk_rating'] = $rsk_details['riskRating1'];
            $section_data['risk_rating_color'] = $rsk_details['riskRatingColor1'];
            $section_data['standards'] = $process_metadata[0]['criticalControlPoint'];
        }

        $miscObj = new Misc();

        if ($section_data['tab'] == 4) {
            $section_data['mse_element'] = $miscObj->get_mse_element($section_data['managementHazardID']);
        }

        if ($section_data['tab'] == 5) {
            $section_data['hazard'] = $miscObj->get_hazard($section_data['managementHazardID']);
        }

        if ($section_data['tab'] == 6) {

            $objProcessMaster = new ProcessFlowMaster();
            $process_data = $objProcessMaster->displayProcessFlowById($section_data['processID']);

            $section_data['process_title'] = $process_data['reference'];
            $section_data['description'] = $process_data['description'];

            $section_data['hazardClassification'] = $miscObj->get_main_hazard($section_data['hazardClassificationID']);
            $section_data['hazards'] = $miscObj->get_multiple_hazards($section_data['hazardsID']);

            $risk_color = $miscObj->get_risk_color($section_data['processID']);
            $section_data['risk_color'] = $risk_color['riskRatingColor1'];
            $section_data['risk_value'] = $risk_color['riskRating1'];
        }


        $email_data[0] = $section_data;


        return $email_data;
    }

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'full') {
            return $this->getInvExportDataFull();
        } else {

            return $this->getInvExportData();
        }
    }

    public function getInvExportDataFull() {


        $heading = array(array('refrence' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Who', 'When' => 'When', 'loc' => 'Location', 'ccp' => 'CCP', 'risk' => 'Risk', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'due' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.', 'ra' => 'Action Desc.', 'raw' => 'Action Who', 'rawu' => 'Action WhoAU', 'rdue' => 'Action Due Date', 'rdo' => 'Action Done Date', 'rdod' => 'Action Done Descp.', 'haz' => 'Hazards', 'pr' => 'Process Number', 'rv' => 'Risk Rating still valid'));

        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setInspectionInfo(1, array('archive' => $archive_session));
        $insp_records = $this->viewInspections();
//dump_array($insp_records);
//exit;
        if (count($insp_records)) {
            $i = 0;
            foreach ($insp_records as $value) {

                $bu_id1 = explode(",", $value['buID']);

                $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = '3'", _DB_OBJ_FULL, $value['ID']);

                $pStatement = $this->dbHand->prepare($sql);
//$pStatement->bindParam(1,$this->filters['id'],PDO::PARAM_INT);
                $pStatement->execute();
                $adata = $pStatement->fetch(PDO::FETCH_ASSOC);

                $sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = '5'", _DB_OBJ_FULL, $value['ID']);

                $pStatement = $this->dbHand->prepare($sql);
//$pStatement->bindParam(1,$this->filters['id'],PDO::PARAM_INT);
                $pStatement->execute();
                $rdata = $pStatement->fetch(PDO::FETCH_ASSOC);
//dump_array($adata);
//exit;

                $sql = sprintf("SELECT * FROM %s.swimlane WHERE buID = %d and (archive=0 or archive is null) ORDER BY swimID ASC ", _DB_OBJ_FULL, $bu_id1[0]);

                $pStatement = $this->dbHand->prepare($sql);
//$pStatement->bindParam(1,$this->filters['id'],PDO::PARAM_INT);
                $pStatement->execute();
                $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (count($data)) {
                    foreach ($data as $valueProcess) {

                        $process_id = $valueProcess['swimID'];

                        $sql_step = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d ORDER BY  altPathIndex,stepLevel,type,ID ASC", _DB_OBJ_FULL, $process_id);
//echo "<br/>";

                        $pStatement2 = $this->dbHand->prepare($sql_step);
//$pStatement2->bindParam(1,$process_id,PDO::PARAM_INT);
                        $pStatement2->execute();
                        $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

                        /* if ( !$ccp_done_flag ) {

                          $report_data['ccp'][$process_id]['reference'] = $valueProcess['reference'];
                          $report_data['ccp'][$process_id]['description'] = $valueProcess['description'];
                          } */

                        if (count($data_steps)) {
//$i=1;
//foreach ( $data_steps as $valueStep ) {
//if ( $valueStep['criticalControlPoint'] != '' ) {

                            $report_data['ccp']['reference'] = $valueProcess['reference'];
                            $report_data['ccp']['description'] = $valueProcess['description'];
//$report_data['ccp'][$process_id]['steps'][$i][text] = $valueStep['descQues']."<BR>".$valueStep['criticalControlPoint']." - ".$valueStep['cmsReference'];
//$report_data['ccp'][$process_id]['steps'][$i][step] = $valueStep['stepLevel'];
//}





                            $i++;
//}
                        }
                    }
                }

//dump_array($report_data);
                $c_r1 = implode(",", $report_data['ccp']);

                $sql = sprintf("SELECT * FROM %s.swimlane WHERE buID = %d and (archive=0 or archive is null) ORDER BY swimID ASC ", _DB_OBJ_FULL, $bu_id1[1]);

                $pStatement = $this->dbHand->prepare($sql);
//$pStatement->bindParam(1,$this->filters['id'],PDO::PARAM_INT);
                $pStatement->execute();
                $data1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
//dump_array($data1);
                if (count($data1)) {
                    foreach ($data1 as $valueProcess) {

                        $process_id = $valueProcess['swimID'];

                        $sql_step = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d ORDER BY  altPathIndex,stepLevel,type,ID ASC", _DB_OBJ_FULL, $process_id);
//echo "<br/>";

                        $pStatement2 = $this->dbHand->prepare($sql_step);
//$pStatement2->bindParam(1,$process_id,PDO::PARAM_INT);
                        $pStatement2->execute();
                        $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

                        /* if ( !$ccp_done_flag ) {

                          $report_data['ccp'][$process_id]['reference'] = $valueProcess['reference'];
                          $report_data['ccp'][$process_id]['description'] = $valueProcess['description'];
                          } */

                        if (count($data_steps)) {
//$i=1;
//foreach ( $data_steps as $valueStep ) {
//if ( $valueStep['criticalControlPoint'] != '' ) {

                            $report_data1['ccp']['reference'] = $valueProcess['reference'];
                            $report_data1['ccp']['description'] = $valueProcess['description'];
//$report_data['ccp'][$process_id]['steps'][$i][text] = $valueStep['descQues']."<BR>".$valueStep['criticalControlPoint']." - ".$valueStep['cmsReference'];
//$report_data['ccp'][$process_id]['steps'][$i][step] = $valueStep['stepLevel'];
//}





                            $i++;
//}
                        }
                    }
                }

//dump_array($report_data1);
                $c_r2 = implode(",", $report_data1['ccp']);

                $sql = sprintf("SELECT * FROM %s.swimlane WHERE buID = %d and (archive=0 or archive is null) ORDER BY swimID ASC ", _DB_OBJ_FULL, $bu_id1[2]);

                $pStatement = $this->dbHand->prepare($sql);
//$pStatement->bindParam(1,$this->filters['id'],PDO::PARAM_INT);
                $pStatement->execute();
                $data2 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
//dump_array($data2);
                if (count($data2)) {
                    foreach ($data2 as $valueProcess) {

                        $process_id = $valueProcess['swimID'];

                        $sql_step = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d ORDER BY  altPathIndex,stepLevel,type,ID ASC", _DB_OBJ_FULL, $process_id);
//echo "<br/>";

                        $pStatement2 = $this->dbHand->prepare($sql_step);
//$pStatement2->bindParam(1,$process_id,PDO::PARAM_INT);
                        $pStatement2->execute();
                        $data_steps = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

                        /* if ( !$ccp_done_flag ) {

                          $report_data['ccp'][$process_id]['reference'] = $valueProcess['reference'];
                          $report_data['ccp'][$process_id]['description'] = $valueProcess['description'];
                          } */

                        if (count($data_steps)) {
//$i=1;
//foreach ( $data_steps as $valueStep ) {
//if ( $valueStep['criticalControlPoint'] != '' ) {

                            $report_data2['ccp']['reference'] = $valueProcess['reference'];
                            $report_data2['ccp']['description'] = $valueProcess['description'];
//$report_data['ccp'][$process_id]['steps'][$i][text] = $valueStep['descQues']."<BR>".$valueStep['criticalControlPoint']." - ".$valueStep['cmsReference'];
//$report_data['ccp'][$process_id]['steps'][$i][step] = $valueStep['stepLevel'];
//}





                            $i++;
//}
                        }
                    }
                }

//dump_array($report_data2);
                $c_r3 = implode(",", $report_data2['ccp']);

//exit;

                $insp_id = $value['ID'];
                $orgObj->setItemInfo(array('id' => $value['buID']));
                $bu_details = $orgObj->displayItemById();

                $locObj->setItemInfo(array('id' => $value['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $participant_id = $value['participantID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['ref'] = $value['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['when'] = format_date($value['whenDate']);
                $result[$i]['loc'] = str_replace(',', '-', $location);
                $result[$i]['ccp'] = $c_r1 . ',' . $c_r2 . ',' . $c_r3;
                $result[$i]['risk'] = $c_r1 . ',' . $c_r2 . ',' . $c_r3;
                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $adata['actionID'],
                ));

                $data_records7 = $type->displayItemById5();
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['due'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $rdata['actionID'],
                ));

                $data_records7 = $type->displayItemById5();
                $result[$i]['ra'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['raw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['rawu'] = $participant_name2;
                $result[$i]['rdue'] = format_datetime($data_records7['dueDate']);
                $result[$i]['rdo'] = format_datetime($data_records7['doneDate']);
                $result[$i]['rdod'] = $data_records7['doneDescription'];
                $result[$i]['haz'] = $c_r3;
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;
                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
//return $heading;
    }

    /*     * *
     * * This method is used to get
     * * listing records for Export
     * */

    public function getInvListingforExport() {


        $heading = array(array('refrence' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Who', 'When' => 'When', 'loc' => 'Location'));

        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setInspectionInfo(1, array('archive' => $archive_session));
        $insp_records = $this->viewInspections();

        if (count($insp_records)) {
            $i = 0;
            foreach ($insp_records as $value) {

                $insp_id = $value['ID'];
                $orgObj->setItemInfo(array('id' => $value['buID']));
                $bu_details = $orgObj->displayItemById();

                $locObj->setItemInfo(array('id' => $value['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $participant_id = $value['participantID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['ref'] = $value['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['when'] = format_date($value['whenDate']);
                $result[$i]['loc'] = str_replace(',', '-', $location);

                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
//return $heading;
    }

    public function getActionMailData($action_id) {

        $sql = sprintf("SELECT inspectionID,step,subStep FROM %s.inspection_metadata WHERE actionID = %d", _DB_OBJ_FULL, $action_id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $insp_metadata = $pStatement->fetch(PDO::FETCH_ASSOC);
        $inspection_id = $insp_metadata['inspectionID'];
        $step = 'Step ' . $insp_metadata['step'];
        $sub_step = 'Substep ' . $insp_metadata['subStep'];

        $sql2 = sprintf("SELECT buID,reference FROM %s.inspection WHERE ID = %d", _DB_OBJ_FULL, $inspection_id);
        $pStatement = $this->dbHand->prepare($sql2);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        $mail_data['bu_id'] = $result['buID'];
        $mail_data['reference'] = $result['reference'];
        $mail_data['step'] = $step;
        $mail_data['sub_step'] = $sub_step;

        return $mail_data;
    }

    public function getBuName($id) {

        $sql = sprintf("select B.buName from %s.business_units B inner join %s.inspection I on B.buID=I.buid where I.id= %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result['buName'];
    }

    public function getRiskDetailsForOutsatnding($p_process_id) {

        $sql = sprintf("SELECT * FROM %s.risk WHERE ID = %d ", _DB_OBJ_FULL, $p_process_id);
        $pStatement = $this->dbHand->prepare($sql);

//$pStatement->bindParam(1,$p_process_id,PDO::PARAM_INT);
//$pStatement->bindParam(2,$p_step_id,PDO::PARAM_INT);
        $pStatement->execute();
        $process_dtata = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $process_dtata[0];
    }

        public function initializeActions($id, $part1, $part2, $part3){
//entered to remove error;
//something to do with overdue records
            //todo needs fixing
    }
    
    public function getOverDueActions($loc, $date) {
        $this->sql_query = sprintf("select A.id,M.step,M.subStep,M.problem,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name  from %s.actions A  inner join %s.inspection_metadata M on a.record=M.ID left join %s.Inspection I on M.inspectionid=I.ID left join %s.locationgram L on I.locationid=L.locID  left join %s.participant_database P on A.currentWho=P.participantID  where modulename like '%s'  and approveAU=0 and I.locationID=%d and duedate < '%s' ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, 'inspection%', $loc, $date);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getOutstandingActions($loc, $fdate) {

        $insp_out = SetupGeneric::useModule('InspectionOutstandingAction');
        $outstanding_duration = explode(':', $insp_out->displayItems());

        switch ($outstanding_duration[1]) {
            case 'M' : $interval = '+' . $outstanding_duration[0] . ' MONTH';
                break;
            case 'Y' : $interval = '+' . $outstanding_duration[0] . ' YEAR';
                break;
        }

        $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");


        $this->sql_query = sprintf("select A.id,M.step,M.subStep,M.problem,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name  from %s.actions A  inner join %s.inspection_metadata M on a.record=M.ID left join %s.Inspection I on M.inspectionid=I.ID left join %s.locationgram L on I.locationid=L.locID  left join %s.participant_database P on A.currentWho=P.participantID  where modulename like '%s'  and approveAU=0 and I.locationID=%d and duedate >=  '%s' ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, 'inspection%', $loc, $outstandingDate);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function updateStages($id, $stage) {

        $sql = sprintf("update %s.inspection set stages=(isnull(stages,0) | %d) where id= %d", _DB_OBJ_FULL, $stage, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function sendActionWarnings() {

        $sql = sprintf("update %s.actions set outstandingcomment='%s' WHERE ID = %d ", _DB_OBJ_FULL, $this->InspectionInfo["comment"], $this->InspectionInfo["aid"]);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $emailObj = new actionEmailHelper($this->InspectionInfo["aid"]);

        $who = $emailObj->getwhoDetails();

        $data = array(
            'singleColData' => array(
                'click-here-url' => '',
                'summary' => '<B>Comment</B><BR>' . $this->InspectionInfo["comment"]
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $this->InspectionInfo["reference"]
                )
            )
        );
        $emailObj->appendInfo($data);
        $emailObj->sendEmail('A Critical Audit Comment', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function getPCIdetails($id) {

        $sql = sprintf("select pci_text from %s.PCI_Compliance where pci_details_list_ID= %d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $data['pci_text'];
    }

    public function initializeCCPs($inspData, $ccpData) {


        $sql = sprintf("INSERT INTO %s.inspection_tab2 (swimid,swimtitle,step.ccpref,ccpstd,cmsummary,inspectid,processPos,ccpPos)
											VALUES (%d,'%s','%s','%s','%s','%s',%d,%d,%d)", _DB_OBJ_FULL, $ccpData['process_id'], $ccpData['desc'], $ccpData['desc_ques'], $ccpData['ccp'], $ccpData['cms_ref'], $ccpData['cms_ref'], $this->InspectionId, $ccpData['pcount'], $ccpData['scount']);


        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        //var_dump($inspData);
        echo "<BR>";
        //var_dump($ccpData);
        //exit();

        $sql = sprintf("INSERT INTO %s.inspection_metadata (inspectionID,tab,step,subStep,expectation,outstanding,mainProcessID,processStepID,isRiskValid)
											VALUES (%d,2,%d,%d,'','0',%d,%d,0)", _DB_OBJ_FULL, $this->InspectionId, $ccpData['pcount'], $ccpData['scount'], $ccpData['process_id'], $ccpData['step_id']);


        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function getCountofNA($id) {

        $sql = sprintf("select count(*) as cnt from %s.inspection_metadata where expectation='N' and inspectionID=%d", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $data["cnt"];
    }

    public function initializeHazards($inspData, $i) {



        $sql = sprintf("INSERT INTO %s.inspection_metadata (inspectionID,tab,step,subStep,expectation,outstanding,mainProcessID,managementHazardID,processStepID,isRiskValid)
											VALUES (%d,5,%d,%d,'','0',%d,%d,0,0)", _DB_OBJ_FULL, $this->InspectionId, $i, $i, $this->InspectionId, $inspData['eID']);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $newId = customLastInsertId($this->dbHand, 'inspection_metadata', 'ID');
        $sql = sprintf("INSERT INTO %s.inspection_metadata (hazard,hazStr,points,inspectID,hazID,pointsID,metalinkid)
											VALUES (%d,'%s','%s',%d,%d,%d)", _DB_OBJ_FULL, $inspData['mainCatID'], $inspData['secondaryHazard'], $inspData['pointsToReview'], $this->InspectionId, $inspData['subCatID'], $i, $newId);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function updatePersonDetail() {
        $sql = "update %s.inspection_team set archive=1 where inspection=%d";
        $psql = sprintf($sql, _DB_OBJ_FULL, $this->InspectionId);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        if ($this->InspectionInfo["inspector"]) {
            $sql = "INSERT into %s.inspection_team (inspection,p_id) VALUES (%d,%d)";
            foreach ($this->InspectionInfo["inspector"] as $a => $value) {
                $psql = sprintf($sql, _DB_OBJ_FULL, $this->InspectionId, $value);
                $stmt = $this->dbHand->prepare($psql);
                $stmt->execute();
            }
        }


        return;
    }

    public function getParticipants($id) {
        $this->id = $id;
        $sql = "SELECT P.forename+' '+P.surname  as name,T.p_id FROM %s.inspection_team T inner join %s.participant_database P on T.p_id=P.participantid WHERE T.archive=0 and inspection = " . $this->id;
        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

        public function getInspectionTeam($loc_id) {
        $this->loc_id = $loc_id;
        //get last inspection
        $sql = "SELECT * FROM %s.inspection WHERE locationID = " . $this->loc_id. " order by id desc";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result1 = $stmt->fetch(PDO::FETCH_ASSOC);
     

        //get_team

        if(is_array($result1)){
        $sql = "SELECT * FROM %s.inspection_team WHERE archive=0 and inspection = " . $result1["ID"] . " order by id desc";
        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        }
        
        return $result;
    }
    
    public function updateActionDueActions($id, $who) {
        $this->loc_id = $id;
        $this->dat = $dat;
        $today=date("Y-m-d");

               $sql = "UPDATE %s.actions SET doneDate = '" . $today. "',donedescription='Inspection started by ".$who."',approcveau=1  WHERE locID =" . $this->loc_id . " AND approcveau=0";
                $psql = sprintf($sql, _DB_OBJ_FULL);

                $stmt = $this->dbHand->prepare($psql);


                $stmt->execute();
        
    }
public function getValidTabs($inspect_id) {
   
             $sql = sprintf(" select count(tab) as cnt,tab from %s.inspection_metadata where inspectionID=%d. group by tab", _DB_OBJ_FULL,$inspect_id);
                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();
             $result = $stmt->fetchAll(PDO::FETCH_ASSOC); 
             foreach($result as $row){
              $tabArr[$row["tab"]]=  $row["cnt"];
                 
             }
             return $tabArr;
}
    public function initializeRisk($inspData, $ccpData) {

        $sql = sprintf("INSERT INTO %s.inspection_metadata (inspectionID,tab,step,subStep,expectation,outstanding,mainProcessID,processStepID,isRiskValid)
											VALUES (%d,3,%d,%d,'','0',%d,%d,0)", _DB_OBJ_FULL, $this->InspectionId, $ccpData['pcount'], $ccpData['scount'], $ccpData['process_id'], $ccpData['step_id']);


        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }
}
?>