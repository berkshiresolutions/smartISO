<?php
 /**
  $Id: DocumentContributor.class.php,v 4.09 Saturday, January 29, 2011 6:46:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This object define the various operations related with Document Contributor object
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Document
  * @since  Saturday, September 11, 2010 2:48:01 PM>
  */

class DocumentContributor
{

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	private $documentId;

	private $documentInformation;

	private $contributorId;

	/**
	 * Constructor for initializing Document Contributor object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 					= DB::connect(_DB_TYPE);
		$this->documentId				= 0;
		$this->contributorId			= 0;
		$this->contributorInformation 	= array();
	}

	/*
	 * This method is used to initialize object for performing various operations.
	 *
	 * @param $p_documentId integer		Id of the document to assign contributor for
	 * @param $p_contributorInfo array 	This will provide contributors information in an array
	 * @access public
	 */
	public function setContributorInfo($p_contributorId,$p_contributorInfo) {

		$this->contributorId 			= $p_contributorId;
		$this->contributorInformation 	= $p_contributorInfo;
	}

	public function viewAssignedDocuments($p_filter_date='') {

		$USER_ID = getLoggedInUserId();
		
		$is_Admin=isAdministrator();
if($is_Admin) {
$sql = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0
				
				",_DB_OBJ_FULL);

		if ( $p_filter_date != '' ) {
			$sql = $sql." AND contribDueDate <= '".$p_filter_date."'";
		}

	$sql = $sql." ORDER BY contributorID DESC";

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
}else{
$sql = sprintf("SELECT * FROM %s.cms_documents_contributors
				WHERE passed = 0 AND authParticipantID = %d
				",_DB_OBJ_FULL,$USER_ID);

		if ( $p_filter_date != '' ) {
			$sql = $sql." AND contribDueDate <= '".$p_filter_date."'";
		}

		$sql = $sql." ORDER BY contributorID DESC";

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);

}
		//$USER_ID =  5;

		
	}
	
        public function getCountOverdueDocuments() {
          $data=$this->viewOverdueDocuments() ;
          if(is_array($data))
            return count($data);
          else
              return 0;
        }
     
        public function viewOverdueDocuments($p_filter_date='') {

		$USER_ID = getLoggedInUserId();
		$date=date("Y-m-d");
		$is_Admin=isAdministrator();
if($is_Admin) {
 $sql = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed = 0 and contribDueDate<='%s'
				
				",_DB_OBJ_FULL,$date);

		

		$sql = $sql." ORDER BY contributorID DESC";

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
}else{
 $sql = sprintf("SELECT * FROM %s.cms_documents_contributors
				WHERE passed = 0 AND authParticipantID = %d and contribDueDate<='%s'
				",_DB_OBJ_FULL,$USER_ID,$date);



		$sql = $sql." ORDER BY contributorID DESC";

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);

}
		//$USER_ID =  5;

		
	}
        
	public function viewAssignedDocuments1($p_filter_date='') {

		$USER_ID = getLoggedInUserId();
		
		$is_Admin=isAdministrator();
if($is_Admin) {
$sql = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE passed != 0
				
				",_DB_OBJ_FULL);

		if ( $p_filter_date != '' ) {
			$sql = $sql." AND contribDueDate <= '".$p_filter_date."'";
		}

		$sql = $sql." ORDER BY contributorID DESC";

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
}else{
$sql = sprintf("SELECT * FROM %s.cms_documents_contributors
				WHERE passed != 0 AND authParticipantID = %d
				",_DB_OBJ_FULL,$USER_ID);

		if ( $p_filter_date != '' ) {
			$sql = $sql." AND contribDueDate <= '".$p_filter_date."'";
		}

		$sql = $sql." ORDER BY contributorID DESC";

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);

}
		//$USER_ID =  5;

		
	}
	
	public function emailFire($id){
	
	$this->id = $id;
	$sql = sprintf("SELECT * FROM %s.cms_documents_contributors
				WHERE cmsdocID = ".$this->id." AND passed = 0
				",_DB_OBJ_FULL);

		

	

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	
	}
	
	public function emailFire1($id){
	
	$this->id = $id;
	$sql = sprintf("SELECT * FROM %s.cms_documents_contributors
				WHERE cmsdocID = ".$this->id." AND passed != 0
				",_DB_OBJ_FULL);

		

	

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	
	}
	
   public function viewDueDate($dat) {
		$this->dat = $dat;
		$USER_ID = getLoggedInUserId();

		$sql = sprintf("SELECT * FROM %s.cms_documents_contributors
				WHERE  contributorID = '".$this->dat."'
				",_DB_OBJ_FULL);

		
		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$USER_ID);
		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}


	public function saveContributorReply() {

		$contributor['contid'] 				= $_POST['contid'];
		$contributor['comments'] 			= $_POST['comments'];
		$contributor['authorize'] 			= $_POST['authorize'];

		if ( $contributor['authorize'] == 'N' ) {
			$authorize = 2;
		} else {
			$authorize = 1;
		}

		$doc_issuer_auth					= '0';

		$sql = sprintf("UPDATE %s.cms_documents_contributors
				SET
					date = ".customCurrentDate().",
					reply = '%s',
					passed = '%d',
					documentID = %d
				WHERE contributorID = %d",_DB_OBJ_FULL,smartisoAddslashes($this->contributorInformation['comments']),$authorize,$this->contributorInformation['file_id'],$this->contributorId);

        $stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
return $this->documentId;
	}
	
        	public function getalert($contid){
	 $sql = sprintf("select alertID from %s.cms_documents_contributors

					
				WHERE contributorID = %d",_DB_OBJ_FULL,$contid);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
                
        return $stmt->fetch(PDO::FETCH_ASSOC);
                }
	public function approveDocument($id,$who,$date){
	$this->id= $id;
	$this->who= $who;
	$this->dat= $date;
	
	 $sql = sprintf("UPDATE %s.cms_documents_metadata
				SET
					dateApproved = '".$this->dat."',
					approvedBy = ".$this->who."
					
				WHERE cmsdocID = ".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$contributor['comments']);
		$stmt->bindParam(2,$authorize);
		$stmt->bindParam(3,$doc_issuer_auth);
		$stmt->bindParam(4,$this->contributorId);*/
		$stmt->execute();
		
	echo $sql = sprintf("UPDATE %s.cms_documents
				SET
					status = 'A'
					
					
				WHERE cmsdocID = ".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		/*$stmt->bindParam(1,$contributor['comments']);
		$stmt->bindParam(2,$authorize);
		$stmt->bindParam(3,$doc_issuer_auth);
		$stmt->bindParam(4,$this->contributorId);*/
		$stmt->execute();

	}

	private function uploadDocumentFile() {

		$objFile = new Upload();

		$this->contributorInformation['file_info']['destination'] = 'contributors';

		$objFile->setFileInfo($this->contributorInformation['file_info']['destination'],$this->contributorInformation['file_info']);
		$objFile->add_file();
		$this->documentId = $objFile->getLastFileId();

		$objFile = null;
	}

        	public function assignContributors($p_documentId,$p_info) {

		$ins = "INSERT INTO %s.cms_documents_contributors (cmsdocID,authParticipantID,date,passed,comments,documentID,contribDueDate)
				VALUES (%d,%d,".customCurrentDate().",0,'%s',0,'%s')";

		if ( count($p_info['contributors']) ) {
		$i = 0;		
                foreach ( $p_info['contributors'] as $contributor ) {

				$sql = sprintf($ins,_DB_OBJ_FULL,$p_documentId,$contributor,smartisoAddslashes($p_info['comment'][$i]),format_date_for_mysql($p_info['due_date'][$i]));

				$stmt = $this->dbHand->prepare($sql);

				$stmt->execute();
				$i++;
			}
		}


		$participantObj = null;

		$ins_sec = sprintf("UPDATE %s.cms_documents_metadata
					SET authorizerComment = '%s'
					WHERE cmsdocID = %d",_DB_OBJ_FULL,$p_info['comment'],$p_documentId);

		$stmt_sec = $this->dbHand->prepare($ins_sec);

		/*$stmt_sec->bindParam(1,$p_info['comment']);
		$stmt_sec->bindParam(2,$p_documentId);*/

		$stmt_sec->execute();
	}
        
        public function assignContributor($p_documentId,$p_info) {

		$ins = "INSERT INTO %s.cms_documents_contributors (cmsdocID,authParticipantID,date,passed,comments,documentID,contribDueDate,alert,alertID)
				VALUES (%d,%d,".customCurrentDate().",0,'%s',0,'%s',%d,%d)";

				$sql = sprintf($ins,_DB_OBJ_FULL,$p_documentId,$p_info['contributors'],smartisoAddslashes($p_info['comment']),format_date_for_mysql($p_info['due_date']),$p_info['alert'],$p_info['alertID']);

				$stmt = $this->dbHand->prepare($sql);

				$stmt->execute();
	$last_insert_id = customLastInsertId($this->dbHand, 'cms_documents_contributors', 'contributorID');			


		$participantObj = null;

		$ins_sec = sprintf("UPDATE %s.cms_documents_metadata
					SET authorizerComment = '%s'
					WHERE cmsdocID = %d",_DB_OBJ_FULL,$p_info['comment'],$p_documentId);

		$stmt_sec = $this->dbHand->prepare($ins_sec);

		$stmt_sec->execute();
                return $last_insert_id;
	}
	public function assignInitialContributors($p_documentId,$p_info) {

		$ins = "INSERT INTO %s.cms_documents_contributors (cmsdocID,authParticipantID,date,passed,comments,documentID,contribDueDate)
				VALUES (%d,%d,".customCurrentDate().",0,'%s',0,'%s')";

		if ( count($p_info['contributors']) ) {
		$i = 0;		
                foreach ( $p_info['contributors'] as $contributor ) {

				$sql = sprintf($ins,_DB_OBJ_FULL,$p_documentId,$contributor,smartisoAddslashes($p_info['comment'][0]),format_date_for_mysql($p_info['due_date'][0]));

				$stmt = $this->dbHand->prepare($sql);

				$stmt->execute();
				$i++;
			}
		}


		$participantObj = null;

		$ins_sec = sprintf("UPDATE %s.cms_documents_metadata
					SET authorizerComment = '%s'
					WHERE cmsdocID = %d",_DB_OBJ_FULL,$p_info['comment'],$p_documentId);

		$stmt_sec = $this->dbHand->prepare($ins_sec);

		/*$stmt_sec->bindParam(1,$p_info['comment']);
		$stmt_sec->bindParam(2,$p_documentId);*/

		$stmt_sec->execute();
	}
        
        	public function saveDropContributor() {

		$authorize = 3;


		$sql = sprintf("UPDATE %s.cms_documents_contributors
				SET
				reply = '%s',
				passed = '%s'
				WHERE passed=0 and cmsdocID = %d",_DB_OBJ_FULL,smartisoAddslashes($this->contributorInformation['comments']),$authorize,$this->documentId);

                 $stmt = $this->dbHand->prepare($sql);

		$stmt->execute();

	}
        
                	public function getExportDetails() {

		$sql = sprintf("select surname,forename,fileReference,title,date,passed from %s.cms_documents D inner join %s.cms_documents_contributors C on D.cmsdocID=C.cmsdocID inner join %s.participant_database P on C.authParticipantID=P.participantid order by surname",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);

                 $stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		
	return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
        
        	public function getContributorall() {

		$sql = sprintf("SELECT * FROM %s.cms_documents_contributors",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		if($action_data){
			
				foreach ($action_data as $key1 => $value1){
					foreach ($action_data as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($action_data[$key1]['authParticipantID'] == $action_data[$key2]['authParticipantID'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($action_data[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
		  
		   $i = 0;
		   $res = array();
		   foreach($action_data as $val){
		   $p_id = $val['authParticipantID'];
		     $sql = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE authParticipantID=".$val['authParticipantID'],_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$result_full = array();
		$result_data = array();
		$result_tottal = array();
		
			$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
		
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
		
				$c_id = 	$row['authParticipantID'];
				if($row['passed'] == 0){
				  $result_full[$c_id]++;
				}else{
				
				  $result_data[$c_id]++;
				}	
				 $result_tottal[$c_id]++;
				
			}
		}
		
	 	$res1 = round(($result_data[$c_id]*100)/$result_tottal[$c_id]);
		 $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = ".$p_id,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$res7 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
		$name = $res7['forename'].''.$res7['surname'];
		
		if($name){
		$res[$i]['key'] = $name;
		$res[$i]['value'] = $res1;
		
		
		$i++;
		}
		
	
		   }


		return $res;
	}
	
	public function getContributor() {

		$sql = sprintf("SELECT * FROM %s.participant_authorization_stats WHERE sectionName='perm_cntrb' AND sectionActive = '1'",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if($action_data){
			
				foreach ($action_data as $key1 => $value1){
					foreach ($action_data as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($action_data[$key1]['participantID'] == $action_data[$key2]['participantID'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($action_data[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
		   $i = 0;
		   $res = array();
		   foreach($action_data as $val){
		   $p_id = $val['participantID'];
		     $sql = sprintf("SELECT * FROM %s.cms_documents_contributors WHERE authParticipantID=".$val['participantID'],_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$result_full = array();
		$result_data = array();
		$result_tottal = array();
		
			$no_rows = $pStatement->rowCount();
		if ( $no_rows ) {
		
			while ($row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {
		
				$c_id = 	$row['authParticipantID'];
				if($row['passed'] == 0){
				  $result_full[$c_id]++;
				}else{
				
				  $result_data[$c_id]++;
				}	
				 $result_tottal[$c_id]++;
				
			}
		}
		if ($result_tottal[$c_id]>0)
	 	$res1 = round(($result_data[$c_id]/$result_tottal[$c_id])*100);
	else
		$res1 = 0;
		 $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = ".$p_id,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$res7 = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		
		$name = $res7['forename'].''.$res7['surname'];
		
		if($name){
		$res[$i]['key'] = $name;
		$res[$i]['value'] = $res1;
		
		
		$i++;
		}
		
	
		   }


		return $res;
	}
}
?>