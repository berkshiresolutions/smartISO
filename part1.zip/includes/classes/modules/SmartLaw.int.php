<?php
 /**
  $Id: SmartLaw.int.php,v 3.18 Tuesday, December 21, 2010 11:00:46 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage smart law object
  *
  * This interface will declare the various methods performed
  * by the smart law object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface SmartLawInterface
{
	/*
	 * to set smart law information for performing various operations with the smart law object
	 */
	public function setSmartLawInfo($p_smartLawId,$p_smartLawInfo);

	/*
	 * This method is used to view the smart law information.
	 */
	public function viewSmartLaw();

	/*
	 * This method is used to save the smart law information
	 */
	public function editSmartLaw();

}