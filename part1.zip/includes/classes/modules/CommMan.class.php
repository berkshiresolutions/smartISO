<?php

/**
  $Id: Comm.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, October 09, 2010 12:50:41 PM>
 */
require "CommMan.int.php";
require_once "Action.class.php";

class CommMan implements CommInterface {

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Comm Id
     * @access private
     */
    private $commId;

    /**
     * Property to hold Comm Info
     * @access private
     */
    private $commInfo;

    /**
     * Constructor for initializing Manual Handling object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /**
     * to set comm information for performing various operations with the comm object
     * @param integer This parameter holds the comm Id
     * @param array This parameter holds the the comm Info
     */
    public function setCommInfo($p_commId, $p_commInfo) {

        $this->commId = $p_commId;
        $this->commInfo = $p_commInfo;
    }

    public function addComm() {
        
    }

    public function addComm1() {
                $ogrObj = SetupGeneric::useModule('Organigram');
        $region=new Region();
		if ($this->commInfo['action_r']==1){
			$reviewdate = "3000-01-01";
		}
		else{
$optionObj = new Option();

$delay = $optionObj->getOption('_SU_COMMS_ARCHIVE_DELAY');
$reviewdate = date('Y-m-d', strtotime("+ " . $delay. " days"));
	}

  $sql = sprintf("INSERT INTO %s.comms_mangement ( reference, uniqueReference, date_r,client,
											date_u, process_r, title, country, type, action_r,
											received, company, document_n, descp, related, bu,document_c,d_id,drop_n,country_from,audit,induct,isIS,who,media_type,in_out,comments,criteria,archive_date,docdate,sub_ref,code27002)
										VALUES ( '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%d,%d,%d,%d,%d,%d,%d,'%s',%d,'%s','%s',%d,%d) ", _DB_OBJ_FULL, $this->commInfo['reference'], $this->commInfo['unique_reference'], $this->commInfo['date_r'], $this->commInfo['client']
                , $this->commInfo['date_u'], $this->commInfo['process_r'], $this->commInfo['title'], $this->commInfo['country']
                , $this->commInfo['type'], $this->commInfo['action_r']
                , $this->commInfo['received'], $this->commInfo['company'], $this->commInfo['document']
                , $this->commInfo['description'], $this->commInfo['related'], $this->commInfo['bu'], $this->commInfo['document_class'], $this->commInfo['file_id']
                , $this->commInfo['drop'], $this->commInfo['countryf'], $this->commInfo['ia'], $this->commInfo['id'], $this->commInfo['is'], $this->commInfo['owner'], $this->commInfo['media'], $this->commInfo['in_out'], $this->commInfo['comments'], $this->commInfo['criteria'],$reviewdate, $this->commInfo['docdate'], $this->commInfo['sub_ref'], $this->commInfo['code51']
                
        );

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
exit();
        $this->commId = customLastInsertId($this->dbHand, 'comms_mangement', 'ID');

$this->addFiles($this->commId, $this->commInfo['fileID']);
        $this->moveFiles();
 //       var_dump($this->commInfo);
//var_dump($this->commInfo['actions']);

        if ($this->commInfo['action_r'] == 1) {
            $actObj = new Action();
            foreach ($this->commInfo['actions'] as $actions) {
                $actionData = array('description' => $actions['action'],
                    'who' => $actions['who'],
                    'whoAU' => $actions['whoAU'],
                    'who2AU' => $actions['whoAU2'],
                    'module_name' => "Communications",
                    'record' => $this->commId,
                    'status' => 1,
                    'buname' => 0,
                    'element' => "comms_mangement",
                    'currentwho' => $actions['who'],
                    'due_date' => $actions['when']);
                $actObj->setActionDetails(0, $actionData);

                $lastId = $actObj->addAction2015();
$periodArr=array(0 =>'-',1 =>'Monthly',2 =>'Bi- Monthly',3=>'Quarterly',4 =>'Semi-Annually',5 => 'Annually',6 => 'Bi - Annually',7 => 'Tri - Annually');
                $sql = sprintf("INSERT INTO %s.comms_action_link(commID,actionID,company,region,alerttype,law_period) VALUES (%d,%d,%d,%d,'%s',%d) "
                        , _DB_OBJ_FULL
                        , $this->commId
                        , $lastId
                        , $actions['company']
                        , $actions['country']
                        , $actions['atype']
                        ,$actions['period']);

                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();
                
                if ($this->commInfo['save'] == 1) {
                    $emailObj = new actionEmailHelper($lastId);
                    $who = $emailObj->getwhoDetails();
                $resultC =   $region->getItemsbyId($actions['country']);
                $country= $resultC ? $resultC['Country'] : '-';
                $ogrObj->setItemInfo(array('id'=>$actions['company']));   
                $resultCo =   $ogrObj->displayItemById();
                $company= $resultCo ? $resultCo['buName'] : '-';
                $period=$periodArr[(int)$actions["period"]];
                
                
                
                                                $data = array(
                                        'singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/report.php?id=' . $this->commId . '">CLICK</a> Here to View Library report'.$url),
                        'twoColData' => array(
                            'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $this->commInfo['reference'] ),

                    ));
                $emailObj->appendInfo($data);


                    $emailObj->sendEmail('A Library Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
                }
            }
        }
        if ($this->commInfo['save'] == 1) {
                 $this->finish();
             }
           
    }

    /**
     * This method is used to view comm information.
     */
    public function viewComm() {

        $sql = sprintf("SELECT * FROM %s.comms_mangement WHERE ID =%d", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    /**
     * This method is used to edit a comm
     * location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
     * address,phone,email,comm_nature,likelihood,impact,risk_rating,risk_color,comm_category,investigation,action,who,when
     */
    public function editComm() {
        
    }

    public function editComm23() {
                        $ogrObj = SetupGeneric::useModule('Organigram');
        $region=new Region();
		if ($this->commInfo['action_r']==1){
			$reviewdate = "3000-01-01";
		}
		else{
$optionObj = new Option();
        
$delay = $optionObj->getOption('_SU_COMMS_ARCHIVE_DELAY');
$reviewdate = date('Y-m-d', strtotime("+ " . $delay. " days"));
	}
       $sql = sprintf("UPDATE %s.comms_mangement SET date_r = '" . $this->commInfo['date_r'] . "',
										client = '" . $this->commInfo['client'] . "',
										date_u = '" . $this->commInfo['date_u'] . "',
                                                                                docdate = '" . $this->commInfo['docdate'] . "',
										process_r = '" . $this->commInfo['process_r'] . "',
										title = '" . $this->commInfo['title'] . "',
										country = '" . $this->commInfo['country'] . "',
										type = '" . $this->commInfo['type'] . "',
										action_r = '" . $this->commInfo['action_r'] . "',
										received = '" . $this->commInfo['received'] . "',
										company = '" . $this->commInfo['company'] . "',
										document_n = '" . $this->commInfo['document'] . "',
										descp = '" . $this->commInfo['description'] . "',
										related = '" . $this->commInfo['related'] . "',
										document_c = '" . $this->commInfo['document_class'] . "',
										bu = '" . $this->commInfo['bu'] . "',
                                                                                who = '" . $this->commInfo['owner'] . "',
                                                                                in_out = '" . $this->commInfo['in_out'] . "',
                                                                                media_type = '" . $this->commInfo['media'] . "',
                                                                                audit = '" . $this->commInfo['ia'] . "',
                                                                                induct = '" . $this->commInfo['id'] . "',
                                                                                isIS = '" . $this->commInfo['is'] . "',
                                                                                code27002 = '" . $this->commInfo['code51'] . "',
										criteria = '" . $this->commInfo['criteria'] . "',
archive_date = '" . $reviewdate . "',
										comments = '" . $this->commInfo['comments'] . "',
                                                                               country_from = " . $this->commInfo['countryf'] . ",
										drop_n = '" . $this->commInfo['drop'] . "'
								WHERE ID = " . $this->commId, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
 $this->removeActions();
        if ($this->commInfo['action_r'] == 1) {
            $actObj = new Action();

            foreach ($this->commInfo['actions'] as $actions) {
                $actionData = array('description' => $actions['action'],
                    'who' => $actions['who'],
                    'whoAU' => $actions['whoAU'],
                    'who2AU' => $actions['whoAU2'],
                    'module_name' => "Communications",
                    'record' => $this->commId,
                    'status' => 1,
                    'buname' => 0,
                    'element' => "comms_mangement",
                    'currentwho' => $actions['who'],
                    'due_date' => $actions['when']);
                $actObj->setActionDetails(0, $actionData);

                $lastId = $actObj->addAction2015();
          
                            $sql = sprintf("INSERT INTO %s.comms_action_link(commID,actionID,company,region,alerttype,law_period) VALUES (%d,%d,%d,%d,'%s',%d) "
                        , _DB_OBJ_FULL
                        , $this->commId
                        , $lastId
                        , $actions['company']
                        , $actions['country']
                        , $actions['atype']
                        ,$actions['period']);

                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();
                
             
                
  if ($this->commInfo['save'] == 1) {
      
$periodArr=array(0 =>'-',1 =>'Monthly',2 =>'Bi- Monthly',3=>'Quarterly',4 =>'Semi-Annually',5 => 'Annually',6 => 'Bi - Annually',7 => 'Tri - Annually');
                $emailObj = new actionEmailHelper($lastId);
                $who = $emailObj->getwhoDetails();
                $whoAU = $emailObj->getAUDetails();
                $resultC =   $region->getItemsbyId($actions['country']);
                $country= $resultC ? $resultC['Country'] : '-';
                $ogrObj->setItemInfo(array('id'=>$actions['company']));   
                $resultCo =   $ogrObj->displayItemById();
                $company= $resultCo ? $resultCo['buName'] : '-';
                $period=$periodArr[(int)$actions["period"]];
                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/report.php?id=' . $this->commId . '">CLICK</a> Here to View Library report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Referenced</strong>',
                            'right' => $this->commInfo['reference']
                        )
                    )
                );

                                    $data = array(
                                        'singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/report.php?id=' . $this->commId . '">CLICK</a> Here to View Library report'.$url),
                        'twoColData' => array(
                            'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $this->commInfo['reference'])
                    ));
                $emailObj->appendInfo($data);

                $emailObj->sendEmail('A Library Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
       
                $data = array(
                                        'singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>'),
                        'twoColData' => array(
                            'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $this->commInfo['reference']),
                            'description' => array('left' => '<strong>Title</strong>', 'right' => $slawdata['slsLegislation']),
                            'country' => array('left' => '<strong>Country</strong>', 'right' => $country)
                    ));
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Library Action To Be Approved Once Complete', $whoAU, array(), array(), 'me_completed', '', 'grey');
            }

        }
    }

                 if ($this->commInfo['save'] == 1) {

      
                 $this->finish();
             }
             
    }
    

    /**
     * This method is used to delete a comm
     */
    public function deleteComm() {
        
    }

    /**
     * This method is used to archive a comm
     */
    public function archiveComm() {
        
    }

    public function archiveComm44() {



        $sql = sprintf("UPDATE %s.comms_mangement SET archive = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();
    }

    public function archiveComm17() {



        $sql = sprintf("UPDATE %s.comms_mangement SET archive = '0' WHERE ID = %d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();
    }

    /**
     * This method is used to remove a comm
     */
    public function purgeComm() {
        
    }

    /**
     * This method is used to last insertted record Id
     */
    public function lastrecordId() {
        return $this->commId;
    }

    /**
     * This method is used to view all comms.
     */
    public function viewAllComms1() {
        $docObj = new Documents();
        $classification = $docObj->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

      $sql = sprintf("SELECT M.*,C.criteria,Q.code FROM %s.comms_mangement M left join %s.comms_criteria C on M.criteria=C.ID  left join msr_departments Q on M.code27002=Q.ID WHERE document_c in (%s)  and isnull(M.archive,0)=0 and  isnull(M.sub_ref,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL,_DB_OBJ_FULL, $classStr);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 0;


        return $result;
    }

        public function getLibraryDocs() {
        $docObj = new Documents();
        $classification = $docObj->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

      $sql = sprintf("SELECT M.*,F.* FROM %s.comms_mangement M inner join  %s.uploaded_files F on M.d_id=F.fileID left join %s.comms_criteria C on M.criteria=C.ID  WHERE document_c in (%s)  and isnull(M.archive,0)=0 and  isnull(M.sub_ref,0)=0 ORDER BY ID DESC", _DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL, $classStr);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 0;


        return $result;
    }
	
        public function displayAddedComms1($ref) {
        $docObj = new Documents();
        $classification = $docObj->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

     $sql = sprintf("SELECT M.*,C.criteria FROM %s.comms_mangement M left join %s.comms_criteria C on M.criteria=C.ID  WHERE document_c in (%s)  and isnull(M.archive,0)=0  and sub_ref>0 and reference='%s' ORDER BY ID DESC", _DB_OBJ_FULL,_DB_OBJ_FULL, $classStr,$ref);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }
    
    public function viewAllComms1ttt() {
        $docObj = new Documents();
        $classification = $docObj->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        $sql = sprintf("SELECT M.*,C.criteria FROM %s.comms_mangement M left join %s.comms_criteria C on M.criteria=C.ID WHERE document_c in (%s)  and M.archive ='1'   ORDER BY ID DESC", _DB_OBJ_FULL,_DB_OBJ_FULL, $classStr);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 0;

        return $result;
    }

    public function archiveRecord() {



        $sql = sprintf("UPDATE %s.comms_mangement SET archive = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();
    }

    public function restoreRecord() {

$optionObj = new Option();
$delay = $optionObj->getOption('_SU_COMMS_ARCHIVE_DELAY');
$reviewdate = date('Y-m-d', strtotime("+ " . $delay. " days"));
        $sql = sprintf("UPDATE %s.comms_mangement SET archive = '0',archive_date='%s' WHERE ID = %d ", _DB_OBJ_FULL, $reviewdate,$this->commId);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
    }

    private function moveFiles() {
        $rec_id = $this->commInfo['fileref'];

        $module = 'management';

        $path = _MYROOT . 'tmp/' . $module;


        $log_file = $path . '/script' . $rec_id . '.log';


        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);
            $objFile = new Upload();

            if (count($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);

                            $file_details = array('user_file_name' => $file_details_arr[2], 'file_type' => $file_type);
                            $objFile->setFileInfo($module, $file_details);
                            $objFile->setBogusDetails($file_details);
                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
                            //	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $this->addFiles($this->commId, $file_id);
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }

    public function addFiles($rec_id, $file_id) {

        $sql = sprintf("update %s.comms_mangement set d_id=%d where id=%d"
                , _DB_OBJ_FULL
                , $file_id
                , $rec_id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function viewActions() {
        $orgObj = SetupGeneric::useModule('Organigram');


$typeString = "<OPTION value='Process'>Process</option><OPTION value='Procedure'>Procedure</option><OPTION value='Update Template'>Update Template</option><OPTION value='Update Manual'>Update Manual</option><OPTION value='Training'>Training</option><OPTION value='Legislation'>Legislation</option><OPTION value='Other'>Other</option>";
$periodStr = "<option value='0' >-- Select --</option><option value='1' >Monthly</option><option value='2' >Bi- Monthly</option><option value='3'>Quarterly</option><option value='4'  >Semi-Annually</option><option value='5' >Annually</option><option value='6' >Bi - Annually</option><option value='7' >Tri - Annually</option>";

   $sql = sprintf("SELECT A.*,L.region,L.company,L.alerttype,L.law_period FROM  %s.actions  A left join %s.comms_action_link L on A.ID=L.actionID where record =%d and moduleelement='comms_mangement'", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->commId);


        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
       // $companies = $this->getCompanies($this->commId,$row["region"]);
        
        $busa = $orgObj->getCompanies();
        

        
        $i = 0;
        foreach ($result as $row) {
            $action_details[$i] = $row;
            $str1=$row['alerttype']."'";
            $str2=$row['alerttype']."' selected ";
            $action_details[$i]['atype']=str_replace($str1,$str2,$typeString);
            $str1=$row['law_period']."'";
             $str2="'".$row['law_period']."' selected ";
            $action_details[$i]['period']=str_replace($str1,$str2,$periodStr);
            
             $action_details[$i]['action_id'] = $row["ID"];
            $bus = $this->getCountries($row["region"]);
            $action_details[$i]['country'] = $bus;
                    foreach ($busa as $bu) {
            $sel= $bu["buID"] == $row["company"] ? "selected " : " ";
                $business_units .= "<option value='" . $bu["buID"] . "' ".$sel.">" . $bu["buName"] . "</option>";
            
        }
            $action_details[$i]['companies'] = $business_units;
            $i++;
        }

        return $action_details;
    }

    public function removeActions() {

        $sql = sprintf("delete FROM  %s.actions where record =%d and moduleelement='comms_GCUmangement'", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        
        $sql = sprintf("delete FROM  %s.comms_action_link where alertid =%d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    
        public function removeGCUActions() {

        $sql = sprintf("delete FROM  %s.actions where record =%d and moduleelement='comms_GCUmangement'", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        
         $sql = sprintf("delete FROM  %s.comms_gcuaction_link where alertid =%d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
    
    public function finish() {

                      $participantObj = SetupGeneric::useModule('Participant');        
            $optionObj = new Option();
            $emailObj = new actionEmailHelper(0);
            $ghl = $optionObj->getOption('_SU_GROUP_EMAIL');
            $dataC=$this->displayId($this->commId)  ; 
            $userID = getLoggedInUserId();


            $participantObj->setItemInfo(array('id' => $ghl));

            $details = $participantObj->displayItemById();

            $whoGLOC = array(
                'displayname' => 'GHL Group',
                'email' => $ghl,
                'ID' => $details['participantID']
            );

            $participantObj->setItemInfo(array('id' => $userID));

            $details = $participantObj->displayItemById();
            $data = array(
                'singleColData' => array(
                    'comment' => 'The above Library  record has been completed <BR></BR>','click-here-url' => 'Finalise this Issue: <BR/><BR/>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/add_gcuedit_comm.php?id=' . $this->commId . '">CLICK</a> Here to approve this record'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $dataC["reference"]
                    ),
                    'assignedto' => array(
                        'left' => '<strong>Assigned To:</strong>',
                        'right' => 'GHL Group'
                    ),
                    'from' => array(
                        'left' => '<strong>From</strong>',
                        'right' => ucwords($details['forename'] . ' ' . $details['surname'])
                    )
                )
            );


            $emailObj->appendInfo($data);

     //      $emailObj->sendEmail('A Library Entry has been Completed', $whoGLOC, array(), array(), 'me_completed', '', 'grey');
        
        
    //  $sql = sprintf("update   %s.comms_mangement set completed =3 where ID =%d ", _DB_OBJ_FULL, $this->commId);
$sql = sprintf("update   %s.comms_mangement set completed =5 where ID =%d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
      public function getAuditLibrary($bus=''){
         $sql=sprintf("select * from %s.comms_mangement where audit=1 and isnull(archive,0)=0", _DB_OBJ_FULL);
          $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();
            $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
            
return $results;
            
 }
     public function getNewAmendNo($ref) {

       $sql = sprintf("SELECT max(sub_ref) as max_ref FROM %s.comms_mangement WHERE reference = '%s' ", _DB_OBJ_FULL, $ref);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetch(PDO::FETCH_ASSOC);


        return ((int) $record["max_ref"]) + 1;
    }
	 public function updateCommSubRef($sub_ref,$record){
		$sql = sprintf("update %s.comms_mangement set sub_ref=%d WHERE ID = %d ", _DB_OBJ_FULL, $sub_ref,$record);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
			}
                        
	    public function getCompanies($id, $region = '') {
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $business_units=array();
      $sql = sprintf("SELECT * FROM %s.comms_mangement WHERE ID=%d  ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetch(PDO::FETCH_ASSOC);



        $busa = $orgObj->getCompanies();

        if ($region != '' && $region !=0) {
            $comp1 = explode(",", $record['company']);
            $comp2 = $locObj->getBufromCountries($region);
            $comp = array_intersect($comp1, $comp2);
        } else
            $comp = explode(",", $record['company']);
        

        foreach ($busa as $bu) {


            if (is_array($comp) && in_array($bu["buID"], $comp)) {
                $business_units .= "<option value='" . $bu["buID"] . "' >" . $bu["buName"] . "</option>";
            }
        }

        return $business_units;
    }	
      public function getCountries($id=0) {
$regions='';
             $sql = sprintf("select * from %s.locationgram L inner join %s.regions R on L.regionlink=R.ID where not regionlink =0", _DB_OBJ_FULL, _DB_OBJ_FULL);

    
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result= $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $bu) {

    $sel=$bu['regionlink'] == $id ? "selected" : "";


            $regions .= "<option value='" . $bu['regionlink'] . "' ".$sel.">" . $bu['name'] . "</option>";
        }

        return $regions;
    }
      public function getComments($id) {
      
     $sql = sprintf("SELECT * FROM %s.comms_comments C left join  %s.participant_database P on C.commentwho=P.participantID  WHERE libraryID=%d order by ID desc ", _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $record = $pStatement->fetchAll(PDO::FETCH_ASSOC);

if (count($record)== 0){
    $html="No comments";
} else {
   foreach($record as $row) {
       $d=strtotime($row["commentdate"]);
       $html.=$row["comments"]."<BR><BR>Entered on ".date("m/d/Y H:i",$d)." by ".$row["forename"]." ".$row["surname"]."<BR><BR>";
   }
}

        echo $html;
    }
          public function saveComments($id,$comments) {
      $commentwho= getLoggedInUserId();
    $sql = sprintf("insert into %s.comms_comments (libraryID,comments,commentwho) VALUES (%d,'%s',%d)", _DB_OBJ_FULL,  $id,$comments,$commentwho);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

       
    }
    
        public function sendInitialMail($doc) {
            $emailObj = new actionEmailHelper(0);
            $participantObj = SetupGeneric::useModule('Participant');
            $optionObj = new Option();

            $ghl= $optionObj->getOption('_SU_GROUP_EMAIL');
              
            $userID= getLoggedInUserId();

        
        $participantObj->setItemInfo(array('id' => $ghl));

        $details = $participantObj->displayItemById();
        
        $whoGLOC = array(
            'displayname' => 'GHL Group',
            'email' => $ghl,
            'ID' => $details['participantID']
        );
          
        $participantObj->setItemInfo(array('id' => $userID));

        $details = $participantObj->displayItemById();
        
            $data = array(
                'singleColData' => array(
                    'comment' => 'The above document is being added to the Library<BR>'
                    ,
                    'click-here-url' => '',
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $doc
                     ),
                    'assignedto' => array(
                        'left' => '<strong>Assigned To:</strong>',
                        'right' => 'GHL Group'
                    ),
                    'from' => array(
                        'left' => '<strong>From</strong>',
                        'right' => ucwords($details['forename'] . ' ' . $details['surname'])
                    )
                  
                )
            );


            $emailObj->appendInfo($data);

            $emailObj->sendEmail('A Libary Document is being added', $whoGLOC, array(), array(), 'me_completed', '', 'grey');

     
    }
        public function editGCUActions() {
            $participantObj = SetupGeneric::useModule('Participant');

                      $sql = sprintf("delete from %s.comms_gcuaction_link where alertID=%d"
                    , _DB_OBJ_FULL,$this->commId);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();
    

        for ($x = 0; $x < count($this->commInfo['who']); $x++) {
            $this->actionData = array('description' => $this->commInfo['action'][$x],
                'who' => $this->commInfo['who'][$x],
                'whoAU' => $this->commInfo['whoAU'][$x],
                'who2AU' => $this->commInfo['whoAU2'][$x],
                'module_name' => "ComplianceAlert",
                'record' => $this->commId,
                'status' => $this->commInfo['save_finish'],
                'buname' => 0,
                'element' => "compliance_GCUalert",
                'currentwho' => $this->commInfo['who'][$x],
                'due_date' => $this->commInfo['when'][$x]);

            if ($this->commInfo['actionID'] > 0) {
                $this->actionHandling->setActionDetails($this->commInfo['actionID'], $this->actionData);
                $this->actionHandling->updateAction();
                $this->actionHandling->updateActionDetail('moduleName', $this->commInfo['module']); //updates module name as may have been changed bythe user
                $new_action_id = $this->smartLawInfo['actionID'];
            } else {
                $this->actionHandling->setActionDetails(0, $this->actionData);
                $new_action_id = $this->actionHandling->addAction2015();
            }

            $action_id = $new_action_id;
            $this->actionHandling->updateStatus($action_id);



            
           $sql = sprintf("INSERT INTO %s.comms_GCUaction_link(alertID,actionID,company,region,alerttype,period) VALUES (%d,%d,%d,%d,'%s',%d) "
                    , _DB_OBJ_FULL
                    , $this->commId
                    , $action_id
                    , $this->commInfo['company'][$x]
                    , $this->commInfo['country'][$x]
                    , $this->commInfo['atype'][$x]
                    , $this->commInfo['period'][$x]);

            $stmt = $this->dbHand->prepare($sql);
            $stmt->execute();




                $emailObj = new actionEmailHelper($action_id);

                $who = $emailObj->getwhoDetails();
                $whoAU = $emailObj->getAUDetails();

                $dataC = $this->getActionsbyID($action_id);

                $sentence = array('sentence' => array("You have an action to carry out the following Library GCU Issue Action"));
                $emailObj->appendInfo($sentence);

                $data = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View GCU Library Action'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $dataC['uniqueReference']), 'description' => array('left' => '<strong>Description</strong>', 'right' => $dataC['descp'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Library GCU Issue Action has been Raised', $who, array(), array(), 'me_completed', '', 'grey');

                $data = array('singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View GCU Library Action<BR>that has been raised for the above'), 'twoColData' => array('actionid' => array('left' => '<strong>Reference</strong>', 'right' => $dataC['uniqueReference']), 'description' => array('left' => '<strong>Description</strong>', 'right' => $dataC['descp'])));

                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Library GCU Issue Action To Be Approved Once Complete', $whoAU, array(), array(), 'me_completed', '', 'grey');
            }
     

            
}
    public function displayId($p_id) {

       $sql = sprintf("SELECT M.*FROM %s.comms_mangement  M  where M.ID=%d", _DB_OBJ_FULL, $p_id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);


        return $result;
    }
    
          public function editGCUComm23() {
                        $ogrObj = SetupGeneric::useModule('Organigram');
        $region=new Region();
       $sql = sprintf("UPDATE %s.comms_mangement SET comments = '" . $this->commInfo['comments'] . "' WHERE ID = " . $this->commId, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //$this->removeGCUActions();
 
        if (count($this->commInfo['who']) > 0) {
            $actObj = new Action();

            foreach ($this->commInfo['who'] as $key=>$actions) {
                $actionData = array('description' => $this->commInfo['action'][$key],
                    'who' => $actions,
                    'whoAU' =>  $this->commInfo['whoAU'][$key],
                    'who2AU' => $this->commInfo['whoAU2'][$key],
                    'module_name' => "Communications",
                    'record' => $this->commId,
                    'status' => 1,
                    'buname' => 0,
                    'element' => "comms_mangement",
                    'currentwho' => $actions,
                    'due_date' => $this->commInfo['when'][$key]);
                $actObj->setActionDetails(0, $actionData);

                $lastId = $actObj->addAction2015();
          
                           $sql = sprintf("INSERT INTO %s.comms_gcuaction_link(alertID,actionID,company,region,alerttype,period) VALUES (%d,%d,%d,%d,'%s',%d) "
                        , _DB_OBJ_FULL
                        , $this->commId
                        , $lastId
                        , $this->commInfo['company'][$key]
                        , $this->commInfo['country'][$key]
                        , $this->commInfo['atype'][$key]
                        , $this->commInfo['period'][$key]);

                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();
                
       
               
  if ($this->commInfo['save'] == 1) {
      $periodArr=array(0 =>'-',1 =>'Monthly',2 =>'Bi- Monthly',3=>'Quarterly',4 =>'Semi-Annually',5 => 'Annually',6 => 'Bi - Annually',7 => 'Tri - Annually');

                $emailObj = new actionEmailHelper($lastId);
                $who = $emailObj->getwhoDetails();
                $whoAU = $emailObj->getAUDetails();
                
                $resultC =   $region->getItemsbyId($this->commInfo['country'][$key]);
                $country= $resultC ? $resultC['Country'] : '-';
                $ogrObj->setItemInfo(array('id'=>$this->commInfo['company'][$key]));   
                $resultCo =   $ogrObj->displayItemById();
                $company= $resultCo ? $resultCo['buName'] : '-';
                $period=$periodArr[(int)$this->commInfo['period'][$key]];
                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/report.php?id=' . $this->commId . '">CLICK</a> Here to View Library report'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Referenced</strong>',
                            'right' => $this->commInfo['reference']
                        )
                    )
                );

                                    $data = array(
                                        'singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/report.php?id=' . $this->commId . '">CLICK</a> Here to View Library report'.$url),
                        'twoColData' => array(
                            'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $this->commInfo['reference'])
                    ));
                $emailObj->appendInfo($data);

                $emailObj->sendEmail('A Library Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
       
                $data = array(
                                        'singleColData' => array('click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/commsmgr.php?filter_date=">CLICK</a> Here to View Library Action<BR>'),
                        'twoColData' => array(
                            'actionid' => array('left' => '<strong>Reference</strong>', 'right' => $this->commInfo['reference'])
                    ));
                $emailObj->appendInfo($data);
                $emailObj->sendEmail('A Library Action To Be Approved Once Complete', $whoAU, array(), array(), 'me_completed', '', 'grey');
            }

        }
        
    }

                 if ($this->commInfo['save'] == 1) {

      
                 $this->GCUfinish();
             }
             
    }
    
       public function GCUfinish() {
          $sql = sprintf("update   %s.comms_mangement set completed =5 where ID =%d ", _DB_OBJ_FULL, $this->commId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
		    public function getGCUActions($p_record_id) {
        $sql = sprintf("select A.*,L.company,L.region,L.alerttype,L.period from  %s.actions A inner join  %s.comms_gcuaction_link L on A.ID=L.actionID where alertID=%d and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }
    
         public function getOutstandingGCUActions() {
      $sql = sprintf("select L.alertID from  %s.actions A inner join  %s.comms_gcuaction_link L on A.ID=L.actionID where status=1 and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }
    
     public function getOutstandingActions() {
      $sql = sprintf("select L.commID from  %s.actions A inner join  %s.comms_action_link L on A.ID=L.actionID where status=1 and approveAU=0", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_record_id);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }
}
?>
