<?php

/**
  $Id: Action.class.php,v 3.84 Saturday, January 29, 2011 5:04:35 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Thursday, October 07, 2010 12:46:05 PM>
 */
class Action {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Action Id
     * @access private
     */
    private $actionId;

    /**
     * Property to hold Action details
     * @access private
     */
    private $actionDetails;

    /**
     * Constructor for initializing Action object
     * @access public
     */
    public function __construct() {
        $this->dbHand = DB::connect(_DB_TYPE);
    }

    public function setActionDetails($p_actionId, $p_actionDetails) {
        $this->actionId = $p_actionId;
        $this->actionDetails = $p_actionDetails;
    }

    /**
     * This method is used to add action
     * module_name,description,who,due_date
     *
     */
    public function addAction() {

        $sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('%s','%s',%d,%d,'%s',0,0,0,0)", _DB_OBJ_FULL, $this->actionDetails['module_name'], $this->actionDetails['description'], $this->actionDetails['who'], $this->actionDetails['whoAU'], format_date_for_mysql($this->actionDetails['due_date']));

        $pStatement = $this->dbHand->prepare($sql);

        if ($pStatement->execute()) {

            $lastId = customLastInsertId($this->dbHand, 'actions', 'ID');
            //$lastId = $this->dbHand->lastInsertId();

            return $lastId;
        } else {
            /* dump_array($pStatement->errorInfo());
              exit; */
        }
    }

    public function updateMainRef($ref) {

        $this->archiveAction();
        $this->ref = $ref;
        /* echo $sql = "UPDATE actions SET actionDescription = ".$this->actionDetails['description'].",
          who = ".$this->actionDetails['who'].",
          dueDate = ".format_date_for_mysql($this->actionDetails['due_date'])."
          WHERE ID = $this->actionId"; */
        $sql = sprintf("UPDATE %s.actionHistory SET thirdParty = " . $this->ref . " WHERE ID = %d", _DB_OBJ_FULL, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    // ADDING FINESSE TO UPDATING ACTIONS, CHAINABLE EXTENSIBLE FUNCTION
    public function updateActionDetail($field, $value, $archive = true) {
        //if($archive) { $this->archiveAction(); } // Preserve History
        $value = is_numeric($value) ? $value : "'$value'"; // quote all non-numeric values
        $sql = sprintf("UPDATE %s.actions SET %s = %s WHERE ID = %d", _DB_OBJ_FULL, $field, $value, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        return $this;
    }

    public function updateAction() {

        $this->archiveAction();

        /* echo $sql = "UPDATE actions SET actionDescription = ".$this->actionDetails['description'].",
          who = ".$this->actionDetails['who'].",
          dueDate = ".format_date_for_mysql($this->actionDetails['due_date'])."
          WHERE ID = $this->actionId"; */
        $sql = sprintf("UPDATE %s.actions SET 
										actionDescription = '%s',
										who = %d,
										whoAU =%d,
										dueDate = '%s'
										
										
									WHERE ID = %d", _DB_OBJ_FULL, $this->actionDetails['description'], $this->actionDetails['who'], $this->actionDetails['whoAU'], format_date_for_mysql($this->actionDetails['due_date']), $this->actionId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function updateActionDataHistory() {

        //$this->archiveAction();


        $sql_ins = sprintf("INSERT INTO %s.actionHistoryx (ID
						,moduleName
						,actionDescription
						,who
						,dueDate
						,doneDate
						,doneDescription
						,approve
						,outstanding
						,status
						,whoAU
						,approveAU)
						SELECT ID,moduleName,actionDescription,who,dueDate,doneDate,doneDescription,approve,outstanding,status,whoAU,approveAU FROM %s.actions WHERE ID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql_ins);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();
    }

    public function editAction() {

        $sql_check = sprintf("SELECT * FROM %s.actions WHERE ID = %d", _DB_OBJ_FULL, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql_check);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($this->actionDetails['description'] != $result['actionDescription'] && $this->actionDetails['who'] != $result['who']) {
            $this->actionDetails['module_name'] = $result['moduleName'];
            $returnId = $this->addAction();
        } else {
            $this->updateAction();
            $returnId = 0;
        }
        //dump_array($this);

        return $returnId;
    }

    private function archiveAction() {

        $sql_ins = sprintf("INSERT INTO %s.actions_archive (ID
						,moduleName
						,actionDescription
						,who
						,dueDate
						,doneDate
						,doneDescription
						,approve
						,outstanding
						,status
						,whoAU
						,approveAU)
						SELECT * FROM %s.actions WHERE ID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql_ins);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();
    }

    public function getActionLinkedTo($record, $moduleElement) {
        $sql_check = sprintf("SELECT * FROM %s.actions WHERE record = %d AND moduleElement = '%s'", _DB_OBJ_FULL, $record, $moduleElement);

        $pStatement = $this->dbHand->prepare($sql_check);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewAction() {
        $sql_check = sprintf("SELECT * FROM %s.actions WHERE ID = %d", _DB_OBJ_FULL, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql_check);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewAction3($id) {
        $this->id = $id;
        $sql_check = sprintf("SELECT * FROM %s.actions WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql_check);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function deleteAction() {

        $sql_delete = sprintf("DELETE FROM %s.actions WHERE ID = %d", _DB_OBJ_FULL, $this->actionId);

        $pStatement = $this->dbHand->prepare($sql_delete);
        //$pStatement->bindParam(1,$this->actionId);
        $pStatement->execute();

        //dump_array($this);
    }

    public function viewAllAction() {
        $sql_check = sprintf("SELECT * FROM %s.actions WHERE outstanding = '0' AND status = '1'", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql_check);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewAllActionUnapproved() {
        $sql_check = sprintf("SELECT * FROM %s.actions WHERE outstanding != 2 AND status = '1' AND approveAU = 0", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql_check);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewAllActionByModule($p_module_name, $p_outstanding = true, $p_filter_date = '') {

        if ($p_module_name == 'smartlaw')
            $p_module_name = 'smartlaw%';

        if ($p_filter_date != '') {
            $date_filter = " AND dueDate <= '" . $p_filter_date . "'";
        }

        if ($p_outstanding) {
            $sql_check = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE '%s' AND outstanding = '1' AND status = '1' ORDER BY ID ASC", _DB_OBJ_FULL, $p_module_name);
        } else {
            $sql_check = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE '%s' AND status = '1' " . $date_filter . " ORDER BY ID ASC", _DB_OBJ_FULL, $p_module_name);
        }

        $pStatement = $this->dbHand->prepare($sql_check);
        //$pStatement->bindParam(1,$p_module_name);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewOverdueActions($p_module_name) {

        $sql_check = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE '%s' AND outstanding = '3' AND status = '1' ORDER BY ID ASC", _DB_OBJ_FULL, $p_module_name);

        //echo $sql_check;

        $pStatement = $this->dbHand->prepare($sql_check);
        //$pStatement->bindParam(1,$p_module_name);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewOverdueActionsSiteWide() {

        $sql_check = "Exec ? = GetOverdueActionsSiteWide 251";
        $pStatement = $this->dbHand->prepare($sql_check);
        $pStatement->bindParam(1, $retval, PDO::PARAM_INT);
        $pStatement->execute();

        return $result;
    }

    public function viewOutstandingActionsSiteWide() {
        
    }

    public function updateStatus($p_action_id) {
$this->updatehistory( $p_action_id);
        $sql = sprintf("UPDATE %s.actions SET status = '1',last_action='In Progress',timechanged=getdate() WHERE ID = %d", _DB_OBJ_FULL, $p_action_id);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$p_action_id);
        $pStatement->execute();
        return true;
    }

        public function updateArchiveStatus($p_action_id) {
$this->updatehistory( $p_action_id);
//status & ~2 to turn off
       $sql = sprintf("UPDATE %s.actions SET status = status | 2,last_action='Archived',timechanged=getdate() WHERE ID = %d", _DB_OBJ_FULL, $p_action_id);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$p_action_id);
        $pStatement->execute();
        return true;
    }
            public function updateRestoreStatus($p_action_id) {
$this->updatehistory( $p_action_id);
//status & ~2 to turn off
       $sql = sprintf("UPDATE %s.actions SET status = status & ~2,last_action='Restored',timechanged=getdate() WHERE ID = %d", _DB_OBJ_FULL, $p_action_id);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$p_action_id);
        $pStatement->execute();
        return true;
    }
    public function confirmRecord($p_action_id) {

        $sql = sprintf("UPDATE %s.actions SET donedate='" . date(Y - m - d) . "',doneDescription='Confirm action completed',approveAU=1 WHERE ID = %d", _DB_OBJ_FULL, $p_action_id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        return true;
    }

    public function insertRequestRecord($p_action_id, $p_record, $p_module) {

        $sql = sprintf("insert into %s.action_request (aid,fromid,fromtable) VALUES (%d,%d,'%s') ", _DB_OBJ_FULL, $p_action_id, $p_record, $p_module);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        return true;
    }

    public function getActionForDashBoard($p_module) {

        $sql = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE '%s' AND status = '1' AND outstanding = '0' ORDER BY ID ASC", _DB_OBJ_FULL, $p_module);

        //echo $sql;

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewCronByModule($p_module_name) {

        $sql_check = sprintf("SELECT * FROM %s.actions WHERE moduleName LIKE '%s' AND outstanding != '1' AND status = '1' AND approveAU = '0'
							 AND (doneDate IS NULL OR doneDate = '1900-01-01') ORDER BY ID ASC", _DB_OBJ_FULL, $p_module_name);

        $pStatement = $this->dbHand->prepare($sql_check);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewActionSelectDetail($Id) {

        $this->id = $Id;

        $sql_check = sprintf("SELECT * FROM %s.actions WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql_check);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewIncidenceSelectDetail($Id) {

        $this->id = $Id;

        $sql3 = sprintf("SELECT reference,buID,actionsID,problemDescription FROM %s.incidence", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql3);

        $pStatement->execute();

        $res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $res_1;
    }

    public function viewNhpSelectDetail($Id) {

        $this->id = $Id;

        $sql3 = sprintf("SELECT reference,businessUnitID,actionsID,problemDescription FROM %s.nhp", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql3);

        $pStatement->execute();

        $res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $res_1;
    }

    public function viewInvestigationSelectDetail($Id) {

        $this->id = $Id;

        $sql3 = sprintf("SELECT C.*,N.ID,buID,problemDescription FROM %s.investigation C
												INNER JOIN %s.incidence N
											ON N.ID = C.incID", _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql3);

        $pStatement->execute();

        $res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $res_1;
    }

    public function viewRiskSelectDetail($Id) {

        $this->id = $Id;

        $sql3 = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.ID =" . $this->id, _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql3);

        $pStatement->execute();

        $res_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $res_1;
    }

    public function viewRisk27kSelectDetail($Id) {

        $this->id = $Id;

        $sql3 = sprintf("SELECT * FROM %s.risk27k WHERE improvements LIKE '" . $this->id . "'", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql3);

        $pStatement->execute();

        $res_1 = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $res_1;
    }

    public function viewInvestigationNhpSelectDetail($Id) {

        $this->id = $Id;

        $sql3 = sprintf("SELECT C.*,N.ID,businessUnitID,problemDescription FROM %s.nhc_investigation C
												INNER JOIN %s.nhp N
											ON N.ID = C.incID", _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql3);

        $pStatement->execute();

        $res_1 = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $res_1;
    }

    public function setThirdParty($id) {
        $this->id = $id;
        $sql = "UPDATE %s.actions
                SET thirdParty = %d
                WHERE ID = %d";
        $pStatement = $dbHand->prepare(sprintf($sql, _DB_OBJ_FULL, $this->id, $this->actionId));
        $pStatement->execute();

        return $this;
    }

//adds with date in Y-m-d format Bob
    public function addAction2() {

        $sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('%s','%s',%d,%d,'%s',0,0,0,0)", _DB_OBJ_FULL, $this->actionDetails['module_name'], $this->actionDetails['description'], $this->actionDetails['who'], $this->actionDetails['whoAU'], $this->actionDetails['due_date']);

        $pStatement = $this->dbHand->prepare($sql);

        if ($pStatement->execute()) {

            $lastId = customLastInsertId($this->dbHand, 'actions', 'ID');
            //$lastId = $this->dbHand->lastInsertId();

            return $lastId;
        } else {

            /* dump_array($pStatement->errorInfo());
              exit; */
        }
    }

    public function addAction2015() {
        $userID = getLoggedInUserId();
    $sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU,currentWho,addapprover,record,moduleelement,origin,last_action,updater)
			VALUES ('%s','%s',%d,%d,'%s',0,0,%d,0,%d,%d,%d,'%s',%d,'Add Action',%d)", _DB_OBJ_FULL, $this->actionDetails['module_name'], $this->actionDetails['description'], $this->actionDetails['who'], $this->actionDetails['whoAU'], format_date_for_mysql($this->actionDetails['due_date']), $this->actionDetails['status'], $this->actionDetails['who'], $this->actionDetails['who2AU'], $this->actionDetails['record'], $this->actionDetails['element'], $userID, $userID);

        $pStatement = $this->dbHand->prepare($sql);

        if ($pStatement->execute()) {

            $lastId = customLastInsertId($this->dbHand, 'actions', 'ID');


            return $lastId;
        } else {
            /* dump_array($pStatement->errorInfo());
              exit; */
        }
     
    }

    public function updateActionRecord($p_Id, $recordid, $element) {
        $this->updatehistory($p_Id);
        $sql = sprintf("update %s.actions set record=%d,moduleelement='%s' where id=%d", _DB_OBJ_FULL, $recordid, $element, $p_Id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    public function updateAction2015() {
        $this->updatehistory($this->actionId);
        $updater= getLoggedInUserId();
     $sql = sprintf("UPDATE %s.actions SET 
										actionDescription = '%s',
										who = %d,
										whoAU =%d,
                                                                                last_action='Edit Action',
                                                                                timechanged=getdate(),
                                                                                addapprover =%d,
                                                                                updater =%d,
										dueDate = '%s'
										
										
									WHERE ID = %d", _DB_OBJ_FULL, $this->actionDetails['description'], $this->actionDetails['who'], $this->actionDetails['whoAU'], $this->actionDetails['who2AU'],$updater, format_date_for_mysql($this->actionDetails['due_date']), $this->actionId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getActionCountTotal() {
        return $this->getActionCount("admin");
    }

    
    public function getActionCount($type = 'none') {

        if ($type == 'admin') {
            $sql = sprintf("select count(moduleName)as total,moduleName from %s.actions where approveAU=0 and status=1  group by moduleName", _DB_OBJ_FULL);
            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
            $datacount = $pStatement->fetchAll(PDO::FETCH_ASSOC);

            $sql = sprintf("select count(moduleName)as total,moduleName from %s.actions where approveAU=0  and status=1 and duedate < '%s' group by moduleName", _DB_OBJ_FULL, date('Y-m-d'));
            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
            $dataredcount = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $sql = sprintf("select count(moduleName)as total,moduleName from %s.actions where approveAU=0 and status=1 and currentWho=%d group by moduleName", _DB_OBJ_FULL, getLoggedInUserId());
            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
            $datacount = $pStatement->fetchAll(PDO::FETCH_ASSOC);

            $sql = sprintf("select count(moduleName)as total,moduleName from %s.actions where approveAU=0 and status=1 and currentWho=%d and duedate < '%s' group by moduleName", _DB_OBJ_FULL, getLoggedInUserId(), date('Y-m-d'));
            $pStatement = $this->dbHand->prepare($sql);

            $pStatement->execute();
            $dataredcount = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        }
//dump_array($datacount);exit();
        foreach ($datacount as $data) {
            switch ($data["moduleName"]) {
                case 'ICR_Action' :
                    $countera["preventive"] += $data["total"];
                    $countera["management"] += $data["total"];
                    $countera["icr"] = $data["total"];
                    break;
                                case 'ISA_action' :
                    $countera["preventive"] += $data["total"];
                    $countera["management"] += $data["total"];
                    $countera["isa"] = $data["total"];
                    break;
                case 'incidence' :
                    case 'Incidence' :
                    $countera["corrective"] += $data["total"];
                    $countera["incidence"] = $data["total"];
                    break;
                case 'nhp' :
                case 'NHP' :
                    $countera["corrective"] += $data["total"];
                    $countera["nhp"] = $data["total"];
                    break;
                case 'investigation' :
                case 'Investigation' :
                    $countera["corrective"] += $data["total"];
                    $countera["investigation"] = $data["total"];
                    break;
                case 'nhcInvestigation' :
                case 'nhcinvestigation' :
                    $countera["corrective"] += $data["total"];
                    $countera["nhcinvestigation"] = $data["total"];
                    break;
//managment
                case 'contract' :
				if (_ALLOW_CONTRACTS == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["management"] += $data["total"];
                    $countera["contract"] = $data["total"];
				}
                    break;
                case 'msr_reviews' :
                    $countera["preventive"] += $data["total"];
                    $countera["management"] += $data["total"];
                    $countera["msr_reviews"] = $data["total"];
                    break;
                case 'msr_action' :
                    $countera["preventive"] += $data["total"];
                    $countera["management"] += $data["total"];
                    $countera["msr_action"] = $data["total"];
                    break;
                //operation               
                case 'risk' :
				if (_ALLOW_RISK == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["operation"] += $data["total"];
                    $countera["risk"] = $data["total"];
				}
                    break;
                case 'PF' :
                    $countera["preventive"] += $data["total"];
                    $countera["operation"] += $data["total"];
                    $countera["pfs"] = $data["total"];
                    break;
                case 'risk27K' :
                case 'risk27k' :
				if (_ALLOW_RISK27K == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["operation"] += $data["total"];
                    $countera["risk27k"] = $data["total"];
				}
                    break;
                case 'SOA' :
				if (_ALLOW_SOA == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["operation"] += $data["total"];
                    $countera["SOA"] = $data["total"];
				}
                    break;
                case 'PCI' :
				if (_ALLOW_PCI == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["operation"] += $data["total"];
                    $countera["PCI"] = $data["total"];
				}
                    break;
                case 'RTA' :
				if (_ALLOW_RTA == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["operation"] += $data["total"];
                    $countera["rta"] = $data["total"];
				}
                    break;
                //functions               
                case 'inspectionC' :
                    $countera["preventive"] += $data["total"];
                    $countera["functions"] += $data["total"];
                    $countera["inspectionc"] = $data["total"];
                    break;
                case 'inspectionH' :
                    $countera["preventive"] += $data["total"];
                    $countera["functions"] += $data["total"];
                    $countera["inspectionh"] = $data["total"];
                    break;
                case 'inspectionR' :
                    $countera["preventive"] += $data["total"];
                    $countera["functions"] += $data["total"];
                    $countera["inspectionr"] = $data["total"];
                    break;
                case 'inspectionN' :
                    $countera["preventive"] += $data["total"];
                    $countera["functions"] += $data["total"];
                    $countera["inspectionn"] = $data["total"];
                    break;
                case 'InspectionDue' :
                    $countera["preventive"] += $data["total"];
                    $countera["functions"] += $data["total"];
                    $countera["inspectiond"] = $data["total"];
                    break;
                //Legislation            
                case 'smartlawT' :
                case 'SmartlawT' :
				if (_ALLOW_LAW == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["law"] += $data["total"];
                    $countera["Smartlaw"] += $data["total"];
				}
                    break;
                case 'smartlawD' :
                case 'SmartlawD' :
				if (_ALLOW_LAW == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["law"] += $data["total"];
                    $countera["Smartlaw"] += $data["total"];
				}
                    break;
                case 'smartlawR' :
                case 'SmartlawR' :
				if (_ALLOW_LAW == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["law"] += $data["total"];
                    $countera["Smartlaw"] += $data["total"];
				}
                    break;
                case 'smartlawI' :
                case 'SmartlawI' :
				if (_ALLOW_LAW == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["law"] += $data["total"];
                    $countera["Smartlaw"] += $data["total"];
				}
                    break;
                case 'smartlawC' :
                case 'SmartlawC' :
				if (_ALLOW_LAW == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["law"] += $data["total"];
                    $countera["Smartlaw"] += $data["total"];
				}
                    break;
                case 'smartlawreview' :
				if (_ALLOW_LAW == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["law"] += $data["total"];
                    $countera["Smartlawreview"] = $data["total"];
				}
                    break;
                //Modules
                case 'bia' :
                case 'BIA' :
				if (_ALLOW_BCP == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["bia"] = $data["total"];
				}
                    break;
                case 'bcp' :
                case 'BCP' :
				if (_ALLOW_BCP == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["bcp"] = $data["total"];
				}
                    break;
                case 'Context' :
				if (_ALLOW_CONTEXT_ANALYSIS == 1) { 
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["context"] = $data["total"];
				}
                    break;
                case 'Communications' :
				if (_ALLOW_COMMS_MGR == 1) {
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["communications"] = $data["total"];
				}
                    break;
//Training to be added
                case 'DSE' :
				if (_ALLOW_DSE == 1 ){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["dse"] = $data["total"];
				}
                    break;


                case 'EquipmentM' :
				if(_ALLOW_ASSET == 1) {
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["equipm"] = $data["total"];
				}
                    break;
                case 'EquipmentC' :
				if(_ALLOW_ASSET == 1) {
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["equipc"] = $data["total"];
				}
                    break;
                case 'template' :
				if(_ALLOW_COMPLIANCE == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["template"] = $data["total"];
				}
                    break;
                case 'ComplianceAlert' :
				if(_ALLOW_COMPLIANCE == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["cpa"] = $data["total"];
				}
                    break;
                case 'vehicleDocument' :
                    if(_ALLOW_FLEET == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["fdocuments"] = $data["total"];
                    }
                    break;
                case 'vehicleService' :
                    if(_ALLOW_FLEET == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["fservices"] = $data["total"];
                    }
                    break;
                case 'vehicleInspection' :
                    if(_ALLOW_FLEET == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["finspections"] = $data["total"];
                    }
                    break;
                case 'gov_action' :
                    if(_ALLOW_GOV == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["gov"] = $data["total"];
                    }
                    break;
                case 'gov1_action' :
                    if(_ALLOW_GOV == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["gov1"] = $data["total"];
                    }
                    break;
                case 'gov2_action' :
                    if(_ALLOW_GOV == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["gov2"] = $data["total"];
                    }
                    break;
                case 'manual_handlingI' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["manual_handling"] += $data["total"];
                    $countera["manual_handlingI"] = $data["total"];
                    }
                    break;
                case 'manual_handlingE' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["manual_handling"] += $data["total"];
                    $countera["manual_handlingE"] = $data["total"];
                    }
                    break;
                case 'manual_handlingT' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["manual_handling"] += $data["total"];
                    $countera["manual_handlingT"] = $data["total"];
                    }
                    break;
                case 'manual_handlingL' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $countera["preventive"] += $data["total"];
                    $countera["modules"] += $data["total"];
                    $countera["manual_handling"] += $data["total"];
                    $countera["manual_handlingL"] = $data["total"];
                    }
                    break;
            }
        }

        $docObj = new Documents();
        $contribObj = new DocumentContributor();
        $docreviewObj = new DocumentReview();
        //
        //documents
        //contributors

        $documents = $contribObj->viewAssignedDocuments($filter_date);
        $documentsCount = count($documents);


        //   $sql = sprintf(" select count(*) as contrcount from %s.cms_documents_contributors where passed=0 and authParticipantID=%d", _DB_OBJ_FULL, getLoggedInUserId());
        //   $pStatement = $this->dbHand->prepare($sql);
        //   $pStatement->execute();
        //  $datacount = $pStatement->fetch(PDO::FETCH_ASSOC);

        $countera["preventive"] += $documentsCount;
        $countera["management"] += $documentsCount;
        $countera["contributor"] = $documentsCount;

        //alerts 
$documents = $docObj->getDocAlerts();
$documentsCount = count($documents);
        /*
          $docObj = new Documents();
          $documents = $docObj->getDocAlerts();
          $datacount["docacount"] = count($documents);
         */
        $countera["preventive"] += $documentsCount;
        $countera["management"] += $documentsCount;
        $countera["docAlert"] = $documentsCount;

        //doc control

        $documents = $docObj->getDocumentListActionTracker();

        if (is_array($documents)){
        foreach($documents as $doc){
        $docs += count($doc);
        }
        } else {
     $docs=0;
 
 }
        $countera["preventive"] += $docs;
        $countera["management"] += $docs;
        $countera["document"] = $docs;

                //doc reviews

        $docreview = $docreviewObj->getDocumentListActionTracker();

        
        $countera["preventive"] += $docreview;
        $countera["management"] += $docreview;
        $countera["documentreview"] = $docreview;
        
        //gap filling
        $gapObj = new ReviewGap();
        $result = $gapObj->getGapQuestionActionTracker(true, 0);
        $datacount = count($result);
        $result = $gapObj->getGapQuestionActionTracker(false, 0);
        $datacount += count($result);
        $countera["preventive"] += $datacount;
        $countera["management"] += $datacount;
        $countera["gap_fillings"] = $datacount;


        //dump_array($countera);
        //overdue


        foreach ($dataredcount as $data) {
            switch ($data["moduleName"]) {
                case 'ICR_Action' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["management"] += $data["total"];
                    $counterb["icr"] = $data["total"];
                    break;
                 case 'ISA_Action' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["management"] += $data["total"];
                    $counterb["isa"] = $data["total"];
                    break;
                case 'incidence' :
                    $counterb["corrective"] += $data["total"];
                    $counterb["incidence"] = $data["total"];
                    break;
                case 'nhp' :
                case 'NHP' :
                    $counterb["corrective"] += $data["total"];
                    $counterb["nhp"] = $data["total"];
                    break;
                case 'Investigation' :
                case 'investigation' :
                    $counterb["corrective"] += $data["total"];
                    $counterb["investigation"] = $data["total"];
                    break;
                case 'nhcInvestigation' :
                case 'nhcinvestigation' :
                    $counterb["corrective"] += $data["total"];
                    $counterb["nhcinvestigation"] = $data["total"];
                    break;
//managment
                case 'contract' :
				if (_ALLOW_CONTRACTS == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["management"] += $data["total"];
                    $counterb["contract"] = $data["total"];
				}
                    break;
                case 'msr_reviews' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["management"] += $data["total"];
                    $counterb["msr_reviews"] = $data["total"];
                    break;
                case 'msr_action' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["management"] += $data["total"];
                    $counterb["msr_action"] = $data["total"];
                    break;
                //operation               
                case 'risk' :
				if (_ALLOW_RISK == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["operation"] += $data["total"];
                    $counterb["risk"] = $data["total"];
				}
                    break;
                case 'PF' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["operation"] += $data["total"];
                    $counterb["pfs"] = $data["total"];
                    break;
                case 'risk27K' :
                case 'risk27k' :
					if (_ALLOW_RISK27K == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["operation"] += $data["total"];
                    $counterb["risk27k"] = $data["total"];
					}
                    break;
                case 'SOA' :
					if (_ALLOW_SOA == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["operation"] += $data["total"];
                    $counterb["SOA"] = $data["total"];
					}
                    break;
                case 'PCI' :
					if (_ALLOW_PCI == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["operation"] += $data["total"];
                    $counterb["PCI"] = $data["total"];
					}
                    break;
                case 'RTA' :
					if (_ALLOW_RTA == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["operation"] += $data["total"];
                    $counterb["rta"] = $data["total"];
					}
                    break;
                //functions               
                case 'inspectionC' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["functions"] += $data["total"];
                    $counterb["inspectionc"] = $data["total"];
                    break;
                case 'inspectionH' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["functions"] += $data["total"];
                    $counterb["inspectionh"] = $data["total"];
                    break;
                case 'inspectionR' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["functions"] += $data["total"];
                    $counterb["inspectionr"] = $data["total"];
                    break;
                case 'inspectionN' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["functions"] += $data["total"];
                    $counterb["inspectionn"] = $data["total"];
                    break;
                case 'InspectionDue' :
                    $counterb["preventive"] += $data["total"];
                    $counterb["functions"] += $data["total"];
                    $counterb["inspectiond"] = $data["total"];
                    break;
                //Legislation            
                case 'smartlawT' :
                case 'SmartlawT' :
				if (_ALLOW_LAW == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["law"] += $data["total"];
                    $counterb["Smartlaw"] += $data["total"];
				}
                    break;
                case 'smartlawD' :
                case 'SmartlawD' :
					if (_ALLOW_LAW == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["law"] += $data["total"];
                    $counterb["Smartlaw"] += $data["total"];
					}
                    break;
                case 'smartlawR' :
                case 'SmartlawR' :
					if (_ALLOW_LAW == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["law"] += $data["total"];
                    $counterb["Smartlaw"] += $data["total"];
					}
                    break;
                case 'smartlawI' :
                case 'SmartlawI' :
					if (_ALLOW_LAW == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["law"] += $data["total"];
                    $counterb["Smartlaw"] += $data["total"];
					}
                    break;
                case 'smartlawC' :
                case 'SmartlawC' :
					if (_ALLOW_LAW == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["law"] += $data["total"];
                    $counterb["Smartlaw"] += $data["total"];
					}
                    break;
                case 'smartlawreview' :
					if (_ALLOW_LAW == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["law"] += $data["total"];
                    $counterb["Smartlawreview"] = $data["total"];
					}
                    break;
                //Modules
                case 'bia' :
                    case 'BIA' :
				if (_ALLOW_BCP == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["bia"] = $data["total"];
				}
                    break;
                case 'bcp' :
                    case 'BCP' :
				if (_ALLOW_BCP == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["bcp"] = $data["total"];
				}
                    break;
                case 'Context' :
				if (_ALLOW_CONTEXT_ANALYSIS == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["context"] = $data["total"];
				}
                    break;
                case 'Communications' :
				if (_ALLOW_COMMS_MGR == 1) {
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["communications"] = $data["total"];
				}
                    break;
//Training to be added
                case 'DSE' :
				if (_ALLOW_DSE == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["dse"] = $data["total"];
				}
                    break;


                case 'EquipmentM' :
				 if (_ALLOW_ASSET == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["equipm"] = $data["total"];
				 }
                    break;
                case 'EquipmentC' :
				 if (_ALLOW_ASSET == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["equipc"] = $data["total"];
				 }
                    break;
                case 'template' :
				if (_ALLOW_COMPLIANCE == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["template"] = $data["total"];
				}
                    break;
                case 'ComplianceAlert' :
				if (_ALLOW_COMPLIANCE == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["cpa"] = $data["total"];
				}
                    break;
                case 'vehicleDocument' :
                    if(_ALLOW_FLEET == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["fdocuments"] = $data["total"];
                    }
                    break;
                case 'vehicleService' :
                    if(_ALLOW_FLEET == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["fservices"] = $data["total"];
                    }
                    break;
                case 'vehicleInspection' :
                    if(_ALLOW_FLEET == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["finspections"] = $data["total"];
                    }
                    break;
                case 'gov_action' :
                    if(_ALLOW_GOV == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["gov"] = $data["total"];
                    }
                    break;
                case 'gov1_action' :
                    if(_ALLOW_GOV == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["gov1"] = $data["total"];
                    }
                    break;
                case 'gov2_action' :
                    if(_ALLOW_GOV == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["gov2"] = $data["total"];
                    }
                    break;
                case 'manual_handlingI' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["manual_handling"] += $data["total"];
                    $counterb["manual_handlingI"] = $data["total"];
                    }
                    break;
                case 'manual_handlingE' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["manual_handling"] += $data["total"];
                    $counterb["manual_handlingE"] = $data["total"];
                    }
                    break;
                case 'manual_handlingT' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["manual_handling"] += $data["total"];
                    $counterb["manual_handlingT"] = $data["total"];
                    }
                    break;
                case 'manual_handlingL' :
                    if(_ALLOW_MANUAL_HANDLING == 1){
                    $counterb["preventive"] += $data["total"];
                    $counterb["modules"] += $data["total"];
                    $counterb["manual_handling"] += $data["total"];
                    $counterb["manual_handlingL"] = $data["total"];
                    }
                    break;
            }
        }

        $docCount = $contribObj->getCountOverdueDocuments();

        $counterb["preventive"] += $docCount;
        $counterb["management"] += $docCount;
        $counterb["contributor"] = $docCount;

        //   $sql = sprintf(" select count(*) as contrcount from %s.cms_documents_contributors where passed=0 and authParticipantID=%d", _DB_OBJ_FULL, getLoggedInUserId());
        //   $pStatement = $this->dbHand->prepare($sql);
        //   $pStatement->execute();
        //  $datacount = $pStatement->fetch(PDO::FETCH_ASSOC);

        if ($countera["corrective"] == 0) {
            $counter["corrective"] = 0;
            $counter["correctiveCnt"] = 0;
        } else {
            $counter["correctiveCnt"] = 1;
            if ($counterb["corrective"] == 0)
                $counter["corrective"] = "<span style='color:green'>" . $countera["corrective"] . "</SPAN>";
            else
                $counter["corrective"] = "<span style='color:red'>" . $counterb["corrective"] . "</SPAN> / <span style='color:green'>" . $countera["corrective"] . "</SPAN>";
        }
        if ($countera["document"] == 0) {
            $counter["documentCnt"] = 0;
            $counter["document"] = 0;
        } else {
            $counter["documentCnt"] = 1;
            if ($counterb["document"] == 0)
                $counter["document"] = "<span style='color:green'>" . $countera["document"] . "</SPAN>";
            else
                $counter["document"] = "<span style='color:red'>" . $counterb["document"] . "</SPAN> / <span style='color:green'>" . $countera["document"] . "</SPAN>";
        }

        if ($countera["docAlert"] == 0) {
            $counter["docAlertCnt"] = 0;
            $counter["docAlert"] = 0;
        } else {
            $counter["docAlertCnt"] = 1;
            if ($counterb["docAlert"] == 0)
                $counter["docAlert"] = "<span style='color:green'>" . $countera["docAlert"] . "</SPAN>";
            else
                $counter["docAlert"] = "<span style='color:red'>" . $counterb["docAlert"] . "</SPAN> / <span style='color:green'>" . $countera["docAlert"] . "</SPAN>";
        }

        if ($countera["functions"] == 0) {
            $counter["functionsCnt"] = 0;
            $counter["functions"] = 0;
        } else {
            $counter["functionsCnt"] = 1;
            if ($counterb["functions"] == 0)
                $counter["functions"] = "<span style='color:green'>" . $countera["functions"] . "</SPAN>";
            else
                $counter["functions"] = "<span style='color:red'>" . $counterb["functions"] . "</SPAN> / <span style='color:green'>" . $countera["functions"] . "</SPAN>";
        }

        if ($countera["gap_fillings"] == 0) {
            $counter["gap_fillingsCnt"] = 0;
            $counter["gap_fillings"] = 0;
        } else {
            $counter["gap_fillingsCnt"] = 1;
            if ($counterb["gap_fillings"] == 0)
                $counter["gap_fillings"] = "<span style='color:green'>" . $countera["gap_fillings"] . "</SPAN>";
            else
                $counter["gap_fillings"] = "<span style='color:red'>" . $counterb["gap_fillings"] . "</SPAN> / <span style='color:green'>" . $countera["gap_fillings"] . "</SPAN>";
        }

                if ($countera["icr"] == 0) {
            $counter["icrCnt"] = 0;
            $counter["icr"] = 0;
        } else {
            $counter["icrCnt"] = 1;
            if ($counterb["icr"] == 0)
                $counter["icr"] = "<span style='color:green'>" . $countera["icr"] . "</SPAN>";
            else
                $counter["icr"] = "<span style='color:red'>" . $counterb["icr"] . "</SPAN> / <span style='color:green'>" . $countera["icr"] . "</SPAN>";
        }
                        if ($countera["isa"] == 0) {
            $counter["isaCnt"] = 0;
            $counter["isa"] = 0;
        } else {
            $counter["isaCnt"] = 1;
            if ($counterb["isa"] == 0)
                $counter["isa"] = "<span style='color:green'>" . $countera["isa"] . "</SPAN>";
            else
                $counter["isa"] = "<span style='color:red'>" . $counterb["isa"] . "</SPAN> / <span style='color:green'>" . $countera["isa"] . "</SPAN>";
        }
        if ($countera["incidence"] == 0) {
            $counter["incidenceCnt"] = 0;
            $counter["incidence"] = 0;
        } else {
            $counter["incidenceCnt"] = 1;
            if ($counterb["incidence"] == 0)
                $counter["incidence"] = "<span style='color:green'>" . $countera["incidence"] . "</SPAN>";
            else
                $counter["incidence"] = "<span style='color:red'>" . $counterb["incidence"] . "</SPAN> / <span style='color:green'>" . $countera["incidence"] . "</SPAN>";
        }
        if ($countera["investigation"] == 0) {
            $counter["investigationCnt"] = 0;
            $counter["investigation"] = 0;
        } else {
            $counter["investigationCnt"] = 1;
            if ($counterb["investigation"] == 0)
                $counter["investigation"] = "<span style='color:green'>" . $countera["investigation"] . "</SPAN>";
            else
                $counter["investigation"] = "<span style='color:red'>" . $counterb["investigation"] . "</SPAN> / <span style='color:green'>" . $countera["investigation"] . "</SPAN>";
        }
        if ($countera["inspectionn"] == 0) {
            $counter["inspectionnCnt"] = 0;
            $counter["inspectionn"] = 0;
        } else {
            $counter["inspectionnCnt"] = 1;
            if ($counterb["inspectionn"] == 0)
                $counter["inspectionn"] = "<span style='color:green'>" . $countera["inspectionn"] . "</SPAN>";
            else
                $counter["inspectionn"] = "<span style='color:red'>" . $counterb["inspectionn"] . "</SPAN> / <span style='color:green'>" . $countera["inspectionn"] . "</SPAN>";
        }
        if ($countera["inspectiond"] == 0) {
            $counter["inspectiondCnt"] = 0;
            $counter["inspectiond"] = 0;
        } else {
            $counter["inspectiondCnt"] = 1;
            if ($counterb["inspectiond"] == 0)
                $counter["inspectiond"] = "<span style='color:green'>" . $countera["inspectiond"] . "</SPAN>";
            else
                $counter["inspectiond"] = "<span style='color:red'>" . $counterb["inspectiond"] . "</SPAN> / <span style='color:green'>" . $countera["inspectiond"] . "</SPAN>";
        }


        if ($countera["inspectionr"] == 0) {
            $counter["inspectionrCnt"] = 0;
            $counter["inspectionr"] = 0;
        } else {
            $counter["inspectionrCnt"] = 1;
            if ($counterb["inspectionr"] == 0)
                $counter["inspectionr"] = "<span style='color:green'>" . $countera["inspectionr"] . "</SPAN>";
            else
                $counter["inspectionr"] = "<span style='color:red'>" . $counterb["inspectionr"] . "</SPAN> / <span style='color:green'>" . $countera["inspectionr"] . "</SPAN>";
        }
        if ($countera["inspectionh"] == 0) {
            $counter["inspectionhCnt"] = 0;
            $counter["inspectionh"] = 0;
        } else {
            $counter["inspectionhCnt"] = 1;
            if ($counterb["inspectionh"] == 0)
                $counter["inspectionh"] = "<span style='color:green'>" . $countera["inspectionh"] . "</SPAN>";
            else
                $counter["inspectionh"] = "<span style='color:red'>" . $counterb["inspectionh"] . "</SPAN> / <span style='color:green'>" . $countera["inspectionh"] . "</SPAN>";
        }
        if ($countera["inspectionc"] == 0) {
            $counter["inspectioncCnt"] = 0;
            $counter["inspectionc"] = 0;
        } else {
            $counter["inspectioncCnt"] = 1;
            if ($counterb["inspectionc"] == 0)
                $counter["inspectionc"] = "<span style='color:green'>" . $countera["inspectionc"] . "</SPAN>";
            else
                $counter["inspectionc"] = "<span style='color:red'>" . $counterb["inspectionc"] . "</SPAN> / <span style='color:green'>" . $countera["inspectionc"] . "</SPAN>";
        }
        if ($countera["law"] == 0) {
            $counter["lawCnt"] = 0;
            $counter["law"] = 0;
        } else {
            $counter["lawCnt"] = 1;
            if ($counterb["law"] == 0)
                $counter["law"] = "<span style='color:green'>" . $countera["law"] . "</SPAN>";
            else
                $counter["law"] = "<span style='color:red'>" . $counterb["law"] . "</SPAN> / <span style='color:green'>" . $countera["law"] . "</SPAN>";
        }

        if ($countera["management"] == 0) {
            $counter["managementCnt"] = 0;
            $counter["management"] = 0;
        } else {
            $counter["managementCnt"] = 1;
            if ($counterb["management"] == 0)
                $counter["management"] = "<span style='color:green'>" . $countera["management"] . "</SPAN>";
            else
                $counter["management"] = "<span style='color:red'>" . $counterb["management"] . "</SPAN> / <span style='color:green'>" . $countera["management"] . "</SPAN>";
        }

        if ($countera["manual_handling"] == 0) {
            $counter["manual_handlingCnt"] = 0;
            $counter["manual_handling"] = 0;
        } else {
            $counter["manual_handlingCnt"] = 1;
            if ($counterb["manual_handling"] == 0)
                $counter["manual_handling"] = "<span style='color:green'>" . $countera["manual_handling"] . "</SPAN>";
            else
                $counter["manual_handling"] = "<span style='color:red'>" . $counterb["manual_handling"] . "</SPAN> / <span style='color:green'>" . $countera["manual_handling"] . "</SPAN>";
        }

        if ($countera["manual_handlingT"] == 0) {
            $counter["manual_handlingTCnt"] = 0;
            $counter["manual_handlingT"] = 0;
        } else {
            $counter["manual_handlingTCnt"] = 1;
            if ($counterb["manual_handlingT"] == 0)
                $counter["manual_handlingT"] = "<span style='color:green'>" . $countera["manual_handlingT"] . "</SPAN>";
            else
                $counter["manual_handlingT"] = "<span style='color:red'>" . $counterb["manual_handlingT"] . "</SPAN> / <span style='color:green'>" . $countera["manual_handlingT"] . "</SPAN>";
        }


        if ($countera["manual_handlingL"] == 0) {
            $counter["manual_handlingLCnt"] = 0;
            $counter["manual_handlingL"] = 0;
        } else {
            $counter["manual_handlingLCnt"] = 1;
            if ($counterb["manual_handlingL"] == 0)
                $counter["manual_handlingL"] = "<span style='color:green'>" . $countera["manual_handlingL"] . "</SPAN>";
            else
                $counter["manual_handlingL"] = "<span style='color:red'>" . $counterb["manual_handlingL"] . "</SPAN> / <span style='color:green'>" . $countera["manual_handlingL"] . "</SPAN>";
        }

        if ($countera["manual_handlingE"] == 0) {
            $counter["manual_handlingECnt"] = 0;
            $counter["manual_handlingE"] = 0;
        } else {
            $counter["manual_handlingECnt"] = 1;
            if ($counterb["manual_handlingE"] == 0)
                $counter["manual_handlingE"] = "<span style='color:green'>" . $countera["manual_handlingE"] . "</SPAN>";
            else
                $counter["manual_handlingE"] = "<span style='color:red'>" . $counterb["manual_handlingE"] . "</SPAN> / <span style='color:green'>" . $countera["manual_handlingE"] . "</SPAN>";
        }

        if ($countera["manual_handlingI"] == 0) {
            $counter["manual_handlingICnt"] = 0;
            $counter["manual_handlingI"] = 0;
        } else {
            $counter["manual_handlingICnt"] = 1;
            if ($counterb["manual_handlingI"] == 0)
                $counter["manual_handlingI"] = "<span style='color:green'>" . $countera["manual_handlingI"] . "</SPAN>";
            else
                $counter["manual_handlingI"] = "<span style='color:red'>" . $counterb["manual_handlingI"] . "</SPAN> / <span style='color:green'>" . $countera["manual_handlingI"] . "</SPAN>";
        }

        if ($countera["modules"] == 0) {
            $counter["modulesCnt"] = 0;
            $counter["modules"] = 0;
        } else {
            $counter["modulesCnt"] = 1;
            if ($counterb["modules"] == 0)
                $counter["modules"] = "<span style='color:green'>" . $countera["modules"] . "</SPAN>";
            else
                $counter["modules"] = "<span style='color:red'>" . $counterb["modules"] . "</SPAN> / <span style='color:green'>" . $countera["modules"] . "</SPAN>";
        }
        if ($countera["msr_action"] == 0) {
            $counter["msr_actionCnt"] = 0;
            $counter["msr_action"] = 0;
        } else {
            $counter["msr_actionCnt"] = 1;
            if ($counterb["msr_action"] == 0)
                $counter["msr_action"] = "<span style='color:green'>" . $countera["msr_action"] . "</SPAN>";
            else
                $counter["msr_action"] = "<span style='color:red'>" . $counterb["msr_action"] . "</SPAN> / <span style='color:green'>" . $countera["msr_action"] . "</SPAN>";
        }

        if ($countera["msr_reviews"] == 0) {
            $counter["msr_reviewsCnt"] = 0;
            $counter["msr_reviews"] = 0;
        } else {
            $counter["msr_reviewsCnt"] = 1;
            if ($counterb["msr_reviews"] == 0)
                $counter["msr_reviews"] = "<span style='color:green'>" . $countera["msr_reviews"] . "</SPAN>";
            else
                $counter["msr_reviews"] = "<span style='color:red'>" . $counterb["msr_reviews"] . "</SPAN> / <span style='color:green'>" . $countera["msr_reviews"] . "</SPAN>";
        }

        if ($countera["operation"] == 0) {
            $counter["operationCnt"] = 0;
            $counter["operation"] = 0;
        } else {
            $counter["operationCnt"] = 1;
            if ($counterb["operation"] == 0)
                $counter["operation"] = "<span style='color:green'>" . $countera["operation"] . "</SPAN>";
            else
                $counter["operation"] = "<span style='color:red'>" . $counterb["operation"] . "</SPAN> / <span style='color:green'>" . $countera["operation"] . "</SPAN>";
        }

        if ($countera["nhcinvestigation"] == 0) {
            $counter["nhcinvestigationCnt"] = 0;
            $counter["nhcinvestigation"] = 0;
        } else {
            $counter["nhcinvestigationCnt"] = 1;
            if ($counterb["nhcinvestigation"] == 0)
                $counter["nhcinvestigation"] = "<span style='color:green'>" . $countera["nhcinvestigation"] . "</SPAN>";
            else
                $counter["nhcinvestigation"] = "<span style='color:red'>" . $counterb["nhcinvestigation"] . "</SPAN> / <span style='color:green'>" . $countera["nhcinvestigation"] . "</SPAN>";
        }

        if ($countera["nhp"] == 0) {
            $counter["nhpCnt"] = 0;
            $counter["nhp"] = 0;
        } else {
            $counter["nhpCnt"] = 1;
            if ($counterb["nhp"] == 0)
                $counter["nhp"] = "<span style='color:green'>" . $countera["nhp"] . "</SPAN>";
            else
                $counter["nhp"] = "<span style='color:red'>" . $counterb["nhp"] . "</SPAN> / <span style='color:green'>" . $countera["nhp"] . "</SPAN>";
        }
        if ($countera["preventive"] == 0) {
            $counter["preventiveCnt"] = 0;
            $counter["preventive"] = 0;
        } else {
            $counter["preventiveCnt"] = 1;
            if ($counterb["preventive"] == 0)
                $counter["preventive"] = "<span style='color:green'>" . $countera["preventive"] . "</SPAN>";
            else
                $counter["preventive"] = "<span style='color:red'>" . $counterb["preventive"] . "</SPAN> / <span style='color:green'>" . $countera["preventive"] . "</SPAN>";
        }

        if ($countera["operation"] == 0) {
            $counter["operationCnt"] = 0;
            $counter["operation"] = 0;
        } else {
            $counter["operationCnt"] = 1;
            if ($counterb["operation"] == 0)
                $counter["operation"] = "<span style='color:green'>" . $countera["operation"] . "</SPAN>";
            else
                $counter["operation"] = "<span style='color:red'>" . $counterb["operation"] . "</SPAN> / <span style='color:green'>" . $countera["operation"] . "</SPAN>";
        }

        if ($countera["PCI"] == 0) {
            $counter["PCICnt"] = 0;
            $counter["PCI"] = 0;
        } else {
            $counter["PCICnt"] = 1;
            if ($counterb["PCI"] == 0)
                $counter["PCI"] = "<span style='color:green'>" . $countera["PCI"] . "</SPAN>";
            else
                $counter["PCI"] = "<span style='color:red'>" . $counterb["PCI"] . "</SPAN> / <span style='color:green'>" . $countera["PCI"] . "</SPAN>";
        }


        if ($countera["pfs"] == 0) {
            $counter["pfsCnt"] = 0;
            $counter["pfs"] = 0;
        } else {
            $counter["pfsCnt"] = 1;
            if ($counterb["pfs"] == 0)
                $counter["pfs"] = "<span style='color:green'>" . $countera["pfs"] . "</SPAN>";
            else
                $counter["pfs"] = "<span style='color:red'>" . $counterb["pfs"] . "</SPAN> / <span style='color:green'>" . $countera["pfs"] . "</SPAN>";
        }

        if ($countera["risk"] == 0) {
            $counter["riskCnt"] = 0;
            $counter["risk"] = 0;
        } else {
            $counter["riskCnt"] = 1;
            if ($counterb["risk"] == 0)
                $counter["risk"] = "<span style='color:green'>" . $countera["risk"] . "</SPAN>";
            else
                $counter["risk"] = "<span style='color:red'>" . $counterb["risk"] . "</SPAN> / <span style='color:green'>" . $countera["risk"] . "</SPAN>";
        }
        if ($countera["risk27k"] == 0) {
            $counter["risk27kCnt"] = 0;
            $counter["risk27k"] = 0;
        } else {
            $counter["risk27kCnt"] = 1;
            if ($counterb["risk27k"] == 0)
                $counter["risk27k"] = "<span style='color:green'>" . $countera["risk27k"] . "</SPAN>";
            else
                $counter["risk27k"] = "<span style='color:red'>" . $counterb["risk27k"] . "</SPAN> / <span style='color:green'>" . $countera["risk27k"] . "</SPAN>";
        }

        if ($countera["Smartlaw"] == 0) {
            $counter["Smartlaw"] = 0;
            $counter["SmartlawCnt"] = 0;
        } else {
            $counter["SmartlawCnt"] = 1;
            if ($counterb["Smartlaw"] == 0)
                $counter["Smartlaw"] = "<span style='color:green'>" . $countera["Smartlaw"] . "</SPAN>";
            else
                $counter["Smartlaw"] = "<span style='color:red'>" . $counterb["Smartlaw"] . "</SPAN> / <span style='color:green'>" . $countera["Smartlaw"] . "</SPAN>";
        }

        if ($countera["Smartlawreview"] == 0) {
            $counter["Smartlawreview"] = 0;
            $counter["SmartlawreviewCnt"] = 0;
        } else {
            $counter["SmartlawreviewCnt"] = 1;
            if ($counterb["Smartlawreview"] == 0)
                $counter["Smartlawreview"] = "<span style='color:green'>" . $countera["Smartlawreview"] . "</SPAN>";
            else
                $counter["Smartlawreview"] = "<span style='color:red'>" . $counterb["Smartlawreview"] . "</SPAN> / <span style='color:green'>" . $countera["Smartlawreview"] . "</SPAN>";
        }

        if ($countera["SOA"] == 0) {
            $counter["SOACnt"] = 0;
            $counter["SOA"] = 0;
        } else {
            $counter["SOACnt"] = 1;
            if ($counterb["SOA"] == 0)
                $counter["SOA"] = "<span style='color:green'>" . $countera["SOA"] . "</SPAN>";
            else
                $counter["SOA"] = "<span style='color:red'>" . $counterb["SOA"] . "</SPAN> / <span style='color:green'>" . $countera["SOA"] . "</SPAN>";
        }
        if ($countera["communications"] == 0) {
            $counter["communicationsCnt"] = 0;
            $counter["communications"] = 0;
        } else {
            $counter["communicationsCnt"] = 1;
            if ($counterb["communications"] == 0)
                $counter["communications"] = "<span style='color:green'>" . $countera["communications"] . "</SPAN>";
            else
                $counter["communications"] = "<span style='color:red'>" . $counterb["communications"] . "</SPAN> / <span style='color:green'>" . $countera["communications"] . "</SPAN>";
        }

        if ($countera["context"] == 0) {
            $counter["contextCnt"] = 0;
            $counter["context"] = 0;
        } else {
            $counter["contextCnt"] = 1;
            if ($counterb["context"] == 0)
                $counter["context"] = "<span style='color:green'>" . $countera["context"] . "</SPAN>";
            else
                $counter["context"] = "<span style='color:red'>" . $counterb["context"] . "</SPAN> / <span style='color:green'>" . $countera["context"] . "</SPAN>";
        }
        if ($countera["dse"] == 0) {
            $counter["dseCnt"] = 0;
            $counter["dse"] = 0;
        } else {
            $counter["dseCnt"] = 1;
            if ($counterb["dse"] == 0)
                $counter["dse"] = "<span style='color:green'>" . $countera["dse"] . "</SPAN>";
            else
                $counter["dse"] = "<span style='color:red'>" . $counterb["dse"] . "</SPAN> / <span style='color:green'>" . $countera["dse"] . "</SPAN>";
        }
        if ($countera["bcp"] == 0) {
            $counter["bcpCnt"] = 0;
            $counter["bcp"] = 0;
        } else {
            $counter["bcpCnt"] = 1;
            if ($counterb["bcp"] == 0)
                $counter["bcp"] = "<span style='color:green'>" . $countera["bcp"] . "</SPAN>";
            else
                $counter["bcp"] = "<span style='color:red'>" . $counterb["bcp"] . "</SPAN> / <span style='color:green'>" . $countera["bcp"] . "</SPAN>";
        }

        if ($countera["template"] == 0) {
            $counter["templateCnt"] = 0;
            $counter["template"] = 0;
        } else {
            $counter["templateCnt"] = 1;
            if ($counterb["template"] == 0)
                $counter["template"] = "<span style='color:green'>" . $countera["template"] . "</SPAN>";
            else
                $counter["template"] = "<span style='color:red'>" . $counterb["template"] . "</SPAN> / <span style='color:green'>" . $countera["template"] . "</SPAN>";
        }

        if ($countera["cpa"] == 0) {
            $counter["cpaCnt"] = 0;
            $counter["cpa"] = 0;
        } else {
            $counter["cpaCnt"] = 1;
            if ($counterb["cpa"] == 0)
                $counter["cpa"] = "<span style='color:green'>" . $countera["cpa"] . "</SPAN>";
            else
                $counter["cpa"] = "<span style='color:red'>" . $counterb["cpa"] . "</SPAN> / <span style='color:green'>" . $countera["cpa"] . "</SPAN>";
        }
        if ($countera["gov"] == 0) {
            $counter["govCnt"] = 0;
            $counter["gov"] = 0;
        } else {
            $counter["govCnt"] = 1;
            if ($counterb["gov"] == 0)
                $counter["gov"] = "<span style='color:green'>" . $countera["gov"] . "</SPAN>";
            else
                $counter["gov"] = "<span style='color:red'>" . $counterb["gov"] . "</SPAN> / <span style='color:green'>" . $countera["gov"] . "</SPAN>";
        }

        if ($countera["gov1"] == 0) {
            $counter["gov1Cnt"] = 0;
            $counter["gov1"] = 0;
        } else {
            $counter["gov1Cnt"] = 1;
            if ($counterb["gov1"] == 0)
                $counter["gov1"] = "<span style='color:green'>" . $countera["gov1"] . "</SPAN>";
            else
                $counter["gov1"] = "<span style='color:red'>" . $counterb["gov1"] . "</SPAN> / <span style='color:green'>" . $countera["gov1"] . "</SPAN>";
        }

        if ($countera["gov2"] == 0) {
            $counter["gov2Cnt"] = 0;
            $counter["gov2"] = 0;
        } else {
            $counter["gov2Cnt"] = 1;
            if ($counterb["gov2"] == 0)
                $counter["gov2"] = "<span style='color:green'>" . $countera["gov2"] . "</SPAN>";
            else
                $counter["gov2"] = "<span style='color:red'>" . $counterb["gov2"] . "</SPAN> / <span style='color:green'>" . $countera["gov2"] . "</SPAN>";
        }

        if ($countera["fdocuments"] == 0) {
            $counter["fdocumentsCnt"] = 0;
            $counter["fdocuments"] = 0;
        } else {
            $counter["fdocumentsCnt"] = 1;
            if ($counterb["fdocuments"] == 0)
                $counter["fdocuments"] = "<span style='color:green'>" . $countera["fdocuments"] . "</SPAN>";
            else
                $counter["fdocuments"] = "<span style='color:red'>" . $counterb["fdocuments"] . "</SPAN> / <span style='color:green'>" . $countera["fdocuments"] . "</SPAN>";
        }
        if ($countera["finspections"] == 0) {
            $counter["finspectionsCnt"] = 0;
            $counter["finspections"] = 0;
        } else {
            $counter["finspectionsCnt"] = 1;
            if ($counterb["finspections"] == 0)
                $counter["finspections"] = "<span style='color:green'>" . $countera["finspections"] . "</SPAN>";
            else
                $counter["finspections"] = "<span style='color:red'>" . $counterb["finspections"] . "</SPAN> / <span style='color:green'>" . $countera["finspections"] . "</SPAN>";
        }

        if ($countera["equipm"] == 0) {
            $counter["equipmCnt"] = 0;
            $counter["equipm"] = 0;
        } else {
            $counter["equipmCnt"] = 1;
            if ($counterb["equipm"] == 0)
                $counter["equipm"] = "<span style='color:green'>" . $countera["equipm"] . "</SPAN>";
            else
                $counter["equipm"] = "<span style='color:red'>" . $counterb["equipm"] . "</SPAN> / <span style='color:green'>" . $countera["equipm"] . "</SPAN>";
        }

        if ($countera["equipc"] == 0) {
            $counter["equipcCnt"] = 0;
            $counter["equipc"] = 0;
        } else {
            $counter["equipcCnt"] = 1;
            if ($counterb["equipc"] == 0)
                $counter["equipc"] = "<span style='color:green'>" . $countera["equipc"] . "</SPAN>";
            else
                $counter["equipc"] = "<span style='color:red'>" . $counterb["equipc"] . "</SPAN> / <span style='color:green'>" . $countera["equipc"] . "</SPAN>";
        }

        if ($countera["rta"] == 0) {
            $counter["rtaCnt"] = 0;
            $counter["rta"] = 0;
        } else {
            $counter["rtaCnt"] = 1;
            if ($counterb["rta"] == 0)
                $counter["rta"] = "<span style='color:green'>" . $countera["rta"] . "</SPAN>";
            else
                $counter["rta"] = "<span style='color:red'>" . $counterb["rta"] . "</SPAN> / <span style='color:green'>" . $countera["rta"] . "</SPAN>";
        }

        if ($countera["fservices"] == 0) {
            $counter["fservicesCnt"] = 0;
            $counter["fservices"] = 0;
        } else {
            $counter["fservicesCnt"] = 1;
            if ($counterb["fservices"] == 0)
                $counter["fservices"] = "<span style='color:green'>" . $countera["fservices"] . "</SPAN>";
            else
                $counter["fservices"] = "<span style='color:red'>" . $counterb["fservices"] . "</SPAN> / <span style='color:green'>" . $countera["fservices"] . "</SPAN>";
        }

        if ($countera["bia"] == 0) {
            $counter["biaCnt"] = 0;
            $counter["bia"] = 0;
        } else {
            $counter["biaCnt"] = 1;
            if ($counterb["bia"] == 0)
                $counter["bia"] = "<span style='color:green'>" . $countera["bia"] . "</SPAN>";
            else
                $counter["bia"] = "<span style='color:red'>" . $counterb["bia"] . "</SPAN> / <span style='color:green'>" . $countera["bia"] . "</SPAN>";
        }


        if ($countera["contributor"] == 0) {
            $counter["contributorCnt"] = 0;
            $counter["contributor"] = 0;
        } else {
            $counter["contributorCnt"] = 1;
            if ($counterb["contributor"] == 0)
                $counter["contributor"] = "<span style='color:green'>" . $countera["contributor"] . "</SPAN>";
            else
                $counter["contributor"] = "<span style='color:red'>" . $counterb["contributor"] . "</SPAN> / <span style='color:green'>" . $countera["contributor"] . "</SPAN>";
        }

        if ($countera["docalert"] == 0) {
            $counter["docalertCnt"] = 0;
            $counter["docalert"] = 0;
        } else {
            $counter["docalertCnt"] = 1;
            if ($counterb["docalert"] == 0)
                $counter["docalert"] = "<span style='color:green'>" . $countera["docalert"] . "</SPAN>";
            else
                $counter["docalert"] = "<span style='color:red'>" . $counterb["docalert"] . "</SPAN> / <span style='color:green'>" . $countera["docalert"] . "</SPAN>";
        }

        if ($countera["document"] == 0) {
            $counter["documentCnt"] = 0;
            $counter["document"] = 0;
        } else {
            $counter["documentCnt"] = 1;
            if ($counterb["document"] == 0)
                $counter["document"] = "<span style='color:green'>" . $countera["document"] . "</SPAN>";
            else
                $counter["document"] = "<span style='color:red'>" . $counterb["document"] . "</SPAN> / <span style='color:green'>" . $countera["document"] . "</SPAN>";
        }

        if ($countera["documentreview"] == 0) {
            $counter["documentreviewCnt"] = 0;
            $counter["documentreview"] = 0;
        } else {
            $counter["documentreviewCnt"] = 1;
            if ($counterb["documentreview"] == 0)
                $counter["documentreview"] = "<span style='color:green'>" . $countera["documentreview"] . "</SPAN>";
            else
                $counter["documentreview"] = "<span style='color:red'>" . $counterb["documentreview"] . "</SPAN> / <span style='color:green'>" . $countera["documentreview"] . "</SPAN>";
        }

        if ($countera["gap_fillings"] == 0) {
            $counter["gap_fillingsCnt"] = 0;
            $counter["gap_fillings"] = 0;
        } else {
            $counter["gap_fillingsCnt"] = 1;
            if ($counterb["gap_fillings"] == 0)
                $counter["gap_fillings"] = "<span style='color:green'>" . $countera["gap_fillings"] . "</SPAN>";
            else
                $counter["gap_fillings"] = "<span style='color:red'>" . $counterb["gap_fillings"] . "</SPAN> / <span style='color:green'>" . $countera["gap_fillings"] . "</SPAN>";
        }

        return $counter;
    }

    public function getActionListCount() {

        $sql = sprintf("select count(moduleName)as total,moduleName from %s.actions where approveAU=0 and status=1 and currentWho=%d group by moduleName", _DB_OBJ_FULL, getLoggedInUserId());
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $datacount = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $datacount;
    }

    public function getActionData($IDs) {

        $sql = sprintf("select approveDate,approveAU from %s.actions  where ID in (%s) order by approveDate,approveAU", _DB_OBJ_FULL, $IDs);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

        public function getHistoryData($ID) {

        $sql = sprintf("select * from %s.actionshistory  where ID = %d order by HID  desc", _DB_OBJ_FULL, $ID);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
}
public function updatehistory($id) {
    $sql = sprintf("INSERT INTO %s.actionshistory
           (ID
           ,moduleName
           ,actionDescription
           ,who
           ,dueDate
           ,doneDate
           ,doneDescription
           ,approve
           ,outstanding
           ,status
           ,approveAU
           ,whoAU
           ,thirdParty
           ,approver
           ,addapprover
           ,rejected
           ,record
           ,moduleElement
           ,reassigned
           ,locID
           ,field
           ,currentWho
           ,app2date
           ,approvedate
           ,rejectreason
           ,approvecomment
           ,approve2comment
           ,outstandingcomment
           ,origin
           ,timestamp
           ,updater
           ,actiontaken)
     select
           ID
           ,moduleName
           ,actionDescription
           ,who
           ,dueDate
           ,doneDate
           ,doneDescription
           ,approve
           ,outstanding
           ,status
           ,approveAU
           ,whoAU
           ,thirdParty
           ,approver
           ,addapprover
           ,rejected
           ,record
           ,moduleElement
           ,reassigned
           ,locID
           ,field
           ,currentWho
           ,app2date
           ,approvedate
           ,rejectreason
           ,approvecomment
           ,approve2comment
           ,outstandingcomment
           ,origin
           ,timechanged 
           ,updater
           ,last_action from %s.actions where ID=%d", _DB_OBJ_FULL,  _DB_OBJ_FULL,$id);
          $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
}


}

?>