<?php
 /**
  $Id: ActionTrackerRisk.class.php,v 3.43 Wednesday, January 26, 2011 6:09:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerGOV extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;
        
            public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
        $this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID where modulename='GOV_action'  and A.status=1  and currentWho=%d and approveAU=0
							ORDER BY A.ID DESC",  _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
        $this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID where modulename='GOV_action' and A.who=%d and approveAU=1
							ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();


        if (isAdministrator()) {

          $this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID where modulename='GOV_action'   and A.status=1  and approveAU=0 and not currentWho=%d
							ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {

           		$this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID  where modulename='GOV_action'  and A.status=1   and approveAU=0 and whoAU=%d
							ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,   $USER_ID);
        }

        return $this->getActionsByFilter(__METHOD__);
    }
    public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {
            $this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID where modulename='GOV_action'  and approveAU=1 and not A.who=%d
							ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,  $USER_ID);
        } else {

        			 $this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID where modulename='GOV_action'  and approveAU=1 and whoAU=%d
							ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }
       
        return $this->getActionsByFilter(__METHOD__);
    }

		        public function getTotalActions($data) {
$startdate=$data["startdate"];
$enddate=$data["enddate"];
$who =$data["who"];
$completed=(int)$data["completed"];

$startStr="";
$endStr="";    
$whoStr="";

if ($startdate)
    $startStr=" and duedate>='".format_date_for_mysql($startdate)."' ";
if ($enddate)
    $endStr=" and duedate<='".format_date_for_mysql($enddate)."' ";
if ($who)
    $whoStr=" and A.who=".$who." ";
    
                 $this->sql_query = sprintf("select A.id,R.problem,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,D.reference,D.reviewID from %s.actions A inner join %s.gov_results R on A.record=R.ID inner join %s.gov_master D on R.GOV_id=D.reviewID where modulename='GOV_action'   and A.status=1  and approveAU=%d %s %s %s
							ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$completed,$startStr,$endStr,$whoStr);
      
        return $this->getActionsByFilter(__METHOD__);
    }
	
    private function getActionsByFilter($p_callingMethod) {

        $USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
        //echo $calling_method;

        $pStatement = $this->dbHand->prepare($this->sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
}