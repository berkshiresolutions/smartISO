<?php
 /**
  $Id: Complaint.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, October 09, 2010 12:50:41 PM>
  */

require "Complaint.int.php";
require_once "Action.class.php";

class Complaint implements ComplaintInterface
{
	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 *Property to hold Complaint Id
	 *@access private
	 */
	private $complaintId;

	/**
	 *Property to hold Complaint Info
	 *@access private
	 */
	private $complaintInfo;

	/**
	 * Constructor for initializing Manual Handling object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/**
	 * to set complaint information for performing various operations with the complaint object
	 * @param integer This parameter holds the complaint Id
	 * @param array This parameter holds the the complaint Info
	 */
	public function setComplaintInfo($p_complaintId,$p_complaintInfo) {

		$this->complaintId		= $p_complaintId;
		$this->complaintInfo	= $p_complaintInfo;
	}

	/**
	 * This method is used to add a new complaint
	 * reference,unique_reference,location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
	 * address,phone,email,complaint_nature,likelihood,impact,risk_rating,risk_color,complaint_category,investigation,action,who,when
	 */
	public function addComplaint() {

		$sql1 = "SELECT * FROM complaint WHERE reference = ?";
		$pStatement1 = $this->dbHand->prepare($sql1);

		$pStatement1->bindParam(1,$this->complaintInfo['reference'],PDO::PARAM_STR);

		$pStatement1->execute();
		$result = $pStatement1->fetchAll(PDO::FETCH_ASSOC);
		$exists = count($result);

		if ( $exists ) {
			throw new ErrorException('Reference number already exist.');
		} else {

	echo		$sql = sprintf("INSERT INTO %s.complaint ( reference, uniqueReference, locationId, considerRisk, complaintDescription, 
											isPhone, isFax, isPerson, isEmail, isLetter, firstName, lastName, relationshipClient, address,
											phoneNumber, emailAddress, complaintNature, likelihood, impact, riskRating, riskRatingColor,
											complaintCategory, isInvestigation )
										VALUES ( '%s','%s',%d,%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ) ",_DB_OBJ_FULL,
		$this->complaintInfo['reference'],$this->complaintInfo['unique_reference'],
		$this->complaintInfo['location'],$this->complaintInfo['consider_risk'],
		$this->complaintInfo['description'],$this->complaintInfo['is_phone'],
$this->complaintInfo['is_fax'],$this->complaintInfo['is_person'],$this->complaintInfo['is_email'],$this->complaintInfo['is_letter'],
$this->complaintInfo['first_name'],$this->complaintInfo['last_name'],$this->complaintInfo['relationship'],$this->complaintInfo['address'],
$this->complaintInfo['phone'],$this->complaintInfo['email'],$this->complaintInfo['complaint_nature'],$this->complaintInfo['likelihood'],
$this->complaintInfo['impact'],$this->complaintInfo['risk_rating'],$this->complaintInfo['risk_color'],$this->complaintInfo['complaint_category'],
$this->complaintInfo['investigation']);



			
			
			
						$pStatement = $this->dbHand->prepare($sql);
				
			$pStatement->execute();

			$this->complaintId = customLastInsertId($this->dbHand,'complaint','ID');

			$this->actionData = array('module_name'=>'complaint','description'=>$this->complaintInfo['action'],
								  'who'=>$this->complaintInfo['who'],'due_date'=>$this->complaintInfo['when']);

			$this->actionHandling->setActionDetails(0,$this->actionData);
			$new_action_id = $this->actionHandling->addAction();
			$action_id = $new_action_id;

			$sql3 = sprintf("UPDATE %s.complaint SET actionID = ? WHERE ID = ? ",_DB_OBJ_FULL);
			$pStatement3 = $this->dbHand->prepare($sql3);

			$pStatement3->bindParam(1,$action_id,PDO::PARAM_INT);
			$pStatement3->bindParam(2,$this->complaintId,PDO::PARAM_INT);

			$pStatement3->execute();

		}

	}

	/**
	 * This method is used to view complaint information.
	 */
	public function viewComplaint() {

		$sql = sprintf("SELECT * FROM %s.complaint WHERE ID = ? ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->bindParam(1,$this->complaintId,PDO::PARAM_INT);
		$pStatement->execute();
		$result = $pStatement->fetch(PDO::FETCH_ASSOC);

		$this->actionHandling->setActionDetails($result['actionID'],"");
		$action_data = $this->actionHandling->viewAction();
		$result['action'] = $action_data['actionDescription'];
		$result['who'] = $action_data['who'];
		$result['when'] = $action_data['dueDate'];

		return $result;
	}

	/**
	 * This method is used to edit a complaint
	 * location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
	 * address,phone,email,complaint_nature,likelihood,impact,risk_rating,risk_color,complaint_category,investigation,action,who,when
	 */
	public function editComplaint() {

		$sql = sprintf("UPDATE %s.complaint SET locationId = '%s',
										considerRisk = '%s',
										complaintDescription = '%s',
										isPhone = '%s',
										isFax = '%s',
										isPerson = '%s',
										isEmail = '%s',
										isLetter = '%s',
										firstName = '%s',
										lastName = '%s',
										relationshipClient = '%s',
										address = '%s',
										phoneNumber = '%s',
										emailAddress = '%s',
										complaintNature = '%s',
										likelihood = '%s',
										impact = '%s',
										riskRating = '%s',
										riskRatingColor = '%s',
										complaintCategory = '%s',
										isInvestigation = '%s'
								WHERE ID = '%s'",_DB_OBJ_FULL

		

		
		,$this->complaintInfo['location']
		,$this->complaintInfo['consider_risk']
		,$this->complaintInfo['description']
		,$this->complaintInfo['is_phone']
		,$this->complaintInfo['is_fax']
		,$this->complaintInfo['is_person']
		,$this->complaintInfo['is_email']
		,$this->complaintInfo['is_letter']
		,$this->complaintInfo['first_name']
		,$this->complaintInfo['last_name']
		,$this->complaintInfo['relationship']
		,$this->complaintInfo['address']
		,$this->complaintInfo['phone']
		,$this->complaintInfo['email']
		,$this->complaintInfo['complaint_nature']
		,$this->complaintInfo['likelihood']
		,$this->complaintInfo['impact']
		,$this->complaintInfo['risk_rating']
		,$this->complaintInfo['risk_color']
		,$this->complaintInfo['complaint_category']
		,$this->complaintInfo['investigation']
		,$this->complaintId);

		$pStatement = $this->dbHand->prepare($sql);
		
		$pStatement->execute();

		$complaint_data = $this->viewComplaint();

		$this->actionData = array('module_name'=>'complaint','description'=>$this->complaintInfo['action'],
								  'who'=>$this->complaintInfo['who'],'due_date'=>$this->complaintInfo['when']);

		$this->actionHandling->setActionDetails($complaint_data['actionID'],$this->actionData);
		$new_action_id = $this->actionHandling->updateAction();

		//dump_array($pStatement->errorInfo());
	}

	/**
	 * This method is used to delete a complaint
	 */
	public function deleteComplaint() {

		$sql = sprintf("UPDATE FROM %s.complaint set archive=1 WHERE ID = ?",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->bindParam(1,$this->complaintId,PDO::PARAM_INT);
		$pStatement->execute();
	}

	/**
	 * This method is used to archive a complaint
	 */
	public function archiveComplaint() {}

	/**
	 * This method is used to remove a complaint
	 */
	public function purgeComplaint() {}

	/**
	 * This method is used to last insertted record Id
	 */
	public function lastrecordId() {
		return $this->complaintId;
	}

	/**
	 * This method is used to view all complaints.
	 */
	public function viewAllComplaints() {

		$sql = sprintf("SELECT * FROM %s.complaint",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();
		//$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		$i = 0;
		while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {

			$this->actionHandling->setActionDetails($row['actionID'],"");
			$action_data = $this->actionHandling->viewAction();


			$result[$i] = $row;
			$result[$i]['action'] = $action_data['actionDescription'];
			$result[$i]['who'] = $action_data['who'];
			$result[$i]['when'] = $action_data['dueDate'];

			$i++;
		}

		return $result;
	}

	public function getOutstandingActions() {

		$data = $this->actionHandling->viewAllActionByModule('complaint');

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];

				$sql = sprintf("SELECT M.reference,M.ID AS cmp_id FROM %s.complaint M
											WHERE M.actionID = $d",_DB_OBJ_FULL,$search_value1);

				$pStatement = $this->dbHand->prepare($sql);

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['cmp_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function updateStatus() {
		$sql = sprintf("UPDATE %s.complaint SET status = '1' WHERE ID = ? ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->complaintId,PDO::PARAM_INT);
		$pStatement->execute();

	}

	public function sendActionAlerts($p_record_id) {

		global $likelihood_arr;

		$this->complaintId = $p_record_id;

		$complaint_details = $this->viewComplaint();

		switch( $complaint_details['considerRisk'] ) {
			case 'T' : $risk = 'Trivial'; break;
			case 'L' : $risk = 'Low'; break;
			case 'M' : $risk = 'Medium'; break;
			case 'H' : $risk = 'High'; break;
			case 'I' : $risk = 'Immediate'; break;
		}

		$complaint_details['considerRisk'] = $risk;
		$dat_time = explode(' ',$complaint_details['time']);
		$complaint_details['date'] = format_date($dat_time[0]);
		$complaint_details['time'] = $dat_time[1];
		$complaint_details['when'] = format_date($complaint_details['when']);

		/* nature of complaint */
		$objComplaint = SetupGeneric::useModule('ComplaintNature');
		$objComplaint->setItemInfo(array(
								'id'=>$complaint_details['complaintNature']
								));
		$recordComplaint = $objComplaint->displayItemById();
		$complaint_details['complaintNature'] = $recordComplaint['name'];

		/* Likelihood of complaint */
		$complaint_details['likelihood'] = $likelihood_arr[$complaint_details['likelihood']];

		/* impact */
		$impactObj = SetupGeneric::useModule('ImpactMeasure');
		$impactObj->setItemInfo(array(
							  'id'=>$complaint_details['impact'],
							  ));
		$data = $impactObj->displayItemById() ;
		$complaint_details['impact'] = $data['name'];

		/* complaint category */
		$objCategory = SetupGeneric::useModule('ComplaintCategory');
		$objCategory->setItemInfo(array(
								'id'=>$complaint_details['complaintCategory']
								));
		$recordategory = $objCategory->displayItemById();

		$complaint_details['complaintCategory'] = $recordategory['name'];


		$this->actionHandling->updateStatus($complaint_details['actionID']);

		//dump_array($complaint_details);
		$email_data[0] = $complaint_details;

		return $email_data;
	}
}
?>