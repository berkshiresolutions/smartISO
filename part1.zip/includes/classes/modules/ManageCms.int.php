<?php
 /**
  $Id: ManageCms.int.php,v 3.05 Friday, September 10, 2010 8:05:30 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Manage CMS object
  *
  * This interface will declare the various methods performed
  * by inspection object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Friday, September 10, 2010 8:00:42 PM>
  */

interface ManageCms
{
	/*
	 * This method is used to set CMS section information for the respective object
	 */
	public function setCmsInfo($p_sectionId,$p_sectionInfo);

	/*
	 * This method is used to save CMS section information
	 */
	public function addCmsRecord();
}
?>