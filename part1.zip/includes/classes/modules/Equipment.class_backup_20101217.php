<?php
 /**
  $Id: Equipment.class_backup_20101217.php,v 3.22 Tuesday, December 28, 2010 12:00:37 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Saturday, October 09, 2010 10:40:08 AM>
  */

require_once "Equipment.int.php";

class Equipment implements EquipmentInterface
{

	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 *Property to hold Equipment Id
	 *@access private
	 */
	private $equipmentId;

	/**
	 *Property to hold Equipment Info
	 *@access private
	 */
	private $equipmentInfo;

	/**
	 * Constructor for initializing Equipment object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/**
	 * to set equipment information for performing various operations with an equipment object
	 * @param integer This parameter holds the equipment Id
	 * @param array This parameter holds the the equipment Info
	 */
	public function setEquipmentInfo($p_equipmentId,$p_equipmentInfo) {

		$this->equipmentId		=	$p_equipmentId;
		$this->equipmentInfo	=	$p_equipmentInfo;
	}

	/**
	 * This function is to manage Equipment supplier data
	 * name,address,contact_name,contact_number,email_address,manufacture_date,purchased_date,purchase_value,
	 * maintenance_expiry,calibration_expiry
	 */
	public function manageSupplier() {

		$sql = "UPDATE equipment_supplier_damage SET name = ?,
														address = ?,
														contactName = ?,
														contactNumber = ?,
														emailAddress = ?,
														dateManufacture = ?,
														datePurchased = ?,
														purchaseValue = ?,
														maintenanceExpiryDate = ?,
														calibrationExpiryDate = ?
													WHERE equipID = ? ";

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentInfo['name'],PDO::PARAM_STR);
		$pStatement->bindParam(2,$this->equipmentInfo['address'],PDO::PARAM_STR);
		$pStatement->bindParam(3,$this->equipmentInfo['contact_name'],PDO::PARAM_STR);
		$pStatement->bindParam(4,$this->equipmentInfo['contact_number'],PDO::PARAM_STR);
		$pStatement->bindParam(5,$this->equipmentInfo['email_address'],PDO::PARAM_STR);
		$pStatement->bindParam(6,format_date_for_mysql($this->equipmentInfo['manufacture_date']));
		$pStatement->bindParam(7,format_date_for_mysql($this->equipmentInfo['purchased_date']));
		$pStatement->bindParam(8,$this->equipmentInfo['purchase_value']);
		$pStatement->bindParam(9,format_date_for_mysql($this->equipmentInfo['maintenance_expiry']));
		$pStatement->bindParam(10,format_date_for_mysql($this->equipmentInfo['calibration_expiry']));
		$pStatement->bindParam(11,$this->equipmentId,PDO::PARAM_INT);

		$pStatement->execute();
	}

	/**
	 * THis function is to manage Equipment supplier data
	 * demage_item,demage_type,item_description,repair_location,written_item
	 */
	public function manageDamage() {

		$sql = "UPDATE equipment_supplier_damage SET damageItem = ?,
														typeDamage = ?,
														damageItemDescription = ?,
														locationRepair = ?,
														writtenItem = ?
													WHERE equipID = ? ";

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentInfo['damage_item'],PDO::PARAM_STR);
		$pStatement->bindParam(2,$this->equipmentInfo['damage_type'],PDO::PARAM_STR);
		$pStatement->bindParam(3,$this->equipmentInfo['item_description'],PDO::PARAM_STR);
		$pStatement->bindParam(4,$this->equipmentInfo['repair_location'],PDO::PARAM_STR);
		$pStatement->bindParam(5,$this->equipmentInfo['written_item']);
		$pStatement->bindParam(6,$this->equipmentId,PDO::PARAM_INT);

		$pStatement->execute();
	}

	/**
	 * This method is used to manage calibration or maintenance tab data
	 * section,required,predicted_cost,actual_cost,internal_contact,internal_business_unit,internal_name,internal_phone,external_contact,external_name,
	 * external_phone,address,date_sent,date_completed,description,upload_file
	 */

	public function manageCalibrationMaintenance() {

		$result = $this->viewEquipmentCalibrationMaintenance();
		$resultCount = (int) count($result);

		if ( $resultCount ) {
			// edit
			$this->editCalibrationMaintenance($result[0]['ID']);
		} else {
			// add
			$this->addCalibrationMaintenance();
		}
	}

	/**
	 * This method is used to Add calibration or maintenance tab data
	 * @access private
	 *
	 */
	private function addCalibrationMaintenance() {

		$sql = " INSERT INTO equipment_calibration_maintenance (equipID,sectionId,sectionRequired,predictedCost,actualCost,internalContact,internalBusinessId,
					internalName,internalPhone,externalContact,externalName,externalPhone,address,dateSent,dateCompleted,description)
					VALUES ( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? ) ";

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->equipmentInfo['section'],PDO::PARAM_INT);
		$pStatement->bindParam(3,$this->equipmentInfo['required'],PDO::PARAM_INT);
		$pStatement->bindParam(4,$this->equipmentInfo['predicted_cost']);
		$pStatement->bindParam(5,$this->equipmentInfo['actual_cost']);
		$pStatement->bindParam(6,$this->equipmentInfo['internal_contact']);
		$pStatement->bindParam(7,$this->equipmentInfo['internal_business_unit'],PDO::PARAM_INT);
		$pStatement->bindParam(8,$this->equipmentInfo['internal_name'],PDO::PARAM_STR);
		$pStatement->bindParam(9,$this->equipmentInfo['internal_phone'],PDO::PARAM_STR);
		$pStatement->bindParam(10,$this->equipmentInfo['external_contact']);
		$pStatement->bindParam(11,$this->equipmentInfo['external_name'],PDO::PARAM_STR);
		$pStatement->bindParam(12,$this->equipmentInfo['external_phone'],PDO::PARAM_STR);
		$pStatement->bindParam(13,$this->equipmentInfo['address'],PDO::PARAM_STR);
		$pStatement->bindParam(14,format_date_for_mysql($this->equipmentInfo['date_sent']));
		$pStatement->bindParam(15,format_date_for_mysql($this->equipmentInfo['date_completed']));
		$pStatement->bindParam(16,$this->equipmentInfo['description'],PDO::PARAM_STR);

		$pStatement->execute();

		//dump_array($this);
	}

	/**
	 * This method is used to Edit calibration or maintenance tab data
	 * @access private
	 *
	 */
	private function editCalibrationMaintenance($p_recordId) {

		$sql = " UPDATE equipment_calibration_maintenance SET sectionRequired = ?,
																predictedCost = ?,
																actualCost = ?,
																internalContact = ?,
																internalBusinessId = ?,
																internalName = ?,
																internalPhone = ?,
																externalContact = ?,
																externalName = ?,
																externalPhone = ?,
																address = ?,
																dateSent = ?,
																dateCompleted = ?,
																description = ?
															WHERE ID = ? ";

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentInfo['required'],PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->equipmentInfo['predicted_cost']);
		$pStatement->bindParam(3,$this->equipmentInfo['actual_cost']);
		$pStatement->bindParam(4,$this->equipmentInfo['internal_contact']);
		$pStatement->bindParam(5,$this->equipmentInfo['internal_business_unit'],PDO::PARAM_INT);
		$pStatement->bindParam(6,$this->equipmentInfo['internal_name'],PDO::PARAM_STR);
		$pStatement->bindParam(7,$this->equipmentInfo['internal_phone'],PDO::PARAM_STR);
		$pStatement->bindParam(8,$this->equipmentInfo['external_contact']);
		$pStatement->bindParam(9,$this->equipmentInfo['external_name'],PDO::PARAM_STR);
		$pStatement->bindParam(10,$this->equipmentInfo['external_phone'],PDO::PARAM_STR);
		$pStatement->bindParam(11,$this->equipmentInfo['address'],PDO::PARAM_STR);
		$pStatement->bindParam(12,format_date_for_mysql($this->equipmentInfo['date_sent']));
		$pStatement->bindParam(13,format_date_for_mysql($this->equipmentInfo['date_completed']));
		$pStatement->bindParam(14,$this->equipmentInfo['description'],PDO::PARAM_STR);
		$pStatement->bindParam(15,$p_recordId,PDO::PARAM_INT);

		$pStatement->execute();

		//dump_array($this);
	}

	/**
	 * This method is used to view an equipment information.
	 */
	public function viewEquipment() {}

	/**
	 * This method is used to view an equipment supplier demage information.
	 */
	public function viewEquipmentSupplierDamage() {

		$sql = "SELECT * FROM equipment_supplier_damage WHERE equipID = ? ";

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);

		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to view an equipment supplier demage information.
	 * section
	 */
	public function viewEquipmentCalibrationMaintenance() {

		$sql = "SELECT * FROM equipment_calibration_maintenance WHERE equipID = ? AND sectionId = ? ";

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->equipmentInfo['section'],PDO::PARAM_INT);

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to edit an equipment
	 */
	public function editEquipment() {}

	/**
	 * This method is used to display an equipment
	 */
	public function displayItems() {

		$sql = "SELECT * FROM equipments ORDER BY equipID DESC,equipTitle ASC";

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	/**
	 * This method is used to add an equipment files
	 * equip id, identifier, file_id
	 */
	public function addEquipmentFile() {

		$sql =" INSERT INTO equipment_files (equipID,section,fileID) VALUES (?,?,?) ";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->equipmentInfo['identifier'],PDO::PARAM_STR);
		$pStatement->bindParam(3,$this->equipmentInfo['file_id'],PDO::PARAM_INT);

		$pStatement->execute();
	}

	/**
	 * This method is used to add an equipment files
	 * equip id, identifier
	 */
	public function getEquipmentFile() {

		$sql =" SELECT * FROM equipment_files WHERE equipID = ? AND section = ?";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);
		$pStatement->bindParam(2,$this->equipmentInfo['identifier'],PDO::PARAM_STR);

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to add an equipment files
	 * file id
	 */
	public function getEquipmentFileDetails() {

		$sql =" SELECT * FROM equipment_files WHERE ID = ?";
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet[0];
	}

	/**
	 * This method is used to add an equipment files
	 * file id
	 */
	public function deleteEquipmentFile() {

		$sql = sprintf("DELETE FROM %s.equipment_files WHERE ID = ?",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->equipmentId,PDO::PARAM_INT);

		$pStatement->execute();
	}

}
?>