<?php

/**
  $Id: Risk27k.class.php,v 3.53 Thursday, February 03, 2011 4:23:33 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Monday, October 18, 2010 4:13:07 PM>
 */
require_once "Risk27k.int.php";
require_once "Action.class.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class Risk27k implements Risk27kInterface {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold Risk 27k Id
     * @access private
     */
    private $Risk27kId;

    /**
     * Property to hold Risk 27k Info
     * @access private
     */
    private $Risk27kInfo;

    /**
     * Constructor for initializing Risk 27k object
     * @access public
     */
    public function __construct() {

         
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /**
     * to set Risk 27k information for performing various operations with the Risk 27k object
     * $p_Risk27kId,$p_Risk27kInfo
     */
    public function setRisk27kInfo($p_Risk27kId, $p_Risk27kInfo) {
//dump_array($p_Risk27kInfo);
        $this->Risk27kId = $p_Risk27kId;
        $this->Risk27kInfo = $p_Risk27kInfo;
    }

    /**
     * This method is used to add a new Risk 27k
     *
     * Array Variables : reference,unique_reference,description,location,who,business_unit,when
     */
    public function addRisk27k() {

        $sql = sprintf("INSERT INTO %s.risk27k (reference ,uniqueReference ,description, locID ,who ,businessUnit ,whenDate,archive )
						VALUES ( '%s' ,'%s' ,'%s' ,%d ,%d ,'%s', '%s' ,%d)"
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['reference']
                , $this->Risk27kInfo['unique_reference']
                , $this->Risk27kInfo['description']
                , $this->Risk27kInfo['location']
                , $this->Risk27kInfo['who']
                , $this->Risk27kInfo['business_unit']
                , format_date_for_mysql($this->Risk27kInfo['whenDate'])
                , $this->Risk27kInfo['archive']
        );

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $this->Risk27kId = customLastInsertId($this->dbHand, 'risk27k', 'ID');
    }

    public function addAction() {

        $sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('%s','%s',%d,%d,'%s',0,0,0,0)", _DB_OBJ_FULL, $this->Risk27kInfo['module'], $this->Risk27kInfo['descp'], $this->Risk27kInfo['who'], $this->Risk27kInfo['whoAU'], $this->Risk27kInfo['dueDate']);

        $pStatement = $this->dbHand->prepare($sql);

        if ($pStatement->execute()) {

            $lastId = customLastInsertId($this->dbHand, 'actions', 'ID');
            //$lastId = $this->dbHand->lastInsertId();

            return $lastId;
        } else {
            /* dump_array($pStatement->errorInfo());
              exit; */
        }
    }

    public function addRisk27kDeleteAssest($v) {
        $this->val = $v;
        echo $sql1 = sprintf("DELETE FROM %s.risk27kAssest WHERE recordID = %d  AND  assestClass = '" . $this->val . "'", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addTrng_equipment() {

        $sql1 = sprintf("DELETE FROM %s.trng_equipment WHERE recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addDelete_equipment() {

        $sql1 = sprintf("DELETE FROM %s.trng_room_equipment WHERE recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function getEquipmentManager() {

        $sql1 = sprintf("SELECT * FROM %s.participant_authorization_stats WHERE sectionName = 'perm_mgr_equip' AND sectionActive = 1", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getEquipmentManagersbyID() {

        $sql1 = sprintf("SELECT distinct participantID FROM %s.participant_authorization_stats WHERE sectionName = 'perm_mgr_equip' AND sectionActive = 1", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getAssetName($id) {
        $this->id = $id;
        $sql1 = sprintf("SELECT * FROM %s.assest_classification WHERE ID = " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function participantData() {

        $sql2 = sprintf("SELECT forename,surname,emailAddress FROM %s.participant_database WHERE participantID = %d", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function participantData44($nam, $sur) {

        $this->nam = $nam;
        $this->sur = $sur;

        $sql2 = sprintf("SELECT * FROM %s.participant_database WHERE forename = '" . $this->nam . "' AND surname='" . $this->sur . "'", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function refernceEquipment($id) {

        $this->id = $id;


        $sql2 = sprintf("SELECT * FROM %s.equipments WHERE equipID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function refernceEquipment1($id) {

        $this->id = $id;


        $sql2 = sprintf("SELECT * FROM %s.equipment_type WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function refernceEquipment2($id) {

        $this->id = $id;


        $sql2 = sprintf("SELECT * FROM %s.equip_classification WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function refernceEquipment3($id) {

        $this->id = $id;


        $sql2 = sprintf("SELECT * FROM %s.equipment_consumables WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function refernceEquipment4($id) {

        $this->id = $id;


        $sql2 = sprintf("SELECT * FROM %s.equipment_consumables_type WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql2);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function addRisk27kDeleteThreat() {
        $sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'threats' ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addRisk27kDeleteVulnerability() {
        $sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'vulnerability' ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addRisk27kDeleteImprovements() {
        $sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'improvements' ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addRisk27kDeleteControls() {
        $sql1 = sprintf("DELETE FROM %s.risk27kReport WHERE recordID = %d AND name = 'controls' ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addRisk27kDeleteEquipment() {

        $sql1 = sprintf("DELETE FROM %s.risk27kaddEquipment WHERE recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql1);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();
    }

    public function addRisk27kAsses() {

        //if (count($this->Risk27kInfo) > 0) {

        $ins = "INSERT INTO %s.risk27kAssest (recordID ,assestClass ,assestType, assestComment,threats,vulnerability,noAsset,noApp,assetDesc) VALUES";
        $ins .= "( %d ,'%s' ,'%s' ,'%s','%s','%s','%s','%s','%s')";

        $assetstype = trim($this->Risk27kInfo['type'], ",");
        $assetsdesc = trim($this->Risk27kInfo['desc'], ',');
        $assetstype1 = isset($this->Risk27kInfo['threats']) ? implode(",", $this->Risk27kInfo['threats']) : '';
        $assetsvuln1 = isset($this->Risk27kInfo['vulnerability']) ? implode(",", $this->Risk27kInfo['vulnerability']) : '';

        $ins = sprintf($ins, _DB_OBJ_FULL, $this->Risk27kId, $this->Risk27kInfo['class'], $assetstype, $this->Risk27kInfo['comment'], $assetstype1, $assetsvuln1, $this->Risk27kInfo['noAsset'], $this->Risk27kInfo['noApp'], $assetsdesc);

        $pStatement = $this->dbHand->prepare($ins);
        $pStatement->execute();
        //}
    }

    public function addTrngEquipment() {

        if (count($this->Risk27kInfo) > 0) {

            $ins = "INSERT INTO %s.trng_equipment (recordID ,equipClass ,equipType, name) VALUES";
            $ins .= "( %d ,'%s' ,'%s' ,'%s')";

            $assetstype = implode(",", $this->Risk27kInfo['type']);

            $ins = sprintf($ins, _DB_OBJ_FULL, $this->Risk27kId, $this->Risk27kInfo['class'], $assetstype, $this->Risk27kInfo['name']);

            $pStatement = $this->dbHand->prepare($ins);
            $pStatement->execute();
        }
    }

    

    public function addRisk27kThreats() {
        $ins = "INSERT INTO %s.risk27kReport (recordID ,name ,details, comment) VALUES";
        $ins .= "( %d ,'%s' ,'%s' ,'%s')";


        $ins = sprintf($ins, _DB_OBJ_FULL, $this->Risk27kId, $this->Risk27kInfo['name'], $this->Risk27kInfo['nameID'], $this->Risk27kInfo['comment']);

        $pStatement = $this->dbHand->prepare($ins);
        $pStatement->execute();
    }

    public function addRisk27kThreats3() {

        $sql = sprintf("Update %s.risk27kReport SET comment = '" . $this->Risk27kInfo['comment'] . "',summary='" . $this->Risk27kInfo['summary'] . "' WHERE name='threats' AND  recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();
    }

    public function addData() {
        $ins = "INSERT INTO %s.risk27kReport (recordID ,name ,details, comment) VALUES";
        $ins .= "( %d ,'%s' ,'%s' ,'%s')";
if (isset($this->Risk27kInfo['nameID']))
        $assetstype = implode(",", $this->Risk27kInfo['nameID']);
else
     $assetstype='';
        //	echo $assetstype;
        $ins = sprintf($ins, _DB_OBJ_FULL, $this->Risk27kId,  $assetstype, $this->Risk27kInfo['nameID'], $this->Risk27kInfo['comment']);

        $pStatement = $this->dbHand->prepare($ins);
        $pStatement->execute();
    }

    public function addEmail($id, $email) {

        $this->id = $id;
        $this->email = $email;

        $sql = sprintf("Update %s.risk27k SET nEmail= '" . $this->email . "' WHERE  ID =" . $this->id, _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();
    }

    public function addRisk27kEquipment() {
        if (is_array($this->Risk27kInfo['threats']))
            $files = implode(',', $this->Risk27kInfo['threats']);
        else
            $files ='';
         
        $sql = sprintf("INSERT INTO %s.risk27kaddEquipment (recordID ,addEquipment,threats,reason,app)
						VALUES ( %d ,'%s' ,'%s' ,'%s' ,'%s')"
        , _DB_OBJ_FULL
        , $this->Risk27kId
        , $this->Risk27kInfo['equipment']
        , $files
        , $this->Risk27kInfo['comment']
        , $this->Risk27kInfo['noApp']);

        $pStatement = $this->dbHand->prepare($sql);



        $pStatement->execute();
        /* dump_array($pStatement->errorInfo());
          exit; */

        //$this->Risk27kId = $this->dbHand->lastInsertId();
    }

    /**
     * This method is used to view the Risk 27k information.
     */
    public function viewRisk27k() {



        $sql = sprintf("SELECT * FROM %s.risk27k WHERE ID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function displayThreats() {


        $sql = "SELECT * FROM %s.hazard_classification WHERE hpcID = 14 ORDER BY CAST([secondaryhazard] AS VARCHAR(8000)) ASC";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function viewRisk27kRef() {



        echo $sql = sprintf("SELECT reference FROM %s.risk27k WHERE reference = '%s' ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kAssest($v = 0) {
        $this->v = $v;
       $sql = sprintf("SELECT * FROM %s.risk27kAssest WHERE recordID = %d AND assestClass='" . $this->v . "'", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kAssest79() {

      $sql = sprintf("SELECT A.* FROM %s.risk27kAssest A inner join %s.assest_primary_classification C on A.assestClass=C.ID WHERE recordID = %d order by risk27K", _DB_OBJ_FULL,_DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewTrngEquipment() {

        $sql = sprintf("SELECT * FROM %s.trng_equipment WHERE recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRoomEquipment() {

        $sql = sprintf("SELECT * FROM %s.trng_room_equipment WHERE recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kThreat() {

        $sql = sprintf("SELECT * FROM %s.risk27kReport WHERE recordID = %d  AND name = 'threats'", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kVulnerability() {

        $sql = sprintf("SELECT * FROM %s.risk27kReport WHERE recordID = %d  AND name = 'vulnerability'", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kThreat333() {

        $sql = sprintf("SELECT * FROM %s.hazard_classification WHERE ID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kThreat1() {

        $sql = sprintf("SELECT * FROM %s.risk27kReport WHERE recordID = %d  AND name = 'threats'", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewRisk27kaddEquipment() {

        $sql = sprintf("SELECT * FROM %s.risk27kaddEquipment WHERE recordID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewParticipantRisk27k() {

        $sql = sprintf("SELECT * FROM %s.participant_locationgram WHERE participantID = %d  AND sectionName ='risk27k'", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /**
     * This method is used to edit the Risk 27k
     *
     * Array Variables : description,who,business_unit,when
     */
    public function editRisk27k() {

        $sql = sprintf("UPDATE %s.risk27k SET description = '%s' ,
									who = %d ,
									locId = %d ,
									businessUnit = '%s' ,
									whenDate = '%s'
									WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['description']
                , $this->Risk27kInfo['who']
                , $this->Risk27kInfo['location']
                , $this->Risk27kInfo['business_unit']
                , format_date_for_mysql($this->Risk27kInfo['whenDate'])
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        //exit;
    }

    /**
     * This method is used to manage Assets
     *
     * Array Variables : assets,assets_reason
     */
    public function manageAssets() {

        $sql = sprintf("UPDATE %s.risk27k SET assets = '%s' ,
				assetsReason = '%s',noEquipment = '%s',noApp = '%s',reason = '%s',the = '%s',vuln = '%s'
						
						WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['assets']
                , $this->Risk27kInfo['assets_reason']
                , $this->Risk27kInfo['noEquipment']
                , $this->Risk27kInfo['noApp']
                , $this->Risk27kInfo['reason']
                , $this->Risk27kInfo['threats']
                , $this->Risk27kInfo['vulnerability']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage threats
     *
     * Array Variables : threats,threats_summary,no_threat,threats_reason
     */
    public function manageThreats() {

        $sql = sprintf("UPDATE %s.risk27k SET threats = '%s' ,
						threatsSummary = '%s',
						noThreat = '%s',
						threatReason = '%s'
						WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['threats']
                , $this->Risk27kInfo['threats_summary']
                , $this->Risk27kInfo['no_threat']
                , $this->Risk27kInfo['threats_reason']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage CIA
     *
     * Array Variables : cia_confidentiality,cia_integrity,cia_availability
     */
    public function manageCia() {

        $sql = sprintf("UPDATE %s.risk27k SET ciaConfidentiality = %d ,
						ciaIntegrity = %d,
						ciaAvailability = %d
						WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['cia_confidentiality']
                , $this->Risk27kInfo['cia_integrity']
                , $this->Risk27kInfo['cia_availability']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage Risk Rating 1
     *
     * Array Variables : likelihood,impact,risk_rating,risk_rating_color
     */
    public function manageRiskRating1() {

        echo $sql = sprintf("UPDATE %s.risk27k SET likelihood1 = %d,
									impact1 = %d,
									riskRating1 = '%s',
									riskRatingColor1 = '%s'
									WHERE ID = %d "
        , _DB_OBJ_FULL
        , $this->Risk27kInfo['likelihood']
        , $this->Risk27kInfo['impact']
        , $this->Risk27kInfo['risk_rating']
        , $this->Risk27kInfo['risk_rating_color']
        , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage improvement
     *
     * Array Variables : source,path,worker,no_improvement,improvement_reason,improvement_ids = array(),
     * improvement = array()
     */
    public function manageImprovement() {

 echo      $sql = sprintf("UPDATE %s.risk27k SET atSource = '%s' ,
									atPath = '%s',
									atWorker = '%s',
									noImprovement = '%s',
									improvementReason = '%s',
									noImprovementFiles = '%s',
                                                                        improvement_d = '%s'
									WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['source']
                , $this->Risk27kInfo['path']
                , $this->Risk27kInfo['worker']
                , $this->Risk27kInfo['no_improvement']
                , $this->Risk27kInfo['improvement_reason']
                , $this->Risk27kInfo['file']
                , $this->Risk27kInfo['improvement']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);
//exit();
        $pStatement->execute();

        if (count($this->Risk27kInfo['improvement_ids'])) {
            $improvement_ids = "";
            foreach ($this->Risk27kInfo['improvement_ids'] as $key => $value) {

                if (!$value) {
                    // add action
                    $this->actionData = array('module_name' => 'risk27k', 'description' => $this->Risk27kInfo['improvement'][$key], 'who' => 0, 'due_date' => '01/01/1900');
                    $this->actionHandling->setActionDetails(0, $this->actionData);
                    $action_id = $this->actionHandling->addAction();
                    $improvements .= $action_id . ',';
                } else {

                    $improvements .= $value . ',';
                }
            }

            $improvements = rtrim($improvements, ',');
        }

        if ($this->Risk27kInfo['no_improvement']) {
            $risk_data = $this->viewRisk27k();

            //echo $risk_data['improvements'];

            if ($risk_data['improvements'] != "" || $risk_data['improvements'] != 0) {

                $improvements_arr = explode(',', $risk_data['improvements']);
                if (count($improvements_arr)) {
                    foreach ($improvements_arr as $value) {
                        $this->actionHandling->setActionDetails($value, "");
                        $improvement = $this->actionHandling->deleteAction();
                    }
                }
            }

            $improvements = 0;
        }


        $sql = sprintf("UPDATE %s.risk27k SET improvements = '%s'
						WHERE ID = %d ", _DB_OBJ_FULL, $improvements, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$improvements);
          $pStatement->bindParam(2,$this->Risk27kId); */

        $pStatement->execute();
    }

    /**
     * This method is used to update files id
     */
    public function addFiles() {

        $record_data = $this->viewRisk27k();

        $new_files_id_string = $record_data['uploadFilesID'] . ',' . $this->Risk27kInfo['file_id'];
        $new_files_id_string = ltrim($new_files_id_string, ',');

        $sql2 = sprintf(" UPDATE %s.risk27k SET uploadFilesID = %d WHERE
						ID = %d", _DB_OBJ_FULL, $new_files_id_string, $this->Risk27kId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$new_files_id_string);
          $pStatement2->bindParam(2,$this->Risk27kId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to delete file id
     */
    public function deleteFile() {

        $record_data = $this->viewRisk27k();

        $files_id_arr = explode(',', $record_data['uploadFilesID']);

        if (count($files_id_arr)) {
            foreach ($files_id_arr as $value) {
                if ($value != $this->Risk27kInfo['file_id']) {
                    $new_files_id_string .= $value . ',';
                }
            }
            $new_files_id_string = rtrim($new_files_id_string, ',');

            $sql2 = sprintf(" UPDATE %s.risk27k SET uploadFilesID = %d WHERE
							ID = %d"
                    , _DB_OBJ_FULL
                    , $new_files_id_string
                    , $this->Risk27kId);

            $pStatement2 = $this->dbHand->prepare($sql2);

            /* $pStatement2->bindParam(1,$new_files_id_string);
              $pStatement2->bindParam(2,$this->Risk27kId); */

            $pStatement2->execute();
        }
    }

    /**
     * This method is used to manage risk rating 2
     *
     * Array Variables : likelihood,impact,risk_rating,risk_rating_color
     */
    public function manageRiskRating2() {

      $sql = sprintf("UPDATE %s.risk27k SET likelihood2 = '%s' ,
						impact2 = '%s',
						riskRating2 = '%s',
						riskRatingColor2 = '%s'
						WHERE ID = %d "
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['likelihood']
                , $this->Risk27kInfo['impact']
                , $this->Risk27kInfo['risk_rating']
                , $this->Risk27kInfo['risk_rating_color']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage priority
     *
     * Array Variables : time_trouble,net_impact,priority
     */
    public function managePriority() {

        $sql = sprintf("UPDATE %s.risk27k SET timeTrouble = '%s' ,
						netImpact = '%s',
						priority = '%s'
						WHERE ID = '%s' "
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['time_trouble']
                , $this->Risk27kInfo['net_impact']
                , $this->Risk27kInfo['priority']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    /**
     * This method is used to manage action
     *
     * Array Variables : improvement,who,when,improvement_id
     */
    public function manageAction() {

        $this->actionData = array('description' => $this->Risk27kInfo['action'], 'who' => $this->Risk27kInfo['who'], 'whoAU' => $this->Risk27kInfo['manager'],'who2AU' => $this->Risk27kInfo['who2AU'],
            'due_date' => $this->Risk27kInfo['when']);
        
        
        $this->actionHandling->setActionDetails($this->Risk27kInfo['improvement_id'], $this->actionData);
        $this->actionHandling->updateAction2015();

        $save_finish = (int) $_POST['save_finish'];
        $update_save = (int) $_POST['update_save'];

        $sql_query = sprintf("SELECT ID,threatsSummary, improvements, reference, locID, businessUnit as buID FROM %s.risk27k
				WHERE improvements IS NOT NULL
				WHERE ID = %s
				", _DB_OBJ_FULL, $this->Risk27kInfo['improvement_id']);
        $pStatement = $this->dbHand->prepare($sql_query);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        //dump_array($result);


        $res = $this->actionHandling->viewRisk27kSelectDetail($this->Risk27kInfo['improvement_id']);


        if ($save_finish == '1') { // Action Raised
            $emailObj = new actionEmailHelper($value['action_id']);
            $who = $emailObj->getwhoDetails();

            $data = array(
                'singleColData' => array(
                    'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk27k_assessment.php?filter_date=">CLICK</a> Here to View Risk 27K Action'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $this->Risk27kInfo['ref']
                    )
                )
            );


            $emailObj->appendInfo($data);

            $emailObj->sendEmail('A Risk27K Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

            $who = $emailObj->getAUDetails();

            $sentence = array('sentence' => "You have an action to approve the following risk27K Action");
            $emailObj->appendInfo($sentence);
            $who = $emailObj->getAUDetails();
            $emailObj->sendEmail('A risk27K Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');


            $this->actionHandling->UpdateStatus($this->Risk27kInfo['improvement_id']);

            $emailObj = new actionEmailHelper($this->Risk27kInfo['improvement_id']);
            $who = $emailObj->getwhoDetails();

            //$slawdata = $this->getActionsbyID($action_id);

            $sentence = array('sentence' => array("You have an action to carry out the following risk27K Action"));
            $emailObj->appendInfo($sentence);

            $data = array(
                'singleColData' => array(
                    'click-here-url' => 'Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/action_tracker/risk27k_assessment.php?filter_date=">CLICK</a> Here to View Risk 27K Action'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $res["reference"]
                    )
                )
            );


            $emailObj->appendInfo($data);



            $emailObj->sendEmail('A Risk27K Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

            $who = $emailObj->getAUDetails();

            $sentence = array('sentence' => "You have an action to approve the following risk27K Action");
            $emailObj->appendInfo($sentence);
            $who = $emailObj->getAUDetails();
            $emailObj->sendEmail('A risk27K Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
        }

        $action_id = $this->actionHandling->updateAction();
    }

    /**
     * This method is used to view the improvement Risk 27k information.
     */
    public function viewImprovementRisk27k() {

        $sql = sprintf("SELECT atSource,atPath,atWorker,improvements,noImprovement,improvementReason FROM %s.risk27k
					   WHERE ID = %d", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($resultSet)) {

            if ($resultSet[0]['improvements'] != "") {

                $improvement_arr = explode(',', $resultSet[0]['improvements']);

                if (count($improvement_arr)) {
                    foreach ($improvement_arr as $value) {
                        $this->actionHandling->setActionDetails($value, "");
                        $improvement = $this->actionHandling->viewAction();
                        $riskImprovements[$value] = $improvement;
                    }
                }

                $resultSet[0]['improvements'] = $riskImprovements;
            }
        }

        return $resultSet[0];
    }

    public function viewActionsRisk27k() {

        $sql = sprintf("SELECT * FROM %s.risk27k
					   WHERE ID = %d", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



        if ($resultSet['improvements'] != "") {

            $improvement_arr = explode(',', $resultSet['improvements']);

            if (count($improvement_arr)) {
                foreach ($improvement_arr as $value) {
                    $this->actionHandling->setActionDetails($value, "");
                    $improvement = $this->actionHandling->viewAction();
                    $riskImprovements[$value] = $improvement;
                }
            }

            $resultSet['improvement'] = $riskImprovements;
        }


        return $resultSet;
    }

    /**
     * This method is used to delete the Risk 27k
     */
    public function deleteRisk27k() {

        $sql = sprintf("DELETE FROM %s.risk27k WHERE ID = %d", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
    }

    /**
     * This method is used to archive the Risk 27k
     */
    public function archiveRisk27k() {

        $sql = sprintf("UPDATE %s.risk27k SET archive = '%s' WHERE ID = %d", _DB_OBJ_FULL, $this->Risk27kInfo['archive'], $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
    }

    /**
     * This method is used to remove the Risk 27k
     */
    public function purgeRisk27k() {
        
    }

    /**
     * This method is used to get last record id
     */
    public function lastRecordId() {
        return $this->Risk27kId;
    }

    /**
     * This method is used to view  All the Risk 27k information.
     */
    public function viewAllRisk27k() {
		$archive= isset($this->Risk27kInfo['archive']) ? $this->Risk27kInfo['archive'] : 0;
        $sql = sprintf("SELECT * FROM %s.risk27k WHERE archive = %d ORDER BY ID DESC ", _DB_OBJ_FULL, $archive);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function emailName($id) {
        $this->id = $id;
        $sql = sprintf("SELECT nEmail FROM %s.risk27k WHERE ID =  " . $this->id, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewBURisk27k($buID) {
        $this->buID = $buID;
        $sql = sprintf("SELECT * FROM %s.risk27k WHERE locId = %d AND archive = %d ORDER BY ID DESC", _DB_OBJ_FULL, $this->buID, $this->Risk27kInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /**
     * This method is used to view  All the Risk 27k information.
     */
    public function getRisk27kByLocation() {
        $sql = sprintf("SELECT * FROM %s.risk27k WHERE locID = %d", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);
        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();

        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getOutstandingActionsdepreciated($p_overdue) {

        if ($p_overdue) {
            $data = $this->actionHandling->viewOverdueActions('risk27k');
        } else {
            $data = $this->actionHandling->viewAllActionByModule('risk27k');
        }

        if (count($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT M.reference,M.businessUnit,M.ID AS risk_id FROM %s.risk27k M
								WHERE M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' "
                        , _DB_OBJ_FULL
                        , $search_value1
                        , $search_value2
                        , $search_value3
                        , $search_value4);

                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$search_value1);
                  $pStatement->bindParam(2,$search_value2);
                  $pStatement->bindParam(3,$search_value3);
                  $pStatement->bindParam(4,$search_value4); */

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (count($action_data)) {

                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['businessUnit'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                        $new_data[$i]['risk_id'] = $value2['risk_id'];
                    }
                    $i++;
                }
            }
        }
        return $new_data;
    }

    public function addOutstandingAction() {

        $sql = sprintf("SELECT improvements FROM %s.risk27k WHERE ID = %d ", _DB_OBJ_FULL, $this->Risk27kId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->Risk27kId);
        $pStatement->execute();

        $improvements = $pStatement->fetchColumn();
        $new_improvements = $improvements . ',' . $this->Risk27kInfo['new_improvement'];

        $sql2 = sprintf("UPDATE %s.risk27k SET improvements = '%s' WHERE ID = %d "
                , _DB_OBJ_FULL
                , $new_improvements
                , $this->Risk27kId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$new_improvements);
          $pStatement2->bindParam(2,$this->Risk27kId); */
        $pStatement2->execute();
    }

    public function updateStatus() {

        $sql = sprintf("UPDATE %s.risk27k SET status = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
    }

    public function sendActionAlerts($p_record_id) {

        $this->Risk27kId = $p_record_id;

        $record_data = $this->viewRisk27k();


        $improvement_data = $this->viewImprovementRisk27k();


        if (count($improvement_data['improvements'])) {
            $i = 0;
            foreach ($improvement_data['improvements'] as $value) {
                $email_data[$i]['reference'] = $record_data['reference'];
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];

                $this->actionHandling->updateStatus($value['ID']);
                $i++;
            }
        }



        return $email_data;
    }

    /**
     * This method is used to manage Control Tab data
     */
    public function updateControl() {

      $sql = sprintf("UPDATE %s.risk27k SET controlAlongPath = '%s',
									controlAlongWorker = '%s',
									controlSymbols = '%s',
									controlSummary = '%s',
									controlFiles = '%s'
								WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->Risk27kInfo['along_path']
                , $this->Risk27kInfo['at_worker']
                , $this->Risk27kInfo['control_symbol']
                , $this->Risk27kInfo['control_summary']
                , $this->Risk27kInfo['file']
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();


     /*   dump_array($pStatement->errorInfo());
          exit; */
    }

    /**
     * This method is used to add an risk 27 k control files
     * id, uploadfilesid
     */
    public function addControlFile() {

        $files_arr = $this->getControlFile();
        $files = implode(',', $files_arr);

        $new_files = $files . ',' . $this->Risk27kInfo['file_id'];

        $sql = sprintf("UPDATE %s.risk27k SET controlFiles = '%s' WHERE ID = %d"
                , _DB_OBJ_FULL
                , $new_files
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$new_files);
          $pStatement->bindParam(2,$this->Risk27kId); */

        $pStatement->execute();
    }

    /**
     * This method is used to get an risk 27 k control files
     * id, identifier
     */
    public function getControlFile() {

        $sql = sprintf("SELECT controlFiles FROM %s.risk27k WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetchColumn();

        $files_list = explode(',', $resultSet);
        return $files_list;
    }

    /**
     * This method is used to delete an risk 27 k control files
     * id
     */
    public function deleteControlFile() {
        $files_arr = $this->getControlFile();

        $new_files = array();

        if (count($files_arr)) {

            foreach ($files_arr as $value) {

                if ($value != $this->Risk27kInfo['file_id']) {
                    $new_files[] = $value;
                }
            }
        }

        $files = implode(',', $new_files);

        $sql = sprintf("UPDATE %.risk27k SET controlFiles = '%s' WHERE ID = %d"
                , _DB_OBJ_FULL, $files
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function addImprovementFile() {
        $files_arr = $this->getImprovementFile();
        $files = implode(',', $files_arr);

        $new_files = $files . ',' . $this->Risk27kInfo['file_id'];

        $sql = sprintf("UPDATE %s.risk27k SET improvementFiles = '%s' WHERE ID = %d"
                , _DB_OBJ_FULL, $new_files, $this->Risk27kId);
        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$new_files);
          $pStatement->bindParam(2,$this->Risk27kId); */

        $pStatement->execute();
    }

    /**
     * This method is used to get an risk 27 k control files
     * id, identifier
     */
    public function getImprovementFile() {

        $sql = sprintf("SELECT improvementFiles FROM %s.risk27k WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetchColumn();

        $files_list = explode(',', $resultSet);
        return $files_list;
    }

    public function displayReportBybu($business_unit_id) {

        $this->bu_id = $business_unit_id;

        $sql = "SELECT ID FROM %s.risk27k WHERE businessUnit = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->bu_id);
        $stmt = $this->dbHand->prepare($psql);
        //$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $colcount = $stmt->rowCount();

        if ($colcount) {
            return $result;
        } else {
            return 0;
        }
    }

    public function getAssestType() {

        $sql = sprintf("SELECT * FROM %s.assest_classification"
                , _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function gettname($id) {
        $this->id = $id;
        $sql = sprintf("SELECT secondaryHazard FROM %s.hazard_classification WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->id);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */

        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getvname($id) {
        $this->id = $id;
        $sql = sprintf("SELECT vulnerability FROM %s.asset_vulnerability WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->id);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getaname($id) {
        $this->id = $id;
        $sql = sprintf("SELECT hazardName FROM %s.control_measures_hazard WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->id);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getrname($id) {
        $this->id = $id;
        $sql = sprintf("SELECT name FROM %s.impact_measure WHERE ID = %d"
                , _DB_OBJ_FULL
                , $this->id);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /* public function gettname($id) {
      $this->id =>$id;
      $sql = sprintf("SELECT * FROM %s.hazard_classification WHERE ID = ".$this->id
      , _DB_OBJ_FULL);

      $pStatement = $this->dbHand->prepare($sql);

      /* $pStatement->bindParam(1,$this->Risk27kId); */

    //$pStatement->execute();
    //$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
    //return $resultSet;
    //}

    /* public function getvname($id) {
      $this->id =>$id;
      $sql = sprintf("SELECT  FROM %s.asset_vulnerability WHERE ID = ".$this->id
      , _DB_OBJ_FULL);

      $pStatement = $this->dbHand->prepare($sql);

      /* $pStatement->bindParam(1,$this->Risk27kId); */
    //	$pStatement->execute();
    //$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
    //return $resultSet;
    //}

    public function getall77($id, $t) {
        $this->id = $id;
        $this->t = $t;
        $sql = sprintf("SELECT * FROM %s.risk27kAssest WHERE recordID = " . $this->id . " AND assestClass = '" . $this->t . "'"
                , _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function getall78($id, $t) {
        $this->id = $id;
        $this->t = $t;
        $sql = sprintf("SELECT * FROM %s.risk27kReport WHERE recordID = " . $this->id . " AND name = '" . $this->t . "'"
                , _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->Risk27kId); */
        $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /**
     * This method is used to delete an risk 27 k control files
     * id
     */
    public function deleteImprovementFile() {
        $files_arr = $this->getImprovementFile();

        $new_files = array();

        if (count($files_arr)) {

            foreach ($files_arr as $value) {

                if ($value != $this->Risk27kInfo['file_id']) {
                    $new_files[] = $value;
                }
            }
        }

        $files = implode(',', $new_files);

        $sql = sprintf("UPDATE %s.risk27k SET improvementFiles = '%s' WHERE ID = %d"
                , _DB_OBJ_FULL
                , $files
                , $this->Risk27kId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$files);
          $pStatement->bindParam(2,$this->Risk27kId); */

        $pStatement->execute();
    }

    /*     * *
     * * This method is used to get
     * * listing records for Export
     * */

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'full') {
            return $this->get27KExportDataFull();
        } else {

            return $this->get27KExportData();
        }
    }

    public function get27KExportDataFull() {

        $is_admin = false;
        $show_participant_name = false;


        if ($tab_type == 'other_completed' || $tab_type == 'me_completed') {
            $is_admin = false;
        } else if ($tab_type == 'other_pending' || $tab_type == 'other_completed') {
            $show_participant_name = true;
        }



        $heading = array(array('refrence' => 'Reference #', 'When' => 'When', 'who' => 'Who', 'loc' => 'Location', 'desc' => 'Description', 'bu' => 'Business Unit', 'ed' => 'Equipment Type| Detail', 'et' => 'Equipment Threats', 'ev' => 'Equipment Vulnerability', 'id' => 'Information Type| Detail', 'it' => 'Information Threats', 'iv' => 'Information Vulnerability', 'cd' => 'Company Type| Detail', 'ct' => 'Company Threats', 'cv' => 'Company Vulnerability', 'pd' => 'People Type| Detail', 'pt' => 'People Threats', 'pv' => 'People Vulnerability', 'nd' => 'Network Type| Detail', 'nt' => 'Network Threats', 'nv' => 'Network Vulnerability', 'sd' => 'Software Type| Detail', 'st' => 'Software Threats', 'sv' => 'Software Vulnerability', 'sid' => 'Sites Type| Detail', 'sit' => 'Sites Threats', 'siv' => 'Sites Vulnerability', 'prd' => 'Process Type| Detail', 'prt' => 'Process Threats', 'prv' => 'Process Vulnerability', 'tc' => 'Threats Comment', 'vc' => 'Vulnerability Comment', 'c' => 'Confidentiality', 'i' => 'Integrity', 'a' => 'Availability', 'al' => 'Along the path ', 'aw' => 'At the worker ', 'cms' => 'Control Measures Summary ', 'l' => 'Likelihood', 'i' => 'Impact', 'ri' => 'Risk Rating', 'rc' => 'Risk Color', 'as' => 'At the Source', 'ap' => 'Along the Path', 'atw' => 'At the worker', 'l2' => 'Likelihood2', 'i2' => 'Impact2', 'ri2' => 'Risk Rating2', 'rc2' => 'Risk Color2', 'ni' => 'Net Impact', 'pc' => 'Priority', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'adue' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.'));

        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setRisk27kInfo(0, array('archive' => $archive_session));
        $view_data = $this->viewAllRisk27k();

        //dump_array($view_data);
        //exit;


        $result = array();

        if (count($view_data)) {
            $i = 0;
            foreach ($view_data as $value) {

                $insp_id = $value['ID'];
                $equip = $this->getall77($insp_id, '1');

                $eui = explode(',', $equip['threats']);
                $evi = explode(',', $equip['vulnerability']);
                $e = 0;
                foreach ($eui as $val) {
                    $t = $this->gettname($val);
                    $et[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $et1 = implode(",", $et);

                $e = 0;
                foreach ($evi as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $ev[$e] = $t['vulnerability'];
                    $e++;
                }

                $ev1 = implode(",", $ev);
                $info = $this->getall77($insp_id, '2');

                $it = explode(',', $info['threats']);
                $iv = explode(',', $info['vulnerability']);
                $e = 0;
                foreach ($it as $val) {
                    $t = $this->gettname($val);
                    $it_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $it_v1 = implode(",", $it_v);

                $e = 0;
                foreach ($iv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $iv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $iv_val1 = implode(",", $iv_val);
                $com = $this->getall77($insp_id, '3');

                $ct = explode(',', $com['threats']);
                $cv = explode(',', $com['vulnerability']);
                $e = 0;
                foreach ($ct as $val) {
                    $t = $this->gettname($val);
                    $ct_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $ct_v1 = implode(",", $ct_v);

                $e = 0;
                foreach ($cv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $cv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $cv_val1 = implode(",", $cv_val);

                $peo = $this->getall77($insp_id, '4');

                $pt = explode(',', $peo['threats']);
                $pv = explode(',', $peo['vulnerability']);
                $e = 0;
                foreach ($pt as $val) {
                    $t = $this->gettname($val);
                    $pt_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $pt_v1 = implode(",", $pt_v);

                $e = 0;
                foreach ($pv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $pv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $pv_val1 = implode(",", $pv_val);

                $net = $this->getall77($insp_id, '5');

                $nt = explode(',', $net['threats']);
                $nv = explode(',', $net['vulnerability']);
                $e = 0;
                foreach ($nt as $val) {
                    $t = $this->gettname($val);
                    $nt_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $nt_v1 = implode(",", $nt_v);

                $e = 0;
                foreach ($nv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $nv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $nv_val1 = implode(",", $nv_val);

                $sot = $this->getall77($insp_id, '6');

                $st = explode(',', $sot['threats']);
                $sv = explode(',', $sot['vulnerability']);
                $e = 0;
                foreach ($st as $val) {
                    $t = $this->gettname($val);
                    $st_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $st_v1 = implode(",", $st_v);

                $e = 0;
                foreach ($sv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $sv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $sv_val1 = implode(",", $sv_val);
                $sit = $this->getall77($insp_id, '7');

                $sit = explode(',', $sit['threats']);
                $siv = explode(',', $sit['vulnerability']);
                $e = 0;
                foreach ($sit as $val) {
                    $t = $this->gettname($val);
                    $sit_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $sit_v1 = implode(",", $sit_v);

                $e = 0;
                foreach ($siv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $siv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $siv_val1 = implode(",", $siv_val);
                $pr = $this->getall77($insp_id, '8');

                $pr1 = explode(',', $pr['threats']);
                $pv = explode(',', $pr['vulnerability']);
                $e = 0;
                foreach ($pr1 as $val) {
                    $t = $this->gettname($val);
                    $pr_v[$e] = $t['secondaryHazard'];
                    $e++;
                }

                $pr_v1 = implode(",", $pr_v);

                $e = 0;
                foreach ($pv as $val) {
                    $t = $this->getvname($val);
                    //dump_array($t);
                    $pv_val[$e] = $t['vulnerability'];
                    $e++;
                }

                $pv_val1 = implode(",", $pv_val);

                $the = $this->getall78($insp_id, 'threats');
                $van = $this->getall78($insp_id, 'vulnerability');

                $al = explode(',', $value['controlAlongPath']);

                $e = 0;
                foreach ($al as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $al_val[$e] = $t['hazardName'];
                    $e++;
                }
                $al_val1 = implode(",", $al_val);

                $aw = explode(',', $value['controlAlongWorker']);

                $e = 0;
                foreach ($aw as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $aw_val[$e] = $t['hazardName'];
                    $e++;
                }
                $aw_val1 = implode(",", $aw_val);
                //dump_array($al_val1);
                //dump_array($aw_val1);

                if ($value['likelihood1'] == '1') {
                    $r1 = 'Virtually Certain';
                }
                if ($value['likelihood1'] == '2') {
                    $r1 = 'Very Likely';
                }
                if ($value['likelihood1'] == '3') {
                    $r1 = 'Likely';
                }
                if ($value['likelihood1'] == '4') {
                    $r1 = 'Unlikely';
                }
                if ($value['likelihood1'] == '5') {
                    $r1 = 'Very Unlikely';
                }
                if ($value['likelihood1'] == '6') {
                    $r1 = 'Almost Impossible';
                }

                if ($value['likelihood2'] == '1') {
                    $r2 = 'Virtually Certain';
                }
                if ($value['likelihood2'] == '2') {
                    $r2 = 'Very Likely';
                }
                if ($value['likelihood2'] == '3') {
                    $r2 = 'Likely';
                }
                if ($value['likelihood2'] == '4') {
                    $r2 = 'Unlikely';
                }
                if ($value['likelihood2'] == '5') {
                    $r2 = 'Very Unlikely';
                }
                if ($value['likelihood2'] == '6') {
                    $r2 = 'Almost Impossible';
                }

                $rimp1 = $this->getrname($value['impact1']);
                $rimp2 = $this->getrname($value['impact2']);
                $rimp3 = $this->getrname($value['netImpact']);
                $at = explode(',', $value['atPath']);

                $e = 0;
                foreach ($at as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $at_val[$e] = $t['hazardName'];
                    $e++;
                }
                $at_val1 = implode(",", $at_val);

                $as = explode(',', $value['atSource']);

                $e = 0;
                foreach ($as as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $as_val[$e] = $t['hazardName'];
                    $e++;
                }
                $as_val1 = implode(",", $as_val);

                $atw = explode(',', $value['atWorker']);

                $e = 0;
                foreach ($atw as $val) {
                    $t = $this->getaname($val);
                    //dump_array($t);
                    $atw_val[$e] = $t['hazardName'];
                    $e++;
                }
                $atw_val1 = implode(",", $atw_val);
                //exit;
                $orgObj->setItemInfo(array('id' => $value['businessUnit']));
                $bu_details = $orgObj->displayItemById();

                $locObj->setItemInfo(array('id' => $value['locID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $participant_id = $value['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];


                $result[$i]['ref'] = $value['reference'];

                $result[$i]['when'] = format_date($value['whenDate']);
                $result[$i]['who'] = $participant_name;
                $result[$i]['loc'] = str_replace(',', '-', $location);
                $result[$i]['desc'] = str_replace(',', ' ', $value['description']);
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['ed'] = '';
                $result[$i]['et'] = $et1;
                $result[$i]['ev'] = $ev1;
                $result[$i]['id'] = '';
                $result[$i]['it'] = $it_val1;
                $result[$i]['iv'] = $iv_val1;
                $result[$i]['cd'] = '';
                $result[$i]['ct'] = $ct_val1;
                $result[$i]['cv'] = $cv_val1;
                $result[$i]['pd'] = '';
                $result[$i]['pt'] = $pt_val1;
                $result[$i]['pv'] = $pv_val1;
                $result[$i]['nd'] = '';
                $result[$i]['nt'] = $nt_val1;
                $result[$i]['nv'] = $nv_val1;
                $result[$i]['sd'] = '';
                $result[$i]['st'] = $st_val1;
                $result[$i]['sv'] = $sv_val1;
                $result[$i]['sid'] = '';
                $result[$i]['sit'] = $sit_val1;
                $result[$i]['siv'] = $siv_val1;
                $result[$i]['prd'] = '';
                $result[$i]['prt'] = $pr_val1;
                $result[$i]['prv'] = $pv_val1;
                $result[$i]['tc'] = $the['comment'];
                $result[$i]['vc'] = $van['comment'];
                $result[$i]['c'] = $value['ciaConfidentiality'];
                $result[$i]['i'] = $value['ciaIntegrity'];
                $result[$i]['a'] = $value['ciaAvailability'];
                $result[$i]['al'] = $al_val1;
                $result[$i]['aw'] = $aw_val1;
                $result[$i]['cms'] = $value['controlSummary'];
                $result[$i]['l'] = $ri;
                $result[$i]['i'] = $rimp1['name'];
                $result[$i]['ri'] = $value['riskRating1'];
                $result[$i]['rc'] = $value['riskRatingColor1'];
                $result[$i]['as'] = $as_val1;
                $result[$i]['at'] = $at_val1;
                $result[$i]['atw'] = $atw_val1;
                $result[$i]['l2'] = $r2;
                $result[$i]['i2'] = $rimp2['name'];
                $result[$i]['ri2'] = $value['riskRating2'];
                $result[$i]['rc2'] = $value['riskRatingColor2'];
                $result[$i]['in'] = $rimp3['name'];
                $result[$i]['pc'] = $value['priority'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $value['improvements'],
                ));

                $data_records7 = $type->displayItemById5();
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];
                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
    }

    public function get27kExportData() {

        $is_admin = false;
        $show_participant_name = false;


        if ($tab_type == 'other_completed' || $tab_type == 'me_completed') {
            $is_admin = false;
        } else if ($tab_type == 'other_pending' || $tab_type == 'other_completed') {
            $show_participant_name = true;
        }



        $heading = array(array('ref' => 'Reference #', 'when' => 'When', 'who' => 'Who', 'loc' => 'Location', 'desc' => 'Description'));

        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setRisk27kInfo(0, array('archive' => $archive_session));
        $view_data = $this->viewAllRisk27k();

        $result = array();

        if (count($view_data)) {
            $i = 0;
            foreach ($view_data as $value) {

                $insp_id = $value['ID'];
                $orgObj->setItemInfo(array('id' => $value['businessUnit']));
                $bu_details = $orgObj->displayItemById();

                $locObj->setItemInfo(array('id' => $value['locID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $participant_id = $value['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];


                $result[$i]['ref'] = $value['reference'];
                //$result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['when'] = format_date($value['whenDate']);
                $result[$i]['who'] = $participant_name;
                $result[$i]['loc'] = str_replace(',', '-', $location);
                $result[$i]['desc'] = str_replace(',', ' ', $value['description']);

                $i++;
            }
        }

        $result = array_merge($heading, $result);
        return $result;
    }

    public function getActionTrackerEmailData($p_record_id) {

        $sql2 = sprintf("SELECT * FROM %s.risk27k ", _DB_OBJ_FULL);
        $sql2 = $sql2 . " WHERE improvements LIKE '" . $p_record_id . "' OR improvements LIKE '%," . $p_record_id . "' OR improvements LIKE '" . $p_record_id . ",%' OR improvements LIKE '%," . $p_record_id . ",%' ";

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

        /*         * * to show the threats ******* */
        $hpc_id = $result[0]['threats'];

        $threat_arr = explode(',', $hpc_id);

        $hazard_list = SetupGeneric::useModule('HazardClassification');

        $hazard_list->setItemInfo(array(
            'id' => 14
        ));
        $data_records = $hazard_list->displayItems();


        if (count($data_records)) {

            foreach ($data_records as $key => $value) {
                $threats[$value['ID']] = $value['secondaryHazard'];
            }
        }
        if (count($threat_arr)) {
            foreach ($threat_arr as $value) {
                $threats_names .= $threats[$value] . ',';
            }
        }
        /*         * ***** *********** */

        if (count($result)) {
            $email_data['bu_id'] = $result[0]['businessUnit'];
            $email_data['reference'] = $result[0]['reference'];
            $email_data['DueDate'] = $result[0]['whenDate'];
            $email_data['threats'] = rtrim($threats_names, ',');
        }

        return $email_data;
    }

    public function getPrimaryAssets($p_id) {
        $sql = sprintf("SELECT * FROM %s.assest_classification where aid= %d order by cast(secondaryAssest as varchar(200))", _DB_OBJ_FULL, $p_id);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getSecondaryAssets($p_id, $p_loc) {
       $sql = sprintf("SELECT * FROM %s.assestMangement where assest_c= %d and flag_v like '%s' and loc=%d order by cast(descp as varchar(200))", _DB_OBJ_FULL, $p_id, "%IS%", $p_loc);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $data) {
            $ids = explode(",", $data["assest_t"]);
            foreach ($ids as $id) {
                $retArray[$id][] = $data;
            }
        }

        return $retArray;
    }

    public function assetEmails($dataemail) {

        $emailObj = new actionEmailHelper(0);

        //
        // setup email
        //
		$who = $emailObj->getwhoDetails();


        $sentence = array('sentence' => array($sentencetext));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => '',
                'details' => "You are hereby informed to make entries for the following assets in the asset mangement database.<BR>" . $dataemail["input"]
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference:</strong>',
                    'right' => $dataemail["ref"]
                ),
                'assignedto' => array(
                    'left' => '<strong>Description:</strong>',
                    'right' => $dataemail["description"]
                ),
                'authorizing' => array(
                    'left' => '<strong>Asset Classification:</strong>',
                    'right' => $dataemail["subject"]
                ),
                'due' => array('left' => '', 'right' => ''
                )
            )
        );

        $emailObj->appendInfo($data);

        $who = array('displayname' => $dataemail["name"], 'email' => $dataemail["email"]);
        $subject = "smart-ISO New Assets for " . $dataemail["subject"];
        return $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function getCriticalProcesses($p_buStr) {

       $sql = sprintf("select * from %s.swimlane where criticalprocess=1  and (archive is null or archive = 0) and buid in (%s)", _DB_OBJ_FULL, $p_buStr);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getOverDueActions($buStr,$date) {
     $this->sql_query = sprintf("select A.id,R.reference,R.improvements,R.improvement_d,R.threatsSummary,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name  from %s.actions A  inner join %s.risk27k R on a.record=R.ID left join %s.locationgram L on R.locID=L.locID left join %s.participant_database P on A.currentWho=P.participantID  where modulename = 'risk27k' and L.locID = %d and approveAU=0 and duedate < '%s'
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr,$date);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getOutstandingActions($buStr,$fdate) {

        $insp_out = SetupGeneric::useModule('InspectionOutstandingAction');
        $outstanding_duration = explode(':', $insp_out->displayItems());

        switch ($outstanding_duration[1]) {
            case 'M' : $interval = '+' . $outstanding_duration[0] . ' MONTH';
                break;
            case 'Y' : $interval = '+' . $outstanding_duration[0] . ' YEAR';
                break;
        }


        $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");

        $this->sql_query = sprintf("select A.id,R.reference,R.improvements,R.improvement_d,R.threatsSummary,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name  from %s.actions A  inner join %s.risk27k R on a.record=R.ID left join %s.locationgram L on R.locID=L.locID left join %s.participant_database P on A.currentWho=P.participantID  where modulename = 'risk27k' and L.locID = %d and approveAU=0 and duedate >= '%s'
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $outstandingDate);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }
    public function getAssets($aid,$loc) {

     $sql = sprintf("select M.assest_t,name,M.ID,M.descp from %s.assestmangement M left join  %s.asset_type T  on M.assest_t=T.id  inner join %s.assest_classification C on T.cID=C.ID where C.aID=%d and loc=%d and flag_v like '%s' order by assest_t", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$aid,$loc,"%IS%");
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
     
	 foreach($result as $row){
	
		 $data[$row['assest_t']]['name']=$row["name"];
		 $data[$row['assest_t']]['data'][$row['ID']]=$row["descp"];
		 
	 }
        return $data;
    }
        public function addRiskFiles() {

        $sql = sprintf("INSERT INTO %s.risk_files (riskID,uploadedFileID) VALUES (%d,'%s',%d)"
                , _DB_OBJ_FULL
                , $this->RiskId
 
                , $this->RiskInfo['file_id']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
}

?>