<?php
/* 
 * *******************************
 * Created by Luong Tran
 * *************************

 */
//require_once '../Vehicle.int.php';
require_once "Action.class.php";
class Vehicle {

   /**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Vehicle Id
	 *@access private
	 */
	private $vehicleId;

	/**
	 *Property to hold Vehicle Info
	 *@access private
	 */
	private $vehicleInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing Vehicle object
	 * @access public
	 */
	public function __construct() {
		 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set vehicle information for the respective object
	 */
	public function setVehicleInfo($p_vehicleId,$p_vehicleInfo) {

		$this->vehicleId		=	$p_vehicleId;
		$this->vehicleInfo		=	$p_vehicleInfo;
	}
	
	public function addPerformInspection(){
	
			echo	$sql2 = sprintf("INSERT INTO %s.perform_vehicle_inspection (vID,dailyInspection,dailyDescp,dailyDate,dailyDateDone,weeklyInspection,weeklyDescp,weeklyDate,weeklyDoneDate,monthlyInspection,monthlyDescp,monthlyDate,monthlyDoneDate)
											VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['vID'],										
											$this->vehicleInfo['dailyInspection'],
											$this->vehicleInfo['dailyDescp'],
											$this->vehicleInfo['dailyInspectionDate'],
											$this->vehicleInfo['dailyDoneDate'],
											$this->vehicleInfo['weeklyInspection'],
											$this->vehicleInfo['weeklyDescp'],
											$this->vehicleInfo['weeklyInspectionDate'],
											$this->vehicleInfo['weeklyDoneDate'],
											$this->vehicleInfo['monthlyInspection'],
											$this->vehicleInfo['monthlyDescp'],
											$this->vehicleInfo['monthlyInspectionDate'],
											$this->vehicleInfo['monthlyDoneDate']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
		
	}
	
		public function addPerformService(){
	
			echo	$sql2 = sprintf("INSERT INTO %s.perform_vehicle_service (vID,done,mileage,odometer)
											VALUES (%d,'%s','%s','%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['vID'],										
											
											$this->vehicleInfo['check'],
											$this->vehicleInfo['comment_box'],
											$this->vehicleInfo['odometer']
											
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
		
	}
	
        	public function addNewVehicle($type,$make,$model,$vari) {
			$this->type = $type;
			$this->make = $make;
			$this->model = $model;
			$this->vari = $vari;
			
			
		 $sql2 = sprintf("INSERT INTO %s.new_vehicle(
							type,make,model,vari)
							VALUES('$this->type','$this->make','$this->model','$this->vari'
							)",
							_DB_OBJ_FULL
							
							);

		$pStatement2 = $this->dbHand->prepare($sql2);

		$pStatement2->execute();
		$pStatement2->errorInfo();

	}

        	public function addEditVehicle($emp_id,$type,$make,$model,$vari) {
			$this->emp_id = $emp_id;
			$this->type = $type;
			$this->make = $make;
			$this->model = $model;
			$this->vari = $vari;
			
			$sql2 = sprintf(" UPDATE %s.new_vehicle SET type = '".$this->type."',
									make = '".$this->make."',
									model = '".$this->model."',
									vari = '".$this->vari."'
									WHERE ID =".$this->emp_id,_DB_OBJ_FULL);

		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$this->incidenceInfo['archive']);
		$pStatement2->bindParam(2,$this->incidenceId);*/

		$pStatement2->execute();
			
			
		 

	}
	
	

	public function addVehicle(){
		
		$sql = sprintf("SELECT * FROM %s.vehicle WHERE id = '%s'",_DB_OBJ_FULL,$this->vehicleInfo['id']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['reference']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {
			throw new ErrorException('Vehicle with this Reference # already exists.');
		} else {
		 echo "dfdsf";

		echo	$sql2 = sprintf("INSERT INTO %s.vehicle (uniqueReference,vehicleType,vehicleMake,vehicleModel,registration,purchaseDate,picture,mileagePurchase,mileageServices,specialServiceMileage,moTNCTDate,licenceDate,insuranceDate,permanentOwnerName,permanentOwnerBU,permanentOwnerContact,temporaryOwnerName,temporaryOwnerBU,temporaryOwnerContact,archive,MoTNCTDocument,licenceDocument,insuranceDocument,document,vari)
											VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['record'],										
											$this->vehicleInfo['vehicleType'],
											$this->vehicleInfo['vehicleMake'],
											$this->vehicleInfo['vehicleModel'],
											$this->vehicleInfo['registration'],
											$this->vehicleInfo['purchaseDate'],
											$this->vehicleInfo['picture'],
											$this->vehicleInfo['mileagePurchase'],
											$this->vehicleInfo['mileageServices'],
											$this->vehicleInfo['specialServiceMileage'],
											$this->vehicleInfo['moTNCTDate'],
											$this->vehicleInfo['licenceDate'],
											$this->vehicleInfo['insuranceDate'],
											$this->vehicleInfo['permanentOwnerName'],
											$this->vehicleInfo['permanentOwnerBU'],
											$this->vehicleInfo['permanentOwnerContact'],
											$this->vehicleInfo['temporaryOwnerName'],
											$this->vehicleInfo['temporaryOwnerBU'],
											$this->vehicleInfo['temporaryOwnerContact'],
											$this->vehicleInfo['archive'],
											$this->vehicleInfo['moTNCTDocument'],
											$this->vehicleInfo['licenceDocument'],
											$this->vehicleInfo['insuranceDocument'],
											$this->vehicleInfo['document'],
											$this->vehicleInfo['vari']);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
			$this->vehicleId = customLastInsertId($this->dbHand,'vehicle','id');
		}
	}
	
	public function addService(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.vehicle_service (vID,servicingRequired,who,mileageServices,services,sContractName,sContractNum,descp,checkFrequency,fTime,whoN,dueDate,actionID)
											VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s',%d,'%s','%s',%d)",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['mileageServices'],
											$this->vehicleInfo['who'],
											$this->vehicleInfo['mileageServices'],
											$this->vehicleInfo['specialServiceMileage'],
											$this->vehicleInfo['contractorName'],
											$this->vehicleInfo['contractorContact'],
											$this->vehicleInfo['description'],
											$this->vehicleInfo['fre'],
											$this->vehicleInfo['time_f'],
											$this->vehicleInfo['whoN'],
											$this->vehicleInfo['today'],
											$this->vehicleInfo['actionID'] 
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
	
	
	}
	
	public function addSetupService(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.vehicle_setup_service (serviceName,descp,mileage,frequency,fTime)
											VALUES ('%s','%s','%s','%s',%d)",_DB_OBJ_FULL,
																				
											$this->vehicleInfo['mileageServices'],
											
											$this->vehicleInfo['description'],
											$this->vehicleInfo['specialServiceMileage'],
											$this->vehicleInfo['fre'],
											$this->vehicleInfo['time_f']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			

			$pStatement2->execute();
	
	
	}
	
	public function addSetupInspection(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.vehicle_setup_inspection (inspectionName,frequency,type)
											VALUES ('%s',%d,%d)",_DB_OBJ_FULL,
																				
											$this->vehicleInfo['inspectionName'],
											
											$this->vehicleInfo['time_f'],
											$this->vehicleInfo['type']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			

			$pStatement2->execute();
	
	
	}
	
	public function addInspectionPre(){
	
	
			
			
			$sql2 = sprintf("INSERT INTO %s.addPre (type,alert,one,two,three)
											VALUES (%d,'%s','%s','%s','%s')",_DB_OBJ_FULL,
																				
											$this->vehicleInfo['type1'],
											
											$this->vehicleInfo['alert'],
											$this->vehicleInfo['one'],
											$this->vehicleInfo['two'],
											$this->vehicleInfo['three']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			

			$pStatement2->execute();
	
	
	}
	public function checkAction(){
	echo	$sql2 = sprintf("SELECT * FROM %s.vehicle_daily_inspection  WHERE dailyInspection = '%s' AND vID = ".$this->vehicleId,_DB_OBJ_FULL,$this->vehicleInfo['dailyInspection']);

		$pStatement = $this->dbHand->prepare($sql2);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$result_service = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $result_service['actionID'];
	
	}
	
	public function checkActionService(){
	echo	$sql2 = sprintf("SELECT * FROM %s.vehicle_service  WHERE servicingRequired = '%s' AND vID = ".$this->vehicleId,_DB_OBJ_FULL,$this->vehicleInfo['mileageServices']);

		$pStatement = $this->dbHand->prepare($sql2);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$result_service = $pStatement->fetch(PDO::FETCH_ASSOC);
		return $result_service['actionID'];
	
	}
	
		public function updatecheckAction(){
	echo	$sql2 = sprintf("UPDATE %s.vehicle_daily_inspection SET dailyWho='%s'  WHERE dailyInspection = '%s' AND vID = ".$this->vehicleId,_DB_OBJ_FULL,$this->vehicleInfo['who'],$this->vehicleInfo['dailyInspection']);

		$pStatement = $this->dbHand->prepare($sql2);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$result_service = $pStatement->fetch(PDO::FETCH_ASSOC);
	//	return $result_service['actionID'];
	
	}
	public function updatepre(){
	echo	$sql2 = sprintf("UPDATE %s.addPre SET alert='%s',one='%s',two='%s',three='%s'  WHERE type =".$this->vehicleInfo['type1'],_DB_OBJ_FULL,$this->vehicleInfo['alert'],$this->vehicleInfo['one'],$this->vehicleInfo['two'],$this->vehicleInfo['three']);

		$pStatement = $this->dbHand->prepare($sql2);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$result_service = $pStatement->fetch(PDO::FETCH_ASSOC);
	//	return $result_service['actionID'];
	
	}
	
	
	public function addDailyInspection(){
	

			//dump_array($result_service);
	
		echo	$sql2 = sprintf("INSERT INTO %s.vehicle_daily_inspection (vID,dailyInspection,dailyDescp,dailywho,dailyName,dailyNum,frequency,type,dueDate,actionID)
											VALUES (%d,'%s','%s','%s','%s','%s',%d,%d,'%s',%d)",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['dailyInspection'],
											$this->vehicleInfo['dailyDescp'],
											$this->vehicleInfo['who'],
											$this->vehicleInfo['name'],
											$this->vehicleInfo['number'],
											$this->vehicleInfo['f_time'],
											$this->vehicleInfo['type_insp'],
											$this->vehicleInfo['dueDate'],
											$this->vehicleInfo['actionID']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
		
		
		
	
	
	}
	public function addMonthlyAction(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.vehicle_monthly_action (vID,dailyInspection,dailyDescp,dailywho,dailyName,dailyNum,frequency,type,dueDate)
											VALUES (%d,'%s','%s','%s','%s','%s',%d,%d,'%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['dailyInspection'],
											$this->vehicleInfo['dailyDescp'],
											$this->vehicleInfo['who'],
											$this->vehicleInfo['name'],
											$this->vehicleInfo['number'],
											$this->vehicleInfo['f_time'],
											$this->vehicleInfo['type_insp'],
											$this->vehicleInfo['dueDate']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
	
	
	}
	
	public function addMonthlyInspection3(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.vehicle_monthly_inspection (vID,dailyInspection,dailyDescp,dailywho,dailyName,dailyNum,frequency,type)
											VALUES (%d,'%s','%s','%s','%s','%s',%d,%d)",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['dailyInspection'],
											$this->vehicleInfo['dailyDescp'],
											$this->vehicleInfo['who'],
											$this->vehicleInfo['name'],
											$this->vehicleInfo['number'],
											$this->vehicleInfo['f_time'],
											$this->vehicleInfo['type_insp']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
	
	
	}
	
	public function addPerformDailyInspection(){
			
			
			$sql2 = sprintf("INSERT INTO %s.perform_vehicle_daily (vID,dateDaily,name,type,frequency,check_ex,comment,checkS,checkU,who,whoAU,date,dailyM,actionID,finish)
											VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%d,%d)",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['date'],
											$this->vehicleInfo['name'],
											$this->vehicleInfo['type'],
											$this->vehicleInfo['frequency'],
											$this->vehicleInfo['check'],
											$this->vehicleInfo['comment'],
											$this->vehicleInfo['checkS'],
											$this->vehicleInfo['checkU'],
											$this->vehicleInfo['who'],
											$this->vehicleInfo['whoAU'],
											$this->vehicleInfo['due'],
											$this->vehicleInfo['d_mileage'],
											$this->vehicleInfo['actionID'],
											$this->vehicleInfo['finish']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			
			

			$pStatement2->execute();
	
	
	}
	
	public function addPerformDailyServicess(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.perform_vehicle_service (vID,service,descp,done,comment,odometer,sDate,cMileage,mileage,actionID,lastDone,checkFrequency,fTime,who)
											VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s',%d,'%s','%s','%s','%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['serviceName'],
											$this->vehicleInfo['serviceDesc'],
											$this->vehicleInfo['check'],
											$this->vehicleInfo['comment'],
											$this->vehicleInfo['odometer'],
											$this->vehicleInfo['sDate'],
											$this->vehicleInfo['cMileage'],
											$this->vehicleInfo['serviceMileage'],
											$this->vehicleInfo['actionID'],
											$this->vehicleInfo['lastDone'],
											$this->vehicleInfo['checkFrequency'],
											$this->vehicleInfo['fTime'],
											$this->vehicleInfo['who']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			
			

			$pStatement2->execute();
	
	
	}
	
	public function addPerformMonthlyInspection(){
			
			
		echo	$sql2 = sprintf("INSERT INTO %s.perform_vehicle_monthly (vID,dateDaily,name,type,frequency,check_ex,comment,checkS,checkU,who,whoAU,date,actionID,finish,dailyM)
											VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%d,%d,'%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['date'],
											$this->vehicleInfo['name'],
											$this->vehicleInfo['type'],
											$this->vehicleInfo['frequency'],
											$this->vehicleInfo['check'],
											$this->vehicleInfo['comment'],
											$this->vehicleInfo['checkS'],
											$this->vehicleInfo['checkU'],
											$this->vehicleInfo['who'],
											$this->vehicleInfo['whoAU'],
											$this->vehicleInfo['due'],
											$this->vehicleInfo['actionID'],
											$this->vehicleInfo['finish'],
											$this->vehicleInfo['d_mileage']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
	
	
	}
	
	public function displaySmartFleetWho($first,$last) {
	
	$this->first = $first;
	$this->last = $last;

		$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE forename = '".$this->first."' AND surname = '".$this->last."'",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displaySmartFleetWhoAU($id) {
	
	$this->id = $id;


		$sql = sprintf("SELECT * FROM %s.participant_database
				
					WHERE participantID =".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function displaySmartFleetWhoService($first,$id) {
	
	$this->first = $first;
	$this->id = $id;

		$sql = sprintf("SELECT * FROM %s.vehicle_service
				
					WHERE mileageServices = '".$this->first."' AND vID = ".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
		public function displaySmartFleetBU($id) {
	
	$this->id = $id;
	

		$sql = sprintf("SELECT * FROM %s.organisation_participant_allocation
				
					WHERE participantID =".$this->id,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function addMonthlyInspection(){
			
			
			$sql2 = sprintf("INSERT INTO %s.vehicle_monthly_inspection (vID,monthlyInspection,monthlyDescp,monthlyWho,monthlyName,monthlyNum)
											VALUES (%d,'%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['cid'],										
											$this->vehicleInfo['monthlyInspection'],
											$this->vehicleInfo['monthlyDescp'],
											$this->vehicleInfo['whoMonthly'],
											$this->vehicleInfo['contractorName'],
											$this->vehicleInfo['contractorContact']
											
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
	
	
	}


	/*
	 * This method is used to edit an vehicle
	 */
	public function editVehicle() {
		
	echo	$sql = sprintf("UPDATE %s.vehicle
						SET vehicleType='%s',vehicleMake='%s',vehicleModel='%s',registration='%s',purchaseDate='%s',picture='%s',mileagePurchase='%s',mileageServices='%s',specialServiceMileage='%s',moTNCTDate='%s',licenceDate='%s',insuranceDate='%s',archive='%s',MoTNCTDocument='%s',licenceDocument='%s',insuranceDocument='%s',document='%s',vari='%s'
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL,$this->vehicleInfo['vehicleType'],
											$this->vehicleInfo['vehicleMake'],
											$this->vehicleInfo['vehicleModel'],
											$this->vehicleInfo['registration'],
											format_date_for_mysql($this->vehicleInfo['purchaseDate']),
											$this->vehicleInfo['picture'],
											$this->vehicleInfo['mileagePurchase'],
											$this->vehicleInfo['mileageServices'],
											$this->vehicleInfo['specialServiceMileage'],								                                            $this->vehicleInfo['moTNCTDate'],
											$this->vehicleInfo['licenceDate'],
											$this->vehicleInfo['insuranceDate'],
											$this->vehicleInfo['archive'],
											$this->vehicleInfo['moTNCTDocument'],
											$this->vehicleInfo['licenceDocument'],
											$this->vehicleInfo['insuranceDocument'],
											$this->vehicleInfo['document'],
											$this->vehicleInfo['vari']);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
	public function editSetupVehicle() {
		
	echo	$sql = sprintf("UPDATE %s.vehicle_setup_service
						SET serviceName='%s',descp='%s',mileage='%s',frequency='%s',fTime='%s'
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL,$this->vehicleInfo['mileageServices'],
											$this->vehicleInfo['description'],
											
											$this->vehicleInfo['specialServiceMileage'],
											
											$this->vehicleInfo['fre'],
											$this->vehicleInfo['time_f']
											);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
	public function editSetupInspection() {
		
	echo	$sql = sprintf("UPDATE %s.vehicle_setup_inspection
						SET inspectionName='%s',frequency=%d,type=%d
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL,$this->vehicleInfo['inspectionName'],
											
											$this->vehicleInfo['time_f'],$this->vehicleInfo['type']
											);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
		public function documentUpdateEdit() {
		
	echo	$sql = sprintf("UPDATE %s.vehicle
						SET licenceDocument=''
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
	
	public function addServiceDone($id) {
		$this->id = $id;
		$sql = sprintf("UPDATE %s.vehicle_service
						SET done='1'
						WHERE ID = ".$this->id ,
						_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
	public function updateAction($id,$today) {
	
	
		$this->today = $today;
		$this->id = $id;
	echo	$sql = sprintf("UPDATE %s.actions
						SET doneDate='".$this->today."' ,  doneDescription ='done' , outstanding = 2  WHERE ID = ".$this->id ,
						_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	public function performActivity(){
		$sql2 = sprintf("INSERT INTO %s.perform_vehicle (vehicleID,dailyInspection,weeklyInspection,monthlyInspection,dailyMiles,weeklyMiles,monthlyMiles,miles,dailyInspectionDate,weeklyInspectionDate,monthlyInspectionDate,dailyDueDate,weeklyDueDate,monthlyDueDate,vehicleDate)
											VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
											$this->vehicleInfo['vehicleid'],										
											$this->vehicleInfo['dailyInspection'],
											$this->vehicleInfo['weeklyInspection'],
											$this->vehicleInfo['monthlyInspection'],
											$this->vehicleInfo['dailyMiles'],
											$this->vehicleInfo['weeklyMiles'],
											$this->vehicleInfo['monthlyMiles'],
											$this->vehicleInfo['miles'],
											$this->vehicleInfo['dailyInspectionDate'],
											$this->vehicleInfo['weeklyInspectionDate'],
											$this->vehicleInfo['monthlyInspectionDate'],
											$this->vehicleInfo['dailyDueDate'],
											$this->vehicleInfo['weeklyDueDate'],
											$this->vehicleInfo['monthlyDueDate'],
											$this->vehicleInfo['milesDate']
											);
											
			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$this->vehicleInfo['incidence_id']);
			$pStatement2->bindParam(2,$this->vehicleInfo['reference']);
			$pStatement2->bindParam(3,$this->vehicleInfo['unique_reference']);*/
			

			$pStatement2->execute();
	
	}
	

	
	public function editVehiclePage2() {
		
	echo	$sql = sprintf("UPDATE %s.vehicle
						SET due='%s',dailyInspection='%s',dailyInspectionDate='%s',weeklyInspection='%s',weeklyInspectionDate='%s',miles='%s',milesDate='%s',contractorName='%s',contractorContact='%s',monthlyInspection='%s',monthlyInspectionDate='%s',dailyMiles='%s',weeklyMiles='%s',monthlyMiles='%s',dailyDescp='%s',weeklyDescp='%s',monthlyDescp='%s',contractDailyName='%s',contractDailyNumber='%s',dailyWho='%s',monthlyWho='%s'
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL,
											
											$this->vehicleInfo['due'],
											$this->vehicleInfo['dailyInspection'],
											$this->vehicleInfo['dailyInspectionDate'],
											$this->vehicleInfo['weeklyInspection'],
											$this->vehicleInfo['weeklyInspectionDate'],
											$this->vehicleInfo['miles'],
											$this->vehicleInfo['milesDate'],
											$this->vehicleInfo['contractorName'],
											$this->vehicleInfo['contractorContact'],
											$this->vehicleInfo['monthlyInspection'],
											$this->vehicleInfo['monthlyInspectionDate'],
											$this->vehicleInfo['dailyMiles'],
											$this->vehicleInfo['weeklyMiles'],
											$this->vehicleInfo['monthlyMiles'],
											$this->vehicleInfo['dailyDescp'],
											$this->vehicleInfo['weeklyDescp'],
											$this->vehicleInfo['monthlyDescp'],
											$this->vehicleInfo['contractorNameDaily'],
											$this->vehicleInfo['contractorContactDaily'],
											$this->vehicleInfo['whoDaily'],
											$this->vehicleInfo['whoMonthly']
										
											);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
	public function archiveVehicle($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.vehicle SET archive = '".$this->flag."' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function archiveVehicleCK($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.vehicle_setup_inspection SET archive = '".$this->flag."' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function archiveVehicleTY($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.new_vehicle SET archive = 0 WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	
	public function archiveVehicleMA($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.vehicleDetail SET archive = '".$this->flag."' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function archiveVehicleMO($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.vehicleModel SET archive = '".$this->flag."' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function archiveVehicleSK($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.vehicle_setup_service SET archive = '".$this->flag."' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
		public function archiveVehicleFR($flag) {
		$this->flag = $flag;
		$sql = "UPDATE %s.addFrequency SET archive = '".$this->flag."' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->vehicleId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	
	public function editService() {
		
	echo $sql = sprintf("UPDATE %s.vehicle
						SET servicingRequired='%s',who='%s',descp='%s',mileageServices='%s',service ='%s',sContractName ='%s',sContractNum ='%s'
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL,$this->vehicleInfo['servicingRequired'],
											$this->vehicleInfo['who_hidden'],
											$this->vehicleInfo['licenceDate'],
											$this->vehicleInfo['mileageServices'],
											$this->vehicleInfo['specialServiceMileage'],
											$this->vehicleInfo['contractorName'],
											$this->vehicleInfo['contractorContact']
											
							);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
		public function editOwnerDetail() {
		
		$sql = sprintf("UPDATE %s.vehicle
						SET permanentOwnerName='%s',permanentOwnerBU='%s',permanentOwnerContact='%s',temporaryOwnerName='%s',temporaryOwnerBU='%s',temporaryOwnerContact='%s'
						WHERE ID = ".$this->vehicleId,
						_DB_OBJ_FULL,$this->vehicleInfo['permanentOwnerName'],
											$this->vehicleInfo['permanentOwnerBU'],
											$this->vehicleInfo['permanentOwnerContact'],
											$this->vehicleInfo['temporaryOwnerName'],
											$this->vehicleInfo['temporaryOwnerBU'],
											$this->vehicleInfo['temporaryOwnerContact']
											);
		$pStatement = $this->dbHand->prepare($sql);
			
		$pStatement->execute();
	}
	
	public function addAction() {

	echo 	$sql = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,whoAU,dueDate,approve,outstanding,status,approveAU)
										VALUES ('%s','%s',%d,%d,'%s',0,0,0,0)",_DB_OBJ_FULL,
										$this->vehicleInfo['module'],$this->vehicleInfo['descp'],$this->vehicleInfo['who'],$this->vehicleInfo['whoAU'],
										$this->vehicleInfo['dueDate']);

		$pStatement = $this->dbHand->prepare($sql);

		if ( $pStatement->execute() ) {

			$lastId = customLastInsertId($this->dbHand,'actions','ID');
			//$lastId = $this->dbHand->lastInsertId();

			return $lastId;
		} else {
			/*dump_array($pStatement->errorInfo());
			exit;*/
		}

	}
	
		public function addDocumentAction() {

	echo 	$sql = sprintf("INSERT INTO %s.vehicle_document_action (vID,actionID,documentID)
										VALUES (%d,%d,%d)",_DB_OBJ_FULL,
										$this->vehicleInfo['vID'],$this->vehicleInfo['actionID'],$this->vehicleInfo['documentID']);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

	}
	
	public function addFleetListing() {
	
	$sql = sprintf("INSERT INTO %s.vehicle_listing (field_1,title_1,field_2,title_2,field_3,title_3,field_4,title_4,field_5,title_5,field_6,title_6)
										VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
										$this->vehicleInfo['field_1'],$this->vehicleInfo['title_1'],$this->vehicleInfo['field_2'],$this->vehicleInfo['title_2'],$this->vehicleInfo['field_3'],$this->vehicleInfo['title_3'],$this->vehicleInfo['field_4'],$this->vehicleInfo['title_4'],$this->vehicleInfo['field_5'],$this->vehicleInfo['title_5'],$this->vehicleInfo['field_6'],$this->vehicleInfo['title_6']);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

	}
	public function adaCheckedListing() {
	


	 	$sql = sprintf("DELETE FROM  %s.vehicle_listing",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

	}
	
	public function configureType($show) {
		$this->show = $show;


	 	$sql = sprintf("UPDATE   %s.vehicle_configure SET typeButton = '".$this->show."' WHERE ID =1",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		

	}
	
	
	
	
	
	
	public function updateDocument() {

				$objFile = new Upload();

			$objFile->setFileInfo('vehicle',array('id'=>$resultSet));
			$single_files_data = $objFile->getFileDetails();

			$objFile->setFileInfo('vehicle',array('id'=>$single_files_data['fileID'],'destination'=>'vehicle'));
			$objFile->delete_file();
		
		//dump_array($stmt->errorInfo());

		$sql = sprintf("UPDATE %s.vehicle SET licenceDocument = '%s' WHERE WHERE ID = ".$this->vehicleId
						,_DB_OBJ_FULL
						,$this->vehicleInfo['file_id']);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->smartLawInfo['file_id']);
		$stmt->bindParam(2,$this->smartLawId);
		$stmt->bindParam(3,$this->smartLawInfo['type']);*/

		$stmt->execute();
	}


//	/*
//	 * This method is used to view vehicle records
//	 */
	public function viewVehicle() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle WHERE ID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function viewVehicleAc() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_daily WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleSer($id,$name) {
	
		$this->id = $id;
		$this->name = $name;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE vID = ".$this->id." AND servicingRequired = '".$this->name."'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServiceCheck() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_service WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function countServiceAction($id) {
			$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleService' AND who = ".$this->id." AND doneDate is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function countDocumentAction($id) {
			$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleDocument' AND who = ".$this->id." AND  doneDate is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function countInspectionAction($id) {
			$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE (moduleName = 'vehicleDaily' OR moduleName = 'vehicleMonthly') AND who = ".$this->id." AND doneDate is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServiceCheck1() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE vID = %d ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleDailyInsp($date) {
	
	$this->dat = $date;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_daily WHERE vID = %d AND dateDaily = '".$this->dat."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleDailyInspMileage($date) {
	
	$this->dat = $date;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT dailyM FROM %s.perform_vehicle_daily WHERE vID = %d AND dateDaily = '".$this->dat."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleMonthlyInspMileage($date) {
	
	$this->dat = $date;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT dailyM FROM %s.perform_vehicle_monthly WHERE vID = %d AND dateDaily = '".$this->dat."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewActionService1() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleService'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewActionDocument1() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleDocument'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	
	public function viewActionServiceWHOAUss($id,$nam) {
			$this->id = $id;
			$this->nam = $nam;
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE servicingRequired = '".$this->nam."' AND vID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($resultSet);
		return $resultSet;
	}
	
	public function viewActionServiceS1($id) {
	
	$this->id = $id;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleService' AND ID=".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	public function viewActionDailyInsp() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleDaily' OR moduleName = 'vehicleMonthly'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewActionDailyInspDA($id) {
	
		$this->id = $id;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE ID = ".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewActionMonthlyInspMA($id) {
	
		$this->id = $id;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleMonthly' AND  ID = ".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	
	public function viewActionService() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewActionMonthlyInsp() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'vehicleMonthly'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewActionMonth() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_monthly_action WHERE frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleMonthlyInsp($date) {
	
	$this->dat = $date;
	
	$piec = explode("-",$this->dat);
	$today_e  = '2013'.'-'.$piec[1].'-'.'31'; 
	$today_s  = '2013'.'-'.$piec[1].'-'.'01'; 
		
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE vID = %d AND dateDaily <= '".$today_e."' AND dateDaily >= '".$today_s."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleService() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewVehicleactionIDhjhjgfg() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		echo  $sql11 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		 $pStatement = $this->dbHand->prepare($sql11);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//dump_array($this->errorInfo());
		$resultSet = $pStatement->fetchAll();
		//dump_array($pStatement->errorInfo());
		return $resultSet;
	}
	
	public function viewVehicleactionMailgg($id,$actionid) {
	
		$this->id = $id;
		$this->actionid = $actionid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		echo  $sql11 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = ".$this->id." AND actionID = ".$this->actionid,_DB_OBJ_FULL);

		 $pStatement = $this->dbHand->prepare($sql11);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//dump_array($this->errorInfo());
		$resultSet = $pStatement->fetch();
		//dump_array($pStatement->errorInfo());
		return $resultSet;
	}
	public function viewVehicleactionActionData($actionid) {
	
		//$this->id = $id;
		$this->actionid = $actionid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		echo  $sql11 = sprintf("SELECT * FROM %s.actions WHERE ID = ".$this->actionid,_DB_OBJ_FULL);

		 $pStatement = $this->dbHand->prepare($sql11);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//dump_array($this->errorInfo());
		$resultSet = $pStatement->fetch();
		//dump_array($pStatement->errorInfo());
		return $resultSet;
	}
 
	
	
	public function viewVehicleactionDocument() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		echo  $sql11 = sprintf("SELECT * FROM %s.vehicle_document_action WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		 $pStatement = $this->dbHand->prepare($sql11);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//dump_array($this->errorInfo());
		$resultSet = $pStatement->fetchAll();
		//dump_array($pStatement->errorInfo());
		return $resultSet;
	}
	
	public function viewVehicleactionDocumentS() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		echo  $sql11 = sprintf("SELECT * FROM %s.vehicle_service WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		 $pStatement = $this->dbHand->prepare($sql11);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//dump_array($this->errorInfo());
		$resultSet = $pStatement->fetchAll();
		//dump_array($pStatement->errorInfo());
		return $resultSet;
	}
	
		
	public function viewVehicleactionDocumentCheck($id,$dID) {
	
	$this->id = $id;
	$this->dID = $dID;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		echo  $sql11 = sprintf("SELECT * FROM %s.vehicle_document_action WHERE vID =".$this->id." AND documentID=".$this->dID,_DB_OBJ_FULL);

		 $pStatement = $this->dbHand->prepare($sql11);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//dump_array($this->errorInfo());
		$resultSet = $pStatement->fetch();
		//dump_array($pStatement->errorInfo());
		return $resultSet;
	}
	
	
	public function viewVehicleServiceAll() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleTypeA($id) {
	
	$this->id = $id;

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addVehicle WHERE ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServiceDone() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_service WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServiceDoneCron() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_service",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServiceDoneAll() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_service ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewEditSetupService($cid) {
           $this->id= $cid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_service WHERE ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewEditSetupInspection($cid) {
           $this->id= $cid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetupService() {
          // $this->id= $cid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_service WHERE archive is NULL OR archive ='0' ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetupService1($cid) {
           $this->id= $cid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addFre WHERE  ID = ".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
		public function viewSetupServiceT() {
          // $this->id= $cid;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_service WHERE archive = '1'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetupInspectionE() {
           
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	 	$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE archive is NULL OR archive = '0'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetupInspection($fe=null) {
           $this->fe= $fe;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);
if ($fe == null)
		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE  ( archive is NULL OR archive = '0') ORDER BY ID DESC",_DB_OBJ_FULL);
else
    		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = ".$this->fe." AND ( archive is NULL OR archive = '0') ORDER BY ID DESC",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetuppre($fe) {
           $this->fe= $fe;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addPre WHERE type = ".$this->fe." ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetuppre1() {
      
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addPre ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetupInspectionA($fe=0) {
           $this->fe= $fe;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);
if($fe == 0)
		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE archive = '1'",_DB_OBJ_FULL);
else
                $sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type =".$this->fe." AND archive = '1'",_DB_OBJ_FULL);
                
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewSetupInspectionA1($fe=0) {
           $this->fe= $fe;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		 $sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE ID =".$this->fe,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	public function viewVehicleDaily() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewListInspection() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '1' AND frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewListInspection1() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '2' AND frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewListInspection2() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '3' AND frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewListInspection3() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '4' AND frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewListInspection4() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '5' AND frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewListInspection5() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '0' AND frequency = '2'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewListInspection6() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_inspection WHERE type = '0' AND frequency = '1'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewListInspection7() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_service ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
		public function viewVehicleDailyWho() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		 $sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = %d AND dailywho != '' AND dailywho != '--SELECT--'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
		public function viewVehicleDailyWhoM() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = %d AND dailywho != '' AND dailywho != '--SELECT--' ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleDailyAction() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_daily WHERE actionID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	public function viewVehicleServieN() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_service WHERE actionID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServieK() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE actionID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleServieA() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_service WHERE actionID = %d ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleDocumentAction() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_document_action WHERE actionID = %d ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewVehicleServieC() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		 $sql = sprintf("SELECT * FROM %s.vehicle_service WHERE  actionID = %d ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleMonthlyAction() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_monthly WHERE actionID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleMonthlyActionDCU() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE actionID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
		public function viewVehicleMonthlyActionC() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE actionID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	public function viewVehicleMonthlyA() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE actionID = %d AND frequency ='2'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	
	public function viewVehicleDailyMonthly() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleDailyMonthlyWho() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE vID = %d AND dailywho != '' AND dailywho != '--SELECT--' ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewVehicleMonthly() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_monthly_inspection WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewPerformService() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle_service WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	public function viewPerformServiceA($name) {
			$this->name = $name;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);
 
		echo $sql = sprintf("SELECT * FROM %s.perform_vehicle_service WHERE vID = %d AND service = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		if($resultSet){
		return $resultSet;
		}else{
		$resultSet = '1';
		}
		
		return $resultSet;
	}
	
	public function viewPerformServiceACD($name) {
			$this->name = $name;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);
 
		echo $sql = sprintf("SELECT * FROM %s.vehicle_service WHERE vID = %d AND servicingRequired = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewFrequency() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addFrequency WHERE archive is NULL OR archive = '0'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewNewService() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_setup_service  WHERE archive is NULL OR archive = '0'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function viewNewService1() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addService  ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
		public function viewMil() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addMileage  ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
		public function viewFre() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addFre  ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewFrequency1() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addFrequency",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function viewPerform() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.perform_vehicle WHERE vehicleID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	public function deletePerform() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.perform_vehicle WHERE vehicleID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function deleteService() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.vehicle_service WHERE ID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	public function deleteFleetListing() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.vehicle_listing",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function deleteDaily() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.vehicle_daily_inspection WHERE ID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function deleteMonthly() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.vehicle_monthly_inspection WHERE ID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	
	public function deleteServiceEdit() {
	
		$sql2 = sprintf("SELECT * FROM %s.vehicle_service  WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql2);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$result_service = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//dump_array($result_service);
		
		foreach($result_service as $v){
		
		echo $sql113 = sprintf("SELECT * FROM %s.actions  WHERE ID =".$v['actionID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql113);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$actionData = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		//dump_array($actionData);
		if($actionData['doneDate'] == 'NULL' || $actionData['doneDate'] == ''){
		
			$sql33 = sprintf("DELETE FROM %s.vehicle_service WHERE actionID =".$v['actionID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql33);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$sql333 = sprintf("DELETE FROM %s.actions WHERE ID =".$v['actionID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql333);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
		
		}
		
		}

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		
	}
	
	
	public function deleteServiceSetup() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.vehicle_setup_service ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function deleteDailyEdit() {

		$sql2 = sprintf("SELECT * FROM %s.vehicle_daily_inspection  WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql2);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$result_service = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//dump_array($result_service);
		
		foreach($result_service as $v){
		
		echo $sql113 = sprintf("SELECT * FROM %s.actions  WHERE ID =".$v['actionID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql113);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$actionData = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		//dump_array($actionData);
		if($actionData['doneDate'] == 'NULL' || $actionData['doneDate'] == ''){
		
			$sql33 = sprintf("DELETE FROM %s.vehicle_daily_inspection WHERE actionID =".$v['actionID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql33);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		$sql333 = sprintf("DELETE FROM %s.actions WHERE ID =".$v['actionID'],_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql333);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
		
		}
		
		}

	}
	
	public function deleteDaiEdit() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("DELETE FROM %s.vehicle_monthly_action WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
	}
	
	public function deleteA($id) {

		$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("DELETE FROM %s.actions WHERE ID =".$this->id." AND doneDate is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
	}
	
		public function deleteADocument($id) {

		$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("DELETE FROM %s.vehicle_document_action WHERE actionID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
	}
	
	
	
	
		public function deleteDailyPerform($date) {
				$this->date = $date;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("DELETE FROM %s.perform_vehicle_daily WHERE vID = %d AND dateDaily='".$this->date."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function deleteservicePerform($date) {
				$this->date = $date;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("DELETE FROM %s.perform_vehicle_service WHERE vID = %d AND done != '1' AND dateDaily='".$this->date."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
		public function deleteMonthlyPerform($date) {
				$this->date = $date;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("DELETE FROM %s.perform_vehicle_monthly WHERE vID = %d ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function deleteMonthlyPerformAction($id,$date) {
				$this->date = $date;
				$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("UPDATE  %s.actions SET doneDate = '".$this->date."' ,doneDescription = 'done', outstanding=2 WHERE moduleName='vehicleMonthly' AND actionDescription LIKE '' AND ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
	}
	
	public function deleteMonthlyPerformActiDocument($id,$date) {
	
				$this->date = $date;
				$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("UPDATE  %s.actions SET doneDate = '".$this->date."' ,doneDescription = 'done', outstanding=2 WHERE ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
	}
	
	public function updateWhoActionName($id,$name) {
	
				$this->name = $name;
				$this->id = $id;
				
			$sql5 = sprintf("SELECT doneDate FROM %s.actions WHERE  ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetch(PDO::FETCH_ASSOC);
	
		
		
		if($reslist['doneDate'] == ""){
		
			//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	echo	$sql = sprintf("UPDATE  %s.actions SET who = ".$this->name."  WHERE ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
		
		}		
				
		
	}
	

	
	public function actionUpdate($id) {
				$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);
 $today = date('Y-m-d');
	echo	$sql = sprintf("UPDATE  %s.actions SET dueDate = '".$today."'  WHERE ID =".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		//return $resultSet[0];
	}
	
	public function displayFleet() {

		$sql = sprintf("SELECT * FROM %s.participant_database D
				INNER JOIN
					%s.participant_authorization_stats M
				ON
					D.participantID = M.participantID
				WHERE M.sectionName='perm_fleet' AND M.sectionActive=1
				ORDER BY
					D.participantID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function deleteMonthlyEdit() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.vehicle_monthly_inspection WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	
	public function deletePerformService() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("DELETE FROM %s.perform_vehicle_service WHERE vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet[0];
	}
	
	public function showFleetListing() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_listing ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function showTypeButton() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_configure ",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
		
	public function showFleetListing1() {

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.vehicle_listing",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	public function showFleetListingType($id) {
		$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.addVehicle WHERE ID = ".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		
		return $resultSet['name'];
	}
	public function InspectionExternal() {

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  type = 1  AND vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	
	public function InspectionExternalA($name) {
	
		$this->name = $name;

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = 2  AND type = '1' AND vID = %d AND dailywho = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionFluidA($name) {
	
		$this->name = $name;

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = 2 AND type = '2' AND vID = %d AND dailywho = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionInternalA($name) {
	
		$this->name = $name;

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = 2 AND type = '3' AND vID = %d AND dailywho = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionFuncA($name) {
	
		$this->name = $name;

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = 2 AND type = '4' AND vID = %d AND dailywho = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionEquipA($name) {
	
		$this->name = $name;

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = 2 AND type = '5' AND vID = %d AND dailywho = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionCustomA($name) {
	
		$this->name = $name;

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE frequency = 2 AND type = '0' AND vID = %d AND dailywho = '".$this->name."'",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	
	public function InspectionFluid() {

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  type = '2' AND vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionInternal() {

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  type = '3' AND vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionFunc() {

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  type = '4' AND vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionEquip() {

	echo $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  type = '5' AND vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	public function InspectionCustom() {

	 $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  type = '0' AND vID = %d",_DB_OBJ_FULL,$this->vehicleId);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetchAll(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	
		public function getVtype($id) {
			$this->id = $id;
	 $sql5 = sprintf("SELECT * FROM %s.addVehicle WHERE  ID = ".$this->id." AND archive is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetch(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	
		public function getVtype1($id) {
			$this->id = $id;
	 $sql5 = sprintf("SELECT * FROM %s.vehicle_service WHERE  vID = ".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetch(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	
		public function getVtype2($id) {
			$this->id = $id;
	 $sql5 = sprintf("SELECT * FROM %s.vehicle_daily_inspection WHERE  vID = ".$this->id,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql5);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$reslist = $pStatement->fetch(PDO::FETCH_ASSOC);
	
		
		return $reslist;
	}
	
	public function getListingforExport() {

		  $type = $_GET['type'];

		if ( $type  =='assest') {

			return $this->getEquipementExportDataFull();

		}else if( $type  =='fulli'){
		
		return $this->getEquipementExportDataFull1();
		}else if( $type  == 'fullvttt'){
		
		return $this->getEquipementExportDataFull2();
		} else {

			return $this->getEquipementExportData();
		}
	}
	
	public function getEquipementExportDataFull2() {

		$objEquip			= SetupGeneric::useModule('Equipment');
		$objOrg				= SetupGeneric::useModule('Organigram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
                $participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 			= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
		
		
$vehicleObj = SetupGeneric::useModule('Vehicle');
$dataVehicle = $vehicleObj->displayItems();
//dump_array($dataVehicle);
		//$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		//$equipment_data = $objEquip->displayItems1();
        //dump_array($equipment_data);
		
		
		$heading = array(array('Reference', 'Type', 'Make','Model','Registration','Odometer','Varient','Road Tax Due Date','MoT/NCT Due Date','Vehicle Insurance Due Date','Purchase date','Purchase mileage','Road Tax','MoT/NCT','Vehicle Insurance','Picture','Responsible For','Responsible For Contact','Responsible For BU','Responsibility Override','Responsibility Override BU','Responsibility Override Contact','Service','Description','Contractor Name','Servicing Mileage','Frequency','FM Responsible','Inspection Name ','Description','Inspection Type','Frequency','FM Responsible'));
		
		
		
		if ( count($dataVehicle) ) {
					$k = 0;
			foreach ( $dataVehicle as $element) {

				$equip_id	= (int) $element['equipID'];

		$n = 	$this->getVtype1($element['ID']);
		$n1 = 	$this->getVtype2($element['ID']);
		//dump_array($n);
		//exit;
				$result[$k] = array($element['uniqueReference'],$n['name'], $element['vehicleMake'],$element['vehicleModel'],$element['registration'],'0',$element['vari'],$element['licenceDate'],$element['licenceDate'],$element['licenceDate'],$element['purchaseDate'],$element['mileagePurchase'],$element['licenceDocument'],$element['licenceDocument'],$element['licenceDocument'],$element['picture'],$element['permanentOwnerName'],$element['permanentOwnerContact'],$element['permanentOwnerBu'],$element['temporaryOwnerName'],$element['temporaryOwnerContact'],$element['temporaryOwnerBu'],$n['servicingRequired'],$n['descp'],$n['sContractName'],$n['services'],$n['fTime'],$n['who'],$n1['dailyInspection'],$n1['type'],$n1['dailyDescp'],$n1['frequency'],$n1['dailywho']);
				$k++;
			}

			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}
	
	public function getEquipementExportDataFull1() {

		$objEquip			= SetupGeneric::useModule('Equipment');
		$objOrg				= SetupGeneric::useModule('Organigram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
                $participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 			= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
		
		
$vehicleObj = SetupGeneric::useModule('Vehicle');
$dataVehicle = $vehicleObj->displayItems();
//dump_array($dataVehicle);
		//$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		//$equipment_data = $objEquip->displayItems1();
        //dump_array($equipment_data);
		
		//exit;
		$heading = array(array('Reference', 'Type', 'Make','Model','Registration','Odometer'));
		
		
		
		if ( count($dataVehicle) ) {
					$k = 0;
			foreach ( $dataVehicle as $element) {

				$equip_id	= (int) $element['equipID'];

		$n = 	$this->getVtype($element['type']);
				$result[$k] = array($element['uniqueReference'],$n['name'], $element['vehicleMake'],$element['vehicleModel'],$element['registration'],'0');
				$k++;
			}

			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}
	
	public function getEquipementExportDataFull() {

		$objEquip			= SetupGeneric::useModule('Equipment');
		$objOrg				= SetupGeneric::useModule('Organigram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
                $participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 			= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		$equipment_data = $objEquip->displayItems1();
        //dump_array($equipment_data);
		
		//exit;
		$heading = array(array('Classification', 'Location', 'Asset','Asset Link Code'));
		
		
		
		if ( count($equipment_data) ) {
					$k = 0;
			foreach ( $equipment_data as $element) {

				$equip_id	= (int) $element['equipID'];

				/*$this->setEquipmentInfo( $equip_id, '' );
				$equip_mod_data = $this->displayClientDetailsByEquipId();
				$asset_tag	= $equip_mod_data['assetTag'];*/

					$objEquip->setItemInfo( array('id'=>$element['assest_c']) );
			$equip_class_data = $objEquip->displayItemById_c();
			
			$type = $objEquip->getEquipmentDetailById22($element['assest_t']);
		
	//dump_array($type);
	//exit;
		
		$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$element['loc']));
				$location_data = "";
				$location = $locObj->getFUllLocation();
				
				$loc				= SetupGeneric::useModule('Locationgram');
				 $bu_id	= (int) $element['loc'];
				$loc->setItemInfo( array('id'=>$bu_id) );
				$loc1 = $loc->displayItemById();
				
				//dump_array($location);
		
		$bu_id	= (int) $element['bu'];
			$objOrg->setItemInfo( array('id'=>$bu_id) );
			$business_unit_data = $objOrg->displayItemById();

			$bu_name = $business_unit_data['buName'] != '' ? $business_unit_data['buName'] : '-';
			//dump_array($bu_name);
			//exit;
				$result[$k] = array($equip_class_data['primaryAssest'], $loc1['name'],$element['descp'],$element['flag_v']);
				$k++;
			}

			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}
	
		public function getEquipementExportData() {

		$objEquip			= SetupGeneric::useModule('Equipment');
		$objOrg				= SetupGeneric::useModule('Organigram');
		$loc				= SetupGeneric::useModule('Locationgram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
		$participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 			= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		$equipment_data = $objEquip->displayItems();
    // dump_array($equipment_data);
		
//exit;
		$heading = array(array('EQ #', 'Location', 'Who', 'Description','Maintenace DueDate','Calibration DueDate'));
		
		
		
		if ( count($equipment_data) ) {
					$k = 0;
			foreach ( $equipment_data as $element) {

				$equip_id	= (int) $element['equipID'];

				/*$this->setEquipmentInfo( $equip_id, '' );
				$equip_mod_data = $this->displayClientDetailsByEquipId();
				$asset_tag	= $equip_mod_data['assetTag'];*/
				$loc				= SetupGeneric::useModule('Locationgram');
				 $bu_id	= (int) $element['equipDetailLocID'];
				$loc->setItemInfo( array('id'=>$bu_id) );
				$loc1 = $loc->displayItemById();
				//dump_array($loc1['name']);
				//exit;
				//$bu_name = $business_unit_data['buName'];

				$equip_class_id	= $element['equipClassID'];
				$objEquipClass->setItemInfo( array('id'=>$equip_class_id) );
				$equip_class_data = $objEquipClass->displayItemById();
				$equip_class_code = $equip_class_data['equipCode'];

				$participant_id = $element['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
				
				$equip_id	= (int) $element['equipID'];
				$objModEquip->setEquipmentInfo($equip_id,array('equip_id'=>$equip_id));
				$periodicity_details = $objModEquip->getPeriodicityDates();
				
				//dump_array($periodicity_details);
		
				$maintenance_duedate_color = 'black';
				$calibration_duedate_color = 'black';

				$one_week_prior_maint_date = $miscObj->makeCustomDate($miscObj->getCurDate(),-$_SU_EMAIL_MAIN_VALUE,'WEEK');
				$one_week_prior_calib_date = $miscObj->makeCustomDate($miscObj->getCurDate(),-$_SU_EMAIL_CALIB_VALUE,'WEEK');

				if ( $periodicity_details['maintenanceDueDate'] < $one_week_prior_maint_date  ) {
					$maintenance_duedate_color = 'green';
				}

				if ( $periodicity_details['calibrationDueDate'] <  $one_week_prior_calib_date ) {
					$calibration_duedate_color = '#FF8105';
				}


				$maintenance_duedate = ($periodicity_details['maintenanceDueDate'] == '//' || $periodicity_details['maintenanceDueDate'] == ' ') ? '-' : $periodicity_details['maintenanceDueDate'];
				$calibration_duedate = ($periodicity_details['calibrationDueDate'] == '//' || $periodicity_details['calibrationDueDate'] == ' ') ? '-' : $periodicity_details['calibrationDueDate'];

				$result[$k] = array($element['reference'],$loc1['name'], $participant_name, $element['equipmentDesc'],$maintenance_duedate,$calibration_duedate);
				$k++;
			}
			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}
	
	/**
	 *This method is used to get last insert record ID
	 *
	 */
	public function getCurrentRecordId() {
		return $this->vehicleId;
	}
	
//
//	public function updateStatus() {
//		$sql = sprintf("UPDATE %s.vehicle SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->vehicleId);
//
//		$pStatement = $this->dbHand->prepare($sql);
//
//		//$pStatement->bindParam(1,$this->vehicleId);
//		$pStatement->execute();
//
//	}
//
//    public function viewAllVehicles() {
//        $sql = sprintf('Select * from %s.vehicle ORDER BY id DESC', _DB_OBJ_FULL);
//
//        $pStatement = $this->dbHand->prepare($sql);
//        //$pStatement->bindParam(1,$this->contractorInfo['archive']);
//        $pStatement->execute();
//
//        $records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
//        return $records;
//    }
//	
//	public function deleteVehicle();
//	
//	public function archiveVehicle();
//
//	/*
//	 * This method is used to remove the vehicle
//	 */
//	public function purgeVehicle();
}

?>
