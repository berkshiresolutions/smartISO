<?php
 /**
  $Id: Documents.int.php,v 3.70 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Manage Document object
  *
  * This interface will declare the various methods performed
  * by document object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Friday, September 10, 2010 8:17:06 PM>
  */

interface DocumentsInterface
{
	/*
	 * This method is used to set document information before uploading and edit operation.
	 */

	public function setDocumentInfo($p_doc_info);

	/*
	 * This method is used to upload the document
	 */
	public function uploadDocument();

	/*
	 * This method is used to delete the document.
	 */
	public function deleteDocument($p_doc_id);

	/*
	 * This method is used to view already uploaded document.
	 */
	public function viewDocument($p_doc_id);

	/*
	 * This method is used to list all the alerts related with the document
	 */
	public function listDocumentAlerts();

	/*
	 * This method is used to view the document alert details.
	 */
	public function viewDocumentAlertDetails();

	/*
	 * This method is used to store the agreement of alert raised by others
	 */
	public function agreeDocumentAlert();

	/*
	 * This method is used to view document history
	 */
	public function viewDocumentHistory();

	/*
	 * This method is used to raise new alert for document.
	 */
	public function raiseDocumentAlert();

	/*
	 * This method is used to store the agreement of alert raised by others
	 */
	public function disagreeDocumentAlert();


	/*
	 * This method is used to get document information
	 */
	public function getDocumentInformation($p_doc_id);

	/*
	 * This method is used to draw document tree
	 */
	public function drawDocumentTree();



}
?>