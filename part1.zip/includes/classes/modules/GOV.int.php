<?php
 /**
  $Id: Incidence.int.php,v 3.08 Wednesday, November 03, 2010 12:24:48 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage incidence object
  *
  * This interface will declare the various methods performed
  * by incidence object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 8:09:18 PM>
  */

interface GOV
{
	/*
	 * This method is used to set incidence information for the respective object
	 */
	public function setGOVInfo($p_Id,$p_Info);

	/*
	/*
	 * This method is used to delete an incidence
	 */
	public function deleteGOV();

	/*
	 * This method is used to archive an incidence record
	 */
	public function archiveGOV();

	/*
	 * This method is used to completely delete an incidence record
	 */
	public function purgeGOV();

}
