<?php
 /**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */
class DashboardIncidenceInvestigation extends DashboardParent
{

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {
		parent::__construct();
	}

	public function getImpactMeasures() {

		$sql = "SELECT * FROM %s.impact_measure
				ORDER BY sort ASC";

		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$impact_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $impact_data;

	}

	public function getIncidenceInvestigationData() {

		if ( $this->filter['selected_bu'] ) {

			$bu_list = $this->getAllBUs();

			$sql = "SELECT buID,N.actionsID,activityImpact
					FROM %s.investigation N
					INNER JOIN %s.incidence I
					ON I.ID = N.incID
					WHERE 
					buID IN (%s)";

			$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,$bu_list);
		} else {

			$sql = "SELECT buID,N.actionsID,activityImpact
					FROM %s.investigation N
					INNER JOIN %s.incidence I
					ON I.ID = N.incID";

			$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL);
		}

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result_data;
	}

	public function getData() {

		$bu_list 	= array();
		$hlist 		= array();
		$dlist 		= array();

		$q1_sr 		= $this->qtrsRange['q1_sr'];
		$q1_er		= $this->qtrsRange['q1_er'];
		/*$q11_sr 	= $this->qtrsRange['q11_sr'];
		$q11_er 	= $this->qtrsRange['q11_er'];
		$q12_sr 	= $this->qtrsRange['q12_sr'];
		$q12_er 	= $this->qtrsRange['q12_er'];
		$q13_sr 	= $this->qtrsRange['q13_sr'];
		$q13_er	 	= $this->qtrsRange['q13_er'];*/
		$q2_sr 		= $this->qtrsRange['q2_sr'];
		$q2_er 		= $this->qtrsRange['q2_er'];
		$q3_sr 		= $this->qtrsRange['q3_sr'];
		$q3_er 		= $this->qtrsRange['q3_er'];
		$q4_sr 		= $this->qtrsRange['q4_sr'];
		$q4_er 		= $this->qtrsRange['q4_er'];
		$q5_sr 		= $this->qtrsRange['q5_sr'];
		$q5_er 		= $this->qtrsRange['q5_er'];
		$cqtr		= $this->qtrsRange['cqtr'];

		$impact_measures = $this->getImpactMeasures();

		if ($impact_measures) {

			foreach ( $impact_measures as $impact_measure_ele ) {
				$impact_measure_ele_name = explode("|",$impact_measure_ele['name']);
				$hlist[$impact_measure_ele['ID']] = trim($impact_measure_ele_name[0]);
			}
		}

		$incidence_data = $this->getIncidenceInvestigationData();

		// Action Object
		$actObj = new Action();
		$incidence = array();

		$buObj = SetupGeneric::useModule('organigram');

		foreach ( $incidence_data as $incidence_data_ele ) {

			//dump_array($nhp_data_ele);

			if ( $incidence_data_ele['actionsID'] != '' ) {

				$incidence_data_actions 	= explode(",",$incidence_data_ele['actionsID']);
				$buid 						= $incidence_data_ele['buID'];
				$riskImpact					= $incidence_data_ele['activityImpact'];

				if ( !$buid ) { continue; }

				$buObj->setItemInfo(array(
									'id' =>$buid
									));

				$bu_info 			= $buObj->displayItemByIdForMSR();
				$bu_list[$buid] 	= $bu_info['buName'];

				if ( !in_array($buid,$dlist) )
					$dlist[] = $buid;

				foreach ( $incidence_data_actions as $incidence_data_action_ele ) {

					if ( $incidence_data_action_ele != '' ) {

						$actObj->setActionDetails($incidence_data_action_ele,array());
						$action_data = $actObj->viewAction();

						$incidence[$buid][$riskImpact]['hazards']['D']++;

						if ( $action_data['approve'] == 1 ) {
							$incidence[$buid][$riskImpact]['actions']['D']++;
						} else {
							$incidence[$buid][$riskImpact]['actions']['P']++;
						}
						
						//dump_array($action_data);

						//switch ($cqtr) {

							//case 1 :
								if($action_data['status'] == '1' && $action_data['doneDate']){
								if ($action_data['doneDate'] >= $q1_sr && $action_data['doneDate'] <= $q1_er ) {
									if ( $action_data['approveAU'] == '0' ) {
										$incidence[$buid]['q1']['P']++;
									} else {
									  // echo $action_data['dueDate'].'---';
										$incidence[$buid]['q1']['D']++;
									}
								} else if ( $action_data['doneDate'] >= $q2_sr && $action_data['doneDate'] <= $q2_er ) {
									if ( $action_data['approveAU'] == '0') {
										$incidence[$buid]['q2']['P']++;
									} else {
										$incidence[$buid]['q2']['D']++;
									}
								} else if ( $action_data['doneDate'] >= $q3_sr && $action_data['doneDate'] <= $q3_er ) {
									if ($action_data['approveAU'] == '0') {
										$incidence[$buid]['q3']['P']++;
									} else {
										$incidence[$buid]['q3']['D']++;
									}
								} else if ($action_data['doneDate'] >= $q4_sr && $action_data['doneDate'] <= $q4_er ) {
									if ( $action_data['approveAU'] == '0') {
										$incidence[$buid]['q4']['P']++;
									} else {
										$incidence[$buid]['q4']['D']++;
									}
								} else if ( $action_data['doneDate'] >= $q5_sr && $action_data['doneDate'] <= $q5_er ) {
									if ($action_data['approveAU'] == '0') {
										$incidence[$buid]['q5']['P']++;
									} else {
										$incidence[$buid]['q5']['D']++;
									}
								}else{
									if ($action_data['doneDate'] < $q1_sr && $action_data['who'] != 0 &&  $action_data['approveAU'] == '0') {
										$incidence[$buid]['q6']['A']++;
										}
								}
								
								}else{
								
								
								if($action_data['status'] == '1'){
								if ($action_data['dueDate'] >= $q1_sr && $action_data['dueDate'] <= $q1_er ) {
									if ( $action_data['approveAU'] == '0' ) {
										$incidence[$buid]['q1']['P']++;
									} else {
									  // echo $action_data['dueDate'].'---';
										$incidence[$buid]['q1']['D']++;
									}
								} else if ( $action_data['dueDate'] >= $q2_sr && $action_data['dueDate'] <= $q2_er ) {
									if ( $action_data['approveAU'] == '0') {
										$incidence[$buid]['q2']['P']++;
									} else {
										$incidence[$buid]['q2']['D']++;
									}
								} else if ( $action_data['dueDate'] >= $q3_sr && $action_data['dueDate'] <= $q3_er ) {
									if ($action_data['approveAU'] == '0') {
										$incidence[$buid]['q3']['P']++;
									} else {
										$incidence[$buid]['q3']['D']++;
									}
								} else if ($action_data['dueDate'] >= $q4_sr && $action_data['dueDate'] <= $q4_er ) {
									if ( $action_data['approveAU'] == '0') {
										$incidence[$buid]['q4']['P']++;
									} else {
										$incidence[$buid]['q4']['D']++;
									}
								} else if ( $action_data['dueDate'] >= $q5_sr && $action_data['dueDate'] <= $q5_er ) {
									if ($action_data['approveAU'] == '0') {
										$incidence[$buid]['q5']['P']++;
									} else {
										$incidence[$buid]['q5']['D']++;
									}
								}else{
									if ($action_data['dueDate'] < $q1_sr && $action_data['who'] != 0 &&  $action_data['approveAU'] == '0') {
										$incidence[$buid]['q6']['A']++;
										}
								}
								
								}
								
								
								
								}
								
								/*break;

							case 2 :
								if ( timestamp($action_data['dueDate']) >= $q1_sr && timestamp($action_data['dueDate']) < $q1_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q1']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q1']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q2_sr && timestamp($action_data['dueDate']) < $q2_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q2']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q2']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q3_sr && timestamp($action_data['dueDate']) <= $q3_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q3']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q3']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q4_sr && timestamp($action_data['dueDate']) < $q4_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q4']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q4']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q5_sr && timestamp($action_data['dueDate']) < $q5_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q5']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q5']['P']++;
									}
								}
								break;

							case 3 :
								if ( timestamp($action_data['dueDate']) >= $q1_sr && timestamp($action_data['dueDate']) < $q1_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q1']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q1']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q2_sr && timestamp($action_data['dueDate']) <= $q2_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q2']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q2']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q3_sr && timestamp($action_data['dueDate']) < $q3_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q3']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q3']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q4_sr && timestamp($action_data['dueDate']) < $q4_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q4']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q4']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q5_sr && timestamp($action_data['dueDate']) < $q5_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q5']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q5']['P']++;
									}
								}
								break;

							case 4 :
								if ( timestamp($action_data['dueDate']) >= $q1_sr && timestamp($action_data['dueDate']) < $q1_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q1']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q1']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q2_sr && timestamp($action_data['dueDate']) <= $q2_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q2']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q2']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q3_sr && timestamp($action_data['dueDate']) < $q3_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q3']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q3']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q4_sr && timestamp($action_data['dueDate']) < $q4_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q4']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q4']['P']++;
									}
								} else if ( timestamp($action_data['dueDate']) >= $q5_sr && timestamp($action_data['dueDate']) <= $q5_er ) {
									if ( $action_data['approve'] ) {
										$incidence[$buid][$riskImpact]['q5']['D']++;
									} else {
										$incidence[$buid][$riskImpact]['q5']['P']++;
									}
								}
								break;*/
						//}

					} else {
						continue;
					}

				} // end foreach $nhp_data_action_ele
			}
		}


		// initialize null records

		foreach( $dlist as $d ) {
			foreach( $hlist as $hk=>$hv ) {

				if ( empty($incidence[$d][$hk]['hazards']['D']) )  $incidence[$d][$hk]['hazards']['D'] = 0;
				if ( empty($incidence[$d][$hk]['actions']['D']) )  $incidence[$d][$hk]['actions']['D'] = 0;
				if ( empty($incidence[$d][$hk]['actions']['P']) )  $incidence[$d][$hk]['actions']['P'] = 0;

				if ( empty($incidence[$d][$hk]['q1']['D']) )  $incidence[$d][$hk]['q1']['D'] = 0;
				if ( empty($incidence[$d][$hk]['q2']['D']) )  $incidence[$d][$hk]['q2']['D'] = 0;
				if ( empty($incidence[$d][$hk]['q3']['D']) )  $incidence[$d][$hk]['q3']['D'] = 0;
				if ( empty($incidence[$d][$hk]['q4']['D']) )  $incidence[$d][$hk]['q4']['D'] = 0;
				if ( empty($incidence[$d][$hk]['q5']['D']) )  $incidence[$d][$hk]['q5']['D'] = 0;

				if ( empty($incidence[$d][$hk]['q1']['P']) )  $incidence[$d][$hk]['q1']['P'] = 0;
				if ( empty($incidence[$d][$hk]['q2']['P']) )  $incidence[$d][$hk]['q2']['P'] = 0;
				if ( empty($incidence[$d][$hk]['q3']['P']) )  $incidence[$d][$hk]['q3']['P'] = 0;
				if ( empty($incidence[$d][$hk]['q4']['P']) )  $incidence[$d][$hk]['q4']['P'] = 0;
				if ( empty($incidence[$d][$hk]['q5']['P']) )  $incidence[$d][$hk]['q5']['P'] = 0;

				$incidence[$d][$hk]['q1']['DUE']	= $incidence[$d][$hk]['q1']['D'] + $incidence[$d][$hk]['q1']['P'];
				$incidence[$d][$hk]['q2']['DUE']	= $incidence[$d][$hk]['q2']['D'] + $incidence[$d][$hk]['q1']['P'];
				$incidence[$d][$hk]['q3']['DUE']	= $incidence[$d][$hk]['q3']['D'] + $incidence[$d][$hk]['q1']['P'];
				$incidence[$d][$hk]['q4']['DUE']	= $incidence[$d][$hk]['q4']['D'] + $incidence[$d][$hk]['q1']['P'];
				$incidence[$d][$hk]['q5']['DUE'] 	= $incidence[$d][$hk]['q5']['D'] + $incidence[$d][$hk]['q1']['P'];
			}
		}


		//dump_array($ra);

			return array(
				'hlist' => $hlist,
				'dlist' => $dlist,
				'bu_list' => $bu_list,
				'section_data'=>$incidence
				);

	}

	public function getGraphData() {

		$grid_data 	= $this->getData();

		$dlist 		= $grid_data['dlist'];
		$hlist 		= $grid_data['hlist'];
		$ra 		= $grid_data['section_data'];

		$graph = array();

		foreach( $dlist as $d ) {
			//foreach( $hlist as $hk=>$hv ) {

				/*$ra[$d][$hk]['q1']['P'] = $ra[$d][$hk]['q2']['P'] = $ra[$d][$hk]['q3']['P'] = 10;
				$ra[$d][$hk]['q1']['D'] = $ra[$d][$hk]['q2']['D'] = $ra[$d][$hk]['q3']['D'] = 20;*/

				$graph['q1']['D'] += $ra[$d]['q1']['D'];
				$graph['q2']['D'] += $ra[$d]['q2']['D'];
				$graph['q3']['D'] += $ra[$d]['q3']['D'];
				$graph['q4']['D'] += $ra[$d]['q4']['D'];

				$graph['q5']['D'] += $ra[$d]['q1']['D'] + $ra[$d]['q2']['D'] + $ra[$d]['q3']['D'] + $ra[$d]['q4']['D'];

				$graph['q1']['P'] += $ra[$d]['q1']['P'];
				$graph['q2']['P'] += $ra[$d]['q2']['P'];
				$graph['q3']['P'] += $ra[$d]['q3']['P'];
				$graph['q4']['P'] += $ra[$d]['q4']['P'];

				$graph['q5']['P'] += $ra[$d]['q1']['P'] + $ra[$d]['q2']['P'] + $ra[$d]['q3']['P'] + $ra[$d]['q4']['P'];
				
				$graph['q6']['A'] += $ra[$d]['q6']['A'];

			//}
		}

		return $graph;
	}

}