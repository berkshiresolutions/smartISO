<?php
 /**
  $Id: InvestigationMain.class.php,v 4.28 Friday, February 04, 2011 5:25:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, November 04, 2010 8:32:17 AM>
  */
require_once "Action.class.php";

class DocumentActionExport 
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Investigation Id
	 *@access private
	 */
	private $investigationId;

	/**
	 *Property to hold Investigation Info
	 *@access private
	 */
	private $investigationInfo;

	private $inadequacyData;


	/**
	 * Constructor for initializing Investigation object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setInvestigationInfo($p_investigationId,$p_investigationInfo) {

		$this->investigationId		=	$p_investigationId;
		$this->investigationInfo	=	$p_investigationInfo;
	}



public function getListingforExport() {

		$heading = array(array('section'=>'Section Reference','document'=>'Document'));
$docObj = new Documents();
$optObj = new Option();
$scopeObj = SetupGeneric::useModule('DocScope');
$scopeArr = $scopeObj->displayItems();

$scope[0]="";
        foreach ($scopeArr as $scope_ele ) {
                
                $scope[$scope_ele["ID"]]="[".$scope_ele['scope']."]";
  
        }

$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$documents = $docObj->getDocumentListActionTracker();
ksort($documents);

		if(!empty($documents)){
			
			foreach($documents as $key=>$document){
				foreach($document as $documentItem){
            $document_code_info = $docObj->getSectionByStandardAndCode('52', $documentItem['fileReference']);
          
            $section_ref = $document_information['fileReference'] . " " . $document_code_info['name'];
            if ($documentItem['documentSubType'] == "W")
                $document = '[WI]';
            else
                $document = '[' . $documentItem['documentType'] . ']';

            $document .= $scope[$documentItem['scope']].'   ' . $documentItem['title'] . ' Ver ' . $documentItem['versionNew'];

            if ($version_type == 'minor_version')
                $document .="." . intval($documentItem['versionMinor']) . '</a>';
           
            
                            
                            
                            
			
			
			$result[$i]['section'] = $key;
			$result[$i]['document'] = $document;

			$i++;
	}
		}
		//$result = array_merge($heading,$result);
		return $result;
			
		}

		
	}
	

}
?>