<?php
 /**
  $Id: ActionTrackerManualhandlingTask.class.php,v 3.58 Friday, January 28, 2011 9:46:30 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";
/*
class ActionTrackerManualhandlingTask extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;

	public function getPendingMeActions() {

		$this->sql_query = "SELECT M.reference, M.businessUnit as buID,A.sectionId, A.actionID
							FROM %s.manual_handling M
							INNER JOIN %s.manual_handling_actions A
							ON M.ID = A.manualID
							WHERE A.actionID IS NOT NULL
							AND A.sectionId = %d
							AND A.actionID != 0
							ORDER BY A.ID DESC";

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedMeActions() {

		$this->sql_query = "SELECT M.reference, M.businessUnit as buID,A.sectionId, A.actionID
							FROM %s.manual_handling M
							INNER JOIN %s.manual_handling_actions A
							ON M.ID = A.manualID
							WHERE A.actionID IS NOT NULL
							AND A.sectionId = %d
							AND A.actionID != 0
							ORDER BY A.ID DESC";

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getPendingOtherActions() {

		$this->sql_query = "SELECT M.reference, M.businessUnit as buID,A.sectionId, A.actionID
							FROM %s.manual_handling M
							INNER JOIN %s.manual_handling_actions A
							ON M.ID = A.manualID
							WHERE A.actionID IS NOT NULL
							AND A.sectionId = %d
							AND A.actionID != 0
							ORDER BY A.ID DESC";

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedOtherActions() {

		$this->sql_query = "SELECT M.reference, M.businessUnit as buID,A.sectionId, A.actionID
							FROM %s.manual_handling M
							INNER JOIN %s.manual_handling_actions A
							ON M.ID = A.manualID
							WHERE A.actionID IS NOT NULL
							AND A.sectionId = %d
							AND A.actionID != 0
							ORDER BY A.ID DESC";

		return $this->getActionsByFilter(__METHOD__);
	}

	private function getActionsByFilter($p_callingMethod) {

		$USER_ID = getLoggedInUserId();

		$section_id = 3;

		$p_callingMethod_arr 	= explode('::',$p_callingMethod);
		$calling_method 		= $p_callingMethod_arr[1];
		//echo $calling_method;

		$this->sql_query = sprintf($this->sql_query,_DB_OBJ_FULL,_DB_OBJ_FULL,$section_id);
		$pStatement = $this->dbHand->prepare($this->sql_query);
		//$pStatement->bindParam(1,$section_id,PDO::PARAM_INT);

		$pStatement->execute();
		//dump_array($pStatement->errorInfo());

		$result 				=  $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$this->new_resultset 	= array();

		$organoObj = SetupGeneric::useModule('Organigram');

		if ( $result ) {
			foreach ( $result as $result_element ) {

				if ( $result_element['actionID'] != '' ) {

					$organoObj->setItemInfo(array('id'=>$result_element['buID']));
					$business_unit_arr = $organoObj->displayItemByIdForMSR();

					$this->new_resultset[$result_element['actionID']] = array('reference'=>$result_element['reference']
															  ,'buID'=>$result_element['buID']
															  ,'buName'=>$business_unit_arr['buName']);

				}
			}
		}

		$organoObj = null;

		$module_info = array();

		//echo $calling_method;

		if ($this->moduleInfo) {

			$participantObj = SetupGeneric::useModule('participant');

			foreach ( $this->moduleInfo as $module_element ) {

				$participantObj->setItemInfo(array('id'=>$module_element['who']));
				$participant_arr 				= $participantObj->displayItemMaininfoById();
				$module_element['who_name'] 	= $participant_arr['forename'].' '.$participant_arr['surname'];

				$module_element['approveAU'] = (int) $module_element['approveAU'];

				if ( $calling_method == 'getPendingMeActions' ) {

					if ( $USER_ID == $module_element['who']  && $module_element['approveAU']==0 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				if ( $USER_ID == $module_element['whoAU']  && $module_element['approveAU']==0 && $module_element['doneDescription']  ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getPendingOtherActions' ) {

					if (  $module_element['approveAU']==0 && ( $USER_ID != $module_element['who'] && $module_element['who'] != 0) ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedMeActions' ) {

					if ( ( $USER_ID == $module_element['who'] ) && $module_element['approveAU']==1 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedOtherActions' ) {

					if ( $USER_ID != $module_element['who'] && $module_element['who'] != 0 && $module_element['approveAU']==1 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				}
			}
		}

		ksort($module_info);
		$module_info = array_reverse($module_info,true);
		ksort($this->new_resultset);

		array_walk($module_info,array($this,'combine_actions_with_data'));

		return $module_info;

	}

	private function combine_actions_with_data($item,$key) {

		$item['reference'] 		= $this->new_resultset[$key]['reference'];
        $item['buID'] 			= $this->new_resultset[$key]['buID'];
		$item['buName'] 		= $this->new_resultset[$key]['buName'];
	}
}
 */
class ActionTrackerManualhandlingTask extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;
        
            public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
       // $this->sql_query = sprintf("select A.id,R.processReference,R.hazardSummary,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID where modulename='risk' and currentWho=%d and approveAU=0 
//							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);

       $this->sql_query = sprintf("select A.id,M.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription from %s.actions A  inner join %s.manual_handling_actions H on a.record=H.ID inner join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT'  and A.status=1 and currentWho=%d and approveAU=0
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
        //$this->sql_query = sprintf("select A.id,R.processReference,R.hazardSummary,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID where modulename='risk' and who=%d and approveAU=1
	//						ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
   $this->sql_query = sprintf("select A.id,M.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription from %s.actions A  inner join %s.manual_handling_actions H on a.record=H.ID left join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT' and A.who=%d and approveAU=1
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();


        if (isAdministrator()) {
          //  $this->sql_query = sprintf("select A.id,R.processReference,R.hazardSummary,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID where modulename='risk'   and approveAU=0 and not currentWho=%d
	//						ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
          $this->sql_query = sprintf("select A.id,M.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho from %s.actions A  left join %s.manual_handling_actions H on a.record=H.ID inner join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT'  and A.status=1 and not currentWho=%d and approveAU=0
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);

            } else {
   $this->sql_query = sprintf("select A.id,M.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho from %s.actions A  inner join %s.manual_handling_actions H on a.record=H.ID left join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT'  and A.status=1 and whoAU=%d and approveAU=0
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);

           	//	$this->sql_query = sprintf("select A.id,R.processReference,R.hazardSummary,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID where modulename='risk'  and approveAU=0 and whoAU=%d
		//					ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {
                $this->sql_query = sprintf("select A.id,H.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription from %s.actions A  inner join %s.manual_handling_actions H on a.record=H.ID left join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT' and approveAU=1 and not A.who=%d
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
  
          //  $this->sql_query = sprintf("select A.id,R.processReference,B.buName,R.hazardSummary,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID where modulename='risk'  and approveAU=1 and not who=%d
	//						ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
          $this->sql_query = sprintf("select A.id,H.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription from %s.actions A  inner join %s.manual_handling_actions H on a.record=H.ID left join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT' and approveAU=1 and whoAU=%d
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);

      //  			 $this->sql_query = sprintf("select A.id,R.processReference,B.buName,R.hazardSummary,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU from %s.actions A  inner join %s.risk R on a.record=R.ID left join %s.business_units B on R.buid=B.buID where modulename='risk'  and approveAU=1 and whoAU=%d
	//						ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }
       
        return $this->getActionsByFilter(__METHOD__);
    }

			        public function getTotalActions($data) {
$startdate=$data["startdate"];
$enddate=$data["enddate"];
$who =$data["who"];
$completed=(int)$data["completed"];

$startStr="";
$endStr="";    
$whoStr="";

if ($startdate)
    $startStr=" and duedate>='".format_date_for_mysql($startdate)."' ";
if ($enddate)
    $endStr=" and duedate<='".format_date_for_mysql($enddate)."' ";
if ($who)
    $whoStr=" and A.who=".$who." ";
        $this->sql_query = sprintf("select A.id,M.reference,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho from %s.actions A  inner join %s.manual_handling_actions H on a.record=H.ID inner join %s.manual_handling M on H.manualID=M.ID left join %s.business_units B on M.businessUnit =B.buID where modulename='manual_handlingT'  and A.status=1  and approveAU=%d %s %s %s
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$completed,$startStr,$endStr,$whoStr);

     
       
        return $this->getActionsByFilter(__METHOD__);
    }
	
    private function getActionsByFilter($p_callingMethod) {

        $USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
        //echo $calling_method;

        $pStatement = $this->dbHand->prepare($this->sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
}