<?php
 /**
  $Id: ProcessObjectSupport.class.php,v 3.46 Tuesday, February 01, 2011 4:35:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 3:56:38 PM>
  */

require_once "ProcessObjectInterface.int.php";

class ProcessSupport implements ProcessObjectInterface
{
	private $p_x1;
	private $p_y1;

	public function printHeadingAndDescription($classObj,$p_x1,$p_y1,$p_heading,$p_content) {

		$this->p_x1 = $p_x1;
		$this->p_y1 = $p_y1;

		$this->printHeading($classObj,$p_heading);
		$this->printDescription($classObj,$p_content);
	}

    private function printHeading($classObj,$p_content) {

        $this->p_x1 = $this->p_x1 + 5;
        $this->p_y1 = $this->p_y1 + 15;

		//$p_content = 'Vehicle Standard';

		//imagefttext($classObj->getResource(), $classObj->getBusinessUnitFontSize(), 0, $p_x1,$p_y1, $path_colour, $classObj->getFontFile(),$p_content);
		$this->wrapText($classObj,$classObj->getBusinessUnitFontSize(),$p_content,28);
    }

	private function wrapText($classObj,$p_fontsize,$p_content1,$p_wrapStrCnt) {

  $p_content=str_ireplace("<BR>"," - ",$p_content1);
		$p_content_strlen = strlen($p_content);
		$p_content_tokens = ceil($p_content_strlen/$p_wrapStrCnt);

		if ( $p_content_strlen > $p_wrapStrCnt ) {

			for ($k=0;$k<2;$k++) {

				$start_pt = $k*$p_wrapStrCnt;

				if ( $k == 1 ) {
					$end_pt = $p_content_strlen - $p_wrapStrCnt;
				} else {
					$end_pt = $p_wrapStrCnt;
				}

				imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),substr($p_content,$start_pt,$end_pt));
				$this->p_y1 = $this->p_y1 + 14;
			}
		} else {
			imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),$p_content);
			$this->p_y1 = $this->p_y1 + 14;
		}

	}

    private function printDescription($classObj,$p_content1) {

		//$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
  $p_content=str_ireplace("<BR>"," - ",$p_content1);
		$p_content_strlen = strlen($p_content);
		$max_string_length = 25;

		$this->p_y1 = $this->p_y1;

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($classObj->getResource(), 9, 0, $this->p_x1-15,$this->p_y1, $path_colour, $classObj->getFontFile_2(),$p_content);
		} else {

			$strings 	= wordwrap(substr($p_content,0,162).' ...', $max_string_length, "#", false);
			$string_arr = explode("#",$strings);

			$cy1 = $this->p_y1;

			foreach ( $string_arr as $strele ) {
				imagefttext($classObj->getResource(), 9, 0, $this->p_x1-15,$cy1, $path_colour, $classObj->getFontFile_2(),$strele);
				$cy1 = $cy1 + 11;
			}
		}
	}

	
		public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

		//$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$blockCord 	= $p_block;
		
		if ( $classObj->getOutputType() == 'H' ) 
		$x1 = $blockCord['x']+85;
		else
		$x1 = $blockCord['x']+10;
		
		$y1 = $blockCord['y'];

		$x2 = $x1 - ($p_width/2) + 5;
		$y2 = $y1 + $p_height;
		$x3 = $x1 + ($p_width/2) - 10;
		$y3 = $y1 + $p_height;



		if ( $classObj->getResample() ) {
			$resamplePercent 	= $classObj->getResamplePercent();

			$x1_resamp = ceil($x1 * $resamplePercent);
			$y1_resamp = ceil($y1 * $resamplePercent);
			$x2_resamp = ceil($x2 * $resamplePercent);
			$y2_resamp = ceil($y2 * $resamplePercent);
			$x3_resamp = ceil($x3 * $resamplePercent);
			$y3_resamp = ceil($y3 * $resamplePercent);

			$node_coordinates = $x1_resamp.','.$y1_resamp.','.$x2_resamp.','.$y2_resamp.','.$x3_resamp.','.$y3_resamp;
		} else {
			$node_coordinates = $x1.','.$y1.','.$x2.','.$y2.','.$x3.','.$y3;
		}

		$classObj->saveNodeCoordinates($p_step_info['ID'],$node_coordinates);
		
		$points = array(
			$x1,$y1,
			$x2,$y2,
			$x3,$y3
		);
		if ( $classObj->getOutputType() == 'N' ) {
		imagefilledpolygon ($classObj->getResource(),$points ,3 ,$classObj->getColour('support_colour'));
} else {
            $classObj->showExternalImage($blockCord['x'], $y1+5, 'support');
           
		}
if ( $classObj->getOutputType() == 'H' && $p_step_info['descQues'] != '' ) {

					$this->printHeadingAndDescription($classObj,$blockCord['x']+35,$y1+10,$p_step_info['buName'],$p_step_info['descQues']);

					if ( !empty($p_step_info['comments_information']['HORZ'][0]) ) {
									$this->printDescription($classObj,$x1,$y1+40,$p_width,$p_height,$p_step_info['comments_information']['HORZ'][0]);
					}
				}
	}
	
	
	public function drawa($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info) {

        $blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$path_no 	= $blockCord['path_no'];

//bob works but could be improved		
$supportdata=$classObj->block_information[$path_no][support_information];

$datacount=explode($p_block,$supportdata);

$samelane=count($datacount);


		$offset_x			= 120;

		$x = $classObj->argBlockWidth()/2;
		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

if ($samelane >=3)
{
$y+=30;
//$x+=20;
}
        if ( $classObj->getOutputType() == 'N' ) {

            $x1 = $x + $blockCord['x'] + 40;
            $y1 = $y + $blockCord['y'];

            $x2 = $x1 - ($p_width/2) + 10;
            $y2 = $y1 + $p_height;
            $x3 = $x1 + ($p_width/2) - 10;
            $y3 = $y1 + $p_height;

        } else {

            $x1 = $x + $blockCord['x'] + $offset_x;
            $y1 = $y + $blockCord['y'];

            $x2 = $x1 - ($p_width/2) + 10;
            $y2 = $y1 + $p_height;
            $x3 = $x1 + ($p_width/2) - 10;
            $y3 = $y1 + $p_height;

        }

		$ym = $blockCord['y'] + $classObj->argObjectHeight();

		$points = array(
			$x1,$y1,
			$x2,$y2,
			$x3,$y3
		);

		// save node coordinates
		if ( $classObj->getResample() ) {
			$resamplePercent 	= $classObj->getResamplePercent();

			$x1_resamp = ceil($x1 * $resamplePercent);
			$y1_resamp = ceil($y1 * $resamplePercent);
			$x2_resamp = ceil($x2 * $resamplePercent);
			$y2_resamp = ceil($y2 * $resamplePercent);
			$x3_resamp = ceil($x3 * $resamplePercent);
			$y3_resamp = ceil($y3 * $resamplePercent);

			$node_coordinates = $x1_resamp.','.$y1_resamp.','.$x2_resamp.','.$y2_resamp.','.$x3_resamp.','.$y3_resamp;
		} else {
			$node_coordinates = $x1.','.$y1.','.$x2.','.$y2.','.$x3.','.$y3;
		}

		$classObj->saveNodeCoordinates($step_info['ID'],$node_coordinates);

		imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

		$path_colour = $classObj->getPathcolour($path_no);

		//imageline($classObj->getResource(),$x1, $ym-20, $x1, $ym, $path_colour);

        if ( $classObj->getOutputType() == 'N' ) {
            imagefilledpolygon ($classObj->getResource(),$points ,3 ,$classObj->getColour('support_colour'));
            imagepolygon($classObj->getResource(),$points ,3 ,$classObj->getColour('text_colour'));
        } else if ( !empty($step_info['buName']) && $classObj->getOutputType() == 'H' ) {
if($samelane >=3)
$x2+=50;
            $classObj->showExternalImage($x2-50, $y1+35, 'support');

            //$this->printHeading($classObj,$x2-30,$y1+5,$p_width,$p_height,$step_info['buName']);
            //$this->printDescription($classObj,$x2-45,$y1,$p_width,$p_height,$step_info['descQues']);

			$this->printHeadingAndDescription($classObj,$x2-30,$y1+40,$step_info['buName'],$step_info['descQues']);

            if ( !empty($p_step_info['comments_information']['HORZ'][0]) ) {
                $this->printDescription($classObj,$x2-45,$y1+30,$p_step_info['comments_information']['HORZ'][0]);
            }
        }
/*
		imagesetthickness($classObj->getResource(), 1);

		// draw arrow
if ( $classObj->getOutputType() == 'N' ) {
  if ($samelane >=3)
{
 		$x1_arrow = $x1 - 40;
		$y1_arrow = $y1 +20;
		$x2_arrow = $x1 - 40;
		$y2_arrow = $y1 +30;
		$x3_arrow = $x1 - 50;
		$y3_arrow = $y1 + 25;

}
else  
{
            $x1_arrow = $x1 - 8;
            $y1_arrow = $y1 - 14;
            $x2_arrow = $x1 + 8;
            $y2_arrow = $y1 - 14;
            $x3_arrow = $x1;
            $y3_arrow = $y1 - 24;
}
        } else {

		 if ($samelane >=3)
			{
            $x1_arrow = $x1 - 81;
            $y1_arrow = $y1 +26;
            $x2_arrow = $x1 - 80;
            $y2_arrow = $y1 +26;
            $x3_arrow = $x1 - 80;
            $y3_arrow = $y1 + 25;
			}
			else
			{
			$x1_arrow = $x1 - 88;
            $y1_arrow = $y1 - 24;
            $x2_arrow = $x1 - 72;
            $y2_arrow = $y1 - 24;
            $x3_arrow = $x1 - 80;
            $y3_arrow = $y1 - 34;
			}

        }





		/*$x1_arrow = $x1 - 5;
		$y1_arrow = $y1 - 14;
		$x2_arrow = $x1 + 5;
		$y2_arrow = $y1 - 14;
		$x3_arrow = $x1 - 0;
		$y3_arrow = $y1 - 4;*/
/*
		$arrow_points = array(
			$x1_arrow,$y1_arrow,
			$x2_arrow,$y2_arrow,
			$x3_arrow,$y3_arrow
		);
*/
		//imagefilledpolygon($classObj->getResource(),$arrow_points ,3 ,$path_colour);

	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info) {

		//$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$blockCord 	= $p_block;

		$x1 = $blockCord['x']+10;
		$y1 = $blockCord['y'];

		$x2 = $x1 - ($p_width/2) + 10;
		$y2 = $y1 + $p_height;
		$x3 = $x1 + ($p_width/2) - 10;
		$y3 = $y1 + $p_height;

		$shade_offset = $classObj->getShadeOffset();

		$shadow_offset_points = array(
			$x1+$shade_offset,$y1+$shade_offset,
			$x2+$shade_offset,$y2+$shade_offset,
			$x3+$shade_offset,$y3+$shade_offset
		);

		$shadow2_offset_points = array(
			$x1+$shade_offset-2,$y1+$shade_offset-2,
			$x2+$shade_offset,$y2+$shade_offset-2,
			$x3+$shade_offset,$y3+$shade_offset-2
		);

		imagefilledpolygon ($classObj->getResource(),$shadow_offset_points ,3 ,$classObj->getColour('shadow2_colour'));
		imagefilledpolygon ($classObj->getResource(),$shadow2_offset_points ,3 ,$classObj->getColour('shadow_colour'));

	}

	public function drawLink($classObj,$p_start_block,$p_end_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge) {
		// do nothing
	}
}
?>