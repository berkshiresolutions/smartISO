<?php
 /**
  $Id: Contractor.class.php,v 3.60 Thursday, February 03, 2011 3:17:03 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Contractor object
  *
  * This interface will declare the various methods performed
  * by the contractor object for operations like add, edit, delete, archive, purge.
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */

require_once "Contractor.int.php";

class Contractor implements ContractorInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Property to hold tabs name and ID mapping
	 * @access private
	 */
	private $tabsMapping;

	/**
	 * Property to hold contractor ID
	 * @access private
	 */
	private $contractorId;

	/**
	 * Property to hold contractor Data
	 * @access private
	 */
	private $contractorInfo;

	/**
	 * Property to hold current contractor Tab
	 * @access private
	 */
	private $contractorCurrentTab;

	/**
	 * Property to hold upper range value
	 * @access private
	 */
	private $lowerValue;

	/**
	 * Property to hold lower range value
	 * @access private
	 */
	private $upperValue;

	/**
	 * Constructor for initializing Contractor object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 				= DB::connect(_DB_TYPE);
		$this->tabsMapping			= array(
										1 => 'companyDetails',
										2 => 'management',
										3 => 'competency',
										4 => 'policy',
										5 => 'riskAssessment',
										6 => 'consultation',
										7 => 'training',
										8 => 'maintenance',
										9 => 'insurance',
										10 => 'documents'
										);

	}

	/**
	 * to set contractor information for performing various operations with the Contractor object
	 * @param integer $p_contractorId 	This parameter is used to set contractor id for adding, editing, archiving, restoring, delete
	 * @param integer $p_currentTab 	This parameter is used to define current working tab
	 * @param array $p_contractorInfo	This array is used to pass set of parameters for each tab. This is Optional
	 */
	public function setContractorInfo($p_contractorId,$p_currentTab,$p_contractorInfo,$p_lowerValue=40,$p_upperValue=60) {

		$this->contractorId 		= $p_contractorId;
		$this->contractorCurrentTab = $p_currentTab;
		$this->contractorInfo 		= $p_contractorInfo;
		$this->lowerValue 			= $p_lowerValue;
		$this->upperValue 			= $p_upperValue;
	}


	/**
	 * This method is used to add a new contractor
	 *
	 *
	 *  Company Details Tab
	 *  unique_reference,reference,email,company_name,location,address,contact_person,date,telephone_number,fax,business unit id
	 *
	 * 	Management Tab
	 * contractor_id,responsible_health_name,responsible_health_position,responsible_environment_name,responsible_environment_position,
	 * responsible_quality_name,responsible_quality_position,competent_health_name,competent_health_position,competent_environment_name,
	 * competent_environment_position,competent_quality_name,competent_quality_position,employee_full_time,employee_part_time,self_employed_persons,
	 * self_employed_persons_count,complete_details_name_1,complete_details_name_2,complete_details_name_3,complete_details_name_4,complete_details_name_5,
	 * complete_details_name_6,complete_details_name_7,complete_details_name_8,complete_details_trade_1,complete_details_trade_2,complete_details_trade_3,
	 * complete_details_trade_4,complete_details_trade_5,complete_details_trade_6,complete_details_trade_7,complete_details_trade_8
	 *
	 *  Competency Tab
	 *  contractor_id,assess_competency1,assess_competency2,assess_competency3,communicate_issues1,communicate_issues2,
	 *  communicate_issues3,assess_health_safety,assess_environment_protection,undertake_assessment1,undertake_assessment2,
	 *  undertake_assessment3,undertake_assessment4,undertake_assessment5,undertake_assessment6,responsible_health_name,
	 *  responsible_environment_name,responsible_environment_position,responsible_quality_name,responsible_quality_position,
	 *  responsible_health_position
	 *
	 *	Policy Tab
	 *	contractor_id,trade_association,trade_association_name1,trade_association_name2,trade_association_address1,
	 *	trade_association_address2,trade_association_ref1,trade_association_ref2,iso9001,iso9001_reason,iso14001,
	 *	iso14001_reason,iso18001,iso18001_reason,continuous_improvement,health_safety_policy,environmental_policy,
	 *	quality_policy,work_instructions
	 *
	 *	Risk Assessment Tab
	 *	contractor_id,carried_risk_assessments,carry_chemical,carry_manual_handling,carry_noise_exposure,
	 *	carry_lead_exposure,carry_asbestos,carry_display_screen,detailed_method_statements,routine_pre_during
	 *
	 *	Consultation Tab
	 *	contractor_id,consult_health_safety,consult_environmental,consult_quality,formal_arrangements1,
	 *	formal_arrangements2,formal_arrangements3,training_person1_1,training_person1_2,training_person1_3,training_person1_4,
	 *	training_person2_1,training_person2_2,training_person2_3,training_person2_4,qualifications_person1,qualifications_person2,
	 *	qualifications_person3,qualifications_person4,handbooks,handbooks_comment1,handbooks_comment2,handbooks_comment3
	 *
	 *	Training Tab
	 *	contractor_id,managers_supervisors1,managers_supervisors2,managers_supervisors3,managers_supervisors4,operatives1,
	 *	operatives2,operatives3,operatives4,competent_relating1,competent_relating2,competent_relating3,competent_relating4,formal_reviews1,
	 *	formal_reviews2,formal_reviews3,formal_reviews4
	 *
	 *	Mintenance
	 *	contractor_id,electrical,access_equipments,pneumatic,gas_monitors,hydraulic,special_equipments,
	 *	electric_equipments,work_equipment,employees_accident,employees_fatality,employees_major,
	 *	employees_lost_time,persons_accident,persons_fatality,persons_major,persons_lost_time,reporting_accidents,
	 *	prosecuted_connection,prohibition_otice,improvement_notice
	 *
	 *	Insurance Tab
	 *	contractor_id,employers_insurer_name,employers_certificate_no,employers_sum_assured,employers_expiry_date,
	 *	public_insurer_name,public_certificate_no,public_sum_assured,public_expiry_date,activities_expose_employees,
	 *	provide_first_aiders,fire_risk_assessments
	 *
	 *	Documents Tab
	 *	contractor_id,contractors_questionnaire,continuous_improvement,health_safety_policy,environmental_policy,
	 *	quality_policy,health_safety_procedures,environmental_procedures,quality_procedures,examples_relevant_risk,
	 *	examples_relevant_method,example_documentation,employee_health_safety,training_certificates,work_equipment,
	 *	portable_appliance,employee_guidance_documentation,public_insurance,employers_insurance,evidence_surveillance,fire_assessment,job_title,when,who
	 *
	 * @access public
	 */
	public function addContractor() {

		$currenttab = $this->contractorCurrentTab;
		$method = $this->tabsMapping[$currenttab];

		/* Dynamic method binding for tabs*/
		$this->$method();
	}

	private function companyDetails() {

	//	$USER_ID = getLoggedInUserId();

		$sql = sprintf("INSERT INTO %s.contractor (uniqueReference,reference,emailAddress,companyName,location,address,contactPerson,
					   date,telephoneNumber,fax,archive,whoID,TRG,buID)
		VALUES ('%s','%s','%s','%s',%d,'%s','%s','%s','%s','%s','0',%d,'%s',%d)",_DB_OBJ_FULL,$this->contractorInfo['unique_reference'],
		$this->contractorInfo['reference'],$this->contractorInfo['email'],smartisoAddslashes($this->contractorInfo['company_name']),
		$this->contractorInfo['location'],smartisoAddslashes($this->contractorInfo['address']),smartisoAddslashes($this->contractorInfo['contact_person']),
		format_date_for_mysql($this->contractorInfo['whenDate']),$this->contractorInfo['telephone_number'],$this->contractorInfo['fax'],$this->contractorInfo['whoID'],
		$this->contractorInfo['trg'],$this->contractorInfo['buID']);

		$pStatement = $this->dbHand->prepare($sql);


		/*$pStatement->bindParam(1,$this->contractorInfo['unique_reference']);
		$pStatement->bindParam(2,$this->contractorInfo['reference']);
		$pStatement->bindParam(3,$this->contractorInfo['email']);
		$pStatement->bindParam(4,$this->contractorInfo['company_name']);
		$pStatement->bindParam(5,$this->contractorInfo['location']);
		$pStatement->bindParam(6,$this->contractorInfo['address']);
		$pStatement->bindParam(7,$this->contractorInfo['contact_person']);
		$pStatement->bindParam(8,format_date_for_mysql($this->contractorInfo['date']));
		$pStatement->bindParam(9,$this->contractorInfo['telephone_number']);
		$pStatement->bindParam(10,$this->contractorInfo['fax']);*/

		$pStatement->execute();

		dump_array($pStatement->errorInfo());

		//$this->contractorId = $this->dbHand->lastInsertId();
		$this->contractorId = customLastInsertId( $this->dbHand,'contractor','ID');

		$sql = sprintf("INSERT INTO %s.contractor_score (contID,scoreManagement, scoreCompetency, scorePolicy, scoreRiskAssessment, scoreConsultation, scoreTraining, scoreMaintenance, scoreInsurance, scoreDocument)
		VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d)",_DB_OBJ_FULL,$this->contractorId,0,0,0,0,0,0,0,0,0);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		/*dump_array($this);
		echo "Calling company details method";*/
	}

	private function management() {

		$sql = sprintf("INSERT INTO %s.contractor_management (cID,responsibleHealthSafetyName, responsibleHealthSafetyPosition, responsibleEnvironmentProtectionName,
				responsibleEnvironmentProtectionPosition, responsibleQualityName, responsibleQualityPosition, competentHealthSafetyName,
				competentHealthSafetyPosition, competentEnvironmentProtectionName, competentEnvironmentProtectionPosition, competentQualityName,
				competentQualityPosition, employeesFullTime, employeesPartTime, engagingSelfEmployedPersons, engagingSelfEmployedPersonsCount,
				completeDetailsName_1, completeDetailsName_2, completeDetailsName_3, completeDetailsName_4, completeDetailsName_5, completeDetailsName_6,
				completeDetailsName_7, completeDetailsName_8, completeDetailsTrade_1, completeDetailsTrade_2, completeDetailsTrade_3, completeDetailsTrade_4,
				completeDetailsTrade_5, completeDetailsTrade_6, completeDetailsTrade_7, completeDetailsTrade_8)
				VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',
				'%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,$this->contractorInfo['contractor_id'],smartisoAddslashes($this->contractorInfo['responsible_health_name']),
				smartisoAddslashes($this->contractorInfo['responsible_health_position']),smartisoAddslashes($this->contractorInfo['responsible_environment_name']),
				smartisoAddslashes($this->contractorInfo['responsible_environment_position']),
				smartisoAddslashes($this->contractorInfo['responsible_quality_name']),smartisoAddslashes($this->contractorInfo['responsible_quality_position']),
				smartisoAddslashes($this->contractorInfo['competent_health_name']),
				smartisoAddslashes($this->contractorInfo['competent_health_position']),smartisoAddslashes($this->contractorInfo['competent_environment_name']),
				smartisoAddslashes($this->contractorInfo['competent_environment_position']),
				smartisoAddslashes($this->contractorInfo['competent_quality_name']),smartisoAddslashes($this->contractorInfo['competent_quality_position']),$this->contractorInfo['employee_full_time'],
				$this->contractorInfo['employee_part_time'],$this->contractorInfo['self_employed_persons'],$this->contractorInfo['self_employed_persons_count'],
				smartisoAddslashes($this->contractorInfo['complete_details_name_1']),smartisoAddslashes($this->contractorInfo['complete_details_name_2']),smartisoAddslashes($this->contractorInfo['complete_details_name_3']),
				smartisoAddslashes($this->contractorInfo['complete_details_name_4']),smartisoAddslashes($this->contractorInfo['complete_details_name_5']),smartisoAddslashes($this->contractorInfo['complete_details_name_6']),
				smartisoAddslashes($this->contractorInfo['complete_details_name_7']),smartisoAddslashes($this->contractorInfo['complete_details_name_8']),smartisoAddslashes($this->contractorInfo['complete_details_trade_1']),
				smartisoAddslashes($this->contractorInfo['complete_details_trade_2']),smartisoAddslashes($this->contractorInfo['complete_details_trade_3']),smartisoAddslashes($this->contractorInfo['complete_details_trade_4']),
				smartisoAddslashes($this->contractorInfo['complete_details_trade_5']),smartisoAddslashes($this->contractorInfo['complete_details_trade_6']),smartisoAddslashes($this->contractorInfo['complete_details_trade_7']),
				smartisoAddslashes($this->contractorInfo['complete_details_trade_8']));

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		//dump_array_and_exit($pStatement->errorInfo());

		//dump_array($this);
		//echo "Calling management method";

		$this->add_management_metadata();
		$this->saveTabScore(1);
		$this->updateScore(1);
	}

	private function competency() {

		$sql = sprintf("INSERT INTO %s.contractor_competency (cID, assessCompetency_1,assessCompetency_2,assessCompetency_3,communicateIssues_1,communicateIssues_2,
		communicateIssues_3,assessHealthSafety,assessEnvironmentProtection,undertakeAssessment_1,undertakeAssessment_2,undertakeAssessment_3,
		undertakeAssessment_4,undertakeAssessment_5,undertakeAssessment_6,responsibleHealthSafetyName,responsibleHealthSafetyPosition,
		responsibleEnvironmentProtectionName,responsibleEnvironmentProtectionPosition,responsibleQualityName,responsibleQualityPosition)
		VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],smartisoAddslashes($this->contractorInfo['assess_competency1']),smartisoAddslashes($this->contractorInfo['assess_competency2']),
		smartisoAddslashes($this->contractorInfo['assess_competency3']),smartisoAddslashes($this->contractorInfo['communicate_issues1']),smartisoAddslashes($this->contractorInfo['communicate_issues2']),
		smartisoAddslashes($this->contractorInfo['communicate_issues3']),$this->contractorInfo['assess_health_safety'],$this->contractorInfo['assess_environment_protection'],
		smartisoAddslashes($this->contractorInfo['undertake_assessment1']),smartisoAddslashes($this->contractorInfo['undertake_assessment2']),smartisoAddslashes($this->contractorInfo['undertake_assessment3']),
		smartisoAddslashes($this->contractorInfo['undertake_assessment4']),smartisoAddslashes($this->contractorInfo['undertake_assessment5']),smartisoAddslashes($this->contractorInfo['undertake_assessment6']),
		smartisoAddslashes($this->contractorInfo['responsible_health_name']),smartisoAddslashes($this->contractorInfo['responsible_health_position']),smartisoAddslashes($this->contractorInfo['responsible_environment_name']),
		smartisoAddslashes($this->contractorInfo['responsible_environment_position']),smartisoAddslashes($this->contractorInfo['responsible_quality_name']),
		smartisoAddslashes($this->contractorInfo['responsible_quality_position']));

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['assess_competency1']);
		$pStatement->bindParam(3,$this->contractorInfo['assess_competency2']);
		$pStatement->bindParam(4,$this->contractorInfo['assess_competency3']);
		$pStatement->bindParam(5,$this->contractorInfo['communicate_issues1']);
		$pStatement->bindParam(6,$this->contractorInfo['communicate_issues2']);
		$pStatement->bindParam(7,$this->contractorInfo['communicate_issues3']);
		$pStatement->bindParam(8,$this->contractorInfo['assess_health_safety']);
		$pStatement->bindParam(9,$this->contractorInfo['assess_environment_protection']);
		$pStatement->bindParam(10,$this->contractorInfo['undertake_assessment1']);
		$pStatement->bindParam(11,$this->contractorInfo['undertake_assessment2']);
		$pStatement->bindParam(12,$this->contractorInfo['undertake_assessment3']);
		$pStatement->bindParam(13,$this->contractorInfo['undertake_assessment4']);
		$pStatement->bindParam(14,$this->contractorInfo['undertake_assessment5']);
		$pStatement->bindParam(15,$this->contractorInfo['undertake_assessment6']);
		$pStatement->bindParam(16,$this->contractorInfo['responsible_health_name']);
		$pStatement->bindParam(17,$this->contractorInfo['responsible_health_position']);
		$pStatement->bindParam(18,$this->contractorInfo['responsible_environment_name']);
		$pStatement->bindParam(19,$this->contractorInfo['responsible_environment_position']);
		$pStatement->bindParam(20,$this->contractorInfo['responsible_quality_name']);
		$pStatement->bindParam(21,$this->contractorInfo['responsible_quality_position']);*/

		$pStatement->execute();

		/*dump_array($this);
		echo "Calling competency method";*/
		$this->add_competency_metadata();
		$this->saveTabScore(2);
		$this->updateScore(2);
	}

	private function policy() {

		$sql = sprintf("INSERT INTO %s.contractor_policy (cID, tradeAssociation,tradeAssociationName_1,tradeAssociationName_2,
		tradeAssociationAddress_1,tradeAssociationAddress_2,tradeAssociationMemberRef_1,tradeAssociationMemberRef_2,iso9001,
		iso9001Reason,iso14001,iso14001Reason,iso18001,iso18001Reason,continuousImprovement,healthSafetyPolicy,environmentalPolicy,
		qualityPolicy,workInstructions ) VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],$this->contractorInfo['trade_association'],smartisoAddslashes($this->contractorInfo['trade_association_name1']),
		smartisoAddslashes($this->contractorInfo['trade_association_name2']),smartisoAddslashes($this->contractorInfo['trade_association_address1']),smartisoAddslashes($this->contractorInfo['trade_association_address2']),
		smartisoAddslashes($this->contractorInfo['trade_association_ref1']),smartisoAddslashes($this->contractorInfo['trade_association_ref2']),smartisoAddslashes($this->contractorInfo['iso14001_reason']),
		smartisoAddslashes($this->contractorInfo['iso9001_reason']),$this->contractorInfo['iso14001'],$this->contractorInfo['contractor_id'],
		$this->contractorInfo['iso18001'],smartisoAddslashes($this->contractorInfo['iso18001_reason']),$this->contractorInfo['continuous_improvement'],
		$this->contractorInfo['health_safety_policy'],$this->contractorInfo['environmental_policy'],$this->contractorInfo['quality_policy'],
		$this->contractorInfo['work_instructions']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['trade_association']);
		$pStatement->bindParam(3,$this->contractorInfo['trade_association_name1']);
		$pStatement->bindParam(4,$this->contractorInfo['trade_association_name2']);
		$pStatement->bindParam(5,$this->contractorInfo['trade_association_address1']);
		$pStatement->bindParam(6,$this->contractorInfo['trade_association_address2']);
		$pStatement->bindParam(7,$this->contractorInfo['trade_association_ref1']);
		$pStatement->bindParam(8,$this->contractorInfo['trade_association_ref2']);
		$pStatement->bindParam(9,$this->contractorInfo['iso9001']);
		$pStatement->bindParam(10,$this->contractorInfo['iso9001_reason']);
		$pStatement->bindParam(11,$this->contractorInfo['iso14001']);
		$pStatement->bindParam(12,$this->contractorInfo['iso14001_reason']);
		$pStatement->bindParam(13,$this->contractorInfo['iso18001']);
		$pStatement->bindParam(14,$this->contractorInfo['iso18001_reason']);
		$pStatement->bindParam(15,$this->contractorInfo['continuous_improvement']);
		$pStatement->bindParam(16,$this->contractorInfo['health_safety_policy']);
		$pStatement->bindParam(17,$this->contractorInfo['environmental_policy']);
		$pStatement->bindParam(18,$this->contractorInfo['quality_policy']);
		$pStatement->bindParam(19,$this->contractorInfo['work_instructions']);*/

		$pStatement->execute();

		$this->add_policy_metadata();
		$this->saveTabScore(3);
		$this->updateScore(3);
		/*dump_array($this);
		echo "Calling policy method";*/
	}

	private function riskAssessment() {

		$sql = sprintf("INSERT INTO %s.contractor_risk_assessment (cID, carriedRiskAssessments,carryChemical,carryManualHandling,
		carryNoiseExposure,carryLeadExposure,carryAsbestos,carryDisplayScreen,detailedMethodStatements,
		routinePreDuringPost ) VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],$this->contractorInfo['carried_risk_assessments'],$this->contractorInfo['carry_chemical'],
		$this->contractorInfo['carry_manual_handling'],$this->contractorInfo['carry_noise_exposure'],$this->contractorInfo['carry_lead_exposure'],
		$this->contractorInfo['carry_asbestos'],$this->contractorInfo['carry_display_screen'],$this->contractorInfo['detailed_method_statements'],
		$this->contractorInfo['routine_pre_during']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['carried_risk_assessments']);
		$pStatement->bindParam(3,$this->contractorInfo['carry_chemical']);
		$pStatement->bindParam(4,$this->contractorInfo['carry_manual_handling']);
		$pStatement->bindParam(5,$this->contractorInfo['carry_noise_exposure']);
		$pStatement->bindParam(6,$this->contractorInfo['carry_lead_exposure']);
		$pStatement->bindParam(7,$this->contractorInfo['carry_asbestos']);
		$pStatement->bindParam(8,$this->contractorInfo['carry_display_screen']);
		$pStatement->bindParam(9,$this->contractorInfo['detailed_method_statements']);
		$pStatement->bindParam(10,$this->contractorInfo['routine_pre_during']);*/

		$pStatement->execute();
		$this->add_risk_assessment_metadata();
		$this->saveTabScore(4);
		$this->updateScore(4);
		/*dump_array($this);
		echo "Calling risk assessment method";*/
	}

	private function consultation() {

		$sql = sprintf("INSERT INTO %s.contractor_consultation (cID, consultHealthSafety,consultEnvironmental,consultQuality,formalArrangements_1,formalArrangements_2,
		formalArrangements_3,trainingPerson_1_1,trainingPerson_1_2,trainingPerson_1_3,trainingPerson_1_4,trainingPerson_2_1,
		trainingPerson_2_2,trainingPerson_2_3,trainingPerson_2_4,qualificationsPerson_1,qualificationsPerson_2,
		qualificationsPerson_3,qualificationsPerson_4,handbooks,handbooksComment_1,handbooksComment_2,handbooksComment_3)
		VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],$this->contractorInfo['consult_health_safety'],$this->contractorInfo['consult_environmental'],
		$this->contractorInfo['consult_quality'],smartisoAddslashes($this->contractorInfo['formal_arrangements1']),smartisoAddslashes($this->contractorInfo['formal_arrangements2']),
		smartisoAddslashes($this->contractorInfo['formal_arrangements3']),smartisoAddslashes($this->contractorInfo['training_person1_1']),smartisoAddslashes($this->contractorInfo['training_person1_2']),
		smartisoAddslashes($this->contractorInfo['training_person1_3']),smartisoAddslashes($this->contractorInfo['training_person1_4']),smartisoAddslashes($this->contractorInfo['training_person2_1']),
		smartisoAddslashes($this->contractorInfo['training_person2_2']),smartisoAddslashes($this->contractorInfo['training_person2_3']),smartisoAddslashes($this->contractorInfo['training_person2_4']),
		smartisoAddslashes($this->contractorInfo['qualifications_person1']),smartisoAddslashes($this->contractorInfo['qualifications_person2']),smartisoAddslashes($this->contractorInfo['qualifications_person3']),
		smartisoAddslashes($this->contractorInfo['qualifications_person4']),$this->contractorInfo['handbooks'],smartisoAddslashes($this->contractorInfo['handbooks_comment1']),
		smartisoAddslashes($this->contractorInfo['handbooks_comment2']),smartisoAddslashes($this->contractorInfo['handbooks_comment3']));

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['consult_health_safety']);
		$pStatement->bindParam(3,$this->contractorInfo['consult_environmental']);
		$pStatement->bindParam(4,$this->contractorInfo['consult_quality']);
		$pStatement->bindParam(5,$this->contractorInfo['formal_arrangements1']);
		$pStatement->bindParam(6,$this->contractorInfo['formal_arrangements2']);
		$pStatement->bindParam(7,$this->contractorInfo['formal_arrangements3']);
		$pStatement->bindParam(8,$this->contractorInfo['training_person1_1']);
		$pStatement->bindParam(9,$this->contractorInfo['training_person1_2']);
		$pStatement->bindParam(10,$this->contractorInfo['training_person1_3']);
		$pStatement->bindParam(11,$this->contractorInfo['training_person1_4']);
		$pStatement->bindParam(12,$this->contractorInfo['training_person2_1']);
		$pStatement->bindParam(13,$this->contractorInfo['training_person2_2']);
		$pStatement->bindParam(14,$this->contractorInfo['training_person2_3']);
		$pStatement->bindParam(15,$this->contractorInfo['training_person2_4']);
		$pStatement->bindParam(16,$this->contractorInfo['qualifications_person1']);
		$pStatement->bindParam(17,$this->contractorInfo['qualifications_person2']);
		$pStatement->bindParam(18,$this->contractorInfo['qualifications_person3']);
		$pStatement->bindParam(19,$this->contractorInfo['qualifications_person4']);
		$pStatement->bindParam(20,$this->contractorInfo['handbooks']);
		$pStatement->bindParam(21,$this->contractorInfo['handbooks_comment1']);
		$pStatement->bindParam(22,$this->contractorInfo['handbooks_comment2']);
		$pStatement->bindParam(23,$this->contractorInfo['handbooks_comment3']);*/

		$pStatement->execute();

		$this->add_consultation_metadata();
		$this->saveTabScore(5);
		$this->updateScore(5);
		/*dump_array($this);
		echo "Calling consultation method";*/
	}

	private function training() {

		$sql = sprintf("INSERT INTO %s.contractor_training (cID, managersSupervisors_1,managersSupervisors_2,managersSupervisors_3,
		managersSupervisors_4,operatives_1,operatives_2,operatives_3,operatives_4,
		competentRelating_1,competentRelating_2,competentRelating_3,competentRelating_4,formalReviews_1,formalReviews_2,formalReviews_3,formalReviews_4)
		VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],smartisoAddslashes($this->contractorInfo['managers_supervisors1']),smartisoAddslashes($this->contractorInfo['managers_supervisors2']),
		smartisoAddslashes($this->contractorInfo['managers_supervisors3']),smartisoAddslashes($this->contractorInfo['managers_supervisors4']),smartisoAddslashes($this->contractorInfo['operatives1']),
		smartisoAddslashes($this->contractorInfo['operatives2']),smartisoAddslashes($this->contractorInfo['operatives3']),smartisoAddslashes($this->contractorInfo['operatives4']),
		smartisoAddslashes($this->contractorInfo['competent_relating1']),smartisoAddslashes($this->contractorInfo['competent_relating2']),smartisoAddslashes($this->contractorInfo['competent_relating3']),
		smartisoAddslashes($this->contractorInfo['competent_relating4']),smartisoAddslashes($this->contractorInfo['formal_reviews1']),smartisoAddslashes($this->contractorInfo['formal_reviews2']),
		smartisoAddslashes($this->contractorInfo['formal_reviews3']),smartisoAddslashes($this->contractorInfo['formal_reviews4']));

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['managers_supervisors1']);
		$pStatement->bindParam(3,$this->contractorInfo['managers_supervisors2']);
		$pStatement->bindParam(4,$this->contractorInfo['managers_supervisors3']);
		$pStatement->bindParam(5,$this->contractorInfo['managers_supervisors4']);
		$pStatement->bindParam(6,$this->contractorInfo['operatives1']);
		$pStatement->bindParam(7,$this->contractorInfo['operatives2']);
		$pStatement->bindParam(8,$this->contractorInfo['operatives3']);
		$pStatement->bindParam(9,$this->contractorInfo['operatives4']);
		$pStatement->bindParam(10,$this->contractorInfo['competent_relating1']);
		$pStatement->bindParam(11,$this->contractorInfo['competent_relating2']);
		$pStatement->bindParam(12,$this->contractorInfo['competent_relating3']);
		$pStatement->bindParam(13,$this->contractorInfo['competent_relating4']);
		$pStatement->bindParam(14,$this->contractorInfo['formal_reviews1']);
		$pStatement->bindParam(15,$this->contractorInfo['formal_reviews2']);
		$pStatement->bindParam(16,$this->contractorInfo['formal_reviews3']);
		$pStatement->bindParam(17,$this->contractorInfo['formal_reviews4']);*/

		$pStatement->execute();

		$this->add_training_metadata();
		$this->saveTabScore(6);
		$this->updateScore(6);
		/*dump_array($this);
		echo "Calling training method";*/
	}

	private function maintenance() {

		$sql = sprintf("INSERT INTO %s.contractor_maintenance (cID, electrical, accessEquipments, pneumatic, gasMonitors, hydraulic, specialTestEquipments,
				electricEquipments, workEquipment, employeesNoAccident, employeesFatality, employeesMajor, employeesLostTime, personsNoAccident,
				personsFatality, personsMajor, personsLostTime, reportingAccidents, prosecutedConnection, prohibitionNotice, improvementNotice)
				VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
				$this->contractorInfo['contractor_id'],$this->contractorInfo['electrical'],$this->contractorInfo['access_equipments'],
				$this->contractorInfo['pneumatic'],$this->contractorInfo['gas_monitors'],$this->contractorInfo['hydraulic'],
				$this->contractorInfo['special_equipments'],$this->contractorInfo['electric_equipments'],$this->contractorInfo['work_equipment'],
				smartisoAddslashes($this->contractorInfo['employees_accident']),smartisoAddslashes($this->contractorInfo['employees_fatality']),smartisoAddslashes($this->contractorInfo['employees_major']),
				smartisoAddslashes($this->contractorInfo['employees_lost_time']),smartisoAddslashes($this->contractorInfo['persons_accident']),smartisoAddslashes($this->contractorInfo['persons_fatality']),
				smartisoAddslashes($this->contractorInfo['persons_major']),smartisoAddslashes($this->contractorInfo['persons_lost_time']),$this->contractorInfo['reporting_accidents'],
				$this->contractorInfo['prosecuted_connection'],$this->contractorInfo['prohibition_otice'],$this->contractorInfo['improvement_notice']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['electrical']);
		$pStatement->bindParam(3,$this->contractorInfo['access_equipments']);
		$pStatement->bindParam(4,$this->contractorInfo['pneumatic']);
		$pStatement->bindParam(5,$this->contractorInfo['gas_monitors']);
		$pStatement->bindParam(6,$this->contractorInfo['hydraulic']);
		$pStatement->bindParam(7,$this->contractorInfo['special_equipments']);
		$pStatement->bindParam(8,$this->contractorInfo['electric_equipments']);
		$pStatement->bindParam(9,$this->contractorInfo['work_equipment']);
		$pStatement->bindParam(10,$this->contractorInfo['employees_accident']);
		$pStatement->bindParam(11,$this->contractorInfo['employees_fatality']);
		$pStatement->bindParam(12,$this->contractorInfo['employees_major']);
		$pStatement->bindParam(13,$this->contractorInfo['employees_lost_time']);
		$pStatement->bindParam(14,$this->contractorInfo['persons_accident']);
		$pStatement->bindParam(15,$this->contractorInfo['persons_fatality']);
		$pStatement->bindParam(16,$this->contractorInfo['persons_major']);
		$pStatement->bindParam(17,$this->contractorInfo['persons_lost_time']);
		$pStatement->bindParam(18,$this->contractorInfo['reporting_accidents']);
		$pStatement->bindParam(19,$this->contractorInfo['prosecuted_connection']);
		$pStatement->bindParam(20,$this->contractorInfo['prohibition_otice']);
		$pStatement->bindParam(21,$this->contractorInfo['improvement_notice']);*/

		$pStatement->execute();

		$this->add_maintenance_metadata();
		$this->saveTabScore(7);
		$this->updateScore(7);
		/*dump_array($this);
		echo "Calling maintenance method";*/
	}

	private function insurance() {

		$sql = sprintf("INSERT INTO %s.contractor_insurance (cID, employersLiabilityInsurerName,employersLiabilityCertificateNo,employersLiabilitySumAssured,
		employersLiabilityExpiryDate,publicLiabilityInsurerName,publicLiabilityCertificateNo,publicLiabilitySumAssured,publicLiabilityExpiryDate,
		activitiesExposeEmployees,provideFirstAiders,fireRiskAssessments)
		VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],smartisoAddslashes($this->contractorInfo['employers_insurer_name']),smartisoAddslashes($this->contractorInfo['employers_certificate_no']),
		smartisoAddslashes($this->contractorInfo['employers_sum_assured']),format_date_for_mysql($this->contractorInfo['employers_expiry_date']),smartisoAddslashes($this->contractorInfo['public_insurer_name']),
		smartisoAddslashes($this->contractorInfo['public_certificate_no']),smartisoAddslashes($this->contractorInfo['public_sum_assured']),format_date_for_mysql($this->contractorInfo['public_expiry_date']),
		$this->contractorInfo['activities_expose_employees'],$this->contractorInfo['provide_first_aiders'],$this->contractorInfo['fire_risk_assessments']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['employers_insurer_name']);
		$pStatement->bindParam(3,$this->contractorInfo['employers_certificate_no']);
		$pStatement->bindParam(4,$this->contractorInfo['employers_sum_assured']);
		$pStatement->bindParam(5,format_date_for_mysql($this->contractorInfo['employers_expiry_date']));
		$pStatement->bindParam(6,$this->contractorInfo['public_insurer_name']);
		$pStatement->bindParam(7,$this->contractorInfo['public_certificate_no']);
		$pStatement->bindParam(8,$this->contractorInfo['public_sum_assured']);
		$pStatement->bindParam(9,format_date_for_mysql($this->contractorInfo['public_expiry_date']));
		$pStatement->bindParam(10,$this->contractorInfo['activities_expose_employees']);
		$pStatement->bindParam(11,$this->contractorInfo['provide_first_aiders']);
		$pStatement->bindParam(12,$this->contractorInfo['fire_risk_assessments']);*/

		$pStatement->execute();

		$this->add_insurance_metadata();
		$this->saveTabScore(8);
		$this->updateScore(8);
		/*dump_array($this);
		echo "Calling insurance method";*/
	}

	private function documents() {

		$date = $this->contractorInfo['when'] ==  '' ? '1900-01-01' : format_date_for_mysql($this->contractorInfo['when']);

		$sql = sprintf("INSERT INTO %s.contractor_documents (cID, subContractorsQuestionnaire,continuousImprovement,healthSafetyPolicy,environmentalPolicy,qualityPolicy,
		healthSafetyProcedures,environmentalProcedures,qualityProcedures,examplesRelevantRisk,examplesRelevantMethod,exampleDocumentation,
		employeeHealthSafety,trainingCertificates,workEquipment,portableAppliance,employeeGuidanceDocumentation,
		publicLiabilityInsurance,employersLiabilityInsurance,evidenceHealthSurveillance,fireRiskAssessment,jobTitle,docWhen,who)
		VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",_DB_OBJ_FULL,
		$this->contractorInfo['contractor_id'],$this->contractorInfo['contractors_questionnaire'],$this->contractorInfo['continuous_improvement'],
		$this->contractorInfo['health_safety_policy'],$this->contractorInfo['environmental_policy'],$this->contractorInfo['quality_policy'],
		$this->contractorInfo['health_safety_procedures'],$this->contractorInfo['environmental_procedures'],$this->contractorInfo['quality_procedures'],
		$this->contractorInfo['examples_relevant_risk'],$this->contractorInfo['examples_relevant_method'],$this->contractorInfo['example_documentation'],
		$this->contractorInfo['employee_health_safety'],$this->contractorInfo['training_certificates'],$this->contractorInfo['work_equipment'],
		$this->contractorInfo['portable_appliance'],$this->contractorInfo['employee_guidance_documentation'],$this->contractorInfo['public_insurance'],
		$this->contractorInfo['employers_insurance'],$this->contractorInfo['evidence_surveillance'],$this->contractorInfo['fire_assessment'],
		smartisoAddslashes($this->contractorInfo['job_title']),$date,$this->contractorInfo['who']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractor_id']);
		$pStatement->bindParam(2,$this->contractorInfo['contractors_questionnaire']);
		$pStatement->bindParam(3,$this->contractorInfo['continuous_improvement']);
		$pStatement->bindParam(4,$this->contractorInfo['health_safety_policy']);
		$pStatement->bindParam(5,$this->contractorInfo['environmental_policy']);
		$pStatement->bindParam(6,$this->contractorInfo['quality_policy']);
		$pStatement->bindParam(7,$this->contractorInfo['health_safety_procedures']);
		$pStatement->bindParam(8,$this->contractorInfo['environmental_procedures']);
		$pStatement->bindParam(9,$this->contractorInfo['quality_procedures']);
		$pStatement->bindParam(10,$this->contractorInfo['examples_relevant_risk']);
		$pStatement->bindParam(11,$this->contractorInfo['examples_relevant_method']);
		$pStatement->bindParam(12,$this->contractorInfo['example_documentation']);
		$pStatement->bindParam(13,$this->contractorInfo['employee_health_safety']);
		$pStatement->bindParam(14,$this->contractorInfo['training_certificates']);
		$pStatement->bindParam(15,$this->contractorInfo['work_equipment']);
		$pStatement->bindParam(16,$this->contractorInfo['portable_appliance']);
		$pStatement->bindParam(17,$this->contractorInfo['employee_guidance_documentation']);
		$pStatement->bindParam(18,$this->contractorInfo['public_insurance']);
		$pStatement->bindParam(19,$this->contractorInfo['employers_insurance']);
		$pStatement->bindParam(20,$this->contractorInfo['evidence_surveillance']);
		$pStatement->bindParam(21,$this->contractorInfo['fire_assessment']);
		$pStatement->bindParam(22,$this->contractorInfo['job_title']);
		$pStatement->bindParam(23,$date);
		$pStatement->bindParam(24,$this->contractorInfo['who']);*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

		$this->add_documents_metadata();
		$this->saveTabScore(9);
		$this->updateScore(9);
		/*dump_array($this);
		echo "Calling documents method";*/

	}

	/*
	 * This method is used to view the contractor information.
	 */
	public function viewContractor() {
		$currenttab = $this->contractorCurrentTab;
		$method = "view".ucwords($this->tabsMapping[$currenttab]);

		/* Dynamic method binding for tabs*/
		$data = $this->$method();
		return $data;
	}

	private function viewCompanyDetails() {

		$sql = sprintf("SELECT * FROM %s.contractor WHERE ID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewManagement() {

		$sql = sprintf("SELECT * FROM %s.contractor_management WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewCompetency() {

		$sql = sprintf("SELECT * FROM %s.contractor_competency WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewPolicy() {

		$sql = sprintf("SELECT * FROM %s.contractor_policy WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewRiskAssessment() {

		$sql = sprintf("SELECT * FROM %s.contractor_risk_assessment WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewConsultation() {

		$sql = sprintf("SELECT * FROM %s.contractor_consultation WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewTraining() {

		$sql = sprintf("SELECT * FROM %s.contractor_training WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewMaintenance() {

		$sql = sprintf("SELECT * FROM %s.contractor_maintenance WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewInsurance() {

		$sql = sprintf("SELECT * FROM %s.contractor_insurance WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	private function viewDocuments() {

		$sql = sprintf("SELECT * FROM %s.contractor_documents WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to edit the contractor
	 *
	 * Company Details Tab
	 *  unique_reference,reference,email,company_name,location,address,contact_person,date,telephone_number,fax
	 *
	 * 	Management Tab
	 * responsible_health_name,responsible_health_position,responsible_environment_name,responsible_environment_position,
	 * responsible_quality_name,responsible_quality_position,competent_health_name,competent_health_position,competent_environment_name,
	 * competent_environment_position,competent_quality_name,competent_quality_position,employee_full_time,employee_part_time,self_employed_persons,
	 * self_employed_persons_count,complete_details_name_1,complete_details_name_2,complete_details_name_3,complete_details_name_4,complete_details_name_5,
	 * complete_details_name_6,complete_details_name_7,complete_details_name_8,complete_details_trade_1,complete_details_trade_2,complete_details_trade_3,
	 * complete_details_trade_4,complete_details_trade_5,complete_details_trade_6,complete_details_trade_7,complete_details_trade_8
	 *
	 *  Competency Tab
	 *  assess_competency1,assess_competency2,assess_competency3,communicate_issues1,communicate_issues2,
	 *  communicate_issues3,assess_health_safety,assess_environment_protection,undertake_assessment1,undertake_assessment2,
	 *  undertake_assessment3,undertake_assessment4,undertake_assessment5,undertake_assessment6,responsible_health_name,
	 *  responsible_environment_name,responsible_environment_position,responsible_quality_name,responsible_quality_position,
	 *  responsible_health_position
	 *
	 *	Policy Tab
	 *	trade_association,trade_association_name1,trade_association_name2,trade_association_address1,
	 *	trade_association_address2,trade_association_ref1,trade_association_ref2,iso9001,iso9001_reason,iso14001,
	 *	iso14001_reason,iso18001,iso18001_reason,continuous_improvement,health_safety_policy,environmental_policy,
	 *	quality_policy,work_instructions
	 *
	 *	Risk Assessment Tab
	 *	carried_risk_assessments,carry_chemical,carry_manual_handling,carry_noise_exposure,
	 *	carry_lead_exposure,carry_asbestos,carry_display_screen,detailed_method_statements,routine_pre_during
	 *
	 *	Consultation Tab
	 *	consult_health_safety,consult_environmental,consult_quality,formal_arrangements1,
	 *	formal_arrangements2,formal_arrangements3,training_person1_1,training_person1_2,training_person1_3,training_person1_4,
	 *	training_person2_1,training_person2_2,training_person2_3,training_person2_4,qualifications_person1,qualifications_person2,
	 *	qualifications_person3,qualifications_person4,handbooks,handbooks_comment1,handbooks_comment2,handbooks_comment3
	 *
	 *	Training Tab
	 *	managers_supervisors1,managers_supervisors2,managers_supervisors3,managers_supervisors4,operatives1,
	 *	operatives2,operatives3,operatives4,competent_relating1,competent_relating2,competent_relating3,competent_relating4,formal_reviews1,
	 *	formal_reviews2,formal_reviews3,formal_reviews4
	 *
	 *	Mintenance
	 *	electrical,access_equipments,pneumatic,gas_monitors,hydraulic,special_equipments,
	 *	electric_equipments,work_equipment,employees_accident,employees_fatality,employees_major,
	 *	employees_lost_time,persons_accident,persons_fatality,persons_major,persons_lost_time,reporting_accidents,
	 *	prosecuted_connection,prohibition_otice,improvement_notice
	 *
	 *	Insurance Tab
	 *	employers_insurer_name,employers_certificate_no,employers_sum_assured,employers_expiry_date,
	 *	public_insurer_name,public_certificate_no,public_sum_assured,public_expiry_date,activities_expose_employees,
	 *	provide_first_aiders,fire_risk_assessments
	 *
	 *	Documents Tab
	 *	contractors_questionnaire,continuous_improvement,health_safety_policy,environmental_policy,
	 *	quality_policy,health_safety_procedures,environmental_procedures,quality_procedures,examples_relevant_risk,
	 *	examples_relevant_method,example_documentation,employee_health_safety,training_certificates,work_equipment,
	 *	portable_appliance,employee_guidance_documentation,public_insurance,employers_insurance,evidence_surveillance,fire_assessment,job_title,when,who

	 */
	public function editContractor() {

		$currenttab = $this->contractorCurrentTab;
		$method = "edit".ucwords($this->tabsMapping[$currenttab]);

		/* Dynamic method binding for tabs*/
		$this->$method();
	}

	private function editCompanyDetails() {

		$date = $this->contractorInfo['whenDate'] = '' ? '1900-01-01' : format_date_for_mysql($this->contractorInfo['whenDate']);

		$sql = sprintf("UPDATE %s.contractor SET emailAddress = '%s',
										companyName = '%s',
										location = %d,
										address = '%s',
										contactPerson = '%s',
										date = '%s',
										telephoneNumber = '%s',
										fax = '%s',
										buID = %d,
										TRG = '%s'
									WHERE ID = %d",_DB_OBJ_FULL,
						$this->contractorInfo['email'],smartisoAddslashes($this->contractorInfo['company_name']),
						$this->contractorInfo['location'],smartisoAddslashes($this->contractorInfo['address']),smartisoAddslashes($this->contractorInfo['contact_person']),
						$date,$this->contractorInfo['telephone_number'],$this->contractorInfo['fax'],
						$this->contractorInfo['buID'],$this->contractorInfo['trg'],$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['email']);
		$pStatement->bindParam(2,$this->contractorInfo['company_name']);
		$pStatement->bindParam(3,$this->contractorInfo['location']);
		$pStatement->bindParam(4,$this->contractorInfo['address']);
		$pStatement->bindParam(5,$this->contractorInfo['contact_person']);
		$pStatement->bindParam(6,format_date_for_mysql($this->contractorInfo['whenDate']));
		$pStatement->bindParam(7,$this->contractorInfo['telephone_number']);
		$pStatement->bindParam(8,$this->contractorInfo['fax']);
		$pStatement->bindParam(9,$this->contractorId);*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;
*/
		/*dump_array($this);
		echo "Calling Edit company details method";*/
	}

	private function editManagement() {

		$sql = sprintf("UPDATE %s.contractor_management SET responsibleHealthSafetyName = '%s',
												responsibleHealthSafetyPosition = '%s',
												responsibleEnvironmentProtectionName = '%s',
												responsibleEnvironmentProtectionPosition = '%s',
												responsibleQualityName = '%s',
												responsibleQualityPosition = '%s',
												competentHealthSafetyName = '%s',
												competentHealthSafetyPosition = '%s',
												competentEnvironmentProtectionName = '%s',
												competentEnvironmentProtectionPosition = '%s',
												competentQualityName = '%s',
												competentQualityPosition = '%s',
												employeesFullTime = '%s',
												employeesPartTime = '%s',
												engagingSelfEmployedPersons = '%s',
												engagingSelfEmployedPersonsCount = '%s',
												completeDetailsName_1 = '%s',
												completeDetailsName_2 = '%s',
												completeDetailsName_3 = '%s',
												completeDetailsName_4 = '%s',
												completeDetailsName_5 = '%s',
												completeDetailsName_6 = '%s',
												completeDetailsName_7 = '%s',
												completeDetailsName_8 = '%s',
												completeDetailsTrade_1 = '%s',
												completeDetailsTrade_2 = '%s',
												completeDetailsTrade_3 = '%s',
												completeDetailsTrade_4 = '%s',
												completeDetailsTrade_5 = '%s',
												completeDetailsTrade_6 = '%s',
												completeDetailsTrade_7 = '%s',
												completeDetailsTrade_8 = '%s'
											WHERE cID = %d",_DB_OBJ_FULL,smartisoAddslashes($this->contractorInfo['responsible_health_name']),
				smartisoAddslashes($this->contractorInfo['responsible_health_position']),smartisoAddslashes($this->contractorInfo['responsible_environment_name']),
				smartisoAddslashes($this->contractorInfo['responsible_environment_position']),
				smartisoAddslashes($this->contractorInfo['responsible_quality_name']),smartisoAddslashes($this->contractorInfo['responsible_quality_position']),
				smartisoAddslashes($this->contractorInfo['competent_health_name']),
				smartisoAddslashes($this->contractorInfo['competent_health_position']),smartisoAddslashes($this->contractorInfo['competent_environment_name']),
				smartisoAddslashes($this->contractorInfo['competent_environment_position']),
				smartisoAddslashes($this->contractorInfo['competent_quality_name']),smartisoAddslashes($this->contractorInfo['competent_quality_position']),$this->contractorInfo['employee_full_time'],
				$this->contractorInfo['employee_part_time'],$this->contractorInfo['self_employed_persons'],$this->contractorInfo['self_employed_persons_count'],
				smartisoAddslashes($this->contractorInfo['complete_details_name_1']),smartisoAddslashes($this->contractorInfo['complete_details_name_2']),smartisoAddslashes($this->contractorInfo['complete_details_name_3']),
				smartisoAddslashes($this->contractorInfo['complete_details_name_4']),smartisoAddslashes($this->contractorInfo['complete_details_name_5']),smartisoAddslashes($this->contractorInfo['complete_details_name_6']),
				smartisoAddslashes($this->contractorInfo['complete_details_name_7']),smartisoAddslashes($this->contractorInfo['complete_details_name_8']),smartisoAddslashes($this->contractorInfo['complete_details_trade_1']),
				smartisoAddslashes($this->contractorInfo['complete_details_trade_2']),smartisoAddslashes($this->contractorInfo['complete_details_trade_3']),smartisoAddslashes($this->contractorInfo['complete_details_trade_4']),
				smartisoAddslashes($this->contractorInfo['complete_details_trade_5']),smartisoAddslashes($this->contractorInfo['complete_details_trade_6']),smartisoAddslashes($this->contractorInfo['complete_details_trade_7']),
				smartisoAddslashes($this->contractorInfo['complete_details_trade_8']),$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['responsible_health_name']);
		$pStatement->bindParam(2,$this->contractorInfo['responsible_health_position']);
		$pStatement->bindParam(3,$this->contractorInfo['responsible_environment_name']);
		$pStatement->bindParam(4,$this->contractorInfo['responsible_environment_position']);
		$pStatement->bindParam(5,$this->contractorInfo['responsible_quality_name']);
		$pStatement->bindParam(6,$this->contractorInfo['responsible_quality_position']);
		$pStatement->bindParam(7,$this->contractorInfo['competent_health_name']);
		$pStatement->bindParam(8,$this->contractorInfo['competent_health_position']);
		$pStatement->bindParam(9,$this->contractorInfo['competent_environment_name']);
		$pStatement->bindParam(10,$this->contractorInfo['competent_environment_position']);
		$pStatement->bindParam(11,$this->contractorInfo['competent_quality_name']);
		$pStatement->bindParam(12,$this->contractorInfo['competent_quality_position']);
		$pStatement->bindParam(13,$this->contractorInfo['employee_full_time']);
		$pStatement->bindParam(14,$this->contractorInfo['employee_part_time']);
		$pStatement->bindParam(15,$this->contractorInfo['self_employed_persons']);
		$pStatement->bindParam(16,$this->contractorInfo['self_employed_persons_count']);
		$pStatement->bindParam(17,$this->contractorInfo['complete_details_name_1']);
		$pStatement->bindParam(18,$this->contractorInfo['complete_details_name_2']);
		$pStatement->bindParam(19,$this->contractorInfo['complete_details_name_3']);
		$pStatement->bindParam(20,$this->contractorInfo['complete_details_name_4']);
		$pStatement->bindParam(21,$this->contractorInfo['complete_details_name_5']);
		$pStatement->bindParam(22,$this->contractorInfo['complete_details_name_6']);
		$pStatement->bindParam(23,$this->contractorInfo['complete_details_name_7']);
		$pStatement->bindParam(24,$this->contractorInfo['complete_details_name_8']);
		$pStatement->bindParam(25,$this->contractorInfo['complete_details_trade_1']);
		$pStatement->bindParam(26,$this->contractorInfo['complete_details_trade_2']);
		$pStatement->bindParam(27,$this->contractorInfo['complete_details_trade_3']);
		$pStatement->bindParam(28,$this->contractorInfo['complete_details_trade_4']);
		$pStatement->bindParam(29,$this->contractorInfo['complete_details_trade_5']);
		$pStatement->bindParam(30,$this->contractorInfo['complete_details_trade_6']);
		$pStatement->bindParam(31,$this->contractorInfo['complete_details_trade_7']);
		$pStatement->bindParam(32,$this->contractorInfo['complete_details_trade_8']);
		$pStatement->bindParam(33,$this->contractorId);*/

		$pStatement->execute();

		/*$this->saveTabScore(1);
		$this->updateScore(1);*/

		//dump_array($this);
		//echo "Calling management method";
	}

	private function editCompetency() {

		$sql = sprintf("UPDATE %s.contractor_competency SET assessCompetency_1 = '%s',
													assessCompetency_2 = '%s',
													assessCompetency_3 = '%s',
													communicateIssues_1 = '%s',
													communicateIssues_2 = '%s',
													communicateIssues_3 = '%s',
													assessHealthSafety = '%s',
													assessEnvironmentProtection = '%s',
													undertakeAssessment_1 = '%s',
													undertakeAssessment_2 = '%s',
													undertakeAssessment_3 = '%s',
													undertakeAssessment_4 = '%s',
													undertakeAssessment_5 = '%s',
													undertakeAssessment_6 = '%s',
													responsibleHealthSafetyName = '%s',
													responsibleHealthSafetyPosition = '%s',
													responsibleEnvironmentProtectionName = '%s',
													responsibleEnvironmentProtectionPosition = '%s',
													responsibleQualityName = '%s',
													responsibleQualityPosition = '%s'
												WHERE cID = %d",_DB_OBJ_FULL,
		smartisoAddslashes($this->contractorInfo['assess_competency1']),smartisoAddslashes($this->contractorInfo['assess_competency2']),
		smartisoAddslashes($this->contractorInfo['assess_competency3']),smartisoAddslashes($this->contractorInfo['communicate_issues1']),smartisoAddslashes($this->contractorInfo['communicate_issues2']),
		smartisoAddslashes($this->contractorInfo['communicate_issues3']),$this->contractorInfo['assess_health_safety'],$this->contractorInfo['assess_environment_protection'],
		smartisoAddslashes($this->contractorInfo['undertake_assessment1']),smartisoAddslashes($this->contractorInfo['undertake_assessment2']),smartisoAddslashes($this->contractorInfo['undertake_assessment3']),
		smartisoAddslashes($this->contractorInfo['undertake_assessment4']),smartisoAddslashes($this->contractorInfo['undertake_assessment5']),smartisoAddslashes($this->contractorInfo['undertake_assessment6']),
		smartisoAddslashes($this->contractorInfo['responsible_health_name']),smartisoAddslashes($this->contractorInfo['responsible_health_position']),smartisoAddslashes($this->contractorInfo['responsible_environment_name']),
		smartisoAddslashes($this->contractorInfo['responsible_environment_position']),smartisoAddslashes($this->contractorInfo['responsible_quality_name']),
		smartisoAddslashes($this->contractorInfo['responsible_quality_position']),$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['assess_competency1']);
		$pStatement->bindParam(2,$this->contractorInfo['assess_competency2']);
		$pStatement->bindParam(3,$this->contractorInfo['assess_competency3']);
		$pStatement->bindParam(4,$this->contractorInfo['communicate_issues1']);
		$pStatement->bindParam(5,$this->contractorInfo['communicate_issues2']);
		$pStatement->bindParam(6,$this->contractorInfo['communicate_issues3']);
		$pStatement->bindParam(7,$this->contractorInfo['assess_health_safety']);
		$pStatement->bindParam(8,$this->contractorInfo['assess_environment_protection']);
		$pStatement->bindParam(9,$this->contractorInfo['undertake_assessment1']);
		$pStatement->bindParam(10,$this->contractorInfo['undertake_assessment2']);
		$pStatement->bindParam(11,$this->contractorInfo['undertake_assessment3']);
		$pStatement->bindParam(12,$this->contractorInfo['undertake_assessment4']);
		$pStatement->bindParam(13,$this->contractorInfo['undertake_assessment5']);
		$pStatement->bindParam(14,$this->contractorInfo['undertake_assessment6']);
		$pStatement->bindParam(15,$this->contractorInfo['responsible_health_name']);
		$pStatement->bindParam(16,$this->contractorInfo['responsible_health_position']);
		$pStatement->bindParam(17,$this->contractorInfo['responsible_environment_name']);
		$pStatement->bindParam(18,$this->contractorInfo['responsible_environment_position']);
		$pStatement->bindParam(19,$this->contractorInfo['responsible_quality_name']);
		$pStatement->bindParam(20,$this->contractorInfo['responsible_quality_position']);
		$pStatement->bindParam(21,$this->contractorId);*/

		$pStatement->execute();

		/*dump_array($this);
		echo "Calling competency method";*/
		$this->saveTabScore(2);
		$this->updateScore(2);
	}

	private function editPolicy() {

		$sql = sprintf("UPDATE %s.contractor_policy SET tradeAssociation = '%s',
												tradeAssociationName_1 = '%s',
												tradeAssociationName_2 = '%s',
												tradeAssociationAddress_1 = '%s',
												tradeAssociationAddress_2 = '%s',
												tradeAssociationMemberRef_1 = '%s',
												tradeAssociationMemberRef_2 = '%s',
												iso9001 = '%s',
												iso9001Reason = '%s',
												iso14001 = '%s',
												iso14001Reason = '%s',
												iso18001 = '%s',
												iso18001Reason = '%s',
												continuousImprovement = '%s',
												healthSafetyPolicy = '%s',
												environmentalPolicy = '%s',
												qualityPolicy = '%s',
												workInstructions = '%s'
											WHERE cID = %d",_DB_OBJ_FULL,$this->contractorInfo['trade_association'],smartisoAddslashes($this->contractorInfo['trade_association_name1']),
		smartisoAddslashes($this->contractorInfo['trade_association_name2']),smartisoAddslashes($this->contractorInfo['trade_association_address1']),smartisoAddslashes($this->contractorInfo['trade_association_address2']),
		smartisoAddslashes($this->contractorInfo['trade_association_ref1']),smartisoAddslashes($this->contractorInfo['trade_association_ref2']),$this->contractorInfo['iso9001'],
		smartisoAddslashes($this->contractorInfo['iso9001_reason']),$this->contractorInfo['iso14001'],smartisoAddslashes($this->contractorInfo['iso14001_reason']),
		$this->contractorInfo['iso18001'],smartisoAddslashes($this->contractorInfo['iso18001_reason']),$this->contractorInfo['continuous_improvement'],
		$this->contractorInfo['health_safety_policy'],$this->contractorInfo['environmental_policy'],$this->contractorInfo['quality_policy'],
		$this->contractorInfo['work_instructions'],$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['trade_association']);
		$pStatement->bindParam(2,$this->contractorInfo['trade_association_name1']);
		$pStatement->bindParam(3,$this->contractorInfo['trade_association_name2']);
		$pStatement->bindParam(4,$this->contractorInfo['trade_association_address1']);
		$pStatement->bindParam(5,$this->contractorInfo['trade_association_address2']);
		$pStatement->bindParam(6,$this->contractorInfo['trade_association_ref1']);
		$pStatement->bindParam(7,$this->contractorInfo['trade_association_ref2']);
		$pStatement->bindParam(8,$this->contractorInfo['iso9001']);
		$pStatement->bindParam(9,$this->contractorInfo['iso9001_reason']);
		$pStatement->bindParam(10,$this->contractorInfo['iso14001']);
		$pStatement->bindParam(11,$this->contractorInfo['iso14001_reason']);
		$pStatement->bindParam(12,$this->contractorInfo['iso18001']);
		$pStatement->bindParam(13,$this->contractorInfo['iso18001_reason']);
		$pStatement->bindParam(14,$this->contractorInfo['continuous_improvement']);
		$pStatement->bindParam(15,$this->contractorInfo['health_safety_policy']);
		$pStatement->bindParam(16,$this->contractorInfo['environmental_policy']);
		$pStatement->bindParam(17,$this->contractorInfo['quality_policy']);
		$pStatement->bindParam(18,$this->contractorInfo['work_instructions']);
		$pStatement->bindParam(19,$this->contractorId);*/

		$pStatement->execute();
		//dump_array_and_exit($pStatement->errorInfo());

		$this->saveTabScore(3);
		$this->updateScore(3);
		/*dump_array($this);
		echo "Calling policy method";*/
	}

	private function editRiskAssessment() {

		$sql = sprintf("UPDATE %s.contractor_risk_assessment SET carriedRiskAssessments = '%s',
														carryChemical = '%s',
														carryManualHandling = '%s',
														carryNoiseExposure = '%s',
														carryLeadExposure = '%s',
														carryAsbestos = '%s',
														carryDisplayScreen = '%s',
														detailedMethodStatements = '%s',
														routinePreDuringPost = '%s'
													WHERE cID = %d",_DB_OBJ_FULL,
		$this->contractorInfo['carried_risk_assessments'],$this->contractorInfo['carry_chemical'],
		$this->contractorInfo['carry_manual_handling'],$this->contractorInfo['carry_noise_exposure'],$this->contractorInfo['carry_lead_exposure'],
		$this->contractorInfo['carry_asbestos'],$this->contractorInfo['carry_display_screen'],$this->contractorInfo['detailed_method_statements'],
		$this->contractorInfo['routine_pre_during'],$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['carried_risk_assessments']);
		$pStatement->bindParam(2,$this->contractorInfo['carry_chemical']);
		$pStatement->bindParam(3,$this->contractorInfo['carry_manual_handling']);
		$pStatement->bindParam(4,$this->contractorInfo['carry_noise_exposure']);
		$pStatement->bindParam(5,$this->contractorInfo['carry_lead_exposure']);
		$pStatement->bindParam(6,$this->contractorInfo['carry_asbestos']);
		$pStatement->bindParam(7,$this->contractorInfo['carry_display_screen']);
		$pStatement->bindParam(8,$this->contractorInfo['detailed_method_statements']);
		$pStatement->bindParam(9,$this->contractorInfo['routine_pre_during']);
		$pStatement->bindParam(10,$this->contractorId);*/

		$pStatement->execute();
		//dump_array_and_exit($pStatement->errorInfo());

		$this->saveTabScore(4);
		$this->updateScore(4);
		/*dump_array($this);
		echo "Calling risk assessment method";*/
	}

	private function editConsultation() {

		$sql = sprintf("UPDATE %s.contractor_consultation SET consultHealthSafety = '%s',
													consultEnvironmental = '%s',
													consultQuality = '%s',
													formalArrangements_1 = '%s',
													formalArrangements_2 = '%s',
													formalArrangements_3 = '%s',
													trainingPerson_1_1 = '%s',
													trainingPerson_1_2 = '%s',
													trainingPerson_1_3 = '%s',
													trainingPerson_1_4 = '%s',
													trainingPerson_2_1 = '%s',
													trainingPerson_2_2 = '%s',
													trainingPerson_2_3 = '%s',
													trainingPerson_2_4 = '%s',
													qualificationsPerson_1 = '%s',
													qualificationsPerson_2 = '%s',
													qualificationsPerson_3 = '%s',
													qualificationsPerson_4 = '%s',
													handbooks = '%s',
													handbooksComment_1 = '%s',
													handbooksComment_2 = '%s',
													handbooksComment_3 = '%s'
												WHERE cID = %d",_DB_OBJ_FULL,
		$this->contractorInfo['consult_health_safety'],$this->contractorInfo['consult_environmental'],
		$this->contractorInfo['consult_quality'],smartisoAddslashes($this->contractorInfo['formal_arrangements1']),smartisoAddslashes($this->contractorInfo['formal_arrangements2']),
		smartisoAddslashes($this->contractorInfo['formal_arrangements3']),smartisoAddslashes($this->contractorInfo['training_person1_1']),smartisoAddslashes($this->contractorInfo['training_person1_2']),
		smartisoAddslashes($this->contractorInfo['training_person1_3']),smartisoAddslashes($this->contractorInfo['training_person1_4']),smartisoAddslashes($this->contractorInfo['training_person2_1']),
		smartisoAddslashes($this->contractorInfo['training_person2_2']),smartisoAddslashes($this->contractorInfo['training_person2_3']),smartisoAddslashes($this->contractorInfo['training_person2_4']),
		smartisoAddslashes($this->contractorInfo['qualifications_person1']),smartisoAddslashes($this->contractorInfo['qualifications_person2']),smartisoAddslashes($this->contractorInfo['qualifications_person3']),
		smartisoAddslashes($this->contractorInfo['qualifications_person4']),$this->contractorInfo['handbooks'],smartisoAddslashes($this->contractorInfo['handbooks_comment1']),
		smartisoAddslashes($this->contractorInfo['handbooks_comment2']),smartisoAddslashes($this->contractorInfo['handbooks_comment3']),$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['consult_health_safety']);
		$pStatement->bindParam(2,$this->contractorInfo['consult_environmental']);
		$pStatement->bindParam(3,$this->contractorInfo['consult_quality']);
		$pStatement->bindParam(4,$this->contractorInfo['formal_arrangements1']);
		$pStatement->bindParam(5,$this->contractorInfo['formal_arrangements2']);
		$pStatement->bindParam(6,$this->contractorInfo['formal_arrangements3']);
		$pStatement->bindParam(7,$this->contractorInfo['training_person1_1']);
		$pStatement->bindParam(8,$this->contractorInfo['training_person1_2']);
		$pStatement->bindParam(9,$this->contractorInfo['training_person1_3']);
		$pStatement->bindParam(10,$this->contractorInfo['training_person1_4']);
		$pStatement->bindParam(11,$this->contractorInfo['training_person2_1']);
		$pStatement->bindParam(12,$this->contractorInfo['training_person2_2']);
		$pStatement->bindParam(13,$this->contractorInfo['training_person2_3']);
		$pStatement->bindParam(14,$this->contractorInfo['training_person2_4']);
		$pStatement->bindParam(15,$this->contractorInfo['qualifications_person1']);
		$pStatement->bindParam(16,$this->contractorInfo['qualifications_person2']);
		$pStatement->bindParam(17,$this->contractorInfo['qualifications_person3']);
		$pStatement->bindParam(18,$this->contractorInfo['qualifications_person4']);
		$pStatement->bindParam(19,$this->contractorInfo['handbooks']);
		$pStatement->bindParam(20,$this->contractorInfo['handbooks_comment1']);
		$pStatement->bindParam(21,$this->contractorInfo['handbooks_comment2']);
		$pStatement->bindParam(22,$this->contractorInfo['handbooks_comment3']);
		$pStatement->bindParam(23,$this->contractorId);*/

		$pStatement->execute();
		$this->saveTabScore(5);
		$this->updateScore(5);

		/*dump_array($this);
		echo "Calling consultation method";*/
	}

	private function editTraining() {

		$sql = sprintf("UPDATE %s.contractor_training SET  managersSupervisors_1 = '%s',
													managersSupervisors_2 = '%s',
													managersSupervisors_3 = '%s',
													managersSupervisors_4 = '%s',
													operatives_1 = '%s',
													operatives_2 = '%s',
													operatives_3 = '%s',
													operatives_4 = '%s',
													competentRelating_1 = '%s',
													competentRelating_2 = '%s',
													competentRelating_3 = '%s',
													competentRelating_4 = '%s',
													formalReviews_1 = '%s',
													formalReviews_2 = '%s',
													formalReviews_3 = '%s',
													formalReviews_4 = '%s'
												WHERE cID = %d",_DB_OBJ_FULL,
		smartisoAddslashes($this->contractorInfo['managers_supervisors1']),smartisoAddslashes($this->contractorInfo['managers_supervisors2']),
		smartisoAddslashes($this->contractorInfo['managers_supervisors3']),smartisoAddslashes($this->contractorInfo['managers_supervisors4']),smartisoAddslashes($this->contractorInfo['operatives1']),
		smartisoAddslashes($this->contractorInfo['operatives2']),smartisoAddslashes($this->contractorInfo['operatives3']),smartisoAddslashes($this->contractorInfo['operatives4']),
		smartisoAddslashes($this->contractorInfo['competent_relating1']),smartisoAddslashes($this->contractorInfo['competent_relating2']),smartisoAddslashes($this->contractorInfo['competent_relating3']),
		smartisoAddslashes($this->contractorInfo['competent_relating4']),smartisoAddslashes($this->contractorInfo['formal_reviews1']),smartisoAddslashes($this->contractorInfo['formal_reviews2']),
		smartisoAddslashes($this->contractorInfo['formal_reviews3']),smartisoAddslashes($this->contractorInfo['formal_reviews4']),$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['managers_supervisors1']);
		$pStatement->bindParam(2,$this->contractorInfo['managers_supervisors2']);
		$pStatement->bindParam(3,$this->contractorInfo['managers_supervisors3']);
		$pStatement->bindParam(4,$this->contractorInfo['managers_supervisors4']);
		$pStatement->bindParam(5,$this->contractorInfo['operatives1']);
		$pStatement->bindParam(6,$this->contractorInfo['operatives2']);
		$pStatement->bindParam(7,$this->contractorInfo['operatives3']);
		$pStatement->bindParam(8,$this->contractorInfo['operatives4']);
		$pStatement->bindParam(9,$this->contractorInfo['competent_relating1']);
		$pStatement->bindParam(10,$this->contractorInfo['competent_relating2']);
		$pStatement->bindParam(11,$this->contractorInfo['competent_relating3']);
		$pStatement->bindParam(12,$this->contractorInfo['competent_relating4']);
		$pStatement->bindParam(13,$this->contractorInfo['formal_reviews1']);
		$pStatement->bindParam(14,$this->contractorInfo['formal_reviews2']);
		$pStatement->bindParam(15,$this->contractorInfo['formal_reviews3']);
		$pStatement->bindParam(16,$this->contractorInfo['formal_reviews4']);
		$pStatement->bindParam(17,$this->contractorId);*/

		$pStatement->execute();
		$this->saveTabScore(6);
		$this->updateScore(6);

		/*dump_array($this);
		echo "Calling training method";*/
	}

	private function editMaintenance() {

		$sql = sprintf("UPDATE %s.contractor_maintenance SET electrical = '%s',
													accessEquipments = '%s',
													pneumatic = '%s',
													gasMonitors = '%s',
													hydraulic = '%s',
													specialTestEquipments = '%s',
													electricEquipments = '%s',
													workEquipment = '%s',
													employeesNoAccident = '%s',
													employeesFatality = '%s',
													employeesMajor = '%s',
													employeesLostTime = '%s',
													personsNoAccident = '%s',
													personsFatality = '%s',
													personsMajor = '%s',
													personsLostTime = '%s',
													reportingAccidents = '%s',
													prosecutedConnection = '%s',
													prohibitionNotice = '%s',
													improvementNotice = '%s'
												WHERE cID = %d",_DB_OBJ_FULL,
				$this->contractorInfo['electrical'],$this->contractorInfo['access_equipments'],
				$this->contractorInfo['pneumatic'],$this->contractorInfo['gas_monitors'],$this->contractorInfo['hydraulic'],
				$this->contractorInfo['special_equipments'],$this->contractorInfo['electric_equipments'],$this->contractorInfo['work_equipment'],
				smartisoAddslashes($this->contractorInfo['employees_accident']),smartisoAddslashes($this->contractorInfo['employees_fatality']),smartisoAddslashes($this->contractorInfo['employees_major']),
				smartisoAddslashes($this->contractorInfo['employees_lost_time']),smartisoAddslashes($this->contractorInfo['persons_accident']),smartisoAddslashes($this->contractorInfo['persons_fatality']),
				smartisoAddslashes($this->contractorInfo['persons_major']),smartisoAddslashes($this->contractorInfo['persons_lost_time']),$this->contractorInfo['reporting_accidents'],
				$this->contractorInfo['prosecuted_connection'],$this->contractorInfo['prohibition_otice'],$this->contractorInfo['improvement_notice'],
				$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['electrical']);
		$pStatement->bindParam(2,$this->contractorInfo['access_equipments']);
		$pStatement->bindParam(3,$this->contractorInfo['pneumatic']);
		$pStatement->bindParam(4,$this->contractorInfo['gas_monitors']);
		$pStatement->bindParam(5,$this->contractorInfo['hydraulic']);
		$pStatement->bindParam(6,$this->contractorInfo['special_equipments']);
		$pStatement->bindParam(7,$this->contractorInfo['electric_equipments']);
		$pStatement->bindParam(8,$this->contractorInfo['work_equipment']);
		$pStatement->bindParam(9,$this->contractorInfo['employees_accident']);
		$pStatement->bindParam(10,$this->contractorInfo['employees_fatality']);
		$pStatement->bindParam(11,$this->contractorInfo['employees_major']);
		$pStatement->bindParam(12,$this->contractorInfo['employees_lost_time']);
		$pStatement->bindParam(13,$this->contractorInfo['persons_accident']);
		$pStatement->bindParam(14,$this->contractorInfo['persons_fatality']);
		$pStatement->bindParam(15,$this->contractorInfo['persons_major']);
		$pStatement->bindParam(16,$this->contractorInfo['persons_lost_time']);
		$pStatement->bindParam(17,$this->contractorInfo['reporting_accidents']);
		$pStatement->bindParam(18,$this->contractorInfo['prosecuted_connection']);
		$pStatement->bindParam(19,$this->contractorInfo['prohibition_otice']);
		$pStatement->bindParam(20,$this->contractorInfo['improvement_notice']);
		$pStatement->bindParam(21,$this->contractorId);*/

		$pStatement->execute();
		$this->saveTabScore(7);
		$this->updateScore(7);
		/*dump_array($this);
		echo "Calling maintenance method";*/
	}

	private function editInsurance() {

		$sql = sprintf("UPDATE %s.contractor_insurance SET employersLiabilityInsurerName = '%s',
													employersLiabilityCertificateNo = '%s',
													employersLiabilitySumAssured = '%s',
													employersLiabilityExpiryDate = '%s',
													publicLiabilityInsurerName = '%s',
													publicLiabilityCertificateNo = '%s',
													publicLiabilitySumAssured = '%s',
													publicLiabilityExpiryDate = '%s',
													activitiesExposeEmployees = '%s',
													provideFirstAiders = '%s',
													fireRiskAssessments = '%s'
												WHERE cID = %d",_DB_OBJ_FULL,
		smartisoAddslashes($this->contractorInfo['employers_insurer_name']),smartisoAddslashes($this->contractorInfo['employers_certificate_no']),
		smartisoAddslashes($this->contractorInfo['employers_sum_assured']),format_date_for_mysql($this->contractorInfo['employers_expiry_date']),smartisoAddslashes($this->contractorInfo['public_insurer_name']),
		smartisoAddslashes($this->contractorInfo['public_certificate_no']),smartisoAddslashes($this->contractorInfo['public_sum_assured']),format_date_for_mysql($this->contractorInfo['public_expiry_date']),
		$this->contractorInfo['activities_expose_employees'],$this->contractorInfo['provide_first_aiders'],$this->contractorInfo['fire_risk_assessments'],
		$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['employers_insurer_name']);
		$pStatement->bindParam(2,$this->contractorInfo['employers_certificate_no']);
		$pStatement->bindParam(3,$this->contractorInfo['employers_sum_assured']);
		$pStatement->bindParam(4,format_date_for_mysql($this->contractorInfo['employers_expiry_date']));
		$pStatement->bindParam(5,$this->contractorInfo['public_insurer_name']);
		$pStatement->bindParam(6,$this->contractorInfo['public_certificate_no']);
		$pStatement->bindParam(7,$this->contractorInfo['public_sum_assured']);
		$pStatement->bindParam(8,format_date_for_mysql($this->contractorInfo['public_expiry_date']));
		$pStatement->bindParam(9,$this->contractorInfo['activities_expose_employees']);
		$pStatement->bindParam(10,$this->contractorInfo['provide_first_aiders']);
		$pStatement->bindParam(11,$this->contractorInfo['fire_risk_assessments']);
		$pStatement->bindParam(12,$this->contractorId);*/

		$pStatement->execute();

		$this->saveTabScore(8);
		$this->updateScore(8);
		/*dump_array($this);
		echo "Calling insurance method";*/
	}

	private function editDocuments() {

		$date = $this->contractorInfo['docWhen'] ==  '' ? '1900-01-01' : format_date_for_mysql($this->contractorInfo['docWhen']);

		$sql = sprintf("UPDATE %s.contractor_documents SET subContractorsQuestionnaire = '%s',
													continuousImprovement = '%s',
													healthSafetyPolicy = '%s',
													environmentalPolicy = '%s',
													qualityPolicy = '%s',
													healthSafetyProcedures = '%s',
													environmentalProcedures = '%s',
													qualityProcedures = '%s',
													examplesRelevantRisk = '%s',
													examplesRelevantMethod = '%s',
													exampleDocumentation = '%s',
													employeeHealthSafety = '%s',
													trainingCertificates = '%s',
													workEquipment = '%s',
													portableAppliance = '%s',
													employeeGuidanceDocumentation = '%s',
													publicLiabilityInsurance = '%s',
													employersLiabilityInsurance = '%s',
													evidenceHealthSurveillance = '%s',
													fireRiskAssessment = '%s',
													jobTitle = '%s',
													docWhen = '%s',
													who = '%s'
												WHERE cID = %d",_DB_OBJ_FULL,
			$this->contractorInfo['contractors_questionnaire'],$this->contractorInfo['continuous_improvement'],
		$this->contractorInfo['health_safety_policy'],$this->contractorInfo['environmental_policy'],$this->contractorInfo['quality_policy'],
		$this->contractorInfo['health_safety_procedures'],$this->contractorInfo['environmental_procedures'],$this->contractorInfo['quality_procedures'],
		$this->contractorInfo['examples_relevant_risk'],$this->contractorInfo['examples_relevant_method'],$this->contractorInfo['example_documentation'],
		$this->contractorInfo['employee_health_safety'],$this->contractorInfo['training_certificates'],$this->contractorInfo['work_equipment'],
		$this->contractorInfo['portable_appliance'],$this->contractorInfo['employee_guidance_documentation'],$this->contractorInfo['public_insurance'],
		$this->contractorInfo['employers_insurance'],$this->contractorInfo['evidence_surveillance'],$this->contractorInfo['fire_assessment'],
		smartisoAddslashes($this->contractorInfo['job_title']),$date,$this->contractorInfo['who'],$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorInfo['contractors_questionnaire']);
		$pStatement->bindParam(2,$this->contractorInfo['continuous_improvement']);
		$pStatement->bindParam(3,$this->contractorInfo['health_safety_policy']);
		$pStatement->bindParam(4,$this->contractorInfo['environmental_policy']);
		$pStatement->bindParam(5,$this->contractorInfo['quality_policy']);
		$pStatement->bindParam(6,$this->contractorInfo['health_safety_procedures']);
		$pStatement->bindParam(7,$this->contractorInfo['environmental_procedures']);
		$pStatement->bindParam(8,$this->contractorInfo['quality_procedures']);
		$pStatement->bindParam(9,$this->contractorInfo['examples_relevant_risk']);
		$pStatement->bindParam(10,$this->contractorInfo['examples_relevant_method']);
		$pStatement->bindParam(11,$this->contractorInfo['example_documentation']);
		$pStatement->bindParam(12,$this->contractorInfo['employee_health_safety']);
		$pStatement->bindParam(13,$this->contractorInfo['training_certificates']);
		$pStatement->bindParam(14,$this->contractorInfo['work_equipment']);
		$pStatement->bindParam(15,$this->contractorInfo['portable_appliance']);
		$pStatement->bindParam(16,$this->contractorInfo['employee_guidance_documentation']);
		$pStatement->bindParam(17,$this->contractorInfo['public_insurance']);
		$pStatement->bindParam(18,$this->contractorInfo['employers_insurance']);
		$pStatement->bindParam(19,$this->contractorInfo['evidence_surveillance']);
		$pStatement->bindParam(20,$this->contractorInfo['fire_assessment']);
		$pStatement->bindParam(21,$this->contractorInfo['job_title']);
		$pStatement->bindParam(22,format_date_for_mysql($this->contractorInfo['docWhen']));
		$pStatement->bindParam(23,$this->contractorInfo['who']);
		$pStatement->bindParam(24,$this->contractorId);*/

		$pStatement->execute();
		//dump_array($pStatement->errorInfo());

		$this->saveTabScore(9);
		$this->updateScore(9);
		/*dump_array($this);
		echo "Calling documents method";*/

	}

	public function add_management_metadata() {

		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'responsibleHealthSafetyName';
		$fields[] =	'responsibleHealthSafetyPosition';
		$fields[] =	'responsibleEnvironmentProtectionName';
		$fields[] =	'responsibleEnvironmentProtectionPosition';
		$fields[] =	'responsibleQualityName';
		$fields[] =	'responsibleQualityPosition';
		$fields[] =	'competentHealthSafetyName';
		$fields[] =	'competentHealthSafetyPosition';
		$fields[] =	'competentEnvironmentProtectionName';
		$fields[] =	'competentEnvironmentProtectionPosition';
		$fields[] =	'competentQualityName';
		$fields[] =	'competentQualityPosition';
		$fields[] =	'employeesFullTime';
		$fields[] =	'employeesPartTime';
		$fields[] =	'engagingSelfEmployedPersons';
		$fields[] =	'engagingSelfEmployedPersonsCount';
		$fields[] =	'completeDetailsName_1';
		$fields[] =	'completeDetailsName_2';
		$fields[] =	'completeDetailsName_3';
		$fields[] =	'completeDetailsName_4';
		$fields[] =	'completeDetailsName_5';
		$fields[] =	'completeDetailsName_6';
		$fields[] =	'completeDetailsName_7';
		$fields[] =	'completeDetailsName_8';
		$fields[] =	'completeDetailsTrade_1';
		$fields[] =	'completeDetailsTrade_2';
		$fields[] =	'completeDetailsTrade_3';
		$fields[] =	'completeDetailsTrade_4';
		$fields[] =	'completeDetailsTrade_5';
		$fields[] =	'completeDetailsTrade_6';
		$fields[] =	'completeDetailsTrade_7';
		$fields[] =	'completeDetailsTrade_8';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_management_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();

	}

	public function add_competency_metadata() {

		$fields	  = array();

		$fields[] =	'cID';
		$fields[] = 'assessCompetency_1';
		$fields[] = 'assessCompetency_2';
		$fields[] = 'assessCompetency_3';
		$fields[] = 'communicateIssues_1';
		$fields[] = 'communicateIssues_2';
		$fields[] = 'communicateIssues_3';
		$fields[] = 'assessHealthSafety';
		$fields[] = 'assessEnvironmentProtection';
		$fields[] = 'undertakeAssessment_1';
		$fields[] = 'undertakeAssessment_2';
		$fields[] = 'undertakeAssessment_3';
		$fields[] = 'undertakeAssessment_4';
		$fields[] = 'undertakeAssessment_5';
		$fields[] = 'undertakeAssessment_6';
		$fields[] = 'responsibleHealthSafetyName';
		$fields[] = 'responsibleHealthSafetyPosition';
		$fields[] = 'responsibleEnvironmentProtectionName';
		$fields[] = 'responsibleEnvironmentProtectionPosition';
		$fields[] = 'responsibleQualityName';
		$fields[] = 'responsibleQualityPosition';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_competency_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);

		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();

	}

	private function add_policy_metadata() {

		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'tradeAssociation';
		$fields[] =	'tradeAssociationName_1';
		$fields[] =	'tradeAssociationName_2';
		$fields[] =	'tradeAssociationAddress_1';
		$fields[] =	'tradeAssociationAddress_2';
		$fields[] =	'tradeAssociationMemberRef_1';
		$fields[] =	'tradeAssociationMemberRef_2';
		$fields[] =	'iso9001';
		$fields[] =	'iso9001Reason';
		$fields[] =	'iso14001';
		$fields[] =	'iso14001Reason';
		$fields[] =	'iso18001';
		$fields[] =	'iso18001Reason';
		$fields[] =	'continuousImprovement';
		$fields[] =	'healthSafetyPolicy';
		$fields[] =	'environmentalPolicy';
		$fields[] =	'qualityPolicy';
		$fields[] =	'workInstructions';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_policy_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}

	private function add_risk_assessment_metadata() {

		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'carriedRiskAssessments';
		$fields[] =	'carryChemical';
		$fields[] =	'carryManualHandling';
		$fields[] =	'carryNoiseExposure';
		$fields[] =	'carryLeadExposure';
		$fields[] =	'carryAsbestos';
		$fields[] =	'carryDisplayScreen';
		$fields[] =	'detailedMethodStatements';
		$fields[] =	'routinePreDuringPost';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_risk_assessment_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}

	private function add_consultation_metadata() {
		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'consultHealthSafety';
		$fields[] =	'consultEnvironmental';
		$fields[] =	'consultQuality';
		$fields[] =	'formalArrangements_1';
		$fields[] =	'formalArrangements_2';
		$fields[] =	'formalArrangements_3';
		$fields[] =	'trainingPerson_1_1';
		$fields[] =	'trainingPerson_1_2';
		$fields[] =	'trainingPerson_1_3';
		$fields[] =	'trainingPerson_1_4';
		$fields[] =	'trainingPerson_2_1';
		$fields[] =	'trainingPerson_2_2';
		$fields[] =	'trainingPerson_2_3';
		$fields[] =	'trainingPerson_2_4';
		$fields[] =	'qualificationsPerson_1';
		$fields[] =	'qualificationsPerson_2';
		$fields[] =	'qualificationsPerson_3';
		$fields[] =	'qualificationsPerson_4';
		$fields[] =	'handbooks';
		$fields[] =	'handbooksComment_1';
		$fields[] =	'handbooksComment_2';
		$fields[] =	'handbooksComment_3';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_consultation_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}

	private function add_training_metadata() {
		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'managersSupervisors_1';
		$fields[] =	'managersSupervisors_2';
		$fields[] =	'managersSupervisors_3';
		$fields[] =	'managersSupervisors_4';
		$fields[] =	'operatives_1';
		$fields[] =	'operatives_2';
		$fields[] =	'operatives_3';
		$fields[] =	'operatives_4';
		$fields[] =	'competentRelating_1';
		$fields[] =	'competentRelating_2';
		$fields[] =	'competentRelating_3';
		$fields[] =	'competentRelating_4';
		$fields[] =	'formalReviews_1';
		$fields[] =	'formalReviews_2';
		$fields[] =	'formalReviews_3';
		$fields[] =	'formalReviews_4';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_training_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}

	private function add_maintenance_metadata() {
		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'electrical';
		$fields[] =	'accessEquipments';
		$fields[] =	'pneumatic';
		$fields[] =	'gasMonitors';
		$fields[] =	'hydraulic';
		$fields[] =	'specialTestEquipments';
		$fields[] =	'electricEquipments';
		$fields[] =	'workEquipment';
		$fields[] =	'employeesNoAccident';
		$fields[] =	'employeesFatality';
		$fields[] =	'employeesMajor';
		$fields[] =	'employeesLostTime';
		$fields[] =	'personsNoAccident';
		$fields[] =	'personsFatality';
		$fields[] =	'personsMajor';
		$fields[] =	'personsLostTime';
		$fields[] =	'reportingAccidents';
		$fields[] =	'prosecutedConnection';
		$fields[] =	'prohibitionNotice';
		$fields[] =	'improvementNotice';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_maintenance_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}

	private function add_insurance_metadata() {
		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'employersLiabilityInsurerName';
		$fields[] =	'employersLiabilityCertificateNo';
		$fields[] =	'employersLiabilitySumAssured';
		$fields[] =	'employersLiabilityExpiryDate';
		$fields[] =	'publicLiabilityInsurerName';
		$fields[] =	'publicLiabilityCertificateNo';
		$fields[] =	'publicLiabilitySumAssured';
		$fields[] =	'publicLiabilityExpiryDate';
		$fields[] =	'activitiesExposeEmployees';
		$fields[] =	'provideFirstAiders';
		$fields[] =	'fireRiskAssessments';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_insurance_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}

	private function add_documents_metadata() {

		$fields	  = array();

		$fields[] =	'cID';
		$fields[] =	'subContractorsQuestionnaire';
		$fields[] =	'continuousImprovement';
		$fields[] =	'healthSafetyPolicy';
		$fields[] =	'environmentalPolicy';
		$fields[] =	'qualityPolicy';
		$fields[] =	'healthSafetyProcedures';
		$fields[] =	'environmentalProcedures';
		$fields[] =	'qualityProcedures';
		$fields[] =	'examplesRelevantRisk';
		$fields[] =	'examplesRelevantMethod';
		$fields[] =	'exampleDocumentation';
		$fields[] =	'employeeHealthSafety';
		$fields[] =	'trainingCertificates';
		$fields[] =	'workEquipment';
		$fields[] =	'portableAppliance';
		$fields[] =	'employeeGuidanceDocumentation';
		$fields[] =	'publicLiabilityInsurance';
		$fields[] =	'employersLiabilityInsurance';
		$fields[] =	'evidenceHealthSurveillance';
		$fields[] =	'fireRiskAssessment';

		if ( count($fields) ) {

			$k = 0;

			$data_str[] = _DB_OBJ_FULL;
			$data_str[] = $this->contractorInfo['contractor_id'];

			foreach ( $fields as $field_ele ) {

				if ($k) { $fields_str .= ","; $qual_str .= ","; }

				$fields_str .= $field_ele;
				$qual_str .= '%d';

				$data_str[] = 0;
				$k++;

			}
		}

		$ins = "INSERT INTO %s.contractor_documents_metadata ($fields_str) VALUES ($qual_str)";

		$s_ins = vsprintf($ins,$data_str);
		$pStatement = $this->dbHand->prepare($s_ins);
		$pStatement->execute();
	}



	/**
	 * This method is used to delete the contractor
	 *
	 * contractor ID ,1 ,""
	 *
	 */
	public function deleteContractor() {

	}

	/**
	 * This method is used to archive the contractor
	 */
	public function archiveContractor() {
		$sql = sprintf("UPDATE %s.contractor SET archive='%s' WHERE ID = %d",_DB_OBJ_FULL,$this->contractorInfo['archive'],$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->contractorInfo['archive']);
		$pStatement->bindParam(2,$this->contractorId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to remove the contractor
	 *
	 *
	 */
	public function purgeContractor() {

		$sql =  sprintf("DELETE FROM %s.contractor_management WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_competency WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_policy WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_risk_assessment WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_consultation WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_training WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_maintenance WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_insurance WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_documents WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_documents WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_na_reason WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_competency_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_policy_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_risk_assessment_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_consultation_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_training_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_maintenance_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_insurance_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

		$sql =  sprintf("DELETE FROM %s.contractor_documents_metadata WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();


		// delete
		$sql_sec =  sprintf("SELECT FROM %s.contractor_files WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement_sec = $this->dbHand->prepare($sql_sec);
		$pStatement_sec->execute();
		$records = $pStatement_sec->fetchAll(PDO::FETCH_ASSOC);

		if ( count($records) ) {
			$objFile = new Upload();

			foreach ( $records as $record_ele ) {

				$objFile->setFileInfo('contractor',array('id'=>$record_ele['filesID']));
				$single_files_data = $objFile->getFileDetails();

				$objFile->setFileInfo('contractor',array('id'=>$single_files_data['fileID'],'destination'=>'contractor'));
				$objFile->delete_file();
			}

			$sql =  sprintf("SELECT FROM %s.contractor_files WHERE cID = %d",_DB_OBJ_FULL,$this->contractorId);
			$pStatement = $this->dbHand->prepare($sql);
			$pStatement->execute();
		}


		$sql =  sprintf("DELETE FROM %s.contractor WHERE ID = %d",_DB_OBJ_FULL,$this->contractorId);
		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);
		$pStatement->execute();

	}

	/**
	 * This method is used to restore the contractor
	 *
	 */
	public function restoreContractor() {
		$sql = sprintf("UPDATE %s.contractor SET archive='0' WHERE ID = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);

		$pStatement->execute();
	}

	/*
	 * This method is used to list Contractor records
	 */
	public function viewAllContractors() {

		$sql = sprintf("SELECT * FROM %s.contractor WHERE archive = '%s'  ORDER BY ID DESC ",_DB_OBJ_FULL,$this->contractorInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorInfo['archive']);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		return $records;
	}

	/**
	 *This method is used to get last insert record ID
	 *
	 */
	public function getCurrentRecordId() {
		return $this->contractorId;
	}

	/**
	 * This method is used to Add files the contractor
	 *
	 * contractor ID ,tab, identifier,file_ids
	 *
	 */
	public function addContractorFiles() {

		$sql = sprintf("INSERT INTO %s.contractor_files (cID, tab,identifier,filesID) VALUES (%d,'%s','%s','%s')",_DB_OBJ_FULL,
					   $this->contractorId,$this->contractorInfo['tab'],$this->contractorInfo['identifier'],$this->contractorInfo['file_ids']);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->contractorId);
		$pStatement->bindParam(2,$this->contractorInfo['tab']);
		$pStatement->bindParam(3,$this->contractorInfo['identifier']);
		$pStatement->bindParam(4,$this->contractorInfo['file_ids']);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to delete files the contractor
	 *
	 * contractor file ID
	 *
	 */
	public function deleteContractorFiles() {

		$sql = sprintf("DELETE FROM %s.contractor_files WHERE id = %d",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);

		$pStatement->execute();
	}

	/**
	 * This method is used to get files the contractor
	 *
	 * contractor file ID
	 *
	 */
	public function getContractorFiles() {

		$sql = sprintf("SELECT * FROM %s.contractor_files WHERE cID = %d AND tab = '%s' AND identifier LIKE '%s' ",_DB_OBJ_FULL,$this->contractorId,
					   $this->contractorCurrentTab,$this->contractorInfo['identifier']);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->contractorId);
		$pStatement->bindParam(2,$this->contractorCurrentTab);
		$pStatement->bindParam(3,$this->contractorInfo['identifier']);*/

		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);


		return $resultSet;

	}

	/**
	 * This method is used to get files the contractor
	 *
	 * contractor file ID
	 *
	 */
	public function getContractorFileDetails() {

		$sql = sprintf("SELECT * FROM %s.contractor_files WHERE id = %d ",_DB_OBJ_FULL,$this->contractorId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorId);

		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);


		return $resultSet[0];
	}

	/**
	 * This method is used to add reason the contractor
	 *
	 * contractor ID,tab,identifier,reason
	 *
	 */
	public function addContractorReason() {

		$sql = sprintf("INSERT INTO %s.contractor_na_reason (cID, section, subSection, reason ) VALUES (%d,'%s','%s','%s')",_DB_OBJ_FULL,
					   $this->contractorId,$this->contractorCurrentTab,$this->contractorInfo['identifier'],$this->contractorInfo['reason']);
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->bindParam(1,$this->contractorId);
		$pStatement->bindParam(2,$this->contractorCurrentTab);
		$pStatement->bindParam(3,$this->contractorInfo['identifier']);
		$pStatement->bindParam(4,$this->contractorInfo['reason']);

		$pStatement->execute();
	}

	/**
	 * This method is used to add reason the contractor
	 *
	 * contractor ID,tab
	 *
	 */
	public function getContractorReason() {

		$sql = sprintf("SELECT * FROM %s.contractor_na_reason WHERE cID = %d AND section LIKE '%s' ",_DB_OBJ_FULL,$this->contractorId,$this->contractorCurrentTab);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorId);
		$pStatement->bindParam(2,$this->contractorCurrentTab);*/

		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to add reason the contractor
	 *
	 * contractor ID,tab
	 *
	 */
	public function deleteContractorReason() {

		$sql = sprintf("DELETE FROM %s.contractor_na_reason WHERE cID = %d AND section LIKE '%s'",_DB_OBJ_FULL,$this->contractorId,$this->contractorCurrentTab);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->contractorId);
		$pStatement->bindParam(2,$this->contractorCurrentTab);*/

		$pStatement->execute();
	}

	public function getListingforExport() {

		$locationObj		= SetupGeneric::useModule('Locationgram');
		$participantObj		= SetupGeneric::useModule('Participant');

		$heading = array(array('Reference #', 'Company', 'Who', 'Location', 'When'));

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
		$archive_data = array('archive'=>$archive_session);
		$this->setContractorInfo(0,1,$archive_data);
		$view_contractors = $this->viewAllContractors();

		foreach ( $view_contractors as $element ) {

			$contractor_id = $element['ID'];

			$locationObj->setItemInfo(array('id'=>$element['location']));
			$location_data = "";
			$location = $locationObj->getFUllLocation();
			$location = str_replace(',', '-' , $location);

			$participantObj->setItemInfo(array('id'=>$element['whoID']));
			$partcipantData = $participantObj->displayItemById();
			$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

			$contractor_data[$contractor_id] = array($element['reference'], $element['companyName'], $participant_name, $location, $element['date']);

		}

		$result = array_merge($heading, $contractor_data);

		return $result;
	}

	private function saveTabScore($p_tab) {

		switch ($p_tab) {
			case 1: $this->saveManagementTabScore(); break;
			case 2: $this->saveCompetencyTabScore(); break;
			case 3: $this->savePolicyTabScore(); break;
			case 4: $this->saveRiskAssessmentTabScore(); break;
			case 5: $this->saveConsultationTabScore(); break;
			case 6: $this->saveTrainingTabScore(); break;
			case 7: $this->saveMaintenanceTabScore(); break;
			case 8: $this->saveInsuranceTabScore(); break;
			case 9: $this->saveDocumentsTabScore(); break;
		}
	}

	public function saveManagementTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_management_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $this->contractorInfo['responsible_health_name'] == '' ) { $record['responsibleHealthSafetyName'] = 0; }
		if ( $this->contractorInfo['responsible_health_position'] == '' ) { $record['responsibleHealthSafetyPosition'] = 0; }
		if ( $this->contractorInfo['responsible_environment_name'] == '' ) { $record['responsibleEnvironmentProtectionName'] = 0; }
		if ( $this->contractorInfo['responsible_environment_position'] == '' ) { $record['responsibleEnvironmentProtectionPosition'] = 0; }
		if ( $this->contractorInfo['responsible_quality_name'] == '' ) { $record['responsibleQualityName'] = 0; }
		if ( $this->contractorInfo['responsible_quality_position'] == '' ) { $record['responsibleQualityPosition'] = 0; }
		if ( $this->contractorInfo['competent_health_name'] == '' ) { $record['competentHealthSafetyName'] = 0; }
		if ( $this->contractorInfo['competent_health_position'] == '' ) { $record['competentHealthSafetyPosition'] = 0; }
		if ( $this->contractorInfo['competent_environment_name'] == '' ) { $record['competentEnvironmentProtectionName'] = 0; }
		if ( $this->contractorInfo['competent_environment_position'] == '' ) { $record['competentEnvironmentProtectionPosition'] = 0; }
		if ( $this->contractorInfo['competent_quality_name'] == '' ) { $record['competentQualityName'] = 0; }
		if ( $this->contractorInfo['competent_quality_position'] == '' ) { $record['competentQualityPosition'] = 0; }
		if ( $this->contractorInfo['employee_full_time'] == '' ) { $record['employeesFullTime'] = 0; }
		if ( $this->contractorInfo['employee_part_time'] == '' ) { $record['employeesPartTime'] = 0; }
		if ( $this->contractorInfo['self_employed_persons'] == '' ) { $record['engagingSelfEmployedPersons'] = 0; }
		if ( $this->contractorInfo['self_employed_persons_count'] == '' ) { $record['engagingSelfEmployedPersonsCount'] = 0; }
		if ( $this->contractorInfo['complete_details_name_1'] == '' ) { $record['completeDetailsName_1'] = 0; }
		if ( $this->contractorInfo['complete_details_name_2'] == '' ) { $record['completeDetailsName_2'] = 0; }
		if ( $this->contractorInfo['complete_details_name_3'] == '' ) { $record['completeDetailsName_3'] = 0; }
		if ( $this->contractorInfo['complete_details_name_4'] == '' ) { $record['completeDetailsName_4'] = 0; }
		if ( $this->contractorInfo['complete_details_name_5'] == '' ) { $record['completeDetailsName_5'] = 0; }
		if ( $this->contractorInfo['complete_details_name_6'] == '' ) { $record['completeDetailsName_6'] = 0; }
		if ( $this->contractorInfo['complete_details_name_7'] == '' ) { $record['completeDetailsName_7'] = 0; }
		if ( $this->contractorInfo['complete_details_name_8'] == '' ) { $record['completeDetailsName_8'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_1'] == '' ) { $record['completeDetailsTrade_1'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_2'] == '' ) { $record['completeDetailsTrade_2'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_3'] == '' ) { $record['completeDetailsTrade_3'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_4'] == '' ) { $record['completeDetailsTrade_4'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_5'] == '' ) { $record['completeDetailsTrade_5'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_6'] == '' ) { $record['completeDetailsTrade_6'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_7'] == '' ) { $record['completeDetailsTrade_7'] = 0; }
		if ( $this->contractorInfo['complete_details_trade_8'] == '' ) { $record['completeDetailsTrade_8'] = 0; }

		$upd = sprintf("UPDATE %s.contractor_management_metadata
					   SET
				     	responsibleHealthSafetyName = %d,
						responsibleHealthSafetyPosition = %d,
						responsibleEnvironmentProtectionName = %d,
						responsibleEnvironmentProtectionPosition = %d,
						responsibleQualityName = %d,
						responsibleQualityPosition = %d,
						competentHealthSafetyName = %d,
						competentHealthSafetyPosition = %d,
						competentEnvironmentProtectionName = %d,
						competentEnvironmentProtectionPosition = %d,
						competentQualityName = %d,
						competentQualityPosition = %d,
						employeesFullTime = %d,
						employeesPartTime = %d,
						engagingSelfEmployedPersons = %d,
						engagingSelfEmployedPersonsCount = %d,
						completeDetailsName_1 = %d,
						completeDetailsName_2 = %d,
						completeDetailsName_3 = %d,
						completeDetailsName_4 = %d,
						completeDetailsName_5 = %d,
						completeDetailsName_6 = %d,
						completeDetailsName_7 = %d,
						completeDetailsName_8 = %d,
						completeDetailsTrade_1 = %d,
						completeDetailsTrade_2 = %d,
						completeDetailsTrade_3 = %d,
						completeDetailsTrade_4 = %d,
						completeDetailsTrade_5 = %d,
						completeDetailsTrade_6 = %d,
						completeDetailsTrade_7 = %d,
						completeDetailsTrade_8 = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
					    $record['responsibleHealthSafetyName'],
						$record['responsibleHealthSafetyPosition'],
						$record['responsibleEnvironmentProtectionName'],
						$record['responsibleEnvironmentProtectionPosition'],
						$record['responsibleQualityName'],
						$record['responsibleQualityPosition'],
						$record['competentHealthSafetyName'],
						$record['competentHealthSafetyPosition'],
						$record['competentEnvironmentProtectionName'],
						$record['competentEnvironmentProtectionPosition'],
						$record['competentQualityName'],
						$record['competentQualityPosition'],
						$record['employeesFullTime'],
						$record['employeesPartTime'],
						$record['engagingSelfEmployedPersons'],
						$record['engagingSelfEmployedPersonsCount'],
						$record['completeDetailsName_1'],
						$record['completeDetailsName_2'],
						$record['completeDetailsName_3'],
						$record['completeDetailsName_4'],
						$record['completeDetailsName_5'],
						$record['completeDetailsName_6'],
						$record['completeDetailsName_7'],
						$record['completeDetailsName_8'],
						$record['completeDetailsTrade_1'],
						$record['completeDetailsTrade_2'],
						$record['completeDetailsTrade_3'],
						$record['completeDetailsTrade_4'],
						$record['completeDetailsTrade_5'],
						$record['completeDetailsTrade_6'],
						$record['completeDetailsTrade_7'],
						$record['completeDetailsTrade_8'],
						$this->contractorInfo['contractor_id']);

			$utmt = $this->dbHand->prepare($upd);
			$utmt->execute();

	}

	public function saveCompetencyTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_competency_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $this->contractorInfo['assess_competency1'] == '' ) { $record['assessCompetency_1'] = 0; }
		if ( $this->contractorInfo['assess_competency2'] == '' ) { $record['assessCompetency_2'] = 0; }
		if ( $this->contractorInfo['assess_competency3'] == '' ) { $record['assessCompetency_3'] = 0; }
		if ( $this->contractorInfo['communicate_issues1'] == '' ) { $record['communicateIssues_1'] = 0; }
		if ( $this->contractorInfo['communicate_issues2'] == '' ) { $record['communicateIssues_2'] = 0; }
		if ( $this->contractorInfo['communicate_issues3'] == '' ) { $record['communicateIssues_3'] = 0; }
		if ( $this->contractorInfo['assess_health_safety'] == '' ) { $record['assessHealthSafety'] = 0; }
		if ( $this->contractorInfo['assess_environment_protection'] == '' ) { $record['assessEnvironmentProtection'] = 0; }
		if ( $this->contractorInfo['undertake_assessment1'] == '' ) { $record['undertakeAssessment_1'] = 0; }
		if ( $this->contractorInfo['undertake_assessment2'] == '' ) { $record['undertakeAssessment_2'] = 0; }
		if ( $this->contractorInfo['undertake_assessment3'] == '' ) { $record['undertakeAssessment_3'] = 0; }
		if ( $this->contractorInfo['undertake_assessment4'] == '' ) { $record['undertakeAssessment_4'] = 0; }
		if ( $this->contractorInfo['undertake_assessment5'] == '' ) { $record['undertakeAssessment_5'] = 0; }
		if ( $this->contractorInfo['undertake_assessment6'] == '' ) { $record['undertakeAssessment_6'] = 0; }
		if ( $this->contractorInfo['responsible_health_name'] == '' ) { $record['responsibleHealthSafetyName'] = 0; }
		if ( $this->contractorInfo['responsible_environment_name'] == '' ) { $record['responsibleHealthSafetyPosition'] = 0; }
		if ( $this->contractorInfo['responsible_environment_position'] == '' ) { $record['responsibleEnvironmentProtectionName'] = 0; }
		if ( $this->contractorInfo['responsible_quality_name'] == '' ) { $record['responsibleEnvironmentProtectionPosition'] = 0; }
		if ( $this->contractorInfo['responsible_quality_position'] == '' ) { $record['responsibleQualityName'] = 0; }
		if ( $this->contractorInfo['responsible_health_position'] == '' ) { $record['responsibleQualityPosition'] = 0; }

		$upd = sprintf("UPDATE %s.contractor_competency_metadata
					   SET
				     	assessCompetency_1 = %d,
						assessCompetency_2 = %d,
						assessCompetency_3 = %d,
						communicateIssues_1 = %d,
						communicateIssues_2 = %d,
						communicateIssues_3 = %d,
						assessHealthSafety = %d,
						assessEnvironmentProtection = %d,
						undertakeAssessment_1 = %d,
						undertakeAssessment_2 = %d,
						undertakeAssessment_3 = %d,
						undertakeAssessment_4 = %d,
						undertakeAssessment_5 = %d,
						undertakeAssessment_6 = %d,
						responsibleHealthSafetyName = %d,
						responsibleHealthSafetyPosition = %d,
						responsibleEnvironmentProtectionName = %d,
						responsibleEnvironmentProtectionPosition = %d,
						responsibleQualityName = %d,
						responsibleQualityPosition = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
					    $record['assessCompetency_1'],
						$record['assessCompetency_2'],
						$record['assessCompetency_3'],
						$record['communicateIssues_1'],
						$record['communicateIssues_2'],
						$record['communicateIssues_3'],
						$record['assessHealthSafety'],
						$record['assessEnvironmentProtection'],
						$record['undertakeAssessment_1'],
						$record['undertakeAssessment_2'],
						$record['undertakeAssessment_3'],
						$record['undertakeAssessment_4'],
						$record['undertakeAssessment_5'],
						$record['undertakeAssessment_6'],
						$record['responsibleHealthSafetyName'],
						$record['responsibleHealthSafetyPosition'],
						$record['responsibleEnvironmentProtectionName'],
						$record['responsibleEnvironmentProtectionPosition'],
						$record['responsibleQualityName'],
						$record['responsibleQualityPosition'],
					   $this->contractorInfo['contractor_id']);

			$utmt = $this->dbHand->prepare($upd);
			$utmt->execute();

	}

	public function savePolicyTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_policy_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $this->contractorInfo['trade_association'] == 1 ) { $record['tradeAssociation'] = $record['tradeAssociationYes']; } else { $record['tradeAssociation'] = $record['tradeAssociationNo']; }
		if ( $this->contractorInfo['trade_association_name1'] == '' ) { $record['tradeAssociationName_1'] = 0; }
		if ( $this->contractorInfo['trade_association_name2'] == '' ) { $record['tradeAssociationName_2'] = 0; }
		if ( $this->contractorInfo['trade_association_address1'] == '' ) { $record['tradeAssociationAddress_1'] = 0; }
		if ( $this->contractorInfo['trade_association_address2'] == '' ) { $record['tradeAssociationAddress_2'] = 0; }
		if ( $this->contractorInfo['trade_association_ref1'] == '' ) { $record['tradeAssociationMemberRef_1'] = 0; }
		if ( $this->contractorInfo['trade_association_ref2'] == '' ) { $record['tradeAssociationMemberRef_2'] = 0; }
		if ( $this->contractorInfo['iso9001'] == 1 ) { $record['iso9001'] = $record['iso9001Yes']; } else { $record['iso9001'] = $record['iso9001No']; }
		if ( $this->contractorInfo['iso9001_reason'] == '' ) { $record['iso9001Reason'] = 0; }
		if ( $this->contractorInfo['iso14001'] == 1 ) { $record['iso14001'] = $record['iso14001Yes']; } else { $record['iso14001'] = $record['iso14001No']; }
		if ( $this->contractorInfo['iso14001_reason'] == '' ) { $record['iso14001Reason'] = 0; }
		if ( $this->contractorInfo['iso18001'] == 1 ) { $record['iso18001'] = $record['iso18001Yes']; } else { $record['iso18001'] = $record['iso18001No']; }
		if ( $this->contractorInfo['iso18001_reason'] == '' ) { $record['iso18001Reason'] = 0; }
		if ( $this->contractorInfo['continuous_improvement'] == 1 ) { $record['continuousImprovement'] = $record['continuousImprovementYes']; } else { $record['continuousImprovement'] = $record['continuousImprovementNo']; }
		if ( $this->contractorInfo['health_safety_policy'] == 1 ) { $record['healthSafetyPolicy'] = $record['healthSafetyPolicyYes']; } else { $record['healthSafetyPolicy'] = $record['healthSafetyPolicyNo']; }
		if ( $this->contractorInfo['environmental_policy'] == 1 ) { $record['environmentalPolicy'] = $record['environmentalPolicyYes']; } else { $record['environmentalPolicy'] = $record['environmentalPolicyNo']; }
		if ( $this->contractorInfo['quality_policy'] == 1 ) { $record['qualityPolicy'] = $record['qualityPolicyYes']; } else { $record['qualityPolicy'] = $record['qualityPolicyNo']; }
		if ( $this->contractorInfo['work_instructions'] == 1 ) { $record['workInstructions'] = $record['workInstructionsYes']; } else { $record['workInstructions'] = $record['workInstructionsNo']; }

		$upd = sprintf("UPDATE %s.contractor_policy_metadata
					   SET
				     	tradeAssociation = %d,
						tradeAssociationName_1 = %d,
						tradeAssociationName_2 = %d,
						tradeAssociationAddress_1 = %d,
						tradeAssociationAddress_2 = %d,
						tradeAssociationMemberRef_1 = %d,
						tradeAssociationMemberRef_2 = %d,
						iso9001 = %d,
						iso9001Reason = %d,
						iso14001 = %d,
						iso14001Reason = %d,
						iso18001 = %d,
						iso18001Reason = %d,
						continuousImprovement = %d,
						healthSafetyPolicy = %d,
						environmentalPolicy = %d,
						qualityPolicy = %d,
						workInstructions = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
					    $record['tradeAssociation'],
						$record['tradeAssociationName_1'],
						$record['tradeAssociationName_2'],
						$record['tradeAssociationAddress_1'],
						$record['tradeAssociationAddress_2'],
						$record['tradeAssociationMemberRef_1'],
						$record['tradeAssociationMemberRef_2'],
						$record['assessEnvironmentProtection'],
						$record['iso9001'],
						$record['iso9001Reason'],
						$record['iso14001'],
						$record['iso14001Reason'],
						$record['iso18001'],
						$record['iso18001Reason'],
						$record['continuousImprovement'],
						$record['healthSafetyPolicy'],
						$record['environmentalPolicy'],
						$record['qualityPolicy'],
						$record['workInstructions'],
					   $this->contractorInfo['contractor_id']);

			$utmt = $this->dbHand->prepare($upd);
			$utmt->execute();

	}

	public function saveRiskAssessmentTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_risk_assessment_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $this->contractorInfo['carried_risk_assessments'] == 1 ) { $record['carriedRiskAssessments'] = $record['carriedRiskAssessmentsYes']; } else { $record['carriedRiskAssessments'] = $record['carriedRiskAssessmentsNo']; }
		if ( $this->contractorInfo['carry_chemical'] == 1 ) { $record['carryChemical'] = $record['carryChemicalYes']; } else { $record['carryChemical'] = $record['carryChemicalNo']; }
		if ( $this->contractorInfo['carry_manual_handling'] == 1 ) { $record['carryManualHandling'] = $record['carryManualHandlingYes']; } else { $record['carryManualHandling'] = $record['carryManualHandlingNo']; }
		if ( $this->contractorInfo['carry_noise_exposure'] == 1 ) { $record['carryNoiseExposure'] = $record['carryNoiseExposureYes']; } else { $record['carryNoiseExposure'] = $record['carryNoiseExposureNo']; }
		if ( $this->contractorInfo['carry_lead_exposure'] == 1 ) { $record['carryLeadExposure'] = $record['carryLeadExposureYes']; } else { $record['carryLeadExposure'] = $record['carryLeadExposureNo']; }
		if ( $this->contractorInfo['carry_asbestos'] == 1 ) { $record['carryAsbestos'] = $record['carryAsbestosYes']; } else { $record['carryAsbestos'] = $record['carryAsbestosNo']; }
		if ( $this->contractorInfo['carry_display_screen'] == 1 ) { $record['carryDisplayScreen'] = $record['carryDisplayScreenYes']; } else { $record['carryDisplayScreen'] = $record['carryDisplayScreenNo']; }
		if ( $this->contractorInfo['detailed_method_statements'] == 1 ) { $record['detailedMethodStatements'] = $record['detailedMethodStatementsYes']; } else { $record['detailedMethodStatements'] = $record['detailedMethodStatementsNo']; }
		if ( $this->contractorInfo['routine_pre_during'] == 1 ) { $record['routinePreDuringPost'] = $record['routinePreDuringPostYes']; } else { $record['routinePreDuringPost'] = $record['routinePreDuringPostNo']; }

		$upd = sprintf("UPDATE %s.contractor_risk_assessment_metadata
					   SET
				     	carriedRiskAssessments = %d,
						carryChemical = %d,
						carryManualHandling = %d,
						carryNoiseExposure = %d,
						carryLeadExposure = %d,
						carryAsbestos = %d,
						carryDisplayScreen = %d,
						detailedMethodStatements = %d,
						routinePreDuringPost = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
					    $record['carriedRiskAssessments'],
						$record['carryChemical'],
						$record['carryManualHandling'],
						$record['carryNoiseExposure'],
						$record['carryLeadExposure'],
						$record['carryAsbestos'],
						$record['carryDisplayScreen'],
						$record['detailedMethodStatements'],
						$record['routinePreDuringPost'],
					   $this->contractorInfo['contractor_id']);

			$utmt = $this->dbHand->prepare($upd);
			$utmt->execute();

	}

	public function saveConsultationTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_consultation_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $this->contractorInfo['consult_health_safety'] == 1 ) { $record['consultHealthSafety'] = $record['consultHealthSafetyYes']; } else { $record['consultHealthSafety'] = $record['consultHealthSafetyNo']; }
		if ( $this->contractorInfo['consult_environmental'] == 1 ) { $record['consultEnvironmental'] = $record['consultEnvironmentalYes']; } else { $record['consultEnvironmental'] = $record['consultEnvironmentalNo']; }
		if ( $this->contractorInfo['consult_quality'] == 1 ) { $record['consultQualityYes'] = $record['consultQualityYes']; } else { $record['consultQuality'] = $record['consultQualityNo']; }
		if ( $this->contractorInfo['formal_arrangements1'] == '' ) { $record['formalArrangements_1'] = 0; }
		if ( $this->contractorInfo['formal_arrangements2'] == '' ) { $record['formalArrangements_2'] = 0; }
		if ( $this->contractorInfo['formal_arrangements3'] == '' ) { $record['formalArrangements_3'] = 0; }
		if ( $this->contractorInfo['training_person1_1'] == '' ) { $record['trainingPerson_1_1'] = 0; }
		if ( $this->contractorInfo['training_person1_2'] == '' ) { $record['trainingPerson_1_2'] = 0; }
		if ( $this->contractorInfo['training_person1_3'] == '' ) { $record['trainingPerson_1_3'] = 0; }
		if ( $this->contractorInfo['training_person1_4'] == '' ) { $record['trainingPerson_1_4'] = 0; }
		if ( $this->contractorInfo['training_person2_1'] == '' ) { $record['trainingPerson_2_1'] = 0; }
		if ( $this->contractorInfo['training_person2_2'] == '' ) { $record['trainingPerson_2_2'] = 0; }
		if ( $this->contractorInfo['training_person2_3'] == '' ) { $record['trainingPerson_2_3'] = 0; }
		if ( $this->contractorInfo['training_person2_4'] == '' ) { $record['trainingPerson_2_4'] = 0; }
		if ( $this->contractorInfo['qualifications_person1'] == '' ) { $record['qualificationsPerson_1'] = 0; }
		if ( $this->contractorInfo['qualifications_person2'] == '' ) { $record['qualificationsPerson_2'] = 0; }
		if ( $this->contractorInfo['qualifications_person3'] == '' ) { $record['qualificationsPerson_3'] = 0; }
		if ( $this->contractorInfo['qualifications_person4'] == '' ) { $record['qualificationsPerson_4'] = 0; }
		if ( $this->contractorInfo['handbooks_comment1'] == '' ) { $record['handbooksComment_1'] = 0; }
		if ( $this->contractorInfo['handbooks_comment2'] == '' ) { $record['handbooksComment_2'] = 0; }
		if ( $this->contractorInfo['handbooks_comment3'] == '' ) { $record['handbooksComment_3'] = 0; }

		$upd = sprintf("UPDATE %s.contractor_consultation_metadata
					   SET
				     	consultHealthSafety = %d,
						consultEnvironmental = %d,
						consultQuality = %d,
						formalArrangements_1 = %d,
						formalArrangements_2 = %d,
						formalArrangements_3 = %d,
						trainingPerson_1_1 = %d,
						trainingPerson_1_2 = %d,
						trainingPerson_1_3 = %d,
						trainingPerson_1_4 = %d,
						trainingPerson_2_1 = %d,
						trainingPerson_2_2 = %d,
						trainingPerson_2_3 = %d,
						trainingPerson_2_4 = %d,
						qualificationsPerson_1 = %d,
						qualificationsPerson_2 = %d,
						qualificationsPerson_3 = %d,
						qualificationsPerson_4 = %d,
						handbooks = %d,
						handbooksComment_1 = %d,
						handbooksComment_2 = %d,
						handbooksComment_3 = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
					    $record['consultHealthSafety'],
						$record['consultEnvironmental'],
						$record['consultQuality'],
						$record['formalArrangements_1'],
						$record['formalArrangements_2'],
						$record['formalArrangements_3'],
						$record['trainingPerson_1_1'],
						$record['trainingPerson_1_2'],
						$record['trainingPerson_1_3'],
						$record['trainingPerson_1_4'],
						$record['trainingPerson_2_1'],
						$record['trainingPerson_2_2'],
						$record['trainingPerson_2_3'],
						$record['trainingPerson_2_4'],
						$record['qualificationsPerson_1'],
						$record['qualificationsPerson_2'],
						$record['qualificationsPerson_3'],
						$record['qualificationsPerson_4'],
						$record['handbooks'],
						$record['handbooksComment_1'],
						$record['handbooksComment_2'],
						$record['handbooksComment_3'],
					   $this->contractorInfo['contractor_id']);

		$utmt = $this->dbHand->prepare($upd);
		$utmt->execute();


	}

	public function saveTrainingTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_training_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);


		if ( $this->contractorInfo['managers_supervisors1'] == '' ) { $record['managersSupervisors_1'] = 0; }
		if ( $this->contractorInfo['managers_supervisors2'] == '' ) { $record['managersSupervisors_2'] = 0; }
		if ( $this->contractorInfo['managers_supervisors3'] == '' ) { $record['managersSupervisors_3'] = 0; }
		if ( $this->contractorInfo['managers_supervisors4'] == '' ) { $record['managersSupervisors_4'] = 0; }
		if ( $this->contractorInfo['operatives1'] == '' ) { $record['operatives_1'] = 0; }
		if ( $this->contractorInfo['operatives2'] == '' ) { $record['operatives_2'] = 0; }
		if ( $this->contractorInfo['operatives3'] == '' ) { $record['operatives_3'] = 0; }
		if ( $this->contractorInfo['operatives4'] == '' ) { $record['operatives_4'] = 0; }
		if ( $this->contractorInfo['competent_relating1'] == '' ) { $record['competentRelating_1'] = 0; }
		if ( $this->contractorInfo['competent_relating2'] == '' ) { $record['competentRelating_2'] = 0; }
		if ( $this->contractorInfo['competent_relating3'] == '' ) { $record['competentRelating_3'] = 0; }
		if ( $this->contractorInfo['competent_relating4'] == '' ) { $record['competentRelating_4'] = 0; }
		if ( $this->contractorInfo['formal_reviews1'] == '' ) { $record['formalReviews_1'] = 0; }
		if ( $this->contractorInfo['formal_reviews2'] == '' ) { $record['formalReviews_2'] = 0; }
		if ( $this->contractorInfo['formal_reviews3'] == '' ) { $record['formalReviews_3'] = 0; }
		if ( $this->contractorInfo['formal_reviews4'] == '' ) { $record['formalReviews_4'] = 0; }

		$upd = sprintf("UPDATE %s.contractor_training_metadata
					   SET
			     	  	managersSupervisors_1 = %d,
						managersSupervisors_2 = %d,
						managersSupervisors_3 = %d,
						managersSupervisors_4 = %d,
						operatives_1 = %d,
						operatives_2 = %d,
						operatives_3 = %d,
						operatives_4 = %d,
						competentRelating_1 = %d,
						competentRelating_2 = %d,
						competentRelating_3 = %d,
						competentRelating_4 = %d,
						formalReviews_1 = %d,
						formalReviews_2 = %d,
						formalReviews_3 = %d,
						formalReviews_4 = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
					    $record['managersSupervisors_1'],
						$record['managersSupervisors_2'],
						$record['managersSupervisors_3'],
						$record['managersSupervisors_4'],
						$record['operatives_1'],
						$record['operatives_2'],
						$record['operatives_3'],
						$record['operatives_4'],
						$record['competentRelating_1'],
						$record['competentRelating_2'],
						$record['competentRelating_3'],
						$record['competentRelating_4'],
						$record['formalReviews_1'],
						$record['formalReviews_2'],
						$record['formalReviews_3'],
						$record['formalReviews_4'],
					   $this->contractorInfo['contractor_id']);

		$utmt = $this->dbHand->prepare($upd);
		$utmt->execute();
	}

	public function saveMaintenanceTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_maintenance_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		switch ( $this->contractorInfo['electrical'] ) {
			case 1: $record['electrical'] = $record['electricalYes']; break;
			case 'na': $record['electrical'] = $record['electricalNa']; break;
			case 0: $record['electrical'] = $record['electricalYes']; break;
		}

		switch ( $this->contractorInfo['access_equipments'] ) {
			case 1: $record['accessEquipments'] = $record['accessEquipmentsYes']; break;
			case 'na': $record['accessEquipments'] = $record['accessEquipmentsNa']; break;
			case 0: $record['accessEquipments'] = $record['accessEquipmentsNo']; break;
		}

		switch ( $this->contractorInfo['gas_monitors'] ) {
			case 1: $record['gasMonitors'] = $record['gasMonitorsYes']; break;
			case 'na': $record['gasMonitors'] = $record['gasMonitorsNa']; break;
			case 0: $record['gasMonitors'] = $record['gasMonitorsNo']; break;
		}

		switch ( $this->contractorInfo['hydraulic'] ) {
			case 1: $record['hydraulic'] = $record['hydraulicYes']; break;
			case 'na': $record['hydraulic'] = $record['hydraulicNa']; break;
			case 0: $record['hydraulic'] = $record['hydraulicNo']; break;
		}

		switch ( $this->contractorInfo['special_equipments'] ) {
			case 1: $record['specialTestEquipments'] = $record['specialTestEquipmentsYes']; break;
			case 'na': $record['specialTestEquipments'] = $record['specialTestEquipmentsNa']; break;
			case 0: $record['specialTestEquipments'] = $record['specialTestEquipmentsNo']; break;
		}

		switch ( $this->contractorInfo['pneumatic'] ) {
			case 1: $record['pneumatic'] = $record['pneumaticYes']; break;
			case 'na': $record['pneumatic'] = $record['pneumaticNa']; break;
			case 0: $record['pneumatic'] = $record['pneumaticNo']; break;
		}

		if ( $this->contractorInfo['electric_equipments'] == 1 ) { $record['electricEquipmentsYes']; } else  { $record['electricEquipmentsNo']; }
		if ( $this->contractorInfo['work_equipment'] == 1 ) { $record['workEquipmentYes']; } else  { $record['workEquipmentNo']; }
		if ( $this->contractorInfo['employees_accident'] == '' ) { $record['employeesNoAccident'] = 0; }
		if ( $this->contractorInfo['employees_fatality'] == '' ) { $record['employeesFatality'] = 0; }
		if ( $this->contractorInfo['employees_major'] == '' ) { $record['employeesMajor'] = 0; }
		if ( $this->contractorInfo['employees_lost_time'] == '' ) { $record['employeesLostTime'] = 0; }
		if ( $this->contractorInfo['reporting_accidents'] == 1 ) { $record['reportingAccidentsYes']; } else  { $record['reportingAccidentsNo']; }
		if ( $this->contractorInfo['prosecuted_connection'] == 1 ) { $record['prosecutedConnectionYes']; } else { $record['prosecutedConnectionNo']; }
		if ( $this->contractorInfo['prohibition_otice'] == 1 ) { $record['prohibitionNoticeYes']; } else { $record['prohibitionNoticeNo']; }
		if ( $this->contractorInfo['improvement_notice'] == 1 ) { $record['improvementNoticeYes']; } else { $record['improvementNoticeNo']; }

		$upd = sprintf("UPDATE %s.contractor_maintenance_metadata
					   SET
							electrical = %d,
							accessEquipments = %d,
							pneumatic = %d,
							gasMonitors = %d,
							hydraulic = %d,
							specialTestEquipments = %d,
							electricEquipments = %d,
							workEquipment = %d,
							employeesNoAccident = %d,
							employeesFatality = %d,
							employeesMajor = %d,
							employeesLostTime = %d,
							personsNoAccident = %d,
							personsFatality = %d,
							personsMajor = %d,
							personsLostTime = %d,
							reportingAccidents = %d,
							prosecutedConnection = %d,
							prohibitionNotice = %d,
							improvementNotice = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
							$record['electrical'],
							$record['accessEquipments'],
							$record['pneumatic'],
							$record['gasMonitors'],
							$record['hydraulic'],
							$record['specialTestEquipments'],
							$record['electricEquipments'],
							$record['workEquipment'],
							$record['employeesNoAccident'],
							$record['employeesFatality'],
							$record['employeesMajor'],
							$record['employeesLostTime'],
							$record['personsNoAccident'],
							$record['personsFatality'],
							$record['personsMajor'],
							$record['personsLostTime'],
							$record['reportingAccidents'],
							$record['prosecutedConnection'],
							$record['prohibitionNotice'],
							$record['improvementNotice'],
					   $this->contractorInfo['contractor_id']);

		$utmt = $this->dbHand->prepare($upd);
		$utmt->execute();

	}

	public function saveInsuranceTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_insurance_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( $this->contractorInfo['employers_insurer_name'] == '' ) { $record['employersLiabilityInsurerName'] = 0; }
		if ( $this->contractorInfo['employers_certificate_no'] == '' ) { $record['employersLiabilityCertificateNo'] = 0; }
		if ( $this->contractorInfo['employers_sum_assured'] == '' ) { $record['employersLiabilitySumAssured'] = 0; }
		if ( $this->contractorInfo['employers_expiry_date'] == '' ) { $record['employersLiabilityExpiryDate'] = 0; }
		if ( $this->contractorInfo['public_insurer_name'] == '' ) { $record['publicLiabilityInsurerName'] = 0; }
		if ( $this->contractorInfo['public_certificate_no'] == '' ) { $record['publicLiabilityCertificateNo'] = 0; }
		if ( $this->contractorInfo['public_sum_assured'] == '' ) { $record['publicLiabilitySumAssured'] = 0; }
		if ( $this->contractorInfo['public_expiry_date'] == '' ) { $record['publicLiabilityExpiryDate'] = 0; }
		if ( $this->contractorInfo['activities_expose_employees'] == 1 ) { $record['activitiesExposeEmployees'] = $record['activitiesExposeEmployeesYes']; } else { $record['activitiesExposeEmployees'] = $record['activitiesExposeEmployeesNo']; }
		if ( $this->contractorInfo['provide_first_aiders'] == 1 ) { $record['provideFirstAiders'] = $record['provideFirstAidersYes']; } else { $record['provideFirstAiders'] = $record['provideFirstAidersNo']; }
		if ( $this->contractorInfo['fire_risk_assessments'] == 1 ) { $record['fireRiskAssessments'] = $record['fireRiskAssessmentsYes']; } else { $record['fireRiskAssessments'] = $record['fireRiskAssessmentsNo']; }

		$upd = sprintf("UPDATE %s.contractor_insurance_metadata
					   SET
							employersLiabilityInsurerName = %d,
							employersLiabilityCertificateNo = %d,
							employersLiabilitySumAssured = %d,
							employersLiabilityExpiryDate = %d,
							publicLiabilityInsurerName = %d,
							publicLiabilityCertificateNo = %d,
							publicLiabilitySumAssured = %d,
							publicLiabilityExpiryDate = %d,
							activitiesExposeEmployees = %d,
							provideFirstAiders = %d,
							fireRiskAssessments = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
							$record['employersLiabilityInsurerName'],
							$record['employersLiabilityCertificateNo'],
							$record['employersLiabilitySumAssured'],
							$record['employersLiabilityExpiryDate'],
							$record['publicLiabilityInsurerName'],
							$record['publicLiabilityCertificateNo'],
							$record['publicLiabilitySumAssured'],
							$record['publicLiabilityExpiryDate'],
							$record['activitiesExposeEmployees'],
							$record['provideFirstAiders'],
							$record['fireRiskAssessments'],
					   $this->contractorInfo['contractor_id']);

		$utmt = $this->dbHand->prepare($upd);
		$utmt->execute();
	}

	public function saveDocumentsTabScore() {

		$sql = sprintf("SELECT * FROM %s.contractor_documents_score_metadata",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

	 	if ( $this->contractorInfo['contractors_questionnaire'] == '' ) { $record['subContractorsQuestionnaire'] = 0; }
		if ( $this->contractorInfo['continuous_improvement'] == '' ) { $record['continuousImprovement'] = 0; }
		if ( $this->contractorInfo['health_safety_policy'] == '' ) { $record['healthSafetyPolicy'] = 0; }
		if ( $this->contractorInfo['environmental_policy'] == '' ) { $record['environmentalPolicy'] = 0; }
		if ( $this->contractorInfo['quality_policy'] == '' ) { $record['qualityPolicy'] = 0; }
		if ( $this->contractorInfo['health_safety_procedures'] == '' ) { $record['healthSafetyProcedures'] = 0; }
		if ( $this->contractorInfo['environmental_procedures'] == '' ) { $record['environmentalProcedures'] = 0; }
		if ( $this->contractorInfo['quality_procedures'] == '' ) { $record['qualityProcedures'] = 0; }
		if ( $this->contractorInfo['examples_relevant_risk'] == '' ) { $record['examplesRelevantRisk'] = 0; }
		if ( $this->contractorInfo['examples_relevant_method'] == '' ) { $record['examplesRelevantMethod'] = 0; }
		if ( $this->contractorInfo['example_documentation'] == '' ) { $record['exampleDocumentation'] = 0; }
		if ( $this->contractorInfo['employee_health_safety'] == '' ) { $record['employeeHealthSafety'] = 0; }
		if ( $this->contractorInfo['training_certificates'] == '' ) { $record['trainingCertificates'] = 0; }
		if ( $this->contractorInfo['work_equipment'] == '' ) { $record['workEquipment'] = 0; }
		if ( $this->contractorInfo['portable_appliance'] == '' ) { $record['portableAppliance'] = 0; }
		if ( $this->contractorInfo['employee_guidance_documentation'] == '' ) { $record['employeeGuidanceDocumentation'] = 0; }
		if ( $this->contractorInfo['public_insurance'] == '' ) { $record['publicLiabilityInsurance'] = 0; }
		if ( $this->contractorInfo['employers_insurance'] == '' ) { $record['employersLiabilityInsurance'] = 0; }
		if ( $this->contractorInfo['evidence_surveillance'] == '' ) { $record['evidenceHealthSurveillance'] = 0; }
		if ( $this->contractorInfo['fire_assessment'] == '' ) { $record['fireRiskAssessment'] = 0; }

		$upd = sprintf("UPDATE %s.contractor_documents_metadata
					   SET
							subContractorsQuestionnaire = %d,
							continuousImprovement = %d,
							healthSafetyPolicy = %d,
							environmentalPolicy = %d,
							qualityPolicy = %d,
							healthSafetyProcedures = %d,
							environmentalProcedures = %d,
							qualityProcedures = %d,
							examplesRelevantRisk = %d,
							examplesRelevantMethod = %d,
							exampleDocumentation = %d,
							employeeHealthSafety = %d,
							trainingCertificates = %d,
							workEquipment = %d,
							portableAppliance = %d,
							employeeGuidanceDocumentation = %d,
							publicLiabilityInsurance = %d,
							employersLiabilityInsurance = %d,
							evidenceHealthSurveillance = %d,
							fireRiskAssessment = %d
					   WHERE cID = %d",_DB_OBJ_FULL,
							$record['subContractorsQuestionnaire'],
							$record['continuousImprovement'],
							$record['healthSafetyPolicy'],
							$record['environmentalPolicy'],
							$record['qualityPolicy'],
							$record['healthSafetyProcedures'],
							$record['environmentalProcedures'],
							$record['qualityProcedures'],
							$record['examplesRelevantRisk'],
							$record['examplesRelevantMethod'],
							$record['exampleDocumentation'],
							$record['employeeHealthSafety'],
							$record['trainingCertificates'],
							$record['workEquipment'],
							$record['portableAppliance'],
							$record['employeeGuidanceDocumentation'],
							$record['publicLiabilityInsurance'],
							$record['employersLiabilityInsurance'],
							$record['evidenceHealthSurveillance'],
							$record['fireRiskAssessment'],
					   $this->contractorInfo['contractor_id']);

		$utmt = $this->dbHand->prepare($upd);
		$utmt->execute();
	}

	public function updateScore($p_tab) {

		$p_contractorID = $this->contractorInfo['contractor_id'];

		$context_tab = $p_tab + 1;

		$fieldname =  'score'.ucfirst($this->tabsMapping[$context_tab]);

		if ( $this->tabsMapping[$context_tab] == 'riskAssessment' ) {
			$tablename_metadata = 'contractor_risk_assessment_metadata';
		} else {
			$tablename_metadata = 'contractor_'.$this->tabsMapping[$context_tab].'_metadata';
		}

		$sql = sprintf("SELECT * FROM %s.%s
						WHERE cID = %d",_DB_OBJ_FULL,$tablename_metadata,$p_contractorID);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		$obtained = 0;

		$k = 0;

		if ($record) {
			foreach ( $record as $record_ele ) {

				if (!$k) { $k++; continue; }

				$obtained += $record_ele;
				$k++;
			}
		}


		$upd = sprintf("UPDATE %s.contractor_score SET %s = %d WHERE contID = %d",_DB_OBJ_FULL,$fieldname,$obtained,$p_contractorID);

		$updstmt = $this->dbHand->prepare($upd);
		$updstmt->execute();

	}

	private function getScore($p_contractorID) {

		$sql = sprintf("SELECT * FROM %s.contractor_score
						WHERE contID = %d",_DB_OBJ_FULL,$p_contractorID);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$record = $stmt->fetch(PDO::FETCH_ASSOC);

		$obtained = 0;
		$total 	  = 0;


		$obtained = $record['scoreManagement'] + $record['scoreCompetency'] + $record['scorePolicy'] + $record['scoreRiskAssessment'];
		$obtained += $record['scoreConsultation'] + $record['scoreTraining'] + $record['scoreMaintenance'] + $record['scoreInsurance'] + $record['scoreDocument'];

		$k = 0;
		foreach ( $this->tabsMapping as $tableEle ) {

			if (!$k) { $k++; continue; }
			$k++;

			if ( $tableEle == 'riskAssessment' ) {
				$tableEle = 'risk_assessment';
			}

			$tablename = 'contractor_'.$tableEle.'_score_metadata';

			$sql = sprintf("SELECT * FROM %s.%s",_DB_OBJ_FULL,$tablename);

			$stmt = $this->dbHand->prepare($sql);

			$stmt->execute();
			$record = $stmt->fetch(PDO::FETCH_ASSOC);

			foreach ( $record as $record_ele ) {
				$total += $record_ele;
			}
		}

		$calculated_score = ($obtained * 100)/$total;
		$calculated_score = round($calculated_score,2);

		//echo "obtained = $obtained, total = $total, score = $calculated_score";

		return $calculated_score;
	}

	public function getColorCode($p_contractorID) {

		$score 	= $this->getScore($p_contractorID);
		$colour = "#00ff00";

		if ( $score < $this->lowerValue ) {
			$colour = "#ff0000";
		} else if ( $score > $this->lowerValue && $score < $this->upperValue ) {
			$colour = "#ff7e00";
		}

		$optObj = null;

		return $colour;
	}
	
	public function viewInstructorsFromContractors() {
		$sql = sprintf("SELECT * FROM %s.contractor WHERE archive = '0' AND TRG='1' ",_DB_OBJ_FULL);
		$sql .= "  AND contactPerson LIKE '".$this->contractorInfo['str']."%' ORDER BY ID DESC"; // ,$this->contractorInfo['archive']

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->contractorInfo['archive']);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		return $records;
	}

}