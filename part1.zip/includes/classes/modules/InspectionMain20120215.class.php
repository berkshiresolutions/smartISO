<?php
 /**
  $Id: InspectionMain.class.php,v 3.44 Saturday, February 05, 2011 10:31:02 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, October 28, 2010 4:24:29 PM>
  */
require_once "Inspection.int.php";
require_once "Action.class.php";

class InspectionMain implements Inspection
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Inspection Id
	 *@access private
	 */
	private $InspectionId;
	/**
	 *Property to hold Inspection Section Id
	 *@access private
	 */
	private $inspectionSectionId;

	/**
	 *Property to hold Inspection Info
	 *@access private
	 */
	private $InspectionInfo;


	/**
	 * Constructor for initializing Inspection object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * This method is used to set Inspection information for the respective object
	 */
	public function setInspectionInfo($p_InspId,$p_InspInfo) {

		$this->InspectionId		 = $p_InspId;
		$this->InspectionInfo	 = $p_InspInfo;
	}

	/*
	 * This method is used to add new Inspection
	 * reference,unique_reference, location,business,participant,when_date
	 */
	public function addInspection() {

		$sql = sprintf("SELECT * FROM %s.inspection WHERE reference LIKE '%s'",_DB_OBJ_FULL,$this->InspectionInfo['reference']);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->InspectionInfo['reference']);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$exists = count($result);

		if ( $exists ) {
			throw new ErrorException('Reference number already exist.');
		} else {

			$sql1 = sprintf("INSERT INTO %s.inspection (reference,uniqueReference,locationID,buID,participantID,whenDate,archive)
										VALUES ('%s','%s',%d,%d,%d,'%s','0') ",_DB_OBJ_FULL,$this->InspectionInfo['reference'],
										$this->InspectionInfo['unique_reference'],$this->InspectionInfo['location'],$this->InspectionInfo['business'],
										$this->InspectionInfo['participant'],format_date_for_mysql($this->InspectionInfo['when_date']));

			$pStatement1 = $this->dbHand->prepare($sql1);

			/*$pStatement1->bindParam(1,$this->InspectionInfo['reference']);
			$pStatement1->bindParam(2,$this->InspectionInfo['unique_reference']);
			$pStatement1->bindParam(3,$this->InspectionInfo['location']);
			$pStatement1->bindParam(4,$this->InspectionInfo['business']);
			$pStatement1->bindParam(5,$this->InspectionInfo['participant']);
			$pStatement1->bindParam(6,format_date_for_mysql($this->InspectionInfo['when_date']));*/

			$pStatement1->execute();

			$this->InspectionId = customLastInsertId( $this->dbHand,'inspection','ID');
		}

	}

	/**
	 * This method is used to get last inserted record Id
	 */
	public function lastRecordId() {
		return $this->InspectionId;
	}

	/*
	 * This method is used to edit an inspection record
	 */
	public function editInspection() {

		$sql = sprintf("UPDATE %s.inspection SET locationID = %d,
										participantID = %d,
										whenDate = '%s'
									WHERE ID = %d ",_DB_OBJ_FULL,$this->InspectionInfo['location'],$this->InspectionInfo['participant'],
									format_date_for_mysql($this->InspectionInfo['when_date']),$this->InspectionId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionInfo['location']);
		$pStatement->bindParam(2,$this->InspectionInfo['participant']);
		$pStatement->bindParam(3,format_date_for_mysql($this->InspectionInfo['when_date']));
		$pStatement->bindParam(4,$this->InspectionId);*/

		//dump_array($this);

		$pStatement->execute();
	}

	/*
	 * This method is used to manage sectoins
	 * section,step,sub_step
	 */
	public function manageSections() {

		switch ( $this->InspectionInfo['section'] ) {

			case 2: $module_identifier = "inspectionC"; break;
			case 3: $module_identifier = "inspectionR"; break;
			case 4: $module_identifier = "inspectionM"; break;
			case 5: $module_identifier = "inspectionH"; break;
			case 6: $module_identifier = "inspectionH"; break;
		}

		$this->actionData = array('module_name'=>$module_identifier,'description'=>$this->InspectionInfo['action'],
								  'who'=>$this->InspectionInfo['who'],'whoAU'=>$this->InspectionInfo['whoAU'],'due_date'=>$this->InspectionInfo['when']);

		$sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d AND step = %d AND subStep = %d ",_DB_OBJ_FULL,
					   $this->InspectionId,$this->InspectionInfo['section'],$this->InspectionInfo['step'],$this->InspectionInfo['sub_step']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionId);
		$pStatement->bindParam(2,$this->InspectionInfo['section']);
		$pStatement->bindParam(3,$this->InspectionInfo['step']);
		$pStatement->bindParam(4,$this->InspectionInfo['sub_step']);*/

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$exists = count($result);

		$this->inspectionSectionId = $result[0]['ID'];

		if ( $exists ) {
			// do update
			$this->editSection($result[0]['actionID'],$result[0]['ID']);
		} else {
			// do insert
			$this->addSection();
		}

		if ( $this->InspectionInfo['section'] == 6 ) {

			$upd = sprintf("UPDATE %s.inspection SET status = 1 WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionId);
			$pStatement = $this->dbHand->prepare($upd);
			$pStatement->execute();

		}
	}

	private function addSection() {

		$this->actionHandling->setActionDetails(0,$this->actionData);
		$new_action_id = $this->actionHandling->addAction();
		$action_id = $new_action_id;
		$this->actionHandling->updateStatus($action_id);

		$sql = sprintf("INSERT INTO %s.inspection_metadata (inspectionID,tab,step,subStep,expectation,problem,actionID,isRiskValid,hazardClassificationID,
													hazardsID,processID,actionDescOld,outstanding,mainProcessID,processStepID,managementHazardID)
											VALUES (%d,%d,%d,%d,'%s','%s',%d,'%s',%d,'%s',%d,'%s','0',%d,%d,%d)",_DB_OBJ_FULL,$this->InspectionId,
											$this->InspectionInfo['section'],$this->InspectionInfo['step'],$this->InspectionInfo['sub_step'],
											$this->InspectionInfo['expectation'],$this->InspectionInfo['problem'],$action_id,
											$this->InspectionInfo['risk_valid'],$this->InspectionInfo['hazard_classification'],$this->InspectionInfo['hazards'],
											$this->InspectionInfo['process_id'],$this->InspectionInfo['action_old'],$this->InspectionInfo['main_process_id'],
											$this->InspectionInfo['step_id'],$this->InspectionInfo['management_hazard']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionId);
		$pStatement->bindParam(2,$this->InspectionInfo['section']);
		$pStatement->bindParam(3,$this->InspectionInfo['step']);
		$pStatement->bindParam(4,$this->InspectionInfo['sub_step']);
		$pStatement->bindParam(5,$this->InspectionInfo['expectation']);
		$pStatement->bindParam(6,$this->InspectionInfo['problem']);
		$pStatement->bindParam(7,$action_id);
		$pStatement->bindParam(8,$this->InspectionInfo['risk_valid']);
		$pStatement->bindParam(9,$this->InspectionInfo['hazard_classification']);
		$pStatement->bindParam(10,$this->InspectionInfo['hazards']);
		$pStatement->bindParam(11,$this->InspectionInfo['process_id']);
		$pStatement->bindParam(12,$this->InspectionInfo['action_old']);
		$pStatement->bindParam(13,$this->InspectionInfo['main_process_id']);
		$pStatement->bindParam(14,$this->InspectionInfo['step_id']);
		$pStatement->bindParam(15,$this->InspectionInfo['management_hazard']);*/

		$pStatement->execute();

		//dump_array_and_exit($pStatement->errorInfo());

		$this->inspectionSectionId = customLastInsertId( $this->dbHand,'inspection_metadata','ID');
	}

	private function editSection($p_action_id,$p_table_id) {


		$this->actionHandling->setActionDetails($p_action_id,$this->actionData);
		$this->actionHandling->updateAction();
		$this->actionHandling->updateStatus($p_action_id);

		$sql = sprintf("UPDATE %s.inspection_metadata SET expectation = '%s',
												problem = '%s',
												isRiskValid = '%s',
												hazardClassificationID = '%s',
												hazardsID = '%s',
												processID = %d,
												actionDescOld = '%s',
												mainProcessID = %d,
												processStepID = %d,
												managementHazardID = %d
											WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionInfo['expectation'],$this->InspectionInfo['problem'],
											$this->InspectionInfo['risk_valid'],$this->InspectionInfo['hazard_classification'],$this->InspectionInfo['hazards'],
											$this->InspectionInfo['process_id'],$this->InspectionInfo['action_old'],$this->InspectionInfo['main_process_id'],
											$this->InspectionInfo['step_id'],$this->InspectionInfo['management_hazard'],$p_table_id);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionInfo['expectation']);
		$pStatement->bindParam(2,$this->InspectionInfo['problem']);
		$pStatement->bindParam(3,$this->InspectionInfo['risk_valid']);
		$pStatement->bindParam(4,$this->InspectionInfo['hazard_classification']);
		$pStatement->bindParam(5,$this->InspectionInfo['hazards']);
		$pStatement->bindParam(6,$this->InspectionInfo['process_id']);
		$pStatement->bindParam(7,$this->InspectionInfo['action_old']);
		$pStatement->bindParam(8,$this->InspectionInfo['main_process_id']);
		$pStatement->bindParam(9,$this->InspectionInfo['step_id']);
		$pStatement->bindParam(10,$this->InspectionInfo['management_hazard']);
		$pStatement->bindParam(11,$p_table_id);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to get last inserted record Id
	 */
	public function lastSectionRecordId() {
		return $this->inspectionSectionId;
	}

	/**/
	public function getSectionDetails() {

		$sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d AND step = %d AND subStep = %d",_DB_OBJ_FULL,$this->InspectionId,
					   $this->InspectionInfo['section'],$this->InspectionInfo['step'],$this->InspectionInfo['sub_step']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionId);
		$pStatement->bindParam(2,$this->InspectionInfo['section']);
		$pStatement->bindParam(3,$this->InspectionInfo['step']);
		$pStatement->bindParam(4,$this->InspectionInfo['sub_step']);*/

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$section_data = $result[0];

		if ( $section_data['actionID'] != '' ) {
			$this->actionHandling->setActionDetails($section_data['actionID'],"");
			$action_data = $this->actionHandling->viewAction();
			$section_data['action'] = $action_data['actionDescription'];
			$section_data['who'] = $action_data['who'];
			$section_data['when'] = $action_data['dueDate'];
		}


		return $section_data;
	}

	/*
	 * This method is used to delete an inspection record
	 */
	public function deleteInspection() {}

	/*
	 * This method is used to archive an inspection record
	 */
	public function archiveInspection() {

		$sql = sprintf("UPDATE %s.inspection SET archive = '%s' WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionInfo['archive'],$this->InspectionId);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionInfo['archive']);
		$pStatement->bindParam(2,$this->InspectionId);*/

		$pStatement->execute();
	}

	/*
	 * This method is used to completely delete an inspection record
	 */
	public function purgeInspection() {

		$sql2 = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d ",_DB_OBJ_FULL,$this->InspectionId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		//$pStatement2->bindParam(1,$this->InspectionId);
		$pStatement2->execute();

		$metadata = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

		if ( count($metadata) ) {
			foreach ( $metadata as $value ) {
				if ( $value['actionID'] != '' ) {
					$this->actionHandling->setActionDetails($value['actionID'],"");
					$this->actionHandling->deleteAction();
				}

			}
		}

		$sql2 = sprintf("DELETE FROM %s.inspection_metadata WHERE inspectionID = %d",_DB_OBJ_FULL,$this->InspectionId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		//$pStatement2->bindParam(1,$this->InspectionId);
		$pStatement2->execute();

		$sql3 = sprintf("DELETE FROM %s.inspection WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionId);
		$pStatement3 = $this->dbHand->prepare($sql3);

		//$pStatement3->bindParam(1,$this->InspectionId);
		$pStatement3->execute();
	}

	/*
	 * This method is used to display an inspection record
	 */
	public function viewInspectionById() {

		$sql = sprintf("SELECT * FROM %s.inspection WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->InspectionId);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($result) ) {
			return $result[0];
		} else {
			return 0;
		}
	}

	/*
	 * This method is used to display an inspection record
	 */
	public function viewInspections() {

		//$sql = sprintf("SELECT * FROM %s.inspection WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->InspectionInfo['archive']);

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.inspection A
			LEFT OUTER JOIN (
				SELECT *
				FROM %s.recordTracking
				WHERE moduleName = 'INSP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->InspectionInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->InspectionInfo['archive']);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function viewInspectionsByLogDate() {

		//$sql = sprintf("SELECT * FROM %s.inspection WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->InspectionInfo['archive']);

		$date_filter = '';

		if ( $this->InspectionInfo['start_date'] != '--' &&  $this->InspectionInfo['end_date'] != '--' && $this->InspectionInfo['start_date'] != '' &&  $this->InspectionInfo['end_date'] != '' ) {
			$date_filter = " AND (dateTimestamp BETWEEN '".$this->InspectionInfo['start_date']." 00:00:00.000' AND '".$this->InspectionInfo['end_date']." 23:59:59.000') ";
			$join_type = 'INNER';
			$date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
		} else {
			$date_filter = '';
			$join_type = 'LEFT OUTER';
			$date_timestamp_not_null = '';
		}

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.inspection A
				".$join_type." JOIN (
				SELECT *
				FROM %s.recordTracking
				WHERE moduleName = 'INSP'
				AND action = 'add'
				".$date_timestamp_not_null."
			) B
			ON recordRef = reference
			WHERE A.archive = '%s'
			$date_filter
			ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->InspectionInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->InspectionInfo['archive']);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getCCPs($p_bu_id) {

		$sql = sprintf("SELECT M.*,N.criticalControlPoint,N.ID AS step_id,N.stepLevel AS step_level
						FROM %s.swimlane M
						INNER JOIN %s.swimlane_data N  ON N.swimID = M.swimID
						WHERE N.criticalControlPoint!='' AND M.buID = %d ORDER BY N.ID ASC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_bu_id);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$p_bu_id);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


		return $result;
	}

	public function getAssessmentDetails($p_process_id,$p_step_id) {

		if ( _DB_TYPE == 'mssql' ) {
			$sql = sprintf("SELECT TOP 1 * FROM %s.risk WHERE processID = %d AND processStepID = %d",_DB_OBJ_FULL,$p_process_id,$p_step_id);
		} else {
			$sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d LIMIT 0,1",_DB_OBJ_FULL,$p_process_id,$p_step_id);
		}


		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_process_id);
		$pStatement->bindParam(2,$p_step_id);*/

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $result[0];
	}

	public function getRiskManagement($p_bu_id) {

		global $RISK_RATING_CODES;

		$sql = sprintf("SELECT opValue FROM %s.options WHERE opName='_INSPECTION_RISK_RATING' ",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		$risk_rating = $pStatement->fetch(PDO::FETCH_ASSOC);

		$risk_rating = trim($risk_rating['opValue'],"");

		$risk_ratings_all = '(';
		foreach ( $RISK_RATING_CODES as $value ) {
			$risk_ratings_all .= " R.riskRating1 LIKE '".$value."' ";
			if ( $risk_rating == $value ) {
				break;
			}

			$risk_ratings_all .= " OR ";
		}

		$risk_ratings_all .= ')';

		$risk_ratings_all = trim($risk_ratings_all,',');

		$sql2 = sprintf("SELECT R.*,M.description,M.reference FROM %s.risk R
								INNER JOIN %s.swimlane M
								ON M.swimID = R.processID
								WHERE M.buID = %d AND ",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_bu_id);

		$sql2 = $sql2.$risk_ratings_all."  ORDER BY R.ID ASC";

		//echo $sql2;

		$pStatement2 = $this->dbHand->prepare($sql2);
		/*$pStatement2->bindParam(1,$risk_rating['opValue']);
		$pStatement2->bindParam(2,$p_bu_id);*/
		$pStatement2->execute();

		$processes = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($processes);
		return $processes;
	}

	public function getInspectionByBu($p_bu_id) {

		if ( _DB_TYPE == 'mssql' ) {
			$sql = sprintf("SELECT TOP 1 * FROM inspection WHERE buID = %d ORDER BY ID DESC ",_DB_OBJ_FULL,$p_bu_id);
		} else {
			$sql = sprintf("SELECT * FROM inspection WHERE buID = %d ORDER BY ID DESC LIMIT 0,1 ",_DB_OBJ_FULL,$p_bu_id);
		}


		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$p_bu_id);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $result[0];
	}

	public function ispectionFrequencies($p_bu_frequencies,$date) {

		$miscObj = new Misc();

		if ( count($p_bu_frequencies) ) {
			foreach ( $p_bu_frequencies as $value ) {

				switch($value['frequency']) {
					case 'W' : $duration = 7; $interval = 'DAY'; break;
					case 'M' : $duration = 1; $interval = 'MONTH'; break;
					case 'Q' : $duration = 3; $interval = 'MONTH'; break;
					case 'B' : $duration = 4; $interval = 'MONTH'; break;
					case 'A' : $duration = 1; $interval = 'YEAR'; break;
				}

				$check_date = $miscObj->makeCustomDate($date,$duration,$interval);
				$current_date = $miscObj->getCurDate();
				//echo "<br/>";
				if ( $current_date < $check_date ) {
					$flags[$value['module']] = 1;
				} else {
					$flags[$value['module']] = 0;
				}
			}
		}

		return $flags;
	}

	public function getAddtionalHazardCount() {

		$sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d ",_DB_OBJ_FULL,$this->InspectionId,$this->InspectionInfo['section']);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionId);
		$pStatement->bindParam(2,$this->InspectionInfo['section']);*/

		$pStatement->execute();
		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return count($records);
	}

	public function getMaxSubStep() {
		$sql = sprintf("SELECT MAX(subStep) FROM %s.inspection_metadata WHERE inspectionID = %d AND tab = %d AND step = %d ",_DB_OBJ_FULL,
					   $this->InspectionId,$this->InspectionInfo['section'],$this->InspectionInfo['step']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionId);
		$pStatement->bindParam(2,$this->InspectionInfo['section']);
		$pStatement->bindParam(3,$this->InspectionInfo['step']);*/

		$pStatement->execute();

		return $pStatement->fetchColumn();
	}

	public function updateOutstanding() {

		$sql = sprintf("UPDATE %s.inspection_metadata SET outstanding = '%s'
											WHERE ID = %d",_DB_OBJ_FULL,$this->InspectionInfo['outstanding_flag'],$this->InspectionInfo['action_id']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->InspectionInfo['outstanding_flag']);
		$pStatement->bindParam(2,$this->InspectionInfo['action_id']);*/

		$pStatement->execute();
	}

	public function getInspectionCountByBu($p_bu_id) {

		$sql = sprintf("SELECT * FROM %s.inspection WHERE buID = %d ",_DB_OBJ_FULL,$p_bu_id);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$p_bu_id);

		$pStatement->execute();
		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return count($records);
	}

	public function getAllInspectionActions() {

		$sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE outstanding='0' ",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();
		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($records) ) {
			$i=0;
			foreach ( $records as $value_record )  {
				$section_data[$i] = $value_record;

				if ( $section_data[$i]['actionID'] != '' ) {
					$this->actionHandling->setActionDetails($section_data[$i]['actionID'],"");
					$action_data = $this->actionHandling->viewAction();
					$section_data[$i]['action'] = $action_data['actionDescription'];
					$section_data[$i]['who'] = $action_data['who'];
					$section_data[$i]['when'] = $action_data['dueDate'];
					$section_data[$i]['done_date'] = $action_data['doneDate'];
					$section_data[$i]['approve'] = $action_data['approve'];
				}

				$i++;
			}
		}

		return $section_data;
	}

	public function checkInspectionDone($p_bu_frequencies) {

		if ( count($p_bu_frequencies) ) {
			foreach ( $p_bu_frequencies as $value ) {

				$sql = sprintf("SELECT * FROM %s.inspections_done WHERE buID = %d AND module LIKE '%s' ",_DB_OBJ_FULL,$value['buID'],$value['module']);
				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$value['buID']);
				$pStatement->bindParam(2,$value['module']);*/

				$pStatement->execute();
				$results = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( !count($results) ) {
					// do insert
					$sql2 = sprintf("INSERT INTO %s.inspections_done (buID,module,whenDate,isDone)
														VALUES (%d,'%s',".customCurrentDate().",'0')",_DB_OBJ_FULL,$value['buID'],$value['module']);
					$pStatement2 = $this->dbHand->prepare($sql2);

					/*$pStatement2->bindParam(1,$value['buID']);
					$pStatement2->bindParam(2,$value['module'])*/;

					$pStatement2->execute();

				} else {

					$miscObj = new Misc();

					switch($value['frequency']) {
						case 'W' : $duration = 7; $interval = 'DAY'; break;
						case 'M' : $duration = 1; $interval = 'MONTH'; break;
						case 'Q' : $duration = 3; $interval = 'MONTH'; break;
						case 'B' : $duration = 4; $interval = 'MONTH'; break;
						case 'A' : $duration = 1; $interval = 'YEAR'; break;
					}

					$check_date = $miscObj->makeCustomDate($results[0]['whenDate'],$duration,$interval);
					$current_date = $miscObj->getCurDate();
					//echo "<br/>";
					if ( $current_date > $check_date ) {
							$this->updInspectionDone($value['buID'],$value['module'],$results[0]['whenDate']);
					}
				}

			}
		}
		return $flags;
	}

	public function updInspectionDone($p_bu_id,$p_module,$p_date,$done_flag=0) {

		$sql2 = sprintf("UPDATE %s.inspections_done SET isDone = '%s',whenDate = '%s'  WHERE buID = %d AND module LIKE '%s' ",_DB_OBJ_FULL,
						$done_flag,$p_date,$p_bu_id,$p_module);
		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$done_flag);
		$pStatement2->bindParam(2,$p_date);
		$pStatement2->bindParam(3,$p_bu_id);
		$pStatement2->bindParam(4,$p_module);*/

		$pStatement2->execute();
	}

	public function getInspectionsDone($p_bu_id,$p_module='') {

		$sql = sprintf("SELECT * FROM %s.inspections_done WHERE buID = %d AND module LIKE '%s' ",_DB_OBJ_FULL,$p_bu_id,$p_module);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_bu_id);
		$pStatement->bindParam(2,$p_module);*/

		$pStatement->execute();
		$results = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $results;

	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('inspection%');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('inspection%',true);
		}

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT I.ID AS insp_id,I.reference,I.buID,M.tab,M.step,M.subStep,M.expectation,M.problem,M.mainProcessID,M.processStepID
							   FROM %s.inspection I
								INNER JOIN %s.inspection_metadata M
								ON M.inspectionID=I.ID
								WHERE M.actionID LIKE '%s' OR M.actionID LIKE '%s' OR M.actionID LIKE '%s' OR M.actionID LIKE '%s' ",_DB_OBJ_FULL,_DB_OBJ_FULL,
								$search_value1,$search_value2,$search_value3,$search_value4);


				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$search_value1);
				$pStatement->bindParam(2,$search_value2);
				$pStatement->bindParam(3,$search_value3);
				$pStatement->bindParam(4,$search_value4);*/

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {
					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']				 = $value2['reference'];
						$new_data[$i]['bu']						 = $value2['buID'];
						$new_data[$i]['tab']					 = $value2['tab'];
						$new_data[$i]['step']					 = $value2['step'];
						$new_data[$i]['subStep']				 = $value2['subStep'];
						$new_data[$i]['expectation']			 = $value2['expectation'];
						$new_data[$i]['problem']				 = $value2['problem'];
						$new_data[$i]['main_process_id']		 = $value2['mainProcessID'];
						$new_data[$i]['step_id']				 = $value2['processStepID'];
						$new_data[$i]['insp_id']				 = $value2['insp_id'];
						$new_data[$i]['action_id']				 = $value['ID'];
						$new_data[$i]['who']					 = $value['who'];
						$new_data[$i]['due_date']				 = $value['dueDate'];
						$new_data[$i]['action']					 = $value['actionDescription'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function getTotalOutstandingActions($p_flag) {

		$sql = sprintf("SELECT * FROM %s.actions WHERE outstanding = '%s'",_DB_OBJ_FULL,$p_flag);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return count($result);
	}

	public function sendActionAlerts($p_record_id) {

		$this->inspectionSectionId = $p_record_id;

		$sql = sprintf("SELECT * FROM %s.inspection_metadata WHERE ID = %d ",_DB_OBJ_FULL,$this->inspectionSectionId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->inspectionSectionId);

		$pStatement->execute();
		$result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$section_data = $result[0];

		$this->InspectionId = $result[0]['inspectionID'];
		$inspection_details = $this->viewInspectionById();

		$orgObj		= SetupGeneric::useModule('Organigram');
		$orgObj->setItemInfo(array('id'=>$inspection_details['buID']));
		$org_data 	= $orgObj->displayItemById();
		$orgObj 	= null;

		$section_data['reference'] = $inspection_details['reference'];
		$section_data['isRiskValid'] = $section_data['isRiskValid'] == 1 ? 'Yes' : 'No';

		$section_data['process_bu'] = $org_data['buName'];

		if ( $section_data['actionID'] != '' ) {
			$this->actionHandling->setActionDetails($section_data['actionID'],"");
			$action_data = $this->actionHandling->viewAction();
			$section_data['action'] = $action_data['actionDescription'];
			$section_data['who'] = $action_data['who'];
			$section_data['whoAU'] = $action_data['whoAU'];
			$section_data['when'] = format_date($action_data['dueDate']);
		}

		if ( $section_data['tab'] == 2 || $section_data['tab'] == 3 ) {

			$sql = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d ",_DB_OBJ_FULL,$section_data['mainProcessID']);
			$pStatement = $this->dbHand->prepare($sql);

			//$pStatement->bindParam(1,$section_data['mainProcessID']);
			$pStatement->execute();
			$process_metadata = $pStatement->fetchAll(PDO::FETCH_ASSOC);

			$objProcessMaster 	= new ProcessFlowMaster();
			$process_data = $objProcessMaster->displayProcessFlowById($section_data['mainProcessID']);

			$objRisk = new RiskAssessment();
			$rsk_details = $objRisk->getControlHazardSummary($section_data['mainProcessID'],$section_data['processStepID']);

			$section_data['process_title'] = $process_data['reference'];
			$section_data['description'] = $process_data['description'];

			$section_data['hazard_summary'] = $rsk_details['hazardSummary'];
			$section_data['control_summary'] = $rsk_details['controlSummary'];
			$section_data['risk_rating'] = $rsk_details['riskRating1'];
			$section_data['risk_rating_color'] = $rsk_details['riskRatingColor1'];
			$section_data['standards'] = $process_metadata[0]['criticalControlPoint'];
		}

		$miscObj = new Misc();

		if ( $section_data['tab'] == 4 ) {
			$section_data['mse_element'] = $miscObj->get_mse_element($section_data['managementHazardID']);
		}

		if ( $section_data['tab'] == 5 ) {
			$section_data['hazard'] = $miscObj->get_hazard($section_data['managementHazardID']);
		}

		if ( $section_data['tab'] == 6 ) {

			$objProcessMaster 	= new ProcessFlowMaster();
			$process_data = $objProcessMaster->displayProcessFlowById($section_data['processID']);

			$section_data['process_title'] = $process_data['reference'];
			$section_data['description'] = $process_data['description'];

			$section_data['hazardClassification'] = $miscObj->get_main_hazard($section_data['hazardClassificationID']);
			$section_data['hazards'] = $miscObj->get_multiple_hazards($section_data['hazardsID']);

			$risk_color = $miscObj->get_risk_color($section_data['processID']);
			$section_data['risk_color'] = $risk_color['riskRatingColor1'];
			$section_data['risk_value'] = $risk_color['riskRating1'];
		}

		$email_data[0] = $section_data;


		return $email_data;

	}

	/***
	 ** This method is used to get
	 ** listing records for Export
	 **/
	public function getListingforExport() {

		$heading = array(array('refrence'=>'Reference #','bu'=>'Business Unit','who'=>'Who','When'=>'When','loc'=>'Location'));

		$orgObj			 = SetupGeneric::useModule('Organigram');
		$locObj			 = SetupGeneric::useModule('Locationgram');
		$participantObj	 = SetupGeneric::useModule('Participant');
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$this->setInspectionInfo(1,array('archive'=>$archive_session));
		$insp_records = $this->viewInspections();

		if ( count($insp_records) ) {
			$i=0;
			foreach ($insp_records as $value ) {

				$insp_id = $value['ID'];
				$orgObj->setItemInfo(array('id'=>$value['buID']));
				$bu_details = $orgObj->displayItemById();

				$locObj->setItemInfo(array('id'=>$value['locationID']));
				$location_data = "";
				$location = $locObj->getFUllLocation();

				$participant_id = $value['participantID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
				$result[$i]['ref'] = $value['reference'];
				$result[$i]['bu'] = $bu_details['buName'];
				$result[$i]['who'] = $participant_name;
				$result[$i]['when'] = format_date($value['whenDate']);
				$result[$i]['loc'] = str_replace(',','-',$location);

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
		//return $heading;
	}

	public function getActionMailData($action_id) {

		$sql = sprintf("SELECT inspectionID,step,subStep FROM %s.inspection_metadata WHERE actionID = %d",_DB_OBJ_FULL,$action_id);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$insp_metadata = $pStatement->fetch(PDO::FETCH_ASSOC);
		$inspection_id = $insp_metadata['inspectionID'];
		$step = 'Step '.$insp_metadata['step'];
		$sub_step = 'Substep '.$insp_metadata['subStep'];

		$sql2 = sprintf("SELECT buID,reference FROM %s.inspection WHERE ID = %d",_DB_OBJ_FULL,$inspection_id);
		$pStatement = $this->dbHand->prepare($sql2);
		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);

		$mail_data['bu_id']			= $result['buID'];
		$mail_data['reference']		= $result['reference'];
		$mail_data['step']			= $step;
		$mail_data['sub_step']		= $sub_step;

		return $mail_data;
	}
}

?>