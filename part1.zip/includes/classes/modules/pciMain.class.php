<?php
 /**
  $Id: ReviewMain.class.php,v 7.80 Thursday, February 03, 2011 3:13:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Review object used to manage operation related to review
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, September 13, 2010 5:30:32 PM>
  */

class ReviewMain
{

	/*
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $dbHand2;
	private $reviewObj;

	/*
	 * This property will hold the value of ID of review under process.
	 * @access private
	 */
	private $reviewID;

	/*
	 * This property will store participant ID of the auditor who is performing a review.
	 * @access private
	 */
	private $auditorID;

	/*
	 * This property will act as a container object for ReviewQuestion class.
	 * @access private
	 */
	private $reviewQuestionContainer;

	public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->dbHand2 					= DB::connect(_DB_TYPE);
		$this->auditorID 				= getLoggedInUserId();
		$this->buID 					= 0;
		$this->reviewType 				= 'MSR';
		$this->reviewID 				= Session::getSessionField('review_id');
		$this->reviewQuestionContainer 	= new ReviewQuestion();
		$this->reviewObj 				= SetupGeneric::useModule('MSR');
	}

	public function checkReviewFrequency() {

		$a = false;
		if ( $a ) {
			return true;
		} else {
			return false;
		}
	}

	private function getIsrSectionByQtr20110922($p_qtr=1) {

		$start_index = ($p_qtr-1)*2;

		if ( _DB_TYPE != 'mysql' ) {

			$sql = sprintf("SELECT TOP ".($start_index+2)." code
				FROM %s.msr_departments
				WHERE sID = 7
				ORDER BY ID ASC",_DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();

			$result = '';

			$f_index = 0;
			while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
				if ( $f_index < $start_index ) {
					$f_index++;
					continue;
				}

				$result[] = $rec['code'];
				$f_index++;
			}

		} else {

			$sql = sprintf("SELECT code
				FROM %s.msr_departments
				WHERE sID = 7
				ORDER BY ID ASC
				LIMIT $start_index,2",_DB_OBJ_FULL);

			$stmt = $this->dbHand->prepare($sql);
			$stmt->execute();

			$result = '';

			while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
				$result[] = $rec['code'];
			}
		}



		return $result;
	}

	private function getIsrSectionByQtr($p_qtr=1) {

		$objOption  = new Option();
		$result_qrtr_codes = $objOption->getOption('_SU_INTERNAL_AUDIT_MSR_QRTR'.$p_qtr);
		$result = explode(",",$result_qrtr_codes);

		$objOption = null;
		return $result;
	}

	private function getIsrQuestionsStow() {

		$sql = sprintf("SELECT ID
				FROM %s.review_questions
				WHERE isStowContractor = '1'
				ORDER BY ID ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$questions = '';

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$questionsmeta[] =$rec['ID'];
		}


$rec=$this->reviewObj->displayItems();
foreach($rec as $data){
	$questions[$data['display_order']] = $data['ID'];
}
ksort($questions);
$result=array_intersect($questions,$questionsmeta);

	$this->questionList = implode(",",$result);
		
		
		
	}

	public function getIsrQuestionsMse($buID) {
			
		$sql = sprintf("SELECT listID
				FROM %s.management_element_permissions
				WHERE buID = ".$buID." AND permission = 1
				",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
		$rec = $stmt->fetch(PDO::FETCH_ASSOC);
		//dump_array($rec);
		//exit;
		foreach($rec as $p_mseListId){
		 $sql = sprintf("SELECT * FROM %s.management_elements
					   WHERE memlListID = %d",_DB_OBJ_FULL,$p_mseListId['listID']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$questions = '';
		$vdata = array();

		$vdata[] = _DB_OBJ_FULL;

		$ins_raw = "INSERT INTO %s.review_questions_mse(question, score, recommendationOption, mseListID)
				VALUES ";

		$i = 0;
		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {

			$sqlItr = sprintf("SELECT * FROM %s.review_questions_mse
					WHERE question LIKE '%s'
					AND mseListID = %d",_DB_OBJ_FULL,$rec['subCategory'],$p_mseListId['listID']);

			$already_exists = false;

			$stmt_itr = $this->dbHand->prepare($sqlItr);
			$stmt_itr->execute();

			// Check the number of rows that match the SELECT statement
			$rec_itr = $stmt_itr->fetch(PDO::FETCH_ASSOC);

			if ( $rec_itr['ID'] ) {
				$already_exists = true;
			}

			if (!$already_exists) {

				if ($i) { $ins_raw .= ","; }

				$ins_raw .= "('%s', %d, '%s', %d)";

				$vdata[] = $rec['subCategory'];
				$vdata[] = 1;
				$vdata[] = $rec['pointsToReview'];
				$vdata[] = $p_mseListId;

				$i++;
			}
		}

		$ins = vsprintf($ins_raw,$vdata);

		$stmt_ins = $this->dbHand->prepare($ins);
		$stmt_ins->execute();

		// get questions for mse

		$sql = sprintf("SELECT *
				FROM %s.review_questions_mse
				WHERE mseListID = %d
				ORDER BY ID ASC",_DB_OBJ_FULL,$p_mseListId['listID']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$questions = '';

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$questions .= ",".$rec['ID'];
		}

		$this->questionList = ltrim($questions,',');

		
		
		}
		//echo $this->questionList;
		//exit;
		return $this->questionList;
		
	}

	private function getMsrQuestions() {
//altered to get revised quesion lists
/*
		$sql = sprintf("SELECT ID
				FROM %s.review_questions
				ORDER BY ID ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$questions = '';

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$questions .= ",".$rec['ID'];
		}
*/


$rec=$this->reviewObj->displayApprovedItems();
foreach($rec as $data){
	$questions[$data['display_order']] = $data['ID'];
}
ksort($questions);


		$this->questionList = implode(",",$questions);

	}

	private function getIsrQuestions($p_codes) {

		$str = implode("','",$p_codes);

		$sql = sprintf("SELECT questionID
				FROM %s.review_question_metadata
				WHERE standardID = 7
				AND SUBSTRING(code,1,1) IN ('$str')
				ORDER BY questionID ASC",_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$questions = '';

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {
			$questionsmeta[] =$rec['questionID'];
		}


$rec=$this->reviewObj->displayItems();
foreach($rec as $data){
	$questions[$data['display_order']] = $data['ID'];
}
ksort($questions);
$result=array_intersect($questions,$questionsmeta);

	$this->questionList = implode(",",$result);
	}

	private function isSimilarReviewDone() {

		$sql = sprintf("SELECT reviewID
				FROM %s.review_master
				WHERE buID = %d
				AND reviewType = '%s'
				ORDER BY reviewID DESC"
				,_DB_OBJ_FULL
				,$this->buID
				,$this->reviewType);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->buID);
		$stmt->bindParam(2,$this->reviewType,PDO::PARAM_STR,5);*/

		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		$count = count($result);

		if ($count) {
			return $result['reviewID'];
		} else {
			return 0;
		}

	}

	private function cloneReview($p_sourceReviewId,$p_destinationReviewId) {

		/* for extra protection */
		$p_sourceReviewId 		= (int) $p_sourceReviewId;
		$p_destinationReviewId 	= (int) $p_destinationReviewId;

		$sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = %d",_DB_OBJ_FULL,$p_sourceReviewId);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_sourceReviewId);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $resultSet ) {

			$ins = sprintf("INSERT INTO %s.review_answers (reviewID,questionID,answer,standardID,recommendation)
				VALUES (%d, %d, '%s', %d, '%s')"
				,_DB_OBJ_FULL
				,$p_destinationReviewId
				,$resultSet['questionID']
				,$resultSet['answer']
				,$resultSet['standardID']
				,$resultSet['recommendation']);

			$stmt_ins = $this->dbHand->prepare($ins);

			/*$stmt_ins->bindParam(1,$p_destinationReviewId);
			$stmt_ins->bindParam(2,$resultSet['questionID']);
			$stmt_ins->bindParam(3,$resultSet['answer']);
			$stmt_ins->bindParam(4,$resultSet['standardID']);
			$stmt_ins->bindParam(5,$resultSet['recommendation']);*/

			$stmt_ins->execute();
		} // end foreach
	}

	/**
	* Format a mysql formatted date to d/m/Y format.
	*
	* This function convert date to d/m/Y using strtotime function if the year is more than 1970
	* else it uses explode function to format the date.
	*
	* @param date $date Stores date to convert.
	* @access public
	*/
	public function startReview($p_reviewType,$p_businessId,$p_mseListId=0) {

		$this->questionList = '';
		$this->buID 		= $p_businessId;

		if ( $p_reviewType == 'MSR' ) {

			$this->getMsrQuestions();

		
		

		} else if ( $p_reviewType == 'ISR_STOW' ) {

			$this->getIsrQuestionsStow();
			$this->reviewType = 'ISR';

		} else if ( $p_reviewType == 'ISR_MSE' ) {

			$this->getIsrQuestionsMse($this->buID);
			$this->reviewType = 'MSE';
		}
		else
		{
		
			$qtr=ceil(date("n")/3);
			$codes = $this->getIsrSectionByQtr($qtr);
			

			$this->getIsrQuestions($codes);
			$this->reviewType = 'ISR';
			}
		/* Check if similar review is done or not
		Need some testing
		*/

		$similar_review_id = (int) $this->isSimilarReviewDone();

		if ( $similar_review_id ) {

			if ( _DB_TYPE != 'mysql' ) {
				$default_datetime = '1900-01-01 00:00:00';
			} else {
				$default_datetime = '0000-00-00 00:00:00';
			}

			$sql = sprintf("INSERT INTO %s.review_master (auditorID,buID,startTime,endTime,reviewType,is_complete,current_question,questions)
				VALUES (%d, %d, ".customCurrentDate().", '%s', '%s','0','1','%s')"
				,_DB_OBJ_FULL
				,$this->auditorID
				,$this->buID
				,$default_datetime
				,$this->reviewType
				,$this->questionList);


			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,$this->auditorID);
			$stmt->bindParam(2,$this->buID);
			$stmt->bindParam(3,$this->reviewType);
			$stmt->bindParam(4,$this->questionList);*/

			if ( $stmt->execute() ) {
				$destination_review_id = customLastInsertId(& $this->dbHand,'review_master','reviewID');
				
				
				
				
		//exit;
				// add review tracker entry
				$this->punchBusinessUnitReview();

				$this->cloneReview($similar_review_id,$destination_review_id);

				return $destination_review_id;
			}
		} else {

			if ( _DB_TYPE != 'mysql' ) {
				$default_datetime = '1900-01-01 00:00:00';
			} else {
				$default_datetime = '0000-00-00 00:00:00';
			}

			$sql = sprintf("INSERT INTO %s.review_master (auditorID,buID,startTime,endTime,reviewType,is_complete,current_question,questions)
				VALUES (%d, %d,".customCurrentDate().",'%s', '%s','0','1','%s')"
				,_DB_OBJ_FULL
				,$this->auditorID
				,$this->buID
				,$default_datetime
				,$this->reviewType
				,$this->questionList);


			$stmt = $this->dbHand->prepare($sql);

			if ( !$stmt->execute() ) {
				throw new ErrorException("Unable to start a review",11);
			} else {
				// add review tracker entry
				$last_insert_id = customLastInsertId(& $this->dbHand,'review_master','reviewID');
				
				$o_id = customLastInsertId(& $this->dbHand,'organigramDetail','ID');
				echo $sql = sprintf("UPDATE %s.organigramDetail
				SET rID = ".$last_insert_id."
				
				WHERE ID = %d",_DB_OBJ_FULL,$o_id);


		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1,$this->reviewID);
		$stmt->execute();

				if ( $this->reviewType != 'MSE' ) {
					$this->punchBusinessUnitReview();
				}

				return $last_insert_id;
			}
		}
	}

	private function punchBusinessUnitReview() {

		$orgObj = SetupGeneric::useModule('Organigram');
		$orgObj->setItemInfo(array('id'=>$this->buID));

		$business_unit_info 	= $orgObj->displayItemByIdForMSR();
		$currentCalendarQuarter = currentCalendarQuarter();

		if ( $this->reviewType == 'MSR' ) {
			$reviewType = $this->reviewType;
			$currentCalendarQuarter = $business_unit_info['optionA'];
		} else {
			$optionA = $business_unit_info['optionA'];
			$optionB = $business_unit_info['optionB'];

			if ( $optionA && !$optionB ) {
				$reviewType = $this->reviewType.$currentCalendarQuarter;
			} else if ( !$optionA && $optionB ) {
				$reviewType = $this->reviewType.'STOW';
			}
		}

		$orgObj = null;

		$sql = sprintf("INSERT INTO %s.review_periodicity_tracker (businessUnit,whenDate,reviewType,quarter)
				VALUES (%d, %s,'%s', %d)"
				,_DB_OBJ_FULL
				,$this->buID
				,customCurrentDate()
				,$reviewType
				,$currentCalendarQuarter);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->buID);
		$stmt->bindParam(2,$reviewType);
		$stmt->bindParam(3,$currentCalendarQuarter);*/

		$stmt->execute();
	}

	public function isReviewDone($p_reviewType,$p_businessUnit) {
		//$p_businessUnit = 1211;
		/*
		businessUnit when 	reviewType 	quarter quarter number
		*/
		$current_year = date('Y');
		$current_qrtr = currentCalendarQuarter();

		//echo $p_reviewType.",".$p_businessUnit."<br/>";

		if ( $p_reviewType == 'MSE' ) {

			$is_complete = 0;

			$sql_pre = sprintf("SELECT endTime,reviewID,is_complete FROM %s.review_master
							   WHERE buID = %d ORDER BY reviewID DESC",_DB_OBJ_FULL,$p_businessUnit);

			$stmt_pre = $this->dbHand->prepare($sql_pre);
			$stmt_pre->execute();

			$result_pre = $stmt_pre->fetchAll(PDO::FETCH_ASSOC);

			if ( count($result_pre) ) {
				$is_complete = 1;
				return true;
			}

			return false;
		}

		if ( $p_reviewType == 'MSR' ) {

			$is_complete = 0;

			$sql_pre = sprintf("SELECT startTime,endTime,reviewID,is_complete FROM %s.review_master
							   WHERE buID = %d ORDER BY reviewID DESC",_DB_OBJ_FULL,$p_businessUnit);

			$stmt_pre = $this->dbHand->prepare($sql_pre);
			$stmt_pre->execute();

			$result_pre = $stmt_pre->fetch(PDO::FETCH_ASSOC);
			$start_date = substr($result_pre['startTime'],0,10);

			$sql = sprintf("SELECT msr,optionA FROM %s.business_units WHERE buID = %d",_DB_OBJ_FULL,$p_businessUnit);
			$stmt = $this->dbHand2->prepare($sql);
			$stmt->execute();

			$result = $stmt->fetch(PDO::FETCH_ASSOC);

			$miscObj = new Misc();
			$new_start_date = $miscObj->makeCustomDate($start_date,$result['optionA'],'MONTH');
			$current_date 	= $miscObj->getCurDate();
			$miscObj = null;

			//echo $new_start_date." - ".$current_date;

			if ( $result_pre['reviewID'] && $result_pre['is_complete'] && $new_start_date <= $current_date ) {
				$is_complete = 1;
			} else if ( $result_pre['reviewID'] && !$result_pre['is_complete'] ) {
				$is_complete = 0;
			} else if ( !$result_pre['reviewID'] && $new_start_date <= $current_date ) {
				$is_complete = 1;
			}

			if ( !$is_complete ) {
				return true;
			}

			return false;
		}

		/*if ( $p_reviewType == 'MSR' || $p_reviewType == 'MSE' ) {

			$is_complete = 0;

			$sql_pre = sprintf("SELECT endTime,reviewID,is_complete FROM %s.review_master
							   WHERE buID = %d ORDER BY reviewID DESC",_DB_OBJ_FULL,$p_businessUnit);

			$stmt_pre = $this->dbHand->prepare($sql_pre);
			$stmt_pre->execute();

			$result_pre = $stmt_pre->fetch(PDO::FETCH_ASSOC);

			if ( $result_pre['reviewID'] && $result_pre['is_complete'] ) {
				$is_complete = 1;
			} else if ( $result_pre['reviewID'] && !$result_pre['is_complete'] ) {
				$is_complete = 0;
			} else if ( !$result_pre['reviewID'] ) {
				$is_complete = 1;
			}

			if ( $p_reviewType == 'MSE' ) {
				return false;
			}

			if ( !$is_complete ) {
				return true;
			}

			return false;
		}*/

		if ( $p_reviewType == 'IA' ) {

			$sql = sprintf("SELECT * FROM %s.review_master
					WHERE buID = %d
					AND reviewType = 'ISR'
					AND is_complete = 0"
					,_DB_OBJ_FULL
					,$p_businessUnit
					);

			$stmt = $this->dbHand->prepare($sql);

			$stmt->execute();

			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

			if ( count($result) ) {
				return true;
			} else {
				return false;
			}
		} else if ( $p_reviewType == 'MSR' ) {

			if ( _DB_TYPE != 'mysql' ) {

				$sql = sprintf("SELECT TOP 1 * FROM %s.review_periodicity_tracker
					WHERE businessUnit = %d
					ORDER BY whenDate DESC"
					,_DB_OBJ_FULL
					,$p_businessUnit
					,$current_year);
			} else {

				$sql = sprintf("SELECT * FROM %s.review_periodicity_tracker
					WHERE businessUnit = %d
					ORDER BY whenDate DESC
					LIMIT 1"
					,_DB_OBJ_FULL
					,$p_businessUnit
					,$current_year);
			}

			$stmt = $this->dbHand->prepare($sql);

			/*$stmt->bindParam(1,$p_businessUnit);
			$stmt->bindParam(2,$current_year);*/

			$stmt->execute();
			$a = $stmt->errorInfo();

			$result = $stmt->fetch(PDO::FETCH_ASSOC);

			$last_when = $result['whenDate'];
			$frequency = $result['quarter'];

			// to be deleted
			//$frequency = $t_fre;

			$miscObj = new Misc();

			$next_date 		= $miscObj->makeCustomDate($last_when,$frequency,'MONTH');
			$current_date 	= $miscObj->getCurDate();

			//echo " $next_date <= $current_date <br/>";

			if ( $next_date <= $current_date ) {
				return false;
			} else {
				return true;
			}
		} /*else if ( $p_reviewType == 'MSE' ) {

			if ( !$is_complete ) {
				return true;
			} else {
				return false;
			}
		}*/
	}
	
	

	public function continueReview() {

		$sql = sprintf("SELECT * FROM %s.review_master
				WHERE reviewID = %d",_DB_OBJ_FULL,$this->reviewID);


		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$this->reviewID);

		$stmt->execute();

		$rec = $stmt->fetch(PDO::FETCH_ASSOC);

		$current_question 			= $rec['current_question'];
		$questions 					= $rec['questions'];
		$questions_arr				= explode(',',$questions);
		$questions_arr_flipped 		= array_flip($questions_arr);
		$current_question			= $questions_arr_flipped[$current_question]+1;

		return array('current_question_index'=>$current_question,
					 'current_question_real_identifier'=>$rec['current_question']);
	}

	public function saveReview($p_questionIdentifier) {

		$sql = sprintf("UPDATE %s.review_master
				SET is_complete = '0',
				current_question = %d
				WHERE reviewID = %d",_DB_OBJ_FULL,$p_questionIdentifier,$this->reviewID);


		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$p_questionIdentifier);
		$stmt->bindParam(2,$this->reviewID);*/
		$stmt->execute();
	}

	public function finishReview() {

		$sql = sprintf("UPDATE %s.review_master
				SET is_complete = '1',
				endTime = ".customCurrentDate()."
				WHERE reviewID = %d",_DB_OBJ_FULL,$this->reviewID);


		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1,$this->reviewID);
		$stmt->execute();

		/*$sql_sec = sprintf("UPDATE %s.review_periodicity_tracker
				SET whenDate = ".customCurrentDate()."
				WHERE reviewID = %d",_DB_OBJ_FULL,$this->reviewID);


		$stmt_sec = $this->dbHand->prepare($sql_sec);

		//$stmt->bindParam(1,$this->reviewID);
		$stmt_sec->execute();*/

	}

	public function finishReviewOutside($p_review_id) {

		$sql = sprintf("UPDATE %s.review_master
				SET is_complete = '1',
				endTime = ".customCurrentDate()."
				WHERE reviewID = %d",_DB_OBJ_FULL,$p_review_id);


		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_review_id);
		$stmt->execute();

	}

	public function deleteReview($p_review_id) {

		$sql = sprintf("DELETE FROM %s.review_answers
				WHERE reviewID = %d",_DB_OBJ_FULL,$p_review_id);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_review_id);

		$sql_sec = sprintf("DELETE FROM %s.review_master
					WHERE reviewID = %d",_DB_OBJ_FULL,$p_review_id);

		$stmt_sec = $this->dbHand->prepare($sql_sec);

		$stmt->execute();
		$stmt_sec->execute();
	}

	public function archiveReview($p_review_id,$p_archive_val) {

	 $sql = sprintf("UPDATE %s.review_master SET archive = '%s' WHERE reviewID = %d",_DB_OBJ_FULL,$p_archive_val,$p_review_id);

	 $stmt = $this->dbHand->prepare($sql);
	 $stmt->execute();
	}

	public function listOpenReview($p_archive_val) {

		$sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '0' AND M.archive = '%s' AND reviewType = 'MSR'
				ORDER BY M.reviewID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_archive_val); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
		public function listOpenReview1($p_archive_val) {

		$sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '0' AND M.archive = '%s' AND reviewType != 'MSR'
				ORDER BY M.reviewID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_archive_val); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function listOpenSoa($p_archive_val=1) {

	 	 $sql = sprintf("SELECT * FROM %s.soaReview WHERE archived = %s AND (complete IS NULL OR complete != 1) ORDER BY ID DESC",_DB_OBJ_FULL,$p_archive_val); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function listOpenPci($p_archive_val=1) {

	 	 $sql = sprintf("SELECT * FROM %s.pciReview WHERE archived = %s AND (complete IS NULL OR complete != 1) ORDER BY ID DESC",_DB_OBJ_FULL,$p_archive_val); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function listClosedSoa($p_archive_val=0) {

		$sql = sprintf("SELECT * FROM %s.soaReview WHERE complete = 1 AND archived = %s ",_DB_OBJ_FULL,$p_archive_val); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function listClosedPci($p_archive_val=0) {

		$sql = sprintf("SELECT * FROM %s.pciReview WHERE complete = 1 AND archived = %s ",_DB_OBJ_FULL,$p_archive_val); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	public function listClosedReview1() {

		$sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '1' AND  reviewType != 'MSR'
				ORDER BY M.reviewID,M.endTime DESC",_DB_OBJ_FULL,_DB_OBJ_FULL); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = array();

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {

			$rec['attempted_questions'] = $this->reviewQuestionContainer->getAttemptedQuestionStats($rec['reviewID']);
			$rec['total_questions'] 	= count(explode(',',$rec['questions']));

			$result[] = $rec;
		}

		return $result;
	}

	public function listClosedReview() {

		$sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
				INNER JOIN %s.business_units B
				ON M.buID = B.buID
				WHERE M.is_complete = '1' AND  reviewType = 'MSR'
				ORDER BY M.reviewID,M.endTime DESC",_DB_OBJ_FULL,_DB_OBJ_FULL); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		$result = array();

		while ( $rec = $stmt->fetch(PDO::FETCH_ASSOC) ) {

			$rec['attempted_questions'] = $this->reviewQuestionContainer->getAttemptedQuestionStats($rec['reviewID']);
			$rec['total_questions'] 	= count(explode(',',$rec['questions']));

			$result[] = $rec;
		}

		return $result;
	}

	public function downloadDocument($p_doc_id) {

		$sql = sprintf("SELECT * FROM %s.question_docs
				WHERE ID = %d",_DB_OBJ_FULL,$p_doc_id);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_doc_id);
		$stmt->execute();

		$rec = $stmt->fetch(PDO::FETCH_ASSOC);


		$file = _PATH_PRIVATE_FILES.$rec['filename'];
		$file_arr = explode('.',basename($rec['filename']));

		$download_file_name = str_replace(' ','_',basename($rec['displayName']));
		$download_file_name_ext = $download_file_name.'.'.$file_arr[count($file_arr)-1];

		if ( !$file ) {
				// File doesn't exist, output error
				die('file not found');
		} else {
				// Set headers
				header('Content-type: application/download');
				header('Content-Description: File Transfer');
				header('Content-Disposition: attachment; filename="'.$download_file_name_ext.'" ');
				header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
				header('Content-Transfer-Encoding: binary');

				// Read the file from disk
				readfile($file);
		}

		$updObj = null;
    }

	public function getReviewInfo($p_reviewID) {

		$sql = sprintf("SELECT M.*,B.buName FROM %s.review_master M
					   INNER JOIN %s.business_units B
					   ON M.buID = B.buID
				WHERE M.reviewID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$p_reviewID);

		$stmt = $this->dbHand->prepare($sql);
		//$stmt->bindParam(1,$p_doc_id);
		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}
	
	public function getListingforExport() {

		  $type = $_GET['type'];

		if ( $type  =='full') {

			return $this->getEquipementExportDataFull();

		} else {

			return $this->getEquipementExportData();
		}
	}
	
	public function getEquipementExportDataFull() {

		$reviews = $_GET['reviews'];

		if ( $reviews == 'open' ) {

			return $this->getOpenReviewsExportData1();

		} else if ( $reviews == 'closed' ) {

			return $this->getClosedReviewsExportData1();
		}
		return $this->getReviewsExportData1();
	}

	public function getEquipementExportData() {

		$reviews = $_GET['reviews'];

		if ( $reviews == 'open' ) {

			return $this->getOpenReviewsExportData();

		} else if ( $reviews == 'closed' ) {

			return $this->getClosedReviewsExportData();
		}
		return $this->getReviewsExportData();
	}

	public function listCSVReview($p_archive_val) {

		$sql = sprintf("SELECT R.ID as cid, * ,R.reviewDate as reviewDate FROM %s.contract_review R LEFT JOIN %s.contract C ON R.contractID = C.ID LEFT JOIN %s.participant_database P ON R.reviewer = P.participantID ".$where."  ORDER BY cid desc",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL); // startTime

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	
	public function getReviewsExportData1() {

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$openReview 	= $this->listCSVReview($archive_session);
		//dump_array($openReview);
		//exit;
		$heading = array(array('Contract Ref', 'Rev Type', 'Title', 'Qtr', 'Reviewed By', 'Due Date','Complete Date','Next Review Date','Amount Paid in Current Financial Quarter','Contract under Review (Ref)','Contract under Review (Title)'));

		$result = array();
		$i = 0;
		if ( count($openReview) ) {

			foreach ( $openReview as $value ) {
			
			if($value['archive'] == '0' || $value['archive'] == 'NULL'){
			$refValue = $value['subReference']>0 ? $value['reference'].".".$value['subReference'] : $value['reference'];
				
				if ($value['f1f2']==2)
				$f1f2Str="Detailed";
				else
				$f1f2Str="Standard";
				
				

				$result[$i][]			= $refValue;
				$result[$i][]			= $f1f2Str;
				$result[$i][]			= $value['contractName'];
				$result[$i][]			= $value['quarterCovered']."'".$value['yearCovered'];
				$result[$i][]			= $value['forename'] .' '. $value['surname'];
				$result[$i][]			= $value['reviewEndDate'] ? format_date($value['reviewEndDate']) : '   ';
				$result[$i][]			= $value['reviewCompleteDate'] ? format_date($value['reviewCompleteDate']) : '   ';
			

				$quarterCovered= 5;
				$nowMonth = intval(date('m'));
				if ($nowMonth >= 1 && $nowMonth <= 3) $quarterCovered = 1;
				else if ($nowMonth >= 4 && $nowMonth <= 6) $quarterCovered = 2;
				else if ($nowMonth >= 7 && $nowMonth <= 9) $quarterCovered = 3;
				else if ($nowMonth >= 10 && $nowMonth <= 12) $quarterCovered = 4;

				$quarterCovered ++;

				if($value['f1f2']=='2')
				{
					$quarterCovered = "4";
	
				}


				$sql = sprintf("SELECT * FROM %s.contract_review_date WHERE quarter = ".$quarterCovered." ORDER BY quarter",_DB_OBJ_FULL);
				$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();
				$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



				if($value['f1f2']=='2')
				{
					$Year = $resultSet['year']+1;
				}
				else
				{
					$Year = $resultSet['year'];
				}
				$reviewDate =$resultSet['month']."/".$resultSet['day']."/".$Year;



				$result[$i][]			= $reviewDate;
					$result[$i][]			= $value['qtr_spend'];
				$result[$i][]			= $value['reference'];
				$result[$i][]			= $value['contractName'];
			

				$i++;
			}
			
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}
	public function getReviewsExportData() {

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$openReview 	= $this->listCSVReview($archive_session);

		$heading = array(array('Contract Ref', 'Rev Type', 'Title', 'Qtr', 'Reviewed By', 'Due Date','Complete Date','Next Review Date'));

		$result = array();
		$i = 0;
		if ( count($openReview) ) {

			foreach ( $openReview as $value ) {
			$refValue = $value['subReference']>0 ? $value['reference'].".".$value['subReference'] : $value['reference'];
				
				if ($value['f1f2']==2)
				$f1f2Str="Detailed";
				else
				$f1f2Str="Standard";
				
				

				$result[$i][]			= $refValue;
				$result[$i][]			= $f1f2Str;
				$result[$i][]			= $value['contractName'];
				$result[$i][]			= $value['quarterCovered']."'".$value['yearCovered'];
				$result[$i][]			= $value['forename'] .' '. $value['surname'];
				$result[$i][]			= $value['reviewEndDate'] ? format_date($value['reviewEndDate']) : '   ';
				$result[$i][]			= $value['reviewCompleteDate'] ? format_date($value['reviewCompleteDate']) : '   ';
				

				$quarterCovered= 5;
				$nowMonth = intval(date('m'));
				if ($nowMonth >= 1 && $nowMonth <= 3) $quarterCovered = 1;
				else if ($nowMonth >= 4 && $nowMonth <= 6) $quarterCovered = 2;
				else if ($nowMonth >= 7 && $nowMonth <= 9) $quarterCovered = 3;
				else if ($nowMonth >= 10 && $nowMonth <= 12) $quarterCovered = 4;

				$quarterCovered ++;

				if($value['f1f2']=='2')
				{
					$quarterCovered = "4";
	
				}


				$sql = sprintf("SELECT * FROM %s.contract_review_date WHERE quarter = ".$quarterCovered." ORDER BY quarter",_DB_OBJ_FULL);
				$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();
				$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);



				if($value['f1f2']=='2')
				{
					$Year = $resultSet['year']+1;
				}
				else
				{
					$Year = $resultSet['year'];
				}
				$reviewDate =$resultSet['month']."/".$resultSet['day']."/".$Year;



				$result[$i][]			= $reviewDate;
			

				$i++;
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}
	public function getOpenReviewsExportData() {

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$openReview 	= $this->listOpenReview($archive_session);

		$heading = array(array('Business Unit', 'Start Date/time', 'Current Question'));

		$result = array();

		if ( count($openReview) ) {

			foreach ( $openReview as $element ) {

				$review_type = rtrim($element['reviewType']);
				$business_unit = $element['buName'].' ('.$review_type.')';
				$start_date = format_datetime($element['startTime']);

				$current_question 			= $element['current_question'];
				$questions 					= $element['questions'];
				$questions_arr				= explode(',',$questions);
				$questions_arr_flipped 		= array_flip($questions_arr);
				$current_question			= $questions_arr_flipped[$current_question]+1;

				$result[] = array($business_unit, $start_date, $current_question);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}

	public function getOpenReviewsExportData1() {

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$openReview 	= $this->listOpenReview($archive_session);
		//dump_array($openReview);
		//exit;
		$heading = array(array('Business Unit', 'Start Date/time', 'Current Question'));

		$result = array();

		if ( count($openReview) ) {

			foreach ( $openReview as $element ) {

				$review_type = rtrim($element['reviewType']);
				$business_unit = $element['buName'].' ('.$review_type.')';
				$start_date = format_datetime($element['startTime']);

				$current_question 			= $element['current_question'];
				$questions 					= $element['questions'];
				$questions_arr				= explode(',',$questions);
				$questions_arr_flipped 		= array_flip($questions_arr);
				$current_question			= $questions_arr_flipped[$current_question]+1;

				$result[] = array($business_unit, $start_date, $current_question);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}

	public function getClosedReviewsExportData() {

		$participantObj 	= SetupGeneric::useModule('Participant');

		$closedReview 	= $this->listClosedReview();

		$heading = array(array('Auditor', 'Business Unit', 'Start date/time', 'End date/time', 'Questions'));

		if ( count($closedReview) ) {

			foreach ( $closedReview as $element ) {

				$participantObj->setItemInfo(array('id'=>$element['auditorID']));
				$participant_details	= $participantObj->displayItemById();

				$auditor_name = ucwords($participant_details['forename'].' '.$participant_details['surname']);
				$business_unit = $element['buName'].' ('.$element['reviewType'].')';
				$start_date = format_datetime($element['startTime']);
				$end_date = format_datetime($element['endTime']);
				$questions = $element['attempted_questions'].'/'.$element['total_questions'];

				$result[] = array($auditor_name, $business_unit, $start_date, $end_date, $questions);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}
	public function getClosedReviewsExportData1() {

		$participantObj 	= SetupGeneric::useModule('Participant');

		$closedReview 	= $this->listClosedReview();
		//dump_array($closedReview);
		//exit;
		$heading = array(array('Auditor', 'Business Unit', 'Start date/time', 'End date/time', 'Questions'));

		if ( count($closedReview) ) {

			foreach ( $closedReview as $element ) {

				$participantObj->setItemInfo(array('id'=>$element['auditorID']));
				$participant_details	= $participantObj->displayItemById();

				$auditor_name = ucwords($participant_details['forename'].' '.$participant_details['surname']);
				$business_unit = $element['buName'].' ('.$element['reviewType'].')';
				$start_date = format_datetime($element['startTime']);
				$end_date = format_datetime($element['endTime']);
				$questions = $element['attempted_questions'].'/'.$element['total_questions'];

				$result[] = array($auditor_name, $business_unit, $start_date, $end_date, $questions);
			}
		}

		$new_result = array_merge($heading,$result);
		return $new_result;
	}
}
?>
