<?php
 /**
  $Id: ProcessObjectLozenge.class.php,v 3.37 Friday, January 28, 2011 7:04:56 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 3:56:29 PM>
  */

require_once "ProcessObjectInterface.int.php";

class ProcessLozenge implements ProcessObjectInterface
{
	public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info) {

//		$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
$blockCord=$p_block;
//		$path_no 	= $blockCord['path_no'];
//		$path_colour = $classObj->getPathcolour($path_no);
//		$path_colour2 = $classObj->getPathcolour($p_alt_path);
		//$p_lozenge = 'STOP';
		switch ($p_lozenge) {

			case 'START': 	//$x = $classObj->argLineThickness() + $classObj->argBusinessUnitColumnWidth() - $p_width/2;
							//$y = $classObj->argLineThickness() + $classObj->argObjectGap()*2;

							//$x1 = $x;
							//$y1 = $y + $blockCord['y'];
							$x1 = $blockCord['x'];
							$y1 = $blockCord['y'];
							
							$x2 = $x1 + $classObj->argBlockWidth();
							break;

			case 'STOP': 	//$x = ($classObj->argBlockWidth() + $p_width)/2 + $classObj->argBlockWidth()/2;
							//$y = $classObj->argLineThickness() + $classObj->argObjectGap()*2;

							//$x1 = $x + $blockCord['x'] + 20;
							//$y1 = $y + $blockCord['y'];

							$x1 = $blockCord['x']+10;
							$y1 = $blockCord['y']+15;
							
							$x2 = $x1 + $classObj->argBlockWidth()/2;


							break;
		}



		
if ( $classObj->argOutputType() == 'H' )  {
		
			if($p_lozenge=='STOP')
			{
			imagefilledellipse($classObj->getResource(), $x1+80, $y1+54,$classObj->argObjectWidth()-80,$classObj->argObjectHeight()-20 ,$classObj->getColour('lozenge_colour'));
			imageellipse($classObj->getResource(), $x1+80, $y1+54, $classObj->argObjectWidth()-80 ,$classObj->argObjectHeight()-20 ,$classObj->getColour('text_colour'));
	
			imagestring($classObj->getResource(), 4, $x1+68, $y1+48,$p_lozenge,$this->colours['text_colour']);
	
			imagesetthickness($classObj->getResource(), 1);
			}
			else
			{
			imagefilledellipse($classObj->getResource(), $x1+50, $y1,$classObj->argObjectWidth()-100,$classObj->argObjectHeight()-40 ,$classObj->getColour('lozenge_colour'));
			imageellipse($classObj->getResource(), $x1+50, $y1, $classObj->argObjectWidth()-100 ,$classObj->argObjectHeight()-40 ,$classObj->getColour('text_colour'));
	
			imagestring($classObj->getResource(), 4, $x1+25, $y1-7,$p_lozenge,$this->colours['text_colour']);
	
			imagesetthickness($classObj->getResource(), 1);
			}
		}
		else
		{
		
		imagefilledellipse($classObj->getResource(), $x1+20, $y1,$classObj->argObjectWidth(),$classObj->argObjectHeight() ,$classObj->getColour('lozenge_colour'));
		imageellipse($classObj->getResource(), $x1+20, $y1, $classObj->argObjectWidth() ,$classObj->argObjectHeight() ,$classObj->getColour('text_colour'));

		imagestring($classObj->getResource(), 4, $x1+5, $y1-7,$p_lozenge,$this->colours['text_colour']);

		imagesetthickness($classObj->getResource(), 1);
		}
	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$step_info) {

//		$blockCord 	= ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$blockCord 	= $p_block;
		$path_no 	= $blockCord['path_no'];
		$path_colour = $classObj->getPathcolour($path_no);
		$path_colour2 = $classObj->getPathcolour($p_alt_path);
		//$p_lozenge = 'STOP';
		$shade_offset = $classObj->getShadeOffset();

		switch ($p_lozenge) {

			case 'START': 	

							$x1 = $blockCord['x'];
							$y1 = $blockCord['y'];

							$x1_s = $x1 + $shade_offset;
							$y1_s = $y1 + $shade_offset;

							$x1 = $x1 + $shade_offset - 2;
							$y1 = $y1 + $shade_offset - 2;


							$x2 = $x1 + $classObj->argBlockWidth();
							
							
							
							
							break;

			case 'STOP': 	
							$x1 = $blockCord['x']+10;
							$y1 = $blockCord['y']+15;

							$x1_s = $x1 + $shade_offset;
							$y1_s = $y1 + $shade_offset;

							$x1 = $x1 + $shade_offset - 2;
							$y1 = $y1 + $shade_offset - 2;

							$x2 = $x1 + $classObj->argBlockWidth()/2;

							break;
		}

		imagefilledellipse($classObj->getResource(), $x1_s+20, $y1_s,$classObj->argObjectWidth() ,$classObj->argObjectHeight() ,$classObj->getColour('shadow2_colour'));
		imagefilledellipse($classObj->getResource(), $x1+20, $y1,$classObj->argObjectWidth() ,$classObj->argObjectHeight() ,$classObj->getColour('shadow_colour'));
	}
}
?>