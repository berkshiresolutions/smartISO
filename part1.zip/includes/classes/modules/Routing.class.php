<?php

class Routing {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Constructor for initializing Vehicle object
     * @access public
     */
    public function __construct() {
        $this->dbHand = DB::connect(_DB_TYPE);
    }

    public function getData() {

        $sql = sprintf("SELECT E.ID,P1.forename+' ' +P1.surname as sender ,P2.forename+' ' +P2.surname as receiver  FROM %s.email_router E inner join %s.participant_database P1 on E.whosends=P1.participantID inner join %s.participant_database P2 on E.whoreceives=P2.participantID", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function getDataA() {

        $sql = sprintf("SELECT * FROM %s.regions order by country", _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $res)
            $data[$res["ID"]] = $res["Country"];

        return $data;
    }

    public function getAUData() {

        $sql = sprintf("SELECT M.participantID,D.forename + ' ' + D.surname as name FROM %s.participant_database D INNER JOIN %s.participant_meta_data M ON D.participantID = M.participantID WHERE isnull(archive,0)=0 and assignRole=1 order by name", _DB_OBJ_FULL,  _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


        if (count($result)) {
            foreach($result as $row){
                
                $ret[$row['participantID']]=$row['name'];
            }
            return $ret;
        } else {
            return array();
        }
    }
    
        public function addRouting($who,$approver) {

        $sql = sprintf("INSERT into %s.email_router (whosends,whoreceives) values (%d,%d)", _DB_OBJ_FULL,$who,$approver);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    }
    public function getRouterData() {

        $sql = sprintf("SELECT M.participantID,D.forename + ' ' + D.surname as name FROM %s.participant_database D INNER JOIN %s.participant_meta_data M ON D.participantID = M.participantID WHERE isnull(archive,0)=0 and assignRole=1 and M.participantID NOT IN (SELECT whosends from %s.email_router) order by name", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


        if (count($result)) {
            foreach($result as $row){
                
                $ret[$row['participantID']]=$row['name'];
            }
            return $ret;
        } else {
            return array();
        }
    }
    
    
        public function createRouterView() {

   $sql = sprintf("select distinct whoreceives,p.forename+' '+surname as name from %s.email_router R inner join %s.participant_database P on R.whoreceives=P.participantID where not whoreceives  in (select whosends from %s.email_router)", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$html="<DIV style='width:400px' id='router'><UL >";
foreach($result as $row){
     $html.="<LI class='expanded'>".$row["name"];
     $html.=$this->getChildren($row["whoreceives"]);
      $html.="</LI>";    
}
 $html.="</UL></DIV>";       
return $html;

    }
  
    
          public function getChildren($id) {

    $sql = sprintf("select R.*,P.forename+' '+P.surname as name  from %s.email_router  R inner join %s.participant_database P on R.whosends=P.participantID  where whoreceives=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,$id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if(count($result)>0){
$child="<UL>";
foreach($result as $row){
     $child.="<LI class='expanded'>".$row["name"];
     $child.=$this->getChildren($row["whosends"]);
      $child.="</LI>";    
}
 $child.="</UL>";  
        }
     
return $child;

    }

             public function getEmailer($id){
        $sql = sprintf("select P.* from %s.email_router  R inner join %s.participant_database P on R.whoreceives=P.participantID  where whosends=%d", _DB_OBJ_FULL, _DB_OBJ_FULL,$id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;

    }
    
            public function getRoutes($who) {

     $sql = sprintf("select  whosends from %s.email_router where whoreceives in (%s)", _DB_OBJ_FULL,$who);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach($result as $row)
       $arr1[]=$row["whosends"];     
 
        return $arr1;
    }
    
    public function deleteRecord($id){
        $sql = sprintf("delete from %s.email_router where ID=%d", _DB_OBJ_FULL,$id);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

    }
    
        public function getRouterTemplate($str) {

            $str.="%";
        $sql = sprintf("SELECT D.participantID,D.forename + ' ' + D.surname as name FROM %s.participant_database D INNER JOIN %s.email_router R ON D.participantID = R.whosends WHERE isnull(D.archive,0)=0  AND forename LIKE '%s' order by name", _DB_OBJ_FULL, _DB_OBJ_FULL, $str);
        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


        if (count($result)) {
            foreach($result as $row){
                
                $ret[$row['participantID']]=$row['name'];
            }
            return $ret;
        } else {
            return array();
        }
    }
}

?>
