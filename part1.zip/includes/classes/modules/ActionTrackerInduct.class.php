<?php

// required for action tracker compatibility through abstract class
require_once "ActionTracker.abs.php";

// required for induct specific handling of data
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/smart_induct/inductData.class.php';

class ActionTrackerInduct extends AbstractActionTracker
{

	public function getPendingMeActions() {
		$iData = new inductData();
		
		$processFlowsData = array();
		$processRiskData = array();
		$documentData = array();
		$courseDataAck = array();
		$courseDataCom = array();
		
		$processFlowData = $iData->getPFData(false,true);
		$processRiskData = $iData->getPRData(false,true);
		$documentData = $iData->getDocData(false,true);
		$courseDataAck = $iData->getCourseAckData(false,true);
		$courseDataCom = $iData->getCourseComData(false,true);

		/*
		echo "process flows";
		var_dump($processFlowData);
		echo "\n\n";
		
		echo "process risks";
		var_dump($processRiskData);
		echo "\n\n";
		
		echo "documents";
		var_dump($documentData);
		echo "\n\n";
		
		echo "courses";
		var_dump($courseData);
		echo "\n\n";
		*/
		return array_merge(
			array_merge($processFlowData,$processRiskData)
			,array_merge($documentData,array_merge($courseDataAck,$courseDataCom))
		); // results for logged in user (incomplete actions)
	}

	public function getCompletedMeActions() {
		$iData = new inductData();
		
		$processFlowsData = array();
		$processRiskData = array();
		$documentData = array();
		$courseDataAck = array();
		$courseDataCom = array();
/*
		$processFlowData = $iData->getPFData(true,false);
		$processRiskData = $iData->getPRData(true,false);
		$documentData = $iData->getDocData(true,false);
*/		$courseDataAck = $iData->getCourseAckData(true,false);
		$courseDataCom = $iData->getCourseComData(true,false);
		
		return array_merge(
			array_merge($processFlowData,$processRiskData)
			,array_merge($documentData,array_merge($courseDataAck,$courseDataCom))
		); // results for logged in user (completed actions, like a history)
	}
	
	public function getPendingOtherActions() {
		// get all users under the authorisation of this user
		$usersUnder = $this->getUsersUnderAU();
		
		$processFlowsData = array();
		$processRiskData = array();
		$documentData = array();
		$courseDataAck = array();
		$courseDataCom = array();

		//for the selected user (denoted, I am not sure how, perhaps sorting by username...)
		foreach($usersUnder as $userUnder) {
/*
			$processFlowData = array_merge($processFlowData,$iData->getPFData(false,true,$userUnder));
			$processRiskData = array_merge($processRiskData,$iData->getPRData(false,true,$userUnder));
			$documentData = array_merge($documentData,$iData->getDocData(false,true,$userUnder));
*/			
			$courseDataAck = array_merge($courseData,$iData->getCourseAckData(false,true,$userUnder));
			$courseDataCom = array_merge($courseData,$iData->getCourseComData(false,true,$userUnder));
		}
		
		return array_merge(
			array_merge($processFlowData,$processRiskData)
			,array_merge($documentData,array_merge($courseDataAck,$courseDataCom))
		);
	}
	
	public function getCompletedOtherActions() {
		// get all users under the authorisation of this user
		$usersUnder = $this->getUsersUnderAU();
		
		$processFlowsData = array();
		$processRiskData = array();
		$documentData = array();
		$courseDataAck = array();
		$courseDataCom = array();

		//for the selected user (denoted, I am not sure how, perhaps sorting by username...)
		foreach($usersUnder as $userUnder) {
/*
			$processFlowData = array_merge($processFlowData,$iData->getPFData(true,false,$userUnder));
			$processRiskData = array_merge($processRiskData,$iData->getPRData(true,false,$userUnder));
			$documentData = array_merge($documentData,$iData->getDocData(true,false,$userUnder));
*/						
			$courseDataAck = array_merge($courseData,$iData->getCourseAckData(true,false,$userUnder));
			$courseDataCom = array_merge($courseData,$iData->getCourseComData(true,false,$userUnder));
		}
		
		return array_merge(
			array_merge($processFlowData,$processRiskData)
			,array_merge($documentData,array_merge($courseDataAck,$courseDataCom))
		);
	}
	
	/*
	 * getUsersUnderAU
	 * This method is used to return all participants under a specified Authorised User by firstly finding the Authorised Users Business Unit, then retrieving all participants under that business unit
	 * NOTE: This should live in newCore
	 */
	private function getUsersUnderAU() {
		if(!isAuthorisedUser()) { // we only want authorised users to use this
			return array();
		}
		
		$out = array();
		
		// get curent buID
		$stmt = $this->dbHand->prepare(
			sprintf(
				" SELECT reportToBuID FROM %s.participant_meta_data WHERE %s.participantID = %d "
				,_DB_OBJ_FULL
				,(int)Session::getSessionField('SESS_USER_REC_ID')
			)
		);
		$stmt->execute();
		if($stmt->errorCode() == 0) {
			$myBuID =  (int)current( $stmt->fetch(PDO::FETCH_ASSOC) );
			$out = $this->getUsersInBuID($myBuID);
		}/* else {
			var_dump($stmt->errorInfo());
		}*/
		return $out;
	}
	
	/*
	 * getUsersInBuID
	 * This method is used to return all participants that report to a specific business unit
	 * NOTE: This should live in newCore
	 */
	private function getUsersInBuID($buID=0) {
		if((int)$buID <= 0){ $buID = self::getUserBuID(); }
		
		$out = array();
		
		$stmt = $this->dbHand->prepare(
			sprintf(
				" SELECT participantID FROM %s.participant_meta_data WHERE reportToBuID = %d "
				,_DB_OBJ_FULL
				,(int)$buID
			)
		);
		$stmt->execute();
		if($stmt->errorCode() == 0) {
			$out =  $stmt->fetchAll(PDO::FETCH_ASSOC);
		}/* else {
			var_dump($stmt->errorInfo());
		}*/
		return $out;
	}
	
	public static function getUserBuID($participant=null) {
		$user_id = 0;
		if($participant !== null) {
			$user_id = $participant;
		} else {
			$user_id = Session::getSessionField('SESS_USER_REC_ID');
		}
		$dbHand = DB::connect(_DB_TYPE);
		$myBuID = 0;
		
		// get curent buID
		$stmt = $dbHand->prepare(
			sprintf(
				" SELECT reportToBuID FROM %s.participant_meta_data WHERE participantID = %d "
				,_DB_OBJ_FULL
				,(int)$user_id
			)
		);
		$stmt->execute();
		if($stmt->errorCode() == 0) {
			$myBuID = (int)current( $stmt->fetch(PDO::FETCH_ASSOC) );
		}/* else {
			var_dump($stmt->errorInfo());
		}*/
		return $myBuID;
	}
	
	public static function getAUsByBUID($buID=0) {
		if((int)$buID <= 0){ $buID = self::getUserBuID(); }
		
		$dbHand = DB::connect(_DB_TYPE);
		$auList = array();
		
		// get curent buID
		$stmt = $dbHand->prepare(
			sprintf(
				" SELECT participantID FROM %s.participant_meta_data WHERE accessLevel = 2 "
				,_DB_OBJ_FULL
			)
		);
		$stmt->execute();
		if($stmt->errorCode() == 0) {
			$auList = $stmt->fetchAll(PDO::FETCH_ASSOC);
		}
		return $auList;
	}
	
	public static function getAUsForUser($user_id=null) {
		$bu_id = self::getUserBuID($user_id); // firstly lets get the buID of the user
		return self::getAUsByBuID($bu_id); //now return all AUs for the business unit
	}

}