<?php

class ImportData {

	private $dbHand;
	private $listId;
	private $fileName;

	public function __construct() {

		$this->dbHand = DB::connect(_DB_TYPE);
	}

	public function setItemInfo($p_mse_id,$p_file_name,$p_module='mse') {

		$this->listId = $p_mse_id;
		$this->fileName = _PATH_TEMP_FILES.$p_module.'/'.$p_file_name;
	}

	public function importData() {

		$handle =  fopen($this->fileName, "r");

		$k = 0;
		while (($data = fgetcsv($handle,1000,",")) !== FALSE ) {

			if ($k) {

				$sql = sprintf("INSERT INTO %s.management_elements (mainCatID,subCategory,pointsToReview,memlListID) VALUES (%d,'%s','%s',%d) ",_DB_OBJ_FULL,$data[0],$data[1],$data[2],$this->listId);
				$pStatement = $this->dbHand->prepare($sql);

				$pStatement->execute();
			}

			$k++;
		}

		fclose($handle);
	}

	public function importDataHazard() {

		$handle =  fopen($this->fileName, "r");

		$k = 1;
		while (($data = fgetcsv($handle,1000,",")) !== FALSE ) {

			if ($k) {
				if ( $data[0] != '' && $data[1] != '' && $data[2] != '' && $this->listId != '' ) {
					$sql = sprintf("INSERT INTO %s.hazards (mainCatID,subCatID,pointsToReview,hsListID) VALUES (%d,%d,'%s',%d) ",_DB_OBJ_FULL,$data[0],$data[1],$data[2],$this->listId);
					$pStatement = $this->dbHand->prepare($sql);

					$pStatement->execute();
				}
			}
			$k++;
		}

		fclose($handle);
	}

	public function importDataEquipment() {

		$unqRef	= new UniqueReference();
		$logged_in_id = getLoggedInUserId();

		$handle =  fopen($this->fileName, "r");

		$k = 0;
		while (($data = fgetcsv($handle,1000,",")) !== FALSE ) {

			if ($k) {

				$unique_reference = $unqRef->getNumber('EQUIPMENT');

				$sql = sprintf("INSERT INTO %s.equipments (reference,uniqueReference,companyName,contactName,contactEmail,contactNumber,address,manufacturerReference,
							   datePurchased,equipTitle,purchaseValue,dateManufacture,equipmentDesc,whoID)
							   VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%f,'%s','%s',%d) ",
							   _DB_OBJ_FULL,$unique_reference,$unique_reference,$data[0],$data[1],$data[2],$data[3],$data[4],$data[5],format_date_for_mysql($data[6]),$data[7],$data[8],
							   format_date_for_mysql($data[9]),$data[10],$logged_in_id);

				$pStatement = $this->dbHand->prepare($sql);

				if ( $pStatement->execute() ) {

					$equip_last_id = customLastInsertId($this->dbHand,'equipments','equipID');

					$sql3 = "INSERT INTO %s.equipment_client_details (equipID) VALUES (%d) ";
					$psql3 = sprintf($sql3,_DB_OBJ_FULL,$equip_last_id);
					$pStatement3 = $this->dbHand->prepare($psql3);
					$pStatement3->execute();

					$sql2 = "INSERT INTO %s.equipment_contacts (equipID, contactType) VALUES (%d, '%s') ";

					$contact_type = 'I';		//'I' - internal contact
					$psql2 = sprintf($sql2,_DB_OBJ_FULL,$equip_last_id,$contact_type);

					$pStatement2 = $this->dbHand->prepare($psql2);
					$pStatement2->execute();

					$contact_type = 'E';		//'E' - external contact
					$psql2 = sprintf($sql2,_DB_OBJ_FULL,$equip_last_id,$contact_type);
					$pStatement = $this->dbHand->prepare($psql2);
					$pStatement2->execute();
				}



			}
			$k++;
		}

		fclose($handle);
	}
}
?>