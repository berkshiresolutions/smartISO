<?php
 /**
  $Id: Inspection.int.php,v 3.10 Thursday, October 28, 2010 4:25:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage inspection object
  *
  * This interface will declare the various methods performed
  * by inspection object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 8:14:13 PM>
  */

interface Inspection
{
	/*
	 * This method is used to set Inspection information for the respective object
	 */
	public function setInspectionInfo($p_NhpId,$p_NhpInfo);

	/*
	 * This method is used to add new Inspection
	 */
	public function addInspection();

	/*
	 * This method is used to edit an inspection record
	 */
	public function editInspection();

	/*
	 * This method is used to delete an inspection record
	 */
	public function deleteInspection();

	/*
	 * This method is used to archive an inspection record
	 */
	public function archiveInspection();

	/*
	 * This method is used to completely delete an inspection record
	 */
	public function purgeInspection();

}