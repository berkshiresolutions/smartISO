<?php
 /**
  $Id: ActionTracker.abs.php,v 3.32 Wednesday, January 26, 2011 7:34:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */

abstract class AbstractActionTracker
{
	protected $dbHand;
	protected $moduleInfo;

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct($p_dbHand,$p_moduleInfo) {

		$this->dbHand 			= $p_dbHand;
		$this->moduleInfo		= $p_moduleInfo;
		
	}

	protected function getPendingMeActions() {}

	protected function getCompletedMeActions() {}

	protected function getPendingOtherActions() {}

	protected function getCompletedOtherActions() {}
}