<?php
 /**
  $Id: Locogram.int.php,v 3.26 Wednesday, September 15, 2010 11:26:12 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage locogram object
  *
  * This interface will declare the various methods performed
  * by locogram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 7:02:36 PM>
  */

interface Locogram
{

	/*
	 * This method is used to get locations hierachy
	 */
	public function drawLocogram();

	/*
	 * This method is used to get location meta data
	 */
	public function getLocationInformation($p_locId);

	/*
	 * This method is used to get location meta data
	 */
	public function setRisk27kInformation($p_locationId,$p_riskInformation);

	/*
	 * This method is used to add risk 27k assessment
	 */
	public function addRisk27k();

	/*
	 * This method is used to edit risk 27k assessment
	 */
	public function editRisk27k();

	/*
	 * This method is used to delete risk 27k assessment
	 */
	public function deleteRisk27k();

	/*
	 * This method is used to archive risk 27k assessment
	 */
	public function archiveRisk27k();

	/*
	 * This method is used to purge risk 27k assessment
	 */
	public function purgeRisk27k();
}