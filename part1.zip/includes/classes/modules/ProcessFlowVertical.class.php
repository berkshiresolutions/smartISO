<?php
 /**
  $Id: ProcessFlowVertical.class.php,v 10.0 Saturday, December 18, 2010 7:11:20 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 2:57:54 PM>
  */

class ProcessFlowVertical
{
	private $pfObject;
	private $img;
	private $canvasWidth;
	private $canvasHeight;
	private $lineThickness;
	private $outlineThickness;
	private $noOfAlternatePaths;
	private $processData;
	private $inputBlockWidth;
	private $outputBlockWidth;
	private $commentBlockWidth;
	private $blockWidth;
	private $blockHeight;
	private $headerHeight;

	private $maxLevel;
	private $maxDepth;
	private $colours;
	private $flagShowGrid;
	private $altPathTotal;
	private $objectWidth; // in case of rectangle
	private $objectHeight; // in case of rectangle
	private $objectVertex;  // in case of diamond, triangle
	private $objectGap;

	private $debugMode;

	private $resample;
	private $resamplePercent;

	private $fontFile;
	private $outputFile;

	public function __construct($p_debugMode=false,$p_resample=false) {

		$this->debugMode 		= $p_debugMode;
		$this->resample 		= (boolean) $p_resample;
		$this->resamplePercent 	= 0.60;

		if (!$this->debugMode) {
			header('Content-type: image/png');
		}

		putenv('GDFONTPATH=' . realpath('.'));
		$this->fontFile 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arialbd.ttf';
		$this->fontFile_2 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arial.ttf';
		$this->fontFile_3 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/ariblk.ttf';

		$this->canvasWidth					= 0; // in px
		$this->canvasHeight					= 0; // in px
		$this->lineThickness				= 1; // in px, Please do not change this property. It is purely used for calculation only.
		$this->outlineThickness				= 2; // in px

		$this->maxLevel = 1; // columns
		$this->maxDepth = 0;

		$this->businessUnitFontSize		= 10;

		$this->inputBlockWidth  		= 300;
		$this->outputBlockWidth 		= 300;
		$this->commentBlockWidth		= 300;
		$this->blockWidth				= 360;
		$this->headerHeight				= 160;

		$this->objectWidth 				= 60;
		$this->objectHeight 			= 120;

		$this->objectGap 				= 15; // in px


		$this->flagShowGrid		= true;
		$this->altPathTotal		= 0;

		$this->business_units 	= array();
		$this->block_information;
		$this->block_path_information_expanded;
	}

	private function getMaxLevel() {

		$this->maxLevel = 1;
	}

	private function getMaxdepth() {

		if ( count($this->block_information[0]['step_information']) ) {
			foreach ( $this->block_information[0]['step_information'] as $block_ele ) {

				//echo $block_ele['type'].'-'.$block_ele['buName']."<br/>";

				if ( $block_ele['type'] != 'S' ) {
					$this->maxDepth++;
				}
			}
		}
	}

	public function setInformation($p_business_units,$p_blocks_information,& $p_procObj) {

		$this->pfObject 					= $p_procObj;

		$this->business_units				= & $p_business_units;
		$this->block_information 			= $p_blocks_information;
		$this->altPathTotal					= count($this->block_information) - 1;

		foreach ( $this->block_information[0]['step_information'] as $block_information_step_ele ) {
			if ( $block_information_step_ele['interProcess'] ) {
				$this->hasInterProcessReferences = true;
				break;
			}
		}

		// get maximum depth of the process flow
		$this->getMaxdepth();

		$total_paths 			= $this->altPathTotal + 1;

		/* Get max level from data */
		$this->getMaxLevel();

		if ( $this->outputType == 'N' )  {
			$this->maxLevel++;       // one extra column for end lozenge
		}

		$this->blockHeight			= $this->objectHeight + 2*$this->objectGap;

		$this->canvasWidth		= $this->inputBlockWidth + $this->outputBlockWidth + $this->commentBlockWidth + ($this->blockWidth*$total_paths) + ($this->lineThickness*(4+$total_paths));
		$this->canvasHeight		= $this->headerHeight + ($this->blockHeight*$this->maxDepth) + ($this->lineThickness*(2+$this->maxDepth));

		$this->img = imagecreatetruecolor($this->canvasWidth,$this->canvasHeight)
			  or die('Cannot Initialize new GD image stream');


		$bcolour 		= $this->hex2RGB('#0D830D');
		$bglosscolour 	= $this->hex2RGB('#219B21');
		$bgloss2colour 	= $this->hex2RGB('#63C563');
		$boutputcolour 	= $this->hex2RGB('#EDFCC8');

		$dcolour 		= $this->hex2RGB('#EFB31F');
		$dglosscolour 	= $this->hex2RGB('#F4D27E');
		$dgloss2colour 	= $this->hex2RGB('#F8F0DF');
		$doutputcolour 	= $this->hex2RGB('#FCF0C8');

		$scolour 		= $this->hex2RGB('#38B0B0');
		$soutputcolour 	= $this->hex2RGB('#A6D9D9');
		$lcolour 		= $this->hex2RGB('#9370DB');
		$mpcolour		= $this->hex2RGB('#668B8B');
		$a1pcolour 		= $this->hex2RGB('#8B8B00');
		$a2pcolour 		= $this->hex2RGB('#CDBE70');
		$a3pcolour 		= $this->hex2RGB('#CDAA7D');
		$a4pcolour 		= $this->hex2RGB('#CD3700');
		$a5pcolour 		= $this->hex2RGB('#388E8E');
		$gccolour 		= $this->hex2RGB('#dddddd');
		$txcolour 		= $this->hex2RGB('#202020');
		$bgcolour 		= $this->hex2RGB('#F7F7F7');
		$sbpcolour 		= $this->hex2RGB('#Ff0000');

		// colours for CCP and CMS Reference
		$ccpcolour 		= $this->hex2RGB('#Ff0000');
		$cmsrcolour 	= $this->hex2RGB('#Ff0000');
		$whitecolour 	= $this->hex2RGB('#ffffff');

		$this->colours['action_colour'] 			= imagecolorallocate($this->img,$bcolour['red'], $bcolour['green'], $bcolour['blue']);
		$this->colours['action_gloss_colour'] 		= imagecolorallocate($this->img,$bglosscolour['red'], $bglosscolour['green'], $bglosscolour['blue']);
		$this->colours['action_gloss2_colour'] 		= imagecolorallocate($this->img,$bgloss2colour['red'], $bgloss2colour['green'], $bgloss2colour['blue']);
		$this->colours['action_output_colour'] 		= imagecolorallocate($this->img,$boutputcolour['red'], $boutputcolour['green'], $boutputcolour['blue']);


		$this->colours['decision_colour']			= imagecolorallocate($this->img,$dcolour['red'], $dcolour['green'], $dcolour['blue']);
		$this->colours['decision_gloss_colour']		= imagecolorallocate($this->img,$dglosscolour['red'], $dglosscolour['green'], $dglosscolour['blue']);
		$this->colours['decision_gloss2_colour']	= imagecolorallocate($this->img,$dgloss2colour['red'], $dgloss2colour['green'], $dgloss2colour['blue']);
		$this->colours['decision_output_colour']	= imagecolorallocate($this->img,$doutputcolour['red'], $doutputcolour['green'], $doutputcolour['blue']);

		$this->colours['support_colour'] 			= imagecolorallocate($this->img,$scolour['red'], $scolour['green'], $scolour['blue']);
		$this->colours['support_output_colour']		= imagecolorallocate($this->img,$soutputcolour['red'], $soutputcolour['green'], $soutputcolour['blue']);
		$this->colours['lozenge_colour'] 			= imagecolorallocate($this->img,$lcolour['red'], $lcolour['green'], $lcolour['blue']);
		$this->colours['main_path_colour'] 			= imagecolorallocate($this->img,$mpcolour['red'], $mpcolour['green'], $mpcolour['blue']);
		$this->colours['alt1_path_colour'] 			= imagecolorallocate($this->img,$a1pcolour['red'], $a1pcolour['green'], $a1pcolour['blue']);
		$this->colours['alt2_path_colour'] 			= imagecolorallocate($this->img,$a2pcolour['red'], $a2pcolour['green'], $a2pcolour['blue']);
		$this->colours['alt3_path_colour'] 			= imagecolorallocate($this->img,$a3pcolour['red'], $a3pcolour['green'], $a3pcolour['blue']);
		$this->colours['alt4_path_colour'] 			= imagecolorallocate($this->img,$a4pcolour['red'], $a4pcolour['green'], $a4pcolour['blue']);
		$this->colours['alt5_path_colour'] 			= imagecolorallocate($this->img,$a5pcolour['red'], $a5pcolour['green'], $a5pcolour['blue']);

		$this->colours['grid_colour'] 				= imagecolorallocate($this->img,$gccolour['red'], $gccolour['green'], $gccolour['blue']);
		$this->colours['text_colour'] 				= imagecolorallocate($this->img,$txcolour['red'], $txcolour['green'], $txcolour['blue']);
		$this->colours['background_colour'] 		= imagecolorallocate($this->img,$bgcolour['red'], $bgcolour['green'], $bgcolour['blue']);
		$this->colours['sub_process_colour']		= imagecolorallocate($this->img,$sbpcolour['red'], $sbpcolour['green'], $sbpcolour['blue']);

		$this->colours['ccp_colour']				= imagecolorallocate($this->img,$ccpcolour['red'], $ccpcolour['green'], $ccpcolour['blue']);
		$this->colours['cmsr_colour']				= imagecolorallocate($this->img,$cmsrcolour['red'], $cmsrcolour['green'], $cmsrcolour['blue']);
		$this->colours['white_colour']				= imagecolorallocate($this->img,$whitecolour['red'], $whitecolour['green'], $whitecolour['blue']);



		//imagestring($this->img, 1, 5, 5,  'A Simple Text String',$action_colour);

	}

	private function hex2RGB($hexStr, $returnAsString = false, $seperator = ',') {

		$hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
		$rgbArray = array();

		if (strlen($hexStr) == 6) { //If a proper hex code, convert using bitwise operation. No overhead... faster
			$colorVal = hexdec($hexStr);
			$rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
			$rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
			$rgbArray['blue'] = 0xFF & $colorVal;
		} elseif (strlen($hexStr) == 3) { //if shorthand notation, need some string manipulations
			$rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
			$rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
			$rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
		} else {
			return false; //Invalid hex color code
		}

		return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
	}

    public function showExternalImage($x1, $y1,$type='action') {

        switch ($type) {
            case 'action': $icon_bg_file = _MYROOT.'images/action_bg.png'; break;
            case 'decision': $icon_bg_file = _MYROOT.'images/decision_bg.png'; break;
            case 'support': $icon_bg_file = _MYROOT.'images/support_bg.png'; break;
            case 'ccp': $icon_bg_file = _MYROOT.'images/ccp_icon.png'; break;
            case 'cmsr': $icon_bg_file = _MYROOT.'images/cmsr_icon.png'; break;
            case 'sbp': $icon_bg_file = _MYROOT.'images/cmsr_icon.png';
        }

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefrompng($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, $x1, $y1, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }
    }

	public function drawCanvas() {

		imagefilledrectangle($this->img,0,0,$this->canvasWidth,$this->canvasHeight,$this->colours['background_colour']);
		imagerectangle($this->img,0,0,($this->canvasWidth-$this->lineThickness),($this->canvasHeight-$this->lineThickness),$this->colours['grid_colour']);

		// to be deleted
		//$strele = 'canvasWidth '.$this->canvasWidth.' = canvasHeight '.$this->canvasHeight.' = Depth '.$this->maxDepth;
		//imagestring($this->img, 2,10,10,$strele,$this->colours['text_colour']);

		// show grid for idea
		if ($this->flagShowGrid) {

			// vertical
			/*for ($i=0;$i<$this->maxLevel;$i++) {

				$x1 = $x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
				$y1 = 0;
				$y2 = $this->canvasHeight - 1;

				imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);

			}*/

			// input column

			$x1 = $x2 = $this->lineThickness + $this->inputBlockWidth;
			$y1 = $this->headerHeight - 30;
			$y2 = $this->canvasHeight - 1;

            imageline($this->img,$x1-1,$y1,$x2-1,$y2,$this->colours['grid_colour']);
			imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
            imageline($this->img,$x1+1,$y1,$x2+1,$y2,$this->colours['grid_colour']);

			// main path column

			$x1 = $x2 = 2*$this->lineThickness + $this->inputBlockWidth + $this->blockWidth;
			$y1 = $this->headerHeight - 30;
			$y2 = $this->canvasHeight - 1;

            imageline($this->img,$x1-1,$y1,$x2-1,$y2,$this->colours['grid_colour']);
			imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
            imageline($this->img,$x1+1,$y1,$x2+1,$y2,$this->colours['grid_colour']);

			// commemt column

			$x1 = $x2 = 3*$this->lineThickness + $this->inputBlockWidth + $this->blockWidth + $this->outputBlockWidth;
			$y1 = $this->headerHeight - 30;
			$y2 = $this->canvasHeight - 1;

            imageline($this->img,$x1-1,$y1,$x2-1,$y2,$this->colours['grid_colour']);
			imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
            imageline($this->img,$x1+1,$y1,$x2+1,$y2,$this->colours['grid_colour']);


			// horizontal
			$x1 = 0;
			$x2 = $this->canvasWidth - 1;
			$y1 = $y2 = $this->headerHeight + $this->lineThickness;
			imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
			imageline($this->img,$x1,$y1-30,$x2,$y2-30,$this->colours['grid_colour']);

			imagefttext($this->img, $this->businessUnitFontSize, 0, $x1+($this->inputBlockWidth/2)-30, $y1-18, $this->colours['text_colour'], $this->fontFile,'Inputs');
			imagefttext($this->img, $this->businessUnitFontSize, 0, $x1+$this->inputBlockWidth+($this->blockWidth/2)-30, $y1-18, $this->colours['text_colour'], $this->fontFile,'Main Path');
			imagefttext($this->img, $this->businessUnitFontSize, 0, $x1+$this->inputBlockWidth+$this->blockWidth+($this->outputBlockWidth/2)-30, $y1-18, $this->colours['text_colour'], $this->fontFile,'Outputs');
			imagefttext($this->img, $this->businessUnitFontSize, 0, $x1+$this->inputBlockWidth+$this->blockWidth+$this->outputBlockWidth+($this->commentBlockWidth/2)-30, $y1-18, $this->colours['text_colour'], $this->fontFile,'Comments');

			imagefttext($this->img, $this->businessUnitFontSize-1, 0, $x1+($this->inputBlockWidth/2)-40, $y1-8, $this->colours['text_colour'], $this->fontFile,'(References)');
			imagefttext($this->img, $this->businessUnitFontSize-1, 0, $x1+$this->inputBlockWidth+$this->blockWidth+$this->outputBlockWidth+($this->commentBlockWidth/2)-30, $y1-8, $this->colours['text_colour'], $this->fontFile,'(Records)');

			for ($i=1;$i<=$this->maxDepth;$i++) {

				$x1 = 0;
				$x2 = $this->canvasWidth - 1;

				//$x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
				$y1 = $y2 = $y1 + $this->lineThickness + ($this->blockHeight);

				imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
			}

		}
	}

	public function printHeading($classObj,$p_x1,$p_y1,$p_content,$p_object_type='A') {

		if ( $p_object_type == 'A' ) {
			$p_y1 = $p_y1 + 35;
			imagefttext($classObj,$this->businessUnitFontSize, 0, $p_x1+85,$p_y1, $path_colour, $this->getFontFile(),$p_content);
		} else if ( $p_object_type == 'D' ) {
			$p_y1 = $p_y1 + 35;
			imagefttext($classObj,$this->businessUnitFontSize, 0, $p_x1+85,$p_y1, $path_colour, $this->getFontFile(),$p_content);
		} else {
			$p_y1 = $p_y1 + 30;
			imagefttext($classObj,$this->businessUnitFontSize, 0, $p_x1,$p_y1, $path_colour, $this->getFontFile(),$p_content);
		}

	}

	public function printDescription($classObj,$p_x1,$p_y1,$p_content,$p_object_type='A',$column_ele) {

		//$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

		$p_content_strlen = strlen($p_content);

        if ( $column_ele == 'mainpath') {
            $max_string_length = 42;
            $p_x1 = $p_x1 + 35;
        } else {
            $max_string_length = 52;
        }


		$p_y1 = $p_y1 + 16;

		if ( $p_content_strlen < $max_string_length ) {

			if ( $p_object_type == 'A' ) {
				imagefttext($classObj,8, 0, $p_x1+10,$p_y1, $path_colour, $this->getFontFile_2(),$p_content);
			} else if ( $p_object_type == 'D' ) {
				imagefttext($classObj,8, 0, $p_x1+30,$p_y1, $path_colour, $this->getFontFile_2(),$p_content);
			} else {
				imagefttext($classObj,8, 0, $p_x1,$p_y1, $path_colour, $this->getFontFile_2(),$p_content);
			}

		} else {

			if ( $p_object_type == 'A' ) {

				$strings 	= wordwrap(substr($p_content,0,260).' ...', $max_string_length, "#", false);
			} else if ( $p_object_type == 'D' ) {

				$p_x1 = $p_x1 + 5;
				$p_y1 = $p_y1;
				$strings 	= wordwrap(substr($p_content,0,150).' ...', $max_string_length, "#", false);
			} else {

				$strings 	= wordwrap(substr($p_content,0,290).' ...', $max_string_length, "#", false);
			}
			$string_arr = explode("#",$strings);

			$cy1 = $p_y1;

			foreach ( $string_arr as $strele ) {
				//imagestring($this->img, $this->businessUnitFontSize, $x1, $cy1,$strele,$this->colours['text_colour']);
				if ( $p_object_type == 'A' ) {
					imagefttext($classObj,8, 0, $p_x1+15,$cy1, $path_colour, $this->getFontFile_2(),$strele);
				} else if ( $p_object_type == 'D' ) {
					imagefttext($classObj,8, 0, $p_x1+15,$cy1, $path_colour, $this->getFontFile_2(),$strele);
				} else {
					imagefttext($classObj,8, 0, $p_x1,$cy1, $path_colour, $this->getFontFile_2(),$strele);
				}
				$cy1 = $cy1 + 11;
			}
		}
	}

	public function drawHeader() {

		/*$logo_file = _MYROOT.'images/logosmall.jpg';

		if ( file_exists($logo_file) ) {

			$src = imagecreatefromjpeg($logo_file);
			$size_information = getimagesize($logo_file);

			// copy
			imagecopy($this->img, $src, 10, 10, 0, 0,$size_information[0], $size_information[1]);

			// free memory
			imagedestroy($src);
		}*/

		$process_information = $this->pfObject->getCurrentProcessFlowInformation();

		/*$label['process_ref'] 		= 'Process Ref. :';
		$label['process_desc'] 		= 'Process Desc. :';
		$label['hazard_symbol'] 	= 'Hazard Symbol :';
		$label['control_symbol'] 	= 'Control Symbol :';

		imagefttext($this->img, $this->businessUnitFontSize, 0, 250, 20, $this->colours['text_colour'], $this->fontFile,$label['process_ref']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 250, 35, $this->colours['text_colour'], $this->fontFile,$label['process_desc']);

		imagefttext($this->img, $this->businessUnitFontSize, 0, 330, 20, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 340, 35, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);

		imagefttext($this->img, $this->businessUnitFontSize, 0, 250, 70, $this->colours['text_colour'], $this->fontFile,$label['hazard_symbol']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 250, 95, $this->colours['text_colour'], $this->fontFile,$label['control_symbol']);

		$symbols 			= $this->pfObject->getHazardControlSymbols();*/

        $label['business_owner'] 	= 'BU Owner:';
        $label['risk_rating'] 		= 'Risk Rating';
		$label['process_ref'] 		= 'Process Ref. :';
		$label['process_desc'] 		= 'Process Desc. :';
		$label['hazard_symbol'] 	= 'Hazard Symbol :';
		$label['control_symbol'] 	= 'Control Symbol :';

        $icon_bg_file = _MYROOT.'images/logo.jpg';
       
 if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefromjpeg($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 25, 0, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }


        imagefttext($this->img, $this->businessUnitFontSize, 0, 25, 70, $this->colours['text_colour'], $this->fontFile,$label['business_owner']);
		////imagefttext($this->img, $this->businessUnitFontSize, 0, 580, 50, $this->colours['text_colour'], $this->fontFile,$label['risk_rating']);

		$p_content_strlen = strlen($process_information['buName']);
		$max_string_length = 30;

		

		if ( $p_content_strlen < $max_string_length ) {
		imagefttext($this->img, $this->businessUnitFontSize, 0, 105, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
		} else {

			$strings 	= substr($process_information['buName'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 105, 70, $this->colours['text_colour'], $this->fontFile_2,$strings);
				
			
			}

		

		imagefttext($this->img, $this->businessUnitFontSize, 0, 900, 70, $this->colours['text_colour'], $this->fontFile,$label['process_ref']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 500, 70, $this->colours['text_colour'], $this->fontFile,$label['process_desc']);

		$p_content_strlen = strlen($process_information['reference']);
		$max_string_length = 30;

		

		if ( $p_content_strlen < $max_string_length ) {
		imagefttext($this->img, $this->businessUnitFontSize, 0, 1000, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		} else {

			$strings 	= substr($process_information['reference'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 1000, 70, $this->colours['text_colour'], $this->fontFile_2,$strings);
				
			
			}
			
			$p_content_strlen = strlen($process_information['description']);
		$max_string_length = 30;

		

		if ( $p_content_strlen < $max_string_length ) {
		imagefttext($this->img, $this->businessUnitFontSize, 0, 610, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);
		} else {

			$strings 	= substr($process_information['description'],0,30).' ...';
			//$string_arr = explode("#",$strings);

		imagefttext($this->img, $this->businessUnitFontSize, 0, 610, 70, $this->colours['text_colour'], $this->fontFile_2,$strings);
				
			
			}

		//imagefttext($this->img, $this->businessUnitFontSize, 0, 1010, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		//imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);

		imagefttext($this->img, $this->businessUnitFontSize, 0, 25, 105, $this->colours['text_colour'], $this->fontFile,$label['hazard_symbol']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 500, 105, $this->colours['text_colour'], $this->fontFile,$label['control_symbol']);

		$hazard_symbols		= $symbols['hazard'];
		$control_symbols 	= $symbols['control'];

        ///$hazard_symbols = array('ha2.jpg','ha20.jpg','ha21.jpg','ha22.jpg','ha23.jpg','ha24.jpg','ha25.jpg','ha26.jpg','ha27.jpg');
        ///$control_symbols = array('2.jpg','20.jpg','21.jpg','22.jpg','23.jpg','24.jpg','25.jpg','26.jpg','27.jpg');

		$max_symbol_count 	= 15;
		if ( 1 && count($hazard_symbols) ) {

			$k = 0;
			foreach ( $hazard_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../hazard') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+280)+($k*6);
					imagecopy($this->img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		if ( 1 && count($control_symbols) ) {

			$k = 0;
			foreach ( $control_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../improvement') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+805)+($k*6);
					imagecopy($this->img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		imagefilledrectangle($this->img, $this->canvasWidth - 130, 65, $this->canvasWidth - 106, 100, $this->colours['action_colour']);
		imagefilledrectangle($this->img, $this->canvasWidth - 104, 65, $this->canvasWidth - 86, 100, $this->colours['action_colour']);
		imagefilledrectangle($this->img, $this->canvasWidth - 84, 65, $this->canvasWidth - 55, 100, $this->colours['action_colour']);
		imagefttext($this->img, $this->businessUnitFontSize*2+4, 0, $this->canvasWidth - 130, 95, $this->colours['white_colour'], $this->fontFile,'C I A');

		$risk_rating 		= $this->pfObject->getRiskRating();

		$risk_rating['riskRating1'] = 'R';
		$risk_rating['riskRatingColor1'] = '#00ff00';

		if ( $risk_rating['riskRating1'] != '' && $risk_rating['riskRating1'] != '#' ) {

			$risk_rating_rgb 	= $this->hex2RGB($risk_rating['riskRatingColor1']);
			$risk_rating_colour = imagecolorallocate($this->img,$risk_rating_rgb['red'], $risk_rating_rgb['green'],$risk_rating_rgb['blue']);

            $x = $this->canvasWidth - 84;
			imagefilledrectangle($this->img, $x, 20, $x + 30, 55, $risk_rating_colour);
			imagefttext($this->img, 24, 0, $x+5, 50, $this->colours['white_colour'], $this->fontFile,$risk_rating['riskRating1']);
		}

	}

	public function drawObjects() {

		$block_information_arr_exp 				= explode('~#~',$this->block_information[0]['path_information']);
		$block_information_arr					= array();

		if ( count($block_information_arr_exp) ) {
			foreach ( $block_information_arr_exp as $block_information_arr_ele ) {

				$block_information_arr_ele_tok = explode(":",$block_information_arr_ele);

				$needle = $block_information_arr_ele_tok[0].':'.$block_information_arr_ele_tok[1].':'.$block_information_arr_ele_tok[2].':'.$block_information_arr_ele_tok[3];

				if ( !in_array($needle,$block_information_arr) ) {
					$block_information_arr[] = $needle;
				}
			}
		}

		$block_step_information 			= $this->block_information[0]['step_information'];
		$block_support_information_arr 		= explode('~#~',$this->block_information[0]['support_information']);

		$input_x_pos = $this->lineThickness + 10;
		$mainpath_x_pos = $this->lineThickness*2 + $this->inputBlockWidth + 10;
		$output_x_pos = $this->lineThickness*3 + $this->inputBlockWidth + $this->blockWidth + 10;
		$comment_x_pos = $this->lineThickness*4 + $this->inputBlockWidth + $this->blockWidth + $this->outputBlockWidth + 10;

		$columns = array('input','mainpath','output','comment');

		$k = 0;

		imagesetthickness($this->img, 2);

		if ( count($block_information_arr) ) {

			foreach ( $block_information_arr as $business_unit_ele_value ) {

				$input_y_pos 	= $this->headerHeight + ($this->blockHeight * $k);
				$mainpath_y_pos = $this->headerHeight + ($this->blockHeight * $k);
				$output_y_pos 	= $this->headerHeight + ($this->blockHeight * $k);
				$comment_y_pos 	= $this->headerHeight + ($this->blockHeight * $k);

				$input_y_pos_off 	= $input_y_pos + 20;
				$mainpath_y_pos_off = $mainpath_y_pos + 20;
				$output_y_pos_off 	= $output_y_pos + 20;
				$comment_y_pos_off 	= $comment_y_pos + 20;

				$block_record_granules  = explode(':',$business_unit_ele_value);

				$step_information = $block_step_information[$block_record_granules[3]];

				$x_pos = 'mainpath_x_pos';
				$y_pos = 'mainpath_y_pos_off';

				if ( count($block_information_arr) != ($k+1) ) {

					$arrow_x1 = $this->lineThickness*2 + $this->inputBlockWidth + $this->blockWidth/2;
					$arrow_y1 = $this->lineThickness*2 + $this->headerHeight + ($this->blockHeight*$k) + $this->blockHeight/2;
					$arrow_x2 = $this->lineThickness*2 + $this->inputBlockWidth + $this->blockWidth/2;
					$arrow_y2 = $this->lineThickness*2 + $this->headerHeight + ($this->blockHeight*($k+1)) + $this->blockHeight/2;

					imageline($this->img,$arrow_x1,$arrow_y1,$arrow_x2, $arrow_y2,$this->getPathcolour(0));

					if ( $step_information['type'] == 'A' ) {

						$x1_arrow = $arrow_x1 - 6;
						$y1_arrow = $arrow_y2 + 5 - $this->blockHeight/2;
						$x2_arrow = $arrow_x1 + 4;
						$y2_arrow = $arrow_y2 + 5 - $this->blockHeight/2;
						$x3_arrow = $arrow_x1 - 1;
						$y3_arrow = $arrow_y2 + 15 - $this->blockHeight/2;

					} else if ( $step_information['type'] == 'S' ) {

						$x1_arrow = $arrow_x1 - 6;
						$y1_arrow = $arrow_y2 + 15 - $this->blockHeight/2;
						$x2_arrow = $arrow_x1 + 4;
						$y2_arrow = $arrow_y2 + 15 - $this->blockHeight/2;
						$x3_arrow = $arrow_x1 - 1;
						$y3_arrow = $arrow_y2 + 25 - $this->blockHeight/2;

					}

					// draw arrow

					$arrow_points = array(
						$x1_arrow,$y1_arrow,
						$x2_arrow,$y2_arrow,
						$x3_arrow,$y3_arrow
					);

					imagefilledpolygon($this->img,$arrow_points ,3 ,$this->getPathcolour(0));
				}

				if ( $step_information['type'] != 'S' ) {
					$k++;
				}
			}

			$k = 0;

            foreach ( $block_information_arr as $business_unit_ele_value ) {

				$mainpath_y_pos = $this->headerHeight + (($this->blockHeight + $this->lineThickness)* $k);
                $input_y_pos 	= $mainpath_y_pos;
				$output_y_pos 	= $mainpath_y_pos;
				$comment_y_pos 	= $mainpath_y_pos;

                $input_y_pos_off 	= $mainpath_y_pos + $this->objectGap;
				$mainpath_y_pos_off = $mainpath_y_pos + $this->objectGap;
				$output_y_pos_off 	= $mainpath_y_pos + $this->objectGap;
				$comment_y_pos_off 	= $mainpath_y_pos + $this->objectGap;

                //$exp = $this->headerHeight." + ".$this->blockHeight." * ".$k." = ".$mainpath_y_pos_off;
                //imagefttext($this->img, 7, 0,$block_x1_pos , $mainpath_y_pos_off-20, $this->colours['text_colour'], $this->fontFile,$exp);

				$block_record_granules  = explode(':',$business_unit_ele_value);

				$step_information = $block_step_information[$block_record_granules[3]];

                $decision_bg_file = _MYROOT.'images/sbp_icon.png';

                if ( file_exists($decision_bg_file) ) {

                    $src = imagecreatefrompng($decision_bg_file);
                    $size_information = getimagesize($decision_bg_file);

                    $block_margin = ($this->blockWidth - $size_information[0])/8;
                }

				foreach ( $columns as $column_ele ) {

					$x_pos = $column_ele.'_x_pos';
					$y_pos = $column_ele.'_y_pos_off';



                    if ( $column_ele == 'mainpath' && $step_information['type'] != 'S' ) {

						if ( $step_information['type'] == 'A' ) {

							$block_x1_pos = $this->lineThickness*2 + $this->inputBlockWidth;
							$block_x2_pos = $this->lineThickness*2 + $this->inputBlockWidth + $this->blockWidth;

                            /*if ( file_exists($action_bg_file) ) {

                                $src = imagecreatefrompng($action_bg_file);
                                $size_information = getimagesize($action_bg_file);

                                $block_margin = ($this->blockWidth - $size_information[0])/2;

                                // copy
                                imagecopy($this->getResource(), $src, ($block_x1_pos+$block_margin), ($mainpath_y_pos_off), 0, 0,$size_information[0], $size_information[1]);

                                // free memory
                                imagedestroy($src);
                            }*/
                            $this->showExternalImage( ($block_x1_pos+$block_margin), $mainpath_y_pos_off, 'action');

							////imagefilledrectangle($this->img, ($block_x1_pos+$block_margin), ($mainpath_y_pos+$block_margin), ($block_x2_pos-$block_margin), ($mainpath_y_pos + $this->blockHeight-$block_margin) , $this->colours['action_output_colour']);
							////imagerectangle($this->img, ($block_x1_pos+$block_margin), ($mainpath_y_pos+$block_margin), ($block_x2_pos-$block_margin), ($mainpath_y_pos + $this->blockHeight-$block_margin) , $this->colours['action_colour']);

						} else if ( $step_information['type'] == 'D' ) {

							$block_x1_pos = $this->lineThickness*2 + $this->inputBlockWidth;
							$block_x2_pos = $this->lineThickness*2 + $this->inputBlockWidth + $this->blockWidth;

                            /*if ( file_exists($decision_bg_file) ) {

                                $src = imagecreatefrompng($decision_bg_file);
                                $size_information = getimagesize($decision_bg_file);

                                $block_margin = ($this->blockWidth - $size_information[0])/2;

                                // copy
                                imagecopy($this->getResource(), $src, ($block_x1_pos+$block_margin), ($mainpath_y_pos_off), 0, 0,$size_information[0], $size_information[1]);

                                // free memory
                                imagedestroy($src);
                            }*/

							////imagefilledpolygon ($this->img,$points ,4 ,$this->colours['decision_output_colour']);
							////imagepolygon($this->img,$points ,4 ,$this->colours['decision_colour']);

                            $this->showExternalImage(($block_x1_pos+$block_margin), $mainpath_y_pos_off, 'decision');

						}

						// for support
						$support1_y_offset = 10;
						$support1_x_offset = 0;
						$support2_y_offset = 70;
						$support2_x_offset = 0;
						$support3_y_offset = 10;
						$support3_x_offset = $this->inputBlockWidth;
						$support4_y_offset = 70;
						$support4_x_offset = $this->inputBlockWidth;


						$support_information_count = count($step_information['step_support_information']);

						for ($i=1;$i<5;$i++) {

							if ( $i > $support_information_count ) {
								break;
							}

							$dynamic_support_x_offset = "support{$i}_x_offset";
							$dynamic_support_y_offset = "support{$i}_y_offset";

							$block_y1_pos = ($this->lineThickness * ($k+2)) + $mainpath_y_pos + ($this->objectGap/2) + $$dynamic_support_y_offset;

							if ( $i == 1 || $i == 2 ) {
                                $block_x1_pos = $this->lineThickness*2 + $this->inputBlockWidth + $$dynamic_support_x_offset;
								$block_x2_pos = $this->lineThickness*2 + $this->inputBlockWidth + $this->blockWidth/8;
                                $block_x3_pos = $this->lineThickness*2 + $this->inputBlockWidth + $$dynamic_support_x_offset;
							} else {
                                $block_x1_pos = $this->lineThickness*2 + $this->inputBlockWidth + $$dynamic_support_x_offset + 60;
								$block_x2_pos = $this->lineThickness*2 + $this->inputBlockWidth + $$dynamic_support_x_offset + 10;
                                $block_x3_pos = $this->lineThickness*2 + $this->inputBlockWidth + $$dynamic_support_x_offset + 60;
							}

							$block_y2_pos = ($this->lineThickness * ($k+2)) + $mainpath_y_pos + 3* $this->objectGap/2 + $$dynamic_support_y_offset;


							$block_y3_pos = ($this->lineThickness * ($k+2)) + $mainpath_y_pos + (2*$this->objectGap) + $this->objectGap/2 + $$dynamic_support_y_offset;

							$points = array(
								$block_x1_pos,$block_y1_pos,
								$block_x2_pos,$block_y2_pos,
								$block_x3_pos,$block_y3_pos
							);

                            imagefilledpolygon($this->img,$points ,3 ,$this->colours['support_output_colour']);
							imagepolygon($this->img,$points ,3 ,$this->colours['support_colour']);
							imagefttext($this->img, 7, 0,$block_x1_pos , $block_y2_pos, $this->colours['text_colour'], $this->fontFile,$step_information['step_support_information'][$i-1]);
						}
					}
				}

				if ( $step_information['type'] != 'S' ) {
					$k++;
				}
			} // end inner foreach
			imagesetthickness($this->img, 1);
		}
	}

	public function showComments() {

		$block_information_arr_exp 				= explode('~#~',$this->block_information[0]['path_information']);
		$block_information_arr					= array();

		if ( count($block_information_arr_exp) ) {
			foreach ( $block_information_arr_exp as $block_information_arr_ele ) {

				$block_information_arr_ele_tok = explode(":",$block_information_arr_ele);

				$needle = $block_information_arr_ele_tok[0].':'.$block_information_arr_ele_tok[1].':'.$block_information_arr_ele_tok[2].':'.$block_information_arr_ele_tok[3];

				if ( !in_array($needle,$block_information_arr) ) {
					$block_information_arr[] = $needle;
				}
			}
		}

		//dump_array($block_information_arr);

		$block_step_information 			= $this->block_information[0]['step_information'];

		$input_x_pos = $this->lineThickness + 10;
		$mainpath_x_pos = $this->lineThickness*2 + $this->inputBlockWidth + 10;
		$output_x_pos = $this->lineThickness*3 + $this->inputBlockWidth + $this->blockWidth + 10;
		$comment_x_pos = $this->lineThickness*4 + $this->inputBlockWidth + $this->blockWidth + $this->outputBlockWidth + 10;

		$columns = array('input','mainpath','output','comment');

		$k = 0;
		$block_margin = 18;

		imagesetthickness($this->img, 2);

		if ( count($block_information_arr) ) {

			$k = 0;
			foreach ( $block_information_arr as $business_unit_ele_value ) {

				//echo $business_unit_ele_value."<br/>";

				$mainpath_y_pos = $this->headerHeight + (($this->blockHeight + $this->lineThickness)* $k);
                $input_y_pos 	= $mainpath_y_pos;
				$output_y_pos 	= $mainpath_y_pos;
				$comment_y_pos 	= $mainpath_y_pos;

                $object_offset	= 18;

                $input_y_pos_off 	= $mainpath_y_pos + $this->objectGap + $object_offset;
				$mainpath_y_pos_off = $mainpath_y_pos + $this->objectGap + $object_offset;
				$output_y_pos_off 	= $mainpath_y_pos + $this->objectGap + $object_offset;
				$comment_y_pos_off 	= $mainpath_y_pos + $this->objectGap + $object_offset;

				$block_record_granules  = explode(':',$business_unit_ele_value);

				$step_information 			= $block_step_information[$block_record_granules[3]];
				$step_comment_information 	= $block_step_information[$block_record_granules[3]]['comments_information'];

				foreach ( $columns as $column_ele ) {

					$x_pos 			= $column_ele.'_x_pos';
					$y_pos 			= $column_ele.'_y_pos_off';
					$y_pos_nooff 	= $column_ele.'_y_pos';

					$comment 	= '';

					switch ($column_ele) {
						case 'mainpath': $comment = $block_step_information[$block_record_granules[3]]['descQues'];	break;
						case 'input': $comment = $step_comment_information['IN'][0];	break;
						case 'output': $comment = $step_comment_information['OUT'][0];	break;
						case 'comment': $comment = $step_comment_information['MAIN'][0];	break;
					}

                    ///$comment = "The contents of this e-mail and any attachments are confidential and privileged. If you are not the intended recipient please notify the sender immediately and delete the message in its entirety. We check e-mails for viruses but you should satisfy yourself that it is virus free as we do not accept responsibility for any loss or damage it may cause. Do not confuse our website with any other of a like sounding name.";

                    if ( $comment != '' ) {
						if ( $column_ele == 'mainpath' ) {
							$this->printHeading($this->img,$$x_pos,$$y_pos_nooff,$step_information['buName'],$step_information['type']);
							$this->printDescription($this->img,$$x_pos,$$y_pos,$comment,$step_information['type'],$column_ele);
						} else {
							//$this->printHeading($this->img,$$x_pos,$$y_pos_nooff,$step_information['buName'],'N');
							$this->printDescription($this->img,$$x_pos,$$y_pos-25,$comment,'N',$column_ele);
						}
					}
				}

				if ( $step_information['type'] != 'S' ) {
					$k++;
				}
			} // end inner foreach
			imagesetthickness($this->img, 1);
		}
	}

	public function drawPaths() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';

		try {

			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				//$k = 0;
				$block_information_elements_count 			= count($block_information_arr);
				$block_support_information_elements_count 	= count($block_support_information_arr);

				$processed_start_node = false;
				$processed_end_node = false;

				if (1) {

					// for ($m=1;$m<=($block_information_elements_count+1);$m++) {
					for ($m=2;$m<=$block_information_elements_count;$m++) {

						$start_block_information_arr 	= $block_information_arr[$m-2];
						$end_block_information_arr 		= $block_information_arr[$m-1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					} // end for loop
				}


				if (1) {

					// loop for inter process process flow
					for ($m=0;$m<=$block_information_elements_count;$m++) {

						$start_block_information_arr 		= $block_information_arr[$m];
						$end_block_information_arr 			= $block_information_arr[$m];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						if ( $block_record_end_granules[5] == 'IN' || $block_record_end_granules[5] == 'OUT' ) {

							$start_context_code 				= chr($this->maxDepth+64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];
							$end_context_code 					= $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

							$alt_node_type = $block_record_end_granules[5].'PROCESS';

							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';


							ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}

						//echo $start_block_information_arr." => ".$end_block_information_arr."<br/>";

					} // end for loop

				} // end if

				// standalone start and end block
				if (1) {
					$alt_node_type = 'START';

					$start_block_information_arr 	= $block_information_arr[0];
					$end_block_information_arr 		= $block_information_arr[1];

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$end_block_information_arr		= $start_block_information_arr;
					$start_block_information_arr	= $this->getMainPathNodeData($block_record_start_granules[4]);

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$start_context_level = $block_record_start_granules[0];
					$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

					$end_context_level = $block_record_end_granules[0];
					$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

					$main_path = false;
					$alt_path = true;
					$lozenge = 'NA';

					ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					/*dump_array($block_record_start_granules[2]);
					dump_array($block_record_end_granules[2]);*/

					if ( $block_record_start_granules[2] || $block_record_end_granules[2] ) {

						$alt_node_type = 'END';

						$start_block_information_arr 	= $block_information_arr[1];
						$end_block_information_arr 		= $block_information_arr[0];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);

						$end_block_information_arr		= $this->getMainPathNodeData($block_record_start_granules[4]);

						// for mid air stop
						if ( $block_record_start_granules[4] ) {

							$block_record_start_granules  	= explode(':',$start_block_information_arr);
							$block_record_end_granules  	= explode(':',$end_block_information_arr);

							$start_context_level = $block_record_start_granules[0];
							$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

							$end_context_level = $block_record_end_granules[0];
							$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';

							ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}
					}
				}

				// support path blocks
				if (1 && $this->outputType == 'N' ) {

					for ($m=0;$m<$block_support_information_elements_count;$m++) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_arr[$m]);

						$start_block_information_arr 	= $block_support_start_end_information_arr[0];
						$end_block_information_arr 		= $block_support_start_end_information_arr[1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawSupportPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					} // end for loop
				} // end if block

			} // end outer foreach

		} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}

	}

	public function showImage() {

		// execute this block if debugMode is enabled.
		if (!$this->debugMode) {

			// if resampling is enabled.
			if ( $this->resample ) {

				// Get new dimensions
				$new_width 	= $this->canvasWidth * $this->resamplePercent;
				$new_height = $this->canvasHeight * $this->resamplePercent;


				// if resampling is enabled.
				$this->imgResampled = imagecreatetruecolor($new_width,$new_height)
					or die('Cannot Initialize new GD image stream');

				imagecopyresampled($this->imgResampled, $this->img, 0, 0, 0, 0, $new_width, $new_height, $this->canvasWidth, $this->canvasHeight);

				// Output
				imagepng($this->imgResampled);

			} else {
				imagepng($this->img);
			}
		}
	}

	public function saveImage() {

		$process_details = $this->pfObject->getCurrentProcessFlowInformation();
		$this->outputFile = "process_flow_vertical_".$process_details['swimID'].".png";
		$output_file_path = realpath("../private_files/process_flow")."/".$this->outputFile;


		if (!$this->debugMode) {

			if ( file_exists($output_file_path) ) {
				unlink($output_file_path);
			}
			imagepng($this->img,$output_file_path,9);


		}
	}

	public function getSavedImageName() {
		if (!$this->debugMode ) {
			return $this->outputFile;
		}
	}

	public function __destruct() {

		if (!$this->debugMode) {
			imagedestroy($this->img);
		}
	}

	public function __call($name,$arguments) {

		$propertyname = strtolower(substr($name,3,1)).substr($name,4);

		return $this->$propertyname;
	}

	public function getColour($p_code) {
		return $this->colours[$p_code];
	}

	public function getResource() {
		return $this->img;
	}

	public function getPathcolour($p_pathno) {

		$p_pathno = (int) $p_pathno;

		if (!$p_pathno) {
			return $this->colours['main_path_colour'];
		} else {
			return $this->colours['alt'.$p_pathno.'_path_colour'];
		}
	}

	public function getMainPathNodeData($node) {

		if ( $node < 1 ) {
			$node = 1;
		}

		$block_information_arr 		= explode('~#~',$this->block_information[0]['path_information']);
		$block_step_information 	= $block_information_ele['step_information'];

		return $block_information_arr[$node-1];
	}

	public function saveNodeCoordinates($p_step_no,$p_coordinates) {
		$this->pfObject->saveNodeCoordinates($p_step_no,$p_coordinates);
	}
}
?>