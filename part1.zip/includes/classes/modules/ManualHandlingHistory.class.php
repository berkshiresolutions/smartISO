<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */

require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class ManualHandlingHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'manual_handling';
		$this->tables[] 		= 'manual_handling_actions';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _manual_handling() {

		$tablename 				= 'manual_handling';
		$tablename_historical 	= $tablename.'_historical';

		$sql = sprintf("INSERT INTO %s.".$tablename_historical."
					   (
					   
						ID
						,reference
						,uniqueReference
						,who
						,businessUnit
						,location
						,date
						,reviewDate
						,personsAffected
						,operationalInvolve
						,operationalInvolveAction
						,mechanizeOperation
						,mechanizeOperationAction
						,likelihood
						,impact
						,riskRating
						,riskRatingColor
						,processNo
						,isRiskValid
						,status
						,archive
						,subReference
					   )
						SELECT
						ID
						,reference
						,uniqueReference
						,who
						,businessUnit
						,location
						,date
						,reviewDate
						,personsAffected
						,operationalInvolve
						,operationalInvolveAction
						,mechanizeOperation
						,mechanizeOperationAction
						,likelihood
						,impact
						,riskRating
						,riskRatingColor
						,processNo
						,isRiskValid
						,status
						,archive
						,subReference
						FROM %s.".$tablename." WHERE ID = %d",
						_DB_OBJ_FULL,
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();
		
	$sql = sprintf("SELECT subReference FROM %s.manual_handling WHERE  ID = %d",_DB_OBJ_FULL,$this->recordId);

		//echo $sql;

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

	
		$result = $pStatement->fetchColumn();
		$this->subReference = $result;
	//dump_array($result);
	if($result == '' || $result == null){
		echo $upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = '1'
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
	}else{
		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1
					    WHERE ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
		
	}
	 
	}
	private function _manual_handling_actions() {

		$tablename 				= 'manual_handling_actions';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from incidence_participants
		 */
		$sql = sprintf("SELECT * FROM %s.".$tablename."
						WHERE manualID = %d",
						_DB_OBJ_FULL,
						$this->recordId);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$participant_data = $pStatement->fetch(PDO::FETCH_ASSOC);
        //  dump_array($participant_data);
		if ( !empty($participant_data) ) {
       
			$sql = sprintf("INSERT INTO %s.".$tablename_historical."
						   (
						    ID
							,manualID
							,sectionId
							,questionId
							,problem
							,actionID
							,subReference
						   ) VALUES (%d,%d,%d,%d,'%s',%d,%d)",
							_DB_OBJ_FULL,
							$participant_data['ID'],
							$participant_data['manualID'],
							$participant_data['sectionId'],
							$participant_data['questionId'],
							$participant_data['problem'],
							$participant_data['actionID'],
							$this->subReference);

				$pStatement = $this->dbHand->prepare($sql);
		        $pStatement->execute();
		}
	}
}