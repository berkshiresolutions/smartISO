<?php

/**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, November 03, 2010 12:25:00 PM>
 */
require_once "Incidence.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class IncidenceMain implements Incidence {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * property contains witness data
     * @access private
     */
    private $witnessData;

    /**
     * Property to hold Incidence Id
     * @access private
     */
    private $incidenceId;

    /**
     * Property to hold Incidence Info
     * @access private
     */
    private $incidenceInfo;

    /**
     * Constructor for initializing Incidence object
     * @access public
     */
    public function __construct() {


        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
        $this->accidentReportable = false;
    }

    /*
     * This method is used to set incidence information for the respective object
     */

    public function setIncidenceInfo($p_incidenceId, $p_incidenceInfo) {
        $this->incidenceId = $p_incidenceId;
        $this->incidenceInfo = $p_incidenceInfo;
    }

    /*
     * This method is used to add new incidence
     * reference,unique_reference,incidence_date,incidence_date_time,location,business_unit
     */

    public function addIncidence() {

       $sql = sprintf("SELECT * FROM %s.incidence WHERE reference LIKE '%s'", _DB_OBJ_FULL, $this->incidenceInfo['reference']);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (isset($resultSet["ID"])) {
            throw new ErrorException('Incidence with this Reference # already exists.');
        } else {

            $USER_ID = getLoggedInUserId();

   echo        $sql2 = sprintf("INSERT INTO %s.incidence (reference,uniqueReference,incidenceDateTime,locID,buID,driverTest,instructor,archive,status,whoID,
							accidentReportable,type,signature)
											VALUES ('%s','%s','%s',%d,%d,'%s',%d,'0','0',%d,'%s','%s',%d)", _DB_OBJ_FULL, $this->incidenceInfo['reference'], $this->incidenceInfo['unique_reference'], format_date_time_for_mysql($this->incidenceInfo['incidence_date']), $this->incidenceInfo['location'], $this->incidenceInfo['business_unit'], $this->incidenceInfo['driver_test'], $this->incidenceInfo['instructor_name'], $this->incidenceInfo['whoID'], $this->incidenceInfo['accident_reportable'], $this->incidenceInfo['type'], $this->incidenceInfo['check_sign']);
            $pStatement2 = $this->dbHand->prepare($sql2);

            /* $pStatement2->bindParam(1,$this->incidenceInfo['reference']);
              $pStatement2->bindParam(2,$this->incidenceInfo['unique_reference']);
              $pStatement2->bindParam(3,format_date_time_for_mysql($this->incidenceInfo['incidence_date']));
              $pStatement2->bindParam(4,$this->incidenceInfo['location']);
              $pStatement2->bindParam(5,$this->incidenceInfo['business_unit']); */

            $pStatement2->execute();
            //dump_array($pStatement2->errorInfo());
            $this->incidenceId = customLastInsertId($this->dbHand, 'incidence', 'ID');

            //$this->trackRecord();
        }
    }

    public function getLastInsertID() {
        return $this->incidenceId;
    }

    private function trackRecord() {
        $trackRec = new ModuleTracker();
        $trackRec->setModuleTrackerInfo('INCD', array('rec_id' => $this->incidenceId, 'role' => 'O', 'ref' => $this->incidenceInfo['reference']));
        $trackRec->trackRecord();
    }

    /*
     * This method is used to edit an incidence
     * incidence_date,location,business_unit
     */

    public function editIncidence() {

        $sql2 = sprintf("UPDATE %s.incidence SET incidenceDateTime = '%s',
										locID = %d,
										buID = %d,
										driverTest = %d,
										instructor = %d,
										accidentReportable = '%s',
										type = '%s',
										whoID = %d,
										signature = %d
									WHERE
										ID = %d", _DB_OBJ_FULL, format_date_time_for_mysql($this->incidenceInfo['incidence_date']), $this->incidenceInfo['location'], $this->incidenceInfo['business_unit'], $this->incidenceInfo['driver_test'], $this->incidenceInfo['instructor_name'], $this->incidenceInfo['accident_reportable'], $this->incidenceInfo['type'], $this->incidenceInfo['whoID'], $this->incidenceInfo['check_sign'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,format_date_time_for_mysql($this->incidenceInfo['incidence_date']));
          $pStatement2->bindParam(2,$this->incidenceInfo['location']);
          $pStatement2->bindParam(3,$this->incidenceInfo['business_unit']);
          $pStatement2->bindParam(4,$this->incidenceId); */

        $pStatement2->execute();
    }

    /*
     * This method is used to update incidence participant
     * is_participant,surname,forename,works_number,shift_work,gender
     */

    public function manageParticipantOld() {

        $sql2 = sprintf("UPDATE %s.incidence SET isParticipant = '%s',
										participantSurname = '%s',
										participantForename = '%s',
										participantWorksNumber = '%s',
										participantShiftWork = '%s',
										participantGender = '%s',
										rtwDate = '%s',
										absentDays = '%s',
										empType = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['is_participant'], $this->incidenceInfo['surname'], $this->incidenceInfo['forename'], $this->incidenceInfo['works_number'], $this->incidenceInfo['shift_work'], $this->incidenceInfo['gender'], $this->incidenceInfo['rtwDate'], $this->incidenceInfo['days_absent'], $this->incidenceInfo['type'], $this->incidenceId);


        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->incidenceInfo['is_participant']);
          $pStatement2->bindParam(2,$this->incidenceInfo['surname']);
          $pStatement2->bindParam(3,$this->incidenceInfo['forename']);
          $pStatement2->bindParam(4,$this->incidenceInfo['works_number']);
          $pStatement2->bindParam(5,$this->incidenceInfo['shift_work']);
          $pStatement2->bindParam(6,$this->incidenceInfo['gender']);
          $pStatement2->bindParam(7,$this->incidenceInfo['rtw_date']);
          $pStatement2->bindParam(8,$this->incidenceInfo['days_absent']);
          $pStatement2->bindParam(9,$this->incidenceId); */

        $pStatement2->execute();
        //dump_array($pStatement2->errorInfo());
    }

    /*
     * This method is used to update incidence activity
     * treatment,impact,accident,part_body,nature_injury,hazard_class,hazards,factor
     */

    public function manageActivity() {

        $sql2 = sprintf(" UPDATE %s.incidence SET activityTreatment = %d,
										activityImpact = %d,
										activityAccident = %d,
										activityPartBody = '%s',
										activityNatureInjury = '%s',
										activityHazardClass = %d,
										activityHazards = '%s',
										activityFactor = %d
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['treatment'], $this->incidenceInfo['impact'], $this->incidenceInfo['accident'], $this->incidenceInfo['part_body'], $this->incidenceInfo['nature_injury'], $this->incidenceInfo['hazard_class'], $this->incidenceInfo['hazards'], $this->incidenceInfo['factor'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        if (!$this->isAccidentReportable() && $this->incidenceInfo['accident_reportable']) {
            $this->markAccidentAsReportable();
        }
    }

    /**
     * This method is used to manage witness
     * witness = array(array('participant'=>'dfg','works_number'=>'gdfg','surname'=>'gdfg',
     * 							'forename'=>'dfg'f,'email'=>'gdfg','telephone'=>'dgdf','description'=>'sdf'),
     * 					array('participant'=>'dfg','works_number'=>'gdfg','surname'=>'gdfg',
     * 							'forename'=>'dfg'f,'email'=>'gdfg','telephone'=>'dgdf','description'=>'sdf'),
     * 					array('participant'=>'dfg','works_number'=>'gdfg','surname'=>'gdfg',
     * 							'forename'=>'dfg'f,'email'=>'gdfg','telephone'=>'dgdf','description'=>'sdf'));
     */
    public function manageWitness() {

        if (is_array($this->incidenceInfo['witness'])) {
            foreach ($this->incidenceInfo['witness'] as $value) {

                $this->witnessData = array('participant' => $value['participant'], 'works_number' => $value['works_number'], 'surname' => $value['surname'],
                    'forename' => $value['forename'], 'email' => $value['email'], 'telephone' => $value['telephone'],
                    'description' => $value['description']);
                if ($value['witness_id']) {
                    // do update
                    $this->editWitness($value['witness_id']);
                } else {
                    // do add
                    $this->addWitness();
                }
            }
        }

        $sql2 = sprintf(" UPDATE %s.incidence SET noWitness = '%s'
								WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['no_witness'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->incidenceInfo['no_witness']);
          $pStatement2->bindParam(2,$this->incidenceId); */

        $pStatement2->execute();
    }

    private function addWitness() {

        //$rtw_date = $this->witnessData['rtw_date'] == '' ? '' : format_date_for_mysql($this->witnessData['rtw_date']);

        $sql = sprintf("INSERT INTO %s.incidence_witness (incID,isParticipant,surname,forename,worksNumber,emailAddress,telephone,description)
										VALUES (%d,'%s','%s','%s','%s','%s','%s','%s') ", _DB_OBJ_FULL, $this->incidenceId, $this->witnessData['participant'], $this->witnessData['surname'], $this->witnessData['forename'], $this->witnessData['works_number'], $this->witnessData['email'], $this->witnessData['telephone'], $this->witnessData['description']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->incidenceId);
          $pStatement->bindParam(2,$this->witnessData['participant']);
          $pStatement->bindParam(3,$this->witnessData['surname']);
          $pStatement->bindParam(4,$this->witnessData['forename']);
          $pStatement->bindParam(5,$this->witnessData['works_number']);
          $pStatement->bindParam(6,$this->witnessData['email']);
          $pStatement->bindParam(7,$this->witnessData['telephone']);
          $pStatement->bindParam(8,$this->witnessData['description']);
          $pStatement->bindParam(9,$rtw_date);
          $pStatement->bindParam(10,$this->witnessData['absent_days']); */

        $pStatement->execute();
        /* $a = $pStatement->errorInfo();
          if ( $a[0] != '0000') {
          echo $sql;
          echo "<br/>";
          } */
    }

    private function editWitness($p_witness_id) {

        //echo $this->witnessData['rtw_date'];
        //$rtw_date = $this->witnessData['rtw_date'] == '' ? '' : format_date_for_mysql($this->witnessData['rtw_date']);
        //exit;

        $sql = sprintf("UPDATE %s.incidence_witness SET isParticipant = '%s',
											surname = '%s',
											forename = '%s',
											worksNumber = '%s',
											emailAddress = '%s',
											telephone = '%s',
											description = '%s'

										WHERE ID = %d", _DB_OBJ_FULL, $this->witnessData['participant'], $this->witnessData['surname'], $this->witnessData['forename'], $this->witnessData['works_number'], $this->witnessData['email'], $this->witnessData['telephone'], $this->witnessData['description'], $p_witness_id);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->witnessData['participant']);
          $pStatement->bindParam(2,$this->witnessData['surname']);
          $pStatement->bindParam(3,$this->witnessData['forename']);
          $pStatement->bindParam(4,$this->witnessData['works_number']);
          $pStatement->bindParam(5,$this->witnessData['email']);
          $pStatement->bindParam(6,$this->witnessData['telephone']);
          $pStatement->bindParam(7,$this->witnessData['description']);
          $pStatement->bindParam(8,$rtw_date);
          $pStatement->bindParam(9,$this->witnessData['absent_days']);
          $pStatement->bindParam(10,$p_witness_id); */

        /* dump_array($this->witnessData); */

        $pStatement->execute();
        /* dump_array($pStatement->errorInfo());
          exit; */
    }

    public function deleteWitness() {

        $sql = sprintf("DELETE FROM %s.incidence_witness WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['witness_id']);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);

        $pStatement->execute();
    }

    /*
     * This method is used to update incidence problem
     * description,detailed_description
     */

    public function manageProblem() {

       $sql2 = sprintf("UPDATE %s.incidence SET problemDescription = '%s',
            uploadFilesID = '%s',
										problemDetailedInvestigation = '%s',
                                                                               
										noInvestigationReqReason = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['description'],$this->incidenceInfo['file'], $this->incidenceInfo['detailed_description'], $this->incidenceInfo['no_di_reason'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->incidenceInfo['description']);
          $pStatement2->bindParam(2,$this->incidenceInfo['detailed_description']);
          $pStatement2->bindParam(3,$this->incidenceId); */

        $pStatement2->execute();
        
        
     
    }

    /**
     * This method is used to manage action
     * actions = array(array('description'=>'dfg','who'=>'gdfg','due_date'=>'gdfg'),
     * 					array('description'=>'dfg','who'=>'gdfg','due_date'=>'gdfg'),
     * 					array('description'=>'dfg','who'=>'gdfg','due_date'=>'gdfg'));
     */
    public function manageActions() {

        $action_array = $this->incidenceInfo['actions'];

        if (is_array($action_array)) {
            $actObj = new Action();
            $action_ids = "";
           
            foreach ($action_array as $actions) {

                $actionData = array('description' => $actions['action'],
                    'who' => $actions['who'],
                    'whoAU' => $actions['manager'],
                    'who2AU' => $actions['whoAU2'],
                    'module_name' => "Incidence",
                    'record' => $this->incidenceId,
                    'status' => 0,
                    'buname' => 0,
                    'element' => "incidence",
                    'currentwho' => $actions['who'],
                    'due_date' => $actions['when']);


                if ($actions['action_id'] == 0) {
                    $actObj->setActionDetails(0, $actionData);

                    $lastId = $actObj->addAction2015();
                } else {
                    $actObj->setActionDetails($actions['action_id'], $actionData);

                   $actObj->updateAction2015();
                   $lastId = $actions['action_id'];
                }


             

                    $action_ids .= $lastId . ',';

                    //}
                    // do update
                
            }

            $action_ids = rtrim($action_ids, ',');

            $sql2 = sprintf("UPDATE %s.incidence SET actionsID = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $action_ids, $this->incidenceId);

            $pStatement2 = $this->dbHand->prepare($sql2);

            /* $pStatement2->bindParam(1,$action_ids);
              $pStatement2->bindParam(2,$this->incidenceId); */

            $pStatement2->execute();
        }

        $sql3 = sprintf("UPDATE %s.incidence SET noActionReason = '%s',noAction = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['no_action_reason'], $this->incidenceInfo['no_action'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql3);

        $pStatement2->execute();
    }

    /*
     * This method is used to update incidence process
     * process,is_risk
     */

    public function manageProcess() {

        $sql2 = sprintf(" UPDATE %s.incidence SET processID = %d,
										isRiskValid = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['process'], $this->incidenceInfo['is_risk'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->incidenceInfo['process']);
          $pStatement2->bindParam(2,$this->incidenceInfo['is_risk']);
          $pStatement2->bindParam(3,$this->incidenceId); */

        $pStatement2->execute();
    }

    /*
     * This method is used to delete an incidence
     */

    public function deleteIncidence() {
        
    }

    /*
     * This method is used to archive an incidence record
     */

    public function archiveIncidence() {

        $sql2 = sprintf(" UPDATE %s.incidence SET archive = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['archive'], $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->incidenceInfo['archive']);
          $pStatement2->bindParam(2,$this->incidenceId); */

        $pStatement2->execute();
    }

    /*
     * This method is used to completely delete an incidence record
     */

    public function purgeIncidence() {
        $incidence_details = $this->viewIncidenceById();
        //dump_array($incidence_details);
        $action_arr = explode(',', $incidence_details['actionsID']);
        //dump_array($action_arr);

        if (is_array($action_arr)) {
            foreach ($action_arr as $value) {
                if ($value != '') {
                    $this->actionHandling->setActionDetails($value, "");
                    $this->actionHandling->deleteAction();
                }
            }
        }

        $sql = sprintf("DELETE FROM %s.incidence_participants WHERE incID = %d", _DB_OBJ_FULL, $this->incidenceId);

        $pStatement = $this->dbHand->prepare($sql);
        //	$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();

        $sql = sprintf("DELETE FROM %s.incidence_witness WHERE incID = %d", _DB_OBJ_FULL, $this->incidenceId);

        $pStatement = $this->dbHand->prepare($sql);
        //	$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();

        $sql2 = sprintf("DELETE FROM %s.incidence WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);
        //$pStatement2->bindParam(1,$this->incidenceId);
        $pStatement2->execute();

        /* to delete related investigations */
        $invObj = new InvestigationMain();

        $invObj->setInvestigationInfo(1, array('incidence_id' => $this->incidenceId));
        $inv_records = $invObj->viewInvestigationByIncidence();

        //dump_array($inv_records);

        if (is_array($inv_records)) {
            foreach ($inv_records as $value) {
                $invObj->setInvestigationInfo($value['ID'], "");
                $inv_records = $invObj->purgeInvestigation();
            }
        }
        /*         * ******************************* */
    }

    /*
     * This method is used to view an incidence record
     */

    public function viewIncidenceById() {

        if (isset($this->incidenceInfo['history']) && $this->incidenceInfo['history']>0) {

            $ref_array = explode(".", $this->incidenceInfo['ref']);
            $cmpref_array = explode(".", $this->incidenceInfo['cmpref']);
            $sub_reference = $ref_array[1];
            $cmp_sub_reference = $cmpref_array[1];

            if ($this->incidenceInfo['tables_involved'] == 2) {
                $sql = sprintf("(SELECT * FROM %s.incidence WHERE ID = %d) UNION ALL (SELECT * FROM %s.incidence_historical WHERE ID = %d and subReference = %d)", _DB_OBJ_FULL, $this->incidenceId, _DB_OBJ_FULL, $this->incidenceId, $cmp_sub_reference);
            } else {
                $sql = sprintf("SELECT * FROM %s.incidence_historical WHERE ID = %d AND subReference IN(%d,%d) ORDER BY subReference DESC", _DB_OBJ_FULL, $this->incidenceId, $sub_reference, $cmp_sub_reference);
            }
        } else {
            $sql = sprintf("SELECT * FROM %s.incidence WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceId);
        }

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if ($resultSet[0]['accidentReportable']) {
            $this->accidentReportable = true;
        }

        if (isset($this->incidenceInfo['history'])) {
            return $resultSet;
        } else {
            return $resultSet[0];
        }
    }

    /**
     * This method is used to get last insert id
     */
    public function lastRecordId() {
        return $this->incidenceId;
    }

    /*
     * This method is used to view incidence records
     * archive
     */

    public function viewIncidences() {

        //$sql = sprintf("SELECT * FROM %s.incidence WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->incidenceInfo['archive'] );

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.incidence A
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'INCD'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->incidenceInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceInfo['archive']);
        //dump_array($pStatement->errorInfo());
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view witness records
     */

    public function viewWitness() {

        $sql = sprintf("SELECT * FROM %s.incidence_witness WHERE incID = %d ORDER BY ID ASC", _DB_OBJ_FULL, $this->incidenceId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->bindParam(1, $this->incidenceId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view action records
     */

    public function viewActions() {

        $resultSet = $this->viewIncidenceById();

        $actions = $resultSet['actionsID'];

        if ($actions != '') {
            $actions_id_arr = explode(',', $actions);
            if (is_array($actions_id_arr)) {
                $i = 0;
                foreach ($actions_id_arr as $value) {
                    $this->actionHandling->setActionDetails($value, "");
                    $action_data = $this->actionHandling->viewAction();
                    if ($action_data) {
                        $action_details[$i] = $this->actionHandling->viewAction();
                        $action_details[$i]['action_id'] = $value;
                        $i++;
                    }
                }
                return $action_details;
            }
        }
    }

    public function getOutstandingActionsDepreciated($p_overdue) {

        if ($p_overdue) {
            $data = $this->actionHandling->viewOverdueActions('incidence');
        } else {
            $data = $this->actionHandling->viewAllActionByModule('incidence');
        }

        if (is_array($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT M.reference,M.buID,M.ID AS inc_id FROM %s.incidence M
											WHERE M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' ", _DB_OBJ_FULL, $search_value1, $search_value2, $search_value3, $search_value4);

                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$search_value1);
                  $pStatement->bindParam(2,$search_value2);
                  $pStatement->bindParam(3,$search_value3);
                  $pStatement->bindParam(4,$search_value4); */

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (is_array($action_data)) {

                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['buID'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                        $new_data[$i]['risk_id'] = $value2['inc_id'];
                    }
                    $i++;
                }
            }
        }
        return $new_data;
    }

    public function addOutstandingAction() {

        $sql = sprintf("SELECT actionsID FROM %s.incidence WHERE ID = %d ", _DB_OBJ_FULL, $this->incidenceId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();

        $improvements = $pStatement->fetchColumn();
        $new_improvements = $improvements . ',' . $this->incidenceInfo['new_improvement'];

        $sql2 = sprintf("UPDATE %s.incidence SET actionsID = %d WHERE ID = %d ", _DB_OBJ_FULL, $new_improvements, $this->incidenceId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$new_improvements);
          $pStatement2->bindParam(2,$this->incidenceId); */
        $pStatement2->execute();
    }

    public function getNoOfAccidents() {

        $sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0' ", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);

                if ($row['activityAccident']) {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }

        return $result_set;
    }

    public function get_main_hazard($p_hazard_id) {

        $hazards_id_arr = explode(',', $p_hazard_id);
        $sql = "SELECT primaryHazard FROM %s.hazard_parent_classification WHERE ID = %d ";

        if (is_array($hazards_id_arr)) {
            foreach ($hazards_id_arr as $value_id) {

                $sql_p = sprintf($sql, _DB_OBJ_FULL, $value_id);
                $pStatement = $this->db_handle->prepare($sql_p);
                //$pStatement->bindParam(1,$value_id);
                $pStatement->execute();
                $hazards .= $pStatement->fetchColumn() . ', ';
            }
        }
        return rtrim($hazards, ', ');
    }

    public function primaryHazard() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row['hazardClassificationID']);



                $date_time = $row['incidenceDateTime'];
                $year = $row['hazardClassificationID'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function controlData() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row['controlAtSource']);



                $date_time = $row['incidenceDateTime'];
                $year = $row['controlAtWorker'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function impData() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row['controlAtSource']);



                $date_time = $row['incidenceDateTime'];
                $year = $row['improvementAlongPath'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function impData1() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row['controlAtSource']);



                $date_time = $row['incidenceDateTime'];
                $year = $row['improvementAtWorker'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function impData2() {
        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row['controlAtSource']);



                $date_time = $row['incidenceDateTime'];
                $year = $row['improvementAtSource'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function pathData() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {




                $date_time = $row['incidenceDateTime'];
                $year = $row['controlAlongPath'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function sourceData() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {




                $date_time = $row['incidenceDateTime'];
                $year = $row['controlAtSource'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function secondaryHazard() {

        $sql = sprintf("SELECT R.*,S.reference,S.* FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row['hazardClassificationID']);



                $date_time = $row['incidenceDateTime'];
                $year = $row['secondaryHazardID'];
                $bu_id = $row['buID'];

                $result_set[$bu_id][$year] ++;
            }
        }
        // dump_array($result_set);
        return $result_set;
    }

    public function getcmFinish() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE cmApproved=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getmaFinish() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE maApproved=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getdaFinish() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE daApproved=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getcmFinishq1() {

        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE cmApproved =1 AND shortTermOrTender=0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getmaFinishq1() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE maApproved =1 AND shortTermOrTender=0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getdaFinishq1() {

        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE daApproved =1 AND shortTermOrTender=0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }


        //dump_array($result_set);

        return $result_set;
    }

    public function getcmFinishq2() {

        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE cmApproved =1 AND shortTermOrTender=1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getcmFinishq3() {

        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE cmApproved =1 AND shortTermOrTender=2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getmaFinishq2() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE maApproved =1 AND shortTermOrTender=1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getmaFinishq3() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE maApproved =1 AND shortTermOrTender=2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getdafinishq2() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE daApproved =1 AND shortTermOrTender=1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getdafinishq3() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE daApproved =1 AND shortTermOrTender=2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {


                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == 1 && $row['archive'] == '0') {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }
        //dump_array($result_set);

        return $result_set;
    }

    public function getcmStarted() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate IS NULL ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] || $row['cmRejected']) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getStarted() {


        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                // dump_array($row);
                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewCompleteDate'] == NULL && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }

        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                //echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                $no_rows = $pStatement->rowCount();
                if ($no_rows) {
                    while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                        // dump_array($row);
                        // echo   $count = count($row);
                        $bu_id = $row['buID'];
                        //$date_time = $row['incidenceDateTime'];
                        $year = '2';

                        if ($row['reviewDueDate'] && $row['archive'] == '0') {
                            //echo "sfsdfsdf";
                            $result_set[$year][$bu_id] ++;
                            //dump_array($res_set);
                        }
                    }
                }
            }
        }




        return $result_set;
    }

    public function getshortq1() {




        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender =0 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row);
                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewCompleteDate'] == NULL && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }

        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re_short = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re_short == '' || $re_short == NULL) {

                //echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val . " AND shortTermOrTender =0", _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                $no_rows = $pStatement->rowCount();
                if ($no_rows) {
                    while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                        // dump_array($row);
                        // echo   $count = count($row);
                        $bu_id = $row['buID'];
                        //$date_time = $row['incidenceDateTime'];
                        $year = '2';

                        if ($row['reviewDueDate'] && $row['archive'] == '0') {
                            //echo "sfsdfsdf";
                            $result_set[$year][$bu_id] ++;
                            //dump_array($res_set);
                        }
                    }
                }
            }
        }




        return $result_set;
    }

    public function getshortq2() {





        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender =1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row);
                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewCompleteDate'] == NULL && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }

        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                //echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val . " AND shortTermOrTender =1", _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                $no_rows = $pStatement->rowCount();
                if ($no_rows) {
                    while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                        // dump_array($row);
                        // echo   $count = count($row);
                        $bu_id = $row['buID'];
                        //$date_time = $row['incidenceDateTime'];
                        $year = '2';

                        if ($row['reviewDueDate'] && $row['archive'] == '0') {
                            //echo "sfsdfsdf";
                            $result_set[$year][$bu_id] ++;
                            //dump_array($res_set);
                        }
                    }
                }
            }
        }




        return $result_set;
    }

    public function getshortq3() {





        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender =2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row);
                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewCompleteDate'] == NULL && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }

        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                //echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val . " AND shortTermOrTender =2", _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                $no_rows = $pStatement->rowCount();
                if ($no_rows) {
                    while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                        // dump_array($row);
                        // echo   $count = count($row);
                        $bu_id = $row['buID'];
                        //$date_time = $row['incidenceDateTime'];
                        $year = '2';

                        if ($row['reviewDueDate'] && $row['archive'] == '0') {
                            //echo "sfsdfsdf";
                            $result_set[$year][$bu_id] ++;
                            //dump_array($res_set);
                        }
                    }
                }
            }
        }




        return $result_set;
    }

    public function getcmStartedq1() {
        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=0  ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] || $row['cmRejected'] || $row['cmFinished']) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getcmStartedq2() {
        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] || $row['cmRejected'] || $row['cmFinished']) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getcmStartedq3() {
        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] || $row['cmRejected'] || $row['cmFinished']) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaStartedq1() {

        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=0 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['cmApproved'] == '1' && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaStartedq2() {

        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaStartedq3() {

        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaStarted() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND maApproved IS NULL AND maRejected IS NULL AND cmApproved =1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0' && $row['cmApproved'] == 1) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getdaStartedq1() {

        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=0 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getdaStartedq2() {

        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getdaStartedq3() {

        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL AND shortTermOrTender=2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getdaStarted() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate IS NULL ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0' && $row['cmApproved'] == 1 && $row['maApproved'] == 1) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getcmOverdue() {
        $today = date("Y-m-d");

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        //$no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $year = $row['quarterCovered'];
            //  echo $row['reviewDate'];
            if ($row['reviewEndDate'] <= $today && $row['archive'] == '0' && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //dump_array($result_set);
            }
        }
        //}


        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                // echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                //$no_rows = $pStatement->rowCount();
                // if ( $no_rows ) {
                while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                    //dump_array($row);
                    // echo   $count = count($row);
                    $bu_id = $row['buID'];
                    //$date_time = $row['incidenceDateTime'];
                    $year = '3';

                    if ($row['startDate'] <= $today && $row['archive'] == '0') {
                        //echo "sfsdfsdf";
                        $result_set[$year][$bu_id] ++;
                        //dump_array($res_set);
                    }
                }
                //}
            }
            // dump_array($result_set);	
        }


        return $result_set;
    }

    public function getOverdue() {
        $today = date("Y-m-d");

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        //$no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $year = $row['quarterCovered'];
            //  echo $row['reviewDate'];
            if ($row['reviewEndDate'] <= $today && $row['archive'] == '0') {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //dump_array($result_set);
            }
        }
        //}


        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                // echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                //$no_rows = $pStatement->rowCount();
                // if ( $no_rows ) {
                while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                    //dump_array($row);
                    // echo   $count = count($row);
                    $bu_id = $row['buID'];
                    //$date_time = $row['incidenceDateTime'];
                    $year = '3';

                    if ($row['startDate'] <= $today && $row['archive'] == '0') {
                        //echo "sfsdfsdf";
                        $result_set[$year][$bu_id] ++;
                        //dump_array($res_set);
                    }
                }
                //}
            }
            // dump_array($result_set);	
        }


        return $result_set;
    }

    public function getcmOverdueq1() {
        $today = date("Y-m-d");
        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=0 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getOverdueq1() {
        $today = date("Y-m-d");
        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getOverdueq2() {
        $today = date("Y-m-d");
        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getOverdueq3() {
        $today = date("Y-m-d");
        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getcmOverdueq2() {
        $today = date("Y-m-d");
        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getcmOverdueq3() {
        $today = date("Y-m-d");
        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['cmApproved'] == NULL && $row['cmRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaOverdueq1() {
        $today = date("Y-m-d");
        $start = '2012-01-01';
        $end = '2012-03-31';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate is NULL AND shortTermOrTender=0 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaOverdueq2() {
        $today = date("Y-m-d");
        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaOverdueq3() {
        $today = date("Y-m-d");
        $start = '2012-04-01';
        $end = '2012-06-30';

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['maApproved'] == NULL && $row['maRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getmaOverdue() {
        $today = date("Y-m-d");

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        //$no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $year = $row['quarterCovered'];
            //  echo $row['reviewDate'];
            if ($row['reviewEndDate'] <= $today && $row['archive'] == '0' && $row['maApproved'] == NULL && $row['maRejected'] == NULL) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //dump_array($result_set);
            }
        }
        //}


        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                // echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                //$no_rows = $pStatement->rowCount();
                // if ( $no_rows ) {
                while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                    //dump_array($row);
                    // echo   $count = count($row);
                    $bu_id = $row['buID'];
                    //$date_time = $row['incidenceDateTime'];
                    $year = '3';

                    if ($row['startDate'] <= $today && $row['archive'] == '0') {
                        //echo "sfsdfsdf";
                        $result_set[$year][$bu_id] ++;
                        //dump_array($res_set);
                    }
                }
                //}
            }
            // dump_array($result_set);	
        }


        return $result_set;
    }

    public function getdaOverdue() {
        $today = date("Y-m-d");

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        //$no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $year = $row['quarterCovered'];
            //  echo $row['reviewDate'];
            if ($row['reviewEndDate'] <= $today && $row['archive'] == '0' && $row['daApproved'] == NULL && $row['daRejected'] == NULL) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //dump_array($result_set);
            }
        }
        //}


        $sql1 = sprintf("SELECT ID FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            // dump_array($val);

            $this->val = $val['ID'];

            $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql2);

            $pStatement->execute();

            $re = $pStatement->fetch(PDO::FETCH_ASSOC);
            //dump_array($re);
            if ($re == '') {

                // echo $this->val;
                $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql3);
                $pStatement->execute();

                //$no_rows = $pStatement->rowCount();
                // if ( $no_rows ) {
                while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                    //dump_array($row);
                    // echo   $count = count($row);
                    $bu_id = $row['buID'];
                    //$date_time = $row['incidenceDateTime'];
                    $year = '3';

                    if ($row['startDate'] <= $today && $row['archive'] == '0') {
                        //echo "sfsdfsdf";
                        $result_set[$year][$bu_id] ++;
                        //dump_array($res_set);
                    }
                }
                //}
            }
            // dump_array($result_set);	
        }


        return $result_set;
    }

    public function getdaOverdueq1() {
        $today = date("Y-m-d");
        $start = '2012-01-01';
        $end = '2012-03-31';
        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=0 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['daApproved'] == NULL && $row['daRejected'] == NULL && $row['archive'] == '0') {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getdaOverdueq2() {
        $today = date("Y-m-d");
        $start = '2012-04-01';
        $end = '2012-06-30';
        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['daApproved'] == NULL && $row['daRejected'] == NULL) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getdaOverdueq3() {
        $today = date("Y-m-d");
        $start = '2012-04-01';
        $end = '2012-06-30';
        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE reviewCompleteDate is NULL AND shortTermOrTender=2 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];

                if ($row['reviewEndDate'] <= $today && $row['daApproved'] == NULL && $row['daRejected'] == NULL) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getAllContract() {

        $sql = sprintf("SELECT C.ID,score_average,review_ID,contractID,N.shortTermOrTender,buID,contractName FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        //dump_array($result_set);
        return $result;
    }

    public function getAllActiveContractors() {

        $sql = sprintf("SELECT C.* FROM %s.contractor C
												INNER JOIN %s.contract N
											ON N.useApprovedContractor = C.ID ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        //dump_array($result_set);
        return $result;
    }

    public function getBUContract() {

        $sql = sprintf("SELECT C.ID,score_average,review_ID,contractID,N.shortTermOrTender,buID,contractName FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE buID=" . $this->incidenceInfo['id'], _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        //dump_array($result_set);
        return $result;
    }

    public function getquestiondata($name) {

        $this->name = $name;
        $sql = sprintf("SELECT C.review_ID,f1f2,quarterCovered,N.archive,shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE contractID =" . $this->name, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        //dump_array($result);
        $count = count($result);
        //echo $result['f1f2'];
        //echo $no_rows ;
        $c = 0;
        foreach ($result as $val) {

            if ($val['f1f2'] == 2) {
                $arr = $c + 1;
            }
        }
        //echo $arr;
        $c = count($result);
        
        foreach ($result as $value) {
            if ($value['archive'] == 0) {
                //dump_array($value['archive']);

                $sql = sprintf("SELECT * FROM %s.contract_actions WHERE contractreviewID =" . $value['review_ID'], _DB_OBJ_FULL);
                $pStatement = $this->dbHand->prepare($sql);
                $pStatement->execute();

                $no_rows = $pStatement->rowCount();

                //echo $no_rows ;
                //if ( $no_rows ) {
                while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                    // dump_array($row);
                    $count = count($row);
                    $bu_id = $row['buID'];
                    //$date_time = $row['incidenceDateTime'];
                    $score = $row['score'];

                    $year = $value['quarterCovered'];
                    $question = $row['questionId'];

                    if ($question == 1) {
                        //echo "sfsdfsdf";
                        $result_set['product'] += (int) $score;
                        //
                    }
                    if ($question == 2) {
                        //echo "sfsdfsdf";
                        $result_set['serv'] += (int) $score;
                        //
                    }
                    if ($question == 3) {
                        //echo "sfsdfsdf";
                        $result_set['ontime'] += (int) $score;
                        //
                    }
                    if ($question == 4) {
                        //echo "sfsdfsdf";
                        $result_set['knowledge'] += (int) $score;
                        //
                    }
                    if ($question == 5) {
                        //echo "sfsdfsdf";
                        $result_set['reputation'] += (int) $score;
                        //
                    }
                    if ($question == 6) {
                        //echo "sfsdfsdf";
                        $result_set['customer'] += (int) $score;
                        //
                    }
                    if ($question == 7) {
                        //echo "sfsdfsdf";
                        $result_set['service'] += (int) $score;
                        //
                    }
                    if ($question == 8) {
                        //echo "sfsdfsdf";
                        $result_set['response'] += (int) $score;
                        //
                    }
                    if ($question == 9) {
                        //echo "sfsdfsdf";
                        $result_set['hazard'] += (int) $score;
                        //
                    }
                    //	exit;
                }
                //}
            }
        }

        $result_set['product'] = $result_set['product'] / $c;
        $result_set['serv'] = $result_set['serv'] / $c;
        $result_set['ontime'] = $result_set['ontime'] / $c;
        $result_set['knowledge'] = $result_set['knowledge'] / $c;
        $result_set['reputation'] = $result_set['reputation'] / $c;
        $result_set['customer'] = $result_set['customer'] / $c;
        $result_set['service'] = $result_set['service'] / $c;
        $result_set['response'] = $result_set['response'] / $c;
        $result_set['hazard'] = $result_set['hazard'] / $arr;

        //dump_array($result_set);
        return $result_set;
    }

    public function getnotstartedname() {

        $sql = sprintf("SELECT C.*,N.contractManagerID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate IS NULL ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);


        $i = 0;

        foreach ($result as $val) {

            if ($val['reviewCompleteDate'] == NULL && $val['cmApproved'] == NULL && $val['cmRejected'] == NULL && $val['maApproved'] == NULL && $row['maRejected'] == NULL && $val['daApproved'] == NULL && $val['daRejected'] == NULL && $val['archive'] == '0') {

                $id = $val['contractManagerID'];
                $buID = $val['buID'];
                $year = $val['quarterCovered'];
                //  echo  $arc = $val['archive'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buID] ++;
                    //
                }
            }
            //dump_array($result_set);
            //return $result_set;
        }


        $sql1 = sprintf("SELECT ID,archive FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        foreach ($result as $val) {
            if ($val['archive'] == 0) {

                // dump_array($val);

                $this->val = $val['ID'];

                $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql2);

                $pStatement->execute();

                $re = $pStatement->fetch(PDO::FETCH_ASSOC);
                //dump_array($re);
                if ($re == '') {

                    //echo $this->val;
                    $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                    $pStatement = $this->dbHand->prepare($sql3);
                    $pStatement->execute();

                    $no_rows = $pStatement->rowCount();
                    if ($no_rows) {
                        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                            $id = $row['contractManagerID'];
                            $buID = $row['buID'];
                            //$year = $row['quarterCovered'];
                            //  echo  $arc = $val['archive'];

                            $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                            $pStatement = $this->dbHand->prepare($sql);

                            $pStatement->execute();

                            $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                            $name = $res['forename'] . '' . $res['surname'];

                            if ($name) {
                                //echo "sfsdfsdf";
                                //$result_set[$name][$buID][1]++;	
                                //$result_set[$name][$buID]++;
                                $result_set[$name][$buID] ++;
                                //$result_set[$name][$buID][4]++;
                            //
		}
                        }
                    }
                }
            }
        }


        //dump_array($result_set);

        return $result_set;
    }

    public function getmanotstartedname() {

        $sql = sprintf("SELECT C.*,N.managerApproverID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate IS NULL AND maApproved IS NULL AND maRejected IS NULL AND cmApproved =1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0) {

                $id = $val['managerApproverID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        return $result_set;
    }

    public function getdanotstartedname() {

        $sql = sprintf("SELECT C.*,N.directorApproverID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate IS NULL AND daApproved IS NULL AND daRejected IS NULL AND maApproved= 1 AND cmApproved= 1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0) {

                $id = $val['directorApproverID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        return $result_set;
    }

    public function getcompletedname() {

        $sql = sprintf("SELECT C.*,N.contractManagerID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE cmApproved= 1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0) {

                $id = $val['contractManagerID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        return $result_set;
    }

    public function getmacompletedname() {

        $sql = sprintf("SELECT C.*,N.managerApproverID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE maApproved= 1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0) {

                $id = $val['managerApproverID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        return $result_set;
    }

    public function getdacompletedname() {

        $sql = sprintf("SELECT C.*,N.directorApproverID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE daApproved= 1 ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0) {

                $id = $val['directorApproverID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        return $result_set;
    }

    public function getovername() {

        $today = date("Y-m-d");
        $sql = sprintf("SELECT C.*,N.contractManagerID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0 && $val['reviewEndDate'] <= $today && $val['cmApproved'] == NULL && $val['cmRejected'] == NULL) {
                //dump_array($val['contractManagerID']);
                $id = $val['contractManagerID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        //return $result_set;

        $sql1 = sprintf("SELECT * FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        //dump_array($result);
        foreach ($result as $val) {
            if ($val['archive'] == 0 && $val['startDate'] <= $today) {

                // dump_array($val);

                $this->val = $val['ID'];

                $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql2);

                $pStatement->execute();

                $re = $pStatement->fetch(PDO::FETCH_ASSOC);
                //dump_array($re);
                if ($re == '') {

                    //echo $this->val;
                    $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                    $pStatement = $this->dbHand->prepare($sql3);
                    $pStatement->execute();

                    $no_rows = $pStatement->rowCount();
                    if ($no_rows) {
                        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                            $id = $row['contractManagerID'];
                            $buID = $row['buID'];
                            //$year = $row['quarterCovered'];
                            //  echo  $arc = $val['archive'];

                            $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                            $pStatement = $this->dbHand->prepare($sql);

                            $pStatement->execute();

                            $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                            $name = $res['forename'] . '' . $res['surname'];

                            if ($name) {
                                //echo "sfsdfsdf";
                                //$result_set[$name][$buID][1]++;	
                                //$result_set[$name][$buID]++;
                                $result_set[$name][$buID][3] ++;
                                //$result_set[$name][$buID][4]++;
                            //
		}
                        }
                    }
                }
            }
        }


        //dump_array($result_set);

        return $result_set;
    }

    public function getmaovername() {

        $today = date("Y-m-d");
        $sql = sprintf("SELECT C.*,N.managerApproverID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0 && $val['reviewEndDate'] <= $today && $val['maApproved'] == NULL && $val['maRejected'] == NULL) {
                //dump_array($val['contractManagerID']);
                $id = $val['managerApproverID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        //return $result_set;

        $sql1 = sprintf("SELECT * FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        //dump_array($result);
        foreach ($result as $val) {
            if ($val['archive'] == 0 && $val['startDate'] <= $today) {

                // dump_array($val);

                $this->val = $val['ID'];

                $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql2);

                $pStatement->execute();

                $re = $pStatement->fetch(PDO::FETCH_ASSOC);
                //dump_array($re);
                if ($re == '') {

                    //echo $this->val;
                    $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                    $pStatement = $this->dbHand->prepare($sql3);
                    $pStatement->execute();

                    $no_rows = $pStatement->rowCount();
                    if ($no_rows) {
                        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                            $id = $row['managerApproverID'];
                            $buID = $row['buID'];
                            //$year = $row['quarterCovered'];
                            //  echo  $arc = $val['archive'];

                            $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                            $pStatement = $this->dbHand->prepare($sql);

                            $pStatement->execute();

                            $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                            $name = $res['forename'] . '' . $res['surname'];

                            if ($name) {
                                //echo "sfsdfsdf";
                                //$result_set[$name][$buID][1]++;	
                                //$result_set[$name][$buID]++;
                                $result_set[$name][$buID][3] ++;
                                //$result_set[$name][$buID][4]++;
                            //
		}
                        }
                    }
                }
            }
        }


        //dump_array($result_set);

        return $result_set;
    }

    public function getdaovername() {

        $today = date("Y-m-d");
        $sql = sprintf("SELECT C.*,N.directorApproverID,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID  WHERE reviewCompleteDate is NULL", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        //dump_array($result);

        $i = 0;
        foreach ($result as $val) {
            if ($val['archive'] == 0 && $val['reviewEndDate'] <= $today && $val['daApproved'] == NULL && $val['daRejected'] == NULL) {
                //dump_array($val['contractManagerID']);
                $id = $val['directorApproverID'];
                $buid = $val['buID'];
                $year = $val['quarterCovered'];

                $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql);

                $pStatement->execute();

                $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                $name = $res['forename'] . '' . $res['surname'];

                if ($name) {
                    //echo "sfsdfsdf";
                    $result_set[$name][$buid][$year] ++;
                    //
                }
            }
        }
        //dump_array($result_set);
        //return $result_set;

        $sql1 = sprintf("SELECT * FROM %s.contract ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql1);

        $pStatement->execute();

        $result = $pStatement->fetchALL(PDO::FETCH_ASSOC);
        //dump_array($result);
        foreach ($result as $val) {
            if ($val['archive'] == 0 && $val['startDate'] <= $today) {

                // dump_array($val);

                $this->val = $val['ID'];

                $sql2 = sprintf("SELECT contractID FROM %s.contract_review WHERE contractID =" . $this->val, _DB_OBJ_FULL);

                $pStatement = $this->dbHand->prepare($sql2);

                $pStatement->execute();

                $re = $pStatement->fetch(PDO::FETCH_ASSOC);
                //dump_array($re);
                if ($re == '') {

                    //echo $this->val;
                    $sql3 = sprintf("SELECT * FROM %s.contract WHERE ID =" . $this->val, _DB_OBJ_FULL);
                    $pStatement = $this->dbHand->prepare($sql3);
                    $pStatement->execute();

                    $no_rows = $pStatement->rowCount();
                    if ($no_rows) {
                        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                            $id = $row['directorApproverID'];
                            $buID = $row['buID'];
                            //$year = $row['quarterCovered'];
                            //  echo  $arc = $val['archive'];

                            $sql = sprintf("SELECT surname,forename FROM %s.participant_database WHERE participantID = " . $id, _DB_OBJ_FULL);

                            $pStatement = $this->dbHand->prepare($sql);

                            $pStatement->execute();

                            $res = $pStatement->fetch(PDO::FETCH_ASSOC);


                            $name = $res['forename'] . '' . $res['surname'];

                            if ($name) {
                                //echo "sfsdfsdf";
                                //$result_set[$name][$buID][1]++;	
                                //$result_set[$name][$buID]++;
                                $result_set[$name][$buID][3] ++;
                                //$result_set[$name][$buID][4]++;
                            //
		}
                        }
                    }
                }
            }
        }


        //dump_array($result_set);

        return $result_set;
    }

    public function contractaveragedata($name) {

        $this->name = $name;

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE contractID =" . $this->name, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
            //dump_array($row);
            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $average = $row['score_average'];
            $year = $row['quarterCovered'];
            //$last =($average/8);
            // echo $last;
            $get = 'first';
            $get_sec = 'sec';
            $get_thr = 'three';
            $archive = $row['archive'];
            if ($average < 2.5 && $archive == 0) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //
            }
        }
        //}
        //dump_array($result_set);
        return $result_set;
    }

    public function contractaveragedataFirst($name) {

        $this->name = $name;

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE contractID =" . $this->name, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $average = $row['score_average'];
            $year = $row['quarterCovered'];
            //$last =($average/8);
            // echo $last;
            $get = 'first';
            $get_sec = 'sec';
            $get_thr = 'three';
            $archive = $row['archive'];
            if ($average <= 3.5 && $average >= 2.5 && $archive == 0) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //
            }
        }
        //}
        //dump_array($result_set);
        return $result_set;
    }

    public function contractaveragedataSec($name) {

        $this->name = $name;

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE contractID =" . $this->name, _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $average = $row['score_average'];
            $year = $row['quarterCovered'];
            //$last =($average/8);
            // echo $last;
            $archive = $row['archive'];
            $get = 'first';
            $get_sec = 'sec';
            $get_thr = 'three';
            if ($average > 3.5 && $archive == 0) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //
            }
        }
        //}
        //dump_array($result_set);
        return $result_set;
    }

    public function getAverage() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        //if ( $no_rows ) {
        while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

            // echo   $count = count($row);
            $bu_id = $row['buID'];
            //$date_time = $row['incidenceDateTime'];
            $average = $row['score_average'];
            $year = $row['quarterCovered'];
            //$last =($average/8);
            // echo $last;
            $archive = $row['archive'];
            if ($average < 2.5 && $archive == 0) {
                //echo "sfsdfsdf";
                $result_set[$year][$bu_id] ++;
                //
            }
        }
        //}
        //dump_array($result_set);
        return $result_set;
    }

    public function getAverage1() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                //$last =($average/8);
                //echo $last;
                $archive = $row['archive'];
                if ($average <= 3.5 && $average >= 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getAverage2() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID ", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                $archive = $row['archive'];
                //echo $last;
                if ($average > 3.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getShortAverage() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender=0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                //echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                $archive = $row['archive'];
                // echo $last;
                if ($average <= 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //
                }
            }
        }

        //dump_array($result_set);
        return $result_set;
    }

    public function getShortAverage1() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender = 0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                $archive = $row['archive'];
                //echo $last;
                if ($average < 3.5 && $average > 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getShortAverage2() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender=0", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                $archive = $row['archive'];
                //echo $last;
                if ($average > 3.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getOJEUAverage() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender=2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                $archive = $row['archive'];
                // echo $last;
                if ($average < 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //
                }
            }
        }

        //dump_array($result_set);
        return $result_set;
    }

    public function getOJEUAverage1() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender = 2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                //$last =($average/8);
                //echo $last;
                $archive = $row['archive'];
                if ($average < 3.5 && $average > 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getOJEUAverage2() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender=2", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];
                $average = $row['score_average'];

                //$last =($average/8);
                //echo $last;
                $archive = $row['archive'];
                if ($average > 3.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getTenderAverage() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender=1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                $archive = $row['archive'];
                // echo $last;
                if ($average < 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //
                }
            }
        }

        //dump_array($result_set);
        return $result_set;
    }

    public function getTenderAverage1() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender = 1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $average = $row['score_average'];
                $year = $row['quarterCovered'];
                //$last =($average/8);
                //echo $last;
                $archive = $row['archive'];
                if ($average < 3.5 && $average > 2.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getTenderAverage2() {

        $sql = sprintf("SELECT C.*,N.shortTermOrTender,buID FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID WHERE shortTermOrTender=1", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        //echo $no_rows ;
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                // echo   $count = count($row);
                $bu_id = $row['buID'];
                //$date_time = $row['incidenceDateTime'];
                $year = $row['quarterCovered'];
                $average = $row['score_average'];

                //$last =($average/8);
                //echo $last;
                $archive = $row['archive'];
                if ($average > 3.5 && $archive == 0) {
                    //echo "sfsdfsdf";
                    $result_set[$year][$bu_id] ++;
                    //dump_array($result_set);
                }
            }
        }


        return $result_set;
    }

    public function getNoOfViolenceIncidence() {

        $sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0' ", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);

                // 306 is id for violence and aggression
                if ($row['activityHazards'] == 306) {
                    $result_set[$year][$bu_id] ++;
                }
            }
        }

        return $result_set;
    }

    public function getNoOfParticipants() {

        $sql = sprintf("SELECT C.*,N.* FROM %s.incidence C
												INNER JOIN %s.incidence_participants N
											ON N.incID = C.ID WHERE archive='0'", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);

                if ($row['participantShiftWork']) {
                    $result_set['shift_work'][$year][$bu_id]['Y'] ++;
                } else {
                    $result_set['shift_work'][$year][$bu_id]['N'] ++;
                }
                //echo $row['participantGender']."<br/>";
                if ($row['gender'] == 'M' || $row['gender'] == 'm') {
                    $result_set['gender'][$year][$bu_id]['M'] ++;
                } else if ($row['gender'] == 'F' || $row['gender'] == 'f') {
                    $result_set['gender'][$year][$bu_id]['F'] ++;
                }

                if ($row['empType']) {
                    $nam = $row['empType'];
                    $result_set['empType'][$year][$bu_id][$nam] ++;
                }
            }

            return $result_set;
        }
    }

    public function getNoOfActions() {

        $sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0'", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);

                if ($row['actionsID'] != '') {

                    $action_count = explode(',', $row['actionsID']);
                    if (count($action_count)) {
                        $result_set[$year][$bu_id] += count($action_count);
                    }
                }
            }

            return $result_set;
        }
    }

    public function getNoOfActivities() {

        $sql = sprintf("SELECT C.*,N.* FROM %s.incidence C
												INNER JOIN %s.incidence_participants N
											ON N.incID = C.ID WHERE archive='0'", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);

                /* for body parts */
                if ($row['activityPartBody'] != '') {

                    $parts = explode(',', $row['activityPartBody']);
                    if (count($parts)) {
                        foreach ($parts as $value) {
                            $result_set['body_part'][$year][$bu_id][$value] ++;
                        }
                    }
                } // end if

                /* for nature of injury */
                if ($row['activityNatureInjury'] != '') {

                    $nature_injury = explode(',', $row['activityNatureInjury']);
                    if (count($nature_injury)) {
                        foreach ($nature_injury as $value) {
                            $result_set['injury'][$year][$bu_id][$value] ++;
                        }
                    }
                } // end if

                /* for treatment */
                if ($row['activityTreatment']) {

                    $treatment = $row['activityTreatment'];
                    $result_set['treatment'][$year][$bu_id][$treatment] ++;
                } // end if
                if ($row['empType']) {

                    $empType = $row['empType'];
                    $result_set['empType'][$year][$bu_id][$empType] ++;
                } // end if

                /* for accident */
                if ($row['activityAccident']) {

                    $treatment = $row['activityAccident'];
                    $result_set['accident'][$year][$bu_id][$treatment] ++;
                } // end if

                /* for accident */
                if ($row['activityImpact']) {

                    $activity = $row['activityImpact'];
                    $result_set['impact'][$year][$bu_id][$activity] ++;
                } // end if

                /* for hazard classification */
                if ($row['activityHazardClass']) {

                    $hazard_class = $row['activityHazardClass'];
                    $result_set['hazard_class'][$year][$bu_id][$hazard_class] ++;
                } // end if

                /* for hazards of injury */
                if ($row['activityHazards'] != '') {

                    $hazards = explode(',', $row['activityHazards']);
                    if (count($hazards)) {
                        foreach ($hazards as $value) {
                            $result_set['hazards'][$year][$bu_id][$value] ++;
                        }
                    }
                } // end if
            }


            return $result_set;
        }
    }

    public function getIncidenceBySearch() {

        $search_filter = '';
        $date_filter = '';

        if ($this->incidenceInfo['reference'] != '') {

            if ($search_filter == '') {
                $search_filter = " WHERE reference = '" . $this->incidenceInfo['reference'] . "'";
            } else {
                $search_filter .= " AND reference = '" . $this->incidenceInfo['reference'] . "'";
            }
        }

        if ($this->incidenceInfo['surname'] != '') {

            if ($search_filter == '') {
                $search_filter = " WHERE participantSurname = '" . $this->incidenceInfo['surname'] . "'";
            } else {
                $search_filter .= " AND participantSurname = '" . $this->incidenceInfo['surname'] . "'";
            }
        }

        if ($this->incidenceInfo['location'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE locID = ' . $this->incidenceInfo['location'];
            } else {
                $search_filter .= ' AND locID = ' . $this->incidenceInfo['location'];
            }
        }

        if ($this->incidenceInfo['driver_test'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE driverTest = ' . $this->incidenceInfo['driver_test'];
            } else {
                $search_filter .= ' AND driverTest = ' . $this->incidenceInfo['driver_test'];
            }
        }

        if ($this->incidenceInfo['treatment'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE activityTreatment = ' . $this->incidenceInfo['treatment'];
            } else {
                $search_filter .= ' AND activityTreatment = ' . $this->incidenceInfo['treatment'];
            }
        }

        if ($this->incidenceInfo['impact'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE activityImpact = ' . $this->incidenceInfo['impact'];
            } else {
                $search_filter .= ' AND activityImpact = ' . $this->incidenceInfo['impact'];
            }
        }

        if ($this->incidenceInfo['accident'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE activityAccident = ' . $this->incidenceInfo['accident'];
            } else {
                $search_filter .= ' AND activityAccident = ' . $this->incidenceInfo['accident'];
            }
        }

        if ($this->incidenceInfo['body_part'] != 0) {

            if ($search_filter == '') {
                $search_filter = " WHERE ( activityPartBody LIKE '" . $this->incidenceInfo['body_part'] . "' OR activityPartBody LIKE '%," . $this->incidenceInfo['body_part'] . ",%' OR activityPartBody LIKE '%," . $this->incidenceInfo['body_part'] . "' OR activityPartBody LIKE '" . $this->incidenceInfo['body_part'] . ",%')";
            } else {
                $search_filter .= " AND ( activityPartBody LIKE '" . $this->incidenceInfo['body_part'] . "' OR activityPartBody LIKE '%," . $this->incidenceInfo['body_part'] . ",%' OR activityPartBody LIKE '%," . $this->incidenceInfo['body_part'] . "' OR activityPartBody LIKE '" . $this->incidenceInfo['body_part'] . ",%')";
            }
        }

        if ($this->incidenceInfo['nature_of_injury'] != 0) {

            if ($search_filter == '') {
                $search_filter = " WHERE ( activityNatureInjury LIKE '" . $this->incidenceInfo['nature_of_injury'] . "' OR activityNatureInjury LIKE '%," . $this->incidenceInfo['nature_of_injury'] . ",%' OR activityNatureInjury LIKE '%," . $this->incidenceInfo['nature_of_injury'] . "' OR activityNatureInjury LIKE '" . $this->incidenceInfo['nature_of_injury'] . ",%')";
            } else {
                $search_filter .= " AND ( activityNatureInjury LIKE '" . $this->incidenceInfo['nature_of_injury'] . "' OR activityNatureInjury LIKE '%," . $this->incidenceInfo['nature_of_injury'] . ",%' OR activityNatureInjury LIKE '%," . $this->incidenceInfo['nature_of_injury'] . "' OR activityNatureInjury LIKE '" . $this->incidenceInfo['nature_of_injury'] . ",%')";
            }
        }

        if ($this->incidenceInfo['primary_hazard'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE activityHazardClass = ' . $this->incidenceInfo['primary_hazard'];
            } else {
                $search_filter .= ' AND activityHazardClass = ' . $this->incidenceInfo['primary_hazard'];
            }
        }

        if ($this->incidenceInfo['secondary_hazard'] != 0) {

            if ($search_filter == '') {
                $search_filter = " WHERE ( activityHazards LIKE '" . $this->incidenceInfo['secondary_hazard'] . "' OR activityHazards LIKE '%," . $this->incidenceInfo['secondary_hazard'] . ",%' OR activityHazards LIKE '%," . $this->incidenceInfo['secondary_hazard'] . "' OR activityHazards LIKE '" . $this->incidenceInfo['secondary_hazard'] . ",%')";
            } else {
                $search_filter .= " AND ( activityHazards LIKE '" . $this->incidenceInfo['secondary_hazard'] . "' OR activityHazards LIKE '%," . $this->incidenceInfo['secondary_hazard'] . ",%' OR activityHazards LIKE '%," . $this->incidenceInfo['secondary_hazard'] . "' OR activityHazards LIKE '" . $this->incidenceInfo['secondary_hazard'] . ",%')";
            }
        }

        if ($this->incidenceInfo['factor'] != 0) {

            if ($search_filter == '') {
                $search_filter = ' WHERE activityFactor = ' . $this->incidenceInfo['factor'];
            } else {
                $search_filter .= ' AND activityFactor = ' . $this->incidenceInfo['factor'];
            }
        }

        //$date_filter = " incidenceDateTime BETWEEN '".$this->incidenceInfo['start_date']." 00:00:00' AND '".$this->incidenceInfo['end_date']." 23:59:59'";
        if ($this->incidenceInfo['start_date'] != '--' && $this->incidenceInfo['end_date'] != '--' && $this->incidenceInfo['start_date'] != '' && $this->incidenceInfo['end_date'] != '') {
            $date_filter = " AND (dateTimestamp BETWEEN '" . $this->incidenceInfo['start_date'] . " 00:00:00.000' AND '" . $this->incidenceInfo['end_date'] . " 23:59:59.000')";
            $join_type = 'INNER';
            $date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
        } else {
            $date_filter = '';
            $join_type = 'LEFT OUTER';
            $date_timestamp_not_null = '';
        }

        if ($this->incidenceInfo['search_type'] == 's') {

            $sql = sprintf("SELECT A.*,userID, dateTimestamp FROM %s.incidence A
							" . $join_type . " JOIN (
								SELECT recID,
									dateTimestamp,
									whoID as userID,
									reference as recordRef,
									role
								FROM %s.module_tracker
								WHERE module = 'INCD'
								AND action = 'add'
								" . $date_timestamp_not_null . "
							) B
							ON recordRef = reference ", _DB_OBJ_FULL, _DB_OBJ_FULL);

            $sql = $sql . $search_filter . $date_filter;
        } else if ($this->incidenceInfo['search_type'] == 'd') {

            $sql = sprintf("SELECT * FROM %s.incidence WHERE" . $date_filter, _DB_OBJ_FULL);
        } else if ($this->incidenceInfo['search_type'] == 'b') {

            if ($search_filter != '') {
                $sql = sprintf("SELECT * FROM %s.incidence", _DB_OBJ_FULL);
                $sql = $sql . $search_filter . " AND" . $date_filter;
            } else {
                $sql = sprintf("SELECT * FROM %s.incidence WHERE" . $date_filter, _DB_OBJ_FULL);
            }
        }

        $sql .= " AND A.archive = '0'";

        /* $sql = sprintf("SELECT A.*,dateTimestamp FROM %s.incidence A
          LEFT OUTER JOIN (
          SELECT *
          FROM %s.recordTracking
          WHERE moduleName = 'INCD'
          AND action = 'add'
          ) B
          ON recordRef = reference
          WHERE A.archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->incidenceInfo['archive']); */

        //echo $sql;

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function updateStatus() {
        $sql = sprintf("UPDATE %s.incidence SET status = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->incidenceId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();
    }

    public function sendActionAlerts($p_record_id) {

        $this->incidenceId = $p_record_id;

        $incidence_details = $this->viewIncidenceById();
        $record_data = $this->viewActions();
        $action_array = $this->incidenceInfo['actions'];
        //dump_array($action_array);
        if (count($record_data)) {
            $i = 0;

            $orgObj = SetupGeneric::useModule('Organigram');
            $orgObj->setItemInfo(array('id' => $incidence_details['buID']));
            $org_data = $orgObj->displayItemById();
            $orgObj = null;

            foreach ($record_data as $value) {

                $email_data[$i]['reference'] = $incidence_details['reference'];
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];

                $email_data[$i]['process_bu'] = $org_data['buName'];
                $email_data[$i]['problem_description'] = $incidence_details['problemDescription'];

                $this->actionHandling->updateStatus($value['ID']);
                $i++;
            }
        }

        return $email_data;
    }

    /* public function sendActionEmail($p_record_id) {

      $this->actionHandling->setActionDetails($p_record_id,'');
      $record_data = $this->actionHandling->viewAction();

      $email_data[0]['reference']	 = $incidence_details['reference'];
      $email_data[0]['summary']		 = $value['actionDescription'];
      $email_data[0]['due_date']		 = format_date($value['dueDate']);
      $email_data[0]['who']			 = $value['who'];

      return $email_data;
      } */

    public function sendActions($p_record_id) {
        $this->incidenceId = $p_record_id;

        $incidence_details = $this->viewIncidenceById();

        $record_data = $this->viewActions();

        if (count($record_data)) {
            $i = 0;

            $orgObj = SetupGeneric::useModule('Organigram');
            $orgObj->setItemInfo(array('id' => $incidence_details['buID']));
            $org_data = $orgObj->displayItemById();
            $orgObj = null;

            foreach ($record_data as $value) {

                $sql2 = sprintf("UPDATE %s.actions SET status = 1
									WHERE ID = " . $value['ID'], _DB_OBJ_FULL);

                $pStatement2 = $this->dbHand->prepare($sql2);

                /* $pStatement2->bindParam(1,$action_ids);
                  $pStatement2->bindParam(2,$this->incidenceId); */

                $pStatement2->execute();



                $emailObj = new actionEmailHelper($value['ID']);
                $who = $emailObj->getwhoDetails();

                //$slawdata = $this->getActionsbyID($action_id);

                $sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
                $emailObj->appendInfo($sentence);

                $data = array(
                    'singleColData' => array(
                        'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_inc.php?id='.$value['ID'].'">CLICK</a> Here to View Incidence Action'
                    ),
                    'twoColData' => array(
                        'actionid' => array(
                            'left' => '<strong>Reference</strong>',
                            'right' => $incidence_details['reference']
                        ),
                        'actionid1' => array(
                            'left' => '<strong>Problem Description</strong>',
                            'right' => $incidence_details['problemDescription']
                        )
                    )
                );


                $emailObj->appendInfo($data);

                // http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145

                $emailObj->sendEmail('An Incidence Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');

                $who = $emailObj->getAUDetails();


                $sentence = array('sentence' => "You have an action to approve the following Incidence Action");
                $emailObj->appendInfo($sentence);
                $who = $emailObj->getAUDetails();
                $emailObj->sendEmail('An Incidence Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
                
                $i++;
            }
        }

        return $email_data;
    }

    /**
     * This method is used to add an incidence files
     * id, uploadfilesid
     */
    public function addIncidenceFile() {
        $files_arr = $this->getIncidenceFile();
        $files = implode(',', $files_arr);

        $new_files = $files . ',' . $this->incidenceInfo['file_id'];

        $sql = sprintf("UPDATE %s.incidence SET uploadFilesID = '%s' WHERE ID = %d", _DB_OBJ_FULL, $new_files, $this->incidenceId);
        $pStatement = $this->dbHand->prepare($sql);
        /* $pStatement->bindParam(1,$new_files);
          $pStatement->bindParam(2,$this->incidenceId); */

        $pStatement->execute();
    }

    /**
     * This method is used to get an incidence files
     * id, identifier
     */
    public function getIncidenceFile() {
        $sql = sprintf("SELECT uploadFilesID FROM %s.incidence WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->incidenceId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchColumn();

        $files_list = explode(',', $resultSet);
        //dump_array($files_list);
        return $files_list;
    }

    /**
     * This method is used to delete an incidence files
     * id
     */
    public function deleteIncidenceFile() {
        $files_arr = $this->getIncidenceFile();

        $new_files = array();

        if (count($files_arr)) {

            foreach ($files_arr as $value) {

                if ($value != $this->incidenceInfo['file_id']) {
                    $new_files[] = $value;
                }
            }
        }

        $files = implode(',', $new_files);

        $sql = sprintf("UPDATE %s.incidence SET uploadFilesID = '%s' WHERE ID = %d", _DB_OBJ_FULL, $files, $this->incidenceId);
        $pStatement = $this->dbHand->prepare($sql);
        /* $pStatement->bindParam(1,$files);
          $pStatement->bindParam(2,$this->incidenceId); */

        $pStatement->execute();
    }

    protected function getNoOfActivitiesNew() {

        $sql = sprintf("SELECT * FROM %s.incidence WHERE archive='0'", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);

                $isParticipant = $row['participantShiftWork'];
                $participantGender = $row['participantGender'];

                /* for body parts */
                if ($row['activityPartBody'] != '') {

                    $parts = explode(',', $row['activityPartBody']);
                    if (count($parts)) {
                        foreach ($parts as $value) {
                            $result_set['body_part'][$year][$bu_id][$value][$isParticipant] ++;
                            $result_set['body_part'][$year][$bu_id][$value][$participantGender] ++;
                        }
                    }
                } // end if

                /* for nature of injury */
                if ($row['activityNatureInjury'] != '') {

                    $nature_injury = explode(',', $row['activityNatureInjury']);
                    if (count($nature_injury)) {
                        foreach ($nature_injury as $value) {
                            $result_set['injury'][$year][$bu_id][$value][$isParticipant] ++;
                            $result_set['injury'][$year][$bu_id][$value][$participantGender] ++;
                        }
                    }
                } // end if

                /* for treatment */
                if ($row['activityTreatment']) {

                    $treatment = $row['activityTreatment'];
                    $result_set['treatment'][$year][$bu_id][$treatment][$isParticipant] ++;
                    $result_set['treatment'][$year][$bu_id][$treatment][$participantGender] ++;
                } // end if

                /* for accident */
                if ($row['activityAccident']) {

                    $treatment = $row['activityAccident'];
                    $result_set['accident'][$year][$bu_id][$treatment][$isParticipant] ++;
                    $result_set['accident'][$year][$bu_id][$treatment][$participantGender] ++;
                } // end if

                /* for accident */
                if ($row['activityImpact']) {

                    $activity = $row['activityImpact'];
                    $result_set['impact'][$year][$bu_id][$activity][$isParticipant] ++;
                    $result_set['impact'][$year][$bu_id][$activity][$participantGender] ++;
                } // end if

                /* for hazard classification */
                if ($row['activityHazardClass']) {

                    $hazard_class = $row['activityHazardClass'];
                    $result_set['hazard_class'][$year][$bu_id][$hazard_class][$isParticipant] ++;
                    $result_set['hazard_class'][$year][$bu_id][$hazard_class][$participantGender] ++;
                } // end if

                /* for hazards of injury */
                if ($row['activityHazards'] != '') {

                    $hazards = explode(',', $row['activityHazards']);
                    if (count($hazards)) {
                        foreach ($hazards as $value) {
                            $result_set['hazards'][$year][$bu_id][$value][$isParticipant] ++;
                            $result_set['hazards'][$year][$bu_id][$value][$participantGender] ++;
                        }
                    }
                } // end if
            }

            return $result_set;
        }
    }

    /*     * *
     * * This method is used to get
     * * listing records for Export
     * */

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'full') {

            return $this->getIncidenceExportDataFull();
        } elseif ($type == 'serach') {
            return $this->getSearchExportData();
        } else {

            return $this->getIncidenceExportData();
        }
    }

    public function getIncidenceExportDataFull() {

         $result[0]['ref']='Reference #';
          $result[0]['bu']='Business Unit';
          $result[0]['who']='Who'; 
         $result[0]['when']='Date'; 
         $result[0]['log']='Log Date';
         $result[0]['loc']='Location'; 
         $result[0]['arr']='Accident Reportable'; 
         $result[0]['sig']='Signature'; 
         $result[0]['isp']='Participant'; 
         $result[0]['sur']='Participant Surname'; 
         $result[0]['for']='Participant Forname';
         $result[0]['work']= 'WorksNumber';
         $result[0]['da']='Days Absent';
         $result[0]['shift']='Shift Work';
        $result[0]['gen']='Gender'; 
        $result[0]['em']='Employement Type';
        $result[0]['treat']='Treatment';
        $result[0]['im']='Risk Impact'; 
        $result[0]['acc']='Accident Occured'; 
        $result[0]['pb']='Part of Body'; 
        $result[0]['nature']='Nature Injury';
        $result[0]['class']='Hazard Class'; 
        $result[0]['haz']='Hazards';
        $result[0]['af']='Additional factors';
        $result[0]['wit']='No Witness';
        $result[0]['wp']='Participant';
        $result[0]['f']='Witness Forename';
        $result[0]['s']='Witness Surname';
        $result[0]['w']='Witness Worknumber';
        $result[0]['e']='Witness Email';
        $result[0]['t']='Witness Telephone';
        $result[0]['d']='Witness Descp';
        $result[0]['pro']='Problem Desc.';
        $result[0]['pdi']='Detailed Investigation';
        $result[0]['a']='Action Desc.';
        $result[0]['aw']='Action Who'; 
        $result[0]['awu']='Action WhoAU';
        $result[0]['due']='Action Due Date';
        $result[0]['do']='Action Done Date';
        $result[0]['dod']='Action Done Descp.';
        $result[0]['pr']='Process Number';
        $result[0]['rv']='Risk Rating still valid';

       
        
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setIncidenceInfo(1, array('archive' => $archive_session));
        $records = $this->viewIncidences();
        //dump_array($records);
        //exit;
        if (is_array($records)) {
            $i = 1;
            foreach ($records as $value) {

                $orgObj->setItemInfo(array('id' => $value['buID']));
                $bu_details = $orgObj->displayItemById();

                $locObj->setItemInfo(array('id' => $value['locID']));

                $location = $locObj->getFUllLocation();

                $participant_id = $value['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $search_date = substr($value['incidenceDateTime'], 0, 10);

                $result[$i]['ref'] = $value['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['when'] = format_datetime($search_date);
                $result[$i]['log'] = format_datetime($value['dateTimestamp']);
                $result[$i]['loc'] = str_replace(',', '-', $location);
                if ($value['accidentReportable'] == '1') {
                    $acc = 'Yes';
                } else {
                    $acc = 'No';
                }
                if ($value['signature'] == '1') {
                    $sig = 'Yes';
                } else {
                    $sig = 'No';
                }
                $result[$i]['arr'] = $acc;
                $result[$i]['sig'] = $sig;
                $nam = $this->getparent1($value['ID']);
                //dump_array($nam);

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $value['activityTreatment'],
                ));

                $data_records = $type->displayItemById();
                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $value['activityImpact'],
                ));

                $data_records1 = $type->displayItemById2();
                $type->setItemInfo(array(
                    'id' => $value['activityAccident'],
                ));

                $data_records2 = $type->displayItemById();
                $type->setItemInfo(array(
                    'id' => $value['activityNatureInjury'],
                ));

                $data_records3 = $type->displayItemById();
                $type->setItemInfo(array(
                    'id' => $value['activityHazardClass'],
                ));

                $data_records4 = $type->displayItemById1();
                $type->setItemInfo(array(
                    'id' => $value['activityHazards'],
                ));

                $data_records5 = $type->displayItemById3();
                $type->setItemInfo(array(
                    'id' => $value['activityHazards'],
                ));

                $data_records6 = $type->displayItemById4();
                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $value['actionsID'],
                ));

                $data_records7 = $type->displayItemById5();

                $type->setItemInfo(array(
                    'id' => $value['activityPartBody'],
                ));

                $data_records78 = $type->displayItemById();
                $type->setItemInfo(array(
                    'id' => $value['activityFactor'],
                ));

                $data_records79 = $type->displayItemById();
//dump_array($data_records7);
//exit;

                if ($nam['gender'] == 'F') {
                    $gen = 'Female';
                } else {
                    $gen = 'Male';
                }
                if ($nam['shiftWork'] == '1') {
                    $shift = 'Yes';
                } else {
                    $shift = 'No';
                }

                if ($value['isParticipant'] == '1') {
                    $isp = 'Yes';
                } else {
                    $isp = 'No';
                }
                if ($value['noWitness'] == '1') {
                    $wit = 'Yes';
                } else {
                    $wit = 'No';
                }
                if ($value['problemDetailedInvestigation'] == '1') {
                    $pdi = 'Yes';
                } else {
                    $pdi = 'No';
                }
                $result[$i]['isp'] = $isp;
                $result[$i]['sur'] = $nam['surname'];
                $result[$i]['for'] = $nam['forename'];
                $result[$i]['work'] = $nam['worksNumber'];
                $result[$i]['da'] = $value['absentDays'];
                $result[$i]['shift'] = $shift;
                $result[$i]['gen'] = $gen;
                $result[$i]['em'] = $value['empType'];
                $result[$i]['treat'] = $data_records['name'];
                $result[$i]['im'] = $data_records1['name'];
                $result[$i]['acc'] = $data_records2['name'];
                $result[$i]['pb'] = $data_records78['name'];
                $result[$i]['nature'] = $data_records3['name'];
                $result[$i]['class'] = $data_records4['primaryHazard'];
                $result[$i]['hazard'] = $data_records5['secondaryHazard'];
                $result[$i]['af'] = $data_records79['name'];
                $result[$i]['wit'] = $wit;
                $result[$i]['wp'] = $isp;
                $result[$i]['f'] = $data_records6['forename'];
                $result[$i]['s'] = $data_records6['surname'];
                $result[$i]['w'] = $data_records6['worksNumber'];
                $result[$i]['e'] = $data_records6['emailAddress'];
                $result[$i]['t'] = $data_records6['telephone'];
                $result[$i]['d'] = $data_records6['description'];
                $result[$i]['problem'] = $value['problemDescription'];
                $result[$i]['pdi'] = $pdi;
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['due'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;
                $i++;
            }
        }


        return $result;
    }

    public function getIncidenceExportData() {

      
        
         $result[0]['ref']='Reference #';
          $result[0]['bu']='Business Unit';
          $result[0]['who']='Who'; 
         $result[0]['when']='Date'; 
         $result[0]['log']='Log Date';
         $result[0]['loc']='Location'; 
         
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

        $this->setIncidenceInfo(1, array('archive' => $archive_session));
        $records = $this->viewIncidences();

        if (count($records)) {
            $i = 1;
            foreach ($records as $value) {

                $orgObj->setItemInfo(array('id' => $value['buID']));
                $bu_details = $orgObj->displayItemById();

                $locObj->setItemInfo(array('id' => $value['locID']));

                $location = $locObj->getFUllLocation();

                $participant_id = $value['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $search_date = substr($value['incidenceDateTime'], 0, 10);

                $result[$i]['ref'] = $value['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['when'] = format_datetime($search_date);
                $result[$i]['log'] = format_datetime($value['dateTimestamp']);
                $result[$i]['loc'] = str_replace(',', '-', $location);

                $i++;
            }
        }

    
        return $result;
    }

    public function getSearchExportData() {

        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');

        $search_type = 's';
        $reference_no = $_GET['ref_no'];
        $surname = $_GET['surname'];
        $location = $_GET['location'];
        $driver_test = $_GET['driver_test'];
        $treatment = $_GET['treatment'];
        $risk = $_GET['risk'];
        $accident = $_GET['accident'];
        $body_part = $_GET['body_part'];
        $nature_of_injury = $_GET['nature_of_injury'];
        $primary_hazard = $_GET['primary_hazard'];
        $secondary_hazard = $_GET['secondary_hazard'];
        $factor = $_GET['factor'];

        $search_data = array(
            'search_type' => $search_type,
            'reference' => $reference_no,
            'surname' => $surname,
            'location' => $location,
            'driver_test' => $driver_test,
            'treatment' => $treatment,
            'impact' => $risk,
            'accident' => $accident,
            'body_part' => $body_part,
            'nature_of_injury' => $nature_of_injury,
            'primary_hazard' => $primary_hazard,
            'secondary_hazard' => $secondary_hazard,
            'factor' => $factor,
        );

        $this->setIncidenceInfo('', $search_data);
        $search_result = $this->getIncidenceBySearch();

        $heading = array(array('Reference #', 'Business Unit', 'Incidence Date', 'Location'));

        if (count($search_result)) {

            foreach ($search_result as $element) {

                $orgObj->setItemInfo(array('id' => $element['buID']));
                $bu_details = $orgObj->displayItemById();
                $business_unit = $bu_details['buName'];

                $locObj->setItemInfo(array('id' => $element['locID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();
                $location = str_replace(',', '-', $location);

                $date = format_datetime($element['incidenceDateTime']);

                $result[] = array($element['reference'], $business_unit, $date, $location);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;
    }

    public function getInstructorGraphData($b_unit = 0, $year = '') {

        $instructor_data = "";

        if ($b_unit == 0) {
            $b_unit = '';
        }

        if ($b_unit == '') {
            $sql = sprintf("SELECT COUNT(*) AS tot_acc,instructor,incidenceDateTime FROM %s.incidence WHERE driverTest='1' GROUP BY instructor,incidenceDateTime", _DB_OBJ_FULL);
        } else {
            $sql = sprintf("SELECT COUNT(*) AS tot_acc,instructor,incidenceDateTime FROM %s.incidence WHERE driverTest='1' AND buID IN (%s) GROUP BY instructor,incidenceDateTime", _DB_OBJ_FULL, $b_unit);

            //echo "<br/>";
        }

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        //dump_array($result);

        if (count($result)) {
            $i = 0;
            foreach ($result as $value) {
                $ins_id = $value['instructor'];
                $date = $value['incidenceDateTime'];

                $year_db = substr($date, 0, 4);
                if ($year_db == $year) {
                    $instructor_data[$ins_id]['tot_acc'] += $value['tot_acc'];
                    $instructor_data[$ins_id]['instructor'] = $value['instructor'];
                }
            }
        }

        return $instructor_data;
    }

    public function getInstructorGraphDataPublic() {

        $sql = sprintf("SELECT * FROM %s.incidence", _DB_OBJ_FULL);

        //echo $sql;


        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        //dump_array($result);

        if (count($result)) {
            $i = 0;
            foreach ($result as $value) {
                $date = $value['incidenceDateTime'];  //isParticipant // buID
                $bu = $value['buID'];
                $emp = $value['isParticipant'];

                $year_db = substr($date, 0, 4);

                if ($emp == 1) {
                    $instructor_data[$year_db][$bu]['employee'] ++;
                    $instructor_data[$year_db][$bu]['public'] += 0;
                } else if ($emp == 0) {
                    $instructor_data[$year_db][$bu]['public'] ++;
                    $instructor_data[$year_db][$bu]['employee'] += 0;
                }

                $name = $value['participantForename'] . ' ' . $value['participantSurname'];
                if ($name != ' ') {
                    $instructor_data[$year_db][$bu]['instructors'][$name] ++;
                }
            }
        }

        return $instructor_data;
    }

    /* function is used to send mail to manager of approved record */

    public function getActionTrackerEmailData($p_record_id) {

        $sql2 = sprintf("SELECT * FROM %s.incidence ", _DB_OBJ_FULL);
        $sql2 = $sql2 . " WHERE actionsID LIKE '" . $p_record_id . "' OR actionsID LIKE '%," . $p_record_id . "' OR actionsID LIKE '" . $p_record_id . ",%' OR actionsID LIKE '%," . $p_record_id . ",%' ";

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

        //dump_array($result);exit;

        if (count($result)) {
            $email_data['bu_id'] = $result[0]['buID'];
            $email_data['reference'] = $result[0]['reference'];
            $email_data['DueDate'] = $result[0]['incidenceDateTime'];
            $email_data['who_id'] = $result[0]['whoID'];
        }
        return $email_data;
    }

    public function manageParticipant() {

         $sql2 = sprintf("UPDATE %s.incidence SET isParticipant = '1' WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceId);
        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();

        if ((int) $this->incidenceInfo['participant_id']) {
            // do update
            $this->updateParticipant();
        } else {
            // do insert
            $this->addParticipant();
        }
    }

    public function markAccidentAsReportable() {


        $sql2 = sprintf(" UPDATE %s.incidence SET
						accidentReportable = %d
						WHERE ID = %d", _DB_OBJ_FULL, 1, $this->incidenceId);

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
    }

    public function isAccidentReportable() {
        return $this->accidentReportable;
    }

    public function getParticipants() {

        if (isset($this->incidenceInfo['history'])) {

            $ref_array = explode(".", $this->incidenceInfo['ref']);
            $sub_reference = $ref_array[1];

            $sql2 = sprintf("SELECT * FROM %s.incidence_participants_historical WHERE incID = %d AND subReference = %d", _DB_OBJ_FULL, $this->incidenceId, $sub_reference);
        } else {
            $sql2 = sprintf("SELECT * FROM %s.incidence_participants WHERE incID = %d ", _DB_OBJ_FULL, $this->incidenceId);
        }

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        $result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    private function addParticipant() {

        $sql2 = sprintf("INSERT INTO %s.incidence_participants (incID,isParticipant,surname,forename,worksNumber,daysAbsent,shiftWork,gender,empType)
									 VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s')", _DB_OBJ_FULL, $this->incidenceId, $this->incidenceInfo['is_participant'], $this->incidenceInfo['surname'], $this->incidenceInfo['forename'], $this->incidenceInfo['works_number'], $this->incidenceInfo['days_absent']
                , $this->incidenceInfo['shift_work'], $this->incidenceInfo['gender'], $this->incidenceInfo['type']);


        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
        /* dump_array($pStatement2->errorInfo());
          exit; */
    }

    private function updateParticipant() {

        echo $sql2 = sprintf("UPDATE %s.incidence_participants SET isParticipant = '%s',
										surname = '%s',
										forename = '%s',
										worksNumber = '%s',
										daysAbsent = '%s',
										shiftWork = '%s',
										gender = '%s',
										empType = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['is_participant'], $this->incidenceInfo['surname'], $this->incidenceInfo['forename'], $this->incidenceInfo['works_number'], $this->incidenceInfo['days_absent']
        , $this->incidenceInfo['shift_work'], $this->incidenceInfo['gender'], $this->incidenceInfo['type'], $this->incidenceInfo['participant_id']);


        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
        //dump_array($pStatement2->errorInfo());
    }

    public function deleteParticipant() {
        $sql2 = sprintf("DELETE FROM %s.incidence_participants WHERE ID = %d", _DB_OBJ_FULL, $this->incidenceInfo['participant_id']);


        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
    }

    public function duplicateRecord() {
        $rec_data = $this->viewIncidenceById();
        $witness = $this->viewWitness();
        $participants = $this->getParticipants();
        $miscObj = $this->incidenceInfo['miscObj'];
        $view_action = $this->viewActions();
        /* dump_array($view_action);
          //dump_array($participants);
          exit; */

        $sql = sprintf("INSERT INTO %s.incidence ", _DB_OBJ_FULL);

        if (count($rec_data)) {
            foreach ($rec_data as $field => $val) {
                if ($field != 'ID') {

                    $fields .= $field . ",";
                    if ($field == 'reference') {

                        if ($this->incidenceInfo['sub_ref']) {
                            $values .= "'" . $val . "." . $this->incidenceInfo['sub_ref'] . "',";
                        } else {
                            $values .= "'" . $val . "',";
                        }
                    } else if ($field == 'archive') {
                        $values .= "'1',";
                    } else {
                        $values .= "'" . $val . "',";
                    }
                }
            }
        }

        $sql .= "(" . trim($fields, ',') . ") VALUES (" . trim($values, ',') . ") ";
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $this->incidenceId = customLastInsertId($this->dbHand, 'incidence', 'ID');

        /*         * ************************************  copy action start ************************************* */

        if (count($view_action)) {
            foreach ($view_action as $value) {
                $this->actionData = array('module_name' => 'incidence', 'description' => $value['actionDescription'],
                    'who' => $value['who'], 'due_date' => $value['when']);
                $sql_action = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,who,dueDate,doneDate,doneDescription,approve,outstanding,status)
								VALUES ('incidence','" . $value['actionDescription'] . "','" . $value['who'] . "','" . $value['dueDate'] . "'
								,'" . $value['doneDate'] . "','" . $value['doneDescription'] . "','" . $value['approve'] . "','" . $value['outstanding'] . "'
								,'0')", _DB_OBJ_FULL);
                $pStatement_action = $this->dbHand->prepare($sql_action);

                $pStatement_action->execute();
                //dump_array($pStatement_action->errorInfo());

                $action_ids .= customLastInsertId($this->dbHand, 'actions', 'ID') . ',';
            }
        }

        //exit;


        $action_ids = rtrim($action_ids, ',');

        $sql_upd = sprintf("UPDATE %s.incidence SET actionsID = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $action_ids, $this->incidenceId);

        $pStatement_upd = $this->dbHand->prepare($sql_upd);

        $pStatement_upd->execute();

        /*         * ************************************ copy action end ****************************************** */

        //echo $sql;

        /*         * ************************************  copy witness start ************************************* */

        if (count($witness)) {
            foreach ($witness as $row) {

                $sql_wt = sprintf("INSERT INTO %s.incidence_witness ", _DB_OBJ_FULL);
                $fields_wt = $values_wt = "";
                foreach ($row as $field => $val) {
                    if ($field != 'ID') {

                        $fields_wt .= $field . ",";
                        if ($field == 'incID') {
                            $values_wt .= "'" . $this->incidenceId . "',";
                        } else {
                            $values_wt .= "'" . $val . "',";
                        }
                    }
                }

                $sql_wt .= "(" . trim($fields_wt, ',') . ") VALUES (" . trim($values_wt, ',') . ") ";
                $pStatement2 = $this->dbHand->prepare($sql_wt);
                $pStatement2->execute();
                /* echo "<br/>";
                  echo $sql_wt; */
            }
        }

        /*         * ************************************  copy witness end ************************************* */
        /*         * ************************************  copy participants start ************************************* */

        if (count($participants)) {
            foreach ($participants as $row) {

                $sql_pt = sprintf("INSERT INTO %s.incidence_participants ", _DB_OBJ_FULL);
                $fields_pt = $values_pt = "";
                foreach ($row as $field => $val) {
                    if ($field != 'ID') {

                        $fields_pt .= $field . ",";
                        if ($field == 'incID') {
                            $values_pt .= "'" . $this->incidenceId . "',";
                        } else {
                            $values_pt .= "'" . $val . "',";
                        }
                    }
                }

                $sql_pt .= "(" . trim($fields_pt, ',') . ") VALUES (" . trim($values_pt, ',') . ") ";
                $pStatement3 = $this->dbHand->prepare($sql_pt);
                $pStatement3->execute();
                /* echo "<br/>";
                  echo $sql_pt; */
            }
        }
        /*         * ************************************  copy participants end ************************************* */

        $miscObj->duplicateRecord(array('module' => 'INCD', 'rec_id' => $this->incidenceId));

        //dump_array($rec_data);
        //exit;
    }

    public function addReportData() {

        $sql2 = sprintf("INSERT INTO %s.incidenceR4_data(
							incidenceID,companyName,companyNumber,telephone,headAddressPremises,
							headAddressStreet,headAddressDistrict,headAddressTown,headAddressCountry,headAddressNotIreland,
							baseAddressPremises,baseAddressStreet,baseAddressTown,baseAddressCountry,employed_organisation,
							employedBaseAddress,accidentAddress,country,natureBusiness,firstName,
							dateAccident,surname,timeAccident,nationality,gender,
							occupation,age,isInjuredPerson,injuredPerson,anticipatedNormalDuties,
							email,healthSafetyAuthority,notificationDate,name,jobTitle,
							typeAccident,didInjuredPerson,accidentDescription,workActivity,itemAccident,
							workplaceEnvironments,triggeredAccident,lossControl,overflow,bestDescribes,
							injuredByVehicle,injuredByPerson,indicateTypeInjury,indicateBodyInjury,nameEmployer,
							baseAddressDistrict)
							VALUES(
							'%d','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s','%s','%s','%s','%s',
							'%s')", _DB_OBJ_FULL, $this->incidenceInfo['id_ele'], $this->incidenceInfo['company_name_ele'], $this->incidenceInfo['company_number_ele'], $this->incidenceInfo['telphone_ele'], $this->incidenceInfo['premises_ele'], $this->incidenceInfo['street_ele'], $this->incidenceInfo['district_ele'], $this->incidenceInfo['town_ele'], $this->incidenceInfo['country_ele'], $this->incidenceInfo['country_not_ireland_ele'], $this->incidenceInfo['base_premises_ele'], $this->incidenceInfo['base_street_ele'], $this->incidenceInfo['base_town_ele'], $this->incidenceInfo['base_country_ele'], $this->incidenceInfo['check_ele_ele'], $this->incidenceInfo['base_check_ele'], $this->incidenceInfo['accident_address_ele'], $this->incidenceInfo['country_accident_ele'], $this->incidenceInfo['nature_business_ele'], $this->incidenceInfo['first_name_ele'], $this->incidenceInfo['date_accident_ele'], $this->incidenceInfo['surnamer_ele'], substr($this->incidenceInfo['time_accident_ele'], 0, 5), $this->incidenceInfo['nationality_ele'], $this->incidenceInfo['group_ele'], $this->incidenceInfo['occupation_ele'], $this->incidenceInfo['age_ele'], $this->incidenceInfo['is_injured_person_ele'], $this->incidenceInfo['injured_person_ele'], $this->incidenceInfo['anticipated_normal_ele'], $this->incidenceInfo['email_ele'], $this->incidenceInfo['health_ele'], $this->incidenceInfo['notification_date_ele'], $this->incidenceInfo['name_ele'], $this->incidenceInfo['job_title_ele'], $this->incidenceInfo['type_accident_ele'], $this->incidenceInfo['did_injured_person_ele'], $this->incidenceInfo['accident_descp_ele'], $this->incidenceInfo['work_ele'], $this->incidenceInfo['item_ele'], $this->incidenceInfo['workplace_environment_ele'], $this->incidenceInfo['triggered_accident_ele'], $this->incidenceInfo['loss_control_ele'], $this->incidenceInfo['overflow_ele'], $this->incidenceInfo['person_was_injured_ele'], $this->incidenceInfo['injured_by_vehicle_ele'], $this->incidenceInfo['injured_by_person_ele'], $this->incidenceInfo['indicate_type_injred_ele'], $this->incidenceInfo['indicate_body_injured_ele'], $this->incidenceInfo['name_employer_ele'], $this->incidenceInfo['base_district_ele']
        );

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();
        $pStatement2->errorInfo();
    }

    public function getReportData() {

        $sql = sprintf("SELECT * FROM %s.incidenceR4_data WHERE incidenceID = %d", _DB_OBJ_FULL, $this->incidenceId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);

        return $result;
    }

    public function deleteReportData() {
        $sql = sprintf("DELETE FROM %s.incidenceR4_data WHERE incidenceID = %d", _DB_OBJ_FULL, $this->incidenceId);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->incidenceInfo['witness_id']);
        $pStatement->execute();
    }

    public function testerBUname() {
        $sql = "SELECT buId,instructor,incidenceDateTime FROM %s.incidence WHERE driverTest = 1 AND instructor != 0";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getAccidetTest() {

        $sql = sprintf("SELECT * FROM %s.incidence WHERE archive =0 ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row);
                $bu_id = $row['buID'];
                $date_time = $row['incidenceDateTime'];
                $year = substr($date_time, 0, 4);
                if ($row['type'] == 'rsa') {
                    $result_set['rsa'][$year][$bu_id] ++;
                } elseif ($row['type'] == 'public') {
                    $result_set['public'][$year][$bu_id] ++;
                } elseif ($row['type'] == 'roadside') {
                    $result_set['roadside'][$year][$bu_id] ++;
                } elseif ($row['type'] == 'other') {
                    $result_set['other'][$year][$bu_id] ++;
                }
                if ($row['type'] == 'rsa' || $row['type'] == 'public' || $row['type'] == 'roadside' || $row['type'] == 'other') {
                    $result_set['all'][$year][$bu_id] ++;
                }
                //elseif($row['type'] == 'other'  || $row['type'] == 'rsa' || $row['type'] == 'public' || $row['type'] == 'roadside'){
                //	$result_set['all'][$year][$bu_id]++;
                //}
            }

            return $result_set;
        }
    }

    public function getSelectedBu() {

        $sql = sprintf("SELECT * FROM %s.accidentTest", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function getAccidetBuTest() {

        $sql = sprintf("SELECT * FROM %s.accidentTest", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $r = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($r as $val) {



            $sql1 = sprintf("SELECT * FROM %s.incidence WHERE buID =" . $val['buID'] . "AND archive =0", _DB_OBJ_FULL);

            $pStatement = $this->dbHand->prepare($sql1);
            $pStatement->execute();

            $no_rows = $pStatement->rowCount();
            if ($no_rows) {
                while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                    //dump_array($row);

                    $type = $row['type'];
                    $bu_id = $row['buID'];
                    $date_time = $row['incidenceDateTime'];
                    $year = substr($date_time, 0, 4);
                    $month = substr($date_time, 5, 2);
                    // echo  $pieces['1'] = explode("-", $month);

                    if ($row['type'] == 'rsa') {

                        $result_set['rsa'][$val['buName']][$year][$bu_id] ++;
                    } elseif ($row['type'] == 'public') {
                        $result_set['public'][$val['buName']][$year][$bu_id] ++;
                    } elseif ($row['type'] == 'roadside') {
                        $result_set['roadside'][$val['buName']][$year][$bu_id] ++;
                    } elseif ($row['type'] == 'other') {
                        $result_set['other'][$val['buName']][$year][$bu_id] ++;
                    }
                    if ($row['type'] == 'rsa' || $row['type'] == 'public' || $row['type'] == 'roadside' || $row['type'] == 'other') {
                        $result_set['all'][$val['buName']][$year][$bu_id] ++;
                    }
                    if ($row['type'] == 'rsa') {

                        $result_set['rsa'][$month][$val['buName']][$year][$bu_id] ++;
                    } elseif ($row['type'] == 'public') {
                        $result_set['public'][$month][$val['buName']][$year][$bu_id] ++;
                    } elseif ($row['type'] == 'roadside') {
                        $result_set['roadside'][$month][$val['buName']][$year][$bu_id] ++;
                    } elseif ($row['type'] == 'other') {
                        $result_set['other'][$month][$val['buName']][$year][$bu_id] ++;
                    }
                    if ($row['type'] == 'rsa' || $row['type'] == 'public' || $row['type'] == 'roadside' || $row['type'] == 'other') {
                        $result_set['all'][$month][$val['buName']][$year][$bu_id] ++;
                    }

                    //}
                    //$result_set[$val['buName']][$year][$bu_id]++;	
                }

                //return $result_set;
            }
        }
//dump_array($result_set);

        return $result_set;
//dump_array($bu);
    }

    public function participantNameBu($id_val) {
        $this->id = $id_val;
        $sql = "SELECT forename,surname FROM %s.participant_database WHERE participantID = %d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $this->id);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getsupplierdata($name, $year, $quarter) {

        $this->name = $name;
        $this->quarter = $quarter;
        $this->year = $year;
        if ($this->name == 'undefined' || $this->name == 0)
            $sql = sprintf("SELECT N.contractName, N.useApprovedContractor,C.review_ID,f1f2,questionID,quarterCovered,N.archive,shortTermOrTender,buID,A.score FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID 
											LEFT JOIN %s.contract_actions A on A.contractreviewid=C.review_id WHERE C.archive=0 and yearCovered =%d and quarterCovered=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->year, $this->quarter);
        else
            $sql = sprintf("SELECT N.contractName, N.useApprovedContractor,C.review_ID,f1f2,questionID,quarterCovered,N.archive,shortTermOrTender,buID,A.score FROM %s.contract_review C
												INNER JOIN %s.contract N
											ON N.ID = C.contractID 
											LEFT JOIN %s.contract_actions A on A.contractreviewid=C.review_id WHERE C.archive=0 and yearCovered =%d and quarterCovered=%d and N.useApprovedContractor=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->year, $this->quarter, $this->name);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            foreach ($result as $value) {
                if ($value["f1f2"] == 1 && $value["questionID"] > 2)
                    $question = $value["questionID"] + 1;
                else
                    $question = $value["questionID"];
                $result_set[$value["useApprovedContractor"]][$value["review_ID"]][$question]['score'] = $value["score"];
            }
        }
//dump_array($result_set);
        return $result_set;
    }

    public function getBu() {
        $sql = "SELECT * FROM %s.business_units ";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getparent($p, $l) {

        $this->p = $p;
        $sql = "SELECT * FROM %s.business_units WHERE parentBuID =  " . $this->p . " AND mseListID = 1";

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getparent1($p) {

        $this->p = $p;
        $sql = "SELECT * FROM %s.incidence_participants WHERE incID =  " . $this->p;

        $psql = sprintf($sql, _DB_OBJ_FULL);
        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getOverDueActions($buStr, $date) {
        $this->sql_query = sprintf("select A.id,I.reference,I.problemDescription,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name from %s.actions A  inner join %s.incidence I on A.record=I.ID left join %s.business_units B on I.buid=B.buID left join %s.participant_database P on A.currentWho=P.participantID where modulename = 'incidence' and B.buID in(%s) and approveAU=0 and duedate < '%s'
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $date);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getOutstandingActions($buStr, $fdate) {
        $insp_out = SetupGeneric::useModule('InspectionOutstandingAction');
        $outstanding_duration = explode(':', $insp_out->displayItems());

        switch ($outstanding_duration[1]) {
            case 'M' : $interval = '+' . $outstanding_duration[0] . ' MONTH';
                break;
            case 'Y' : $interval = '+' . $outstanding_duration[0] . ' YEAR';
                break;
        }

        $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");

        $this->sql_query = sprintf("select A.id,I.reference,I.problemDescription,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,(P.forename +' '+P.surname) as who_name from %s.actions A  inner join %s.incidence I on A.record=I.ID left join %s.business_units B on I.buid=B.buID left join %s.participant_database P on A.currentWho=P.participantID where modulename = 'incidence' and B.buID in(%s) and approveAU=0 and duedate >=  '%s'
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $outstandingDate);

        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getWordReport($p) {

        $this->p = $p;
        $incObj = new IncidenceMain();
        $incObj->setIncidenceInfo($this->p, '');

        $incidence_dataset = objectsIntoArray($incObj->viewIncidenceById());


        $participant_data = $incObj->getParticipants();

        if (count($incidence_dataset[0])) {
            $incidence_data = $incidence_dataset[0];
            $incidence_cmp_data = $incidence_dataset[1];
        } else {
            $incidence_data = $incidence_dataset;
        }

        /* dump_array($participant_data); */
        $i = 0;
        if (count($participant_data)) {

            foreach ($participant_data as $employee_ele) {

                if ($employee_ele['isParticipant'] == 1) {

                    $participant_data[$i]['isParticipant'] = 'Yes';
                } else if ($employee_ele['isParticipant'] == 0) {

                    $participant_data[$i]['isParticipant'] = 'No';
                }

                $employee_ele['gender'] = trim($employee_ele['gender'], '');

                switch ($employee_ele['gender']) {
                    case 'M' : $participant_data[$i]['gender'] = 'Male';
                        break;
                    case 'F' : $participant_data[$i]['gender'] = 'Female';
                        break;
                }

                $participant_data[$i]['shiftWork'] = $employee_ele['shiftWork'] == 1 ? 'Yes' : 'No';
                $participant_data[$i]['worksNumber'] = $employee_ele['worksNumber'] != '' ? $employee_ele['worksNumber'] : '-';
                $participant_data[$i]['forename'] = $employee_ele['forename'] != '' ? $employee_ele['forename'] : '-';
                $participant_data[$i]['surname'] = $employee_ele['surname'] != '' ? $employee_ele['surname'] : '-';
                $participant_data[$i]['gender'] = $participant_data[$i]['gender'] != '' ? $participant_data[$i]['gender'] : '-';
                $participant_data[$i]['daysAbsent'] = $employee_ele['daysAbsent'] != '' ? $employee_ele['daysAbsent'] : '-';
                $i++;
            }
        } // end participant condition
        //dump_array($participant_data);
        // for incidence_data
        $format_time = format_dateTime($incidence_data['incidenceDateTime']);
        $time = substr($format_time, 11, 24);
        $date = substr($format_time, 0, 11);


        $incidence_data['bu_name'] = $this->get_bu_name($incidence_data['buID']) != '' ? $this->get_bu_name($incidence_data['buID']) : '-';
        $incidence_data['date_time'] = $time != '' ? $time : '-';
        $incidence_data['date'] = $date;
        $incidence_data['reference'] = $incidence_data['reference'] != '' ? $incidence_data['reference'] : '-';
        $incidence_data['participants'] = $participant_data;
        $incidence_data['participants_count'] = $incidence_data['participants'] == '' ? 0 : count($incidence_data['participants']);


        if ($incidence_data['isRiskValid'] == 0) {
            $incidence_data['isRiskValid'] = 'No';
        } elseif ($incidence_data['isRiskValid'] == 1) {
            $incidence_data['isRiskValid'] = 'Yes';
        }

        $incidence_data['forename'] = $incidence_data['participantForename'] != '' ? $incidence_data['participantForename'] : '-';
        $incidence_data['surname'] = $incidence_data['participantSurname'] != '' ? $incidence_data['participantSurname'] : '-';
        $incidence_data['treatment'] = $this->get_activity_name($incidence_data['activityTreatment']) != '' ? $this->get_activity_name($incidence_data['activityTreatment']) : '-';
        $incidence_data['injury'] = $this->get_activity_name($incidence_data['activityNatureInjury']) != '' ? $this->get_activity_name($incidence_data['activityNatureInjury']) : '-';
        $incidence_data['accident'] = $this->get_activity_name($incidence_data['activityAccident']) != '' ? $this->get_activity_name($incidence_data['activityAccident']) : '-';
        $incidence_data['part_of_body'] = $this->get_activity_name($incidence_data['activityPartBody']) != '' ? $this->get_activity_name($incidence_data['activityPartBody']) : '-';
        $incidence_data['impact'] = $this->getImpact($incidence_data['activityImpact']) != '' ? $this->getImpact($incidence_data['activityImpact']) : '-';
        //$incidence_data['hazard'] = $this->get_primary_hazard_name($incidence_data['activityHazardClass']) != '' ? $this->get_primary_hazard_name($incidence_data['activityHazardClass']) : '-';
        //$incidence_data['hazard_classification'] = $this->get_secondary_hazard_name($incidence_data['activityHazards']) != '' ? $this->get_secondary_hazard_name($incidence_data['activityHazards']) : '-';
        $incidence_data['additional_factor'] = $this->get_activity_name($incidence_data['activityFactor']) != '' ? $this->get_activity_name($incidence_data['activityFactor']) : '-';
        $incidence_data['iswitness'] = $incidence_data['noWitness'] != '' ? $incidence_data['noWitness'] : '-';

        //echo $this->get_witness($data[0]['ID']);
        //echo $data[0]['ID'];
        if ($incidence_data['subReference'] == 0) {
            $incidence_data['witness'] = $this->get_witness($incidence_data['ID'], false);
        } else {
            $incidence_data['witness'] = $this->get_witness($incidence_data['ID'], true);
        }

        $incidence_data['witness_count'] = $incidence_data['witness'] == '' ? 0 : count($incidence_data['witness']);

        if ($incidence_data['iswitness']) {

            $incidence_data['iswitness'] = 'Yes';
        } else {

            $incidence_data['iswitness'] = 'No';
        }

        //get uploaded files
        $file_arr = array();


        if ($incidence_data['uploadFilesID']) {

            $file_arr = explode(',', $incidence_data['uploadFilesID']);
        }

        if (count($file_arr)) {
            foreach ($file_arr as $key => $value) {

                //	$this->objFile->setFileInfo('incidence',array('id'=>$value));
                //$incidence_file = $this->objFile->getFileDetails();
                //$incidence_uploaded_file = "<a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=".$incidence_file['sysFilename']."&un=".$incidence_file['usrFilename']."&module=incidence','mywindow')\">".$incidence_file['usrFilename']."</a>";
                //$incidence_data['uploaded_files'][$key]	= $incidence_uploaded_file;
            }
        } else {
            $incidence_data['uploaded_files'][$key] = '-';
        }



        $incidence_data['problem'] = $incidence_data['problemDescription'] != '' ? $incidence_data['problemDescription'] : '-';
        $incidence_data['detailed_investigation'] = $incidence_data['problemDetailedInvestigation'];

        if ($incidence_data['detailed_investigation']) {
            $incidence_data['detailed_investigation'] = 'Yes';
        } else {
            $incidence_data['detailed_investigation'] = 'No';
        }

        if ($incidence_data['detailed_investigation']) {
            $incidence_data['no_detailed_investigation_reason'] = $incidence_data['noInvestigationReqReason'];
        } else {
            $incidence_data['no_detailed_investigation_reason'] = $incidence_data['noInvestigationReqReason'];
        }

        $incidence_data['action'] = $this->getAction($incidence_data['actionsID']);
//dump_array($incidence_data);
        $process_data = $this->get_process_details($incidence_data['processID']);
        $incidence_data['process_ref'] = $process_data['ref'] != '' ? $process_data['ref'] : '-';
        $incidence_data['process_desc'] = $process_data['desc'] != '' ? $process_data['desc'] : '-';
        //	$incidence_data['risk_color'] = $this->get_risk_color($incidence_data['processID']);
        //	$this->locObj->setItemInfo(array(
        //'id'=>$incidence_data['locID']
        // ));
        //$incidence_data['location'] = $this->locObj->getFUllLocation();
        // }
        //$incidence_data['report_head'] = false;
        // if ( $this->filters['heading'] ) {
        // $incidence_data['report_head'] = true;
        // }
        //dump_array($incidence_data);
        //$incidence_data['history'] 	= $this->filters['history'];
        //$incidence_data['vref'] 	= $this->filters['ref'];
        //$incidence_data['cref'] 	= $this->filters['cmpref'];



        return $incidence_data;
    }

    private function get_bu_name($p_bu_id) {

        $sql = sprintf("SELECT buName FROM %s.business_units WHERE buID = %d ", _DB_OBJ_FULL, $p_bu_id);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$p_bu_id);
        $pStatement->execute();
        return $pStatement->fetchColumn();
    }

    private function get_activity_name($p_activity_id) {

        if ($p_activity_id) {

            $sql2 = sprintf("SELECT * FROM %s.incidence_classification WHERE ID IN (" . $p_activity_id . ") ", _DB_OBJ_FULL);

            $stmt = $this->dbHand->prepare($sql2);
            $stmt->execute();
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($data)) {
                foreach ($data as $valueActivity) {
                    $activity_name .= $valueActivity['name'] . ', ';
                }

                return rtrim($activity_name, ', ');
            }
        }
    }

    private function getImpact($p_impact_id) {

        $sql = sprintf("SELECT name FROM %s.impact_measure WHERE ID = %d ", _DB_OBJ_FULL, $p_impact_id);

        $stmt = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$p_impact_id);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    private function get_witness($p_witness_id, $p_use_history_table = false) {
        $sql = sprintf("SELECT * FROM %s.incidence_witness WHERE incID = %d ", _DB_OBJ_FULL, $p_witness_id);


        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 1;
        //dump_array($data);

        if (count($data)) {

            foreach ($data as $valueWitness) {

                if ($valueWitness['isParticipant'] == 1) {

                    $witness[$i]['is_participant'] = 'Yes';
                } else if ($valueWitness['isParticipant'] == 0) {

                    $witness[$i]['is_participant'] = 'No';
                }

                $witness[$i]['works_number'] = $valueWitness['worksNumber'] != '' ? $valueWitness['worksNumber'] : '-';
                $witness[$i]['forename'] = $valueWitness['forename'] != '' ? $valueWitness['forename'] : '-';
                $witness[$i]['surname'] = $valueWitness['surname'] != '' ? $valueWitness['surname'] : '-';
                $witness[$i]['telephone'] = $valueWitness['telephone'] != '' ? $valueWitness['telephone'] : '-';
                $witness[$i]['email'] = $valueWitness['emailAddress'] != '' ? $valueWitness['emailAddress'] : '-';
                $witness[$i]['description'] = $valueWitness['description'] != '' ? $valueWitness['description'] : '-';
                $i++;
            }
            return $witness;
        } else {
            return "";
        }
    }

    private function getAction($p_action_id) {


        $sql = sprintf("SELECT * FROM %s.actions WHERE ID IN (" . $p_action_id . ") ", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        $i = 1;
        if (count($data)) {

            foreach ($data as $valueAction) {

                $action[$i]['name'] = $valueAction['actionDescription'];
                $action[$i]['who'] = $this->get_participant_name($valueAction['who']);
                $action[$i]['when'] = $valueAction['dueDate'];
                $action[$i]['when'] = $valueAction['dueDate'] != '' ? format_date($valueAction['dueDate']) : '-';
                $i++;
            }

            return $action;
        }
    }

    private function get_process_details($p_process_id) {

        $sql = sprintf("SELECT * FROM %s.swimlane WHERE swimID = %d ", _DB_OBJ_FULL, $p_process_id);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$p_process_id);
        $pStatement->execute();
        $process_dtata = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return array('ref' => $process_dtata[0]['reference'], 'desc' => $process_dtata[0]['description']);
    }

    
    	public function sendReportableActions($p_record_id) {
		$this->incidenceId = $p_record_id;

		$incidence_details = $this->viewIncidenceById();



		if ( is_array($record_data) ) {
			$i = 0;

			$orgObj		= SetupGeneric::useModule('Organigram');
			$orgObj->setItemInfo(array('id'=>$incidence_details['buID']));
			$org_data 	= $orgObj->displayItemById();
			$orgObj 	= null;

			foreach ( $record_data as $value ) {
			
				$sql2 = sprintf("UPDATE %s.actions SET status = 1
									WHERE ID = ".$value['ID'],_DB_OBJ_FULL);

			$pStatement2 = $this->dbHand->prepare($sql2);

			/*$pStatement2->bindParam(1,$action_ids);
			$pStatement2->bindParam(2,$this->incidenceId);*/

			$pStatement2->execute();
			
			
			
			$emailObj = new actionEmailHelper($value['ID']);
			$who = $emailObj->getwhoDetails();

			//$slawdata = $this->getActionsbyID($action_id);

			$sentence = array('sentence' => array("You have an action to carry out the following Incidence Action"));
			$emailObj->appendInfo($sentence);

			$data = array(
					'singleColData' => array(
							'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_inc.php?id='.$value['ID'].'">CLICK</a> Here to View Incidence Action'
					),
					'twoColData' => array(
							'actionid' => array(
								'left' => '<strong>Reference</strong>', 
								'right' => $incidence_details['reference']
							),
							'actionid1' => array(
								'left' => '<strong>Problem Description</strong>', 
								'right' => $incidence_details['problemDescription']
							)
					)
			);


			$emailObj->appendInfo($data);
			
			// http://smart-test.smart-iso.net/risk27k/add_edit_action.php?id=145
			
			$emailObj->sendEmail('An Incidence Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
			
			$who = $emailObj->getAUDetails();

				
				$sentence = array('sentence' => "You have an action to approve the following Incidence Action");
				$emailObj->appendInfo($sentence);
				$who = $emailObj->getAUDetails();
				//$emailObj->sendEmail('An Incidence Action To Be Approved', $who, array(), $cto, 'me_completed', '', 'grey');
				$email_data[$i]['reference']	 = $incidence_details['reference'];
				$email_data[$i]['summary']		 = $value['actionDescription'];
				$email_data[$i]['due_date']		 = format_date($value['dueDate']);
				$email_data[$i]['who_allocated'] = $value['who'];
				$email_data[$i]['who']			 = _INCIDENCE_REPORTABLE_ACTION_USER_ID;
				$email_data[$i]['type']			 = "action_reportable";
				$email_data[$i]['process_bu'] = $org_data['buName'];
				$i++;
			}
		}

		return $email_data;

	}

}

?>