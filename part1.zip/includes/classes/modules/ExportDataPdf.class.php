<?php
 /**
  $Id: ExportDataPdf.class.php,v 3.03 Thursday, January 13, 2011 4:00:16 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, January 13, 2011 3:57:07 PM>
  */

class ExportDataPdf
{
	private $objCont;

	public function downloadFile($p_obj) {
		$this->objCont = $p_obj;
		
		header('Content-type: application/download');
		header('Content-Description: File Transfer');
		header('Content-Disposition: attachment; filename="'.$download_file_name.'" ');
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header('Content-Transfer-Encoding: binary');

		//dump_array($this->objCont);
	}
}
?>