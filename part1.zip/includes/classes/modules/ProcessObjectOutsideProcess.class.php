<?php
 /**
  $Id: ProcessObjectOutsideProcess.class.php,v 3.64 Wednesday, December 15, 2010 6:42:49 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 3:56:29 PM>
  */

require_once "ProcessObjectInterface.int.php";

class ProcessInprocess implements ProcessObjectInterface
{
	public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

		$blockCord  = ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$path_no 	= (int) $blockCord['path_no'];

		$x = ($classObj->argBlockWidth() - $p_width)/2;
		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

		$x1 = $x + $blockCord['x'] - 10;
		$y1 = $y + $blockCord['y'];
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$xStart = $x + $blockCord['x'] + 55;
		$yStart = $y + $blockCord['y'];
		$xEnd = $xStart;
		$yEnd = $yStart - 90;

		switch ($path_no) {
			case 0: $path_x_offset = $classObj->argxOffsetMainPath();
					break;

			case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
					break;

			case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
					break;

			case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
					break;

			case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
					break;
		}

		$ym = $blockCord['y'] + $classObj->argObjectHeight();

		imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

		$path_colour = $classObj->getPathcolour($path_no);

		//dump_array($blockCord);
		imageline($classObj->getResource(),$xStart, $yStart, $xEnd, $yEnd, $path_colour);

		imagefilledrectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('lozenge_colour'));

		imagerectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('text_colour'));
		imagesetthickness($classObj->getResource(), 1);

		// save node coordinates
		if ( $classObj->getResample() ) {
			$resamplePercent 	= $classObj->getResamplePercent();

			$x1_resamp = ceil($x1 * $resamplePercent);
			$y1_resamp = ceil($y1 * $resamplePercent);
			$x2_resamp = ceil($x2 * $resamplePercent);
			$y2_resamp = ceil($y2 * $resamplePercent);

			$node_coordinates = $x1_resamp.','.$y1_resamp.','.$x2_resamp.','.$y2_resamp;
		} else {
			$node_coordinates = $x1.','.$y1.','.$x2.','.$y2;
		}

		$classObj->saveProcessInOutCoordinates($p_step_info['ID'],$node_coordinates);

		//imagefttext($classObj->getResource(), $classObj->getBusinessUnitFontSize(),0, $x1, $cy1,$classObj->getColour('text_colour'), $classObj->getFontFile(),'aaaaaaaa');
		imagefttext($classObj->getResource(), 16,0, ($x1 + ($classObj->argBlockWidth()/4)-5),$y2-8,$classObj->getColour('background_colour'), $classObj->getFontFile(),'IN');
	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

		$blockCord  = ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$path_no 	= (int) $blockCord['path_no'];

		$x = ($classObj->argBlockWidth() - $p_width)/2;
		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

		$x1 = $x + $blockCord['x'] - 10;
		$y1 = $y + $blockCord['y'];
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$shade_offset = $classObj->getShadeOffset();

		switch ($path_no) {
			case 0: $path_x_offset = $classObj->argxOffsetMainPath();
					break;

			case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
					break;

			case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
					break;

			case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
					break;

			case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
					break;
		}

		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset, $y1 + $shade_offset, $x2 + $shade_offset, $y2 + $shade_offset, $classObj->getColour('shadow2_colour'));
		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset - 2, $y1 + $shade_offset - 2, $x2 + $shade_offset - 2 , $y2 + $shade_offset - 2, $classObj->getColour('shadow_colour'));
	}
}

class ProcessOutprocess implements ProcessObjectInterface
{
	public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

		$blockCord  = ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$path_no 	= (int) $blockCord['path_no'];

		$x = ($classObj->argBlockWidth() - $p_width)/2;
		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

		$x1 = $x + $blockCord['x'] - 10;
		$y1 = $y + $blockCord['y'];
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$xStart = $x + $blockCord['x'] + 55;
		$yStart = $y + $blockCord['y'];
		$xEnd = $xStart;
		$yEnd = $yStart - 140;

		switch ($path_no) {
			case 0: $path_x_offset = $classObj->argxOffsetMainPath();
					break;

			case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
					break;

			case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
					break;

			case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
					break;

			case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
					break;
		}


		imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

		$path_no = 10;
		$path_colour = $classObj->getPathcolour($path_no);

		imageline($classObj->getResource(),$xStart, $yStart, $xEnd, $yEnd, $path_colour);

		imagefilledrectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('lozenge_colour'));

		imagerectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('text_colour'));
		imagesetthickness($classObj->getResource(), 1);

		// save node coordinates
		if ( $classObj->getResample() ) {
			$resamplePercent 	= $classObj->getResamplePercent();

			$x1_resamp = ceil($x1 * $resamplePercent);
			$y1_resamp = ceil($y1 * $resamplePercent);
			$x2_resamp = ceil($x2 * $resamplePercent);
			$y2_resamp = ceil($y2 * $resamplePercent);

			$node_coordinates = $x1_resamp.','.$y1_resamp.','.$x2_resamp.','.$y2_resamp;
		} else {
			$node_coordinates = $x1.','.$y1.','.$x2.','.$y2;
		}

		$classObj->saveProcessInOutCoordinates($p_step_info['ID'],$node_coordinates);

		imagefttext($classObj->getResource(), 16,0, ($x1 + ($classObj->argBlockWidth()/4)-15),$y2-8,$classObj->getColour('background_colour'), $classObj->getFontFile(),'OUT');

		// draw arrow

		$x1_arrow = $x1 + 50;
		$y1_arrow = $y1 - 12;
		$x2_arrow = $x1 + 60;
		$y2_arrow = $y1 - 12;
		$x3_arrow = $x1 + 55;
		$y3_arrow = $y1 + 1;

		$arrow_points = array(
		$x1_arrow,$y1_arrow,
		$x2_arrow,$y2_arrow,
		$x3_arrow,$y3_arrow
		);

		imagefilledpolygon($classObj->getResource(),$arrow_points ,3 ,$path_colour);
	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

		$blockCord  = ProcessBlock::getBlockCoordinates($classObj,$p_block);
		$path_no 	= (int) $blockCord['path_no'];

		$x = ($classObj->argBlockWidth() - $p_width)/2;
		$y = $classObj->argObjectHeight() - $classObj->argObjectGap();

		$x1 = $x + $blockCord['x'] - 10;
		$y1 = $y + $blockCord['y'];
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$shade_offset = $classObj->getShadeOffset();

		switch ($path_no) {
			case 0: $path_x_offset = $classObj->argxOffsetMainPath();
					break;

			case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
					break;

			case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
					break;

			case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
					break;

			case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
					break;
		}

		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset, $y1 + $shade_offset, $x2 + $shade_offset, $y2 + $shade_offset, $classObj->getColour('shadow2_colour'));
		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset - 2, $y1 + $shade_offset - 2, $x2 + $shade_offset - 2 , $y2 + $shade_offset - 2, $classObj->getColour('shadow_colour'));
	}
}


class ProcessExinprocess implements ProcessObjectInterface
{
 	private $p_x1;
	private $p_y1;

	public function printHeadingAndDescription($classObj,$p_x1,$p_y1,$p_heading,$p_content) {

		$this->p_x1 = $p_x1;
		$this->p_y1 = $p_y1;

		$this->printHeading($classObj,$p_heading);
		$this->printDescription($classObj,$p_content);
	}

    private function printHeading($classObj,$p_content) {

        $this->p_x1 = $this->p_x1 + 45;
        $this->p_y1 = $this->p_y1 + 18;

		//$p_content = 'Vehicle Standard';

		//imagefttext($classObj->getResource(), $classObj->getBusinessUnitFontSize(), 0, $p_x1,$p_y1, $path_colour, $classObj->getFontFile(),$p_content);
		$this->wrapText($classObj,$classObj->getBusinessUnitFontSize(),$p_content,29);
    }

	private function wrapText($classObj,$p_fontsize,$p_content1,$p_wrapStrCnt) {

  $p_content=str_ireplace("<BR>"," - ",$p_content1);
		$p_content_strlen = strlen($p_content);
		$p_content_tokens = ceil($p_content_strlen/$p_wrapStrCnt);

		if ( $p_content_strlen > $p_wrapStrCnt ) {

			for ($k=0;$k<2;$k++) {

				$start_pt = $k*$p_wrapStrCnt;

				if ( $k == 1 ) {
					$end_pt = $p_content_strlen - $p_wrapStrCnt;
				} else {
					$end_pt = $p_wrapStrCnt;
				}

				imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),substr($p_content,$start_pt,$end_pt));
				$this->p_y1 = $this->p_y1 + 14;
			}
		} else {
			imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),$p_content);
			$this->p_y1 = $this->p_y1 + 14;
		}

	}

    private function printDescription($classObj,$p_content1) {

		//$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
  $p_content=str_ireplace("<BR>"," - ",$p_content1);
		$p_content_strlen = strlen($p_content);
		$max_string_length = 35;

		$this->p_y1 = $this->p_y1;

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$this->p_y1, $path_colour, $classObj->getFontFile_2(),$p_content);
		} else {

			$strings 	= wordwrap(substr($p_content,0,150).' ...', $max_string_length,  "#", true);
			$string_arr = explode("#",$strings);

			$cy1 = $this->p_y1;

			foreach ( $string_arr as $strele ) {
				imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$cy1, $path_colour, $classObj->getFontFile_2(),$strele);
				$cy1 = $cy1 + 11;
			}
		}
	}
	
	
	public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info,$output_type='N') {

	$blockCord 	= $p_block;

	
		$x1 = $blockCord['x'];
		$y1 = $blockCord['y'];


		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$xStart = $x + $blockCord['x'] + 58;
		
		if ($output_type=='H')
		$xStart+=90;
		
		$yStart = $y + $blockCord['y'];
		$xEnd = $xStart;
		$yEnd = $yStart - 160;

		switch ($path_no) {
			case 0: $path_x_offset = $classObj->argxOffsetMainPath();
					break;

			case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
					break;

			case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
					break;

			case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
					break;

			case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
					break;
		}

		$ym = $blockCord['y'] + $classObj->argObjectHeight();

		imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());
		$path_no 	= 10;
		$path_colour = $classObj->getPathcolour($path_no);


		imagefilledrectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('lozenge_colour'));

		imagerectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('text_colour'));
		imagesetthickness($classObj->getResource(), 1);


		$node_coordinates = $x1.','.$y1.','.$x2.','.$y2;
		

		$classObj->saveProcessInOutCoordinates($p_step_info['ID'],$node_coordinates);


		imagefttext($classObj->getResource(), 16,0, ($x1 + ($classObj->argBlockWidth()/4)-5),$y2-8,$classObj->getColour('background_colour'), $classObj->getFontFile(),'IN');
		
					if ( $classObj->getOutputType() == 'H' && $p_step_info['descQues'] != '' ) {
			$this->printHeadingAndDescription($classObj,$x1,$y1,$p_step_info['buName'],$p_step_info['descQues']);
			}
	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

	$blockCord 	= $p_block;

	
		$x1 = $blockCord['x'];
		$y1 = $blockCord['y'];
	
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$shade_offset = $classObj->getShadeOffset();

		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset, $y1 + $shade_offset, $x2 + $shade_offset, $y2 + $shade_offset, $classObj->getColour('shadow2_colour'));
		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset - 2, $y1 + $shade_offset - 2, $x2 + $shade_offset - 2 , $y2 + $shade_offset - 2, $classObj->getColour('shadow_colour'));
	}
}

class ProcessExoutprocess implements ProcessObjectInterface
{
 
 	private $p_x1;
	private $p_y1;

	public function printHeadingAndDescription($classObj,$p_x1,$p_y1,$p_heading,$p_content) {

		$this->p_x1 = $p_x1;
		$this->p_y1 = $p_y1;

		$this->printHeading($classObj,$p_heading);
		$this->printDescription($classObj,$p_content);
	}

    private function printHeading($classObj,$p_content) {

        $this->p_x1 = $this->p_x1 + 45;
        $this->p_y1 = $this->p_y1 + 18;

		//$p_content = 'Vehicle Standard';

		//imagefttext($classObj->getResource(), $classObj->getBusinessUnitFontSize(), 0, $p_x1,$p_y1, $path_colour, $classObj->getFontFile(),$p_content);
		$this->wrapText($classObj,$classObj->getBusinessUnitFontSize(),$p_content,29);
    }

	private function wrapText($classObj,$p_fontsize,$p_content,$p_wrapStrCnt) {


		$p_content_strlen = strlen($p_content);
		$p_content_tokens = ceil($p_content_strlen/$p_wrapStrCnt);

		if ( $p_content_strlen > $p_wrapStrCnt ) {

			for ($k=0;$k<2;$k++) {

				$start_pt = $k*$p_wrapStrCnt;

				if ( $k == 1 ) {
					$end_pt = $p_content_strlen - $p_wrapStrCnt;
				} else {
					$end_pt = $p_wrapStrCnt;
				}

				imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),substr($p_content,$start_pt,$end_pt));
				$this->p_y1 = $this->p_y1 + 14;
			}
		} else {
			imagefttext($classObj->getResource(), $p_fontsize, 0, $this->p_x1,$this->p_y1, $path_colour, $classObj->getFontFile(),$p_content);
			$this->p_y1 = $this->p_y1 + 14;
		}

	}

    private function printDescription($classObj,$p_content) {

		//$p_content = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

		$p_content_strlen = strlen($p_content);
		$max_string_length = 35;

		$this->p_y1 = $this->p_y1;

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$this->p_y1, $path_colour, $classObj->getFontFile_2(),$p_content);
		} else {

			$strings 	= wordwrap(substr($p_content,0,150).' ...', $max_string_length,  "#", true);
			$string_arr = explode("#",$strings);

			$cy1 = $this->p_y1;

			foreach ( $string_arr as $strele ) {
				imagefttext($classObj->getResource(), 9, 0, $this->p_x1-30,$cy1, $path_colour, $classObj->getFontFile_2(),$strele);
				$cy1 = $cy1 + 11;
			}
		}
	}
	
 
	public function draw($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info,$output_type='N') {


	$blockCord 	= $p_block;

	
		$x1 = $blockCord['x'];
		$y1 = $blockCord['y'];
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;


		imagesetthickness($classObj->getResource(), $classObj->argOutlineThickness());

		$path_no = 10;
		$path_colour = $classObj->getPathcolour($path_no);

		imagefilledrectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('lozenge_colour'));

		imagerectangle($classObj->getResource(), $x1, $y1, $x2, $y2, $classObj->getColour('text_colour'));
		imagesetthickness($classObj->getResource(), 1);

		
			$node_coordinates = $x1.','.$y1.','.$x2.','.$y2;
		

		$classObj->saveProcessInOutCoordinates($p_step_info['ID'],$node_coordinates);

		imagefttext($classObj->getResource(), 16,0, ($x1 + ($classObj->argBlockWidth()/4)-15),$y2-8,$classObj->getColour('background_colour'), $classObj->getFontFile(),'OUT');

		
		
			if ( $classObj->getOutputType() == 'H' && $p_step_info['descQues'] != '' ) {
			$this->printHeadingAndDescription($classObj,$x1,$y1,$p_step_info['buName'],$p_step_info['descQues']);
			}
		
	}

	public function drawShadow($classObj,$p_block,$p_width,$p_height,$p_main_path,$p_alt_path,$p_lozenge,$p_step_info) {

	$blockCord 	= $p_block;

	
		$x1 = $blockCord['x'];
		$y1 = $blockCord['y'];
		$x2 = $x1 + $p_width + 20;
		$y2 = $y1 + $p_height;

		$shade_offset = $classObj->getShadeOffset();

		switch ($path_no) {
			case 0: $path_x_offset = $classObj->argxOffsetMainPath();
					break;

			case 1: $path_x_offset = $classObj->argxOffsetAltFirstPath();
					break;

			case 2: $path_x_offset = $classObj->argxOffsetAltSecondPath();
					break;

			case 3: $path_x_offset = $classObj->argxOffsetAltThirdPath();
					break;

			case 4: $path_x_offset = $classObj->argxOffsetAltFourthPath();
					break;
		}

		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset, $y1 + $shade_offset, $x2 + $shade_offset, $y2 + $shade_offset, $classObj->getColour('shadow2_colour'));
		imagefilledrectangle($classObj->getResource(), $x1 + $shade_offset - 2, $y1 + $shade_offset - 2, $x2 + $shade_offset - 2 , $y2 + $shade_offset - 2, $classObj->getColour('shadow_colour'));
	}
}
?>