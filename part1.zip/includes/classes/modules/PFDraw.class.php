<?php

/**
  $Id: ProcessFlow.class.php,v 10.0 Saturday, February 05, 2011 1:26:07 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Wednesday, October 20, 2010 2:57:54 PM>
 */
require_once "ProcessObject.class.php";

class PFDraw {

 private $dbHand;
 private $PFDInfo;
 private $id;
  private $Bus; 
  
  
    public function __construct($id) {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->id = $id;
        $this->Bus = array();
    }

    public function Get_Draw_Data() {
      
    $sql = sprintf("SELECT * FROM %s.swimlane_data S left join %s.business_units B on S.buid=B.buID WHERE swimID = %d ORDER BY altPathIndex,stepLevel,type ASC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->id);
        $pStatement = $this->dbHand->prepare($sql);

       $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
$width=$this->Get_Width($this->id);
        $step=101;
        $xmlstep='';
        foreach($resultSet as $row) {
           
         if (!in_array($row["buID"],$this->Bus,true))
          $this->Bus[$row["buID"]]=array("id"=>$row["buID"],"name"=>$row["buName"]); 
         
        $pos=explode(",",$row["imageMaps"]);
        $x=$pos[0];
        $y=$pos[1];
        if ($row["type"]=='S')
            $type='typeS';
        elseif ($row["type"]=='D')
            $type='typeD';
        else
          $type='typeA';
        if($type == 'typeD'){
        $xa=$x-370;
        $ya=$y-10;
        }  else {        
    $xa=$x-340;
    $ya=$y-15;
        }  
    $xNew=($xa*300/180)+150;
    $yNew=($ya*200/60)+15;
     $xmlstep .='<mxCell  id="'.$step.'" value="'.$row["descQues"].'"  style="'.$type.'" vertex="1" parent="2" ><mxGeometry x="'.$xNew.'" y="'.$yNew.'" width="255" height="155"  whitespace="wrap"  as="geometry"/></mxCell>';
          
         
         $stepArr[$row["ID"]]  =$step; 
          $step++;
          if ($step == -102){
        $xml .='<mxCell id="'.$step.'" value="" edge="1" parent="1" source="start" target="101"><mxGeometry relative="1" as="geometry"/></mxCell>';
       
        $step++;
        }
        }


    
    $xml = '<mxGraphModel><root><mxCell id="0"/><mxCell id="1" parent="0"/>';
    $i=2;
    foreach($this->Bus as $bus) {
        $y=($i-2)*200;
       
        $xml .='<mxCell id="'.$i.'" value="'.$bus["name"].'" style="swimlane" vertex="1" parent="1"><mxGeometry x="1" y="'.$y.'" width="'.$width.'" height="200" as="geometry"/></mxCell>';
    $i++;
        
    }
   
    $xml .='<mxCell id="start" value="Start" style="start" vertex="1" parent="2"><mxGeometry x="40" y="78" width="60" height="30" as="geometry"/></mxCell>';
    $xml .=$xmlstep;
    $xml .='<mxCell id="8" value="" edge="1" parent="2" source="start" target="101"><mxGeometry relative="1" as="geometry"/></mxCell>';
   $xml .='<mxCell id="9" value="" edge="1" parent="2" source="101" target="102"><mxGeometry relative="1" as="geometry"/></mxCell>';
				
    $xml .='</root></mxGraphModel>';
    return $xml;
    }  
    
      public function Get_Width($id) {
        $sql = sprintf("SELECT max(steplevel) as width FROM %s.swimlane_data where swimid=%d ", _DB_OBJ_FULL,  $id);
        $pStatement = $this->dbHand->prepare($sql);

       $pStatement->execute();
        $resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
       
        return ($resultSet['width']*300)+150;
}

            public function Get_Height($id) {
        
            //    $sql = sprintf("SELECT max(steplevel) as width FROM %s.swimlane_data where swimid=%d ", _DB_OBJ_FULL,  $id);
      $sql = sprintf("SELECT distinct count(buid)*200 as height,buid FROM %s.swimlane_data where swimid=%d group by buid,steplevel", _DB_OBJ_FULL,  $id);
        
                $pStatement = $this->dbHand->prepare($sql);

       $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
        
        return $resultSet;
      }
}

?>