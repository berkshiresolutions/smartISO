<?php
 /**
  $Id: DseAssessment.class.php,v 3.43 Thursday, February 03, 2011 3:15:44 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Thursday, October 07, 2010 9:49:05 AM>
  */

require_once "DseAssessment.int.php";
require_once "Action.class.php";

class DseAssessment implements DseAssessmentInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 *Property to hold Dse Assessment Id
	 *@access private
	 */
	private $dseId;

	/**
	 *property holds the action data
	 *@access private
	 */
	private $dseActionData;

	/**
	 *Property to hold Dse Info
	 *@access private
	 */
	private $dseInfo;

	/**
	 * Constructor for initializing Dse Assessment object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/**
	 * to set dse assessment information for performing various operations with the dse assessment object
	 *
	 * @param integer $p_dseAssessmentId This parameter is used to set Dse Assessment Id for adding, editing, archiving, restoring, delete
	 * @param array This array holds the information of Dse. THis is optional
	 * @access public
	 */
	public function setDseAssessmentInfo($p_dseAssessmentId,$p_dseAssessmentInfo) {
		$this->dseId	=	$p_dseAssessmentId;
		$this->dseInfo	=	$p_dseAssessmentInfo;
	}

	/**
	 * This method is used to add a new dse assessment
	 * Participant Details Tab
	 * reference,unique_reference,participant_name,works_number,job_title,time_length,
	 * time_length_option,description,location,business_unit,workstation
	 */
	public function addDseAssessment() {
		$sql = sprintf("INSERT INTO %s.dse_assessment (reference,uniqueReference,nameParticipant,worksNumber,
					   jobTitle,lengthTime,lengthTimeOption,description,location,
											businessUnit,workstation,processNo,archive,status)
											VALUES ('%s','%s','%s','%s','%s','%s','%s','%s',%d,%d,'%s',NULL,'0','0')",_DB_OBJ_FULL,
											$this->dseInfo['reference'],$this->dseInfo['unique_reference'],$this->dseInfo['participant_name'],
											$this->dseInfo['works_number'],smartisoAddslashes($this->dseInfo['job_title']),$this->dseInfo['time_length'],
											$this->dseInfo['time_length_option'],smartisoAddslashes($this->dseInfo['description']),$this->dseInfo['location'],
											$this->dseInfo['business_unit'],smartisoAddslashes($this->dseInfo['workstation']));

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->dseInfo['reference']);
		$pStatement->bindParam(2,$this->dseInfo['unique_reference']);
		$pStatement->bindParam(3,$this->dseInfo['participant_name']);
		$pStatement->bindParam(4,$this->dseInfo['works_number']);
		$pStatement->bindParam(5,$this->dseInfo['job_title']);
		$pStatement->bindParam(6,$this->dseInfo['time_length']);
		$pStatement->bindParam(7,$this->dseInfo['time_length_option']);
		$pStatement->bindParam(8,$this->dseInfo['description']);
		$pStatement->bindParam(9,$this->dseInfo['location']);
		$pStatement->bindParam(10,$this->dseInfo['business_unit']);
		$pStatement->bindParam(11,$this->dseInfo['workstation']);*/

		$pStatement->execute();
		/*dump_array($pStatement->errorInfo());
		exit;*/

		//$this->dseId = $this->dbHand->lastInsertId();
		$this->dseId = customLastInsertId( $this->dbHand,'dse_assessment','ID');

		//dump_array($this);
	}

	/**
	 * This method is used to add Dse Assessment section
	 *
	 * Keyboard,Display Pointing Devices,Chair,VDU Work,Document Holder,Workdesk,Heat Ventilation,General Safety
	 * dse_id,section_id,question_id,is_yes,is_no,is_na,comments,action,who,when
	 */

	public function addDseSections() {

		$sql_check = sprintf("SELECT * FROM %s.dse_assessment_sections WHERE dID = %d AND section = %d AND question = %d",_DB_OBJ_FULL,
							 $this->dseId,$this->dseInfo['section_id'],$this->dseInfo['question_id']);

		$pStatementCheck = $this->dbHand->prepare($sql_check);

		/*$pStatementCheck->bindParam(1,$this->dseId);
		$pStatementCheck->bindParam(2,$this->dseInfo['section_id']);
		$pStatementCheck->bindParam(3,$this->dseInfo['question_id']);*/

		$pStatementCheck->execute();
		$result = $pStatementCheck->fetchAll(PDO::FETCH_ASSOC);
		$result_count = (int) count($result);

		if ( !$result_count ) {

			$sql = sprintf("INSERT INTO %s.dse_assessment_sections (dID,section,question,checkedYes,checkedNo,checkedNa,comments,actionID)
														VALUES (%d,%d,%d,'%s','%s','%s','%s',NUll)",_DB_OBJ_FULL,$this->dseId,
														$this->dseInfo['section_id'],$this->dseInfo['question_id'],$this->dseInfo['is_yes'],
														$this->dseInfo['is_no'],$this->dseInfo['is_na'],smartisoAddslashes($this->dseInfo['comments']));

			$pStatement = $this->dbHand->prepare($sql);


			/*$pStatement->bindParam(1,$this->dseId);
			$pStatement->bindParam(2,$this->dseInfo['section_id']);
			$pStatement->bindParam(3,$this->dseInfo['question_id']);
			$pStatement->bindParam(4,$this->dseInfo['is_yes']);
			$pStatement->bindParam(5,$this->dseInfo['is_no']);
			$pStatement->bindParam(6,$this->dseInfo['is_na']);
			$pStatement->bindParam(7,$this->dseInfo['comments']);*/

			$pStatement->execute();
			/*dump_array($pStatement->errorInfo());
			exit;*/

			//$dse_last_id = $this->dbHand->lastInsertId();
			$dse_last_id = "";
			$dse_last_id = customLastInsertId( $this->dbHand,'dse_assessment_sections','ID');

			$is_no = (int) $this->dseInfo['is_no'];
			if ( $is_no ) {
				$actionId = $this->addDseActions();

				$sql = sprintf("UPDATE %s.dse_assessment_sections SET actionID = %d WHERE ID = %d",_DB_OBJ_FULL,$actionId,$dse_last_id);

				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$actionId);
				$pStatement->bindParam(2,$dse_last_id);*/
				$pStatement->execute();

			}

			return $actionId; // for data transfer

			//dump_array($this);
		}
	}

	/**
	 *This mehtod the Add Dse Action
	 *@access private
	 */
	private function addDseActions() {

		if ( $this->dseInfo['action'] !='' && $this->dseInfo['who'] !='' && $this->dseInfo['when'] != '' ) {
			$add_action_data = array('module_name'=>'DSE','description'=>smartisoAddslashes($this->dseInfo['action']),'who'=>$this->dseInfo['who'],
										'due_date'=>$this->dseInfo['when']);

			$this->actionHandling->setActionDetails(0,$add_action_data);
			$action_id = $this->actionHandling->addAction();

			return $action_id;
		}


		//dump_array($this);
	}

	/**
	 * This method is used to manage Dse Assessment process
	 * process_number
	 **/

	public function manageDseProcess() {

		$sql = sprintf("UPDATE %s.dse_assessment SET processNo = %d,isRiskValid = '%s' WHERE ID = %d",_DB_OBJ_FULL,$this->dseInfo['process_number'],
					   $this->dseInfo['is_risk'],$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->dseInfo['process_number']);
		$pStatement->bindParam(2,$this->dseInfo['is_risk']);
		$pStatement->bindParam(3,$this->dseId);*/

		$pStatement->execute();

	}

	/*
	 * This method is used to view dse assessment information.
	 */
	public function viewDseAssessment() {

		$sql = sprintf("SELECT * FROM %s.dse_assessment WHERE ID = %d ",_DB_OBJ_FULL,$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->dseId);
		$pStatement->execute();

		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);

		return $resultSet;
	}

	/**
	 * This method is used to view dse assessment section information.
	 */
	public function viewDseAssessmentSection() {

		$sql = sprintf("SELECT * FROM %s.dse_assessment_sections WHERE dID = %d AND section = %d ",_DB_OBJ_FULL,$this->dseId,$this->dseInfo['section_id']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->dseId);
		$pStatement->bindParam(2,$this->dseInfo['section_id']);*/
		$pStatement->execute();

		//$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		while ( $result = $pStatement->fetch(PDO::FETCH_ASSOC) )  {

			$questionId = $result['question'];
			$dseSectionData[$questionId] = $result;

			if ( $result['checkedNo'] ) {
				$action = $this->viewDseAssessmentAction($result['actionID']);
				$dseSectionData[$questionId]['action'] = $action['actionDescription'];
				$dseSectionData[$questionId]['who'] = $action['who'];
				$dseSectionData[$questionId]['when'] = $action['dueDate'];
			}

		}
		//dump_array($this);

		return $dseSectionData;
	}

	private function viewDseAssessmentAction($p_questionId) {


		$this->actionHandling->setActionDetails($p_questionId,"");
		$action = $this->actionHandling->viewAction();


		$dse_action = "";

		if ( count($action) ) {
			//dump_array($action_value);
			$dse_action = $action;
		}

		return $dse_action;
	}

	/**
	 * This method is used to edit the dse assessment
	 * Participant Details Tab
	 * participant_name,works_number,job_title,time_length,
	 * time_length_option,description,location,business_unit,workstation
	 */
	public function editDseAssessment() {

		$sql = sprintf("UPDATE %s.dse_assessment SET  nameParticipant = '%s',
											worksNumber = '%s',
											jobTitle = '%s',
											lengthTime = '%s',
											lengthTimeOption = '%s',
											description = '%s',
											location = %d,
											businessUnit = %d,
											workstation = '%s'
										WHERE ID = %d ",_DB_OBJ_FULL,
											$this->dseInfo['participant_name'],
											$this->dseInfo['works_number'],smartisoAddslashes($this->dseInfo['job_title']),$this->dseInfo['time_length'],
											$this->dseInfo['time_length_option'],smartisoAddslashes($this->dseInfo['description']),$this->dseInfo['location'],
											$this->dseInfo['business_unit'],smartisoAddslashes($this->dseInfo['workstation']),$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->dseInfo['participant_name']);
		$pStatement->bindParam(2,$this->dseInfo['works_number']);
		$pStatement->bindParam(3,$this->dseInfo['job_title']);
		$pStatement->bindParam(4,$this->dseInfo['time_length']);
		$pStatement->bindParam(5,$this->dseInfo['time_length_option']);
		$pStatement->bindParam(6,$this->dseInfo['description']);
		$pStatement->bindParam(7,$this->dseInfo['location']);
		$pStatement->bindParam(8,$this->dseInfo['business_unit']);
		$pStatement->bindParam(9,$this->dseInfo['workstation']);
		$pStatement->bindParam(10,$this->dseId);*/

		$pStatement->execute();

		//dump_array($this);
	}

	/**
	 * This method is used to add Dse Assessment section
	 *
	 * Keyboard,Display Pointing Devices,Chair,VDU Work,Document Holder,Workdesk,Heat Ventilation,General Safety
	 * is_yes,is_no,is_na,comments,section_record_id
	 */

	public function editDseSections() {

		$action_details = $this->viewDseAssessmentSection();

		//dump_array($action_details);exit;
		$action_details = $action_details[$this->dseInfo['question_id']];

		//dump_array($action_details);

		$sql = sprintf("UPDATE %s.dse_assessment_sections SET checkedYes = '%s',
													checkedNo = '%s',
													checkedNa = '%s',
													comments = '%s'
												WHERE ID = %d",_DB_OBJ_FULL,$this->dseInfo['is_yes'],$this->dseInfo['is_no'],$this->dseInfo['is_na'],
												smartisoAddslashes($this->dseInfo['comments']),$this->dseInfo['section_record_id']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->dseInfo['is_yes']);
		$pStatement->bindParam(2,$this->dseInfo['is_no']);
		$pStatement->bindParam(3,$this->dseInfo['is_na']);
		$pStatement->bindParam(4,$this->dseInfo['comments']);
		$pStatement->bindParam(5,$this->dseInfo['section_record_id']);*/

		$pStatement->execute();

		$is_no = (int) $this->dseInfo['is_no'];
		if ( $is_no ) {
			//echo $action_details['actionID']."--------";
			if ( $action_details['actionID'] ) {
				$this->editDseActions($action_details['actionID']);
				$action_id = $action_details['actionID'];
			} else {
				$action_id = $this->addDseActions();
			}

		} else {
			if ( $action_details['actionID'] ) {
				$this->actionHandling->setActionDetails($action_details['actionID'],"");
				$this->actionHandling->deleteAction();
				//echo $action_details['actionID']; exit;
			}
			$action_id = "";
		}

		$sql = sprintf("UPDATE %s.dse_assessment_sections SET actionID = %d WHERE ID = %d",_DB_OBJ_FULL,$action_id,$this->dseInfo['section_record_id']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$action_id);
		$pStatement->bindParam(2,$this->dseInfo['section_record_id']);*/
		$pStatement->execute();

		//dump_array($this);
	}

	/**
	 *This function manages the Edit Dse Action
	 *@access private
	 *@param integer $p_actionId This holds the action ID of action table
	 *@param integer $p_dseActionId This holds the dse Action ID
	 */
	private function editDseActions($p_actionId) {

		$edit_action_data = array('description'=>smartisoAddslashes($this->dseInfo['action']),'who'=>$this->dseInfo['who'],
										'due_date'=>$this->dseInfo['when']);

		//dump_array($edit_action_data);
		$this->actionHandling->setActionDetails($p_actionId,$edit_action_data);
		$this->actionHandling->updateAction();

		//dump_array($this);
	}

	/**
	 * This method is used to delete the dse assessment
	 */
	public function deleteDseAssessment() {

	}

	/*
	 * This method is used to list dse assessment records
	 * archive
	 */
	public function viewAllDseAssessments() {

		$sql = sprintf("SELECT * FROM %s.dse_assessment WHERE archive = '%s'  ORDER BY ID DESC",_DB_OBJ_FULL,$this->dseInfo['archive']);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->dseInfo['archive']);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		return $records;
	}

	/*
	 * This method is used to archive the dse assessment
	 */
	public function archiveDseAssessment() {

		$sql = sprintf("UPDATE %s.dse_assessment SET archive='%s' WHERE ID = %d",_DB_OBJ_FULL,$this->dseInfo['archive'],$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->dseInfo['archive']);
		$pStatement->bindParam(2,$this->dseId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to restore the dse assessment
	 *
	 */
	public function restoreDseAssessment() {
		$sql = sprintf("UPDATE %s.dse_assessment SET archive='0' WHERE ID = %d",_DB_OBJ_FULL,$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);
		//$pStatement->bindParam(1,$this->dseId);

		$pStatement->execute();
	}

	/*
	 * This method is used to remove the dse assessment
	 */
	public function purgeDseAssessment() {
		//
		$sections = array(2,3,4,5,6,7,8,9);

		foreach ( $sections as $value ) {
			$this->dseInfo['section_id'] = $value;
			$section_data = $this->viewDseAssessmentSection();

			if ( count ($section_data) ) {
				foreach ( $section_data as $valueSection ) {
					if ( $valueSection['actionID'] != '' ) {
						$this->actionHandling->setActionDetails($valueSection['actionID'],"");
						$this->actionHandling->deleteAction();
					}
				}
			}

			$sql = sprintf("DELETE FROM %s.dse_assessment_sections WHERE dID = %d AND section = %d",_DB_OBJ_FULL,$this->dseId,$this->dseInfo['section_id']);

			$pStatement = $this->dbHand->prepare($sql);

			/*$pStatement->bindParam(1,$this->dseId);
			$pStatement->bindParam(2,$this->dseInfo['section_id']);*/
			$pStatement->execute();
		}

		$sql = sprintf("DELETE FROM %s.dse_assessment WHERE ID = %d",_DB_OBJ_FULL,$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->dseId);
		$pStatement->execute();
	}

	/*
	 * This method is used to get the last dse assessment Id
	 */
	public function lastREcordId() {
		return $this->dseId;
	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('DSE');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('DSE');
		}

		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				/*$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';*/

				$sql = sprintf("SELECT M.reference,M.businessUnit,M.ID AS dse_id FROM %s.dse_assessment M
												INNER JOIN %s.dse_assessment_sections A
												ON A.dID = M.ID
											WHERE A.actionID = %d ",_DB_OBJ_FULL,_DB_OBJ_FULL,$search_value1);

				$pStatement = $this->dbHand->prepare($sql);

				//$pStatement->bindParam(1,$search_value1);

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['businessUnit'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['dse_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	protected function getDseGraphData() {
		$sql = sprintf("SELECT * FROM %s.dse_assessment_sections",_DB_OBJ_FULL);
		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($records) ) {
			foreach ( $records as $value ) {

				$section = $value['section'];
				$question = $value['question'];

				if ( $value['checkedYes'] ) {
					$graph_data[$section][$question]['yes']++;
				}
				if ( $value['checkedNo'] ) {
					$graph_data[$section][$question]['no']++;
				}
				if ( $value['checkedNa'] ) {
					$graph_data[$section][$question]['na']++;
				}

			}
		}

		return $graph_data;
	}

	protected function getDseProcessGraphData() {

		$this->dseInfo['archive'] = 0;
		$dse_records = $this->viewAllDseAssessments();

		if ( count($dse_records) ) {
			foreach( $dse_records as $value ) {

				$process_no = $value['processNo'];

				if ( $process_no ) {
					$graph_data[$value['processNo']]++;
				}
			}
		}
		return $graph_data;
	}

	public function updateStatus() {

		$sql = sprintf("UPDATE %s.dse_assessment SET status = '1' WHERE ID = %d ",_DB_OBJ_FULL,$this->dseId);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->dseId);
		$pStatement->execute();

	}

	public function sendActionAlerts($p_record_id) {

		$this->dseId = $p_record_id;

		$dse_details = $this->viewDseAssessment();

		$sql = sprintf("SELECT * FROM %s.dse_assessment_sections WHERE dID = %d ORDER BY section,question ASC",_DB_OBJ_FULL,$this->dseId);
		//exit;
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->dseId);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($records);

		if ( count($records) ) {
			$i = 0;
			foreach ( $records as $value ) {

				if ( $value['actionID'] ) {

					$this->actionHandling->setActionDetails($value['actionID'],"");
					$action = $this->actionHandling->viewAction();

					if ( count($action) ) {

						$dse_action = $action;
						$email_data[$i]['reference']	 = $dse_details['reference'];
						$email_data[$i]['summary']		 = $action['actionDescription'];
						$email_data[$i]['due_date']		 = format_date($action['dueDate']);
						$email_data[$i]['who']			 = $action['who'];
						/*echo $action['ID'];
						exit;*/

						$this->actionHandling->updateStatus($action['ID']);
						$i++;
					}

				}
			}
		}

		return $email_data;

	}

	public function getListingforExport() {

		$orgObj				= 		SetupGeneric::useModule('Organigram');
		$locObj				= 		SetupGeneric::useModule('Locationgram');
		$participantObj 	= 		SetupGeneric::useModule('Participant');

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
		$records['archive'] = $archive_session;

		$this->setDseAssessmentInfo(0,$records);
		$dse_data = $this->viewAllDseAssessments();

		$heading = array(array('DS #', 'EM #', 'Surname', 'Forename', 'Business Unit', 'Location'));

		foreach ( $dse_data as $element ) {

			$record_id	= $element['ID'];

			$orgObj->setItemInfo(array('id'=>$element['businessUnit']));
			$bu_details = $orgObj->displayItemById();
			$business_unit = $bu_details['buName'];

			$locObj->setItemInfo(array('id'=>$element['location']));
			$location_data = "";
			$location = $locObj->getFUllLocation();

			$location = str_replace(',', '-', $location);

			/* participant details*/
			$participantObj->setItemInfo(array('id'=>$element['nameParticipant']));
			$participant_details	= $participantObj->displayItemById();

			/* works number details*/
			$participantObj->setItemInfo(array('id'=>$element['worksNumber']));
			$work_details	= $participantObj->displayItemById();
			$works_no	= $work_details['worksNumber'];

			$first_name = $participant_details['forename'];
			$last_name = $participant_details['surname'];

			$result_data[$record_id] = array($element['reference'], $works_no, $last_name, $first_name, $business_unit, $location);

		}

		$result = array_merge($heading,$result_data);

		return $result;

	}

	public function getActionMailData($action_id) {

		global $dse_assessment_tabs;

		$sql = sprintf("SELECT dID,section FROM %s.dse_assessment_sections",_DB_OBJ_FULL);
		$sql = $sql." WHERE actionID = ".$action_id;

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$dse_action_data = $pStatement->fetch(PDO::FETCH_ASSOC);

		$dse_id = $dse_action_data['dID'];
		$dse_section_id = $dse_action_data['section'];
		$dse_tab = $dse_assessment_tabs[$dse_section_id];

		$sql2 = sprintf("SELECT * FROM %s.dse_assessment WHERE ID = %d",_DB_OBJ_FULL,$dse_id);
		$pStatement2 = $this->dbHand->prepare($sql2);
		$pStatement2->execute();

		$result = $pStatement2->fetch(PDO::FETCH_ASSOC);

		$mail_data['bu_id']		= $result['businessUnit'];
		$mail_data['reference']	= $result['reference'];
		$mail_data['dse_tab']	= $dse_tab;

		return $mail_data;

	}
}

?>