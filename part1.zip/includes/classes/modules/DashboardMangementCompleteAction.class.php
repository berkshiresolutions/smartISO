<?php
/**
  $Id: ActionTracker.class.php,v 4.29 Monday, May 01, 2018 4:40:01 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Interface to manage Organigram object
 *
 * This interface will declare the various methods performed
 * by organigram object for operations like add, edit, delete, archive, purge.
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Interface
 * @since  Thursday, September 09, 2010 6:29:33 PM>
 */
require_once(_MYCLASSES . '/graph/GraphModuleData.int.php');
require_once(_MYCLASSES . '/graph/GraphData.abs.php');

class DashboardMangementCompleteAction extends DashboardParent {

    /**
     * Constructor for initializing Action Tracker object
     * @access public
     */
    public $filter_query, $filters, $data_set;

    public function __construct() {
        $this->data_format = new GraphData();
        parent::__construct();
    }

    public function getCompletedMASRActions() {

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk' and approveAU=1";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk' and approveAU=1";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data['0']['complete_action'];
    }

    public function getMASRActionsTotal() {

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $sql = "select count(modulename) as complete_action from actions A inner join risk R on a.record=R.ID left join business_units B on R.buid=B.buID where modulename='risk'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data['0']['complete_action'];
    }

    public function getUserClass() {

        $id = getLoggedInUserId();

        $sql = "SELECT docClassification FROM " . _DB_OBJ_FULL . ".participant_meta_data
				WHERE participantID = " . $id;

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['docClassification'];
    }

    public function getDocAlertsActionTotal() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();
            $sql = "select count(A.cmsdocID) as total_document_alert from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' and D.classification in (%s)";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr, $bu_list);
        } else {
            $sql = "select count(A.cmsdocID) as total_document_alert from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' and D.classification in (%s)";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        }


        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
        return $results['0']['total_document_alert'];
    }

    public function getCompletedDocAlertsAction() {

        $classification = $this->getUserClass();
        $classArr = explode($classification, "'U','R','C','S','T'");
        $classStr = $classArr[0] . $classification . "'";

        if ($this->filter['selected_bu']) {
            $bu_list = $this->getAllBUs();
            $sql = "select count(A.cmsdocID) as total_document_alert_done from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' AND doneStatus ='L'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr, $bu_list);
        } else {
        echo    $sql = "select count(A.cmsdocID) as total_document_alert_done from %s.cms_document_alerts A inner join %s.cms_documents D on A.cmsdocID=D.cmsdocID where A.alertStatus='N' AND doneStatus ='L'";
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $classStr);
        }


        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();
        $results = $stmt->fetchaLL(PDO::FETCH_ASSOC);
        return $results['0']['total_document_alert_done'];
    }

    public function getGapFillingAction() {



        if ($this->filter['selected_bu']) {

            $bu_list = $this->getAllBUs();

            $psql = sprintf("SELECT count(*) as total_  FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description,RM.buID FROM %s.review_gap_question Q
                                INNER JOIN  dbSmartBeta.dbo.review_master RM ON RM.reviewID=Q.reviewID
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption != 'NA' ) V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID) D2
				ON D1.ID = D2.documentID AND buID IN (%s)", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $bu_list);
        } else {

            $psql = sprintf("SELECT count(*) as total_ FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description FROM %s.review_gap_question Q
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption != 'NA' ) V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID) D2
				ON D1.ID = D2.documentID ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }



        $stmt = $this->dbHand->prepare($psql);
        $stmt->execute();

        $result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result_data[0]['total_'];
    }

    public function getCompletedGapQuestionActionTracker($p_assignedToMe = true, $p_due_date = '') {

        if ($p_due_date != '') {
            $filter_date = "whenDate <= '" . $p_due_date . "'";
        }
        
        
        
        if ($this->filter['selected_bu']) {

          $bu_list = $this->getAllBUs();
          $psql = sprintf("SELECT * FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description FROM %s.review_gap_question Q
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption != 'NA' ) V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID
				WHERE  $filter_date) D2
				ON D1.ID = D2.documentID ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
            
            
            } else {

         $psql = sprintf("SELECT * FROM (SELECT *
				FROM %s.question_docs) D1
				INNER JOIN
				(SELECT Q.reviewID,whenDate,Q.documentID,Q.participantID,description FROM %s.review_gap_question Q
				INNER JOIN (SELECT * FROM %s.review_gap_docs_viewed
				WHERE siconaOption != 'NA' ) V
				ON Q.reviewID = V.reviewID
				AND Q.documentID = V.documentID
				WHERE  $filter_date) D2
				ON D1.ID = D2.documentID ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);
        }

        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result[0]['total_completed'];
    }

    
   public function get_percentage($percentage, $of)
    {      
        if ($of != 0)
        $percent = $percentage / $of;
        else
        $percent =0;
       
        return  number_format( $percent * 100, 2 ) . '%';;
    }
    
    public function getGraphData() {

        $bu_list = array();
        $hlist = array();
        $dlist = array();

        $q1_sr = $this->qtrsRange['q1_sr'];
        $q1_er = $this->qtrsRange['q1_er'];
        $q2_sr = $this->qtrsRange['q2_sr'];
        $q2_er = $this->qtrsRange['q2_er'];
        $q3_sr = $this->qtrsRange['q3_sr'];
        $q3_er = $this->qtrsRange['q3_er'];
        $q4_sr = $this->qtrsRange['q4_sr'];
        $q4_er = $this->qtrsRange['q4_er'];
        $q5_sr = $this->qtrsRange['q5_sr'];
        $q5_er = $this->qtrsRange['q5_er'];
        $cqtr = $this->qtrsRange['cqtr'];


//        $complete_msr_action = $this->getCompletedMASRActions();
//        $total_msr_action = $this->getMASRActionsTotal();
//       
//
//        $complete_document_alert = $this->getCompletedDocAlertsAction();
//        $document_alert_total = $this->getDocAlertsActionTotal();
//
//        $complete_gap_filling = $this->getCompletedGapQuestionActionTracker();
//        $gap_filling_total = $this->getGapFillingAction();

        $data_stat_type = strip_tags($_GET['data_stat_type']);
       
        $module_name = 'gap_filling';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name);
        $dashObj->setFilter(array('selected_bu'=>$this->filter['selected_bu']));
        $dashObj->setBlockRange($_GET['data_stat_type']);
        $grid_data = $dashObj->getData();
        $gap_c_total= $grid_data['q5']['D'];
        $gap_p_total= $grid_data['q5']['P'];
        $gap_total= $grid_data['q6']['A']+$gap_p_total+$gap_c_total;
       
       
        $module_name2 = 'Msr';
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name2);
        $dashObj->setFilter(array('selected_bu'=>$this->filter['selected_bu']));
        $dashObj->setBlockRange($_GET['data_stat_type']);
        $msr_data = $dashObj->getData();
        $msr_c_total= $msr_data['q5']['D'];
        $msr_p_total= $msr_data['q5']['P'];
        $msr_total= $msr_data['q6']['A']+$msr_p_total+$msr_c_total;
        
        
        
        
        $module_name1 = 'Document';       
        $dashObj = new DashboardGraph();
        $dashObj->setGridType($module_name1);
        $dashObj->setFilter(array('selected_bu'=>$this->filter['selected_bu']));
        $dashObj->setBlockRange($_GET['data_stat_type']);
        $doucment_data = $dashObj->getData();
        $document_c_total= $doucment_data['q5']['D'];
        $document_p_total= $doucment_data['q5']['P'];
        $document_total= $doucment_data['q6']['A']+$document_p_total+$document_c_total;
        
       
        
        
        
        
        $complete_gap_filling = $gap_c_total;
        $gap_filling_total =$gap_total;
        
       
        $complete_msr_action = $msr_c_total;
        $total_msr_action = $msr_total;
       

        $complete_document_alert = $document_c_total;
        $document_alert_total = $document_total;

        
        
        $gap_filling_percentage =$this->get_percentage($complete_gap_filling,$gap_filling_total);
        $document_percentage =$this->get_percentage($complete_document_alert,$document_alert_total);
        $msr_percentage =$this->get_percentage($complete_msr_action,$total_msr_action);
        
        
        
       
        
        
        $this->data_format->addData('Gap Filling', $gap_filling_percentage);        
        $this->data_format->addData('MSR', $msr_percentage);
        $this->data_format->addData('Document Alerts', $document_percentage);
        $this->data_format->getGraphData();

        $this->data_set['chart_data'][] = $this->data_format->graph_data;
        $this->data_set['heading'] = 'Mangement Completed Action';
        $this->data_set['xaxis_text'] = "Actions";
        $this->data_set['yaxis_text'] = "% age of Completed Action";       
        return $this->data_set;
        
    }

   

}
