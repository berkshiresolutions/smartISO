<?php
 /**
  $Id: IncidenceMain.class.php,v 3.89 Wednesday, February 02, 2011 2:50:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, November 03, 2010 12:25:00 PM>
  */
require_once "ModuleHistory.int.php";
require_once "Action.class.php";

class ContractReviewsHistory implements ModuleHistoryInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;
	private $tables;
	private $recordId;
	private $subReference;

	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);

		$this->tables[] 		= 'contract_reviews';
		$this->tables[]			= 'contract_actions';
	}

	public function setItemInfo($p_record_id) {
		$this->recordId = $p_record_id;
	}

	public function sendToHistory() {

		if ( count($this->tables) ) {
			foreach ( $this->tables as $tablename ) {

				$method = '_'.$tablename;
				$this->$method();
			}
		}
	}

	private function _contract_reviews() {

		$tablename 				= 'contract_review';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from incidence_participants
		 */
		$sql = sprintf("insert into %s.%s select * from %s.%s where review_ID=%d",
						_DB_OBJ_FULL,
						$tablename_historical,
						_DB_OBJ_FULL,
						$tablename,
						$this->recordId);
			$pStatement2 = $this->dbHand->prepare($sql);
			$pStatement2->execute();

		$upd = sprintf("UPDATE %s.".$tablename."
					   SET subReference = subReference + 1,
					   cmRejected=1,
					   maRejected=0,
					   daRejected=0,
					   cmApproved=0,
					   maApproved=0,
					   daApproved=0,
					   notes=' ',
					   maNotes='',
					   daNotes='',
					   approved=0
					   WHERE review_ID = %d",
						_DB_OBJ_FULL,
						$this->recordId);


		$pStatement2 = $this->dbHand->prepare($upd);
		$pStatement2->execute();
		
		}
	

	private function _contract_actions() {

		$tablename 				= 'contract_actions';
		$tablename_historical 	= $tablename.'_historical';

		/**
		 *
		 * Get Data from incidence_witness
		 */
$sql = sprintf("insert into %s.%s select * from %s.%s where contractreviewID=%d",
						_DB_OBJ_FULL,
						$tablename_historical,
						_DB_OBJ_FULL,
						$tablename,
						$this->recordId);

			$pStatement2 = $this->dbHand->prepare($sql);
			$pStatement2->execute();
		}
	
}
?>