<?php
 /**
  $Id: DseAssessment.int.php,v 3.08 Saturday, October 09, 2010 10:01:10 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage dse assessment object
  *
  * This interface will declare the various methods performed
  * by the dse assessment object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface DseAssessmentInterface
{
	/*
	 * to set dse assessment information for performing various operations with the dse assessment object
	 */
	public function setDseAssessmentInfo($p_dseAssessmentId,$p_dseAssessmentInfo);

	/*
	 * This method is used to add a new dse assessment
	 */
	public function addDseAssessment();

	/*
	 * This method is used to view dse assessment information.
	 */
	public function viewDseAssessment();

	/*
	 * This method is used to edit the dse assessment
	 */
	public function editDseAssessment();

	/*
	 * This method is used to delete the dse assessment
	 */
	public function deleteDseAssessment();

	/*
	 * This method is used to archive the dse assessment
	 */
	public function archiveDseAssessment();

	/*
	 * This method is used to remove the dse assessment
	 */
	public function purgeDseAssessment();

}