<?php
 /**
  $Id: Risk27k.int.php,v 3.05 Tuesday, October 19, 2010 12:02:34 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  *Interface to manage Risk 27k object
  *
  * This interface will declare the various methods performed
  * by the Risk 27k object for operations like add, edit, delete, archive, purge.
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Monday, October 18, 2010 4:15:16 PM>
  */

interface Risk27kInterface
{
	/*
	 * to set Risk 27k information for performing various operations with the Risk 27k object
	 */
	public function setRisk27kInfo($p_Risk27kId,$p_Risk27kInfo);

	/*
	 * This method is used to add a new Risk 27k
	 */
	public function addRisk27k();

	/*
	 * This method is used to view the Risk 27k information.
	 */
	public function viewRisk27k();

	/*
	 * This method is used to edit the Risk 27k
	 */
	public function editRisk27k();

	/*
	 * This method is used to delete the Risk 27k
	 */
	public function deleteRisk27k();

	/*
	 * This method is used to archive the Risk 27k
	 */

	public function archiveRisk27k();

	/*
	 * This method is used to remove the Risk 27k
	 */
	public function purgeRisk27k();

}

?>