<?php
 /**
  $Id: ActionTrackerRisk.class.php,v 3.43 Wednesday, January 26, 2011 6:09:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";
/*
class ActionTrackerRisk extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;

	public function getPendingMeActions() {

		$this->sql_query = sprintf("SELECT R.ID,R.processID,R.processStepID,R.hazardSummary,R.improvements,R.newAction,S.processRreference,S.buID,S.done FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedMeActions() {

		$this->sql_query = sprintf("SELECT R.hazardSummary,R.improvements,S.processRreference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getPendingOtherActions() {

		$this->sql_query = sprintf("SELECT R.ID,R.processID,R.processStepID,R.hazardSummary,R.improvements,R.newAction,S.processRreference,S.buID,S.done FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedOtherActions() {

		$this->sql_query = sprintf("SELECT R.hazardSummary,R.improvements,S.processRreference,S.buID FROM %s.risk R
				INNER JOIN %s.swimlane S
				ON R.processID = S.swimID
				WHERE R.improvements IS NOT NULL
				ORDER BY R.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	private function getActionsByFilter($p_callingMethod) {

		$USER_ID = getLoggedInUserId();

		$p_callingMethod_arr 	= explode('::',$p_callingMethod);
		$calling_method 		= $p_callingMethod_arr[1];
		//echo $calling_method;

		$pStatement = $this->dbHand->prepare($this->sql_query);
		$pStatement->execute();

		$result 				=  $pStatement->fetchAll(PDO::FETCH_ASSOC);
		//dump_array($result);
		$this->new_resultset 	= array();

		$organoObj = SetupGeneric::useModule('Organigram');

		if ( $result ) {
			foreach ( $result as $result_element ) {
			
			//dump_array($result_element);

				if ( $result_element['improvements'] != '' ) {

					$improvements_arr = explode(',',$result_element['improvements']);
					//dump_array($improvements_arr);
					foreach ( $improvements_arr as $improvements_ele ) {
								//dump_array($improvements_ele);
						$organoObj->setItemInfo(array('id'=>$result_element['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();

						$this->new_resultset[$improvements_ele] = array('hazardSummary'=>$result_element['hazardSummary']
																  ,'processRreference'=>$result_element['processRreference']
																  ,'buID'=>$result_element['buID']
																  ,'done'=>$result_element['done']
																   ,'r_ID'=>$result_element['ID']
																    ,'p_ID'=>$result_element['processID']
																	 ,'p_s_ID'=>$result_element['processStepID']
																	 ,'new_action'=>$result_element['newAction']
																	  ,'imp'=>$result_element['improvements']
																  ,'buName'=>$business_unit_arr['buName']);
					}
					//dump_array($this->new_resultset);

				}
			}
		}

		$organoObj = null;

		$module_info = array();

		//echo $calling_method;
		//dump_array($this->moduleInfo);
		if ($this->moduleInfo) {

			$participantObj = SetupGeneric::useModule('participant');

			foreach ( $this->moduleInfo as $module_element ) {

				$participantObj->setItemInfo(array('id'=>$module_element['who']));
				$participant_arr 				= $participantObj->displayItemMaininfoById();
				$module_element['who_name'] 	= $participant_arr['forename'].' '.$participant_arr['surname'];

				$module_element['approveAU'] = (int) $module_element['approveAU'];

				if ( $calling_method == 'getPendingMeActions' ) {

					if ( $USER_ID == $module_element['who']  && $module_element['approveAU']==0 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				if ( $USER_ID == $module_element['whoAU']  && $module_element['approveAU']==0 && $module_element['doneDescription']  ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getPendingOtherActions' ) {
				
				//dump_array($module_element);

					if (  $module_element['approveAU']==0 && ( $USER_ID != $module_element['who'] && $module_element['who'] != 0) ) {
							
						$module_info[$module_element['ID']] = $module_element;
						//dump_array($module_info);
					}
				} else if ( $calling_method == 'getCompletedMeActions' ) {

					if ( ( $USER_ID == $module_element['who'] ) && $module_element['approveAU']==1 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedOtherActions' ) {

					if ( $USER_ID != $module_element['who'] && $module_element['who'] != 0 && $module_element['approveAU']==1 ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				}
			}
		}

		ksort($module_info);
		$module_info = array_reverse($module_info,true);
		ksort($this->new_resultset);

		array_walk(& $module_info,array($this,'combine_actions_with_data'));
		//dump_array($module_info);
		return $module_info;

	}

	private function combine_actions_with_data(& $item,$key) {

		$item['hazardSummary'] 	= $this->new_resultset[$key]['hazardSummary'];
        $item['processRreference'] 		= $this->new_resultset[$key]['processRreference'];
        $item['buID'] 			= $this->new_resultset[$key]['buID'];
		$item['done'] 			= $this->new_resultset[$key]['done'];
		$item['r_ID'] 			= $this->new_resultset[$key]['r_ID'];
		$item['new_action'] 			= $this->new_resultset[$key]['new_action'];
		$item['p_ID'] 			= $this->new_resultset[$key]['p_ID'];
		$item['p_s_ID'] 			= $this->new_resultset[$key]['p_s_ID'];
		$item['buName'] 			= $this->new_resultset[$key]['buName'];
		$item['imp'] 			= $this->new_resultset[$key]['imp'];
	}
 * 
 * 
 */
class ActionTrackerICR extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;
        
            public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
    $this->sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,R.reviewID,M.reference from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID where modulename='ICR_action'  and A.status=1  and currentWho=%d and approveAU=0
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
        $this->sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,R.reviewID,M.reference from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID where modulename='ICR_action' and A.who=%d and approveAU=1
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();


        if (isAdministrator()) {
         $this->sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,R.reviewID,M.reference from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID where modulename='ICR_action'   and A.status=1  and approveAU=0 and not currentWho=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {

           		$this->sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,R.reviewID,M.reference from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID where modulename='ICR_action'  and A.status=1   and approveAU=0 and whoAU=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

        return $this->getActionsByFilter(__METHOD__);
    }
    public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {
            $this->sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,R.reviewID,M.reference from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID where modulename='ICR_action'  and approveAU=1 and not A.who=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {

        			 $this->sql_query = sprintf("select A.id,Q.question,B.buName,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,R.reviewID,M.reference from %s.actions A inner join %s.review_answers R on a.record=R.ID inner join %s.review_questions_mse Q on R.questionid=Q.ID inner join %s.review_master M on R.reviewID=M.reviewID left join %s.business_units B on M.buid=B.buID where modulename='ICR_action'  and approveAU=1 and whoAU=%d
							ORDER BY R.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }
       
        return $this->getActionsByFilter(__METHOD__);
    }

    private function getActionsByFilter($p_callingMethod) {

        $USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
        //echo $calling_method;

        $pStatement = $this->dbHand->prepare($this->sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
}