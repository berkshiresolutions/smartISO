<?php

/**
  $Id: Meeting.class.php,v 3.19 Saturday, January 08, 2011 6:27:13 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Saturday, October 09, 2010 12:50:41 PM>
 */
require "Meetings.int.php";
require_once "Action.class.php";

class Meetings implements MeetingsInterface {

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Property to hold Meeting Id
     * @access private
     */
    private $meetId;

    /**
     * Property to hold Meeting Info
     * @access private
     */
    private $meetInfo;

    /**
     * Constructor for initializing Manual Handling object
     * @access public
     */
    public function __construct() {

        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /**
     * to set comm information for performing various operations with the comm object
     * @param integer This parameter holds the comm Id
     * @param array This parameter holds the the comm Info
     */
    public function setMeetingInfo($p_meetId, $p_meetInfo) {

        $this->meetId = $p_meetId;
        $this->meetInfo = $p_meetInfo;
    }



    public function addMeeting() {


  $sql = sprintf("INSERT INTO %s.meeting_master ( Reference , firstdate , Title ,owner, type , week , day , monthlyperiod )
     VALUES
           ('%s','%s','%s',%d,%d,%d ,%d,%d)", _DB_OBJ_FULL
		   ,$this->meetInfo['reference_number']
		   ,$this->meetInfo['date1']
		   ,$this->meetInfo['title']
		    ,$this->meetInfo['owner']
		   ,$this->meetInfo['type']
		   ,$week
		   ,$day
		   ,$this->meetInfo['period']);


        $pStatement = $this->dbHand->prepare($sql);


        $pStatement->execute();

        $this->meetId = customLastInsertId($this->dbHand, 'meeting_master', 'ID');


	  $sql = sprintf("INSERT INTO %s.meetings ( meetingsid ,nextdate,meettime )
     VALUES
           (%d,'%s','%s')", _DB_OBJ_FULL
		   ,$this->meetId
		   ,$this->meetInfo['date1']
                  ,$this->meetInfo['meettime']
		  );
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();	
		
    $this->meetingId = customLastInsertId($this->dbHand, 'meetings', 'ID');
	
	
	foreach($this->meetInfo['who'] as $who){
			  $sql = sprintf("INSERT INTO %s.meetings_attendees ( meetingsId ,participantID )
     VALUES
           (%d,'%s')", _DB_OBJ_FULL
		   ,$this->meetingId
		   ,$who
		  );
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();	
	}
	
	
        if ($this->meetInfo['save'] == 1) {
                 $this->finish();
             }
           
    }

    /**
     * This method is used to view meet information.
     */
    public function viewMeeting() {

        $sql = sprintf("SELECT * FROM %s.meeting_master WHERE ID =%d", _DB_OBJ_FULL, $this->meetId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $result = $pStatement->fetch(PDO::FETCH_ASSOC);



        return $result;
    }

    /**
     * This method is used to edit a meet
     * location,consider_risk,description,is_phone,is_fax,is_person,is_email,is_letter,first_name,last_name,relationship
     * address,phone,email,meet_nature,likelihood,impact,risk_rating,risk_color,meet_category,investigation,action,who,when
     */
    public function archiveMeeting() {
        
    }

    public function editMeeting() {

       $sql = sprintf("UPDATE %s.meetings SET date_r = '" . $this->meetInfo['date_r'] . "',
										client = '" . $this->meetInfo['client'] . "',
										date_u = '" . $this->meetInfo['date_u'] . "',
                                                                                docdate = '" . $this->meetInfo['docdate'] . "',
										process_r = '" . $this->meetInfo['process_r'] . "',
										title = '" . $this->meetInfo['title'] . "',
										country = '" . $this->meetInfo['country'] . "',
										type = '" . $this->meetInfo['type'] . "',
										action_r = '" . $this->meetInfo['action_r'] . "',
										received = '" . $this->meetInfo['received'] . "',
										company = '" . $this->meetInfo['company'] . "',
										document_n = '" . $this->meetInfo['document'] . "',
										descp = '" . $this->meetInfo['description'] . "',
										related = '" . $this->meetInfo['related'] . "',
										document_c = '" . $this->meetInfo['document_class'] . "',
										bu = '" . $this->meetInfo['bu'] . "',
                                                                                who = '" . $this->meetInfo['owner'] . "',
                                                                                in_out = '" . $this->meetInfo['in_out'] . "',
                                                                                media_type = '" . $this->meetInfo['media'] . "',
                                                                                audit = '" . $this->meetInfo['audit'] . "',
                                                                                induct = '" . $this->meetInfo['induct'] . "',
										criteria = '" . $this->meetInfo['criteria'] . "',
archive_date = '" . $reviewdate . "',
										meetents = '" . $this->meetInfo['meetents'] . "',
                                                                               country_from = " . $this->meetInfo['countryf'] . ",
										drop_n = '" . $this->meetInfo['drop'] . "'
								WHERE ID = " . $this->meetId, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

                 if ($this->meetInfo['save'] == 1) {

      
                 $this->finish();
             }
             
    }
    

    /**
     * This method is used to delete a meet
     */
    public function deleteMeeting() {
        
    }


    /**
     * This method is used to remove a meet
     */
    public function purgeMeeting() {
        
    }

    /**
     * This method is used to last insertted record Id
     */
    public function lastrecordId() {
        return $this->meetId;
    }

    /**
     * This method is used to view all meets.
     */
    public function viewAllMeetings() {

    $sql = sprintf("SELECT M.*,ME.nextdate,ME.meettime,P.surname,P.forename FROM %s.meeting_master M inner join %s.meetings ME on M.ID=ME.meetingsid inner join %s.participant_database P on M.owner=P.participantID WHERE isnull(M.archive,0)=0  ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);



        return $result;
    }


   

    public function archiveRecord() {

        $sql = sprintf("UPDATE %s.meetings SET archive = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->meetId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

  
    public function finish() {

                      $participantObj = SetupGeneric::useModule('Participant');        
            $optionObj = new Option();
            $emailObj = new actionEmailHelper(0);
            $ghl = $optionObj->getOption('_SU_GROUP_EMAIL');
            $dataC=$this->displayId($this->meetId)  ; 
            $userID = getLoggedInUserId();


            $participantObj->setItemInfo(array('id' => $ghl));

            $details = $participantObj->displayItemById();

            $whoGLOC = array(
                'displayname' => 'GHL Group',
                'email' => $ghl,
                'ID' => $details['participantID']
            );

            $participantObj->setItemInfo(array('id' => $userID));

            $details = $participantObj->displayItemById();
            $data = array(
                'singleColData' => array(
                    'meetent' => 'The above Library  record has been completed <BR></BR>','click-here-url' => 'Finalise this Issue: <BR/><BR/>Please <a href="http://' . $_SERVER['HTTP_HOST'] . '/management/add_gcuedit_meet.php?id=' . $this->meetId . '">CLICK</a> Here to approve this record'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $dataC["reference"]
                    ),
                    'assignedto' => array(
                        'left' => '<strong>Assigned To:</strong>',
                        'right' => 'GHL Group'
                    ),
                    'from' => array(
                        'left' => '<strong>From</strong>',
                        'right' => ucwords($details['forename'] . ' ' . $details['surname'])
                    )
                )
            );


            $emailObj->appendInfo($data);

           $emailObj->sendEmail('A Library Entry has been Completed', $whoGLOC, array(), array(), 'me_completed', '', 'grey');
        
        
      $sql = sprintf("update   %s.meets_mangement set completed =3 where ID =%d ", _DB_OBJ_FULL, $this->meetId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }
                    
     
        
   


    

    

}
?>
