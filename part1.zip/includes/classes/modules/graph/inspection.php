<?php
 /**
  $Id: nhp.php,v 3.11 Saturday, January 22, 2011 10:38:56 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage NHP Graph
  * @since  Wednesday, December 01, 2010 4:42:05 PM>
  */
    require_once "GraphModuleData.int.php";
	require_once "GraphData.abs.php";

class InspectionGraph extends NhpMain implements GraphModuleData {

	private $filter_query;
	private $filters;
	private $data_set;
	private $buObj;
	private $org_data;
	private $childTotal;

	public function __construct() {

		$this->data_format = new GraphData();

		// organigram object
		$this->buObj = SetupGeneric::useModule('Organigram');

		parent::__construct();
	}

	/* to set the filters for search */
	public function setFilter($filter_fields) {
		$this->filters = $filter_fields;
		//dump_array($filter_fields);
	}

	public function processData($p_type='main') {


		if ( empty($this->filters['bu']) ) {
			$this->buObj->setItemInfo(array(
													'id'=>0
											));
		} else {
			$this->buObj->setItemInfo(array(
													'id'=>$this->filters['bu']
											));
		}

		$partObj = SetupGeneric::useModule('Participant');
		$this->participant_count = $partObj->getActiveParticipantCount();
		$partObj = null;

		$current_bu_info = $this->buObj->displayItemByIdForMSR();
		$current_bu_id = $current_bu_info['buID'];

		$child_business_units = $this->buObj->displayBuIDByPid();
		//echo $p_type;
		if ( $p_type == 'main' ) {

			$nhp_info = $this->resultSet();
			if ( $this->filters['subtype'] == 'A' ) {
				$nhp = $nhp_info['all'];
			}
			if ( $this->filters['subtype'] == 'N' ) {
				$nhp = $nhp_info['close_call'];
			}
			if ( $this->filters['subtype'] == 'H' ) {
				$nhp = $nhp_info['hazard'];
			}
			if ( $this->filters['subtype'] == 'O' ) {
				$nhp = $nhp_info['conformance'];
			}

			//$nhp = $this->resultSetType();

			//dump_array($nhp);

			$this->buObj->clearStack();
			$this->buObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->buObj->getStack();

			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					//$current_bu_acc_count += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele]['0'];
					if ( $this->filters['subtype'] == 'N' ) {
						$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['subtype'] == 'H' ) {
						$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['subtype'] == 'A' ) {
						$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['subtype'] == 'O' ) {
						$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
					}
				}
			}
			
			
			

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			//dump_array($current_bu_acc_count);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->buObj->clearStack();
					$this->buObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->buObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->buObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->buObj->getStack();

					$current_childbu_acc_count = 0;
					//dump_array($business_units_stack);
					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							if ( $this->filters['subtype'] == 'N' ) {
									$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
							}
							if ( $this->filters['subtype'] == 'H' ) {
									$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
								}
							if ( $this->filters['subtype'] == 'A' ) {
									$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
							}
							if ( $this->filters['subtype'] == 'O' ) {
								$current_bu_acc_count += (int) $nhp[$this->filters['year']][$business_units_stack_ele];
							}
						}
					}

					$child_arr[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}

			//dump_array($this->filters);

			//
			$graph_heading = $this->filters['bu_name'] == '' ? "NHC Graph" : $this->filters['bu_name']." - ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>"Number of NHC",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>"Number of NHC",
						'yaxis_text'=>$yaxis_text,
						)
					);

		} // end of main condition
		else if ( $p_type == 'risk_impact' ) {

			$nhp_info = $this->resultSetImpact();

			$impact = SetupGeneric::useModule('ImpactMeasure');
			$impact_measures_data_records = $impact->displayItems();
			$impact = null;

			$impact_measures = array();
			$main_chart_data = array();

			if ($impact_measures_data_records) {
				foreach ( $impact_measures_data_records as $impact_measures_data_record_ele ) {

					$name_arr 								= explode("|",$impact_measures_data_record_ele['name']);
					$impact_id 								= $impact_measures_data_record_ele['ID'];
					$impact_measures[$impact_id] 			= trim($name_arr[0]," ");
					$current_childbu_acc_count[$impact_id] 	= 0;
					$current_bu_acc_count[$impact_id]		= 0;
				}
			}

			$this->buObj->clearStack();
			$this->buObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->buObj->getStack();

			if ( count($business_units_stack) ) {
				foreach ( $impact_measures as $impact_measure_ele_k=>$impact_measure_ele_v ) {
					$current_bu_acc_count[$impact_measure_ele_k] =0;
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					
						$current_bu_acc_count[$impact_measure_ele_k] += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele][$impact_measure_ele_k];
					}
				}

				foreach ( $impact_measures as $impact_measure_ele_k=>$impact_measure_ele_v ) {

					if ( $impact_measure_ele_v == '=>3 Days' ) {
						$label = 'Greater than Equal to 3 Days';
					} else if ( $impact_measure_ele_v == '< 3 Days' ) {
						$label = 'Less than 3 Days';
					} else {
						$label = $impact_measure_ele_v;
					}

					$main_chart_data[] = array('key'=>ucwords($label),'value'=>$current_bu_acc_count[$impact_measure_ele_k]);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->buObj->clearStack();
					$this->buObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->buObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->buObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->buObj->getStack();

					if ( count($business_units_stack) ) {
							foreach ( $impact_measures as $impact_measure_ele_k=>$impact_measure_ele_v ) {
								$current_childbu_acc_count[$impact_measure_ele_k] =0;
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
						
								$current_childbu_acc_count[$impact_measure_ele_k] += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele][$impact_measure_ele_k];
							}

						}
					}

					foreach ( $impact_measures as $impact_measure_ele_k=>$impact_measure_ele_v ) {

						$child_arr[$impact_measure_ele_k][] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count[$impact_measure_ele_k]);

					}
				}
			}

			//dump_array($child_arr);

			//
			$graph_heading = $this->filters['bu_name'] == '' ? "NHC Graph" : $this->filters['bu_name']." - ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>$main_chart_data,
						'heading'=>$graph_heading,
						'xaxis_text'=>"Number of NHC",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>"Number of NHC",
						'yaxis_text'=>$yaxis_text,
						)
					);

		} // end of risk impact condition

		else if ( $p_type == 'disposition' ) {

			$nhp_info = $this->resultSetDisposition();
            //dump_array($nhp_info);
			$nhpObj  = SetupGeneric::useModule('NhpOption');
			$disposition_data_records = $nhpObj->displayItems();
			$nhpObj = null;

			$dispositions = array();
			$main_chart_data = array();

			if ($disposition_data_records) {
				foreach ( $disposition_data_records as $disposition_data_record_ele ) {

					if ( $disposition_data_record_ele['envSubType'] == 'D' ) {

						$disposition_id 						= $disposition_data_record_ele['ID'];
						$dispositions[$disposition_id] 			= trim($disposition_data_record_ele['optionLabel']," ");
						$current_childbu_acc_count[$impact_id] 	= 0;
						$current_bu_acc_count[$impact_id]		= 0;
					}
				}
			}

			$this->buObj->clearStack();
			$this->buObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->buObj->getStack();

			if ( count($business_units_stack) ) {
				foreach ( $dispositions as $dispositions_ele_k=>$dispositions_ele_v ) {
					$current_bu_acc_count[$dispositions_ele_k] =0;

				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					
						//dump_array($dispositions);
						$current_bu_acc_count[$dispositions_ele_k] += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele][$dispositions_ele_k];
					}
				}

				foreach ( $dispositions as $dispositions_ele_k=>$dispositions_ele_v ) {

					$main_chart_data[] = array('key'=>ucwords($dispositions_ele_v),'value'=>$current_bu_acc_count[$dispositions_ele_k]);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->buObj->clearStack();
					$this->buObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->buObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->buObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->buObj->getStack();

					if ( count($business_units_stack) ) {
						foreach ( $dispositions as $dispositions_ele_k=>$dispositions_ele_v ) {
							$current_childbu_acc_count[$dispositions_ele_k]=0;
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							
								//dump_array($dispositions);
								$current_childbu_acc_count[$dispositions_ele_k] += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele][$dispositions_ele_k];
							}

						}
					}

					foreach ( $dispositions as $dispositions_ele_k=>$dispositions_ele_v ) {

						$child_arr[$dispositions_ele_k][] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count[$dispositions_ele_k]);

					}
				}
			}

			//dump_array($child_arr);

			//
			$graph_heading = $this->filters['bu_name'] == '' ? "NHC Graph" : $this->filters['bu_name']." - ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>$main_chart_data,
						'heading'=>$graph_heading,
						'xaxis_text'=>"Number of Dispositions",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>"Number of Dispositions",
						'yaxis_text'=>$yaxis_text,
						)
					);

		} // end of disposition condition

		else if ( $p_type == 'causes' ) {

			$nhp_info = $this->resultSetCauses();
			//dump_array($nhp_info);
			$causes = array();

			$causes['unsafe_act'] 			= 'unsafe_act';
			$causes['unsafe_design'] 		= 'unsafe_design';
			$causes['faulty_construction'] 	= 'faulty_construction';
			$causes['unsafe_condition'] 	= 'unsafe_condition';
			$causes['unsafe_method'] 		= 'unsafe_method';

			$main_chart_data = array();

			$current_childbu_acc_count['unsafe_act'] 			= 0;
			$current_childbu_acc_count['unsafe_design'] 		= 0;
			$current_childbu_acc_count['faulty_construction'] 	= 0;
			$current_childbu_acc_count['unsafe_condition'] 		= 0;
			$current_childbu_acc_count['unsafe_method'] 		= 0;

			$current_bu_acc_count['unsafe_act']				= 0;
			$current_bu_acc_count['unsafe_design']			= 0;
			$current_bu_acc_count['faulty_construction']	= 0;
			$current_bu_acc_count['unsafe_condition']		= 0;
			$current_bu_acc_count['unsafe_method']			= 0;

			$this->buObj->clearStack();
			$this->buObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->buObj->getStack();

			if ( count($business_units_stack) ) {
					foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {
						$current_childbu_acc_count[$causes_ele_k] =0;
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
				
						$current_bu_acc_count[$causes_ele_k] += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele][$causes_ele_k];
					}
				}

				foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {

					$main_chart_data[] = array('key'=>ucwords($causes_ele_v),'value'=>$current_bu_acc_count[$causes_ele_k]);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->buObj->clearStack();
					$this->buObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->buObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->buObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->buObj->getStack();
						
					if ( count($business_units_stack) ) {
						
						foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {
							
							$current_childbu_acc_count[$causes_ele_k] =0;
						foreach ( $business_units_stack as $business_units_stack_ele ) {
						//	$current_childbu_acc_count[$causes_ele_k]
							//dump_array($accident_info[$this->filters['year']]);
							
								
								$current_childbu_acc_count[$causes_ele_k] += (int) $nhp_info[$this->filters['year']][$business_units_stack_ele][$causes_ele_v];
							}

						}
					}

					foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {

						$child_arr[$causes_ele_k][] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count[$causes_ele_k]);

					}
				}
			}

			//dump_array($child_arr);

			//
			$graph_heading = $this->filters['bu_name'] == '' ? "NHC Graph" : $this->filters['bu_name']." - ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>$main_chart_data,
						'heading'=>$graph_heading,
						'xaxis_text'=>"Number of NHC Causes",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>"Number of NHC Causes",
						'yaxis_text'=>$yaxis_text,
						)
					);

		} else if ( $p_type == 'environment' ) {
			$nhp_info = $this->resultSetEnvironment();
			//dump_array($nhp_info);
			if ( $this->filters['subtype'] == 'T' ) {
				$nhp = $nhp_info['type'];
				//dump_array($nhp);
				$causes = array();

				$causes['Fauna/Flora'] 			= 'Fauna/Flora';
				$causes['Water Pollution'] 		= 'Water Pollution';
				$causes['Noise/Vibration'] 	= 'Noise/Vibration';
				$causes['Fire'] 	= 'Fire';
				$causes['Gas/Fumes'] 		= 'Gas/Fumes';
				$causes['Chemical/Oil Spill'] 		= 'Chemical/Oil Spill';

				$main_chart_data = array();

					$current_childbu_acc_count['Fauna/Flora'] 			= 0;
				$current_childbu_acc_count['Water Pollution'] 		= 0;
				$current_childbu_acc_count['Noise/Vibration'] 	= 0;
				$current_childbu_acc_count['Fire'] 		= 0;
				$current_childbu_acc_count['Gas/Fumes'] 		= 0;
				$current_childbu_acc_count['Chemical/Oil Spill'] 		= 0;

				$current_bu_acc_count['Fauna/Flora']				= 0;
				$current_bu_acc_count['Water Pollution']			= 0;
					$current_bu_acc_count['Noise/Vibration']	= 0;
				$current_bu_acc_count['Fire']		= 0;
				$current_bu_acc_count['Gas/Fumes']			= 0;
				$current_bu_acc_count['Chemical/Oil Spill'] 		= 0;
			}
			if ( $this->filters['subtype'] == 'S' ) {
				$nhp = $nhp_info['scale'];
				$causes = array();

			$causes['Continuing Downstream'] 			= 'Continuing Downstream';
			$causes['Spreading Downwind'] 		= 'Spreading Downwind';
			$causes['Continuing'] 	= 'Continuing';
			$causes['Reducing'] 	= 'Reducing';
			$causes['Local to Site'] 		= 'Local to Site';
			$causes['Contained on site'] 		= 'Contained on site';

			$main_chart_data = array();

			$current_childbu_acc_count['Continuing Downstream'] 			= 0;
			$current_childbu_acc_count['Spreading Downwind'] 		= 0;
			$current_childbu_acc_count['Continuing'] 	= 0;
			$current_childbu_acc_count['Reducing'] 		= 0;
			$current_childbu_acc_count['Local to Site'] 		= 0;
			$current_childbu_acc_count['Contained on site'] 		= 0;

			$current_bu_acc_count['Continuing Downstream']				= 0;
			$current_bu_acc_count['Spreading Downwind']			= 0;
			$current_bu_acc_count['Continuing']	= 0;
			$current_bu_acc_count['Reducing']		= 0;
			$current_bu_acc_count['Local to Site']			= 0;
			$current_bu_acc_count['Contained on site'] 		= 0;

			}
			//dump_array($current_childbu_acc_count);
			
			$this->buObj->clearStack();
			$this->buObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->buObj->getStack();

			//if ( count($business_units_stack) ) {
	//dump_array($business_units_stack);
				//foreach ( $business_units_stack as $business_units_stack_ele ) {
				
					foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {
						
						if ( $this->filters['subtype'] == 'T' ) {
						$current_bu_acc_count[$causes_ele_k] += (int) $nhp['T'][$causes_ele_v];
					}
					if ( $this->filters['subtype'] == 'S' ) {
						$current_bu_acc_count[$causes_ele_k] += (int) $nhp['S'][$causes_ele_v];
					}
					}
				//}
				//dump_array($current_bu_acc_count);
				foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {

					$main_chart_data[] = array('key'=>ucwords($causes_ele_v),'value'=>$current_bu_acc_count[$causes_ele_k]);
				}
			//}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->buObj->clearStack();
					$this->buObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->buObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->buObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->buObj->getStack();

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {
								$current_childbu_acc_count[$causes_ele_k] += (int) $nhp[$this->filters['year']][$business_units_stack_ele][$causes_ele_v];
							}

						}
					}

					foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {

						$child_arr[$causes_ele_k][] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count[$causes_ele_k]);

					}
				}
			}

			//dump_array($child_arr);

			//
			$graph_heading = $this->filters['bu_name'] == '' ? "NHC Graph" : $this->filters['bu_name']." - ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>$main_chart_data,
						'heading'=>$graph_heading,
						'xaxis_text'=>"Number of NHC Environment",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>"Number of NHC Environment",
						'yaxis_text'=>$yaxis_text,
						)
					);
			//dump_array($this->data_set);
		} // end of causes condition
	}

	private function getnhpCounts($org_data_key,$valuetoadd=0,$nhp_data) {

		if ( count($this->org_data[$org_data_key]) ) {

			foreach( $this->org_data[$org_data_key] as $key=>$value ) {

				if ( $nhp_data[$key] ) {
					$this->childTotal += (int) $nhp_data[$key];
				}
				if ( count($this->org_data[$key]) ) {
					$this->getnhpCounts($key,$valuetoadd,$nhp_data);
					//echo "<br/>";
				}
			}

		}

		return $valuetoadd;
	}

	/* to get result for main graph */
	private function resultSet() {
		return $this->getNoOfNhps();
	}
	
	private function resultSetType() {
		return $this->getNhpType();
	}


	/* to get result for risk impact graph */
	public function resultSetImpact() {

		$data = $this->getGraphDataRisk();
		return $data['risk'];

	}


	/* to get result for causes graph */
	public function resultSetCauses() {
		return $this->getGraphDataCauses();
	}
	
	public function resultSetEnvironment() {
		return $this->getGraphDataEnvironment();
	}


	/* to get result for disposition graph */
	public function resultSetDisposition() {

		$data = $this->getGraphDataRisk();
		return $data['disposition'];

	}

	/* to export data*/
	public function exportGraphData($p_type='') {

		if ( !empty($p_type) ) {

			$method = "resultSet".ucwords($p_type);
			$this->$method();
		} else {
			$this->resultSet();
		}

		return $this->data_set;
	}
}
?>