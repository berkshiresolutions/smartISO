<?php
 /**
  $Id: HorizontalGraph.class.php,v 3.14 Thursday, January 20, 2011 3:27:05 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Horizontal graphs
  * @since  Thursday, September 09, 2010 10:08:22 AM>
  */
    class TrendGraph
    {

        public $graph_parameter;
        private $graph_width;
		private $graph_height;
		private $xml_file_name;
		private $graph_data;
        private $graph_settings;
		private $module_name;
		private $graph_type;

        public function __construct($p_module,$p_graph_data) {

            $this->graph_data = & $p_graph_data;
			$this->module_name = $p_module;
            $this->graph_parameter = array();
			$this->graph_settings = "/includes/js/graphs/amline_settings.xml" ;
			$this->graph_type = "/includes/js/graphs/amline.swf" ;
        }

		public function convertToXml() {

			$next_label_id = 1;

			//dump_array($this->graph_data['chart_data']);

			$deps[] = 'Organization';
			$deps[] = 'Risk Management';
			$deps[] = 'Training';
			$deps[] = 'Inspection';
			$deps[] = 'Non Conformance';
			$deps[] = 'Emergency';
			$deps[] = 'Health';
			$deps[] = 'Design and Purchasing';

			$deps_colors[] = '#72658C';
			$deps_colors[] = '#929292';
			$deps_colors[] = '#46B5DA';
			$deps_colors[] = '#0000FF';
			$deps_colors[] = '#FF0000';
			$deps_colors[] = '#CC00CC';
			$deps_colors[] = '#FBF80D';
			$deps_colors[] = '#0AF9E0';

			//dump_array_and_exit($this->graph_data['chart_data']);


			if ( count($this->graph_data['chart_data']) ) {
                $i = 0;
                foreach ( $this->graph_data['chart_data'] as $val ) {

					$graph_data_main .= "<value xid='".$i."'><![CDATA[".$val['key']."]]></value>";

					$child_elements = $val['values'];


					if ( count($val['values']) ) {
						$m = 0;
						foreach ( $val['values'] as $value ) {

							$var_name = 'graph_data_y'.$m;

							$$var_name .=  "<value xid='".$i."'>".$value."</value>";

							$m++;
						}
					}
                    $i++;

                } // end foreach
            } // end if

            $graph_data = "<?xml version='1.0' encoding='UTF-8'?><chart><series>";
			$graph_data .= $graph_data_main;
			$graph_data .= "</series><graphs>";

			if ( $i != 0 ) {
				for( $j=0;$j<$m;$j++ ) {
					$var =  'graph_data_y'.$j;

					$graph_data .= "<graph color='".$deps_colors[$j]."' title='".$deps[$j]."'>";
					$graph_data .= $$var;
					$graph_data .= "</graph>";
				}
			}
			$graph_data .= "</graphs>";
			$graph_data .= "</chart>";

			     /* write the xml data into xml file */
            $dyn_xml_name = str_replace(' ','_',$this->graph_data['heading']);
            $this->xml_file_url = realpath($_SERVER['DOCUMENT_ROOT']."/private_files/".$this->module_name)."/graph_data_file_".$dyn_xml_name.".xml";
			$this->xml_file_name  = "/private_files/".$this->module_name."/graph_data_file_".$dyn_xml_name.".xml";

            $file_handle = fopen($this->xml_file_url,'w');
            if ($file_handle) {
                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if

			//exit;
		}

        public function getData() {
            $this->graph_parameter['graph_width'] = $this->graph_width;
            $this->graph_parameter['graph_height'] = $this->graph_height;
            $this->graph_parameter['xml_file_name'] = $this->xml_file_name;
            $this->graph_parameter['graph_settings'] = $this->graph_settings;
            $this->graph_parameter['graph_type'] = $this->graph_type;
        }
    }
?>