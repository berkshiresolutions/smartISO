<?php
 /**
  $Id: VerticalGraph.class.php,v 3.01 Friday, December 03, 2010 3:39:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Vertical graph
  * @since  Friday, December 03, 2010 3:39:13 PM>
  */
    class VerticalGraph {

        public $graph_parameter;
        private $graph_width;
        private $graph_height;
        private $xml_file_name;
        private $graph_data;
        private $graph_settings;
		private $graph_type;

        public function __construct($p_module,$p_graph_data) {

            $this->graph_data = $p_graph_data;
            $this->horizontalgraph = array();
			$this->graph_settings = "/includes/js/graphs/chart_settings_vertical.xml" ;
			$this->graph_type = "/includes/js/graphs/amcolumn.swf" ;
        }

		public function convertToXml() {

			$next_label_id = 1;

			if ( count($this->graph_data['chart_data']) ) {
                $i = 0;
                foreach ( $this->graph_data['chart_data'] as $val ) {
                    $graph_data_y .=  "<value xid='".$i."'>".$val['key']."</value>";
					$graph_data_x .=  "<value xid='".$i."'>".$val['value']."</value>";
                    $this->graph_width = $this->graph_width + 45;                 // for graph width
					$this->graph_height = $this->graph_height + 15;
                    $i++;
                } // end foreach
            } // end if

			/* increase height of graph for labels */
            if( count($this->graph_data['labels']) ) {
                foreach ( $this->graph_data['labels'] as $label_val ) {
                    $this->graph_height = $this->graph_height + 30;
                    $graph_data_y .=  "<value xid='".$i."'> </value>";
                    $i++;
                } // end foreach
            } // end if

			$graph_data = "<?xml version='1.0' encoding='UTF-8'?><chart><series>";
			$graph_data .= $graph_data_y;
			$graph_data .= "</series><graphs><graph gid='1'>";
			$graph_data .= $graph_data_x;
			$graph_data .= "</graph></graphs>";

			#################### labels code ########################
            $graph_data .=  "<labels>";

            $this->graph_height = $this->graph_height <= 400? 400 : $this->graph_height;
            $this->graph_width = $this->graph_width <= 400? 400 : $this->graph_width;

            if ( $this->graph_data['heading'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>25</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['heading']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['xaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>".($this->graph_height-25)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['xaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['yaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>5</x>";
				$graph_data .=  "<rotate>true</rotate>";
                $graph_data .=  "<y>".($this->graph_height)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['yaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if( count($this->graph_data['labels']) ) {
                $i = $next_label_id;
                $x_pos = $this->graph_width/2;
                $y_pos = 55;
                foreach ( $this->graph_data['labels'] as $label_val ) {

                    $graph_data .=  "<label lid='".$i."'>";
                    $graph_data .=  "<x>".$x_pos."</x>";
                    $graph_data .=  "<y>".$y_pos."</y>";
                    $graph_data .=  "<align></align>";
                    $graph_data .=  "<text><![CDATA[".$label_val."]]></text>";
                    $graph_data .=  "</label>";

                    $y_pos = $y_pos + 20;
                    $i++;
                } // end foreach
            } //end if

            ##################################################################

			$graph_data .= "</labels></chart>";

			     /* write the xml data into xml file */
            $this->xml_file_name = "graph_data_file.xml";

            $file_handle = fopen($this->xml_file_name,'w');
            if ($file_handle) {

                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if
		}
/*
        public function convertToXml() {

            $this->graph_width = 35;
            $this->graph_height = 35;

            $graph_data = "<?xml version='1.0' encoding='UTF-8'?><chart><series>";

            if ( count($this->graph_data['x_axis']) ) {
                $i = 0;
                foreach ( $this->graph_data['x_axis'] as $val ) {
                    $graph_data .=  "<value xid='".$i."'>".$val."</value>";
                    $this->graph_height = $this->graph_height + 35;
                    $i++;
                } // end foreach
            } // end if


            $graph_data .=  "</series><graphs><graph gid='1'>";
            $graph_data .=  "<value color='#46B5DA' xid='0'>6</value>";

            if ( count($this->graph_data['y_axis']) ) {
                $i = 1;
                foreach ( $this->graph_data['y_axis'] as $val ) {
                    $graph_data .=  "<value xid='".$i."'>".$val."</value>";
                    $this->graph_width = $this->graph_width + 15;
                    $i++;
                } // end foreach
            } // end if

            $graph_data .=  "</graph></graphs><labels>";

            if ( $this->graph_data['heading'] ) {

                $graph_data .=  "<label lid='1'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>25</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['heading']."</b>]]></text>";
                $graph_data .=  "</label>";
                $i++;
            }

            $graph_data .=  "</labels></chart>";

            $this->graph_width = $this->graph_width <= 600? 600 : $this->graph_width;
            $this->graph_height = $this->graph_height <= 200? 200 : $this->graph_height;

            $this->xml_file_name = "graph_data_file.xml";

            $file_handle = fopen($this->xml_file_name,'w');
            if ($file_handle) {

                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if
        }*/

        public function getData() {
            $this->graph_parameter['graph_width'] = $this->graph_width;
            $this->graph_parameter['graph_height'] = $this->graph_height;
            $this->graph_parameter['xml_file_name'] = $this->xml_file_name;
            $this->graph_parameter['graph_settings'] = $this->graph_settings;
            $this->graph_parameter['graph_type'] = $this->graph_type;
        }
    }
?>