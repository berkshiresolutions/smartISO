<?php
 /**
  $Id: HorizontalGraph.class.php,v 3.14 Thursday, January 20, 2011 3:27:05 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Horizontal graphs
  * @since  Thursday, September 09, 2010 10:08:22 AM>
  */
class Pie3dGraph
{
	private $graph_width;
	private $graph_height;
	private $xml_file_name;
	private $graph_data;
	private $graph_settings;
	private $module_name;
	private $graph_swf_file;
	private $graph_subtype;
	private $graph_module_type;

	public function __construct($p_module,$p_graph_data,$p_subtype='',$p_graph_module_type='') {

		$this->graph_data = & $p_graph_data;
		//dump_array($this->graph_data);
		$this->module_name = $p_module;
		$this->graph_settings = "/includes/js/graphs/chart_settings.xml" ;
		//$this->graph_type = "/includes/js/graphs/fusion_charts/Bar2D.swf" ;

		switch ($p_subtype) {
			case 'stacked': $this->graph_swf_file = "/includes/js/graphs/fusion_charts/StackedBar3D.swf"; break;
			case 'group': $this->graph_swf_file = "/includes/js/graphs/fusion_charts/MSBar3D.swf"; break;
			default : $this->graph_swf_file = "/includes/js/graphs/fusion_charts/Pie3D.swf";
		}

		$this->graph_subtype = $p_subtype;
		 $this->graph_module_type = $p_graph_module_type;
	}

	public function convertToXml() {

		$additional_height = $this->graph_data['additional_height'] == '' ? 0 : (int) $this->graph_data['additional_height'];

		$next_label_id = 1;

		//dump_array($this->graph_data['chart_data']);

		if ( count($this->graph_data['chart_data']) ) {

			switch ($this->graph_subtype) {

				case 'group':

						if ( $this->graph_module_type == 'participantS' ) {

							$total_elements = count($this->graph_data['chart_data']['yes']);

							for ( $i=0;$i<$total_elements;$i++ ) {

								$val_yes = $this->graph_data['chart_data']['yes'][$i];
								$val_no = $this->graph_data['chart_data']['no'][$i];

								$graph_data_values .= "<dataset seriesName='".$val_yes['key']."' showValues='0'>\n";
								$graph_data_values .= "<set label='".$val_yes['key']."' value='".$val_yes['value']."' ".$url."/>\n";
								$graph_data_values .= "<set label='".$val_no['key']."' value='".$val_no['value']."' ".$url."/>\n";
								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 80;
							}

						} // end participant Shift block

						else if ( $this->graph_module_type == 'participantG' ) {

							$total_elements = count($this->graph_data['chart_data']['male']);

							for ( $i=0;$i<$total_elements;$i++ ) {

								$val_male = $this->graph_data['chart_data']['male'][$i];
								$val_female = $this->graph_data['chart_data']['female'][$i];

								$graph_data_values .= "<dataset seriesName='".$val_male['key']."' showValues='0'>\n";
								$graph_data_values .= "<set label='".$val_male['key']."' value='".$val_male['value']."' ".$url."/>\n";
								$graph_data_values .= "<set label='".$val_female['key']."' value='".$val_female['value']."' ".$url."/>\n";
								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 80;
							}

						} // end participant Gender block

						else if ( $this->graph_module_type == 'activityB' ) {

							$total_elements = count($this->graph_data['chart_data']['upper body']);

							for ( $i=0;$i<$total_elements;$i++ ) {

								$val_upper 	= $this->graph_data['chart_data']['upper body'][$i];
								$val_middle = $this->graph_data['chart_data']['middle body'][$i];
								$val_lower 	= $this->graph_data['chart_data']['lower body'][$i];

								$graph_data_values .= "<dataset seriesName='".$val_upper['key']."' showValues='0'>\n";
								$graph_data_values .= "<set label='".$val_upper['key']."' value='".$val_upper['value']."' ".$url."/>\n";
								$graph_data_values .= "<set label='".$val_middle['key']."' value='".$val_middle['value']."' ".$url."/>\n";
								$graph_data_values .= "<set label='".$val_lower['key']."' value='".$val_lower['value']."' ".$url."/>\n";
								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 30 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 30;
							}

						} // end activity Part of Body block

						else if ( $this->graph_module_type == 'activityI'
								 || $this->graph_module_type == 'activityT'
								 || $this->graph_module_type == 'activityA'
								 || $this->graph_module_type == 'activityM'
								 || $this->graph_module_type == 'activityH' ) {

							//dump_array($this->graph_data['chart_data']);
							foreach ( $this->graph_data['chart_data'] as $key=>$value ) {
								$main_elements[] = $key;
							}

							$total_elements = count($this->graph_data['chart_data'][$main_elements[0]]);

							for ( $i=0;$i<$total_elements;$i++ ) {

								$graph_data_values .= "<dataset seriesName='".$this->graph_data['chart_data'][$main_elements[0]][$i]['key']."' showValues='0'>\n";

								foreach ( $main_elements as $m_ele ) {

									$val_dynamic 	= $this->graph_data['chart_data'][$m_ele][$i];
									$graph_data_values .= "<set label='".$val_dynamic['key']."' value='".$val_dynamic['value']."' ".$url."/>\n";
								}

								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 30 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 30;
							}

						} // end activity Nature of Injury block
						else if ( $this->graph_module_type == 'risk_impact' ) {

							$total_elements = count($this->graph_data['chart_data'][1]);

							$impact = SetupGeneric::useModule('ImpactMeasure');
							$impact_measures_data_records = $impact->displayItems();
							$impact = null;

							$impact_measures = array();

							if ($impact_measures_data_records) {
								foreach ( $impact_measures_data_records as $impact_measures_data_record_ele ) {

									$name_arr 								= explode("|",$impact_measures_data_record_ele['name']);
									$impact_id 								= $impact_measures_data_record_ele['ID'];
									$impact_measures[$impact_id] 			= trim($name_arr[0]," ");
								}
							}


							for ( $i=0;$i<$total_elements;$i++ ) {

								$k = 0;
								foreach ( $impact_measures as $impact_measure_ele_k=>$impact_measure_ele_v ) {

									if (!$k) {
										$graph_data_values .= "<dataset seriesName='".$this->graph_data['chart_data'][$impact_measure_ele_k][$i]['key']."' showValues='0'>\n";
									}
									$k++;

									if ( $impact_measure_ele_v == '=>3 Days' ) {
										$label = 'Greater than Equal to 3 Days';
									} else if ( $impact_measure_ele_v == '< 3 Days' ) {
										$label = 'Less than 3 Days';
									} else {
										$label = $impact_measure_ele_v;
									}

									$graph_data_values .= "<set value='".$this->graph_data['chart_data'][$impact_measure_ele_k][$i]['value']."' ".$url."/>\n";

									$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
									$this->graph_width = $this->graph_width + 80;

								}

								$graph_data_values .= "</dataset>\n";

							}

						} // end risk impact block

						else if ( $this->graph_module_type == 'disposition' ) {

							$total_elements = count($this->graph_data['chart_data'][1]);

							$nhpObj  = SetupGeneric::useModule('NhpOption');
							$disposition_data_records = $nhpObj->displayItems();
							$nhpObj = null;

							$dispositions = array();

							if ($disposition_data_records) {
								foreach ( $disposition_data_records as $disposition_data_record_ele ) {

									if ( $disposition_data_record_ele['envSubType'] == 'D' ) {

										$disposition_id 						= $disposition_data_record_ele['ID'];
										$dispositions[$disposition_id] 			= trim($disposition_data_record_ele['optionLabel']," ");
									}
								}
							}

							for ( $i=0;$i<$total_elements;$i++ ) {

								$k = 0;
								foreach ( $dispositions as $dispositions_ele_k=>$dispositions_ele_v ) {

									if (!$k) {
										$graph_data_values .= "<dataset seriesName='".$this->graph_data['chart_data'][$dispositions_ele_k][$i]['key']."' showValues='0'>\n";
									} $k++;

									$graph_data_values .= "<set value='".$this->graph_data['chart_data'][$dispositions_ele_k][$i]['value']."' ".$url."/>\n";

									$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
									$this->graph_width = $this->graph_width + 80;

								}

								$graph_data_values .= "</dataset>\n";

							}

						} // end disposition block

						else if ( $this->graph_module_type == 'causes' ) {

							$total_elements = count($this->graph_data['chart_data']['unsafe_act']);

							$causes = array();

							$causes['unsafe_act'] 			= 'unsafe_act';
							$causes['unsafe_design'] 		= 'unsafe_design';
							$causes['faulty_construction'] 	= 'faulty_construction';
							$causes['unsafe_condition'] 	= 'unsafe_condition';
							$causes['unsafe_method'] 		= 'unsafe_method';

							for ( $i=0;$i<$total_elements;$i++ ) {

								$k = 0;
								foreach ( $causes as $causes_ele_k=>$causes_ele_v ) {

									if (!$k) {
										$graph_data_values .= "<dataset seriesName='".$this->graph_data['chart_data'][$causes_ele_k][$i]['key']."' showValues='0'>\n";
									} $k++;

									$graph_data_values .= "<set value='".$this->graph_data['chart_data'][$causes_ele_k][$i]['value']."' ".$url."/>\n";

									$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
									$this->graph_width = $this->graph_width + 80;

								}

								$graph_data_values .= "</dataset>\n";

							}

						} // end causes block


					else {
						
						//echo "sdfdsfad";
                        // dump_array($this->graph_data);
							$total_elements = count($this->graph_data['chart_data']['Contract Manager']);
							$total = count($this->graph_data['chart_data']['Questions']);
							$tot = count($this->graph_data['chart_data']['name']);
                         // echo $total_elements;
						  
						  if($total){
						//  echo "ghjhgjg";
						  for ( $i=0;$i<$total;$i++ ) {

								$val1 = $this->graph_data['chart_data']['Questions'][$i];
		
								

								//dump_array($val1);

								$graph_data_values .= "<dataset showValues='1' seriesName='".$val1['key']."' showValues='0'>\n";
							
							   $graph_data_values .= "<set  legendBgColor ='FFCC00' label='".$val1['key']."' value='".$val1['value']."' ".$url."/>\n";
							   
					
								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 80;
							}
						  }else if($tot){
						  
						    for ( $i=0;$i<$tot;$i++ ) {

								$val1 = $this->graph_data['chart_data']['name'][$i];
		
								

								//dump_array($val1);

								$graph_data_values .= "<dataset showValues='1' seriesName='".$val1['key']."' showValues='0'>\n";
							
							   $graph_data_values .= "<set  legendBgColor ='FFCC00' label='".$val1['key']."' value='".$val1['value']."' ".$url."/>\n";
							   
					
								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 80;
							}
						  
						  }else{
						  
						  
						  for ( $i=0;$i<$total_elements;$i++ ) {

								$val_male = $this->graph_data['chart_data']['Contract Manager'][$i];
								$val_female =$this->graph_data['chart_data']['Manager Approver'][$i];
								$val = $this->graph_data['chart_data']['Director Approver'][$i];
								
								$val1 = $this->graph_data['chart_data']['Director Approver'][$i];
								//dump_array($val_male);

								$graph_data_values .= "<dataset showValues='1' seriesName='".$val_male['key']."' showValues='0'>\n";
								if($val_male['key'] == 'Not Started'){
							   $graph_data_values .= "<set  color ='FFCC00' legendBgColor ='FFCC00' label='".$val_male['key']."' value='".$val_male['value']."' ".$url."/>\n";
							     }
								 if($val_male['key'] == 'Completed'){
							   $graph_data_values .= "<set color ='66CC33' label='".$val_male['key']."' value='".$val_male['value']."' ".$url."/>\n";
							     }
								  if($val_male['key'] == 'Overdue'){
							   $graph_data_values .= "<set color ='FF0000' label='".$val_male['key']."' value='".$val_male['value']."' ".$url."/>\n";
							     }
								 if($val_female['key'] == 'Not Started'){
							   $graph_data_values .= "<set color ='FF9600' label='".$val_female['key']."' value='".$val_female['value']."' ".$url."/>\n";
							     }
								 if($val_female['key'] == 'Completed'){
							   $graph_data_values .= "<set color ='339900' label='".$val_female['key']."' value='".$val_female['value']."' ".$url."/>\n";
							     }
								  if($val_female['key'] == 'Overdue'){
							   $graph_data_values .= "<set color ='CC0000' label='".$val_female['key']."' value='".$val_female['value']."' ".$url."/>\n";
							     }
								  if($val['key'] == 'Not Started'){
							   $graph_data_values .= "<set color ='FF6600' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							     }
								 if($val['key'] == 'Completed'){
							   $graph_data_values .= "<set color ='336600' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							     }
								  if($val['key'] == 'Overdue'){
							   $graph_data_values .= "<set color ='990000' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							     }
								$graph_data_values .= "</dataset>\n";

								$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
								$this->graph_width = $this->graph_width + 80;
							}
						  
						  
						  
						  }
							

						} // end participant Gender block// end causes block


					break;

				default:
					//echo "dsfsdf";
						////foreach ( $this->graph_data['chart_data'] as $val ) {
						//dump_array($this->graph_data['chart_data']);
					$total_elements = count($this->graph_data['chart_data']);
						if($total_elements > '1'){
						$this->graph_swf_file = "/includes/js/graphs/fusion_charts/Pie3D.swf";
						}

						foreach ($this->graph_data['chart_data'] as $val ) {
							//$val = $this->graph_data['chart_data'];
							
							//echo $count = count($val);
							//dump_array($val);

							$url = "";
							if ( $val['link'] != '' ) {
								$url = " link='".urlencode($val['link'])."'";
							}

							//$graph_data_y .=  "<value xid='".$i."'><![CDATA[".$val['key']."]]></value>";
							//$graph_data_x .=  "<value xid='".$i."' ".$url."><![CDATA[".$val['value']."]]></value>";
							////$graph_data_values .= "<dataset showValues='1' seriesName='".$val['key']."' >\n";
							if($val['key'] == 'Not Started'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'  showLegend = '0'>\n";
							$graph_data_values .= "<set color='FFCC00' showLegend = '0' thickness ='10'  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							}else if($val['key'] == 'Contract Manager Completed Reviews'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'  showLegend = '0'>\n";
							$graph_data_values .= "<set color='66CC33' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Manager Approver Completed Reviews'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'  showLegend = '0'>\n";
							$graph_data_values .= "<set color='339900' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Director Approver Completed Reviews'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'  showLegend = '0'>\n";
							$graph_data_values .= "<set color='336600' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Overdue'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set color='990000' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Less than 2.5'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set color='990000' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == '2.5 - 3.5'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set color='FFCC00' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == '> 3.5'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set color='66CC33' label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Long Term'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Greater Than Equal To 3 Days'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['key'] == 'Less Than 3 Days'){
							//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
							$graph_data_values .= "<set  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
							//$graph_data_values .= "</dataset>\n";
							
							}else if($val['0']['key']){
                                                            foreach($val as $data){
                                                             // $graph_data_values .= "<dataset seriesName='".$data['key']."' showValues='0'>\n";
							$graph_data_values .= "<set  label='".$data['key']."' value='".$data['value']."' ".$url."/>\n";
								//$graph_data_values .= "</dataset>\n";
                                                            }
                                                            /*
									if($val['0']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['0']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['0']['key']."' value='".$val['0']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
									if($val['1']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['1']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['1']['key']."' value='".$val['1']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['2']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['2']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['2']['key']."' value='".$val['2']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['3']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['3']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['3']['key']."' value='".$val['3']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['4']['key']){
									//	$graph_data_values .= "<dataset seriesName='".$val['4']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['4']['key']."' value='".$val['4']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['5']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['5']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['5']['key']."' value='".$val['5']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['6']['key']){
									//	$graph_data_values .= "<dataset seriesName='".$val['6']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['6']['key']."' value='".$val['6']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['7']['key']){
									//	$graph_data_values .= "<dataset seriesName='".$val['7']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['7']['key']."' value='".$val['7']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['8']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['8']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['8']['key']."' value='".$val['8']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['9']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['9']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['9']['key']."' value='".$val['9']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['10']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['10']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['10']['key']."' value='".$val['10']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['11']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['10']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['10']['key']."' value='".$val['10']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['12']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['10']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['10']['key']."' value='".$val['10']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
									if($val['13']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['10']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['10']['key']."' value='".$val['10']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['14']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['10']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['10']['key']."' value='".$val['10']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
								if($val['15']['key']){
										//$graph_data_values .= "<dataset seriesName='".$val['10']['key']."' showValues='0'>\n";
								$graph_data_values .= "<set  label='".$val['10']['key']."' value='".$val['10']['value']."' ".$url."/>\n";


								//$graph_data_values .= "</dataset>\n";

									}
*/



								}else if($val['key'] && $total_elements > '1'){
									//echo "dsfsdf";

									//$graph_data_values .= "<dataset seriesName='".$val['key']."' showValues='0'>\n";
									$graph_data_values .= "<set  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
									//$graph_data_values .= "</dataset>\n";

								}else{
								
								//echo "dfgdfg";

									//$graph_data_values .= "<dataset seriesName='".$val['key']."'>\n";
									$graph_data_values .= "<set  label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";
									//$graph_data_values .= "</dataset>\n";

								}
							////$graph_data_values .= "</dataset>\n";


							//$graph_data_values .= "<set label='".$val['key']."' value='".$val['value']."' ".$url."/>\n";


							$this->graph_height = $this->graph_height + 50 + $additional_height;                 // for graph height
							$this->graph_width = $this->graph_width + 80;
							$i++;

						} // end foreach
			} // end switch

		} // end if

		/* increase height of graph for labels */
		if( count($this->graph_data['labels']) ) {
			foreach ( $this->graph_data['labels'] as $label_val ) {
				$this->graph_height = $this->graph_height + 50;
				$graph_data_y .=  "<value xid='".$i."'> </value>";
				$i++;
			} // end foreach
		} // end if


//exportFormats='PDF=Export as PDF|PNG=Export as PNG'
		// LCowles Added Chart Server-Side Export
		$graph_data =  "<chart exportAction='download' exportFileName='".$this->graph_data['heading']."' exportEnabled='1' exportAtClient='0' exportHandler='/includes/chartExport/FCExporter.php' showLegend = '1' chartRightMargin='15' showValues='0'  yAxisMinValue='0' yAxisMaxValue='10' adjustDiv='' numDivLines='10' caption='".$this->graph_data['heading']."' chartleftmargin='15' ";

		switch ($this->graph_subtype) {

			case 'group':

				$graph_data .= "yAxisName='".$this->graph_data['xaxis_text']."' ";
				$graph_data .= "xAxisName='".$this->graph_data['yaxis_text']."' bgColor='F1F1F1' ";
				$graph_data .= "canvasBorderThickness='1' canvasBorderColor='999999' ";
				if ($this->module_name=='contract')
				$graph_data .= "paletteColors='FFCC00,339900,CC0000' ";
				$graph_data .= "plotFillAngle='330' plotBorderColor='999999' showAlternateVGridColor='1' divLineAlpha='0'>";
				$graph_data .= "<categories>";

				if ($this->graph_data['chart_data']) {
					foreach ( $this->graph_data['chart_data'] as $cat_name=>$cat_data) {

						if ( $this->graph_module_type == 'risk_impact' ) {

							if ( trim($impact_measures[$cat_name]," ") == '=>3 Days' ) {
								$label = 'Greater than Equal to 3 Days';
							} else if ( trim($impact_measures[$cat_name]," ") == '< 3 Days' ) {
								$label = 'Less than 3 Days';
							} else {
								$label = $impact_measures[$cat_name];
							}

							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'disposition' ) {

							$label = $dispositions[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'causes' ) {

							$label = $causes[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else {
							$graph_data .= "<category label='".ucfirst($cat_name)."'/>";
						}
					}
				}

				$graph_data .= "</categories>";
				$graph_data .= $graph_data_values;
				break;

			default:
				$graph_data .= "yAxisName='".$this->graph_data['xaxis_text']."' ";
				$graph_data .= "xAxisName='".$this->graph_data['yaxis_text']."' bgColor='F1F1F1' ";
				$graph_data .= "canvasBorderThickness='1' canvasBorderColor='999999' ";

				if ($this->graph_module_type=='graph')
				$graph_data .= "paletteColors='FFCC00,66CC33,339900,336600,CC0000' ";
				
				if ($this->graph_module_type=='contract')
				$graph_data .= "paletteColors='FFCC00,336600,CC0000' ";

				$graph_data .= "plotFillAngle='330' plotBorderColor='999999' showAlternateVGridColor='1' divLineAlpha='0'>";
				////$graph_data .= "<categories><category label=''/></categories>";
				$graph_data .= "<categories>";

				if ($this->graph_data['chart_data']) {
					foreach ( $this->graph_data['chart_data'] as $cat_name=>$cat_data) {

						if ( $this->graph_module_type == 'risk_impact' ) {

							if ( trim($impact_measures[$cat_name]," ") == '=>3 Days' ) {
								$label = 'Greater than Equal to 3 Days';
							} else if ( trim($impact_measures[$cat_name]," ") == '< 3 Days' ) {
								$label = 'Less than 3 Days';
							} else {
								$label = $impact_measures[$cat_name];
							}

							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'disposition' ) {

							$label = $dispositions[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else if ( $this->graph_module_type == 'causes' ) {

							$label = $causes[$cat_name];
							$graph_data .= "<category label='".ucfirst($label)."'/>";
						} else {
							$graph_data .= "<category label='".ucfirst($cat_name)."'/>";
						}
					}
				}

				$graph_data .= "</categories>";
				$graph_data .= $graph_data_values;
				//$graph_data .= "</series><graphs><graph gid='1'>";
				//$graph_data .= $graph_data_x;
		}

		$graph_data .= "</chart>";

			 /* write the xml data into xml file */
		$dyn_xml_name = str_replace(' ','_',$this->graph_data['heading']);
		$this->xml_file_url = realpath($_SERVER['DOCUMENT_ROOT']."/private_files/".$this->module_name)."/graph_data_file_".$dyn_xml_name.".xml";
		$this->xml_file_name  = "/private_files/".$this->module_name."/graph_data_file_".$dyn_xml_name.".xml";

		$file_handle = fopen($this->xml_file_url,'w');

		if ( $file_handle) {

			fwrite($file_handle,$graph_data,strlen($graph_data));
			fclose($file_handle);
		} // end if
	}

	public function getData() {

		if ( $this->graph_width > 740 ) {
			$graph_parameter['graph_width'] = $this->graph_width;
		} else {
			$graph_parameter['graph_width'] = 740;
		}

		if ( $this->graph_width > 400 ) {
			$graph_parameter['graph_height'] = $this->graph_height;
		} else {
			$graph_parameter['graph_height'] = 400;
		}
		//echo $this->graph_swf_file;
		$graph_parameter['xml_file_name'] = $this->xml_file_name;
		$graph_parameter['graph_settings'] = $this->graph_settings;
		$graph_parameter['graph_swf_file'] = $this->graph_swf_file;
		$graph_parameter['secondary_graph_swf_file'] = $this->secondary_graph_swf_file;

		return $graph_parameter;
	}
}
?>