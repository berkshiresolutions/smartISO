<?php
 /**
  $Id: AuditGraph.class.php,v 3.13 Monday, January 31, 2011 10:07:23 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Horizontal graphs
  * @since  Thursday, September 09, 2010 10:08:22 AM>
  */
    class AuditGraph
    {

        public $graph_parameter;
        private $graph_width;
		private $graph_height;
		private $xml_file_name;
		private $graph_data;
        private $graph_settings;

        public function __construct($p_module,$p_graph_data) {

            $this->graph_data = & $p_graph_data;
            $this->graph_parameter = array();
			$this->graph_settings = "/includes/js/graphs/audit_chart_settings.xml" ;
        }

		public function convertToXml() {

			$next_label_id = 1;

			$chart_data_arr = $this->graph_data['chart_data'];

			//dump_array($chart_data_arr);

			$data_count = count($chart_data_arr)-1;

			if ( count($chart_data_arr) ) {

				$i=0;
				for ( $ic=$data_count; $ic>=0; $ic-- ) {

					$color = "";
					if ( $chart_data_arr[$ic]['key'] == 'Key Questions' ) {

						/*if ( $chart_data_arr[$ic]['value'] < 20 ) {
							$color = " color='#000000' ";
						} else if ( $chart_data_arr[$ic]['value'] > 20 && $chart_data_arr[$ic]['value'] < 42.5 ) {
							$color = " color='#A67D3D' ";
						} else if ( $chart_data_arr[$ic]['value'] > 42.5 &&  $chart_data_arr[$ic]['value'] < 65 ) {
							$color = " color='#C0C0C0' ";
						} else {
							$color = " color='#D4A017' ";
						}*/

						$color = " color='#C0C0C0' ";

					}

					$graph_data_y .=  "<value xid='".$i."'>".$chart_data_arr[$ic]['key']."</value>";
					$graph_data_x .=  "<value xid='".$i."' ".$color.">".$chart_data_arr[$ic]['value']."</value>";
                    $this->graph_height = $this->graph_height + 65;                 // for graph height
					$this->graph_width = $this->graph_width + 25;

					$i++;
				}
			}

			/*if ( count($this->graph_data['chart_data']) ) {
                $i = 0;
                foreach ( $this->graph_data['chart_data'] as $val ) {
                    $graph_data_y .=  "<value xid='".$i."'>".$val['key']."</value>";
					$graph_data_x .=  "<value xid='".$i."' color='#ccc'>".$val['value']."</value>";
                    $this->graph_height = $this->graph_height + 65;                 // for graph height
					$this->graph_width = $this->graph_width + 25;
                    $i++;
                } // end foreach
            } // end if*/

			/* increase height of graph for labels */
            if( count($this->graph_data['labels']) ) {
                foreach ( $this->graph_data['labels'] as $label_val ) {
                    $this->graph_height = $this->graph_height + 40;
                    $graph_data_y .=  "<value xid='".$i."'>".$label_val."</value>";
                    $i++;
                } // end foreach
            } // end if

            $graph_data = "<?xml version='1.0' encoding='UTF-8'?><chart><series>";
			$graph_data .= $graph_data_y;
			$graph_data .= "</series><graphs><graph gid='1'>";
			$graph_data .= $graph_data_x;
			$graph_data .= "</graph></graphs>";



			 #################### labels code ########################
            $graph_data .=  "<labels>";

            $this->graph_width = $this->graph_width <= 600? 600 : $this->graph_width;
            $this->graph_height = $this->graph_height <= 250? 250 : $this->graph_height;

			$this->graph_height = 380;

            if ( $this->graph_data['heading'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>25</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['heading']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['xaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>".($this->graph_height)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['xaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['yaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>5</x>";
				$graph_data .=  "<rotate>true</rotate>";
                $graph_data .=  "<y>".($this->graph_height)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['yaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if( count($this->graph_data['labels']) ) {
                $i = $next_label_id;
                $x_pos = $this->graph_width/2;
                $y_pos = 55;
                foreach ( $this->graph_data['labels'] as $label_val ) {

                    $graph_data .=  "<label lid='".$i."'>";
                    $graph_data .=  "<x>".$x_pos."</x>";
                    $graph_data .=  "<y>".$y_pos."</y>";
                    $graph_data .=  "<align></align>";
                    $graph_data .=  "<text><![CDATA[".$label_val."]]></text>";
                    $graph_data .=  "</label>";

                    $y_pos = $y_pos + 20;
                    $i++;
                } // end foreach
            } //end if

            ##################################################################

			$graph_data .= "</labels></chart>";

			     /* write the xml data into xml file */
            $this->xml_file_name = "graph_data_file.xml";

            $file_handle = fopen($this->xml_file_name,'w');
            if ($file_handle) {

                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if
		}

        public function getData() {
            $this->graph_parameter['graph_width'] = $this->graph_width;
            $this->graph_parameter['graph_height'] = $this->graph_height;
            $this->graph_parameter['xml_file_name'] = $this->xml_file_name;
            $this->graph_parameter['graph_settings'] = $this->graph_settings;
        }
    }
?>