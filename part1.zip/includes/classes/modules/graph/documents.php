<?php
 /**
  $Id: incidence.php,v 3.46 Wednesday, February 02, 2011 2:50:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used for incidence graphs
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence graph data
  * @since  Tuesday, September 28, 2010 6:13:45 PM>
  */

require_once "GraphModuleData.int.php";
require_once "GraphData.abs.php";

class DocumentsGraph implements GraphModuleData  {

	private $data_set;
	private $filter_query;
	private $filters;
	private $organigramObj;
	private $contribObj;
	private $child_business_units;

	public function __construct() {

		$this->data_format = new GraphData();
		$this->organigramObj = SetupGeneric::useModule('Organigram');
		$this->contribObj = new DocumentContributor();
	}

	public function setFilter($p_filter_fields) {

		$this->filters = $p_filter_fields;
		//dump_array($this->filters);
	}

	private function getRateFromValue($p_val,$p_decimal_place=2) {

		return number_format(($p_val*1000)/$this->participant_count,$p_decimal_place);
	}
	public function processData_all($p_type='main') {




			$accident_info1 = $this->getMainGraphData1();



			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
				}

				if ( $this->filters['data_stat_type'] == 'rate' ) {
					$current_bu_acc_count = $this->getRateFromValue($current_bu_acc_count);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {
						//dump_array($business_units_stack_ele);
					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					if ( $this->filters['data_stat_type'] == 'rate' ) {
						$current_childbu_acc_count = $this->getRateFromValue($current_childbu_acc_count);
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			$child_arr[''] = $accident_info;
			if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->contribObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['contribDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->contribObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = $accident_info;
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   // function removeElementWithValue($child_arr, $key, $value){
		   if($child_arr){
			
				foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
             
			//}

				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Total ".ucfirst($this->filters['data_stat_type'])." of accidents Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

				$this->data_set['chart_data'][] = $child_arr;
			$this->data_set['heading'] = $this->filters['heading'];
			$this->data_set['xaxis_text'] = "Sections";
			$this->data_set['yaxis_text'] = "Questions";
			

					
			
			}else{
				
					//
			$graph_heading = "Contributors_all";
			

		

			$this->data_set['chart_data'][] = $accident_info1;
			$this->data_set['heading'] = 'Contributors All';
			$this->data_set['xaxis_text'] = "Percentage(%)";
			$this->data_set['yaxis_text'] = "Contributors Names";
				
			}

		
	}

	public function processData($p_type='main') {




			$accident_info = $this->getMainGraphData();



			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
				}

				if ( $this->filters['data_stat_type'] == 'rate' ) {
					$current_bu_acc_count = $this->getRateFromValue($current_bu_acc_count);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {
						//dump_array($business_units_stack_ele);
					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					if ( $this->filters['data_stat_type'] == 'rate' ) {
						$current_childbu_acc_count = $this->getRateFromValue($current_childbu_acc_count);
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			$child_arr[''] = $accident_info;
			if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->contribObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['contribDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->contribObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = $accident_info;
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   // function removeElementWithValue($child_arr, $key, $value){
		   if($child_arr){
			
				foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
             
			//}

				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Total ".ucfirst($this->filters['data_stat_type'])." of accidents Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

				$this->data_set['chart_data'][] = $child_arr;
			$this->data_set['heading'] = $this->filters['heading'];
			$this->data_set['xaxis_text'] = "Sections";
			$this->data_set['yaxis_text'] = "Questions";
			

					
			
			}else{
				
					//
			$graph_heading = "Contributor";
			



			$this->data_set['chart_data'][] = $accident_info;
			$this->data_set['heading'] = 'Contributor';
			$this->data_set['xaxis_text'] = "Percentage(%)";
			$this->data_set['yaxis_text'] = "Contributors Names";
				
			}

		
	}

	private function getMainGraphData() {

		return $this->contribObj->getContributor();
	}
		private function getMainGraphData1() {

		return $this->contribObj->getContributorall();
	}

	private function getViolenceGraphData() {

		return $this->contribObj->getNoOfViolencecontrib();
	}

	private function getParticipantGraphData() {

		return $this->contribObj->getNoOfParticipants();
	}

	private function getActivityGraphData() {

		return $this->contribObj->getNoOfActivities();
	}

	private function getActionGraphData() {

		return $this->contribObj->getNoOfActions();
	}

	private function getAccidentTestGraphData() {

		$this->contribObj->getInstructorGraphData();
	}

	private function getAccidentPublicGraphData() {

		return $this->contribObj->getAccidentPublicGraphData();
	}
	private function resultSet() {

		return $this->contribObj->getAccidetTest();
	}
	
	private function resultSetBU() {

		return $this->contribObj->getAccidetBuTest();
	}

	
	private function resultSelectBU() {

		return $this->contribObj->getSelectedBu();
	}

	public function exportGraphData() {

		return $this->data_set;
	}
}
?>