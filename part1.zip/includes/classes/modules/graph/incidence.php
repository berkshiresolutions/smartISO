<?php
 /**
  $Id: incidence.php,v 3.46 Wednesday, February 02, 2011 2:50:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used for incidence graphs
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence graph data
  * @since  Tuesday, September 28, 2010 6:13:45 PM>
  */

require_once "GraphModuleData.int.php";
require_once "GraphData.abs.php";

class IncidenceGraph implements GraphModuleData  {

	private $data_set;
	private $filter_query;
	private $filters;
	private $organigramObj;
	private $incidenceObj;
	private $child_business_units;

	public function __construct() {

		$this->data_format = new GraphData();
		$this->organigramObj = SetupGeneric::useModule('Organigram');
		$this->incidenceObj = new IncidenceMain();
	}

	public function setFilter($p_filter_fields) {

		$this->filters = $p_filter_fields;
		//dump_array($this->filters);
	}

	private function getRateFromValue($p_val,$p_decimal_place=2) {

		return number_format(($p_val*1000)/$this->participant_count,$p_decimal_place);
	}

	public function processData($p_type='main') {


		if ( empty($this->filters['bu']) ) {
			$this->organigramObj->setItemInfo(array(
													'id'=>0
											));
		} else {
			$this->organigramObj->setItemInfo(array(
													'id'=>$this->filters['bu']
											));
		}

		$partObj = SetupGeneric::useModule('Participant');
		$this->participant_count = $partObj->getActiveParticipantCount();
		$partObj = null;

		$current_bu_info = $this->organigramObj->displayItemByIdForMSR();
		$current_bu_id = $current_bu_info['buID'];
		//dump_array($current_bu_id);
		$child_business_units = $this->organigramObj->displayBuIDByPid();

		if ( $p_type == 'main' ) {

			$accident_info = $this->getMainGraphData();

			//dump_array($accident_info);

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
				}

				if ( $this->filters['data_stat_type'] == 'rate' ) {
					$current_bu_acc_count = $this->getRateFromValue($current_bu_acc_count);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {
						//dump_array($business_units_stack_ele);
					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					if ( $this->filters['data_stat_type'] == 'rate' ) {
						$current_childbu_acc_count = $this->getRateFromValue($current_childbu_acc_count);
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			$child_arr[''] = $child_arr_t;
			if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->incidenceObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['incidenceDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->incidenceObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = array('bu_id'=>$id_val,
								  'key'=>$name_instuctor,
								  'value'=>$val_na);
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   // function removeElementWithValue($child_arr, $key, $value){
		   if($child_arr){
			
				foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
             
			//}

				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Total ".ucfirst($this->filters['data_stat_type'])." of accidents Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Tester Name';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$val_main)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

					//dump_array($this->data_set);

					
			
			}else{
				
					//
			$graph_heading = $this->filters['bu_name'] == '' ? "Total ".ucfirst($this->filters['data_stat_type'])." of Accidents Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);
				
			}

		} if ( $p_type == 'violence' ) {

			$accident_info = $this->getViolenceGraphData();
			
			//dump_array($accident_info);

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
				}

				if ( $this->filters['data_stat_type'] == 'rate' ) {
					$current_bu_acc_count = $this->getRateFromValue($current_bu_acc_count);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					if ( $this->filters['data_stat_type'] == 'rate' ) {
						$current_childbu_acc_count = $this->getRateFromValue($current_childbu_acc_count);
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			$child_arr[''] = $child_arr_t;
			
				
				$graph_heading = $this->filters['bu_name'] == '' ? "Violence and Aggression ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Violence and Aggression ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

				
		
			//
			
		} else if ( $p_type == 'participant' ) {

			$participant_full_info = $this->getParticipantGraphData();
			if ( $this->filters['subtype'] == 'S' ) {
				$participant_info = $participant_full_info['shift_work'];
			} else if ( $this->filters['subtype'] == 'G' ) {
				$participant_info = $participant_full_info['gender'];
			}else if ( $this->filters['subtype'] == 'E' ) {
				$participant_info = $participant_full_info['empType'];
				//dump_array($participant_info);
			}

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();

			if ( $this->filters['subtype'] == 'S' ) {
				$current_bu_yes_count = 0;
				$current_bu_no_count = 0;
			} else if ( $this->filters['subtype'] == 'G' ) {
				$current_bu_male_count = 0;
				$current_bu_female_count = 0;
			} else if ( $this->filters['subtype'] == 'E' ) {

				$hazards = SetupGeneric::useModule('HazardClassification');
				$hazard_parents1 = $hazards->displayCategories1();

				if ( count($hazard_parents1) ) {
					foreach ( $hazard_parents1 as $hazard_class_ele ) {

						$dyn_name = $hazard_class_ele['name'];
						$current_bu_count[$dyn_name] = 0;
					}
				}

			}

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					if ( $this->filters['subtype'] == 'S' ) {
						$current_bu_yes_count += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['Y'];
						$current_bu_no_count += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['N'];
					} else if ( $this->filters['subtype'] == 'G' ) {
						$current_bu_male_count += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['M'];
						$current_bu_female_count += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['F'];
					}else if ( $this->filters['subtype'] == 'E' ) {

						//dump_array($activity_info);

						if ( count($hazard_parents1) ) {
							foreach ( $hazard_parents1 as $hazard_class_ele ) {

								$dyn_name = $hazard_class_ele['name'];

								//$dyn_name = ucwords($this->accident_names[$accident_eled]);
								$current_bu_count[$dyn_name] += (int) $participant_info[$this->filters['year']][$business_units_stack_ele][$hazard_class_ele['name']];

							} // end foreach
						} // end if
					}
				}

				if ( $this->filters['data_stat_type'] == 'rate' && $this->filters['subtype'] == 'S' ) {

					$current_bu_yes_count = $this->getRateFromValue($current_bu_yes_count);
					$current_bu_no_count = $this->getRateFromValue($current_bu_no_count);

				} else if ( $this->filters['data_stat_type'] == 'rate' && $this->filters['subtype'] == 'G' ) {

					$current_bu_male_count = $this->getRateFromValue(current_bu_male_count);
					$current_bu_female_count = $this->getRateFromValue($current_bu_female_count);

				}
			}
			$main_arr = array();

				if ($this->filters['subtype'] == 'E') {
					if ( count($current_bu_count) ) {
					//dump_array($current_bu_count);
						foreach ( $current_bu_count as $current_bu_key=>$current_bu_value ) {
							$main_arr[] = array('key'=>$current_bu_key,'value'=>$current_bu_value);
						}
					}
				}

			if ( $this->filters['subtype'] == 'S' ) {
				$child_arr = array(
							'yes'=>array(),
							'no'=>array()
						);
			} else if ( $this->filters['subtype'] == 'G' ) {
				$child_arr = array(
							'male'=>array(),
							'female'=>array()
						   );
			}

			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {

				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( $this->filters['subtype'] == 'S' ) {
						$current_childbu_yes_count[$child_business_unit_ele['buID']] = 0;
						$current_childbu_no_count[$child_business_unit_ele['buID']] = 0;
					} else if ( $this->filters['subtype'] == 'G' ) {
						$current_childbu_male_count[$child_business_unit_ele['buID']] = 0;
						$current_childbu_female_count[$child_business_unit_ele['buID']] = 0;
					}else if ( $this->filters['subtype'] == 'E' ) {

						if ( count($hazard_parents1) ) {
							foreach ( $hazard_parents1 as $hazard_class_ele ) {

								$dyn_name = $hazard_class_ele['name'];
								$current_childbu_count[$dyn_name][$child_business_unit_ele['buID']] = 0;
							}
						}
					}

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();
					$current_bu_id = $bu_info['buID'];

					if ( count($business_units_stack) ) {

						if ( $this->filters['subtype'] == 'S' ) {

							foreach ( $business_units_stack as $business_units_stack_ele ) {
								$current_childbu_yes_count[$child_business_unit_ele['buID']] += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['Y'];
								$current_childbu_no_count[$child_business_unit_ele['buID']] += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['N'];
							}

							if ( $this->filters['data_stat_type'] == 'rate' ) {

								$current_childbu_yes_count[$child_business_unit_ele['buID']] = $this->getRateFromValue($current_childbu_yes_count[$child_business_unit_ele['buID']]);
								$current_childbu_no_count[$child_business_unit_ele['buID']] = $this->getRateFromValue($current_childbu_no_count[$child_business_unit_ele['buID']]);

							}

							$child_arr_yes[] = array('bu_id'=>$current_bu_id,
													 'key'=>$bu_info['buName'],
													'value'=>$current_childbu_yes_count[$child_business_unit_ele['buID']]);
							$child_arr_no[] = array('bu_id'=>$current_bu_id,
													'key'=>$bu_info['buName'],
											'value'=>$current_childbu_no_count[$child_business_unit_ele['buID']]);

						} else if ( $this->filters['subtype'] == 'G' ) {

							foreach ( $business_units_stack as $business_units_stack_ele ) {
								$current_childbu_male_count[$child_business_unit_ele['buID']] += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['M'];
								$current_childbu_female_count[$child_business_unit_ele['buID']] += (int) $participant_info[$this->filters['year']][$business_units_stack_ele]['F'];
							}

							if ( $this->filters['data_stat_type'] == 'rate' ) {

								$current_childbu_male_count[$child_business_unit_ele['buID']] = $this->getRateFromValue($current_childbu_male_count[$child_business_unit_ele['buID']]);
								$current_childbu_female_count[$child_business_unit_ele['buID']] = $this->getRateFromValue($current_childbu_female_count[$child_business_unit_ele['buID']]);

							}

							$child_arr_male[] = array('bu_id'=>$current_bu_id,
													  'key'=>$bu_info['buName'],
													'value'=>$current_childbu_male_count[$child_business_unit_ele['buID']]);
							$child_arr_female[] = array('bu_id'=>$current_bu_id,
														'key'=>$bu_info['buName'],
											'value'=>$current_childbu_female_count[$child_business_unit_ele['buID']]);
						}else if ( $this->filters['subtype'] == 'E' ) {

								//dump_array($impact_records);

								if ( count($hazard_parents1) ) {
									foreach ( $hazard_parents1 as $hazard_class_ele ) {

										$dyn_name = $hazard_class_ele['name'];
										//dump_array($business_units_stack);
										foreach ( $business_units_stack as $business_units_stack_ele ) {
										$current_childbu_count[$dyn_name][$child_business_unit_ele['buID']] += (int) $participant_info[$this->filters['year']][$business_units_stack_ele][$hazard_class_ele['name']];
										}
									} // end foreach
								} // end if
							}
						
					}
				}
				
				if ($this->filters['subtype'] == 'E' ) {
					$child_arr = array();
					
					//dump_array($current_childbu_count);

					if ( count($current_childbu_count) ) {
						foreach ( $current_childbu_count as $current_childbu_key=>$current_childbu_value ) {

							foreach ( $current_childbu_value as $current_childbu_level2_key=>$current_childbu_level2_value ) {
									//dump_array($current_childbu_count);
									$this->organigramObj->setItemInfo(array(
														'id'=>$current_childbu_level2_key));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
								$current_childbu_key_human_readable = str_replace("_"," ",$current_childbu_key);
								$child_arr[$current_childbu_key_human_readable][] = array('bu_id'=>$current_childbu_level2_key,
																						  'key'=>$bu_info['buName'],
																						  'value'=>$current_childbu_level2_value);
							}
						}
					}
				}

				if ( $this->filters['subtype'] == 'S' ) {
					$child_arr['yes'] = $child_arr_yes;
					$child_arr['no'] = $child_arr_no;
				} else if ( $this->filters['subtype'] == 'G' ) {
					$child_arr['male'] = $child_arr_male;
					$child_arr['female'] = $child_arr_female;
				}
			}


			/*echo "<div style='text-align: left'>";
			dump_array($child_arr);
			echo "</div>";*/



			if ( $this->filters['subtype'] == 'S' ) {
				$yaxis_text = 'Shift';
				$graph_heading = $this->filters['bu_name'] == '' ? "Participant Shift Work ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Participant Shift Work ".ucfirst($this->filters['data_stat_type'])." Graph";
			} else if ( $this->filters['subtype'] == 'G' ) {
				$yaxis_text = 'Gender';
				$graph_heading = $this->filters['bu_name'] == '' ? "Participant Gender ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Participant Gender ".ucfirst($this->filters['data_stat_type'])." Graph";
			} else if ( $this->filters['subtype'] == 'E' ) {
				$yaxis_text = 'Gender';
				$graph_heading = $this->filters['bu_name'] == '' ? "Participant Employment Type ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Participant Employment Type ".ucfirst($this->filters['data_stat_type'])." Graph";
			}

			$graph_heading .= ' for '.$this->filters['year'];
			
			//dump_array($child_arr);

			if ( $this->filters['subtype'] == 'S' ) {

				$this->data_set = array(
						'main_graph'=>array(
							'chart_data'=>array(
												0=>array('key'=>'Yes',
												'value'=>$current_bu_yes_count),
												1=>array('key'=>'No',
												'value'=>$current_bu_no_count)
									),
							'heading'=>$graph_heading,
							'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Participants",
							'yaxis_text'=>'Company/Shift',
							),
						'child_graph'=>array(
							'chart_data'=>$child_arr,
							'heading'=> 'Under '.$graph_heading,
							'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Participants",
							'yaxis_text'=>'Business Units/Shift',
							)
				);
			} else if ( $this->filters['subtype'] == 'G' ) {

				$this->data_set = array(
						'main_graph'=>array(
							'chart_data'=>array(
												0=>array('key'=>'Male',
												'value'=>$current_bu_male_count),
												1=>array('key'=>'Female',
												'value'=>$current_bu_female_count)
									),
							'heading'=>$graph_heading,
							'xaxis_text'=>'Number of Employees',
							'yaxis_text'=>'Company/Gender',
							),
						'child_graph'=>array(
							'chart_data'=>$child_arr,
							'heading'=> 'Under '.$graph_heading,
							'xaxis_text'=>'Number of Employees',
							'yaxis_text'=>'Business Units/Gender',
							)
						);
			}else if ( $this->filters['subtype'] == 'E' ) {

				$this->data_set = array(
						'main_graph'=>array(
							'chart_data'=>$main_arr,
							'heading'=>$graph_heading,
							'xaxis_text'=>'Number of Participants',
							'yaxis_text'=>'Employment Type',
							),
						'child_graph'=>array(
							'chart_data'=>$child_arr,
							'heading'=> 'Under '.$graph_heading,
							'xaxis_text'=>'Number of Participants',
							'yaxis_text'=>'Employment Type',
							)
						);
			}
		} else if ( $p_type == 'activity' ) {

			$activity_full_info = $this->getActivityGraphData();
			//dump_array($activity_full_info['empType']);
			//'B'=>'Part of Body','I'=>'Nature of Injury','T'=>'Type of Treatment','A'=>'Accident Occured','M'=>'Impact','H'=>'Hazard Class'
			//echo $this->filters['subtype'];
			switch ($this->filters['subtype']) {

				case 'B': $activity_info = $activity_full_info['body_part']; break;
				case 'I': $activity_info = $activity_full_info['injury']; break;
				case 'T': $activity_info = $activity_full_info['treatment']; break;
				case 'A': $activity_info = $activity_full_info['accident']; break;
				case 'M': $activity_info = $activity_full_info['impact']; break;
				case 'H': $activity_info = $activity_full_info['hazard_class']; break;
				case 'E': $activity_info = $activity_full_info['empType']; break;

			}

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();

			$part = SetupGeneric::useModule('IncidenceDetail');
			$data_records = $part->displayItems();

			if ( count($data_records) ) {

				foreach ( $data_records as $value ) {
					if ( $value['ipcID'] == 3 ) {

						$part_region = $value['region'];
						$part_id = $value['ID'];

						$this->body_parts[$part_region][] = $part_id;
						$this->part_names[$part_id] = $value['name'];

					}

					if ( $value['ipcID'] == 4 ) {
						$injury_id = $value['ID'];

						$this->injuries[] = $injury_id;
						$this->injury_names[$injury_id] = $value['name'];
					}
					if ( $value['ipcID'] == 1 ) {
						$treatment_id = $value['ID'];

						$this->treatments[] = $treatment_id;
						$this->treatment_names[$treatment_id] = $value['name'];
					}
					if ( $value['ipcID'] == 2 ) {
						$treatment_id = $value['ID'];

						$this->accidents[] = $treatment_id;
						$this->accident_names[$treatment_id] = $value['name'];
					}
				}
			}

			if ( $this->filters['subtype'] == 'B' ) {

				$current_bu_upper_count = 0;
				$current_bu_middle_count = 0;
				$current_bu_lower_count = 0;

			} else if ( $this->filters['subtype'] == 'I' ) {

				if ( count($this->injury_names) ) {
					foreach ( $this->injury_names as $injury_name_ele ) {
						$dyn_name = str_replace("/","_",$injury_name_ele);
						$current_bu_count[$dyn_name] = 0;
					}
				}

			} else if ( $this->filters['subtype'] == 'T' ) {

				if ( count($this->treatment_names) ) {
					foreach ( $this->treatment_names as $treatment_name_ele ) {
						$dyn_name = ucwords($treatment_name_ele);
						$current_bu_count[$dyn_name] = 0;
					}
				}

			}else if ( $this->filters['subtype'] == 'E' ) {

				$hazards = SetupGeneric::useModule('HazardClassification');
				$hazard_parents1 = $hazards->displayCategories1();

				if ( count($hazard_parents1) ) {
					foreach ( $hazard_parents1 as $hazard_class_ele ) {

						$dyn_name = $hazard_class_ele['name'];
						$current_bu_count[$dyn_name] = 0;
					}
				}

			} else if ( $this->filters['subtype'] == 'A' ) {

				if ( count($this->accident_names) ) {
					foreach ( $this->accident_names as $accident_name_ele ) {
						$dyn_name = str_replace("'","-",ucwords($accident_name_ele));
						$current_bu_count[$dyn_name] = 0;
					}
				}

			} else if ( $this->filters['subtype'] == 'M' ) {

				$impact = SetupGeneric::useModule('ImpactMeasure');
				$impact_records = $impact->displayItems();
				//dump_array($impact_records);

				if ( count($impact_records) ) {
					foreach ( $impact_records as $keyImpact=>$valueImpact ) {

						$impact_name = str_replace('<',' ',$valueImpact['name']);
						$impact_shortname = explode('|',$impact_name);

						$dyn_name = ucwords(trim($impact_shortname[0]));
						$current_bu_count[$dyn_name] = 0;
					}
				}

			} else if ( $this->filters['subtype'] == 'H' ) {

				$hazards = SetupGeneric::useModule('HazardClassification');
				$hazard_parents = $hazards->displayCategories();

				if ( count($hazard_parents) ) {
					foreach ( $hazard_parents as $hazard_class_ele ) {

						$dyn_name = $hazard_class_ele['primaryHazard'];
						$current_bu_count[$dyn_name] = 0;
					}
				}
			}

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					if ( $this->filters['subtype'] == 'B' ) {

						foreach ( $this->body_parts as $body_part_elek=>$body_part_eled ) {

							if ( $body_part_elek == 'U' ) {
								foreach ( $body_part_eled as $body_part_sub_ele ) {
									$current_bu_upper_count += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$body_part_sub_ele];
								}
							}

							if ( $body_part_elek == 'M' ) {
								foreach ( $body_part_eled as $body_part_sub_ele ) {
									$current_bu_middle_count += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$body_part_sub_ele];
								}
							}

							if ( $body_part_elek == 'L' ) {
								foreach ( $body_part_eled as $body_part_sub_ele ) {
									$current_bu_lower_count += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$body_part_sub_ele];
								}
							}
						} // end foreach

					} else if ( $this->filters['subtype'] == 'I' ) {
						//dump_array( $this->injury_names);
						if ( count($this->injuries) ) {
							foreach ( $this->injuries as $injury_elek=>$injury_eled ) {
							
								//echo $this->injuries[$injury_elek];
								//dump_array( $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled]);
								if ( $this->injury_names['33'] == 'Amputation' ) {
									$dyn_name = 'Amputation';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['34'] == 'Break/Fracture' ) {
									$dyn_name = 'Break/Fracture';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['35'] == 'Burn/Scald' ) {
									$dyn_name = 'Consciousness';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['36'] == 'Consciousness' ) {
									$dyn_name = 'Consciousness';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['37'] == 'Crush' ) {
									$dyn_name = 'Crush';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['38'] == 'Cut/Laceration' ) {
									$dyn_name = 'Cut/Laceration';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['39'] == 'Dermatitis' ) {
									$dyn_name = 'Dermatitis';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['40'] == 'Dislocate' ) {
									$dyn_name = 'Dislocate';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['41'] == 'Foreign Body' ) {
									$dyn_name = 'Foreign Body';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['42'] == 'Graze/Abrasion' ) {
									$dyn_name = 'Graze/Abrasion';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['43'] == 'Ingestion' ) {
									$dyn_name = 'Ingestion';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['44'] == 'Puncture' ) {
									$dyn_name = 'Puncture';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}
								if ( $this->injury_names['45'] == 'Sprain/Strain' ) {
									$dyn_name = 'Sprain/Strain';
									$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
								}



							} // end foreach
						} // end if

					} else if ( $this->filters['subtype'] == 'T' ) {

						if ( count($this->treatments) ) {
							foreach ( $this->treatments as $treatment_elek=>$treatment_eled ) {

								$dyn_name = ucwords($this->treatment_names[$treatment_eled]);
								$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$treatment_eled];

							} // end foreach
						} // end if

					} else if ( $this->filters['subtype'] == 'A' ) {

						if ( count($this->accidents) ) {
							foreach ( $this->accidents as $accident_elek=>$accident_eled ) {

								//$dyn_name = ucwords($this->accident_names[$accident_eled]);
								$dyn_name = str_replace("'","-",ucwords($this->accident_names[$accident_eled]));
								$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$accident_eled];

							} // end foreach
						} // end if
					} else if ( $this->filters['subtype'] == 'M' ) {

						if ( count($impact_records) ) {
							foreach ( $impact_records as $keyImpact=>$valueImpact ) {

								$impact_name = str_replace('<',' ',$valueImpact['name']);
								$impact_shortname = explode('|',$impact_name);

								$dyn_name = ucwords(trim($impact_shortname[0]));

								//$dyn_name = ucwords($this->accident_names[$accident_eled]);
								$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$valueImpact['ID']];

							} // end foreach
						} // end if
					} else if ( $this->filters['subtype'] == 'H' ) {

						//dump_array($impact_records);

						if ( count($hazard_parents) ) {
							foreach ( $hazard_parents as $hazard_class_ele ) {

								$dyn_name = $hazard_class_ele['primaryHazard'];

								//$dyn_name = ucwords($this->accident_names[$accident_eled]);
								$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$hazard_class_ele['ID']];

							} // end foreach
						} // end if
					} else if ( $this->filters['subtype'] == 'E' ) {

						//dump_array($activity_info);

						if ( count($hazard_parents1) ) {
							foreach ( $hazard_parents1 as $hazard_class_ele ) {

								$dyn_name = $hazard_class_ele['name'];

								//$dyn_name = ucwords($this->accident_names[$accident_eled]);
								$current_bu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$hazard_class_ele['name']];

							} // end foreach
						} // end if
					}
				}

				$main_arr = array();

				if ( $this->filters['subtype'] == 'I' || $this->filters['subtype'] == 'T' || $this->filters['subtype'] == 'A' || $this->filters['subtype'] == 'M' || $this->filters['subtype'] == 'H' || $this->filters['subtype'] == 'E') {
					if ( count($current_bu_count) ) {
					//dump_array($current_bu_count);
						foreach ( $current_bu_count as $current_bu_key=>$current_bu_value ) {
							$main_arr[] = array('key'=>$current_bu_key,'value'=>$current_bu_value);
						}
					}
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);


			switch ($this->filters['subtype']) {

				case 'B': $child_arr = array(
							'upper body'=>array(),
							'middle body'=>array(),
							'lower body'=>array()
							);
						break;

				case 'I': $child_arr = array();
						break;

			}

			// for child business units
			if ( count($child_business_units) ) {

				foreach ( $child_business_units as $child_business_unit_ele ) {

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					$bu_name = $bu_info['buName'];

					if ( $this->filters['subtype'] == 'B' ) {

						$current_childbu_upper_count[$child_business_unit_ele['buID']] 	= 0;
						$current_childbu_middle_count[$child_business_unit_ele['buID']] = 0;
						$current_childbu_lower_count[$child_business_unit_ele['buID']] 	= 0;

					} else if ( $this->filters['subtype'] == 'I' ) {

						if ( count($this->injury_names) ) {
							foreach ( $this->injury_names as $injury_name_ele ) {
								$dyn_name = str_replace("/","_",$injury_name_ele);
								$current_childbu_count[$dyn_name][$bu_name] = 0;
								

								$child_arr[$dyn_name] = array();
							}
						}

					} else if ( $this->filters['subtype'] == 'T' ) {

						if ( count($this->treatment_names) ) {
							foreach ( $this->treatment_names as $treatment_name_ele ) {
								$dyn_name = ucwords($treatment_name_ele);
								$current_childbu_count[$dyn_name][$bu_name] = 0;
							}
						}

					} else if ( $this->filters['subtype'] == 'A' ) {

						if ( count($this->accident_names) ) {
							foreach ( $this->accident_names as $accident_name_ele ) {
								$dyn_name = str_replace("'","-",ucwords($accident_name_ele));
								$current_childbu_count[$dyn_name][$bu_name] = 0;
							}
						}

					} else if ( $this->filters['subtype'] == 'M' ) {

						if ( count($impact_records) ) {
							foreach ( $impact_records as $keyImpact=>$valueImpact ) {

								$impact_name = str_replace('<',' ',$valueImpact['name']);
								$impact_shortname = explode('|',$impact_name);

								$dyn_name = ucwords(trim($impact_shortname[0]));
								$current_childbu_count[$dyn_name][$bu_name] = 0;
							}
						}

					} else if ( $this->filters['subtype'] == 'H' ) {

						if ( count($hazard_parents) ) {
							foreach ( $hazard_parents as $hazard_class_ele ) {

								$dyn_name = $hazard_class_ele['primaryHazard'];
								$current_childbu_count[$dyn_name][$bu_name] = 0;
							}
						}
					} else if ( $this->filters['subtype'] == 'E' ) {

						if ( count($hazard_parents1) ) {
							foreach ( $hazard_parents1 as $hazard_class_ele ) {

								$dyn_name = $hazard_class_ele['name'];
								$current_childbu_count[$dyn_name][$bu_name] = 0;
							}
						}
					}

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);

							if ( $this->filters['subtype'] == 'B' ) {

								foreach ( $this->body_parts as $body_part_elek=>$body_part_eled ) {

									if ( $body_part_elek == 'U' ) {
										foreach ( $body_part_eled as $body_part_sub_ele ) {
											$current_childbu_upper_count[$child_business_unit_ele['buID']] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$body_part_sub_ele];
										}
									}

									if ( $body_part_elek == 'M' ) {
										foreach ( $body_part_eled as $body_part_sub_ele ) {
											$current_childbu_middle_count[$child_business_unit_ele['buID']] += $activity_info[$this->filters['year']][$business_units_stack_ele][$body_part_sub_ele];
										}
									}

									if ( $body_part_elek == 'L' ) {
										foreach ( $body_part_eled as $body_part_sub_ele ) {
											$current_childbu_lower_count[$child_business_unit_ele['buID']] += $activity_info[$this->filters['year']][$business_units_stack_ele][$body_part_sub_ele];
										}
									}
								} // end foreach


							} else if ( $this->filters['subtype'] == 'I' ) {

								$bu_name = $bu_info['buName'];

								if ( count($this->injuries) ) {
									foreach ( $this->injuries as $injury_elek=>$injury_eled ) {

										if ( $this->injury_names[$injury_elek] != '' ) {
											$dyn_name = str_replace("/","_",$this->injury_names[$injury_elek]);
											//$current_childbu_count[$dyn_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
											$current_childbu_count[$dyn_name][$bu_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$injury_eled];
										}

									} // end foreach
								} // end if

							} else if ( $this->filters['subtype'] == 'T' ) {

								if ( count($this->treatments) ) {
									foreach ( $this->treatments as $treatment_elek=>$treatment_eled ) {

										$dyn_name = ucwords($this->treatment_names[$treatment_eled]);
										$current_childbu_count[$dyn_name][$bu_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$treatment_eled];

									} // end foreach
								} // end if

							} else if ( $this->filters['subtype'] == 'A' ) {

								if ( count($this->accidents) ) {
									foreach ( $this->accidents as $accident_elek=>$accident_eled ) {

										//$dyn_name = ucwords($this->accident_names[$accident_eled]);
										$dyn_name = str_replace("'","-",ucwords($this->accident_names[$accident_eled]));
										$current_childbu_count[$dyn_name][$bu_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$accident_eled];

									} // end foreach
								} // end if
							} else if ( $this->filters['subtype'] == 'M' ) {

								//dump_array($impact_records);

								if ( count($impact_records) ) {
									foreach ( $impact_records as $keyImpact=>$valueImpact ) {

										$impact_name = str_replace('<',' ',$valueImpact['name']);
										$impact_shortname = explode('|',$impact_name);

										$dyn_name = ucwords(trim($impact_shortname[0]));

										//$dyn_name = ucwords($this->accident_names[$accident_eled]);
										$current_childbu_count[$dyn_name][$bu_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$valueImpact['ID']];

									} // end foreach
								} // end if
							} else if ( $this->filters['subtype'] == 'H' ) {

								//dump_array($impact_records);

								if ( count($hazard_parents) ) {
									foreach ( $hazard_parents as $hazard_class_ele ) {

										$dyn_name = $hazard_class_ele['primaryHazard'];
										$current_childbu_count[$dyn_name][$bu_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$hazard_class_ele['ID']];

									} // end foreach
								} // end if
							}else if ( $this->filters['subtype'] == 'E' ) {

								//dump_array($impact_records);

								if ( count($hazard_parents1) ) {
									foreach ( $hazard_parents1 as $hazard_class_ele ) {

										$dyn_name = $hazard_class_ele['name'];
										$current_childbu_count[$dyn_name][$bu_name] += (int) $activity_info[$this->filters['year']][$business_units_stack_ele][$hazard_class_ele['name']];

									} // end foreach
								} // end if
							}
						}
					}


					if ( $this->filters['subtype'] == 'B' ) {

						$child_arr_upper[] = array('bu_id'=>$child_business_unit_ele['buID'],
												   'key'=>$bu_info['buName'],
													'value'=>$current_childbu_upper_count[$child_business_unit_ele['buID']]);

						$child_arr_middle[] = array('bu_id'=>$child_business_unit_ele['buID'],
													'key'=>$bu_info['buName'],
											'value'=>$current_childbu_middle_count[$child_business_unit_ele['buID']]);

						$child_arr_lower[] = array('bu_id'=>$child_business_unit_ele['buID'],
												   'key'=>$bu_info['buName'],
											'value'=>$current_childbu_lower_count[$child_business_unit_ele['buID']]);


					}
				}

				if ( $this->filters['subtype'] == 'B' ) {

					$child_arr['upper body'] 	= $child_arr_upper;
					$child_arr['middle body'] 	= $child_arr_middle;
					$child_arr['lower body'] 	= $child_arr_lower;

					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Part of Body ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Part of Body ".ucfirst($this->filters['data_stat_type'])." Graph";

				}

				if ( $this->filters['subtype'] == 'I' ) {
					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Nature of Injury ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Nature of Injury ".ucfirst($this->filters['data_stat_type'])." Graph";
				}

				if ( $this->filters['subtype'] == 'T' ) {
					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Type of Treatment ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Type of Treatment ".ucfirst($this->filters['data_stat_type'])." Graph";
				}

				if ( $this->filters['subtype'] == 'A' ) {
					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Accident Occured ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Accident Occured ".ucfirst($this->filters['data_stat_type'])." Graph";
				}

				if ( $this->filters['subtype'] == 'M' ) {
					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Impact ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Impact ".ucfirst($this->filters['data_stat_type'])." Graph";
				}

				if ( $this->filters['subtype'] == 'H' ) {
					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Hazard Class ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Hazard Class ".ucfirst($this->filters['data_stat_type'])." Graph";
				}
				if ( $this->filters['subtype'] == 'E' ) {
					$graph_heading = $this->filters['bu_name'] == '' ? "Activity - Employment Type ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Activity - Employment Type".ucfirst($this->filters['data_stat_type'])." Graph";
				}

				$graph_heading .= ' for '.$this->filters['year'];

				if ( $this->filters['subtype'] == 'I' || $this->filters['subtype'] == 'T' || $this->filters['subtype'] == 'A' || $this->filters['subtype'] == 'M' || $this->filters['subtype'] == 'H' || $this->filters['subtype'] == 'E' ) {
					$child_arr = array();
					
					//dump_array($current_childbu_count);

					if ( count($current_childbu_count) ) {
						foreach ( $current_childbu_count as $current_childbu_key=>$current_childbu_value ) {

							foreach ( $current_childbu_value as $current_childbu_level2_key=>$current_childbu_level2_value ) {
									//dump_array($current_childbu_count);
								$current_childbu_key_human_readable = str_replace("_"," ",$current_childbu_key);
								$child_arr[$current_childbu_key_human_readable][] = array('bu_id'=>$child_business_unit_ele['buID'],
																						  'key'=>$current_childbu_level2_key,
																						  'value'=>$current_childbu_level2_value);
							}
						}
					}
				}
			}

			//$graph_heading = $this->filters['bu_name'] == '' ? "Participant Shift Work Graph" : $this->filters['bu_name']." - Participant Shift Work Graph";
			//$graph_heading .= ' for '.$this->filters['year'];
			
			//dump_array($child_arr);

			if ( $this->filters['subtype'] == 'S' ) {
				$yaxis_text = 'Shift Work';
			} else if ( $this->filters['subtype'] == 'G' ) {
				$yaxis_text = 'Gender';
			}

			if ( $this->filters['subtype'] == 'B' ) {

				$this->data_set = array(
						'main_graph'=>array(
							'chart_data'=>array(
												0=>array('key'=>'Upper Body',
												'value'=>$current_bu_upper_count),
												1=>array('key'=>'Middle Body',
												'value'=>$current_bu_middle_count),
												2=>array('key'=>'Lower Body',
												'value'=>$current_bu_lower_count)
									),
							'heading'=>$graph_heading,
							'xaxis_text'=>'Number of Participants',
							'yaxis_text'=>$yaxis_text,
							),
						'child_graph'=>array(
							'chart_data'=>$child_arr,
							'heading'=> 'Under '.$graph_heading,
							'xaxis_text'=>'Number of Participants',
							'yaxis_text'=>$yaxis_text,
							)
						);
			} else if ( $this->filters['subtype'] == 'I' || $this->filters['subtype'] == 'T' || $this->filters['subtype'] == 'A' || $this->filters['subtype'] == 'M' || $this->filters['subtype'] == 'H'  || $this->filters['subtype'] == 'E' ) {

				$this->data_set = array(
						'main_graph'=>array(
							'chart_data'=>$main_arr,
							'heading'=>$graph_heading,
							'xaxis_text'=>'Number of Participants',
							'yaxis_text'=>$yaxis_text,
							),
						'child_graph'=>array(
							'chart_data'=>$child_arr,
							'heading'=> 'Under '.$graph_heading,
							'xaxis_text'=>'Number of Participants',
							'yaxis_text'=>$yaxis_text,
							)
						);
			}
		} else if ( $p_type == 'action' ) {

			$action_full_info = $this->getActionGraphData();

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();
            
			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $action_full_info[$this->filters['year']][$business_units_stack_ele];
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $action_full_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			$child_arr[''] = $child_arr_t;
		if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->incidenceObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['incidenceDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->incidenceObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = array('bu_id'=>$id_val,
								  'key'=>$name_instuctor,
								  'value'=>$val_na);
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   if($child_arr){
			
			 	foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }

				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Accident ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Tester Name';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$val_main)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

					//dump_array($this->data_set);

					
			
			}else{
				
					$graph_heading = $this->filters['bu_name'] == '' ? "Action ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Action ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						)
					);
				
			}
			//
		
		} else if ( $p_type == 'accident_ontest' ) {

			$action_full_info = $this->getActionGraphData();
             $ac = $this->resultSet();
			 
			
			
			if ( $this->filters['type'] == 'rsa' ) {
				$nhp1 = $ac['rsa'];
			}
			if ( $this->filters['type'] == 'all' ) {
				$nhp5 = $ac['all'];
			}
		
			if ( $this->filters['type'] == 'public' ) {
				$nhp2 = $ac['public'];
			}
			if ( $this->filters['type'] == 'other' ) {
				$nhp3 = $ac['other'];
			}
			
			if ( $this->filters['type'] == 'roadside' ) {
				$nhp4 = $ac['roadside'];
			}
				
			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();
            
			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					
					if ( $this->filters['type'] == 'all' ) {
					$current_bu_acc_count += (int) $nhp5[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'rsa' ) {
						$current_bu_acc_count += (int) $nhp1[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'public' ) {
						$current_bu_acc_count += (int) $nhp2[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'other' ) {
						$current_bu_acc_count += (int) $nhp3[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'roadside' ) {
						$current_bu_acc_count += (int) $nhp4[$this->filters['year']][$business_units_stack_ele];
					}
					//$current_bu_acc_count += (int) $action_full_info[$this->filters['year']][$business_units_stack_ele];
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
					if ( $this->filters['type'] == 'all' ) {
						$current_childbu_acc_count += (int) $nhp5[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'rsa' ) {
						$current_childbu_acc_count += (int) $nhp1[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'public' ) {
						$current_childbu_acc_count += (int) $nhp2[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'other' ) {
						$current_childbu_acc_count += (int) $nhp3[$this->filters['year']][$business_units_stack_ele];
					}
					if ( $this->filters['type'] == 'roadside' ) {
						$current_childbu_acc_count += (int) $nhp4[$this->filters['year']][$business_units_stack_ele];
					}
							//$current_childbu_acc_count += (int) $action_full_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			$child_arr[''] = $child_arr_t;
			if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->incidenceObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['incidenceDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->incidenceObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = array('bu_id'=>$id_val,
								  'key'=>$name_instuctor,
								  'value'=>$val_na);
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   if($child_arr){
			
				foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Accidents on Test ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'].'-'.$this->filters['type'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Tester Name';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$val_main)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

					//dump_array($this->data_set);

					
			
			}else{
				$graph_heading = $this->filters['bu_name'] == '' ? "Accidents on Test ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Action ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'].'-'.ucfirst($this->filters['type']);

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						)
					);
				
				
			}

		
		} 
		
		else if ( $p_type == 'accident_butest' ) {
		//echo "sdfsfsdf";
				$action_full_info = $this->getActionGraphData();
             $ac = $this->resultSetBU();
			 $data = $this->resultSelectBU();
			//dump_array($ac['all']);
			
			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();
            
			$current_bu_acc_count = 0;

			if ( count($data) ) {
			 
				foreach ( $data as $value ) {
				
				if($this->filters['t_month'] == 'a'){
					if ( $this->filters['type_bu'] == 'all' ) {
					$current_bu_acc_count_1 += (int) $ac['all'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'rsa' ) {
					$current_bu_acc_count_1 += (int) $ac['rsa'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'public' ) {
					$current_bu_acc_count_1 += (int) $ac['public'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'roadside' ) {
					$current_bu_acc_count_1 += (int) $ac['roadside'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'other' ) {
					$current_bu_acc_count_1 += (int) $ac['other'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				}else{
				if ( $this->filters['type_bu'] == 'all' ) {
					$current_bu_acc_count_1 += (int) $ac['all'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'rsa' ) {
					$current_bu_acc_count_1 += (int) $ac['rsa'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'public' ) {
					$current_bu_acc_count_1 += (int) $ac['public'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'roadside' ) {
					$current_bu_acc_count_1 += (int) $ac['roadside'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'other' ) {
					$current_bu_acc_count_1 += (int) $ac['other'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				
				}
		
				
				}
			
				
			}
		
			$child_arr_A['0'] = array(
									'bu_id'=>'4',
								  'key'=>'Standards and Enforcement',
								  'value'=>$current_bu_acc_count_1);
			$child_arr_A['1'] = array(
									'bu_id'=>'3',
								  'key'=>'Completed',
								  'value'=>$current_bu_acc_count_2);
		   


			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			//if ( count($child_business_units) ) {
			//	foreach ( $child_business_units as $child_business_unit_ele ) {

					//if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
					//	continue;
					//}

					//$business_units_stack = array();

					//$this->organigramObj->clearStack();
					//$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					//$this->organigramObj->setItemInfo(array(
					//									'id'=>$child_business_unit_ele['buID']));
					//$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					//$business_units_stack = $this->organigramObj->getStack();

					//dump_array($data);

					if ( count($data) ) {
						foreach ( $data as $value ) {
						//dump_array($value);
							//dump_array($accident_info[$this->filters['year']]);
							if ( in_array($value['buID'],$exclude_bus_arr) ) {
									continue;
								}

							$current_childbu_acc_count = 0;
							if($this->filters['t_month'] == 'a'){
							//echo "sdfsdf";
							if ( $this->filters['type_bu'] == 'all' ) {
							$current_childbu_acc_count += (int) $ac['all'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'rsa' ) {
							$current_childbu_acc_count += (int) $ac['rsa'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'public' ) {
							$current_childbu_acc_count += (int) $ac['public'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'other' ) {
							$current_childbu_acc_count += (int) $ac['other'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'roadside' ) {
							$current_childbu_acc_count += (int) $ac['roadside'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							
							}else{
							if ( $this->filters['type_bu'] == 'all' ) {
							$current_childbu_acc_count += (int) $ac['all'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'rsa' ) {
							$current_childbu_acc_count += (int) $ac['rsa'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'public' ) {
							$current_childbu_acc_count += (int) $ac['public'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'other' ) {
							$current_childbu_acc_count += (int) $ac['other'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'roadside' ) {
							$current_childbu_acc_count += (int) $ac['roadside'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							
							}
							
							
							$child_arr_t[] = array('bu_id'=>$value['buID'],
								  'key'=>$value['buName'],
								  'value'=>$current_childbu_acc_count);
						}
					}

					$child_arr[''] = $child_arr_t;
				//}
			//}
		//dump_array($child_arr);
				$graph_heading = $this->filters['bu_name'] == '' ? "Accidents on Test ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Action ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'].'-'.ucfirst($this->filters['type_bu']);

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>'',
											'value'=>$current_bu_acc_count_1)
									
											
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						)
					);
				
				
			
		
		}

		else if ( $p_type == 'accident_bypublic' ) {

			$accident_info = $this->getAccidentPublicGraphData();

			//dump_array($accident_info);

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					$child_arr_t[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
				$child_arr[''] = $child_arr_t;
			//
			$graph_heading = $this->filters['bu_name'] == '' ? "Accident by Public ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Accident by Public ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											''=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'yaxis_text'=>'Number of accidents',
						'xaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'yaxis_text'=>'Number of accidents',
						'xaxis_text'=>$yaxis_text,
						)
					);

		} // end $p_type == 'accident_bypublic'
	}

	private function getMainGraphData() {

		return $this->incidenceObj->getNoOfAccidents();
	}

	private function getViolenceGraphData() {

		return $this->incidenceObj->getNoOfViolenceIncidence();
	}

	private function getParticipantGraphData() {

		return $this->incidenceObj->getNoOfParticipants();
	}

	private function getActivityGraphData() {

		return $this->incidenceObj->getNoOfActivities();
	}

	private function getActionGraphData() {

		return $this->incidenceObj->getNoOfActions();
	}

	private function getAccidentTestGraphData() {

		$this->incidenceObj->getInstructorGraphData();
	}

	private function getAccidentPublicGraphData() {

		return $this->incidenceObj->getAccidentPublicGraphData();
	}
	private function resultSet() {

		return $this->incidenceObj->getAccidetTest();
	}
	
	private function resultSetBU() {

		return $this->incidenceObj->getAccidetBuTest();
	}

	
	private function resultSelectBU() {

		return $this->incidenceObj->getSelectedBu();
	}

	public function exportGraphData() {

		return $this->data_set;
	}
}
?>