<?php
 /**
  $Id: HorizontalMultiGraph.class.php,v 3.19 Thursday, January 20, 2011 3:27:07 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage
  * @since  Thursday, November 25, 2010 6:02:00 PM>
  */
    class HorizontalMultiGraph {

        public $graph_parameter ;
        private $graph_width;
		private $graph_height;
		private $xml_file_name;
		private $graph_data;
        private $graph_settings;
		private $module_name;
		private $graph_type;

        public function __construct($p_module,$p_graph_data) {

            $this->graph_data = $p_graph_data;
			$this->module_name = $p_module;
            $this->horizontalgraph = array();
			$this->graph_settings = "/includes/js/graphs/chart_horizonat_multiple_settings.xml" ;
			$this->graph_type = "/includes/js/graphs/amcolumn.swf" ;
        }

		public function convertToXml() {

			$next_label_id = 1;
			$number_of_multiples = 0;

			if ( count($this->graph_data['chart_data']) ) {
                $i = 0;

                foreach ( $this->graph_data['chart_data'] as $val ) {
					$j=0;
					if ($val['link'] != "") {$url = "url='".$val['link']."'"; }
                    $graph_data_y .=  "<value xid='".$i."'>".$val['key']."</value>\n";

					if ( count($val['values']) ) {
						foreach ( $val['values'] as $keyval ) {
							$xaxis_array_id = "graph_data_x".$j;
							/*if($j==0) {

							}*/
							if($i==0) {
								//$$xaxis_array_id .=  "<title>".$this->graph_data['xaxis_labels'][$j]."</title>";
								$this->graph_width = $this->graph_width + 85;
								$number_of_multiples++;
							}
							$$xaxis_array_id .=  "<value xid='".$i."' ".$url.">".$keyval."</value>\n";
							$j++;
						}
					}


                    $this->graph_height = $this->graph_height + 50;                 // for graph height


                    $i++;
                } // end foreach

				/* increase height of graph for labels */
				if( count($this->graph_data['labels']) ) {

					foreach ( $this->graph_data['labels'] as $label_val ) {

						$this->graph_height = $this->graph_height + 70;
						$graph_data_y .=  "<value xid='".$i."'> </value>\n";
						$i++;

					} // end foreach

				} // end if

				$this->graph_width = $this->graph_width <= 600? 600 : $this->graph_width;
				$this->graph_height = $this->graph_height <= 250? 250 : $this->graph_height;


				$graph_data = "<?xml version='1.0' encoding='UTF-8'?><chart><series>";
				$graph_data .= $graph_data_y;
				$graph_data .= "</series><graphs>\n";

				//dump_array($this->graph_data['xaxis_labels']);

				if ( $number_of_multiples ) {

					for($i=0;$i<=($number_of_multiples-1);$i++) {

						if ( $this->graph_data['xaxis_labels'][$i] != '' ) {
							$title = " title='".$this->graph_data['xaxis_labels'][$i]."' ";
						}

						$graph_data .= "<graph gid='".$i."' ".$title.">\n";
						//$graph_data .= "<title><![CDATA[".$this->graph_data['xaxis_labels'][$i]."]]></title>\n";
						$xaxis_array_id = "graph_data_x".$i;
						$graph_data .= $$xaxis_array_id;
						$graph_data .= "</graph>\n";

						$this->graph_height = $this->graph_height + 13;

					}
				}


				$graph_data .= "</graphs>";

            } // end if

			#################### labels code ########################
            $graph_data .=  "<labels>";

            $this->graph_width = $this->graph_width <= 600? 600 : $this->graph_width;
            $this->graph_height = $this->graph_height <= 200? 200 : $this->graph_height;

            if ( $this->graph_data['heading'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>25</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['heading']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['xaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>205</x>";
                $graph_data .=  "<y>".($this->graph_height-50)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['xaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['yaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>5</x>";
				$graph_data .=  "<rotate>true</rotate>";
                $graph_data .=  "<y>".($this->graph_height+59)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['yaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if( count($this->graph_data['labels']) ) {
                $i = $next_label_id;
                $x_pos = $this->graph_width/2;
                $y_pos = 55;

                foreach ( $this->graph_data['labels'] as $label_val ) {

                    $graph_data .=  "<label lid='".$i."'>";
                    $graph_data .=  "<x>".$x_pos."</x>";
                    $graph_data .=  "<y>".$y_pos."</y>";
                    $graph_data .=  "<align></align>";
                    $graph_data .=  "<text><![CDATA[".$label_val."]]></text>";
                    $graph_data .=  "</label>";

                    $y_pos = $y_pos + 20;
					//$x_pos = $x_pos + 60;
                    $i++;
                } // end foreach
            } //end if

            ##################################################################

			//$graph_data .= "</chart>";
			$graph_data .= "</labels></chart>";

			//echo $graph_data;

			     ####### write the xml data into xml file #########
			$dyn_xml_name = str_replace(' ','_',$this->graph_data['heading']);
            $this->xml_file_url = realpath($_SERVER['DOCUMENT_ROOT']."/private_files/".$this->module_name)."/graph_data_file_".$dyn_xml_name.".xml";
			$this->xml_file_name  = "/private_files/".$this->module_name."/graph_data_file_".$dyn_xml_name.".xml";

			//$this->xml_file_name = "graph_data_file_".$dyn_xml_name.".xml";

            $file_handle = fopen($this->xml_file_url,'w');
            if ($file_handle) {

                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if

		}
/*
        public function convertToXml() {

           $this->graph_width = 35;
           $this->graph_height = 35;

            $graph_data = "<?xml version='1.0' encoding='UTF-8'?><chart><series>";

            if ( count($this->graph_data['y_axis']) ) {
                $i = 0;
                foreach ( $this->graph_data['y_axis'] as $val ) {
                    $graph_data .=  "<value xid='".$i."'>".$val."</value>";
                    $this->graph_height = $this->graph_height + 35;
                    $i++;
                } // end foreach
            } // end if


            $graph_data .=  "</series><graphs>";

            if ( count($this->graph_data['x_axis']) ) {
                $j=0;
                foreach($this->graph_data['x_axis'] as $key=>$val) {
                    $graph_data .=  "<graph gid='".$j."'>";
                    $graph_data .=  "<title>".$key."</title>";
                    $i=0;
                    foreach($val as $value) {
                        $graph_data .=  "<value xid='".$i."'>".$value."</value>";
                        if($j == 0) {
                            $this->graph_width = $this->graph_width + 15;
                        }
                        $i++;
                    }
                    $graph_data .=  "</graph>";
                    $j++;
                }
            }

            $graph_data .=  "</graphs><labels>";

            if ( $this->graph_data['heading'] ) {

                $graph_data .=  "<label lid='1'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>25</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['heading']."</b>]]></text>";
                $graph_data .=  "</label>";
                $i++;

            }
            $graph_data .=  "</labels></chart>";

            $this->graph_width = $this->graph_width <= 600? 600 : $this->graph_width;
            $this->graph_height = $this->graph_height <= 200? 200 : $this->graph_height;

            $this->xml_file_name = "graph_data_file.xml";

            $file_handle = fopen($this->xml_file_name,'w');
            if ($file_handle) {

                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if
        }*/

        public function getData() {
            $this->graph_parameter['graph_width'] = $this->graph_width;
            $this->graph_parameter['graph_height'] = $this->graph_height;
            $this->graph_parameter['xml_file_name'] = $this->xml_file_name;
            $this->graph_parameter['graph_settings'] = $this->graph_settings;
            $this->graph_parameter['graph_type'] = $this->graph_type;
        }
    }
?>