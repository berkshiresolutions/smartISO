<?php
 /**
  $Id: NhpPieGraph.class.php,v 3.08 Thursday, December 23, 2010 12:04:05 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage NHP Graph
  * @since  Wednesday, December 01, 2010 4:42:05 PM>
  */
    require_once "GraphModuleData.int.php";
	require_once "GraphData.abs.php";

class NhpPieGraph extends NhpMain implements GraphModuleData {

	private $filter_query;
	private $filters;
	private $data_set;
	private $buObj;
	private $org_data;
	private $childTotal;

	public function __construct() {

		//$this->setFilter();
		$this->data_format = new GraphData();

		// organigram object
		$this->buObj = SetupGeneric::useModule('Organigram');

		parent::__construct();
	}

	/* to set the filetrs for search */
	public function setFilter($filter_fields) {
		$this->filters = $filter_fields;
	}

	private function getnhpCounts($org_data_key,$valuetoadd=0,$nhp_data) {

		if ( count($this->org_data[$org_data_key]) ) {

			foreach( $this->org_data[$org_data_key] as $key=>$value ) {

				if ( $nhp_data[$key] ) {
					$this->childTotal += (int) $nhp_data[$key];
				}
				if ( count($this->org_data[$key]) ) {
					$this->getnhpCounts($key,$valuetoadd,$nhp_data);
					//echo "<br/>";
				}
			}

		}

		return $valuetoadd;
	}

	/* to get result for main graph */
	private function resultSet() {
		
		$data = $this->getNoOfNhps();
		$this->org_data = $this->buObj->businessListForGraph(0);

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$nhp_data = $data[$selected_year];



		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( count($this->org_data[$bu_id]) ) {
			foreach( $this->org_data[$bu_id] as $key=>$value ) {

				$this->childTotal = 0;

				if ( count($this->org_data[$key]) ) {

					$this->getnhpCounts($key,$new2_data[$key],$nhp_data);
				}

				$graph_data[$key]['name'] = $value;
				$graph_data[$key]['self_data'] = (int) $nhp_data[$key];
				$graph_data[$key]['child_data'] = (int) $this->childTotal;
				//}
			}
		}
		//dump_array($data);

		$graph_heading = $this->filters['bu_name'] == '' ? "NHC Graph" : $this->filters['bu_name']." - NHC Graph";

		$graph_heading = $graph_heading.' for '.$selected_year;

		$sql_query = "".$this->filter_query ;

		if ( count($graph_data) ) {
			foreach($graph_data as $key=>$val) {
				$data_arr = array($val['name'],'?year='.$selected_year.'&bu='.$key,(int) ($val['self_data']+$val['child_data']));
				$this->data_format->addDataPieLink($data_arr);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "NHC Graph";
	}


	/* to get result for risk impact graph */
	public function resultSetImpact() {

		$impact = SetupGeneric::useModule('ImpactMeasure');
		$data = $this->getGraphDataRisk();

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$nhp_data = $data['risk'][$selected_year];


		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( $bu_id ) {
			$graph_data = $nhp_data[$bu_id];
		} else {
			if ( count( $nhp_data ) ) {
				foreach ( $nhp_data as $value ) {

					if ( count( $value ) ) {
						foreach ( $value as $key=>$value2 ) {
							$graph_data[$key] += $value2;
						}
					}

				}
			}
		}

		$data_records = $impact->displayItems();
		$record_count = count($data_records);

		if ( $record_count ) {
			foreach ( $data_records as $valueImpact ) {
				$impact_arr[$valueImpact['ID']] = $valueImpact['name'];
			}
		}

		if ( count($impact_arr) ) {
			foreach ( $impact_arr as $key=>$value ) {

				$value = str_replace('<','&lt;',$value);
				$name_arr = explode('|',$value);
				$dipaly_name = str_replace('&lt;','',$name_arr[0]);
				//$this->data_format->addData($dipaly_name,$graph_data[$key]);
				$this->data_format->addDataPieLink(array($dipaly_name,'',(int) $graph_data[$key]));

				$legends[] = $dipaly_name.' = '.$value;
			}
		}

		//dump_array($impact_arr);

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "NHC Graph";
		$this->data_set['labels'] = $legends;


	}


	/* to get result for causes graph */
	public function resultSetCauses() {

		$data = $this->getGraphDataCauses();

		$selected_year = $this->filters['year'];
		//$selected_year = '2007';
		$nhp_data = $data[$selected_year];


		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( $bu_id ) {
			$graph_data = $nhp_data[$bu_id];
		} else {
			if ( count( $nhp_data ) ) {
				foreach ( $nhp_data as $value ) {

					if ( count( $value ) ) {
						foreach ( $value as $key=>$value2 ) {
							$graph_data[$key] += $value2;
						}
					}

				}
			}
		}

		//dump_array($graph_data);

		if ( count($graph_data) ) {
			foreach ( $graph_data as $key=>$value ) {

				$dipaly_name = str_replace('_',' ',$key);
				$this->data_format->addDataPieLink(array(ucwords($dipaly_name),'',(int) $value));

			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "NHC Causes Graph";
	}


	/* to get result for disposition graph */
	public function resultSetDisposition() {

		$disposition = SetupGeneric::useModule('NhpOption');
		$data = $this->getGraphDataRisk();

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$nhp_data = $data['disposition'][$selected_year];


		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( $bu_id ) {
			$graph_data = $nhp_data[$bu_id];
		} else {
			if ( count( $nhp_data ) ) {
				foreach ( $nhp_data as $value ) {

					if ( count( $value ) ) {
						foreach ( $value as $key=>$value2 ) {
							$graph_data[$key] += $value2;
						}
					}

				}
			}
		}

		$data_records = $disposition->displayItems();
		$record_count = count($data_records);

		//dump_array($data_records);

		if ( $record_count ) {
			foreach ( $data_records as $valueDisp ) {
				if ( $valueDisp['envSubType'] != 'D' ) { continue; }
				$disposition_arr[$valueDisp['ID']] = $valueDisp['optionLabel'];
			}
		}

		if ( count($disposition_arr) ) {
			foreach ( $disposition_arr as $key=>$value ) {

				//$this->data_format->addData($value,$graph_data[$key]);
				$this->data_format->addDataPieLink(array(ucwords($value),'',(int) $graph_data[$key]));

				//$legends[] = $dipaly_name.' = '.$value;
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "NHC Disposition Graphh";
		$this->data_set['xaxis_text'] = "Number of NHC Dispositions";
		$this->data_set['yaxis_text'] = "Dispositions";

	}

	/* to export data*/
	public function exportGraphData($p_type='') {

		if ( !empty($p_type) ) {

			$method = "resultSet".ucwords($p_type);
			$this->$method();
		} else {
			$this->resultSet();
		}

		return $this->data_set;
	}
}
?>