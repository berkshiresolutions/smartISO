<?php
 /**
  $Id: HorizontalGraph.class.php,v 3.14 Thursday, January 20, 2011 3:27:05 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Horizontal graphs
  * @since  Thursday, September 09, 2010 10:08:22 AM>
  */
    class HorizontalIpadGraph
    {

        public $graph_parameter;
        private $graph_width;
		private $graph_height;
		private $xml_file_name;
		private $graph_data;
        private $graph_settings;
		private $module_name;
		private $graph_type;

        public function __construct($p_module,$p_graph_data) {

            $this->graph_data = & $p_graph_data;
			$this->module_name = $p_module;
            $this->graph_parameter = array();
			$this->graph_settings = "/includes/js/graphs/chart_settings.xml" ;
			$this->graph_type = "/includes/js/graphs/ipad/Bar2D.swf" ;
        }

		public function convertToXml() {
			
			$additional_height = $this->graph_data['additional_height'] == '' ? 0 : (int) $this->graph_data['additional_height'];

			$next_label_id = 1;

			//dump_array($this->graph_data['chart_data']);

			if ( count($this->graph_data['chart_data']) ) {
                $i = 0;
                foreach ( $this->graph_data['chart_data'] as $val ) {

					$url = "";
					if ( $val['link'] != '' ) {
						$url = " link='".$val['link']."'";
					}
					
					$g_data .= '<set label="'.$val['key'].'" value="'.$val['value'].'" toolText="'.$val['key'].' : '.$val['value'].'" '.$url.' /> ';

                    /*$graph_data_y .=  "<value xid='".$i."'><![CDATA[".$val['key']."]]></value>";
					$graph_data_x .=  "<value xid='".$i."' ".$url."><![CDATA[".$val['value']."]]></value>";*/
                    $this->graph_height = $this->graph_height + 40 + $additional_height;                 // for graph height
					$this->graph_width = $this->graph_width + 20;
                    $i++;

                } // end foreach
            } // end if

			/* increase height of graph for labels */
            if( count($this->graph_data['labels']) ) {
                foreach ( $this->graph_data['labels'] as $label_val ) {
                    $this->graph_height = $this->graph_height + 50;
                    $graph_data_y .=  "<value xid='".$i."'> </value>";
                    $i++;
                } // end foreach
            } // end if

            $graph_data = "<chart caption='".$this->graph_data['heading']."' yAxisName='".$this->graph_data['xaxis_text']."' xAxisName='".$this->graph_data['yaxis_text']."' bgColor='F1F1F1' showValues='0' canvasBorderThickness='1' canvasBorderColor='999999' plotFillAngle='330' plotBorderColor='999999' showAlternateVGridColor='1' divLineAlpha='0'>";
			$graph_data .= $g_data;
			$graph_data .= "</chart>";



			 #################### labels code ########################
           /* $graph_data .=  "<labels>";

            $this->graph_width = $this->graph_width <= 600? 600 : $this->graph_width;
            $this->graph_height = $this->graph_height <= 250? 250 : $this->graph_height;

            if ( $this->graph_data['heading'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>25</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['heading']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['xaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>0</x>";
                $graph_data .=  "<y>".($this->graph_height-25)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['xaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if ( $this->graph_data['yaxis_text'] ) {

                $graph_data .=  "<label lid='".$next_label_id."'>";
                $graph_data .=  "<x>5</x>";
				$graph_data .=  "<rotate>true</rotate>";
                $graph_data .=  "<y>".($this->graph_height-55)."</y>";
                $graph_data .=  "<align>center</align>";
                $graph_data .=  "<text><![CDATA[<b>".$this->graph_data['yaxis_text']."</b>]]></text>";
                $graph_data .=  "</label>";

                $next_label_id++;

            } // end if

			if( count($this->graph_data['labels']) ) {
                $i = $next_label_id;
                $x_pos = ($this->graph_width/2 - 50);
                $y_pos = 55;
                foreach ( $this->graph_data['labels'] as $label_val ) {

                    $graph_data .=  "<label lid='".$i."'>";
                    $graph_data .=  "<x>".$x_pos."</x>";
                    $graph_data .=  "<y>".$y_pos."</y>";
                    $graph_data .=  "<align></align>";
                    $graph_data .=  "<text><![CDATA[".$label_val."]]></text>";
                    $graph_data .=  "</label>";

                    $y_pos = $y_pos + 20;
                    $i++;
                } // end foreach
            } //end if

            ##################################################################

			$graph_data .= "</labels></chart>";*/

			     /* write the xml data into xml file */
            $dyn_xml_name = str_replace(' ','_',$this->graph_data['heading']);
            $this->xml_file_url = realpath($_SERVER['DOCUMENT_ROOT']."/private_files/".$this->module_name)."/graph_data_file_".$dyn_xml_name.".xml";
			$this->xml_file_name  = "/private_files/".$this->module_name."/graph_data_file_".$dyn_xml_name.".xml";
			

            $file_handle = fopen($this->xml_file_url,'w');
            if ($file_handle) {

                fwrite($file_handle,$graph_data,strlen($graph_data));
                fclose($file_handle);
            } // end if
			
			//exit;
		}

        public function getData() {
            $this->graph_parameter['graph_width'] = $this->graph_width;
            $this->graph_parameter['graph_height'] = $this->graph_height;
            $this->graph_parameter['xml_file_name'] = $this->xml_file_name;
            $this->graph_parameter['graph_settings'] = $this->graph_settings;
            $this->graph_parameter['graph_type'] = $this->graph_type;
        }
    }
?>