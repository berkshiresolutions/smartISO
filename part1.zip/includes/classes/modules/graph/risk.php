<?php
 /**
  $Id: incidence.php,v 3.46 Wednesday, February 02, 2011 2:50:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used for incidence graphs
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence graph data
  * @since  Tuesday, September 28, 2010 6:13:45 PM>
  */

require_once "GraphModuleData.int.php";
require_once "GraphData.abs.php";

class RiskGraph implements GraphModuleData  {

	private $data_set;
	private $filter_query;
	private $filters;
	private $organigramObj;
	private $incidenceObj;
	private $child_business_units;

	public function __construct() {

		$this->data_format = new GraphData();
		$this->organigramObj = SetupGeneric::useModule('Organigram');
		$this->incidenceObj = new IncidenceMain();
	}

	public function setFilter($p_filter_fields) {

		$this->filters = $p_filter_fields;
		//dump_array($this->filters['name']['primaryHazard']);
	}

	private function getRateFromValue($p_val,$p_decimal_place=2) {

		return number_format(($p_val*1000)/$this->participant_count,$p_decimal_place);
	}

	public function processData($p_type='main') {


		if ( empty($this->filters['bu']) ) {
			$this->organigramObj->setItemInfo(array(
													'id'=>0
											));
		} else {
			$this->organigramObj->setItemInfo(array(
													'id'=>$this->filters['bu']
											));
		}

		$partObj = SetupGeneric::useModule('Participant');
		$this->participant_count = $partObj->getActiveParticipantCount();
		$partObj = null;

		$current_bu_info = $this->organigramObj->displayItemByIdForMSR();
		$current_bu_id = $current_bu_info['buID'];
		//dump_array($current_bu_id);
		$child_business_units = $this->organigramObj->displayBuIDByPid();
       
		if ( $p_type == 'main' ) {
		
		

			$accident_info = $this->getMainGraphData();
             
			//dump_array($accident_info);

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
				
				if($this->filters['year'] == '2012' || $this->filters['year'] == 0){
			$current_bu_acc_count += (int) $accident_info[$business_units_stack_ele]['1'] + $accident_info[$business_units_stack_ele]['2'] + $accident_info[$business_units_stack_ele]['3'] + $accident_info[$business_units_stack_ele]['4'] + $accident_info[$business_units_stack_ele]['5'] + $accident_info[$business_units_stack_ele]['6'] + $accident_info[$business_units_stack_ele]['7'] + $accident_info[$business_units_stack_ele]['8'] + $accident_info[$business_units_stack_ele]['9'] + $accident_info[$business_units_stack_ele]['10'] + $accident_info[$business_units_stack_ele]['11'] + $accident_info[$business_units_stack_ele]['12'] + $accident_info[$business_units_stack_ele]['13'] + $accident_info[$business_units_stack_ele]['14'] + $accident_info[$business_units_stack_ele]['15'] + $accident_info[$business_units_stack_ele]['16'] + $accident_info[$business_units_stack_ele]['17'] + $accident_info[$business_units_stack_ele]['18'];
				}else{
				$current_bu_acc_count += (int) $accident_info[$business_units_stack_ele][$this->filters['year']];
				}
					//dump_array($accident_info[$this->filters['year']]);
					
				}

				if ( $this->filters['data_stat_type'] == 'rate' ) {
					$current_bu_acc_count = $this->getRateFromValue($current_bu_acc_count);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {
						//dump_array($business_units_stack_ele);
					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							if($this->filters['year'] == '2012' || $this->filters['year'] == 0){
							$current_childbu_acc_count += (int) $accident_info[$business_units_stack_ele]['1'] + $accident_info[$business_units_stack_ele]['2'] + $accident_info[$business_units_stack_ele]['3'] + $accident_info[$business_units_stack_ele]['4'] + $accident_info[$business_units_stack_ele]['5'] + $accident_info[$business_units_stack_ele]['6'] + $accident_info[$business_units_stack_ele]['7'] + $accident_info[$business_units_stack_ele]['8'] + $accident_info[$business_units_stack_ele]['9'] + $accident_info[$business_units_stack_ele]['10'] + $accident_info[$business_units_stack_ele]['11'] + $accident_info[$business_units_stack_ele]['12'] + $accident_info[$business_units_stack_ele]['13'] + $accident_info[$business_units_stack_ele]['14'] + $accident_info[$business_units_stack_ele]['15'] + $accident_info[$business_units_stack_ele]['16'] + $accident_info[$business_units_stack_ele]['17'] + $accident_info[$business_units_stack_ele]['18'];
							}else{
				$current_childbu_acc_count += (int) $accident_info[$business_units_stack_ele][$this->filters['year']];
				}
						}
					}

					if ( $this->filters['data_stat_type'] == 'rate' ) {
						$current_childbu_acc_count = $this->getRateFromValue($current_childbu_acc_count);
					}

					$child_arr[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->incidenceObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['incidenceDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->incidenceObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = array('bu_id'=>$id_val,
								  'key'=>$name_instuctor,
								  'value'=>$val_na);
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   // function removeElementWithValue($child_arr, $key, $value){
		   if($child_arr){
			
				foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
             
			//}

				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Total ".ucfirst($this->filters['data_stat_type'])." of accidents Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Tester Name';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$val_main)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

					//dump_array($this->data_set);

					
			
			}else{
			
			if($this->filters['name']['primaryHazard'] == ''){
			$this->filters['name']['primaryHazard'] = 'ALL';
			}
				
					//
			$graph_heading = $this->filters['bu_name'] == '' ? "Primary Source Graph" : $this->filters['bu_name']." - Primary Source Graph";
			$graph_heading .= ' for '.$this->filters['name']['primaryHazard'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Sources",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Sources",
						'yaxis_text'=>$yaxis_text,
						)
					);
				
			}
	

		

		} if ( $p_type == 'violence' ) {
		
           
			$accident_info = $this->getViolenceGraphData();
			
			//dump_array($accident_info);

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					if($this->filters['year'] == '2012' || $this->filters['year'] == 0){
			$current_bu_acc_count += (int) $accident_info[$business_units_stack_ele]['1'] + $accident_info[$business_units_stack_ele]['2'] + $accident_info[$business_units_stack_ele]['3'] + $accident_info[$business_units_stack_ele]['4'] + $accident_info[$business_units_stack_ele]['5'] + $accident_info[$business_units_stack_ele]['6'] + $accident_info[$business_units_stack_ele]['7'] + $accident_info[$business_units_stack_ele]['8'] + $accident_info[$business_units_stack_ele]['9'] + $accident_info[$business_units_stack_ele]['10'] + $accident_info[$business_units_stack_ele]['11'] + $accident_info[$business_units_stack_ele]['12'] + $accident_info[$business_units_stack_ele]['13'] + $accident_info[$business_units_stack_ele]['14'] + $accident_info[$business_units_stack_ele]['15'] + $accident_info[$business_units_stack_ele]['16'] + $accident_info[$business_units_stack_ele]['17'] + $accident_info[$business_units_stack_ele]['18'];
				}else{
				$current_bu_acc_count += (int) $accident_info[$business_units_stack_ele][$this->filters['year']];
				}
				}

				if ( $this->filters['data_stat_type'] == 'rate' ) {
					$current_bu_acc_count = $this->getRateFromValue($current_bu_acc_count);
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							if($this->filters['year'] == '2012' || $this->filters['year'] == 0){
							$current_childbu_acc_count += (int) $accident_info[$business_units_stack_ele]['1'] + $accident_info[$business_units_stack_ele]['2'] + $accident_info[$business_units_stack_ele]['3'] + $accident_info[$business_units_stack_ele]['4'] + $accident_info[$business_units_stack_ele]['5'] + $accident_info[$business_units_stack_ele]['6'] + $accident_info[$business_units_stack_ele]['7'] + $accident_info[$business_units_stack_ele]['8'] + $accident_info[$business_units_stack_ele]['9'] + $accident_info[$business_units_stack_ele]['10'] + $accident_info[$business_units_stack_ele]['11'] + $accident_info[$business_units_stack_ele]['12'] + $accident_info[$business_units_stack_ele]['13'] + $accident_info[$business_units_stack_ele]['14'] + $accident_info[$business_units_stack_ele]['15'] + $accident_info[$business_units_stack_ele]['16'] + $accident_info[$business_units_stack_ele]['17'] + $accident_info[$business_units_stack_ele]['18'];
							}else{
				$current_childbu_acc_count += (int) $accident_info[$business_units_stack_ele][$this->filters['year']];
				}
						}
					}

					if ( $this->filters['data_stat_type'] == 'rate' ) {
						$current_childbu_acc_count = $this->getRateFromValue($current_childbu_acc_count);
					}

					$child_arr[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			
			if($this->filters['name']['primaryHazard'] == ''){
			$this->filters['name']['primaryHazard'] = 'ALL';
			}
				
				$graph_heading = $this->filters['bu_name'] == '' ? "Secondary Source Graph" : $this->filters['bu_name']." - Secondary Source Graph";
			$graph_heading .= ' for '.$this->filters['name']['primaryHazard'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Sources",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Sources",
						'yaxis_text'=>$yaxis_text,
						)
					);

				
		
			//
			
		} else if ( $p_type == 'action' ) {
            //echo $this->filters['year'];
			$action_control = $this->getActionGraphData();
			$action_path = $this->getpathData();
			$action_source = $this->getsourceData();

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();
            
			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					if($this->filters['year'] == '2012'){
					$current_bu_acc_count += (int) $action_path[$business_units_stack_ele][''] + $action_control[$business_units_stack_ele][''] + $action_source[$business_units_stack_ele][''];
					}
					if($this->filters['year'] == '1'){
					$current_bu_acc_count += (int) $action_path[$business_units_stack_ele][''];
					}
					if($this->filters['year'] == '2'){
					$current_bu_acc_count += (int) $action_control[$business_units_stack_ele][''];
					}
					if($this->filters['year'] == '3'){
					$current_bu_acc_count += (int) $action_source[$business_units_stack_ele][''];
					}
					
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							if($this->filters['year'] == '2012'){
					$current_childbu_acc_count += (int) $action_path[$business_units_stack_ele][''] + $action_control[$business_units_stack_ele][''] + $action_source[$business_units_stack_ele][''];
					}
					if($this->filters['year'] == '1'){
					$current_childbu_acc_count += (int) $action_path[$business_units_stack_ele][''];
					}
					if($this->filters['year'] == '2'){
					$current_childbu_acc_count += (int) $action_control[$business_units_stack_ele][''];
					}
					if($this->filters['year'] == '3'){
					$current_childbu_acc_count += (int) $action_source[$business_units_stack_ele][''];
					}
							
						}
					}

					$child_arr[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
		if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->incidenceObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['incidenceDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->incidenceObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = array('bu_id'=>$id_val,
								  'key'=>$name_instuctor,
								  'value'=>$val_na);
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   if($child_arr){
			
			 	foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }

				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Control Graph" : $this->filters['bu_name']." - Control Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Tester Name';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$val_main)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

					//dump_array($this->data_set);

					
			
			}else{
			
			if($this->filters['year'] == '2012'){
				$this->filters['year'] = 'All';
			}
			if($this->filters['year'] == '1'){
				$this->filters['year'] = 'Along the path';
			}
			if($this->filters['year'] == '2'){
				$this->filters['year'] = 'At the worker';
			}
			if($this->filters['year'] == '3'){
				$this->filters['year'] = 'At the source';
			}
				
					$graph_heading = $this->filters['bu_name'] == '' ? "Control Graph" : $this->filters['bu_name']." - Control Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						)
					);
				
			}
			//
		
		} else if ( $p_type == 'accident_ontest' ) {
		

			$action_full_info = $this->getActionGraphData();
             $ac = $this->resultSet();
			 
			 $ac1 = $this->resultSet1();
			 $ac2 = $this->resultSet2();
			
			
			
				
			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();
            
			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					
					if ( $this->filters['year'] == '2012' || $this->filters['year'] == '0') {
					$current_bu_acc_count += (int) $ac[$business_units_stack_ele][''] +  $ac1[$business_units_stack_ele][''] +  $ac2[$business_units_stack_ele]['']; 
					}
					if ( $this->filters['year'] == '1' ) {
						$current_bu_acc_count += (int) $ac[$business_units_stack_ele][''];
					}
					if ( $this->filters['year'] == '2' ) {
						$current_bu_acc_count += (int) $ac1[$business_units_stack_ele][''];
					}
					if ( $this->filters['year'] == '3' ) {
						$current_bu_acc_count += (int) $ac2[$business_units_stack_ele][''];
					}
					
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
					if ( $this->filters['year'] == '2012' || $this->filters['year'] == '0') {
					$current_childbu_acc_count += (int) $ac[$business_units_stack_ele][''] +  $ac1[$business_units_stack_ele][''] +  $ac2[$business_units_stack_ele]['']; 
					}
					if ( $this->filters['year'] == '1' ) {
						$current_childbu_acc_count += (int) $ac[$business_units_stack_ele][''];
					}
					if ( $this->filters['year'] == '2' ) {
						$current_childbu_acc_count += (int) $ac1[$business_units_stack_ele][''];
					}
					if ( $this->filters['year'] == '3' ) {
						$current_childbu_acc_count += (int) $ac2[$business_units_stack_ele][''];
					}
					
							
						}
					}

					$child_arr[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}
			
			if($this->filters['bu_name'] == 'Tester'){
				
				$bu_id_val = $this->filters['bu'];
					$res = $this->incidenceObj->testerBUname();
					//dump_array($res);
					$val_main = 0;
					foreach($res  as $val){
						
                         //  dump_array($val);
						$id_val = $val['instructor'];
						$bu_val = $val['buId'];
						$date = $val['incidenceDateTime'];
						$year = substr($date,0,4);
						if($year ==  $this->filters['year']){
							if($bu_id_val == $bu_val){
							
							if($id_val != '0'){
							
							$result = $this->incidenceObj->participantNameBu($id_val);
							
						
						$participant_nameAU	 = $result['forename'].' '.$result['surname'];
						
						$val_name =(int) count($participant_nameAU);
						
						if($participant_nameAU == $name_instuctor){
							$val_na = $val_name+1;
							$name_instuctor = $participant_nameAU;

							
						}else{
							$val_na = $val_name;
							$name_instuctor = $participant_nameAU;

				
								
						}
						
						$child_arr[] = array('bu_id'=>$id_val,
								  'key'=>$name_instuctor,
								  'value'=>$val_na);
						}
							
						}
							
						}
						
						//echo $val_main;
						
					}
			$val_main = count($child_arr);
			//dump_array($child_arr);
		   if($child_arr){
			
				foreach ($child_arr as $key1 => $value1){
					foreach ($child_arr as $key2 => $value2){
						//echo $child_arr[$key1]['key'];
						//$child_arr[$key2]['key'];
							if($child_arr[$key1]['bu_id'] == $child_arr[$key2]['bu_id'] && $key1 != $key2){
								//echo "sdfdfssdf";
								
								unset($child_arr[$key1]);
								
						}
					}
					//dump_array($child_arr);
				}
			
		   }
				
			
			
			$graph_heading = $this->filters['bu_name'] == '' ? "Accidents on Test ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Accidents ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'].'-'.$this->filters['type'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Tester Name';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$val_main)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>ucfirst($this->filters['data_stat_type'])." of Accidents",
						'yaxis_text'=>$yaxis_text,
						)
					);

					//dump_array($this->data_set);

					
			
			}else{
			if($this->filters['year'] == '2012'){
				$this->filters['year'] = 'All';
			}
			if($this->filters['year'] == '1'){
				$this->filters['year'] = 'Along the path';
			}
			if($this->filters['year'] == '2'){
				$this->filters['year'] = 'At the worker';
			}
			if($this->filters['year'] == '3'){
				$this->filters['year'] = 'At the source';
			}
				$graph_heading = $this->filters['bu_name'] == '' ? "Improvement Graph" : $this->filters['bu_name']." - Improvement Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						)
					);
				
				
			}

		
		} 
		
		else if ( $p_type == 'accident_butest' ) {
		//echo "sdfsfsdf";
				$action_full_info = $this->getActionGraphData();
             $ac = $this->resultSetBU();
			 $data = $this->resultSelectBU();
			//dump_array($ac['all']);
			
			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();
            
			$current_bu_acc_count = 0;

			if ( count($data) ) {
			 
				foreach ( $data as $value ) {
				
				if($this->filters['t_month'] == 'a'){
					if ( $this->filters['type_bu'] == 'all' ) {
					$current_bu_acc_count_1 += (int) $ac['all'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'rsa' ) {
					$current_bu_acc_count_1 += (int) $ac['rsa'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'public' ) {
					$current_bu_acc_count_1 += (int) $ac['public'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'roadside' ) {
					$current_bu_acc_count_1 += (int) $ac['roadside'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'other' ) {
					$current_bu_acc_count_1 += (int) $ac['other'][$value['buName']][$this->filters['year']][$value['buID']];
					}
				}else{
				if ( $this->filters['type_bu'] == 'all' ) {
					$current_bu_acc_count_1 += (int) $ac['all'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'rsa' ) {
					$current_bu_acc_count_1 += (int) $ac['rsa'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'public' ) {
					$current_bu_acc_count_1 += (int) $ac['public'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'roadside' ) {
					$current_bu_acc_count_1 += (int) $ac['roadside'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				if ( $this->filters['type_bu'] == 'other' ) {
					$current_bu_acc_count_1 += (int) $ac['other'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
					}
				
				}
		
				
				}
			
				
			}
		
			$child_arr_A['0'] = array(
									'bu_id'=>'4',
								  'key'=>'Standards and Enforcement',
								  'value'=>$current_bu_acc_count_1);
			$child_arr_A['1'] = array(
									'bu_id'=>'3',
								  'key'=>'Completed',
								  'value'=>$current_bu_acc_count_2);
		   


			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			//if ( count($child_business_units) ) {
			//	foreach ( $child_business_units as $child_business_unit_ele ) {

					//if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
					//	continue;
					//}

					//$business_units_stack = array();

					//$this->organigramObj->clearStack();
					//$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					//$this->organigramObj->setItemInfo(array(
					//									'id'=>$child_business_unit_ele['buID']));
					//$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					//$business_units_stack = $this->organigramObj->getStack();

					

					if ( count($data) ) {
						foreach ( $data as $value ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count = 0;
							if($this->filters['t_month'] == 'a'){
							if ( $this->filters['type_bu'] == 'all' ) {
							$current_childbu_acc_count += (int) $ac['all'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'rsa' ) {
							$current_childbu_acc_count += (int) $ac['rsa'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'public' ) {
							$current_childbu_acc_count += (int) $ac['public'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'other' ) {
							$current_childbu_acc_count += (int) $ac['other'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'roadside' ) {
							$current_childbu_acc_count += (int) $ac['roadside'][$value['buName']][$this->filters['year']][$value['buID']];
							}
							
							}else{
							if ( $this->filters['type_bu'] == 'all' ) {
							$current_childbu_acc_count += (int) $ac['all'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'rsa' ) {
							$current_childbu_acc_count += (int) $ac['rsa'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'public' ) {
							$current_childbu_acc_count += (int) $ac['public'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'other' ) {
							$current_childbu_acc_count += (int) $ac['other'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							if ( $this->filters['type_bu'] == 'roadside' ) {
							$current_childbu_acc_count += (int) $ac['roadside'][$this->filters['t_month']][$value['buName']][$this->filters['year']][$value['buID']];
							}
							
							}
							
							$child_arr[] = array('bu_id'=>$value['buID'],
								  'key'=>$value['buName'],
								  'value'=>$current_childbu_acc_count);
						}
					}

					
				//}
			//}
		
				$graph_heading = $this->filters['bu_name'] == '' ? "Accidents on Test ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Action ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'].'-'.ucfirst($this->filters['type_bu']);

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>'',
											'value'=>$current_bu_acc_count_1)
									
											
								),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Participants',
						'yaxis_text'=>$yaxis_text,
						)
					);
				
				
			
		
		}

		else if ( $p_type == 'accident_bypublic' ) {

			$accident_info = $this->getAccidentPublicGraphData();

			//dump_array($accident_info);

			$this->organigramObj->clearStack();
			$this->organigramObj->getBusinessUnitHierarchy($current_bu_id);
			$business_units_stack = $this->organigramObj->getStack();


			$current_bu_acc_count = 0;

			if ( count($business_units_stack) ) {
				foreach ( $business_units_stack as $business_units_stack_ele ) {
					//dump_array($accident_info[$this->filters['year']]);
					$current_bu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
				}
			}

			$child_array = array();
			$exclude_bus_arr = explode(',',$this->filters['exclude']);

			// for child business units
			if ( count($child_business_units) ) {
				foreach ( $child_business_units as $child_business_unit_ele ) {

					if ( in_array($child_business_unit_ele['buID'],$exclude_bus_arr) ) {
						continue;
					}

					$business_units_stack = array();

					$this->organigramObj->clearStack();
					$this->organigramObj->getBusinessUnitHierarchy($child_business_unit_ele['buID']);

					$this->organigramObj->setItemInfo(array(
														'id'=>$child_business_unit_ele['buID']));
					$bu_info = $this->organigramObj->displayItemByIdForMSR();
					//echo $child_business_unit_ele['buID']."-".$bu_info['buName']."<br/>";
					$business_units_stack = $this->organigramObj->getStack();

					$current_childbu_acc_count = 0;

					if ( count($business_units_stack) ) {
						foreach ( $business_units_stack as $business_units_stack_ele ) {
							//dump_array($accident_info[$this->filters['year']]);
							$current_childbu_acc_count += (int) $accident_info[$this->filters['year']][$business_units_stack_ele];
						}
					}

					$child_arr[] = array('bu_id'=>$child_business_unit_ele['buID'],
								  'key'=>$bu_info['buName'],
								  'value'=>$current_childbu_acc_count);
				}
			}

			//
			$graph_heading = $this->filters['bu_name'] == '' ? "Accident by Public ".ucfirst($this->filters['data_stat_type'])." Graph" : $this->filters['bu_name']." - Accident by Public ".ucfirst($this->filters['data_stat_type'])." Graph";
			$graph_heading .= ' for '.$this->filters['year'];

			$yaxis_text = $this->filters['bu'] == 0 ? 'Company' : 'Business Units';

			$this->data_set = array(
					'main_graph'=>array(
						'chart_data'=>array(
											0=>array('bu_id'=>$current_bu_id,
											'key'=>$current_bu_info['buName'],
											'value'=>$current_bu_acc_count)
								),
						'heading'=>$graph_heading,
						'yaxis_text'=>'Number of accidents',
						'xaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'yaxis_text'=>'Number of accidents',
						'xaxis_text'=>$yaxis_text,
						)
					);

		} // end $p_type == 'accident_bypublic'
	}

	private function getMainGraphData() {

		return $this->incidenceObj->primaryHazard();
	}

	private function getViolenceGraphData() {

		return $this->incidenceObj->secondaryHazard();
	}

	private function getParticipantGraphData() {

		return $this->incidenceObj->getNoOfParticipants();
	}

	private function getActivityGraphData() {

		return $this->incidenceObj->getNoOfActivities();
	}

	private function getActionGraphData() {

		return $this->incidenceObj->controlData();
	}
	
	private function getpathData() {

		return $this->incidenceObj->pathData();
	}
	private function getsourceData() {

		return $this->incidenceObj->sourceData();
	}

	private function getAccidentTestGraphData() {

		$this->incidenceObj->getInstructorGraphData();
	}

	private function getAccidentPublicGraphData() {

		return $this->incidenceObj->getAccidentPublicGraphData();
	}
	private function resultSet() {

		return $this->incidenceObj->impData();
	}
	private function resultSet1() {

		return $this->incidenceObj->impData1();
	}
	private function resultSet2() {

		return $this->incidenceObj->impData2();
	}
	
	private function resultSetBU() {

		return $this->incidenceObj->getAccidetBuTest();
	}

	
	private function resultSelectBU() {

		return $this->incidenceObj->getSelectedBu();
	}

	public function exportGraphData() {

		return $this->data_set;
	}
}
?>