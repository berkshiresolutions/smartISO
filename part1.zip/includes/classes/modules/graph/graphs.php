<?php
 /**
  $Id: graphs.php,v 3.07 Thursday, January 20, 2011 3:05:59 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used to convert the data in graph formats
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Graphs
  * @since  Tuesday, September 28, 2010 6:13:18 PM>
  */
class Graphs {

	public $xml_data_file;
	public $graph_height;
	public $graph_width;
	public $graph_settings_file;
	private $graph_parameter;

	public function __construct($p_type,$p_module,$p_graph_data,$p_sub_type='',$p_graph_modulesub_type='') {

		$class = ucwords($p_type)."Graph";

		require_once $class.'.class.php';

		$this->gtype = new $class($p_module,$p_graph_data,$p_sub_type,$p_graph_modulesub_type);
		$this->gtype->convertToXml();
		$this->graph_parameter = $this->gtype->getData();

		$this->xml_data_file        = $this->graph_parameter['xml_file_name'];
		$this->graph_height         = $this->graph_parameter['graph_height'];
		$this->graph_width          = $this->graph_parameter['graph_width'];
		$this->graph_settings_file  = $this->graph_parameter['graph_settings'];
	}

	public function getGraphType() {
		return $this->graph_parameter['graph_swf_file'];;
	}
}
?>