<?php
 /**
  $Id: audit.php,v 3.15 Monday, January 31, 2011 4:05:50 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @since  Friday, November 26, 2010 5:31:01 PM>
  */

    require_once "GraphModuleData.int.php";
    require_once "GraphData.abs.php";

    class ReviewGraph implements GraphModuleData {

        public $filter_query,$filters,$data_set;
		private $dbHand;
		private $optionObj;
		private $departments7;
		private $temprecords;

        public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
			$this->optionObj = new Option();
            $this->data_format = new GraphData();

        }

		public function setFilter($p_filter_fields) {

			$this->filters = $p_filter_fields;

			if ( $this->filters['department'] ) {
                $this->filter_query = "WHERE id = ".$this->filters['id'];
            }
        }

		/* number of questions done */
        private function resultSet() {

			global $question;

			if ( $this->filters['exu_arr'] != '' ) {
				$exu_arr = explode(",",$this->filters['exu_arr']);
			} else {
				$exu_arr = null;
			}

			$standard = $this->filters['std_id'] == '' ? 52 : $this->filters['std_id'];

            $sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE standardID = 52 AND reviewID = %d ",_DB_OBJ_FULL,$this->filters['review_id']);
			$pStatement_rev = $this->dbHand->prepare($sql_rev);
			//$pStatement_rev->bindParam(1,$this->filters['review_id'],PDO::PARAM_INT);
			$pStatement_rev->execute();

			$records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);
			if ( count($records_rev) ) {

				foreach ( $records_rev as $value ) {
					$answers[$value['questionID']] = $value;
				}
			}
			
            $sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE standardID = %d AND reviewID = %d ",_DB_OBJ_FULL,$standard,$this->filters['review_id']);
			$pStatement_rev = $this->dbHand->prepare($sql_rev);
			//$pStatement_rev->bindParam(1,$this->filters['review_id'],PDO::PARAM_INT);
			$pStatement_rev->execute();

			$records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);
			if ( count($records_rev) ) {

				foreach ( $records_rev as $value ) {
					$answers[$value['questionID']] = $value;
				}
			}
			//dump_array($answers);

			$sql = sprintf("SELECT * FROM %s.msr_departments WHERE sID = %d ORDER BY ID",_DB_OBJ_FULL,$standard);
			$pStatement = $this->dbHand->prepare($sql);
			//$pStatement->bindParam(1,$standard,PDO::PARAM_INT);
			$pStatement->execute();
			$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);
			//dump_array($records);


			if ( $standard != 10 ) {
				$question['Key Questions']['answered_score'] = 0;
				$question['Key Questions']['actual_score'] = 0;
			}


			if (count($records) ) {
				foreach ( $records as $value ) {

					if ( $standard == 7 ) {

						$main_dep = $value['code'];
						$str = $value['code'].'%';
						$sql2 = sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = %d ",_DB_OBJ_FULL,$standard);
						$sql2 = $sql2." AND code LIKE '".$str."' ORDER BY questionID ASC";
					} else {

						$main_dep = $value['code'];
						$str = $value['code'];
						$sql2 = sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = %d AND code = '%s' ORDER BY questionID ASC",_DB_OBJ_FULL,$standard,$str);
					}

					$codes_name[$value['code']] = str_replace("OH&S","OH&amp;S",$value['name']);


					$pStatement2 = $this->dbHand->prepare($sql2);

					$pStatement2->execute();
					$records2 = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

					//dump_array($pStatement2->errorInfo());

					//dump_array($records2);

					if ( $standard == 2 || $standard == 4 ) {

						$main_dep_arr = explode('.',$main_dep);
						$main_dep = $main_dep_arr[0].'.'.$main_dep_arr[1];
						//$main_dep = $codes_name[$main_dep].' - '.$main_dep;
						$main_dep = $codes_name[$main_dep];

					} else {

						$main_dep_arr = explode('.',$main_dep);
						$main_dep = $main_dep_arr[0];

						$main_dep = $codes_name[$main_dep];
					}





					if ( count($records2) ) {

						/*echo $sql3 = "SELECT * FROM review_questions WHERE ID = ".$valueQues['questionID']." ORDER BY ID ASC";
						echo "<br>";*/

						$sql3 = "SELECT * FROM %s.review_questions WHERE ID = %d ORDER BY ID ASC";


						foreach ( $records2 as $valueQues ) {

							$sql3_p = sprintf($sql3,_DB_OBJ_FULL,$valueQues['questionID']);
							//echo "<br/>";
							$pStatement3 = $this->dbHand->prepare($sql3_p);

							$pStatement3->execute();
							$records3 = $pStatement3->fetchAll(PDO::FETCH_ASSOC);

							if ( !count($records3) ) {
								continue;
							}


							$question_id = $records3[0]['ID'];

							$answer = $answers[$question_id]['answer'] == '' ? '0' : $answers[$question_id]['answer'];
							$answer = $answer == 'NA' ? '0' : $answer;
							$answer = $answer == 'na' ? '0' : $answer;


							switch($answer) {
								case 0 : $option = 1; break;
								case 20 : $option = 2; break;
								case 80 : $option = 3; break;
								case 100 : $option = 4; break;
							}

							$option_score =  $this->optionObj->getOption('_SU_REVIEW_OPTION'.$option.'_PERCENT');

							$score = ($records3[0]['score']*$option_score)/100;

							//echo $records3[0]['score'].' - '.$option_score.'-'.$score.'<br/>';

							$flag_check = 1;
							/*if ( $standard == 9 ) {
								$flag_check = 2;
							}*/

							if ( $records3[0]['isStowContractor'] == $flag_check ) {

								$question['Key Questions']['answered_score'] += $score;
								$question['Key Questions']['actual_score'] += $records3[0]['score'];

							} else {

								$question[$main_dep]['answered_score'] += $score;
								$question[$main_dep]['actual_score'] += $records3[0]['score'];
							}

						}
						//dump_array($question);
					}

				}

				//dump_array($question);
				//return $question;
			}


			if ( count($question) ) {
				foreach ( $question as $key=>$value ) {

					if ( $exu_arr != null && in_array($key,$exu_arr) ) {
						continue;
					}

					//echo $value['answered_score'].'-'.$value['actual_score'].'<br/>';
					$percentage = number_format((($value['answered_score']*100)/$value['actual_score']),0);
					$this->data_format->addData($key,$percentage);
				}
			}


			$this->data_format->getGraphData();

			$this->data_set['chart_data'][] = $this->data_format->graph_data;
			$this->data_set['heading'] = $this->filters['heading'];
			$this->data_set['xaxis_text'] = "Sections";
			$this->data_set['yaxis_text'] = "Questions";

        }

		/* number of questions done */
        private function resultSetMse() {

			global $question;

            $sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE reviewID = %d ",_DB_OBJ_FULL,$this->filters['review_id']);
			$pStatement_rev = $this->dbHand->prepare($sql_rev);

			$pStatement_rev->execute();

			$records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);
			$answered_questions = (int) count($records_rev);

			$sql = sprintf("SELECT questions FROM %s.review_master WHERE reviewID = %d ",_DB_OBJ_FULL,$this->filters['review_id']);
			$pStatement1 = $this->dbHand->prepare($sql);

			$pStatement1->execute();

			$total_questions = $pStatement1->fetchColumn();
			$total_questions_arr = explode(',',$total_questions);

			$total_questions_count = count($total_questions_arr);

			$percentage = number_format((($answered_questions*100)/$total_questions_count),0);
			$this->data_format->addData('Questions Done',$percentage);


			$this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = 'MSE';
			$this->data_set['yaxis_text'] = "";

        }
		
		private function resultSetTrend1() {

			// 188
			$this->TempTrend();

			global $question;

			$sql_master = sprintf("SELECT * FROM %s.review_master",_DB_OBJ_FULL);
			$sql_master = $sql_master." WHERE is_complete='1' AND reviewType LIKE 'MSR%'";

			$pStatement_master = $this->dbHand->prepare($sql_master);

			$pStatement_master->execute();
			$records_master = $pStatement_master->fetchAll(PDO::FETCH_ASSOC);

			if ( count($records_master) ) {
				foreach ( $records_master as $masterValue ) {

					$end_date = $masterValue['endTime'];
					$endyear = substr($end_date,0,4);

					if ( $endyear == '1900' || $endyear == '0000' ) {
						continue;
					}

					$start_date = $masterValue['startTime'];
					$year = substr($start_date,0,4);

					$review_id = $masterValue['reviewID'];

					$data = $this->resultSetTemp($review_id);

					$trend_data[$year]['Organization'][]		 = $data['Organization'];
					$trend_data[$year]['Risk Management'][] 	 = $data['Risk Management'];
					$trend_data[$year]['Training'][]			 = $data['Training'];
					$trend_data[$year]['Inspection'][]			 = $data['Inspection'];
					$trend_data[$year]['Non Conformance'][]		 = $data['Non Conformance'];
					$trend_data[$year]['Emergency'][]			 = $data['Emergency'];
					$trend_data[$year]['Health'][]				 = $data['Health'];
					$trend_data[$year]['Design and Purchasing'][] = $data['Design and Purchasing'];

				}
			}


			$all_data = '';
			//dump_aarray($trend_data);
			//exit;
			if ( count($trend_data) ) {
				foreach ( $trend_data as $keyYear=>$valueyear) {
				
				//dump_array($valueyear);

					//echo $keyYear;
					$data = '';

					$data[] = $keyYear;

					if ( count ($valueyear) ) {
						foreach ( $valueyear as $finalKey=>$finalCount ) {
					$total_average_score = number_format(array_sum($finalCount)/count($finalCount),0);
							//echo $finalKey.'-------'.$total_average_score;
							//$data[] = $finalKey;
							
							$data[$finalKey] = $total_average_score;
							//$data[] = ;
							
							//if($keyYear['Organization'] == 'Organization'){
							$data_new[$keyYear][$finalKey] = $total_average_score;
							//}
							
						}
					}
					$this->data_format->addDataMultiple1($data);
				}

				//ksort($data_new);
			}

		/*	if ( count ( $data_new) ) {
				foreach ( $data_new as $year=>$values ) {
					$data_array_temp = array();
					$data_array_temp[] = $year;

					if ( count($values) ) {
						foreach ( $values as $val ) {
							$data_array_temp[] = $val;
						}
					}

					//$this->data_format->addDataMultiple($data_array_temp);
				}
			}*/

			$this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = 'MSR Trend Graph';
			$this->data_set['yaxis_text'] = "";
		}

		private function resultSetTrend() {

			// 188
			$this->TempTrend();

			global $question;

			$sql_master = sprintf("SELECT * FROM %s.review_master",_DB_OBJ_FULL);
			$sql_master = $sql_master." WHERE is_complete='1' AND reviewType LIKE 'MSR%'";

			$pStatement_master = $this->dbHand->prepare($sql_master);

			$pStatement_master->execute();
			$records_master = $pStatement_master->fetchAll(PDO::FETCH_ASSOC);

			if ( count($records_master) ) {
				foreach ( $records_master as $masterValue ) {

					$end_date = $masterValue['endTime'];
					$endyear = substr($end_date,0,4);

					if ( $endyear == '1900' || $endyear == '0000' ) {
						continue;
					}

					$start_date = $masterValue['startTime'];
					$year = substr($start_date,0,4);

					$review_id = $masterValue['reviewID'];

					$data = $this->resultSetTemp($review_id);

					$trend_data[$year]['Organization'][]		 = $data['Organization'];
					$trend_data[$year]['Risk Management'][] 	 = $data['Risk Management'];
					$trend_data[$year]['Training'][]			 = $data['Training'];
					$trend_data[$year]['Inspection'][]			 = $data['Inspection'];
					$trend_data[$year]['Non Conformance'][]		 = $data['Non Conformance'];
					$trend_data[$year]['Emergency'][]			 = $data['Emergency'];
					$trend_data[$year]['Health'][]				 = $data['Health'];
					$trend_data[$year]['Design and Purchasing'][] = $data['Design and Purchasing'];

				}
			}


			$all_data = '';
			//dump_aarray($trend_data);
			//exit;
			if ( count($trend_data) ) {
				foreach ( $trend_data as $keyYear=>$valueyear) {
				
				//dump_array($valueyear);

					//echo $keyYear;
					$data = '';

					$data[] = $keyYear;

					/*if ( count ($valueyear) ) {
						foreach ( $valueyear as $finalKey=>$finalCount ) {
					$total_average_score = @number_format(array_sum($finalCount)/count($finalCount),0);
							echo $finalKey.'-------'.$total_average_score;
							//$data[] = $finalKey;
							
							$data[$finalKey][] = $total_average_score;
							//$data[] = ;
							
							//if($keyYear['Organization'] == 'Organization'){
							$data_new[$keyYear][$finalKey] = $total_average_score;
							//}
							
						}
					}*/
					$this->data_format->addDataMultiple($valueyear);
				}

				//ksort($data_new);
			}

		/*	if ( count ( $data_new) ) {
				foreach ( $data_new as $year=>$values ) {
					$data_array_temp = array();
					$data_array_temp[] = $year;

					if ( count($values) ) {
						foreach ( $values as $val ) {
							$data_array_temp[] = $val;
						}
					}

					//$this->data_format->addDataMultiple($data_array_temp);
				}
			}*/

			$this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = 'MSR Trend Graph';
			$this->data_set['yaxis_text'] = "";
		}

		private function TempTrend() {

			$sql = sprintf("SELECT * FROM %s.msr_departments WHERE sID = 7 ORDER BY ID",_DB_OBJ_FULL);
			$pStatement = $this->dbHand->prepare($sql);

			$pStatement->execute();
			$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

			if (count($records) ) {
				$i = 0;
				foreach ( $records as $value ) {



					$main_dep = $value['code'];
					$str = $value['code'].'%';
					$sql2 = sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = 7 ",_DB_OBJ_FULL);
					$sql2 = $sql2." AND code LIKE '".$str."' ORDER BY questionID ASC";


					$codes_name[$value['code']] = str_replace("OH&S","OH&amp;S",$value['name']);


					$pStatement2 = $this->dbHand->prepare($sql2);

					$pStatement2->execute();
					$records2[$i] = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

					$main_dep_arr = explode('.',$main_dep);
					$main_dep = trim($main_dep_arr[0],' ');

					$main_dep_full[$i] = $codes_name[$main_dep];

					$i++;
				}
			}

			//dump_array_and_exit($main_dep);

			$this->departments7 = $main_dep_full;
			$this->temprecords = $records2;
		}

		/* number of questions done */
        private function resultSetTemp($p_review_id) {

			global $question;

            $sql_rev = sprintf("SELECT * FROM %s.review_answers WHERE reviewID = %d ",_DB_OBJ_FULL,$p_review_id);
			$pStatement_rev = $this->dbHand->prepare($sql_rev);

			$pStatement_rev->execute();

			$records_rev = $pStatement_rev->fetchAll(PDO::FETCH_ASSOC);
			if ( count($records_rev) ) {

				foreach ( $records_rev as $value ) {
					$answers[$value['questionID']] = $value;
				}
			}
			//dump_array($answers);

			$standard = 7;

				$question['Key Questions']['answered_score'] = 0;
				$question['Key Questions']['actual_score'] = 0;

			$records = $this->temprecords;


			/*if (count($records) ) {
				foreach ( $records as $value ) {



					$main_dep = $value['code'];
					$str = $value['code'].'%';
					$sql2 = sprintf("SELECT * FROM %s.review_question_metadata WHERE standardID = %d ",_DB_OBJ_FULL,$standard);
					$sql2 = $sql2." AND code LIKE '".$str."' ORDER BY questionID ASC";


					$codes_name[$value['code']] = str_replace("OH&S","OH&amp;S",$value['name']);;


					$pStatement2 = $this->dbHand->prepare($sql2);

					$pStatement2->execute();
					$records2 = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

					$main_dep_arr = explode('.',$main_dep);
					$main_dep = $main_dep_arr[0];

					$main_dep = $codes_name[$main_dep];*/

					$records_all = $this->temprecords;
					$dep_all = $this->departments7;

			if ( count($records_all) ) {
				foreach ( $records_all as $key=>$valuetemp ) {

					$records2 = $valuetemp;
					$main_dep = $dep_all[$key];
					//dump_array($main_dep);
					//exit;


					if ( count($records2) ) {

						/*echo $sql3 = "SELECT * FROM review_questions WHERE ID = ".$valueQues['questionID']." ORDER BY ID ASC";
						echo "<br>";*/

						$sql3 = "SELECT * FROM %s.review_questions WHERE ID = %d ORDER BY ID ASC";


						foreach ( $records2 as $valueQues ) {

							$sql3_p = sprintf($sql3,_DB_OBJ_FULL,$valueQues['questionID']);
							//echo "<br/>";
							$pStatement3 = $this->dbHand->prepare($sql3_p);

							$pStatement3->execute();
							$records3 = $pStatement3->fetchAll(PDO::FETCH_ASSOC);


							$question_id = $records3[0]['ID'];

							$answer = $answers[$question_id]['answer'] == '' ? '0' : $answers[$question_id]['answer'];
							$answer = $answer == 'NA' ? '0' : $answer;
								$answer = $answer == 'na' ? '0' : $answer;

							switch($answer) {
								case 0 : $option = 1; break;
								case 20 : $option = 2; break;
								case 80 : $option = 3; break;
								case 100 : $option = 4; break;
							}

							$option_score =  $this->optionObj->getOption('_SU_REVIEW_OPTION'.$option.'_PERCENT');

							$score = ($records3[0]['score']*$option_score)/100;

							//echo $records3[0]['score'].' - '.$option_score.'-'.$score.'<br/>';

							$flag_check = 1;
							/*if ( $standard == 9 ) {
								$flag_check = 2;
							}*/

							if ( $records3[0]['isStowContractor'] == $flag_check ) {

								$question['Key Questions']['answered_score'] += $score;
								$question['Key Questions']['actual_score'] += $records3[0]['score'];

							} else {

								$question[$main_dep]['answered_score'] += $score;
								$question[$main_dep]['actual_score'] += $records3[0]['score'];
							}

						}
						//dump_array($question);
					}
				}
			}




				//return $question;



			if ( count($question) ) {
				foreach ( $question as $key=>$value ) {

					//echo $value['answered_score'].'-'.$value['actual_score'].'<br/>';
					$percentage = number_format((($value['answered_score']*100)/$value['actual_score']),0);

					$return_data[$key] = $percentage;
					//$this->data_format->addData($key,$percentage);
				}
			}
			//dump_array($return_data);
			//	exit;

			return $return_data;

        }


		/* to export data*/
		public function exportGraphData() {

			if ( $this->filters['type'] == '' ) {
				$this->resultSet();
			} else {
				$dynFxn = "resultSet".$this->filters['type'];
				$this->$dynFxn();
			}
            //dump_array($this->data_set);
			return $this->data_set;
		}
    }
?>