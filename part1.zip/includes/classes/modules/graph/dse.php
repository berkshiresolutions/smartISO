<?php
 /**
  $Id: dse.php,v 3.08 Wednesday, January 19, 2011 11:29:21 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage NHP GRaph
  * @since  Thursday, December 02, 2010 12:19:49 PM>
  */
    require_once "GraphModuleData.int.php";
    require_once "GraphData.abs.php";

    class DseGraph extends DseAssessment implements GraphModuleData
	{

        private $filter_query;
        private $filters;
        public $data_set;

        public function __construct($filter_fields) {
            $this->filters = $filter_fields;
            $this->setFilter();
			$this->data_format = new GraphData();

			parent::__construct();

			$this->dse_tabs_section_data = array(
							  1=>array(0,1,2,3,4,5,6,7,8),
							  2=>array(0,1,2,3,4,5,6,7),
							  3=>array(8,9,10,11,12),
							  4=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13),
							  5=>array(0,1,2),
							  6=>array(3,4,5),
							  7=>array(0,1,2,3),
							  8=>array(4,5),
							  9=>array(6,7,8,9),
							  10=>array(0,1,2,3,4,5,6,7),
							  11=>array(0,1,2),
							  12=>array(3),
							  13=>array(4,5,6,7,8,9),
							  14=>array(0,1,2),
							  15=>array(3,4,5),
							  16=>array(6,7,8));
        }

		/* to set the filetrs for search */
        public function setFilter() {

            if ( $this->filters['graph_type'] ) {
                $this->filter_query = "AND Gtype = ".$this->filters['graph_type'];
            }
        }

		/* dse sections graph data set*/
        private function resultSet() {

			global $dse_assessment_tabs;
			global $dse_assessment_section_listing;
			$selected_section = "";

			$dse_text_graph = $dse_assessment_tabs;

			$data = $this->getDseGraphData();

			$selected_section = $this->filters['graph_type'] == '' ? 0 : $this->filters['graph_type'];

			if ( $selected_section ) {

				$selected_section_arr = explode('_',$selected_section);
				$selected_section = $selected_section_arr[0];
				$sub_section = $selected_section_arr[1];

				$data = $data[$selected_section];

				$dse_text_graph = $dse_assessment_section_listing[$selected_section-1];

				if ( count($data) ) {

					foreach ( $data as $key=>$value ) {
						$section = $key; // question id

						if ( in_array($key,$this->dse_tabs_section_data[$sub_section]) ) {

							$graph_data_array[$section]['yes'] += (int) $value['yes'];
							$graph_data_array[$section]['no'] += (int) $value['no'];
							$graph_data_array[$section]['na'] += (int) $value['na'];

						}


					}
				}

				$heading = "DSE ".$dse_assessment_tabs[$selected_section]." Assessments";

			} else {

				if ( count($data) ) {
					foreach ( $data as $key=>$value ) {
						$section = $key;

						$graph_data_array[$section]['yes'] = 0;
						$graph_data_array[$section]['no'] = 0;
						$graph_data_array[$section]['na'] = 0;


						if ( count($value) ) {
							foreach ( $value as $keyAns=>$valueAns ) {

									$graph_data_array[$section]['yes'] += $valueAns['yes'];
									$graph_data_array[$section]['no'] += $valueAns['no'];
									$graph_data_array[$section]['na'] += $valueAns['na'];

							}
						}

					}
				}

				$heading = "DSE Assessments";

			}

			//dump_array($data);

			//dump_array($graph_data_array);

			$new_arr = array_reverse($graph_data_array,true);

            $sql_query = "".$this->filter_query ;

            $depts = array('Yes','No','NA');
			$i=2;
			if ( count($new_arr) ) {
				foreach($new_arr as $keyid=>$val) {
					$data_arr = array($dse_text_graph[$keyid],$val['yes'],$val['no'],$val['na']);
					$this->data_format->addDataMultiple($data_arr);
				}
			}


            $this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = $heading;
			$this->data_set['xaxis_text'] = "Number of Selections";
			$this->data_set['xaxis_labels'] = $depts;
        }

		/* process graph data set*/
        private function resultSetProcess() {

			$dse_data = $this->getDseProcessGraphData();
			if ( count($dse_data) ) {
				foreach ( $dse_data as $value ) {
					$done += (int) $value;
				}
			}

			$riskObj = new RiskAssessment();
			$risk_data = $riskObj->getRiskRecordsDse();

			if ( count($risk_data) ) {
				foreach ( $risk_data as $value ) {
					$total += (int) $value;
				}
			}

			//dump_array($risk_data);

			$this->data_format->addDataPieLink(array('Total','?type=total',$total));
			$this->data_format->addDataPieLink(array('Done','?type=done',$done));

            $this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = "DSE Assessments";
			$this->data_set['xaxis_text'] = "Number of Process";
			$this->data_set['xaxis_labels'] = $depts;
        }

		private function resultSetProcessSpecific() {
			$graph_type = $this->filters['graph_type'];

			if ( $graph_type == 'done' ) {

				$graph_data = $this->getDseProcessGraphData();

			} else {

				$riskObj = new RiskAssessment();
				$graph_data = $riskObj->getRiskRecordsDse();

			}

			$objProcessMaster 	= new ProcessFlowMaster();


			if ( count($graph_data) ) {
				foreach ( $graph_data as $key=>$value ) {
					$process_data = $objProcessMaster->displayProcessFlowById($key);

					//dump_array($process_data);
					$this->data_format->addData($process_data['reference'],$value);
				}
			}

		//	dump_array($graph_data);

			$this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = ucwords($graph_type)." DSE Assessments";
			$this->data_set['yaxis_text'] = "Processes";
			$this->data_set['xaxis_text'] = "Number of Assessments";
		}

		/* process graph data set*/
        private function resultSetProcessPie() {

			$dse_data = $this->getDseProcessGraphData();
			if ( count($dse_data) ) {
				foreach ( $dse_data as $value ) {
					$done += (int) $value;
				}
			}

			$riskObj = new RiskAssessment();
			$risk_data = $riskObj->getRiskRecordsDse();

			if ( count($risk_data) ) {
				foreach ( $risk_data as $value ) {
					$total += (int) $value;
				}
			}

			//dump_array($risk_data);

			$this->data_format->addDataPieLink(array('Total','?type=total',$total));
			$this->data_format->addDataPieLink(array('Done','?type=done',$done));

            $this->data_format->getGraphData();

			$this->data_set['chart_data'] = $this->data_format->graph_data;
			$this->data_set['heading'] = "DSE Assessments";
			$this->data_set['xaxis_text'] = "Number of Process";
			$this->data_set['xaxis_labels'] = $depts;
        }

		/* to export data*/
		public function exportGraphData($p_type='') {

			if ( !empty($p_type) ) {

				$method = "resultSet".ucwords($p_type);
				$this->$method();
			} else {
				$this->resultSet();
			}

			return $this->data_set;
		}

    }
?>