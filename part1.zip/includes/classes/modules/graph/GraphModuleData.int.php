<?php
/**
* This class is interface for graph
*
*
*
* @author Sanjeev Krishan
* @package Smartiso
* @subpackage Audit
* @since  17 aug, 2010 IST
* @version 0.1
* @interface
*/
interface GraphModuleData {

	public function setFilter($p_filter_fields);
    public function exportGraphData();
}
?>