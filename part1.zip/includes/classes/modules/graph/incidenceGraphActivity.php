<?php
 /**
  $Id: incidenceGraphActivity.php,v 3.31 Sunday, January 30, 2011 10:01:59 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used for incidence graphs
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence graph data
  * @since  Tuesday, September 28, 2010 6:13:45 PM>
  */

    require_once "GraphModuleData.int.php";
    require_once "GraphData.abs.php";

class IncidenceGraphActivity extends IncidenceMain implements GraphModuleData  {

	private $data_set;
	private $filter_query;
	private $filters;
	private $buObj;
	private $org_data;

	public function __construct($p_filter_fields) {

		$this->filters = $p_filter_fields;
		$this->setFilter();
		$this->data_format = new GraphData();
		$this->buObj = SetupGeneric::useModule('Organigram');

		parent::__construct();

		if ( $this->filters['participant_type'] == 'shift_work' ) {

			$this->key1 = 0;
			$this->key2 = 1;
			$this->xlabels = array('No','Yes');

		} else if ( $this->filters['participant_type'] == 'male' ) {

			$this->key1 = 'M';
			$this->key2 = '';
			$this->xlabels = array('Male');

		} else if ( $this->filters['participant_type'] == 'female' ) {

			$this->key1 = 'F';
			$this->key2 = '';
			$this->xlabels = array('Female');

		} else {
			$this->key1 = 'M';
			$this->key2 = 'F';
			$this->xlabels = array('Male','Female');
		}
	}

	/* to set the filetrs for search */
	public function setFilter() {

	}



	/*private function getchildTotal($p_arr,$p_data,$org_data,$category) {

		if ( count($p_arr) ) {
			foreach ( $p_arr as $key=>$val ) {

				$total[$category] = $total[$category] + $p_data[$key][$category];
				//echo $total[$category].'<br/>';

				if ( count($org_data[$key]) ) {
					$total_child = $this->getchildTotal($org_data[$key],$p_data,$org_data,$category);
					$total[$category] += $total_child[$category];
				}
			}
		}
		//dump_array($total);
		return $total;
	}*/



	private function getRecordsForActivity() {

		$part = SetupGeneric::useModule('IncidenceDetail');
		$data_records = $part->displayItems();

		if ( count($data_records) ) {

			foreach ( $data_records as $value ) {
				if ( $value['ipcID'] == 3 ) {

					$part_region = $value['region'];
					$part_id = $value['ID'];

					$this->body_parts[$part_region][] = $part_id;
					$this->part_names[$part_id] = $value['name'];

				}

				if ( $value['ipcID'] == 4 ) {
					$injury_id = $value['ID'];

					$this->injuries[] = $injury_id;
					$this->injury_names[$injury_id] = $value['name'];
				}
				if ( $value['ipcID'] == 1 ) {
					$treatment_id = $value['ID'];

					$this->treatments[] = $treatment_id;
					$this->treatment_names[$treatment_id] = $value['name'];
				}
				if ( $value['ipcID'] == 2 ) {
					$treatment_id = $value['ID'];

					$this->accidents[] = $treatment_id;
					$this->accident_names[$treatment_id] = $value['name'];
				}
			}
		}

		$this->activity_main_data = $this->getNoOfActivitiesNew();

		//dump_array($this->activity_main_data);

	}

	/* activity graph data set*/
	private function resultSetActivityMain() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];

		$data['Upper'] = array('head'=>'Upper Body','link'=>'?sub_type=upper&year='.$selected_year.'&participant_type='.$this->filters['participant_type']);
		$data['Middle'] = array('head'=>'Middle Body','link'=>'?sub_type=middle&year='.$selected_year.'&participant_type='.$this->filters['participant_type']);
		$data['Lower'] = array('head'=>'Lower Body','link'=>'?sub_type=lower&year='.$selected_year.'&participant_type='.$this->filters['participant_type']);



		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit = $bu_name['buName'];

				if ( count($valueBu) ) {
					foreach( $valueBu as $keyPart=>$valuePart ) {

						if ( in_array($keyPart,$this->body_parts['U']) ) {

							$data['Upper']['total'][$this->key1] += $valuePart[$this->key1];
							$data['Upper']['total'][$this->key2] += $valuePart[$this->key2];


						} else if ( in_array($keyPart,$this->body_parts['M']) ) {

							$data['Middle']['total'][$this->key1] += $valuePart[$this->key1];
							$data['Middle']['total'][$this->key2] += $valuePart[$this->key2];


						} else if ( in_array($keyPart,$this->body_parts['L']) ) {

							$data['Lower']['total'][$this->key1] += $valuePart[$this->key1];
							$data['Lower']['total'][$this->key2] += $valuePart[$this->key2];


						} else {

							$data['Upper']['total'][$this->key1] += 0;
							$data['Middle']['total'][$this->key1] += 0;
							$data['Lower']['total'][$this->key1] += 0;
							$data['Upper']['total'][$this->key2] += 0;
							$data['Middle']['total'][$this->key2] += 0;
							$data['Lower']['total'][$this->key2] += 0;
						}

					}
				}
				$business_units[] = $business_unit;

			}
		}

		//dump_array($data);

		if ( count($data) ) {
			foreach( $data as $value ) {

				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($value['head'],$value['link'],$value['total'][$this->key1]);
				} else {
					$data_array = array($value['head'],$value['link'],$value['total'][$this->key1],$value['total'][$this->key2]);
				}


				$this->data_format->addDataMultipleLink($data_array);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Body Parts";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	/* activity lower body graph data set*/
	private function resultSetActivityLower() {


		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];
		$business_units = array();

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];
		$departments = $org_data[$bu_id];

		//dump_array($graph_data);

		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit_name = $bu_name['buName'];

				if ( count($this->body_parts['L']) ) {

					foreach ( $this->body_parts['L'] as $valueParts ) {
						$part_name = $this->part_names[$valueParts];

						$data[$part_name]['name'] = $part_name;
						$data[$part_name]['link'] = '?sub_type=lower&part='.$valueParts.'&year='.$selected_year.'&participant_type='.$this->filters['participant_type'];
						//$data[$part_name]['link'] = '';
						$data[$part_name]['total'][$this->key1] += (int) $valueBu[$valueParts][$this->key1];
						$data[$part_name]['total'][$this->key2] += (int) $valueBu[$valueParts][$this->key2];

						if ( !in_array($business_unit_name,$business_units) ) {
							$business_units[] = $business_unit_name;
						}
					}
				}
			}
		}

		//dump_array($data);


		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {

				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1]);
				} else {
					$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1],$valuePart['total'][$this->key2]);
				}


				$this->data_format->addDataMultipleLink($data_array);

			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Lower Body Parts";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	/* activity upper body graph data set*/
	private function resultSetActivityUpper() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];
		//dump_array($graph_data);
		$business_units = array();

		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit_name = $bu_name['buName'];

				if ( count($this->body_parts['U']) ) {

					foreach ( $this->body_parts['U'] as $valueParts ) {
						$part_name = $this->part_names[$valueParts];

						$data[$part_name]['name'] = $part_name;
						$data[$part_name]['link'] = '?sub_type=upper&part='.$valueParts.'&year='.$selected_year.'&participant_type='.$this->filters['participant_type'];
						//$data[$part_name]['link'] = '';
						$data[$part_name]['total'][$this->key1] += (int) $valueBu[$valueParts][$this->key1];
						$data[$part_name]['total'][$this->key2] += (int) $valueBu[$valueParts][$this->key2];

						if ( !in_array($business_unit_name,$business_units) ) {
							$business_units[] = $business_unit_name;
						}
					}
				}
			}
		}

		//dump_array($data);


		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {

				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1]);
				} else {
					$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1],$valuePart['total'][$this->key2]);
				}
				//$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1],$valuePart['total'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);

			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body  Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Upper Body Parts";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	/* activity middle body graph data set*/
	private function resultSetActivityMiddle() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];
		$business_units = array();


		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit_name = $bu_name['buName'];

				if ( count($this->body_parts['M']) ) {

					foreach ( $this->body_parts['M'] as $valueParts ) {

						$part_name = $this->part_names[$valueParts];

						$data[$part_name]['name'] = $part_name;
						//$data[$part_name]['link'] = '';
						$data[$part_name]['link'] = '?sub_type=middle&part='.$valueParts.'&year='.$selected_year.'&participant_type='.$this->filters['participant_type'];
						$data[$part_name]['total'][$this->key1] += (int) $valueBu[$valueParts][$this->key1];
						$data[$part_name]['total'][$this->key2] += (int) $valueBu[$valueParts][$this->key2];

						if ( !in_array($business_unit_name,$business_units) ) {
							$business_units[] = $business_unit_name;
						}
					}
				}
			}
		}


		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {

				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1]);
				} else {
					$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1],$valuePart['total'][$this->key2]);
				}
				//$data_array = array($valuePart['name'],$valuePart['link'],$valuePart['total'][$this->key1],$valuePart['total'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Middle Body Parts";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	private function getChildActivityTotal($bu_id,$p_part_id) {

		//global $total_rec ;

		if ( count($this->org_data[$bu_id]) ) {
			foreach ( $this->org_data[$bu_id] as $key=>$value ) {

				//echo $key.'---'.$total_rec.'--<br/>';
				//$total_rec += (int) $this->graph_data[$key][$p_part_id];
				$total_rec += (int) $this->graph_data[$key][$p_part_id][$this->key1];
				$total_rec += (int) $this->graph_data[$key][$p_part_id][$this->key2];
				//echo $key.'---'.$total_rec.'--<br/>';

				if ( count($this->org_data[$key]) ) {
					$total_rec += $this->getChildActivityTotal($key,$p_part_id);
				}
			}
		}

		return $total_rec;

	}

	private function resultSetActivityupperSpecific() {
		$this->activity_type = 'body_part';
		$this->graph_heading = "Upper Body Part ";
		$this->specificPartData();
	}

	private function resultSetActivitylowerSpecific() {
		$this->activity_type = 'body_part';
		$this->graph_heading = "Lower Body Part ";
		$this->specificPartData();
	}
	private function resultSetActivitymiddleSpecific() {
		$this->activity_type = 'body_part';
		$this->graph_heading = "Middle Body Part ";
		$this->specificPartData();
	}

	private function specificPartData() {

		$this->getRecordsForActivity();

		$part_id = $this->filters['part'];
		$sub_type = $this->filters['sub_type'];

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$selected_bu = $this->filters['bu'];
		$selected_bu = $selected_bu == '' ? 0 : $selected_bu;
		$this->org_data = $this->buObj->businessListForGraph(0);
		$activity_type = $this->activity_type;

		$this->graph_data = $this->activity_main_data[$activity_type][$selected_year];

		//dump_array($this->graph_data);

		if ( count($this->org_data[$selected_bu]) ) {
			foreach ( $this->org_data[$selected_bu] as $key=>$value ) {

				$data[$value]['link'] = '?sub_type='.$sub_type.'&part='.$part_id.'&bu='.$key.'&year='.$selected_year.'&participant_type='.$this->filters['participant_type'];
				//$data[$value]['rec'] += (int) $this->graph_data[$key][$part_id];
				
				$data[$value]['rec'] += (int) $this->graph_data[$key][$part_id][$this->key1];
				$data[$value]['rec'] += (int) $this->graph_data[$key][$part_id][$this->key2];

			//	echo $key.'---'.$data[$value]['rec'].'--<br/>';

				if ( count($this->org_data[$key]) ) {

					$total_rec = 0;
					$count = $this->getChildActivityTotal($key,$part_id);
					$data[$value]['rec'] += (int) $count;
				}
				//echo $key.'---'.$data[$value]['rec'].'--<br/>';
			}
		}

	//dump_array($data);

		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {

				$this->data_format->addDataPieLink(array($keyPart,$valuePart['link'],$valuePart['rec']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $this->graph_heading." Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Business Units";

	}

	private function resultSetActivitynatureSpecific() {
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Nature of injury ";
		$this->activity_type = 'injury';
		$this->specificPartData();
	}

	/* activity nature of injury graph data set*/
	private function resultSetActivitynature() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['injury'][$selected_year];

		//dump_array($graph_data);
		$business_units = array();

		if ( count($this->injuries) ) {
			foreach ( $this->injuries as $valueInjury ) {

				$data = array();
				$injury_name = $this->injury_names[$valueInjury];
				$data['name'] = $injury_name;
				$data['link'] = '?type=nature&year='.$selected_year.'&part='.$valueInjury.'&participant_type='.$this->filters['participant_type'];
				//$data['link'] = '';

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'][$this->key1] += (int) $valueBu[$valueInjury][$this->key1];
							$data['rec'][$this->key2] += (int) $valueBu[$valueInjury][$this->key2];
						}
					}
				}
				//dump_array($data);
				//$this->data_format->addDataPieLink(array($data['name'],$data['link'],$data['rec']));

				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1]);
				} else {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				}


				$this->data_format->addDataMultipleLink($data_array);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Nature of Injury Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Nature of Injury";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	private function resultSetActivitytreatmentSpecific() {
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Type of Treatment ";
		$this->activity_type = 'treatment';
		$this->specificPartData();
	}

	/* activity treatment graph data set*/
	private function resultSetActivitytreatment() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['treatment'][$selected_year];

		//dump_array($graph_data);
		$business_units = array();

		if ( count($this->treatments) ) {
			foreach ( $this->treatments as $valueInjury ) {

				$data = array();
				$treatment_name = $this->treatment_names[$valueInjury];
				$data['name'] = $treatment_name;
				$data['link'] = "?type=treatment&year=".$selected_year."&part=".$valueInjury.'&participant_type='.$this->filters['participant_type'];
				//$data['link'] = "";

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'][$this->key1] += (int) $valueBu[$valueInjury][$this->key1];
							$data['rec'][$this->key2] += (int) $valueBu[$valueInjury][$this->key2];
						}
					}
				}

				//dump_array($data);
				//$this->data_format->addDataPieLink(array($data['name'],$data['link'],$data['rec']));

				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1]);
				} else {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				}

				//$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = " Type of Treatment Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Type of Treatment";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	private function resultSetActivityaccidentSpecific() {
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Accident Occured ";
		$this->activity_type = 'accident';
		$this->specificPartData();
	}

	/* activity accident graph data set*/
	private function resultSetActivityaccident() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['accident'][$selected_year];

		//dump_array($graph_data);
		$business_units = array();

		if ( count($this->accidents) ) {
			foreach ( $this->accidents as $valueInjury ) {

				$data = array();
				$treatment_name = $this->accident_names[$valueInjury];
				$data['name'] = $treatment_name;
				$data['link'] = "?type=accident&year=".$selected_year."&part=".$valueInjury.'&participant_type='.$this->filters['participant_type'];
				//$data['link'] = "";

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'][$this->key1] += (int) $valueBu[$valueInjury][$this->key1];
							$data['rec'][$this->key2] += (int) $valueBu[$valueInjury][$this->key2];
						}
					}
				}
				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1]);
				} else {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				}
				//$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Accident Occured Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Accident Occured";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	private function resultSetActivityimpactSpecific() {
		//
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Impact ";
		$this->activity_type = 'impact';
		$this->specificPartData();
	}

	/* activity impact graph data set*/
	private function resultSetActivityimpact() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['impact'][$selected_year];

		//dump_array($graph_data);

		$impact = SetupGeneric::useModule('ImpactMeasure');
		$impact_records = $impact->displayItems();
		//dump_array($impact_records);

		$business_units = array();

		if ( count($impact_records) ) {
			foreach ( $impact_records as $keyImpact=>$valueImpact ) {

				$data = array();
				//$impact_name = str_replace(' | ',' ',$valueImpact['name']);
				$impact_name = str_replace('<',' ',$valueImpact['name']);
				$impact_name = explode('|',$impact_name);
				$data['name'] = $impact_name[0];
				$data['link'] = "?type=impact&year=".$selected_year."&part=".$valueImpact['ID'].'&participant_type='.$this->filters['participant_type'];
				//$data['link'] = "";

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							//$data['rec'] += (int) $valueBu[$valueImpact['ID']];

							$data['rec'][$this->key1] += (int) $valueBu[$valueImpact['ID']][$this->key1];
							$data['rec'][$this->key2] += (int) $valueBu[$valueImpact['ID']][$this->key2];
						}
					}
				}
				//dump_array($data);
				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1]);
				} else {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				}
				//$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);
			}
		}


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Impact Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Impact";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	/* activity hazard classification graph data set*/
	private function resultSetActivityhazardClass() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['hazard_class'][$selected_year];

		$hazards = SetupGeneric::useModule('HazardClassification');
		$hazard_parents = $hazards->displayCategories();
		//dump_array($graph_data);

		$business_units = array();

		if ( count($hazard_parents) ) {
			foreach ( $hazard_parents as $keyImpact=>$valueImpact ) {

				$data = array();
				$data['name'] = $valueImpact['primaryHazard'];
				$data['link'] = '?type=hazard&year='.$selected_year.'&hazard_id='.$valueImpact['ID'].'&participant_type='.$this->filters['participant_type'];

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							//$data['rec'] += (int) $valueBu[$valueImpact['ID']];

							$data['rec'][$this->key1] += (int) $valueBu[$valueImpact['ID']][$this->key1];
							$data['rec'][$this->key2] += (int) $valueBu[$valueImpact['ID']][$this->key2];
						}
					}
				}
				//dump_array($data);
				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1]);
				} else {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				}

				//$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);
			}
		}


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Hazards Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Hazard Class";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	/* activity hazards graph data set*/
	private function resultSetActivityhazard() {

		if ( $this->filters['part'] == '' ) {
			$this->resultSetActivityhazardMain();
		} else {
			//
			$this->resultSetActivityhazardChild();
		}
	}

	private function resultSetActivityhazardSpecific() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$hazards = SetupGeneric::useModule('HazardClassification');

	//	dump_array($graph_data);

		$sub_hazard_id = $this->filters['part'];

		$business_units = array();

		/***/
		$selected_bu = $this->filters['bu'];
		$selected_bu = $selected_bu == '' ? 0 : $selected_bu;
		$this->org_data = $this->buObj->businessListForGraph(0);
		$activity_type = $this->activity_type;

		$this->graph_data = $this->activity_main_data['hazards'][$selected_year];

		//dump_array($this->graph_data);

		if ( count($this->org_data[$selected_bu]) ) {
			foreach ( $this->org_data[$selected_bu] as $key=>$value ) {

				$data[$value]['link'] = "?type=hazard&year=".$selected_year."&hazard_id=".$this->filters['hazard_id']."&part=".$sub_hazard_id."&bu=".$key  ; //'?sub_type='.$sub_type.'&part='.$part_id.'&bu='.$key;
				$data[$value]['rec'] += (int) $this->graph_data[$key][$sub_hazard_id];

				if ( count($this->org_data[$key]) ) {

					$total_rec = 0;
					$count = $this->getChildActivityTotal($key,$sub_hazard_id);
					$data[$value]['rec'] += (int) $count;
				}


				$this->data_format->addDataPieLink(array($value,$data[$value]['link'],$data[$value]['rec']));
			}
		}
		/***/

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Hazards Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Business Units";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

	private function resultSetActivityhazardMain() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['hazards'][$selected_year];

		$hazards = SetupGeneric::useModule('HazardClassification');

		$hazards->setItemInfo(array(
						'id'=>$this->filters['hazard_id']
						));
		$hazard_records = $hazards->displayItems();
		//dump_array($graph_data);

		$business_units = array();

		if ( count($hazard_records) ) {
			foreach ( $hazard_records as $keyImpact=>$valueImpact ) {

				$data = array();
				$data['name'] = $valueImpact['secondaryHazard'];
				$data['link'] = "?type=hazard&year=".$selected_year."&hazard_id=".$this->filters['hazard_id']."&part=".$valueImpact['ID'].'&participant_type='.$this->filters['participant_type'];

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'][$this->key1] += (int) $valueBu[$valueImpact['ID']][$this->key1];
							$data['rec'][$this->key2] += (int) $valueBu[$valueImpact['ID']][$this->key2];
						}
					}
				}
				//dump_array($data);
				if ( $this->filters['participant_type'] == 'male' || $this->filters['participant_type'] == 'female' ) {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1]);
				} else {
					$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				}

				//$data_array = array($data['name'],$data['link'],$data['rec'][$this->key1],$data['rec'][$this->key2]);
				$this->data_format->addDataMultipleLink($data_array);
			}
		}


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Hazards Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Hazards";
		$this->data_set['xaxis_labels'] = $this->xlabels;
	}

/* to export data*/
	public function exportGraphData($p_type='') {

		if ( !empty($p_type) ) {

			$method = "resultSet".ucwords($p_type);
			$this->$method();
		} else {
			$this->resultSet();
		}

		return $this->data_set;
	}
}
?>