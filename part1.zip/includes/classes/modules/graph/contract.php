<?php
 /**
  $Id: incidence.php,v 3.46 Wednesday, February 02, 2011 2:50:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used for incidence graphs
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence graph data
  * @since  Tuesday, September 28, 2010 6:13:45 PM>
  */

require_once "GraphModuleData.int.php";
require_once "GraphData.abs.php";

class ContractGraph implements GraphModuleData  {

	private $data_set;
	private $filter_query;
	private $filters;
	private $organigramObj;
	private $incidenceObj;
	private $child_business_units;
	private $quarterdata;

	public function __construct() {

		$this->data_format = new GraphData();
		$this->organigramObj = SetupGeneric::useModule('Organigram');
		$this->contractObj = new Contract();
		$this->quarterdata=$this->contractObj->getquarter(date('Y'),date('m'),date('d'));
	}

	public function setFilter($p_filter_fields) {

		$this->filters = $p_filter_fields;
	
		if($this->filters['type']=='undefined'){
			$this->filters['type'] ='all';
		}
		

		if($this->filters['not']=='undefined'){
			$this->filters['not'] ='not';
		}
		if($this->filters['manager']=='undefined'){
			$this->filters['manager'] ='cm';
		}
		
	}

	private function getRateFromValue($p_val,$p_decimal_place=2) {

		return number_format(($p_val*1000)/$this->participant_count,$p_decimal_place);
	}
	
	//$p_type='main';

	public function processData($p_type='main') {

		switch($this->filters['heading']){
		case 'Contract Type':
			$this->processDataType();
			break;
		case 'Contract Manager':
			$this->processDataManager();
			break;
		case 'Supplier':
			$this->processDataSupplier();
			break;
		default:
			$this->processDataMain();
			break;
		}
	}

	public function processDataManager() {
	 $participantObj	= SetupGeneric::useModule('Participant');
	 
 switch ($this->filters['manager']){
case 'cm':
$graph_heading = $this->filters['heading']." Review  Graph for Contract Manager ";
break;
case 'ma':
$graph_heading = $this->filters['heading']." Review  Graph for Manager Approver ";
break;
case 'da':
$graph_heading = $this->filters['heading']." Review  Graph for Dirctor Approver ";
break;
default:
$graph_heading = $this->filters['heading']." Review Graph for Contract Manager ";
break;
}

	 
	 if ($this->filters['not']=='over'){
	  	 $title="Over Due";
	 $completed = $this->contractObj->getGraphMangerOverDue($this->quarterdata['year'],$this->filters['manager'],$this->quarterdata['quarter']);


	 	foreach( $completed[$this->filters['quarter']] as $key=>$value) {
		 if (is_numeric($key))
		 {
	//	$current_ns+=($value*$factor)-$completed[$key];
		$current_ns+=$value;
		$participantObj->setItemInfo(array('id'=>$key));
		$pdetails = $participantObj->displayItemById();
		$name = $pdetails['forename'].''.$pdetails['surname'];
	
//	$childvalue=($value*$factor)-$completed[$key];
$child_arr_A[] = array(
									'bu_id'=>'1',
								  'key'=>$name,
								  'value'=>$value);
								  
				}
		}
		
	 }
	 elseif ($this->filters['not']=='com'){

	 $title="Completed";
	 $completed = $this->contractObj->getGraphMangerCompleted($this->quarterdata['year'],$this->filters['manager'],$this->filters['quarter']);
	foreach($completed as $key=>$value) {
		$current_ns+=$value;
				
		$participantObj->setItemInfo(array('id'=>$key));
		$pdetails = $participantObj->displayItemById();
		$name = $pdetails['forename'].' '.$pdetails['surname'];
	
$child_arr_A[] = array(
									'bu_id'=>'1',
								  'key'=>$name,
								  'value'=>$value);
								  

		}
		
	  }
	  
	  else{
	  	 $title="Not Started";
//	 $completed = $this->contractObj->getGraphMangerCompleted($this->quarterdata['year'],$this->filters['manager'],$this->filters['quarter']);
	 $contractCount = $this->contractObj->getGraphContractCountByManager($this->filters['manager'],$this->quarterdata['year']);

	if( is_numeric($this->filters['quarter'])){
	 	foreach( $contractCount[$this->filters['quarter']] as $key=>$value) {
		 if (is_numeric($key))
		 {
		 
		$current_ns+=($value);
		
		$participantObj->setItemInfo(array('id'=>$key));
		$pdetails = $participantObj->displayItemById();
		$name = $pdetails['forename'].''.$pdetails['surname'];
	
	$childvalue=($value);
$child_arr_A[] = array(
									'bu_id'=>'1',
								  'key'=>$name,
								  'value'=>$childvalue);
								  
				}
		}
		
	 }
	else
	{
	 	foreach( $contractCount['all'] as $key=>$value) {
		 if (is_numeric($key))
		 {
		 
		$current_ns+=($value);
		
		$participantObj->setItemInfo(array('id'=>$key));
		$pdetails = $participantObj->displayItemById();
		$name = $pdetails['forename'].''.$pdetails['surname'];
	
	$childvalue=($value);
$child_arr_A[] = array(
									'bu_id'=>'1',
								  'key'=>$name,
								  'value'=>$childvalue);
								  
				}
		}
		
	 }
	
	
	  }
	  
	  
$child_arr['name'] = $child_arr_A;
		//}
		
		
if(is_numeric($this->filters['quarter']	))
$qtrhead="Quarter ".$this->filters['quarter'];

$graph_heading.=$title." ".$this->quarterdata["year"]." ".$qtrhead;		





	$this->data_set = array(
					'main_graph'=>array(
							'chart_data'=>array(
												$title=>array(
												'value'=>$current_ns)
												
												
									),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Contracts',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Reviews',
						'yaxis_text'=>$yaxis_text,
						)
					);
	 }
	public function processDataMain() {

		$finish = $this->contractObj->getGraphFinish($this->quarterdata['year']);
		$contractCount = $this->contractObj->getGraphContractCountByType($this->quarterdata['year']);
		$overdue = $this->contractObj->getGraphOverDue($this->quarterdata['year'],$this->quarterdata['quarter']);
			

$current_cm=0;
$current_ma=0;
$current_da=0;
$current_rcd=0;

switch ($this->filters['change']){
case '0':
$graph_heading = $this->filters['heading']." Review Short Term Graph for ".$this->quarterdata["year"];
break;
case '1':
$graph_heading = $this->filters['heading']." Review Tender Graph for ".$this->quarterdata["year"];
break;
case '2':
$graph_heading = $this->filters['heading']." Review OJEU Notice Graph for ".$this->quarterdata["year"];
break;
default:
$graph_heading = $this->filters['heading']." Review Graph for ".$this->quarterdata["year"];
break;
}



	
if (is_numeric($this->filters['type']) && is_numeric($this->filters['change'])){

$current_cm+=$finish[$this->filters['type']][$this->filters['change']]['cm'] ;
$current_ma+=$finish[$this->filters['type']][$this->filters['change']]['ma'];
$current_da+=$finish[$this->filters['type']][$this->filters['change']]['da'] ;
$current_rcd+=$overdue[$this->filters['type']][$this->filters['change']] ;

$current_ns=$contractCount[$this->filters['type']][$this->filters['change']];
$qtrhead=" Quarter ".$this->filters['type'];
}
elseif (is_numeric($this->filters['type']) ){
 if ($finish[$this->filters['type']]){
	foreach($finish[$this->filters['type']] as $findata){
	
$current_cm+=$findata['cm'];
$current_ma+=$findata['ma'];
$current_da+=$findata['da'];

}

}
$current_rcd+=$overdue[$this->filters['type']]['all'];
$current_ns=$contractCount[$this->filters['type']]['all'];
$qtrhead=" Quarter ".$this->filters['type'];
}
elseif ( is_numeric($this->filters['change'])){
for ($x=1;$x<5;$x++){
$current_cm+=$finish[$x][$this->filters['change']]['cm'];
$current_ma+=$finish[$x][$this->filters['change']]['ma'];
$current_da+=$finish[$x][$this->filters['change']]['da'];
$current_rcd+=$overdue[$x][$this->filters['change']];
$current_ns+=$contractCount[$x][$this->filters['change']];
}



}
else{

for ($x=1;$x<5;$x++){
 if($finish[$x]){
	

	foreach($finish[$x] as $findata){
$current_cm+=$findata['cm'];
$current_ma+=$findata['ma'];
$current_da+=$findata['da'];
}
}
$current_rcd+=$overdue[$x]['all'];

}
$current_ns=($contractCount['all']);

}

$graph_heading.=$qtrhead;

if ($current_ns<0)
$current_ns == 0;

			$child_arr_A['0'] = array(
									'bu_id'=>'4',
								  'key'=>'Not Started',
								  'value'=>$current_ns);
			$child_arr_A['1'] = array(
									'bu_id'=>'3',
								  'key'=>'Completed',
								  'value'=>$current_cm);
		    $child_arr_A['2'] = array(
									'bu_id'=>'5',
								  'key'=>'Overdue',
								  'value'=>$current_rcd);
								  
		  
			$child_arr_R['0'] = array(
									'bu_id'=>'4',
								  'key'=>'Not Started',
								  'value'=>$current_ns+$current_cm-$current_ma);

			$child_arr_R['1'] = array(
									'bu_id'=>'3',
								  'key'=>'Completed',
								  'value'=>$current_ma);
	
		    $child_arr_R['2'] = array(
									'bu_id'=>'5',
								  'key'=>'Overdue',
								  'value'=>$current_rcd);
								  
			

			
		    $child_arr_F['0'] = array(
								'bu_id'=>'4',
								  'key'=>'Not Started',
								  'value'=>$current_ns+$current_cm-$current_da);
			$child_arr_F['1'] = array(
									'bu_id'=>'3',
								  'key'=>'Completed',
								  'value'=>$current_da);
			$child_arr_F['2'] = array(
									'bu_id'=>'5',
								  'key'=>'Overdue',
								  'value'=>$current_rcd);
$child_arr = array(
							'Contract Manager'=>array(),
							'Manager Approver'=>array(),
							'Director Approver'=>array());
			
			$child_arr['Contract Manager'] = $child_arr_A;
			$child_arr['Manager Approver'] = $child_arr_R;
			$child_arr['Director Approver']= $child_arr_F;




$this->data_set = array(
					'main_graph'=>array(
							'chart_data'=>array(
							                  'reviews'=>array(
												0=>array('key'=>'Not Started',
												'value'=>$current_ns),
												1=>array('key'=>'Contract Manager Completed Reviews',
												'value'=>$current_cm),
												2=>array('key'=>'Manager Approver Completed Reviews',
												'value'=>$current_ma),
												3=>array('key'=>'Director Approver Completed Reviews',
												'value'=>$current_da),
												4=>array('key'=>'Overdue',
												'value'=>$current_rcd)
											  ),
												
									),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Reviews',
						'yaxis_text'=>$yaxis_text
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Reviews',
						'yaxis_text'=>$yaxis_text
						)
					);
 	}
 	
	public function processDataSupplier() {
		$supplier_info = $this->getSupplierData($this->filters['name'],$this->filters['year'],$this->filters['quarter']);
		
				if ($supplier_info)
				{
				foreach( $supplier_info as $reviewdata)
				{
				$countcontractors++;
				foreach( $reviewdata as $suppdata)
				{
				$count++;
				foreach( $suppdata as $key=>$value)
				{
				$ch_data[$key]+=$value["score"];
				}
				}
				}
				}
				if ($count>0)
				{
				for ($w=1;$w<10;$w++)
				$ch_data[$w]=number_format(($ch_data[$w]/$count),2);
				}

		$child_arr_A['0'] = array(
									'bu_id'=>'1',
								  'key'=>'Product Quality',
								  'value'=>$ch_data[1]);
		$child_arr_A['1'] = array(
									'bu_id'=>'2',
								  'key'=>'Service Quality',
								  'value'=>$ch_data[2]);
if ($this->filters['quarter']==4)		
{
$child_arr_A['2'] = array(
									'bu_id'=>'3',
								  'key'=>'Health and Quality',
								  'value'=>$ch_data[3]);
								  
		$child_arr_A['3'] = array(
									'bu_id'=>'4',
								  'key'=>'On time Delivery',
								  'value'=>$ch_data[4]);
		$child_arr_A['4'] = array(
									'bu_id'=>'5',
								  'key'=>'Knowledge',
								  'value'=>$ch_data[5]);						  
		$child_arr_A['5'] = array(
									'bu_id'=>'6',
								  'key'=>'Reputation',
								  'value'=>$ch_data[6]);
		$child_arr_A['6'] = array(
									'bu_id'=>'7',
								  'key'=>'Customer Focus',
								  'value'=>$ch_data[7]);
		$child_arr_A['7'] = array(
									'bu_id'=>'8',
								  'key'=>'Customer Service',
								  'value'=>$ch_data[8]);
		$child_arr_A['8'] = array(
									'bu_id'=>'9',
								  'key'=>'Responsiveness',
								  'value'=>$ch_data[9]);
}
else
{
	$child_arr_A['2'] = array(
									'bu_id'=>'4',
								  'key'=>'On time Delivery',
								  'value'=>$ch_data[4]);
		$child_arr_A['3'] = array(
									'bu_id'=>'5',
								  'key'=>'Knowledge',
								  'value'=>$ch_data[5]);						  
		$child_arr_A['4'] = array(
									'bu_id'=>'6',
								  'key'=>'Reputation',
								  'value'=>$ch_data[6]);
		$child_arr_A['5'] = array(
									'bu_id'=>'7',
								  'key'=>'Customer Focus',
								  'value'=>$ch_data[7]);
		$child_arr_A['6'] = array(
									'bu_id'=>'8',
								  'key'=>'Customer Service',
								  'value'=>$ch_data[8]);
		$child_arr_A['7'] = array(
									'bu_id'=>'9',
								  'key'=>'Responsiveness',
								  'value'=>$ch_data[9]);
}
		

      
			
		$child_arr['Questions'] = $child_arr_A;	
			$graph_heading = $this->filters['bu_name'] == '' ? $this->filters['heading']." Review Graph ": $this->filters['bu_name']." - ".$this->filters['heading']." Review".ucfirst($this->filters['data_stat_type'])." Graph";


				$this->data_set = array(
					'main_graph'=>array(
							'chart_data'=>array(
												'Reviews'=>array('key'=>'Suppliers',
												'value'=>$countcontractors)
												
												
									),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Contracts',
						'yaxis_text'=>$yaxis_text
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Question Average',
						'yaxis_text'=>$yaxis_text
						)
					);
				

}


	public function processDataType() {

		    $score = $this->contractObj->getGraphScore($this->quarterdata['year']);


$current_l=0;
$current_m=0;
$current_h=0;

switch ($this->filters['contract_type']){
case '0':
$graph_heading = $this->filters['heading']." Review Short Term Graph for ".$this->quarterdata["year"];
break;
case '1':
$graph_heading = $this->filters['heading']." Review Tender Graph for ".$this->quarterdata["year"];
break;
case '2':
$graph_heading = $this->filters['heading']." Review OJEU Notice Graph for ".$this->quarterdata["year"];
break;
default:
$graph_heading = $this->filters['heading']." Review Graph for ".$this->quarterdata["year"];
break;
}

if (is_numeric($this->filters['quarter']) && is_numeric($this->filters['contract_type'])){

$current_l+=$score[$this->filters['quarter']][$this->filters['contract_type']]['lowscore'] ;
$current_m+=$score[$this->filters['quarter']][$this->filters['contract_type']]['midscore'];
$current_h+=$score[$this->filters['quarter']][$this->filters['contract_type']]['highscore'] ;
$qtrhead=" Quarter ".$this->filters['quarter'];
}
elseif (is_numeric($this->filters['quarter']) ){
 if ($score[$this->filters['quarter']]){
	foreach($score[$this->filters['quarter']] as $findata){
	
$current_l+=$findata['lowscore'];
$current_m+=$findata['midscore'];
$current_h+=$findata['highscore'];
$qtrhead=" Quarter ".$this->filters['quarter'];
}

}
}
elseif ( is_numeric($this->filters['contract_type'])){
for ($x=1;$x<5;$x++){
$current_l+=$score[$x][$this->filters['contract_type']]['lowscore'];
$current_m+=$score[$x][$this->filters['contract_type']]['midscore'];
$current_h+=$score[$x][$this->filters['contract_type']]['highscore'];
}
}
else{

for ($x=1;$x<5;$x++){
 if($score[$x]){
	

	foreach($score[$x] as $findata){
$current_l+=$findata['lowscore'];
$current_m+=$findata['midscore'];
$current_h+=$findata['highscore'];
}
}
}
}

$graph_heading.=$qtrhead;

				$this->data_set = array(
					'main_graph'=>array(
							'chart_data'=>array(
											'Reviews'=>	array(
												
												0=>array('key'=>'Less than 2.5',
												'value'=>$current_l),
												1=>array('key'=>'2.5 - 3.5',
												'value'=>$current_m),
												2=>array('key'=>'> 3.5',
												'value'=>$current_h)
												),
												
												
									),
						'heading'=>$graph_heading,
						'xaxis_text'=>'Number of Contracts',
						'yaxis_text'=>$yaxis_text,
						),
					'child_graph'=>array(
						'chart_data'=>$child_arr,
						'heading'=> 'Under '.$graph_heading,
						'xaxis_text'=>'Number of Reviews',
						'yaxis_text'=>$yaxis_text,
						)
					);
						

 	}


/*
	private function getAverageData() {

		return $this->incidenceObj->getAverage();
	}
	private function getAverageData1() {

		return $this->incidenceObj->getAverage1();
	}
	private function getAverageData2() {

		return $this->incidenceObj->getAverage2();
	}
	
	private function getShortAverageData() {

		return $this->incidenceObj->getShortAverage();
	}
	private function getShortAverageData1() {

		return $this->incidenceObj->getShortAverage1();
	}
	private function getShortAverageData2() {

		return $this->incidenceObj->getShortAverage2();
	}
	private function getTenderAverageData() {

		return $this->incidenceObj->getTenderAverage();
	}
	private function getTenderAverageData1() {

		return $this->incidenceObj->getTenderAverage1();
	}
	private function getTenderAverageData2() {

		return $this->incidenceObj->getTenderAverage2();
	}

	
		private function getOjeuAverageData() {

		return $this->incidenceObj->getOJEUAverage();
	}
	private function getOjeuAverageData1() {

		return $this->incidenceObj->getOJEUAverage1();
	}
	private function getOjeuAverageData2() {

		return $this->incidenceObj->getOJEUAverage2();
	}
*/	
	private function getContractFinish() {

		return $this->incidenceObj->getcmFinish();
	}
		private function getdaFinish() {

		return $this->incidenceObj->getdaFinish();
	}
		private function getmaFinish() {

		return $this->incidenceObj->getmaFinish();
	}
	
	private function getContractFinishq1() {

		return $this->contractObj->getcmFinishq1();
	}
	private function getContractFinishMAq1() {

		return $this->contractObj->getmaFinishq1();
	}
	private function getContractFinishDAq1() {

		return $this->contractObj->getdaFinishq1();
	}

	private function getContractFinishq2() {

		return $this->incidenceObj->getcmFinishq2();
	}
		private function getContractFinishq3() {

		return $this->incidenceObj->getcmFinishq3();
	}
	private function getContractFinishMAq2() {

		return $this->incidenceObj->getmaFinishq2();
	}
	
		private function getContractFinishMAq3() {

		return $this->incidenceObj->getmaFinishq3();
	}
	
	private function getContractFinishDAq2() {

		return $this->incidenceObj->getdaFinishq2();
	}
		private function getContractFinishDAq3() {

		return $this->incidenceObj->getdaFinishq3();
	}
	private function getNotStarted() {

		return $this->incidenceObj->getStarted();
	}
/*	private function getCMNotStarted() {

		return $this->incidenceObj->getcmStarted();
	}
	
	private function getCMNotStartedq1() {

		return $this->incidenceObj->getcmStartedq1();
	}
	
	*/
	
	private function getStartedq1() {

		return $this->incidenceObj->getshortq1();
	}
	
	private function getStartedq2() {

		return $this->incidenceObj->getshortq2();
	}
	
		private function getStartedq3() {

		return $this->incidenceObj->getshortq3();
	}
/*	
	private function getCMNotStartedq2() {

		return $this->incidenceObj->getcmStartedq2();
	}
		private function getCMNotStartedq3() {

		return $this->incidenceObj->getcmStartedq3();
	}*/
	private function getMANotStarted() {

		return $this->incidenceObj->getmaStarted();
	}
	
	private function getMANotStartedq1() {

		return $this->incidenceObj->getmaStartedq1();
	}
	
	private function getMANotStartedq2() {

		return $this->incidenceObj->getmaStartedq2();
	}
	
	private function getMANotStartedq3() {

		return $this->incidenceObj->getmaStartedq3();
	}
		
	private function getCMOverdue() {

		return $this->incidenceObj->getcmOverdue();
	}
	
	private function getNotstartedName() {

		return $this->incidenceObj->getnotstartedname();
	}
	private function getMANotstartedName() {

		return $this->incidenceObj->getmanotstartedname();
	}
	
	private function getDANotstartedName() {

		return $this->incidenceObj->getdanotstartedname();
	}
	
	private function getCompletedName() {

		return $this->incidenceObj->getcompletedname();
	}
	
	private function getMACompletedName() {

		return $this->incidenceObj->getmacompletedname();
	}
	private function getDACompletedName() {

		return $this->incidenceObj->getdacompletedname();
	}
	
	private function getOverName() {

		return $this->incidenceObj->getovername();
	}

	private function getMAOverName() {

		return $this->incidenceObj->getmaovername();
	}
	private function getDAOverName() {

		return $this->incidenceObj->getdaovername();
	}
	
	private function getOverdue() {

		return $this->incidenceObj->getOverdue();
	}
	private function getCMOverdueq1() {

		return $this->incidenceObj->getcmOverdueq1();
	}
	private function getOverdueq1() {

		return $this->incidenceObj->getOverdueq1();
	}
	
	private function getOverdueq2() {

		return $this->incidenceObj->getOverdueq2();
	}
	
		private function getOverdueq3() {

		return $this->incidenceObj->getOverdueq3();
	}
	
	private function getCMOverdueq2() {

		return $this->incidenceObj->getcmOverdueq2();
	}
	
		private function getCMOverdueq3() {

		return $this->incidenceObj->getcmOverdueq3();
	}
	
	private function getMAOverdue() {

		return $this->incidenceObj->getmaOverdue();
	}
	private function getMAOverdueq1() {

		return $this->incidenceObj->getmaOverdueq1();
	}
	
	private function getMAOverdueq2() {

		return $this->incidenceObj->getmaOverdueq2();
	}
	
		private function getMAOverdueq3() {

		return $this->incidenceObj->getmaOverdueq3();
	}
	
	private function getDAOverdue() {

		return $this->incidenceObj->getdaOverdue();
	}
	private function getDAOverdueq1() {

		return $this->incidenceObj->getdaOverdueq1();
	}
	
	private function getDAOverdueq2() {

		return $this->incidenceObj->getdaOverdueq2();
	}
	private function getDAOverdueq3() {

		return $this->incidenceObj->getdaOverdueq3();
	}

	private function getDANotStarted() {

		return $this->incidenceObj->getdaStarted();
	}
	private function getDANotStartedq1() {

		return $this->incidenceObj->getdaStartedq1();
	}
	private function getDANotStartedq2() {

		return $this->incidenceObj->getdaStartedq2();
	}

	private function getDANotStartedq3() {

		return $this->incidenceObj->getdaStartedq3();
	}

	private function getViolenceGraphData() {

		return $this->incidenceObj->getNoOfViolenceIncidence();
	}

	private function getParticipantGraphData() {

		return $this->incidenceObj->getNoOfParticipants();
	}

	private function getActivityGraphData() {

		return $this->incidenceObj->getNoOfActivities();
	}

	private function getActionGraphData() {

		return $this->incidenceObj->getNoOfActions();
	}

	private function getAccidentTestGraphData() {

		$this->incidenceObj->getInstructorGraphData();
	}

	private function getAccidentPublicGraphData() {

		return $this->incidenceObj->getAccidentPublicGraphData();
	}
/*	
	private function contractAverageData($name) {

		return $this->incidenceObj->contractaveragedata($name);
	}
	private function contractAverageDataFirst($name) {

		return $this->incidenceObj->contractaveragedataFirst($name);
	}
	private function contractAverageDataSec($name) {

		return $this->incidenceObj->contractaveragedataSec($name);
	}*/
	private function getQuestionData($name) {

		return $this->incidenceObj->getquestiondata($name);
	}

	private function getSupplierData($name='',$year,$quarter) {

		return $this->contractObj->getsupplierdata($name,$year,$quarter);
	}

	public function exportGraphData() {

		return $this->data_set;
	}
	

	
	
}
?>