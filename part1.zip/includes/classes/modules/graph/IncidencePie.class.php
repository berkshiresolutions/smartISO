<?php
 /**
  $Id: IncidencePie.class.php,v 3.03 Wednesday, January 19, 2011 11:10:54 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence pie charts
  * @since  Wednesday, December 22, 2010 11:56:18 AM>
  */
    require_once "GraphModuleData.int.php";
    require_once "GraphData.abs.php";

class IncidencePie extends IncidenceMain implements GraphModuleData  {
	private $data_set;
	private $filter_query;
	private $filters;
	private $buObj;
	private $org_data;
	private $child_total;

	public function __construct($p_filter_fields) {

		$this->filters = $p_filter_fields;
		$this->setFilter();
		$this->data_format = new GraphData();
		$this->buObj = SetupGeneric::useModule('Organigram');

		parent::__construct();
	}

	/* to set the filetrs for search */
	public function setFilter() {

	}

	/* to export data*/
	public function exportGraphData($p_type='') {

		if ( !empty($p_type) ) {

			$method = "resultSet".ucwords($p_type);
			$this->$method();
		} else {
			$this->resultSet();
		}

		return $this->data_set;
	}

	private function  getOrgAccidents($org_data_key) {

		if ( count($this->org_data[$org_data_key]) ) {

			foreach( $this->org_data[$org_data_key] as $key=>$value ) {

				if ( $this->accident_data[$key] ) {
					$this->child_total += (int) $this->accident_data[$key];
				}
				if ( count($this->org_data[$key]) ) {
					$this->getOrgAccidents($key);
					//echo "<br/>";
				}
			}

		}

		//return $this->child_total;
	}

	/* accidents graph data set*/
	private function resultSet() {


		$accident_data_array = $this->getNoOfAccidents();
		$this->org_data = $this->buObj->businessListForGraph(0);

		$selected_year = $this->filters['year'];
		$this->accident_data = $accident_data_array[$selected_year];


		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( count($this->org_data[$bu_id]) ) {
			foreach( $this->org_data[$bu_id] as $key=>$value ) {

					$this->child_total = 0;
					if ( count($this->org_data[$key]) ) {
						$this->getOrgAccidents($key);
					}

					//echo $key.'--'.$child_total.'--------'.$accident_data[$key].'<br/>';

					$graph_data[$key]['name'] = $value;
					$graph_data[$key]['self_data'] = (int) $this->accident_data[$key];
					$graph_data[$key]['child_data'] = $this->child_total;
				//}
			}
		}

		$graph_heading = $this->filters['bu_name'] == '' ? "Accidents Graph" : $this->filters['bu_name']." - Accidents Graph";
		$graph_heading = $graph_heading.' for '.$selected_year;
		$sql_query = "".$this->filter_query ;

		if ( count($graph_data) ) {
			foreach($graph_data as $key=>$val) {
				$data_arr = array($val['name'],'accident_pie.php?year='.$selected_year.'&bu='.$key,($val['self_data']+$val['child_data']));
				$this->data_format->addDataPieLink($data_arr);
				//$this->data_format->addDataMultipleLink($data_arr);
			}
		}


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $graph_heading;
		$this->data_set['xaxis_text'] = "Number of accidents";
		$this->data_set['yaxis_text'] = "Business Units";
		$this->data_set['xaxis_labels'] = array('Self Accidents','Child Accidents');
	}


	private function getchildTotal($p_arr,$category) {

		if ( count($this->org_data[$p_arr]) ) {
			foreach ( $this->org_data[$p_arr] as $key=>$val ) {

				$this->total_rec += $this->participant_data[$key][$category];
				//echo $total[$category].'<br/>';

				if ( count($this->org_data[$key]) ) {
					$this->getchildTotal($key,$category);
				}
			}
		}
		//dump_array($total);
		//return $total;
	}


	/* participant graph data set*/
	private function resultSetParticipant() {

		// displayBusinessName
		$participant_data_array = $this->getNoOfParticipants();
		$this->org_data = $this->buObj->businessListForGraph(0);


		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$selected_type = $this->filters['type'];
		$selected_type = $selected_type == '' ? 'shift_work' : $selected_type;

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];
		$departments = $this->org_data[$bu_id];

		$this->participant_data = $participant_data_array[$selected_type][$selected_year];

		if ( count($this->participant_data) ) {
			ksort($this->participant_data);
		}


		if ( $selected_type == 'shift_work' ) {
			$array_types = array('yes','no');
		} else {
			$array_types = array('male','female');
		}

		$category = $this->filters['sub_type'];

		if ( !empty($this->filters['sub_type']) ) {


			$data = $data[$this->filters['sub_type']];

			if ( count($departments) ) {
				$departments_name = array();
				foreach ( $departments as $key=>$value ) {

					$this->total_rec	= (int) $this->participant_data[$key][$category];


					if ( count($this->org_data[$key]) ) {

						$this->getchildTotal($key,$category);
						$graph_data[$key][$category]	= $this->total_rec;
						//exit;

					}

					$this->buObj->setItemInfo(array('id'=>$key));
					$bu_name = $this->buObj->displayItemByIdForMSR();

					$departments_name[$key] = $bu_name['buName'];

				}
			}

			//dump_array($graph_data);
			//exit;


			if ( count($departments_name) ) {
				foreach ( $departments_name as $key=>$value ) {

					$link = '';
					$link = '?type='.$selected_type.'&year='.$selected_year.'&sub_type='.$category.'&bu='.$key;
					//$link = '?type='.$selected_type.'|'.$selected_year.'|'.$category.'|'.$key;

					//$this->data_format->addDataMultipleLink(array($value,$link,$graph_data[$key][$category]));
					$data = array();
					$data = array($value,$link,(int) $graph_data[$key][$category]);
					$this->data_format->addDataPieLink($data);
				}
			}
		} else {

			if ( count($this->participant_data) ) {

				$data[$array_types[0]][] = ucwords($array_types[0]);
				$data[$array_types[1]][] = ucwords($array_types[1]);

				foreach( $this->participant_data as $key=>$value ) {

					$data[$array_types[0]][1] += $value[$array_types[0]];
					$data[$array_types[1]][1] += $value[$array_types[1]];
				}
			}

			if ( count($array_types) ) {
				foreach( $array_types as $valueType ) {

					$link = '';
					$link = '?type='.$selected_type.'&year='.$selected_year.'&sub_type='.strtolower($data[$valueType][0]);
					$this->data_format->addDataPieLink(array($data[$valueType][0],$link,$data[$valueType][1]));
				}
			}
		}

		$sub_heading = ucwords(str_replace('_',' ',$selected_type));


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Participant ".$sub_heading." Graph";
		$this->data_set['xaxis_text'] = "Number of Employees";
		$this->data_set['yaxis_text'] = "Business Units";
	}

	private function getRecordsForActivity() {

		$part = SetupGeneric::useModule('IncidenceDetail');
		$data_records = $part->displayItems();

		if ( count($data_records) ) {

			foreach ( $data_records as $value ) {
				if ( $value['ipcID'] == 3 ) {

					$part_region = $value['region'];
					$part_id = $value['ID'];

					$this->body_parts[$part_region][] = $part_id;
					$this->part_names[$part_id] = $value['name'];

				}

				if ( $value['ipcID'] == 4 ) {
					$injury_id = $value['ID'];

					$this->injuries[] = $injury_id;
					$this->injury_names[$injury_id] = $value['name'];
				}
				if ( $value['ipcID'] == 1 ) {
					$treatment_id = $value['ID'];

					$this->treatments[] = $treatment_id;
					$this->treatment_names[$treatment_id] = $value['name'];
				}
				if ( $value['ipcID'] == 2 ) {
					$treatment_id = $value['ID'];

					$this->accidents[] = $treatment_id;
					$this->accident_names[$treatment_id] = $value['name'];
				}
			}
		}

		$this->activity_main_data = $this->getNoOfActivities();

	}

	private function resultSetActivityMain() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];

		$data['Upper'] = array('head'=>'Upper Body','link'=>'?sub_type=upper&year='.$selected_year);
		$data['Middle'] = array('head'=>'Middle Body','link'=>'?sub_type=middle&year='.$selected_year);
		$data['Lower'] = array('head'=>'Lower Body','link'=>'?sub_type=lower&year='.$selected_year);

		$data['Upper']['total'] = 0;
		$data['Middle']['total'] = 0;
		$data['Lower']['total'] = 0;

		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit = $bu_name['buName'];

				if ( count($valueBu) ) {
					foreach( $valueBu as $keyPart=>$valuePart ) {

						if ( in_array($keyPart,$this->body_parts['U']) ) {

							$data['Upper']['total'] += $valuePart;

						} else if ( in_array($keyPart,$this->body_parts['M']) ) {

							$data['Middle']['total'] += $valuePart;

						} else if ( in_array($keyPart,$this->body_parts['L']) ) {

							$data['Lower']['total'] += $valuePart;

						} else {

							$data['Upper']['total'] += 0;
							$data['Middle']['total'] += 0;
							$data['Lower']['total'] += 0;
						}
					}
				}
				$business_units[] = $business_unit;
			}
		}

		if ( count($data) ) {
			foreach( $data as $value ) {

				$data_array = array();

				if ( count($value) ){
					foreach ( $value as $valueEle ) {
						$data_array[] = $valueEle;
					}
				}
				$this->data_format->addDataPieLink($data_array);
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Body Parts";
	}

	/* activity lower body graph data set*/
	private function resultSetActivityLower() {


		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];
		$business_units = array();

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];
		$departments = $org_data[$bu_id];

		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit_name = $bu_name['buName'];

				if ( count($this->body_parts['L']) ) {

					foreach ( $this->body_parts['L'] as $valueParts ) {
						$part_name = $this->part_names[$valueParts];

						$data[$part_name]['name'] = $part_name;
						$data[$part_name]['link'] = '?sub_type=lower&part='.$valueParts.'&year='.$selected_year;
						$data[$part_name]['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev
						$data[$part_name]['total'] += (int) $valueBu[$valueParts];

						if ( !in_array($business_unit_name,$business_units) ) {
							$business_units[] = $business_unit_name;
						}
					}
				}
			}
		}

		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {
				//$this->data_format->addDataPieLink(array($valuePart['name'],$valuePart['link'],$valuePart['total']));
				$this->data_format->addDataPieLink(array($valuePart['name'],$valuePart['link'],(int) $valuePart['total']));

			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Lower Body Parts";
	}

	/* activity upper body graph data set*/
	private function resultSetActivityUpper() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];
		$business_units = array();

		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit_name = $bu_name['buName'];

				if ( count($this->body_parts['U']) ) {

					foreach ( $this->body_parts['U'] as $valueParts ) {
						$part_name = $this->part_names[$valueParts];

						$data[$part_name]['name'] = $part_name;
						$data[$part_name]['link'] = '?sub_type=upper&part='.$valueParts.'&year='.$selected_year;
						$data[$part_name]['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev
						$data[$part_name]['total'] += (int) $valueBu[$valueParts];

						if ( !in_array($business_unit_name,$business_units) ) {
							$business_units[] = $business_unit_name;
						}
					}
				}
			}
		}

		//dump_array($data);


		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {
				$this->data_format->addDataPieLink(array($valuePart['name'],$valuePart['link'],(int) $valuePart['total']));

			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body  Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Upper Body Parts";
		//$this->data_set['xaxis_labels'] = $business_units;
	}

	/* activity middle body graph data set*/
	private function resultSetActivityMiddle() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['body_part'][$selected_year];
		$business_units = array();


		if ( count($graph_data) ) {
			foreach( $graph_data as $keyBu=>$valueBu ) {

				$this->buObj->setItemInfo(array('id'=>$keyBu));
				$bu_name = $this->buObj->displayItemByIdForMSR();

				$business_unit_name = $bu_name['buName'];

				if ( count($this->body_parts['M']) ) {

					foreach ( $this->body_parts['M'] as $valueParts ) {

						$part_name = $this->part_names[$valueParts];

						$data[$part_name]['name'] = $part_name;
						$data[$part_name]['link'] = '?sub_type=middle&part='.$valueParts.'&year='.$selected_year;
						$data[$part_name]['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev
						$data[$part_name]['total'] += (int) $valueBu[$valueParts];

						if ( !in_array($business_unit_name,$business_units) ) {
							$business_units[] = $business_unit_name;
						}
					}
				}
			}
		}


		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {

				$this->data_format->addDataPieLink(array($valuePart['name'],$valuePart['link'],(int) $valuePart['total']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Part of Body Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Middle Body Parts";
		//$this->data_set['xaxis_labels'] = $business_units;
	}

	private function getChildActivityTotal($bu_id,$p_part_id) {

		if ( count($this->org_data[$bu_id]) ) {
			foreach ( $this->org_data[$bu_id] as $key=>$value ) {

				$total_rec += (int) $this->graph_data[$key][$p_part_id];

				if ( count($this->org_data[$key]) ) {
					$total_rec += $this->getChildActivityTotal($key,$p_part_id);
				}
			}
		}

		return $total_rec;

	}

	private function resultSetActivityupperSpecific() {
		$this->activity_type = 'body_part';
		$this->graph_heading = "Upper Body Part ";
		$this->specificPartData();
	}

	private function resultSetActivitylowerSpecific() {
		$this->activity_type = 'body_part';
		$this->graph_heading = "Lower Body Part ";
		$this->specificPartData();
	}
	private function resultSetActivitymiddleSpecific() {
		$this->activity_type = 'body_part';
		$this->graph_heading = "Middle Body Part ";
		$this->specificPartData();
	}

	private function specificPartData() {

		$this->getRecordsForActivity();

		$part_id = $this->filters['part'];
		$sub_type = $this->filters['sub_type'];

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$selected_bu = $this->filters['bu'];
		$selected_bu = $selected_bu == '' ? 0 : $selected_bu;
		$this->org_data = $this->buObj->businessListForGraph(0);
		$activity_type = $this->activity_type;

		$this->graph_data = $this->activity_main_data[$activity_type][$selected_year];

		if ( count($this->org_data[$selected_bu]) ) {
			foreach ( $this->org_data[$selected_bu] as $key=>$value ) {

				$data[$value]['link'] = '?sub_type='.$sub_type.'&part='.$part_id.'&bu='.$key.'&year='.$selected_year;
				$data[$value]['rec'] += (int) $this->graph_data[$key][$part_id];

				if ( count($this->org_data[$key]) ) {

					$total_rec = 0;
					$count = $this->getChildActivityTotal($key,$part_id);
					$data[$value]['rec'] += (int) $count;
				}
			}
		}

		if ( count($data) ) {
			foreach ( $data as $keyPart=>$valuePart ) {
				$this->data_format->addDataPieLink(array($keyPart,$valuePart['link'],(int) $valuePart['rec']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $this->graph_heading." Activity Graph";
		$this->data_set['xaxis_text'] = "";
		$this->data_set['yaxis_text'] = "Business Units";
	}

	private function resultSetActivitynatureSpecific() {
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Nature of injury ";
		$this->activity_type = 'injury';
		$this->specificPartData();
	}

	/* activity nature of injury graph data set*/
	private function resultSetActivitynature() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['injury'][$selected_year];

		//dump_array($graph_data);
		$business_units = array();

		if ( count($this->injuries) ) {
			foreach ( $this->injuries as $valueInjury ) {

				$data = array();
				$injury_name = $this->injury_names[$valueInjury];
				$data['name'] = $injury_name;
				$data['link'] = '?type=nature&year='.$selected_year.'&part='.$valueInjury;
				$data['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'] += (int) $valueBu[$valueInjury];
						}
					}
				}
				//dump_array($data);
				$this->data_format->addDataPieLink(array($data['name'],$data['link'],(int) $data['rec']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Nature of Injury Activity Graph";
	}

	private function resultSetActivitytreatmentSpecific() {
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Type of Treatment ";
		$this->activity_type = 'treatment';
		$this->specificPartData();
	}

	/* activity treatment graph data set*/
	private function resultSetActivitytreatment() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['treatment'][$selected_year];

		$business_units = array();

		if ( count($this->treatments) ) {
			foreach ( $this->treatments as $valueInjury ) {

				$data = array();
				$treatment_name = $this->treatment_names[$valueInjury];
				$data['name'] = $treatment_name;
				$data['link'] = "?type=treatment&year=".$selected_year."&part=".$valueInjury;
				$data['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'] += (int) $valueBu[$valueInjury];
						}
					}
				}
				$this->data_format->addDataPieLink(array($data['name'],$data['link'],(int) $data['rec']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = " Type of Treatment Activity Graph";
	}

	private function resultSetActivityaccidentSpecific() {
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Accident Occured ";
		$this->activity_type = 'accident';
		$this->specificPartData();
	}

	/* activity accident graph data set*/
	private function resultSetActivityaccident() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['accident'][$selected_year];

		//dump_array($graph_data);
		$business_units = array();

		if ( count($this->accidents) ) {
			foreach ( $this->accidents as $valueInjury ) {

				$data = array();
				$treatment_name = $this->accident_names[$valueInjury];
				$data['name'] = $treatment_name;
				$data['link'] = "?type=accident&year=".$selected_year."&part=".$valueInjury;
				$data['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'] += (int) $valueBu[$valueInjury];
						}
					}
				}
				$this->data_format->addDataPieLink(array($data['name'],$data['link'],(int) $data['rec']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Accident Occured Activity Graph";
	}

	private function resultSetActivityimpactSpecific() {
		//
		if ( $this->filters['sub_type'] == '' ) {
			$this->filters['sub_type'] = $this->filters['type'];
		}

		$this->graph_heading = "Impact ";
		$this->activity_type = 'impact';
		$this->specificPartData();
	}

	/* activity impact graph data set*/
	private function resultSetActivityimpact() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['impact'][$selected_year];

		//dump_array($graph_data);

		$impact = SetupGeneric::useModule('ImpactMeasure');
		$impact_records = $impact->displayItems();
		//dump_array($impact_records);

		$business_units = array();

		if ( count($impact_records) ) {
			foreach ( $impact_records as $keyImpact=>$valueImpact ) {

				$data = array();
				//$impact_name = str_replace(' | ',' ',$valueImpact['name']);
				$impact_name = str_replace('<',' ',$valueImpact['name']);
				$impact_name = explode('|',$impact_name);
				$data['name'] = $impact_name[0];
				$data['link'] = "?type=impact&year=".$selected_year."&part=".$valueImpact['ID'];
				$data['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'] += (int) $valueBu[$valueImpact['ID']];
						}
					}
				}
				$this->data_format->addDataPieLink(array($data['name'],$data['link'],(int) $data['rec']));
			}
		}


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Impact Activity Graph";
	}

	/* activity hazard classification graph data set*/
	private function resultSetActivityhazardClass() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['hazard_class'][$selected_year];

		$hazards = SetupGeneric::useModule('HazardClassification');
		$hazard_parents = $hazards->displayCategories();
		//dump_array($graph_data);

		$business_units = array();

		if ( count($hazard_parents) ) {
			foreach ( $hazard_parents as $keyImpact=>$valueImpact ) {

				$data = array();
				$data['name'] = $valueImpact['primaryHazard'];
				$data['link'] = '?type=hazard&year='.$selected_year.'&hazard_id='.$valueImpact['ID'];

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'] += (int) $valueBu[$valueImpact['ID']];
						}
					}
				}
				//dump_array($data);
				$this->data_format->addDataPieLink(array($data['name'],$data['link'],(int) $data['rec']));
			}
		}


		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Hazards Activity Graph";
	}

	/* activity hazards graph data set*/
	private function resultSetActivityhazard() {

		if ( $this->filters['part'] == '' ) {
			$this->resultSetActivityhazardMain();
		} else {
			//
			$this->resultSetActivityhazardChild();
		}
	}

	private function resultSetActivityhazardSpecific() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$hazards = SetupGeneric::useModule('HazardClassification');

		$sub_hazard_id = $this->filters['part'];

		$business_units = array();

		/***/
		$selected_bu = $this->filters['bu'];
		$selected_bu = $selected_bu == '' ? 0 : $selected_bu;
		$this->org_data = $this->buObj->businessListForGraph(0);
		$activity_type = $this->activity_type;

		$this->graph_data = $this->activity_main_data['hazards'][$selected_year];

		//dump_array($this->graph_data);

		if ( count($this->org_data[$selected_bu]) ) {
			foreach ( $this->org_data[$selected_bu] as $key=>$value ) {

				$data[$value]['link'] = "?type=hazard&year=".$selected_year."&hazard_id=".$this->filters['hazard_id']."&part=".$sub_hazard_id."&bu=".$key  ; //'?sub_type='.$sub_type.'&part='.$part_id.'&bu='.$key;
				$data[$value]['rec'] += (int) $this->graph_data[$key][$sub_hazard_id];

				if ( count($this->org_data[$key]) ) {

					$total_rec = 0;
					$count = $this->getChildActivityTotal($key,$sub_hazard_id);
					$data[$value]['rec'] += (int) $count;
				}

				$this->data_format->addDataPieLink(array($value,$data[$value]['link'],(int) $data[$value]['rec']));
			}
		}
		/***/

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Hazards Activity Graph";
	}

	private function resultSetActivityhazardMain() {

		$this->getRecordsForActivity();

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;

		$graph_data = $this->activity_main_data['hazards'][$selected_year];

		$hazards = SetupGeneric::useModule('HazardClassification');

		$hazards->setItemInfo(array(
						'id'=>$this->filters['hazard_id']
						));
		$hazard_records = $hazards->displayItems();
		//dump_array($hazard_records);

		$business_units = array();

		if ( count($hazard_records) ) {
			foreach ( $hazard_records as $keyImpact=>$valueImpact ) {

				$data = array();
				$data['name'] = $valueImpact['secondaryHazard'];
				$data['link'] = "?type=hazard&year=".$selected_year."&hazard_id=".$this->filters['hazard_id']."&part=".$valueImpact['ID'];
				$data['link'] = ''; // not to go to bu level..done on 20 may 2011 by sanjeev

				if ( count($graph_data) ) {
					foreach( $graph_data as $keyBu=>$valueBu ) {

						if ( $keyBu ) {
							$data['rec'] += (int) $valueBu[$valueImpact['ID']];
						}
					}
				}
				//echo $data['name'];
				//dump_array($data);
				$this->data_format->addDataPieLink(array($data['name'],$data['link'],(int) $data['rec']));
			}
		}
		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Hazards Activity Graph";
	}

	private function getChildActionTotal($bu_id) {

		//global $total_rec ;

		if ( count($this->org_data[$bu_id]) ) {
			foreach ( $this->org_data[$bu_id] as $key=>$value ) {

				$total_rec += (int) $this->action_data[$key];

				if ( count($this->org_data[$key]) ) {
					$total_rec += $this->getChildActionTotal($key);
				}
			}
		}

		return $total_rec;

	}

	/* action graph data set*/
	private function resultSetAction() {

		$action_data_array = $this->getNoOfActions();

		$this->org_data = $this->buObj->businessListForGraph(0);
		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];
		$departments = $this->org_data[$bu_id];

		$selected_year = $this->filters['year'];
		$selected_year = $selected_year == '' ? date('Y') : $selected_year;
		$this->action_data = $action_data_array[$selected_year];

		//dump_array($action_data);

		if ( count($departments) ) {
			foreach ( $departments as $key=>$value ) {
				$graph_data['name'] = $value;
				$graph_data['link'] = "?year=".$selected_year."&bu=".$key;
				$graph_data['rec'] = (int) $this->action_data[$key];

				if ( count($this->org_data[$key]) ) {
					$total_rec = "";
					$graph_data['rec'] += $this->getChildActionTotal($key);
				}

				//dump_array($graph_data);
				$this->data_format->addDataPieLink(array($graph_data['name'],$graph_data['link'],(int) $graph_data['rec']));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Action Graph";
	}
}

?>