<?php
 /**
  $Id: investigation.php,v 3.04 Wednesday, January 19, 2011 3:46:27 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Investigation Graph
  * @since  Wednesday, December 01, 2010 1:26:27 PM>
  */
require_once "GraphModuleData.int.php";
require_once "GraphData.abs.php";

class InvestigationGraph extends InvestigationMain implements GraphModuleData {

	private $filter_query;
	private $filters;
	private $data_set;
	private $buObj;

	public function __construct($p_filter_fields) {
		$this->filters = $p_filter_fields;
		$this->setFilter();

		// initialize GraphData class
		$this->data_format = new GraphData();

		// organigram object
		$this->buObj = SetupGeneric::useModule('Organigram');

		parent::__construct();
	}

		/* to set the filetrs for search */
	public function setFilter($filter_fields) {
		$this->filters = $filter_fields;
		//dump_array($filter_fields);
	}

	/**** number of investigations */

	private function resultSet() {

		$data = $this->getNoOfInvestigations();
		$org_data = $this->buObj->businessListForGraph(0);

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$investigation_data = $data[$selected_year];

		function getInvestigationCounts($org_data_array,$valuetoadd=0,$org_data,$investigation_data) {

		//	dump_array($investigation_data);

			if ( count( $org_data_array) ) {

				foreach( $org_data_array as $key=>$value ) {

					if ( $investigation_data[$key] ) {
						$valuetoadd += (int) $investigation_data[$key];
					}
					if ( count($org_data[$key]) ) {
						$valuetoadd = getInvestigationCounts($org_data[$key],$valuetoadd,$org_data,$investigation_data);
						//echo "<br/>";
					}
				}

			}

			return $valuetoadd;
		}

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( count($org_data[$bu_id]) ) {
			foreach( $org_data[$bu_id] as $key=>$value ) {

					if ( count($org_data[$key]) ) {
						//echo $key."<br/>";
						$new2_data[$key] = getInvestigationCounts($org_data[$key],$new2_data[$key],$org_data,$investigation_data);
					}

					$graph_data[$key]['name'] = $value;
					$graph_data[$key]['self_data'] = (int) $investigation_data[$key];
					$graph_data[$key]['child_data'] = (int) $new2_data[$key];
				//}
			}
		}

	//	dump_array($graph_data);

		$graph_heading = $this->filters['bu_name'] == '' ? "Investigation Graph" : $this->filters['bu_name']." - Investigation Graph";

		$graph_heading = $graph_heading.' for '.$selected_year;

		$sql_query = "".$this->filter_query ;

		if ( count($graph_data) ) {
			foreach($graph_data as $key=>$val) {
				$data_arr = array($val['name'],'?year='.$selected_year.'&bu='.$key,($val['self_data']+$val['child_data']));
				$this->data_format->addDataLink($data_arr);
			}
		}


		$this->data_format->getGraphData();

		$yaxis_text = $bu_id == 0 ? 'Company Name' : 'Business Units';

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $graph_heading;
		$this->data_set['xaxis_text'] = "Number of Investigations";
		$this->data_set['yaxis_text'] = $yaxis_text;
		//$this->data_set['xaxis_labels'] = array('Self Investigations','Child Investigations');

	}

	/**** number of investigations */

	private function resultSetPie() {

		$data = $this->getNoOfInvestigations();
		$org_data = $this->buObj->businessListForGraph(0);

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$investigation_data = $data[$selected_year];

		function getInvestigationCounts($org_data_array,$valuetoadd=0,$org_data,$investigation_data) {

		//	dump_array($investigation_data);

			if ( count( $org_data_array) ) {

				foreach( $org_data_array as $key=>$value ) {

					if ( $investigation_data[$key] ) {
						$valuetoadd += (int) $investigation_data[$key];
					}
					if ( count($org_data[$key]) ) {
						$valuetoadd = getInvestigationCounts($org_data[$key],$valuetoadd,$org_data,$investigation_data);
						//echo "<br/>";
					}
				}

			}

			return $valuetoadd;
		}

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( count($org_data[$bu_id]) ) {
			foreach( $org_data[$bu_id] as $key=>$value ) {

					if ( count($org_data[$key]) ) {
						//echo $key."<br/>";
						$new2_data[$key] = getInvestigationCounts($org_data[$key],$new2_data[$key],$org_data,$investigation_data);
					}

					$graph_data[$key]['name'] = $value;
					$graph_data[$key]['self_data'] = (int) $investigation_data[$key];
					$graph_data[$key]['child_data'] = (int) $new2_data[$key];
				//}
			}
		}

		//dump_array($graph_data);

		$graph_heading = $this->filters['bu_name'] == '' ? "Investigation Graph" : $this->filters['bu_name']." - Investigation Graph";

		$graph_heading = $graph_heading.' for '.$selected_year;

		$sql_query = "".$this->filter_query ;

		if ( count($graph_data) ) {
			foreach($graph_data as $key=>$val) {
				$data_arr = array($val['name'],'?year='.$selected_year.'&bu='.$key,(int) ($val['self_data']+$val['child_data']));
				$this->data_format->addDataPieLink($data_arr);
			}
		}
		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $graph_heading;

	}

	/* to export data*/
	public function exportGraphData() {
		if ( $this->filters['type'] == 'pie' ){
			$this->resultSetPie();
		} else {
			$this->resultSet();
		}

		return $this->data_set;
	}
}
?>