<?php
 /**
  $Id: investigation.php,v 3.04 Wednesday, January 19, 2011 3:46:27 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Investigation Graph
  * @since  Wednesday, December 01, 2010 1:26:27 PM>
  */
require_once "GraphModuleData.int.php";
require_once "GraphData.abs.php";

class InvestigationGraph extends NhcInvestigationMain implements GraphModuleData {

	private $filter_query;
	private $filters;
	private $data_set;
	private $buObj;

	public function __construct($p_filter_fields) {
		$this->filters = $p_filter_fields;
		$this->setFilter();

		// initialize GraphData class
		$this->data_format = new GraphData();

		// organigram object
		$this->buObj = SetupGeneric::useModule('Organigram');

		parent::__construct();
	}

		/* to set the filetrs for search */
	public function setFilter($filter_fields) {
		$this->filters = $filter_fields;
		//dump_array($filter_fields);
	}
	
	private function getInvestigationCounts($org_data_array,$investigation_data) {

	//	dump_array($investigation_data);

		if ( count( $this->org_data[$org_data_array]) ) {

			foreach( $this->org_data[$org_data_array] as $key=>$value ) {

				if ( $investigation_data[$key] ) {
					//echo $key."<br/>";
					$this->child_total += (int) $investigation_data[$key];
				}
				if ( count($this->org_data[$key]) ) {
					$this->getInvestigationCounts($key,$investigation_data);
					//echo "<br/>";
				}
			}

		}

		//return $valuetoadd;
	}

	/**** number of investigations */

	private function resultSet() {

		$data = $this->getNoOfInvestigations();
		$this->org_data = $this->buObj->businessListForGraph(0);

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$investigation_data = $data[$selected_year];
		//dump_array($data);

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( count($this->org_data[$bu_id]) ) {
			foreach( $this->org_data[$bu_id] as $key=>$value ) {

					if ( count($this->org_data[$key]) ) {
						$this->child_total = 0;
						$this->getInvestigationCounts($key,$investigation_data);
					}

					$graph_data[$key]['name'] = $value;
					$graph_data[$key]['self_data'] = (int) $investigation_data[$key];
					$graph_data[$key]['child_data'] = (int) $this->child_total;
				//}
			}
		}

		//dump_array($graph_data);

		$graph_heading = $this->filters['bu_name'] == '' ? "Investigation Graph" : $this->filters['bu_name']." - Investigation Graph";

		$graph_heading = $graph_heading.' for '.$selected_year;

		$sql_query = "".$this->filter_query ;

		if ( count($graph_data) ) {
			foreach($graph_data as $key=>$val) {
				$data_arr = array($val['name'],'?year='.$selected_year.'&bu='.$key,($val['self_data']+$val['child_data']));
				$this->data_format->addDataLink($data_arr);
			}
		}


		$this->data_format->getGraphData();

		$yaxis_text = $bu_id == 0 ? 'Company Name' : 'Business Units';

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $graph_heading;
		$this->data_set['xaxis_text'] = "Number of Investigations";
		$this->data_set['yaxis_text'] = $yaxis_text;
		//$this->data_set['xaxis_labels'] = array('Self Investigations','Child Investigations');

	}

	/**** number of investigations */

	private function resultSetPie() {

		$data = $this->getNoOfInvestigations();
		$this->org_data = $this->buObj->businessListForGraph(0);

		$selected_year = $this->filters['year'];
		//$selected_year = '2010';
		$investigation_data = $data[$selected_year];

		$bu_id = $this->filters['bu'] == '' ? 0 : $this->filters['bu'];

		if ( count($this->org_data[$bu_id]) ) {
			foreach( $this->org_data[$bu_id] as $key=>$value ) {

					if ( count($this->org_data[$key]) ) {
						$this->child_total = 0;
						$this->getInvestigationCounts($key,$investigation_data);
					}

					$graph_data[$key]['name'] = $value;
					$graph_data[$key]['self_data'] = (int) $investigation_data[$key];
					$graph_data[$key]['child_data'] = (int) $this->child_total;
				//}
			}
		}

		//dump_array($graph_data);

		$graph_heading = $this->filters['bu_name'] == '' ? "Investigation Graph" : $this->filters['bu_name']." - Investigation Graph";

		$graph_heading = $graph_heading.' for '.$selected_year;

		$sql_query = "".$this->filter_query ;

		if ( count($graph_data) ) {
			foreach($graph_data as $key=>$val) {
				$data_arr = array($val['name'],'?year='.$selected_year.'&bu='.$key,(int) ($val['self_data']+$val['child_data']));
				$this->data_format->addDataPieLink($data_arr);
			}
		}
		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = $graph_heading;

	}

	/* to export data*/
	public function exportGraphData() {
		if ( $this->filters['type'] == 'pie' ){
			$this->resultSetPie();
		} else {
			$this->resultSet();
		}

		return $this->data_set;
	}
}
?>