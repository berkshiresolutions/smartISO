<?php
 /**
  $Id: GraphData.abs.php,v 3.15 Tuesday, January 25, 2011 3:57:02 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Graph Abstract
  * @since  Friday, December 03, 2010 3:43:31 PM>
  */
    class GraphData {
		public $graph_data;
        private $graph_data_array,$array_count;

        public function __construct() {
            $this->graph_data_array = array();
			$this->array_count = 0;
        }

        public function addData($yaxis,$xaxis) {
			$this->graph_data_array[] = array('key'=>$yaxis,'value'=>$xaxis);
        }
		
			public function addDataMultiple1($record_arr) {
		
		//dump_array($record_arr);
		
		//exit;
		
	
			$this->graph_data_array[$this->array_count]['key'] = $record_arr[0];
			//for($i=1;$i<=(count($record_arr)-1);$i++) {
			
			foreach($record_arr as $k=>$v){
			
			//$this->graph_data_array[$this->array_count]['key'] = $record_arr[0];
			//$this->graph_data_array[$this->array_count]['link'] = $record_arr[1];
			//for($i=2;$i<=(count($record_arr)-1);$i++) {
				
			//}
			//$this->array_count++;
			
			//echo $record_arr['0'];
				//if($k != '0'){
				//dump_array($v);
				if($k != '0'){
				$this->graph_data_array[$this->array_count]['values'][$k] = $v;
				}
				
				
				
				
				
			}
				//exit;
			
			$this->array_count++;
		//dump_array($this->graph_data_array);
		//exit;
        }

		public function addDataMultiple($record_arr) {
		
		//dump_array($record_arr);
		
		//exit;
		
	
			//$this->graph_data_array[$this->array_count]['key'] = $record_arr[0];
			//for($i=1;$i<=(count($record_arr)-1);$i++) {
			
			foreach($record_arr as $k=>$v){
			
			//echo $record_arr['0'];
				//if($k != '0'){
				//dump_array($v);
				//if($k == '0'){
				$this->graph_data_array[$k] = $v;
				//}
				
				
				
				
				
			}
				//exit;
			
			$this->array_count++;
		//dump_array($this->graph_data_array);
		//exit;
        }

		public function addDataMultipleLink($record_arr) {
			$this->graph_data_array[$this->array_count]['key'] = $record_arr[0];
			//$this->graph_data_array[$this->array_count]['link'] = $record_arr[1];
			for($i=2;$i<=(count($record_arr)-1);$i++) {
				$this->graph_data_array[$this->array_count]['values']['value'.$i] = $record_arr[$i];
			}
			$this->array_count++;
        }

		public function getGraphData() {
			$this->graph_data = $this->graph_data_array;
		}

		public function clearGraphData() {
			$this->graph_data_array  = "";
		}

		public function addDataPieLink($record_arr) {
			$this->graph_data_array[$this->array_count]['key'] = $record_arr[0];
			//$this->graph_data_array[$this->array_count]['link'] = $record_arr[1];
			$this->graph_data_array[$this->array_count]['value'] = $record_arr[2];
			$this->array_count++;
        }

		public function addDataLink($record_arr) {
			$this->graph_data_array[$this->array_count]['key'] = $record_arr[0];
			//$this->graph_data_array[$this->array_count]['link'] = $record_arr[1];
			$this->graph_data_array[$this->array_count]['value'] = $record_arr[2];
			$this->array_count++;
        }

		public function destroyData() {
			$this->graph_data_array = '';
		}
    }

?>