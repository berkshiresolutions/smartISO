<?php
 /**
  $Id: DashboardGraph.class.php,v 3.32 Wednesday, January 26, 2011 10:53:10 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This class is used for incidence graphs
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Incidence graph data
  * @since  Tuesday, September 28, 2010 6:13:45 PM>
  */

    require_once "GraphModuleData.int.php";
    require_once "GraphData.abs.php";

class DashboardGraph extends Dashboard implements GraphModuleData  {

	private $data_set;
	private $data_format;
	private $dbHand;

	public function __construct($p_filter_fields='') {

		$this->filters = $p_filter_fields;
		$this->setFilter();
		$this->data_format = new GraphData();

	 
$this->dbHand 			= DB::connect(_DB_TYPE);


		parent::__construct();
	}

	/* to set the filetrs for search */
	public function setFilter() {

	}

	public function resultSet() {

	}

	private function getDisplayQauter($p_quater) {

		$current_year = date('Y');
		$current_year = substr($current_year,2,2);
		$next_year = ($current_year+1);

		switch($p_quater) {
			case 1: $disp_qtrs = array('Q1'=>'Q1['.$current_year.'] ','Q2'=>'Q2['.$current_year.'] ','Q3'=>'Q3['.$current_year.'] ','Q4'=>'Q4['.$current_year.'] ',
									  'Q5'=>'Q5['.$next_year.'] '); break;
			case 2: $disp_qtrs = array('Q1'=>'Q1['.$current_year.'] ','Q2'=>'Q2['.$current_year.'] ','Q3'=>'Q3['.$current_year.'] ','Q4'=>'Q4['.$next_year.'] ',
									  'Q5'=>'Q5['.$next_year.'] '); break;
			case 3: $disp_qtrs = array('Q1'=>'Q1['.$current_year.'] ','Q2'=>'Q2['.$current_year.'] ','Q3'=>'Q3['.$next_year.'] ','Q4'=>'Q4['.$next_year.'] ',
									  'Q5'=>'Q5['.$next_year.'] '); break;
			case 4: $disp_qtrs = array('Q1'=>'Q1['.$current_year.'] ','Q2'=>'Q2['.$next_year.'] ','Q3'=>'Q3['.$next_year.'] ','Q4'=>'Q4['.$next_year.'] ',
									  'Q5'=>'Q5['.$next_year.'] '); break;
		}

		return $disp_qtrs;
	}

	private function resultSetRisk() {

		$data			 = $this->getActionsCount('risk');
		$display_quaters = $this->getDisplayQauter($data['currentQuater']);

		if( count($data) ) {
			foreach( $data['pending'] as $key=>$value ) {

				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$value,$data['done'][$key]));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Risk Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');

		//exit;
	}

	private function resultSetInsp() {

		$mod_count['inspectionC']	 = $this->getActionsCount('inspectionC');
		$mod_count['inspectionR']	 = $this->getActionsCount('inspectionR');
		$mod_count['inspectionM']	 = $this->getActionsCount('inspectionM');
		$mod_count['inspectionH']	 = $this->getActionsCount('inspectionH');
		$display_quaters			 = $this->getDisplayQauter($mod_count['inspectionC']['currentQuater']);

		/*$insp_count['inspection']['pending'] = $mod_count['inspectionC']['pending'] + $mod_count['inspectionR']['pending'] + $mod_count['inspectionM']['pending'] + $mod_count['inspectionH']['pending'];
		$insp_count['inspection']['done'] = $mod_count['inspectionC']['done'] + $mod_count['inspectionR']['done'] + $mod_count['inspectionM']['done'] + $mod_count['inspectionH']['done'];
*/
		if( count($mod_count['inspectionC']) ) {
			foreach( $mod_count['inspectionC']['pending'] as $key=>$value ) {
				$pending_total = $value+$mod_count['inspectionR']['pending'][$key]+$mod_count['inspectionM']['pending'][$key]+$mod_count['inspectionH']['pending'][$key];
				$done_total = $mod_count['inspectionC']['done'][$key]+$mod_count['inspectionR']['done'][$key]+$mod_count['inspectionM']['done'][$key]+$mod_count['inspectionH']['done'][$key];

				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$pending_total,$done_total));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Critical Audit Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');

	}

	private function resultSetNonc() {

		$mod_cnt['incidence']	 = $this->getActionsCount('incidence');
		$mod_cnt['investigation'] = $this->getActionsCount('investigation');
		$mod_cnt['nhp']			 = $this->getActionsCount('nhp');
		$display_quaters		 = $this->getDisplayQauter($mod_cnt['incidence']['currentQuater']);
		//

		/*$nc_count['nonc']['pending'] = $mod_cnt['incidence']['pending'] + $mod_cnt['investigation']['pending'] + $mod_cnt['nhp']['pending'] ;
		$nc_count['nonc']['done'] = $mod_cnt['incidence']['done'] + $mod_cnt['investigation']['done'] + $mod_cnt['nhp']['done'] */;

		if( count($mod_cnt['incidence']) ) {
			foreach( $mod_cnt['incidence']['pending'] as $key=>$value ) {
				$pending_total = $value + $mod_cnt['investigation']['pending'][$key] + $mod_cnt['nhp']['pending'][$key];
				$done_total = $mod_cnt['incidence']['done'][$key] + $mod_cnt['investigation']['done'][$key] + $mod_cnt['nhp']['done'][$key];

				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$pending_total,$done_total));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Non-conformance Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetRisk27k() {
		$risk27k_data		 = $this->getActionsCount('risk27k');
		$display_quaters	 = $this->getDisplayQauter($risk27k_data['currentQuater']);

		if( count($risk27k_data) ) {
			foreach( $risk27k_data['pending'] as $key=>$value ) {
				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$value,$risk27k_data['done'][$key]));
			}
		}

		/*$this->data_format->addDataLink(array('Pending','',$risk27k_data['pending']));
		$this->data_format->addDataLink(array('Done','',$risk27k_data['done']));*/

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Risk 27K Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetDse() {

		$data			 = $this->getActionsCount('DSE');
		$display_quaters = $this->getDisplayQauter($data['currentQuater']);

		/*$this->data_format->addDataLink(array('Pending','',$data['pending']));
		$this->data_format->addDataLink(array('Done','',$data['done']));*/

		if( count($data) ) {
			foreach( $data['pending'] as $key=>$value ) {
				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$value,$data['done'][$key]));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "DSE Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetManh() {

		$mod_count['manual_handlingT']	 = $this->getActionsCount('manual_handlingT');
		$mod_count['manual_handlingL']	 = $this->getActionsCount('manual_handlingL');
		$mod_count['manual_handlingE']	 = $this->getActionsCount('manual_handlingE');
		$mod_count['manual_handlingI']	 = $this->getActionsCount('manual_handlingI');
		$display_quaters				 = $this->getDisplayQauter($mod_count['manual_handlingT']['currentQuater']);

		/*$insp_count['inspection']['pending'] = $mod_count['manual_handlingT']['pending'] + $mod_count['manual_handlingL']['pending'] + $mod_count['manual_handlingE']['pending'] + $mod_count['manual_handlingI']['pending'];
		$insp_count['inspection']['done'] = $mod_count['manual_handlingT']['done'] + $mod_count['manual_handlingL']['done'] + $mod_count['manual_handlingE']['done'] + $mod_count['manual_handlingI']['done'];

		$this->data_format->addDataLink(array('Pending','',$insp_count['inspection']['pending']));
		$this->data_format->addDataLink(array('Done','',$insp_count['inspection']['done']));*/

		if( count($mod_count['manual_handlingT']) ) {
			foreach( $mod_count['manual_handlingT']['pending'] as $key=>$value ) {

				$pending_total = $value+$mod_count['manual_handlingL']['pending'][$key]+$mod_count['manual_handlingE']['pending'][$key]+$mod_count['manual_handlingI']['pending'][$key];
				$done_total = $mod_count['manual_handlingT']['done'][$key]+$mod_count['manual_handlingL']['done'][$key]+$mod_count['manual_handlingE']['done'][$key]+$mod_count['manual_handlingI']['done'][$key];

				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$pending_total,$done_total));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Manual Handling Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');

	}

	private function resultSetSlaw() {

		$data			 = $this->getActionsCount('SLAW');
		$display_quaters = $this->getDisplayQauter($data['currentQuater']);

		if( count($data) ) {
			foreach( $data['pending'] as $key=>$value ) {
				$this->data_format->addDataMultipleLink(array($display_quaters[$key],'',$value,$data['done'][$key]));
			}
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Law Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetCntr() {

		$quaters = $this->getDashboardQauters();
		$current_quater = $this->getCurrentQauter();
		$display_quaters = $this->getDisplayQauter($current_quater);

		$pending_recs = array('Q1'=>0,'Q2'=>0,'Q3'=>0,'Q4'=>0,'Q5'=>0);
		$done_recs = array('Q1'=>0,'Q2'=>0,'Q3'=>0,'Q4'=>0,'Q5'=>0);


		$sql = "SELECT * FROM %s.cms_documents_contributors WHERE passed = '0'";

		$sql_p = sprintf($sql,_DB_OBJ_FULL);
		$pending = $this->dbHand->prepare($sql_p);
		$pending->execute();
		$pending_records = $pending->fetchAll(PDO::FETCH_ASSOC);

		if ( count($pending_records) ) {
			foreach ( $pending_records as $record ) {

				foreach ( $quaters as $key=>$valueqt ) {

					if ( $record['contribDueDate'] >= $valueqt[0] && $record['contribDueDate'] < $valueqt[1] ) {

						$pending_recs[$key]++;

					}
				}

			}
		}

		$sql2 = "SELECT * FROM %s.cms_documents_contributors WHERE passed != '0'";
		$sql_d = sprintf($sql2,_DB_OBJ_FULL);
		$done = $this->dbHand->prepare($sql_d);
		$done->execute();
		$done_records = $done->fetchAll(PDO::FETCH_ASSOC);

		if ( count($done_records) ) {
			foreach ( $done_records as $record ) {

				foreach ( $quaters as $key=>$valueqt ) {

					if ( $record['contribDueDate'] >= $valueqt[0] && $record['contribDueDate'] < $valueqt[1] ) {

						$done_recs[$key]++;

					}
				}

			}
		}

		foreach ( $pending_recs as $qtr=>$val ) {

			$this->data_format->addDataMultipleLink(array($display_quaters[$qtr],'',$val,$done_recs[$qtr]));
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Contributor Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetDoc() {

		$quaters = $this->getDashboardQauters();
		$current_quater = $this->getCurrentQauter();
		$display_quaters = $this->getDisplayQauter($current_quater);

		$pending_recs = array('Q1'=>0,'Q2'=>0,'Q3'=>0,'Q4'=>0,'Q5'=>0);
		$done_recs = array('Q1'=>0,'Q2'=>0,'Q3'=>0,'Q4'=>0,'Q5'=>0);

		$sql = "SELECT * FROM %s.cms_documents WHERE isGapDocument='0' AND status = 'U'";

		$sql_p = sprintf($sql,_DB_OBJ_FULL);
		$pending = $this->dbHand->prepare($sql_p);
		$pending->execute();
		$pending_records = $pending->fetchAll(PDO::FETCH_ASSOC);

		if ( count($pending_records) ) {
			foreach ( $pending_records as $record ) {

				foreach ( $quaters as $key=>$valueqt ) {

					if ( $record['dateInitiated'] >= $valueqt[0] && $record['dateInitiated'] < $valueqt[1] ) {

						$pending_recs[$key]++;

					}
				}

			}
		}

		$sql2 = "SELECT * FROM %s.cms_documents WHERE isGapDocument='0' AND status != 'U'";
		$sql_d = sprintf($sql2,_DB_OBJ_FULL);
		$done = $this->dbHand->prepare($sql_d);
		$done->execute();
		$done_records = $done->fetchAll(PDO::FETCH_ASSOC);

		if ( count($done_records) ) {
			foreach ( $done_records as $record ) {

				foreach ( $quaters as $key=>$valueqt ) {

					if ( $record['dateInitiated'] >= $valueqt[0] && $record['dateInitiated'] < $valueqt[1] ) {

						$done_recs[$key]++;

					}
				}

			}
		}

		foreach ( $pending_recs as $qtr=>$val ) {

			$this->data_format->addDataMultipleLink(array($display_quaters[$qtr],'',$val,$done_recs[$qtr]));
		}

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Documents Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetGap() {

		$quaters = $this->getDashboardQauters();
		$current_quater = $this->getCurrentQauter();
		$display_quaters = $this->getDisplayQauter($current_quater);

		$pending_recs = array('Q1'=>0,'Q2'=>0,'Q3'=>0,'Q4'=>0,'Q5'=>0);
		$done_recs = array('Q1'=>0,'Q2'=>0,'Q3'=>0,'Q4'=>0,'Q5'=>0);

		$sql = "SELECT * FROM %s.cms_documents WHERE isGapDocument='1' AND status = 'U'";

		$sql_p = sprintf($sql,_DB_OBJ_FULL);
		$pending = $this->dbHand->prepare($sql_p);
		$pending->execute();
		$pending_records = $pending->fetchAll(PDO::FETCH_ASSOC);

		if ( count($pending_records) ) {
			foreach ( $pending_records as $record ) {

				foreach ( $quaters as $key=>$valueqt ) {

					if ( $record['dateInitiated'] >= $valueqt[0] && $record['dateInitiated'] < $valueqt[1] ) {

						$pending_recs[$key]++;

					}
				}

			}
		}

		$sql2 = "SELECT * FROM %s.cms_documents WHERE isGapDocument='1' AND status != 'U'";
		$sql_d = sprintf($sql2,_DB_OBJ_FULL);
		$done = $this->dbHand->prepare($sql_d);
		$done->execute();
		$done_records = $done->fetchAll(PDO::FETCH_ASSOC);

		if ( count($done_records) ) {
			foreach ( $done_records as $record ) {

				foreach ( $quaters as $key=>$valueqt ) {

					if ( $record['dateInitiated'] >= $valueqt[0] && $record['dateInitiated'] < $valueqt[1] ) {

						$done_recs[$key]++;

					}
				}

			}
		}

		foreach ( $pending_recs as $qtr=>$val ) {

			$this->data_format->addDataMultipleLink(array($display_quaters[$qtr],'',$val,$done_recs[$qtr]));
		}

		/*$this->data_format->addDataLink(array('Pending','',$pending_records_count));
		$this->data_format->addDataLink(array('Done','',$done_records_count));*/

		$this->data_format->getGraphData();

		$this->data_set['chart_data'] = $this->data_format->graph_data;
		$this->data_set['heading'] = "Gap Filling Actions";
		$this->data_set['xaxis_text'] = "Number of Actions";
		$this->data_set['xaxis_labels'] = array('Pending','Done');
	}

	private function resultSetModSpecific() {

	}

/* to export data*/
	public function exportGraphData($p_type='') {

		$this->data_format->graph_data = '';
		$this->data_set = '';
		$this->data_format->destroyData();
		$method = "resultSet".ucwords($p_type);
		$this->$method();

		return $this->data_set;
	}
}
?>