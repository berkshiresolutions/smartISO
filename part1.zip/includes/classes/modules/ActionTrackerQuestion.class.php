<?php
 /**
  $Id: ActionTrackerRisk.class.php,v 3.43 Wednesday, January 26, 2011 6:09:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerQuestion extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;
        
            public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
		$this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID where modulename='Context'  and A.status=1  and currentWho=%d and approveAU=0
   						ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
		$this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID where modulename='Context' and A.who=%d and approveAU=1
  							ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();

  /*      select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.ID from actions A  left join context_action C on A.record=C.ID  left join context S on C.c_id=S.ID 
where modulename='Context'   and approveAU=0 and not currentWho=2
							ORDER BY S.ID DESC*/

        if (isAdministrator()) {
					$this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID  where modulename='Context'  and A.status=1   and approveAU=0 and not currentWho=%d
							ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
                       		$this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.ID from %s.actions A left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID where modulename='Context'  and A.status=1   and approveAU=0 and whoAU=%d
							ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {
	        
			$this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID  where modulename='Context'  and approveAU=1 and not A.who=%d
							ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
        			 $this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID  where modulename='Context'  and approveAU=1 and whoAU=%d
							ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }
       
        return $this->getActionsByFilter(__METHOD__);
    }

    	        public function getTotalActions($data) {
$startdate=$data["startdate"];
$enddate=$data["enddate"];
$who =$data["who"];
$completed=(int)$data["completed"];

$startStr="";
$endStr="";    
$whoStr="";

if ($startdate)
    $startStr=" and duedate>='".format_date_for_mysql($startdate)."' ";
if ($enddate)
    $endStr=" and duedate<='".format_date_for_mysql($enddate)."' ";
if ($who)
    $whoStr=" and A.who=".$who." ";
  
$this->sql_query = sprintf("select A.id,S.reference,S.bu,S.title,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.ID from %s.actions A  left join %s.context_action C on A.record=C.ID  left join %s.context S on C.c_id=S.ID  where modulename='Context'  and A.status=1   and approveAU=%d %s %s %s
							ORDER BY S.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,$completed,$startStr,$endStr,$whoStr);
 
             
        return $this->getActionsByFilter(__METHOD__);
    }
    private function getActionsByFilter($p_callingMethod) {

        $USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
        //echo $calling_method;

        $pStatement = $this->dbHand->prepare($this->sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
}