<?php
 /**
  $Id: Equipment.class.php,v 3.16 Monday, January 17, 2011 1:46:11 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, December 17, 2010 4:27:41 PM>
  */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';
class Equipment {

	/*
	 * property to hold database object
	 *
	 * access private
	*/
	private $dbHand;

	/*
	 * property to hold equipment id
	 *
	 * @access private
	*/
	private $equipmentId;

	/*
	 * property to hold equipment info
	*/
	private $equipmentInfo;
	private $lastRecordId;

	public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
	}

	public function setEquipmentInfo( $equipment_id, $equipment_info ) {

		$this->equipmentId		= $equipment_id;
		$this->equipmentInfo	= $equipment_info;
	}

	/*
	 * This method is used to manage client details
	 *
	 * @access public
	*/
	public function manageClientDetails() {

		$already_exists = false;

		$sql = sprintf("SELECT COUNT(*) FROM %s.equipment_client_details WHERE clientReference = '".$this->equipmentInfo['reference']."'",_DB_OBJ_FULL);

		if ( $res = $this->dbHand->query($sql) ) {

			if ( $res->fetchColumn() > 0 ) {

				$already_exists = true;
			}
		}

		$res = NULL;
		$already_exists = false;

		if ( $already_exists ) {

			throw new ErrorException("This reference number already exists.");

		} else {

			$reference_filter	= '';

			if ( $this->equipmentInfo['task'] == 'add' ) {

				$reference_filter	= " clientReference = '".$this->equipmentInfo['reference']."',";
			}

			$this->equipmentInfo['date_sent'] = $this->equipmentInfo['date_sent'] == '' ? '01/01/1900' : $this->equipmentInfo['date_sent'];
			$this->equipmentInfo['date_returned'] = $this->equipmentInfo['date_returned'] == '' ? '01/01/1900' : $this->equipmentInfo['date_returned'];

			$sql2 = sprintf("UPDATE %s.equipment_client_details
										SET ".$reference_filter." assetTag = '%s',
										location = %d,
										businessUnit = %d,
										contactName = '%s',
										contactNumber = '%s',
										contactEmail = '%s',
										predictedCost = %f,
										actualCost = %f,
										dateSent = '%s',
										dateReturned = '%s'
									WHERE equipId = %d",_DB_OBJ_FULL, smartisoAddslashes($this->equipmentInfo['asset_tag']), $this->equipmentInfo['location'],
									$this->equipmentInfo['business_unit'], smartisoAddslashes($this->equipmentInfo['contact_name']),
									$this->equipmentInfo['contact_number'], $this->equipmentInfo['contact_email'], $this->equipmentInfo['predicted_cost'],
									$this->equipmentInfo['actual_cost'], format_date_for_mysql($this->equipmentInfo['date_sent']),
									format_date_for_mysql($this->equipmentInfo['date_returned']), $this->equipmentId);

			/*echo $sql2;
			exit*/;

			$stmt = $this->dbHand->prepare($sql2);

			/*$stmt->bindParam(1, $this->equipmentInfo['asset_tag']);
			$stmt->bindParam(2, $this->equipmentInfo['location']);
			$stmt->bindParam(3, $this->equipmentInfo['business_unit']);
			$stmt->bindParam(4, $this->equipmentInfo['contact_name']);
			$stmt->bindParam(5, $this->equipmentInfo['contact_number']);
			$stmt->bindParam(6, $this->equipmentInfo['contact_email']);
			$stmt->bindParam(7, $this->equipmentInfo['predicted_cost']);
			$stmt->bindParam(8, $this->equipmentInfo['actual_cost']);
			$stmt->bindParam(9, format_date_for_mysql( $this->equipmentInfo['date_sent'] ));
			$stmt->bindParam(10, format_date_for_mysql( $this->equipmentInfo['date_returned'] ));
			$stmt->bindParam(11, $this->equipmentId);*/

			$stmt->execute();

		}
	}

	/*
	*/
	public function displayClientDetailsByEquipId() {

		$sql = sprintf("SELECT * FROM %s.equipment_client_details WHERE equipId = %d",_DB_OBJ_FULL, $this->equipmentId);
		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1, $this->equipmentId);

		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}
	public function action_data() {

		 $sql = sprintf("SELECT R.*,B.buName FROM %s.equipments R 
		 LEFT JOIN %s.business_units B on R.businessUnit=B.buID
				WHERE R.equipID  = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$this->equipmentId);
		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1, $this->equipmentId);

		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		//dump_array($result);
		return $result;
	}

	/*
	 * This method manages contact details for maintenance & calibration
	 *
	 * @access public
	*/
	public function manageContactsOld() {

		/*echo "UPDATE equipment_contacts SET
											maintenanceDueDate = '".format_date_time_for_mysql( $this->equipmentInfo['maintenance_due_date'] )."',
											maintenanceContactName = '".$this->equipmentInfo['maintenance_contact_name']."',
											maintenanceContactNumber = '".$this->equipmentInfo['maintenance_contact_number']."',
											maintenanceCompetence = '".$this->equipmentInfo['maintenance_competence']."',
											maintenancePredictedCost = '".$this->equipmentInfo['maintenance_predicted_cost']."',
											maintenanceActualCost = '".$this->equipmentInfo['maintenance_actual_cost']."',
											calibrationDueDate = '".format_date_time_for_mysql( $this->equipmentInfo['calibration_due_date'] )."',
											calibrationContactName = '".$this->equipmentInfo['calibration_contact_name']."',
											calibrationContactNumber = '".$this->equipmentInfo['calibration_contact_number']."',
											calibrationCompetence = '".$this->equipmentInfo['calibration_competence']."',
											calibrationPredictedCost = '".$this->equipmentInfo['calibration_predicted_cost']."',
											calibrationActualCost = '".$this->equipmentInfo['calibration_actual_cost']."'
											WHERE equipId = ".$this->equipmentId." AND
											contactType = '".$this->equipmentInfo['contact_type']."'";*/

		$sql = sprintf("UPDATE %s.equipment_contacts SET
											maintenanceDueDate = '%s',
											maintenanceContactName = '%s',
											maintenanceContactNumber = '%s',
											maintenanceCompetence = '%s',
											maintenancePredictedCost = %f,
											maintenanceActualCost = %f,
											calibrationDueDate = '%s',
											calibrationContactName = '%s',
											calibrationContactNumber = '%s',
											calibrationCompetence = '%s',
											calibrationPredictedCost = %f,
											calibrationActualCost = %f
											WHERE equipId = %d AND contactType = '%s' ",_DB_OBJ_FULL,
											format_date_time_for_mysql($this->equipmentInfo['maintenance_due_date']), smartisoAddslashes($this->equipmentInfo['maintenance_contact_name']),
											$this->equipmentInfo['maintenance_contact_number'],smartisoAddslashes($this->equipmentInfo['maintenance_competence']),
											$this->equipmentInfo['maintenance_predicted_cost'], $this->equipmentInfo['maintenance_actual_cost'],
											format_date_time_for_mysql($this->equipmentInfo['calibration_due_date']),
											smartisoAddslashes($this->equipmentInfo['calibration_contact_name']),$this->equipmentInfo['calibration_contact_number'],
											smartisoAddslashes($this->equipmentInfo['calibration_competence']),$this->equipmentInfo['calibration_predicted_cost'],
											$this->equipmentInfo['calibration_actual_cost'], $this->equipmentId, $this->equipmentInfo['contact_type']);

		$stmt = $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1, format_date_time_for_mysql($this->equipmentInfo['maintenance_due_date']));
		$stmt->bindParam(2, $this->equipmentInfo['maintenance_contact_name']);
		$stmt->bindParam(3, $this->equipmentInfo['maintenance_contact_number']);
		$stmt->bindParam(4, $this->equipmentInfo['maintenance_competence']);
		$stmt->bindParam(5, $this->equipmentInfo['maintenance_predicted_cost']);
		$stmt->bindParam(6, $this->equipmentInfo['maintenance_actual_cost']);
		$stmt->bindParam(7, format_date_time_for_mysql($this->equipmentInfo['calibration_due_date']));
		$stmt->bindParam(8, $this->equipmentInfo['calibration_contact_name']);
		$stmt->bindParam(9, $this->equipmentInfo['calibration_contact_number']);
		$stmt->bindParam(10, $this->equipmentInfo['calibration_competence']);
		$stmt->bindParam(11, $this->equipmentInfo['calibration_predicted_cost']);
		$stmt->bindParam(12, $this->equipmentInfo['calibration_actual_cost']);
		$stmt->bindParam(13, $this->equipmentId);
		$stmt->bindParam(14, $this->equipmentInfo['contact_type']);*/

		$stmt->execute();
		//dump_array($this);
		//dump_array($stmt->errorInfo());

	}

	public function manageContacts() {

		$sql = sprintf("UPDATE %s.equipment_contacts SET contactType = '%s',
												contactName = '%s',
												contactEmail = '%s',
												contactNumber = '%s',
												competenceEvidence = '%s' WHERE equipId = %d",_DB_OBJ_FULL,
												$this->equipmentInfo['contact_type'],$this->equipmentInfo['contact_name'],
												$this->equipmentInfo['contact_email'],$this->equipmentInfo['contact_number'],
												$this->equipmentInfo['competence'],$this->equipmentId);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();

	}
	
	public function viewActionMain() {
	
	

		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

		$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'equipmentM'",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}

	/**
	 * This method is used to add Maintenance/Calibration data.
	*/
	public function addMaintenanceCalibrationData() {

		$objOrg				= SetupGeneric::useModule('Organigram');
		$whoAUarr=$objOrg->getManager($this->equipmentInfo['whoID']);
		if(!$whoAUarr){
                                $participantObj = SetupGeneric::useModule('Participant');
                $details = $participantObj->getAdminDetails();
                $whoAUarr['participantID']=$details["participantID"];
                }
                

	
/*		
if ($this->equipmentInfo['job_type']=='M')
		$sql = "update %s.equipments set maintenanceduedate= '%s' where equipID=%d and maintenanceduedate is NULL"; 
	else
		$sql = "update %s.equipments set calibrationduedate= '%s' where equipID=%d and calibrationduedate is NULL";

		$psql = sprintf($sql,_DB_OBJ_FULL,format_date_for_mysql($this->equipmentInfo['due_date']),$this->equipmentId);
		$stmt	= $this->dbHand->prepare($psql);
		$stmt->execute();
*/


		$sql = "INSERT INTO %s.maintenance_calibration_data (equipId,jobType,type,nature,competenceRequired,notes,period,periodType,dueDate,contactType,contactName,contactEmail,
				contactNumber,competenceEvidence,productType,partNo,manufacturer,productDescription,whoAU,mType,whoID,whoAUID)
				VALUES (%d, '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',%d,%d)";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentId,$this->equipmentInfo['job_type'],$this->equipmentInfo['type'],$this->equipmentInfo['nature'],$this->equipmentInfo['competence_required'],
						$this->equipmentInfo['notes'],$this->equipmentInfo['period'],$this->equipmentInfo['period_type'],format_date_for_mysql($this->equipmentInfo['due_date']),$this->equipmentInfo['contact_type'],
						$this->equipmentInfo['contact_name'],$this->equipmentInfo['contact_email'],$this->equipmentInfo['contact_number'],$this->equipmentInfo['competence_evidence'],
						$this->equipmentInfo['product_type'], $this->equipmentInfo['part_no'], $this->equipmentInfo['manufacturer'], $this->equipmentInfo['product_description'], $this->equipmentInfo['who_AU'], $this->equipmentInfo['main'],$this->equipmentInfo['whoID'],$whoAUarr['participantID']);


		$stmt	= $this->dbHand->prepare($psql);
		$stmt->execute();

		//$this->lastRecordId	= $this->dbHand->lastInsertId();
		$this->lastRecordId	= customLastInsertId($this->dbHand,'maintenance_calibration_data','id');
		if ($this->equipmentInfo['job_type'] =='M'){
			$module="EquipmentM";
			$description="Equipment Maintenance to be carried out on ".$this->equipmentInfo['desc'];
			$url='Please <a href="http://'.$_SERVER['HTTP_HOST'].'/equipment/perform_maintenance_calibration.php?task=add&eid='.$this->equipmentId.'">CLICK</a> Here to carry out Equipment Maintenance<BR>';
			$title="Smart-ISO Equipment Maintenance";
		}
		else
		{		
			$module="EquipmentC";
			$description="Equipment Calibration to be carried out on ".$this->equipmentInfo['desc'];	
			$url='Please <a href="http://'.$_SERVER['HTTP_HOST'].'/equipment/perform_maintenance_calibration.php?task=add&eid='.$this->equipmentId.'">CLICK</a> Here to carry out Equipment Calibration<BR>';
			$title="Smart-ISO Equipment Calibration";
		}

	$file_id=array_filter(explode(",",$this->equipmentInfo['doc_id']));
$objFile = new Upload();
if( count($file_id)>0){
$url.="<BR>Documents<BR>";	
foreach($file_id as $filedata){
$objFile->setFileInfo('equipment',array('id'=>$filedata));
	$file_detail = $objFile->getFileDetails();	

	$url.= '<a href="http://'.$_SERVER['HTTP_HOST'].'/download_file.php?fn='.$file_detail['sysFilename'].'&un='.$file_detail['usrFilename'].'&module=equipment">View&nbsp;</a>'.$file_detail['usrFilename'].'<BR>';
	
}	
}

		$actionHandling	= new Action();
		//get manager for actions

	//	$actionData = array('module_name'=>$module,'description'=>$description,'who'=>$this->equipmentInfo['whoID'],'whoAU'=>$whoAUarr["participantID"],'due_date'=>$this->equipmentInfo['due_date']);
		
            $actionData = array('description' => $description,
            'who' => $this->equipmentInfo['whoID'],
            'whoAU' => $whoAUarr["participantID"],
            'who2AU' => 0,
            'module_name' => $module,
            'record' => $this->equipmentId,
            'status' => 1,
            'buname' => $bu["buName"],
            'currentwho' => $this->equipmentInfo['whoID'],
            'element' => "assestmangement",
            'due_date' => $this->equipmentInfo['due_date']);
                
                $actionHandling->setActionDetails(0,$actionData);
		$new_action_id = $actionHandling->addAction2015();
                
                
		//$actionHandling->updateRecord($new_action_id,$this->equipmentId,"equipments");
		
		$data=array('singleColData'=>array('click-here-url'=>$url),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>$this->equipmentInfo['reference'])));		
		$emailObj =	new actionEmailHelper($new_action_id);	
		$whoarr=$emailObj->getwhoDetails();
		$emailObj->appendInfo($data);
		$emailObj->sendEmail($title,$whoarr,array(),array(),'me_completed','','grey');


	}
	
	public function countMaintenanceAction($id) {
			$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	 	$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'equipmentM' AND who = ".$this->id." AND doneDate is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function countCalibrationAction($id) {
			$this->id = $id;
		//$sql = sprintf("SELECT * FROM %s.vehicle WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->vehicleInfo['archive']);

	 	$sql = sprintf("SELECT * FROM %s.actions WHERE moduleName = 'equipmentC' AND who = ".$this->id." AND doneDate is NULL",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->vehicleInfo['archive']);
		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		
		return $resultSet;
	}
	
	public function addActionequip(){
	
	$sql = "INSERT INTO %s.equipment_action (eId,maP,maD,caP,caD) VALUES(".$this->equipmentId.",'".$this->equipmentInfo['due_date']."','','','')";
	$psql = sprintf($sql,_DB_OBJ_FULL);
	$stmt	= $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	public function getLastInsertedId() {
		return $this->lastRecordId;
	}

	/**
	 * This method is used to edit Maintenance/Calibration data.
	*/
	public function editMaintenanceCalibrationData() {


		if ( $this->equipmentInfo['record_id'] != 0 ) {

			$sql = "UPDATE %s.maintenance_calibration_data SET type = '%s', nature = '%s', competenceRequired = '%s', notes = '%s', period = %d, periodType = '%s', dueDate = '%s',
									contactType = '%s', contactName = '%s', contactEmail = '%s', contactNumber = '%s', competenceEvidence = '%s',productType = '%s', partNo = '%s',
									manufacturer = '%s', productDescription = '%s', whoID = '%s' , whoAU = '%s', mType = '%s', docIDvalues = '%s' WHERE id = %d";

			$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['type'],$this->equipmentInfo['nature'],$this->equipmentInfo['competence_required'],$this->equipmentInfo['notes'],
							$this->equipmentInfo['period'],$this->equipmentInfo['period_type'],format_date_for_mysql($this->equipmentInfo['due_date']),$this->equipmentInfo['contact_type'],
							$this->equipmentInfo['contact_name'],$this->equipmentInfo['contact_email'],$this->equipmentInfo['contact_number'],$this->equipmentInfo['competence_evidence'],
							$this->equipmentInfo['product_type'], $this->equipmentInfo['part_no'], $this->equipmentInfo['manufacturer'], $this->equipmentInfo['product_description'],$this->equipmentInfo['whoID'], $this->equipmentInfo['who_AU'],  $this->equipmentInfo['main'],  $this->equipmentInfo['file'], $this->equipmentInfo['record_id']);

			$stmt = $this->dbHand->prepare($psql);
			$stmt->execute();
		} else {
			$this->addMaintenanceCalibrationData();
		}
               
	}

	/**
	 * This method updates uploaded file id.
	*/
	public function updateFileId() {

		 $sql = "UPDATE %s.maintenance_calibration_data SET docID = '%s' WHERE id = %d";

		 $psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['file_id'],$this->equipmentId);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	
	public function updateActionId() {

		 $sql = "UPDATE %s.maintenance_calibration_data SET actionID = %d WHERE id = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['file_id'],$this->equipmentId);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	/**
	 * This method displays maintenance/calibration data.
	*/
	public function displayMaintenanceCalibrationData() {

		if ( $this->equipmentInfo['job_type'] ) {
			$sql = "SELECT * FROM %s.maintenance_calibration_data WHERE equipId = %d AND jobType = '%s'";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id'],$this->equipmentInfo['job_type']);
		} else {
			$sql = "SELECT * FROM %s.maintenance_calibration_data WHERE equipId = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id']);
		}


		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		$result_ready = array();

		foreach ( $result as $result_ele ) {

			$cdata = $this->displayConsumablesByCMId($result_ele['id']);

			$result_ele['consumables'] 	= $cdata['consumables'];
			$result_ele['quantity'] 	= $cdata['quantity'];
			$result_ele['typeID'] 		= $cdata['typeID'];
			$result_ele['identifier']	= $cdata['ID'];

			$result_ready[$result_ele['jobType']][] = $result_ele;
		}

		return $result_ready;
	}

	
	/**
	 * This method displays maintenance/calibration data by Id.
	*/
	public function displayMaintCalDataById() {

		$sql = "SELECT * FROM %s.maintenance_calibration_data WHERE id = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentId);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		return $result;
	}

	/**
	 * This method deletes maintenance/calibration record from db.
	*/
	public function deleteMaintenanceCalibrationDataById() {

		$sql = "DELETE FROM %s.maintenance_calibration_data WHERE id = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentId);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	public function deleteMaintCalDataByEquipId() {

		$objUpload = new Upload();

		$result = $this->displayMaintenanceCalibrationData();

		foreach ( $result as $element ) {

			$doc_id = $element['docID'];

			$objUpload->setFileInfo('equipment',array('id'=>$doc_id,'destination'=>'equipment'));
			$objUpload->delete_file();
		}

		$objUpload = NULL;

		$sql = "DELETE FROM %s.maintenance_calibration_data WHERE equipId = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	public function deleteEquipment() {

		$objEquip = SetupGeneric::useModule('Equipment');

		$objEquip->setItemInfo(array('id'=>$this->equipmentInfo['equip_id']));
		$objEquip->deleteItem();

		$this->deleteMaintCalDataByEquipId();
		$this->deleteActivityData();

		$objEquip = NULL;
	}

	public function archiveEquipment() {

		$sql = "UPDATE %s.assestMangement SET archive = %d WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['archive'],$this->equipmentId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	public function archiveEquipment1Deprecated() {

		$sql = "UPDATE %s.assestMangement SET archive = '%s' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['archive'],$this->equipmentId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
		public function archiveEquipment7() {

		$sql = "UPDATE %s.material SET archive = '%s' WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['archive'],$this->equipmentId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}
	

	/**
	 * This method adds maintenance/calibration activity to db.
	*/
	public function addActivity() {

$this->equipmentId=$this->equipmentInfo['equip_id'];
	 	$sql = "INSERT INTO %s.maintenance_calibration_records (equipID,dateSent,maintenanceDueDate,calibrationDueDate,contactName,dateReturned,cost,jobDone,workDescription,reason) VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s')";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id'],format_date_for_mysql($this->equipmentInfo['date_sent']),
						format_date_for_mysql($this->equipmentInfo['m_due_date']),format_date_for_mysql($this->equipmentInfo['c_due_date']),$this->equipmentInfo['contact_name'],format_date_for_mysql($this->equipmentInfo['date_returned']),$this->equipmentInfo['cost'],$this->equipmentInfo['job_done'],$this->equipmentInfo['work_description'],$this->equipmentInfo['job_reason']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$this->lastRecordId	= customLastInsertId($this->dbHand,'maintenance_calibration_records','ID');

		
		$reference=$this->equipmentInfo['reference'];
		$title=$this->equipmentInfo['title'];
		$actionTracker	= new ActionTracker();
                $dataMtype=explode(",",$this->equipmentInfo['job_done']);


if (in_array("M",$dataMtype))
{
    $sql = "update %s.maintenance_calibration_data set DueDate='%s' where equipID=%d and jobType='M'";
	$psql = sprintf($sql,_DB_OBJ_FULL,format_date_for_mysql($this->equipmentInfo['m_due_date']),$this->equipmentInfo['equip_id']);
			$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();	

$this->equipmentId=$this->equipmentInfo['equip_id'];
 	$actiondata=$this->getActionsID("M");
	$this->approveActions("M",$actiondata["who"]);
	$actionTracker->sendEquipmentAUemail($actiondata["ID"],"Maintenance",$reference,$title);

	$this->addPerformAction("M",format_date($this->equipmentInfo['m_due_date']),$reference,$actiondata["whoAU"],$title);
}

//if (strpos($this->equipmentInfo['job_done'],"C") !== false)
if (in_array("C",$dataMtype))
{
       $sql = "update %s.maintenance_calibration_data set DueDate='%s' where equipID=%d and jobType='C'";
		$psql = sprintf($sql,_DB_OBJ_FULL,format_date_for_mysql($this->equipmentInfo['c_due_date']),$this->equipmentInfo['equip_id']);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
                
$this->equipmentId=$this->equipmentInfo['equip_id'];
  	$actiondata=$this->getActionsID("C");

	$this->approveActions("C",$actiondata["who"]);
	$actionTracker->sendEquipmentAUemail($actiondata["ID"],"Calibration",$reference,$title);

	$this->addPerformAction("C",format_date($this->equipmentInfo['c_due_date']),$reference,$actiondata["whoAU"],$title);
}		
	



		
	}

	public function editActivity() {

		$sql = "UPDATE %s.maintenance_calibration_records SET dateSent = '%s', maintenanceDueDate = '%s',calibrationDueDate = '%s', contactName = '%s',dateReturned = '%s',cost = '%s',jobDone = '%s',workDescription = '%s',mileage = '%s',mainT = '%s' WHERE equipID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,format_date_for_mysql($this->equipmentInfo['date_sent']),
						format_date_for_mysql($this->equipmentInfo['m_due_date']),format_date_for_mysql($this->equipmentInfo['c_due_date']),$this->equipmentInfo['contact_name'],format_date_for_mysql($this->equipmentInfo['date_returned']),$this->equipmentInfo['cost'],$this->equipmentInfo['job_done'],$this->equipmentInfo['work_description'],$this->equipmentInfo['mileage'],$this->equipmentInfo['main'],$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
		//$a = $stmt->errorInfo();

	}

	public function manageActivityRecord() {

		$sql = "UPDATE %s.maintenance_calibration_records SET dateReturned = '%s', cost = %f, jobDone = '%s', consumables = '%s', workDescription = '%s'
				WHERE equipID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,format_date_for_mysql($this->equipmentInfo['date_returned']),$this->equipmentInfo['cost'],
						$this->equipmentInfo['job_done'],$this->equipmentInfo['consumables'],$this->equipmentInfo['work_description'],
						$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	public function displayActivityById() {

		$sql = "SELECT * FROM %s.maintenance_calibration_records WHERE equipID = %d order by Id desc";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		return $result;
	}

	public function displayMostRecentActivityById() {

		if ( _DB_TYPE == 'mysql' ) {
			$sql = "SELECT * FROM %s.maintenance_calibration_records WHERE equipID = %d ORDER BY ID DESC LIMIT 1";
		} else {
			$sql = "SELECT TOP 1 * FROM %s.maintenance_calibration_records WHERE equipID = %d ORDER BY ID DESC";
		}

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		return $result;
	}

	public function deleteActivityData() {

		$sql = "DELETE FROM %s.maintenance_calibration_records WHERE equipID = %d";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();
	}

	public function displayContactsByEquipId() {

		$sql = sprintf("SELECT * FROM %s.equipment_contacts WHERE equipId = %d AND jobType LIKE '%s'",_DB_OBJ_FULL,$this->equipmentId,
					   $this->equipmentInfo['job_type']);

		$stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1, $this->equipmentId);
		//$stmt->bindParam(2, $this->equipmentInfo['contact_type']);

		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

	public function testdata() {
		echo "called test data";
	}
	
	public function getPeriodicityDates() {

		$main_calib_data = $this->displayMaintenanceCalibrationData();
		$periodic_activity_data = $this->displayMostRecentActivityById();

		$miscObj = new Misc();

		switch ( $main_calib_data['M'][0]['periodType'] ) {
			case 'H': $interval_M = 'HOUR'; break;
			case 'D': $interval_M = 'DAY'; break;
			case 'M': $interval_M = 'MONTH'; break;
			case 'Y': $interval_M = 'YEAR'; break;
		}

		switch ( $main_calib_data['C'][0]['periodType'] ) {
			case 'H': $interval_C = 'HOUR'; break;
			case 'D': $interval_C = 'DAY'; break;
			case 'M': $interval_C = 'MONTH'; break;
			case 'Y': $interval_C = 'YEAR'; break;
		}

		if ( $main_calib_data['M'][0]['periodType'] == 'H' && $main_calib_data['M'][0]['period'] < 24 ) {
			$main_calib_data['M'][0]['period'] = 1;
			$interval_M = 'D';
		}

		if ( $periodic_activity_data['dateReturned'] != '' ) {

			$periodic_activity_data['dateReturnedM'] = $miscObj->makeCustomDatetime($periodic_activity_data['dateReturned'],$main_calib_data['M'][0]['period'],$interval_M);
			$periodic_activity_data['dateReturnedC'] = $miscObj->makeCustomDatetime($periodic_activity_data['dateReturned'],$main_calib_data['C'][0]['period'],$interval_C);

			$result_data['maintenanceDueDate'] = format_date($periodic_activity_data['dateReturnedM']);
			$result_data['calibrationDueDate'] = format_date($periodic_activity_data['dateReturnedC']);

		} else {

			$objEquipment = SetupGeneric::useModule('Equipment');
			$objEquipment->setItemInfo(array('id'=>$this->equipmentInfo['equip_id']));
			$equip_details = $objEquipment->displayItemById();

			$objEquipment = null;

			$result_data['maintenanceDueDate'] = format_date($main_calib_data['M'][0]['dueDate']);
			$result_data['calibrationDueDate'] = format_date($miscObj->makeCustomDatetime($equip_details['datePurchased'],$main_calib_data['C'][0]['period'],$interval_C));
		}

		$miscObj = null;

		return $result_data;
	}
	
	public function displayMaintenanceM($id,$type) {
		$this->id= $id;
		$this->type= $type;
			$sql = "SELECT * FROM %s.maintenance_calibration_data WHERE equipId = %d AND jobType = '%s'";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->id,$this->type);
		

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);

	

		return $result;
	}
	
		public function getListingforExport() {

		 $type = $_GET['type'];

		if ( $type  =='assest') {

			return $this->getEquipementExportDataFull();

		} else {

			return $this->getEquipementExportData();
		}
	}
	
	public function getEquipementExportDataFull() {

		$objEquip			= SetupGeneric::useModule('Equipment');
		$objOrg				= SetupGeneric::useModule('Organigram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
                $participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 			= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		$equipment_data = $objEquip->displayItems1();
        //dump_array($equipment_data);
		
		//exit;
		$heading = array(array('Classification', 'Location', 'Asset','Asset Link Code','Business Unit','Type'));
		
		
		
		if ( count($equipment_data) ) {
					$k = 0;
			foreach ( $equipment_data as $element) {

				$equip_id	= (int) $element['equipID'];

				/*$this->setEquipmentInfo( $equip_id, '' );
				$equip_mod_data = $this->displayClientDetailsByEquipId();
				$asset_tag	= $equip_mod_data['assetTag'];*/

					$objEquip->setItemInfo( array('id'=>$element['assest_c']) );
			$equip_class_data = $objEquip->displayItemById_c();
			
			$type = $objEquip->getEquipmentDetailById22($element['assest_t']);
		
	//dump_array($type);
	//exit;
		
		$locObj				= SetupGeneric::useModule('Locationgram');
				$locObj->setItemInfo(array('id'=>$element['loc']));
				$location_data = "";
				$location = $locObj->getFUllLocation();
				
				$loc				= SetupGeneric::useModule('Locationgram');
				 $bu_id	= (int) $element['loc'];
				$loc->setItemInfo( array('id'=>$bu_id) );
				$loc1 = $loc->displayItemById();
				
				//dump_array($location);
				
				$locObj = SetupGeneric::useModule('Locationgram');
$locObj->setItemInfo(array('id'=>$bu_id));
$locdata = $locObj->displayItemById();
		
	//	if ( $locdata['businessUnit'] != 0 ) {
	$business_unit_arr = explode(",",$locdata['businessUnit']);

	$orgObj	= SetupGeneric::useModule('Organigram');
	$data = $orgObj->getBusinessUnitsforSelectedIds($business_unit_arr);
//dump_array($data);
	if ($data) {
		$i = 0;
		foreach ( $data as $data_ele ) {

	

		
			$business_unit_list1[$i] = $data_ele['buName'];
			$i++;
		}
	}
//}
//dump_array($business_unit_list);
$business_unit_list = implode(",",$business_unit_list1);
//dump_array($business_unit_list);
	//	exit;
		$bu_id	= (int) $element['bu'];
			$objOrg->setItemInfo( array('id'=>$bu_id) );
			$business_unit_data = $objOrg->displayItemById();

			$bu_name = $business_unit_data['buName'] != '' ? $business_unit_data['buName'] : '-';
			//dump_array($bu_name);
			//exit;
				$result[$k] = array($equip_class_data['primaryAssest'], $loc1['name'],$element['descp'],$element['flag_v'],$business_unit_list,$type['secondaryAssest']);
				$k++;
			}

			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}


	public function getEquipementExportData() {

		$objEquip			= SetupGeneric::useModule('Equipment');
		$objOrg				= SetupGeneric::useModule('Organigram');
		$objEquipClass		= SetupGeneric::useModule('EquipmentClassification');
                $participantObj	 	= SetupGeneric::useModule('Participant');
		$objModEquip		= new Equipment();
		$miscObj 			= new Misc();
		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$objEquip->setItemInfo(array('id'=>'','archive'=>$archive_session));
		$equipment_data = $objEquip->displayItems();
       // dump_array($equipment_data);
		
		///exit;
		$heading = array(array('EQ #', 'Location','Who', 'Description','Equip. Type','Equip. Details','Maintenace DueDate','Calibration DueDate','Manufacture Reference','Company Name','Address','Contact Name','Contact Number','Email','Fax','Reference','Equp. Title','Equip. Descp','Date Purchased','Date Manufacture','Purchase Value','Addtional Info','Maint. Type','Maint. Nature','Maint. Competence','Maint. Notes','Maint. Period','Maint. Period Type','Cali. Type','Cali. Nature','Cali. Competence','Cali. Notes','Cali. Period','Cali. Period Type'));
		
		
		
		if ( count($equipment_data) ) {
					$k = 0;
			foreach ( $equipment_data as $element) {

				$equip_id	= (int) $element['equipID'];

				/*$this->setEquipmentInfo( $equip_id, '' );
				$equip_mod_data = $this->displayClientDetailsByEquipId();
				$asset_tag	= $equip_mod_data['assetTag'];*/

				$loc				= SetupGeneric::useModule('Locationgram');
				 $bu_id	= (int) $element['equipDetailLocID'];
				$loc->setItemInfo( array('id'=>$bu_id) );
				$loc1 = $loc->displayItemById();

                                $equip_type_id	= $element['equipmentType'];
                                $objEquip->setItemInfo( array('id'=>$equip_type_id) );
				$equip_type_data = $objEquip->getEquipmentTypeById();
                                
				$equip_class_id	= $element['equipClassID'];
				$objEquipClass->setItemInfo( array('id'=>$equip_class_id) );
				$equip_class_data = $objEquipClass->displayItemById();
				$equip_class_code = $equip_class_data['equipCode'];

				$participant_id = $element['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
				
				$equip_id	= (int) $element['equipID'];
				$objModEquip->setEquipmentInfo($equip_id,array('equip_id'=>$equip_id));
				$periodicity_details = $objModEquip->getPeriodicityDates();
				
				//dump_array($periodicity_details);
		
				$maintenance_duedate_color = 'black';
				$calibration_duedate_color = 'black';

				$one_week_prior_maint_date = $miscObj->makeCustomDate($miscObj->getCurDate(),-$_SU_EMAIL_MAIN_VALUE,'WEEK');
				$one_week_prior_calib_date = $miscObj->makeCustomDate($miscObj->getCurDate(),-$_SU_EMAIL_CALIB_VALUE,'WEEK');

				if ( $periodicity_details['maintenanceDueDate'] < $one_week_prior_maint_date  ) {
					$maintenance_duedate_color = 'green';
				}

				if ( $periodicity_details['calibrationDueDate'] <  $one_week_prior_calib_date ) {
					$calibration_duedate_color = '#FF8105';
				}


				$maintenance_duedate = ($periodicity_details['maintenanceDueDate'] == '//' || $periodicity_details['maintenanceDueDate'] == ' ') ? '-' : $periodicity_details['maintenanceDueDate'];
				$calibration_duedate = ($periodicity_details['calibrationDueDate'] == '//' || $periodicity_details['calibrationDueDate'] == ' ') ? '-' : $periodicity_details['calibrationDueDate'];
				$r = 	 $this->displayMaintenanceM($equip_id,'M');
				$c = 	 $this->displayMaintenanceM($equip_id,'C');
			//dump_array($c);
			//exit;
				$result[$k] = array($element['reference'], $loc1['name'], $participant_name, $element['equipmentDesc'],$equip_type_data['equipment_type'],$equip_class_data['description'],$maintenance_duedate,$calibration_duedate,$element['manufacturerReference'],$element['companyName'],$element['address'],$element['contactName'],$element['contactNumber'],$element['contactEmail'],$element['contactFax'],$element['reference'],$element['equipTitle'],$element['equipmentDesc'],$element['datePurchased'],$element['dateManufacture'],$element['purchaseValue'],$element['additionalInfo'],$r['type'],$r['nature'],$r['competenceRequired'],$r['notes'],$r['period'],$r['periodType'],$c['type'],$c['nature'],$c['competenceRequired'],$c['notes'],$c['period'],$c['periodType']);
				$k++;
			}
			//dump_array($result);
			//exit;
			$new_result = array_merge($heading,$result);
			return $new_result;
		}
	}

	public function addPerformConsumables() {

		$lastAddedActivityID = $this->lastRecordId;

		$sql = "INSERT INTO %s.equipment_perform_activity_consumables (equipId,tab,consumables,quantity,activityID) VALUES ";

		//dump_array($this->equipmentInfo['consumables']);

		for ($k=0;$k<count($this->equipmentInfo['consumables']['tab']);$k++) {

			// if quantity is not 0
			if ( $this->equipmentInfo['consumables']['quantity'][$k] ) {

				if ( $this->equipmentInfo['job_repair'] == 1 && $this->equipmentInfo['consumables']['tab'][$k] == 'R' ) {
					$this->equipmentInfo['job_repair'].'->'.$this->equipmentInfo['consumables']['tab'][$k].'<br/>';
					$sql2 .= "('%d','%s','%s','%s',%d),";
				}

				if ( $this->equipmentInfo['job_maintenance'] == 1 && $this->equipmentInfo['consumables']['tab'][$k] == 'M' ) {
					$this->equipmentInfo['job_maintenance'].'->'.$this->equipmentInfo['consumables']['tab'][$k].'<br/>';
					$sql2 .= "('%d','%s','%s','%s',%d),";
				}

				if ( $this->equipmentInfo['job_calibration'] == 1 && $this->equipmentInfo['consumables']['tab'][$k] == 'C' ) {
					$this->equipmentInfo['job_calibration'].'->'.$this->equipmentInfo['consumables']['tab'][$k].'<br/>';
					$sql2 .= "('%d','%s','%s','%s',%d),";
				}
			}
		}

		$psql = sprintf($sql,_DB_OBJ_FULL);

		for ($k=0;$k<count($this->equipmentInfo['consumables']['tab']);$k++) {

			// if quantity is not 0
			if ( $this->equipmentInfo['consumables']['quantity'][$k] ) {

				if ( $this->equipmentInfo['job_repair'] == 1 && $this->equipmentInfo['consumables']['tab'][$k] == 'R' ) {

					$p_arr[] = $this->equipmentInfo['equip_id'];
					$p_arr[] = $this->equipmentInfo['consumables']['tab'][$k];
					$p_arr[] = $this->equipmentInfo['consumables']['detail'][$k];
					$p_arr[] = $this->equipmentInfo['consumables']['quantity'][$k];
					$p_arr[] = $lastAddedActivityID;
				}

				if ( $this->equipmentInfo['job_maintenance'] == 1 && $this->equipmentInfo['consumables']['tab'][$k] == 'M' ) {

					$p_arr[] = $this->equipmentInfo['equip_id'];
					$p_arr[] = $this->equipmentInfo['consumables']['tab'][$k];
					$p_arr[] = $this->equipmentInfo['consumables']['detail'][$k];
					$p_arr[] = $this->equipmentInfo['consumables']['quantity'][$k];
					$p_arr[] = $lastAddedActivityID;
				}

				if ( $this->equipmentInfo['job_calibration'] == 1 && $this->equipmentInfo['consumables']['tab'][$k] == 'C' ) {

					$p_arr[] = $this->equipmentInfo['equip_id'];
					$p_arr[] = $this->equipmentInfo['consumables']['tab'][$k];
					$p_arr[] = $this->equipmentInfo['consumables']['detail'][$k];
					$p_arr[] = $this->equipmentInfo['consumables']['quantity'][$k];
					$p_arr[] = $lastAddedActivityID;
				}
			}
		}

		$psql2 = vsprintf($sql2,$p_arr);

		$final_psql = $psql.rtrim($psql2,',');

		$stmt = $this->dbHand->prepare($final_psql);
		$stmt->execute();

	}


	public function addPerformConsumablesSpecialCase() {

		$sql = "INSERT INTO %s.equipment_perform_consumables (equipId,tab,consumables,quantity,mcID)
				VALUES ('%d','%s','%s','%s',%d)";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentId,$this->equipmentInfo['tab'],$this->equipmentInfo['consumables_detail'],$this->equipmentInfo['consumables_quantity'],$this->lastRecordId);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

	}
	
	public function updateeuipAction(){
	
	$sql = "UPDATE %s.equipment_action SET caP = '".$this->equipmentInfo['due_date']."' WHERE eID = ".$this->equipmentId;
				$psql = sprintf($sql,_DB_OBJ_FULL);

				$stmt = $this->dbHand->prepare($psql);
				$stmt->execute();
	
	}
	
	public function actionEquipment() {
	
		$sql = sprintf("SELECT * FROM %s.equipment_action WHERE done is NULL AND eID = %d",_DB_OBJ_FULL,$this->equipmentInfo['equip_id']);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		if($result['maP']){
			$sql = "UPDATE %s.equipment_action SET maD = '".$this->equipmentInfo['date_returned']."' , done ='yes' WHERE ID = ".$result['ID'];
				$psql = sprintf($sql,_DB_OBJ_FULL);

				$stmt = $this->dbHand->prepare($psql);
				$stmt->execute();
			//$maD = $result['maP'];
		}
		$maD = '';
		if($result['caP']){
		
			$sql = "UPDATE %s.equipment_action SET caD = '".$this->equipmentInfo['date_returned']."' , done ='yes' WHERE ID = ".$result['ID'];
				$psql = sprintf($sql,_DB_OBJ_FULL);

				$stmt = $this->dbHand->prepare($psql);
				$stmt->execute();
		}
		$caD = '';
		$sql = "INSERT INTO %s.equipment_action (eId,maP,maD,caP,caD)
				VALUES ('%d','%s','%s','%s','%s')";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['equip_id'],$this->equipmentInfo['m_due_date'],$maD,$this->equipmentInfo['c_due_date'],$caD);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

	}

	public function getLastConsumablesId() {
		return $this->lastRecordId;
	}

	public function editPerformConsumables() {

		$sqlins = "INSERT INTO %s.equipment_perform_consumables (equipId,tab,consumables,quantity) VALUES ";

		$EXEC_IN = false;

		for ($k=0;$k<count($this->equipmentInfo['consumables']['identifier']);$k++) {
			if ( $this->equipmentInfo['consumables']['identifier'][$k] != '' ) {

				$sql = "UPDATE %s.equipment_perform_consumables SET quantity = '%s' WHERE ID = %d";
				$psql = sprintf($sql,_DB_OBJ_FULL,trim($this->equipmentInfo['consumables']['quantity'][$k]),$this->equipmentInfo['consumables']['identifier'][$k]);

				$stmt = $this->dbHand->prepare($psql);
				$stmt->execute();

			} else {

				$EXEC_IN = true;

				$sql2 .= "('%d','%s','%s','%s'),";

				$p_arr[] = $this->equipmentInfo['equip_id'];
				$p_arr[] = $this->equipmentInfo['tab'];
				$p_arr[] = $this->equipmentInfo['consumables']['detail'][$k];
				$p_arr[] = $this->equipmentInfo['consumables']['quantity'][$k];

			}
		}

		if ($EXEC_IN) {
			$psql = sprintf($sqlins,_DB_OBJ_FULL);
			$psql2 = vsprintf($sql2,$p_arr);

			$final_psql = $psql.rtrim($psql2,',');

			$stmt2 = $this->dbHand->prepare($final_psql);
			$stmt2->execute();
		}
	}

	public function editPerformConsumablesSpecialCase() {

		if ( $this->equipmentInfo['consumables_identifier'] != 0 ) {

			$sql = "UPDATE %s.equipment_perform_consumables SET tab = '%s', consumables = '%s', quantity = '%s' WHERE ID = %d";
			$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['tab'],$this->equipmentInfo['consumables_detail'],trim($this->equipmentInfo['consumables_quantity']),$this->equipmentInfo['consumables_identifier']);

			$stmt = $this->dbHand->prepare($psql);
			$stmt->execute();

		} else {
			$this->addPerformConsumablesSpecialCase();
		}
	}

	public function displayConsumablesByCMId($p_id) {

		$eqObj = SetupGeneric::useModule('equipment');

		$sql = sprintf("SELECT * FROM %s.equipment_perform_consumables WHERE mcID = %d",_DB_OBJ_FULL,$p_id);

		$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		$eqObj->setItemInfo(array('id' =>$result['consumables']));
		$consumable_data = $eqObj->getConsumablesById();

		$result['typeID'] = $consumable_data['typeID'];

		$eqObj = null;

		return $result;
	}



	public function displayConsumablesIDByEquipId() {

		if ( $this->equipmentInfo['tab'] == '' ) {
			$sql = sprintf("SELECT * FROM %s.equipment_perform_consumables WHERE equipId = %d",_DB_OBJ_FULL,
					   $this->equipmentInfo['equip_id']);
		} else {
			$sql = sprintf("SELECT * FROM %s.equipment_perform_consumables WHERE equipId = %d AND tab = '%s'",_DB_OBJ_FULL,
					   $this->equipmentInfo['equip_id'],$this->equipmentInfo['tab']);
		}


		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$stmt->errorInfo();
		$result = $stmt->fetchALL(PDO::FETCH_ASSOC);

		$eqObj = SetupGeneric::useModule('equipment');

		if ( $result ) {

			foreach ( $result as $result_ele ) {

				if ( $this->equipmentInfo['tab'] == '' ) {

					$ID = $result_ele['ID'];
					$consumables[$result_ele['tab']][$ID]['consumables'] 	= $result_ele['consumables'];
					$consumables[$result_ele['tab']][$ID]['quantity'] 		= $result_ele['quantity'];
					$consumables[$result_ele['tab']][$ID]['tab'] 			= $result_ele['tab'];


					$eqObj->setItemInfo(array('id' =>$result_ele['consumables']));
					$consumable_data = $eqObj->getConsumablesById();

					$consumables[$result_ele['tab']][$ID]['typeID'] 		= $consumable_data['typeID'];
					$consumables[$result_ele['tab']][$ID]['unit'] 			= $consumable_data['unit'];
					$consumables[$result_ele['tab']][$ID]['mcID'] 			= $result_ele['mcID'];

				} else {

					$ID = $result_ele['ID'];
					$consumables[$ID]['consumables'] 	= $result_ele['consumables'];
					$consumables[$ID]['quantity'] 		= $result_ele['quantity'];
					$consumables[$ID]['tab'] 			= $result_ele['tab'];


					$eqObj->setItemInfo(array('id' =>$result_ele['consumables']));
					$consumable_data = $eqObj->getConsumablesById();

					$consumables[$ID]['typeID'] 		= $consumable_data['typeID'];
					$consumables[$ID]['unit'] 			= $consumable_data['unit'];
					$consumables[$ID]['mcID'] 			= $result_ele['mcID'];
				}
			}
		}

		$eqObj = null;

		return $consumables;

	}
    public function displayQuantityIDByEquipId() {

		 $sql = sprintf("SELECT quantity FROM %s.equipment_perform_consumables WHERE equipId = %d ",_DB_OBJ_FULL,
					   $this->equipmentInfo['equip_id']);

		 $stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1, $this->equipmentId);
		//$stmt->bindParam(2, $this->equipmentInfo['contact_type']);

		$stmt->execute();
		$stmt->errorInfo();
		$result = $stmt->fetchALL(PDO::FETCH_ASSOC);

		//dump_array($result);
		if ( $result ) {
			foreach ( $result as $result_ele ) {
				$quantity[] = $result_ele['quantity'];

			}
		}
		return $quantity;

	}


	public function consumablesGetById(){

			 $sql = sprintf("SELECT * FROM %s.equipment_perform_consumables WHERE consumables = %s ",_DB_OBJ_FULL,
					   $this->equipmentInfo['consumables']);

		 $stmt = $this->dbHand->prepare($sql);

		//$stmt->bindParam(1, $this->equipmentId);
		//$stmt->bindParam(2, $this->equipmentInfo['contact_type']);

		$stmt->execute();
		$stmt->errorInfo();
		$result = $stmt->fetchALL(PDO::FETCH_ASSOC);

			//exit;
		return $result;

	}
	public function deleteConsumablesById() {

		$sql = "DELETE FROM %s.equipment_perform_consumables WHERE ID = %d";

		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentId);

		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

	}
	public function consumablesType() {

		$sql = "SELECT name FROM %s.equipment_consumables where ID = %s
				ORDER BY name ASC";
		$psql = sprintf($sql,_DB_OBJ_FULL,$this->equipmentInfo['c_id']);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}

	public function getR2Data() {

		$sql = "SELECT A.equipID,equipmentType,equipDetailLocID,B.*
				FROM %s.equipments A
				INNER JOIN %s.maintenance_calibration_records B
				ON A.equipID = B.equipID
				WHERE jobDone != ''
				AND equipmentType IS NOT NULL";

		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;

	}

	public function getR3Data() {
$sql = "select *,P.forename+' '+P.surname as name from %s.actions A left join %s.assestmangement M on A.record=M.ID left join %s.participant_database P on A.who=P.participantID where modulename like '%s' and approveau=0 order by moduleName";
	/*	$sql = "SELECT A.equipID,equipmentType,equipDetailLocID,B.*
				FROM %s.equipments A
				INNER JOIN %s.maintenance_calibration_data B
				ON A.equipID = B.equipId
				WHERE jobType != ''
				AND equipmentType IS NOT NULL";
*/
		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,'equipment%');

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ($result) {
		//	$objEquipment = SetupGeneric::useModule('Equipment');

			foreach ( $result as $result_ele ) {

				//$objEquipment->setItemInfo(array('id'=>$result_ele['equipID']));
				//$equip_data = $objEquipment->displayItemById();

				$result_ele['equip_title'] 		= $result_ele['equipTitle'];
				$result_ele['equipment_desc'] 	= $result_ele['actionDescription'];
				$result_ele['dueDate'] 			= format_date($result_ele['dueDate']);
				$result_ele['reference'] 		= $result_ele['ref'];
                                $result_ele['who'] =$result_ele['name'];
				$records[] = $result_ele;
			} // end foreach

			$objEquipment = null;
		}

		return $records;

	}

	public function getR4Data() {

		$sql = "SELECT A.ID,A.tab,A.consumables,A.quantity,B.jobDone
				FROM %s.equipment_perform_activity_consumables A
				INNER JOIN %s.maintenance_calibration_records B
				ON A.activityID = B.ID
				WHERE jobDone != ''
				AND consumables IS NOT NULL AND consumables != ''";

		$psql = sprintf($sql,_DB_OBJ_FULL,_DB_OBJ_FULL);

		$stmt = $this->dbHand->prepare($psql);
		//$stmt->bindParam(1,$this->id,PDO::PARAM_INT);
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $result;
	}
	
	public function approveActions($pjobType="Q",$whoID) {
	 if ($pjobType == "C")
	 $text=  "Calibration" ;
	 else
	 $text=  "Maintenance";
	
	
		$objOrg				= SetupGeneric::useModule('Organigram');
		$whoAUarr=$objOrg->getManager($whoID);
		if(!$whoAUarr){
                                                    $participantObj = SetupGeneric::useModule('Participant');
                $details = $participantObj->getAdminDetails();
                $whoAUarr['participantID']=$details["participantID"];
                }

	//agreed with Jow action goes to whoever is entering the data to cover external but the manager remains the same
	$who=getLoggedInUserId();
	
$sql = sprintf("UPDATE %s.actions SET doneDate = '%s',who=%d,whoAU=%d,doneDescription = '%s carried out' where record = %d and moduleName='equipment%s' and doneDescription is null",_DB_OBJ_FULL,format_date_for_mysql($this->equipmentInfo['date_returned']),$who,$whoAUarr['participantID'],$text,$this->equipmentInfo['equip_id'],$pjobType);

$pStatement = $this->dbHand->prepare($sql);
$pStatement->execute();
	}

	public function getActionsID($pjobType="Q") {

		$sql =  sprintf("select * from  %s.actions where  record = %d and moduleName='equipment%s' and doneDescription is null order by ID desc",_DB_OBJ_FULL,$this->equipmentInfo['equip_id'],$pjobType);


$stmt = $this->dbHand->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		return $result;
	}

public function addPerformAction($pjobType="Q",$date,$reference,$whoAU,$title) {
	$objFile = new Upload();
	$ID= $this->equipmentId;

	$this->equipmentInfo['job_type']=$pjobType;
	$result_calibration		= $this->displayMaintenanceCalibrationData();

	
		if ($pjobType =='M'){
		 $whoID=$result_calibration["M"][0]["whoID"];
			$module="EquipmentM";
			$description="Equipment Maintenance to be carried out on ".$title.". ";
			$url='Please <a href="http://'.$_SERVER['HTTP_HOST'].'/equipment/perform_maintenance_calibration.php?task=add&eid='.$ID.'">CLICK</a> Here to carry out Equipment Maintenance<BR>';
			$title="Smart-ISO Equipment Maintenance";
			$file_id=array_filter(explode(",",$result_calibration["M"][0]["docID"]));
		}
		else
		{	
		 $whoID=$result_calibration["C"][0]["whoID"];	
			$module="EquipmentC";
			$description="Equipment Calibration to be carried out on ".$title.". ";	
			$url='Please <a href="http://'.$_SERVER['HTTP_HOST'].'/equipment/perform_maintenance_calibration.php?task=add&eid='.$ID.'">CLICK</a> Here to carry out Equipment Calibrations<BR>';
			$title="Smart-ISO Equipment Calibration";
			$file_id=array_filter(explode(",",$result_calibration["C"][0]["docID"]));
		}
		

if(count($file_id)>0){
$url.="<BR>Documents<BR>";	
foreach($file_id as $filedata){
$objFile->setFileInfo('equipment',array('id'=>$filedata));
	$file_detail = $objFile->getFileDetails();	

	$url.= '<a href="http://'.$_SERVER['HTTP_HOST'].'/download_file.php?fn='.$file_detail['sysFilename'].'&un='.$file_detail['usrFilename'].'&module=equipment">View&nbsp;</a>'.$file_detail['usrFilename'].'<BR>';
	
}	
}

		$actionHandling	= new Action();
		$objOrg				= SetupGeneric::useModule('Organigram');
		$whoAUarr=$objOrg->getManager($whoID);
		if(!$whoAUarr){
                                                    $participantObj = SetupGeneric::useModule('Participant');
                $details = $participantObj->getAdminDetails();
                $whoAUarr['participantID']=$details["participantID"];
                }
		

		//$actionData = array('module_name'=>$module,'description'=>$description,'who'=>$whoID,'whoAU'=>$whoAUarr['participantID'],'due_date'=>$date);

		$actionData = array('description' => $description,
            'who' => $whoID,
            'whoAU' => $whoAUarr['participantID'],
            'who2AU' => 0,
            'module_name' => $module,
            'record' => $ID,
            'status' => 1,
            'buname' => $bu["buName"],
            'currentwho' => $whoID,
            'element' => "equipment",
            'due_date' => $date);

			
		$actionHandling->setActionDetails(0,$actionData);

		$new_action_id = $actionHandling->addAction2015();

		//$actionHandling->updateRecord($new_action_id,$ID,"equipments");
		
		$data=array('singleColData'=>array('click-here-url'=>$url),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>$reference)));		
		$emailObj =	new actionEmailHelper($new_action_id);	
		$whoarr=$emailObj->getwhoDetails();
		$emailObj->appendInfo($data);
		$emailObj->sendEmail($title,$whoarr,array(),array(),'me_completed','','grey');

	}
	
		public function displayTotalConsumablesByEquipId($equip_id) {


			$sql = sprintf("SELECT P.tab,P.ID,P.mcID,P.consumables,C.unit,C.detail,C.typeID,T.name FROM %s.equipment_perform_consumables P inner join %s.equipment_consumables C on P.consumables=C.ID inner join %s.equipment_consumables_type T on C.typeID=T.ID WHERE equipId = %d",
			_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,$equip_id);

		$stmt = $this->dbHand->prepare($sql);

		$stmt->execute();
		$stmt->errorInfo();
		$result = $stmt->fetchALL(PDO::FETCH_ASSOC);
		
		foreach ( $result as $result_ele ) {

					$ID = $result_ele['ID'];
					$consumables[$result_ele['tab']][$ID]['consumables'] 	= $result_ele['consumables'];
					$consumables[$result_ele['tab']][$ID]['quantity'] 		= $result_ele['quantity'];
					$consumables[$result_ele['tab']][$ID]['typeID'] 		= $result_ele['typeID'];
					$consumables[$result_ele['tab']][$ID]['unit'] 			= $result_ele['unit'];
					$consumables[$result_ele['tab']][$ID]['mcID'] 			= $result_ele['mcID'];
					$consumables[$result_ele['tab']][$ID]['consumables']    = $result_ele['consumables'];
					$consumables[$result_ele['tab']][$ID]['detail'] 		= $result_ele['detail'];
					$consumables[$result_ele['tab']][$ID]['name']           = $result_ele['name'];
				}

				return $consumables;
}
}
?>