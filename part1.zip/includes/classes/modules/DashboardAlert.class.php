<?php
 /**
  $Id: ActionTracker.class.php,v 4.29 Tuesday, February 01, 2011 4:40:01 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Organigram object
  *
  * This interface will declare the various methods performed
  * by organigram object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 6:29:33 PM>
  */
class DashboardAlert extends DashboardParent
{

	/**
	 * Constructor for initializing Action Tracker object
	 * @access public
	 */
	public function __construct() {
		parent::__construct();
	}

	public function getImpactMeasures() {

		$sql = "SELECT * FROM %s.ncr_type
				ORDER BY sort ASC";

		$psql = sprintf($sql,_DB_OBJ_FULL);
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$impact_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $impact_data;

	}

	public function getNHPData() {

		
			$sql = "SELECT nearmissHazardFlag,alert_actionID FROM %s.nhp
							WHERE che = '1' AND (nearmissHazardFlag = 6 OR nearmissHazardFlag = 9 OR nearmissHazardFlag = 7)
							ORDER BY ID DESC";

			$psql = sprintf($sql,_DB_OBJ_FULL);
	
		$stmt = $this->dbHand->prepare($psql);
		$stmt->execute();

		$result_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result_data;
	}

	public function getData() {

		$bu_list 	= array();
		$hlist 		= array();
		$dlist 		= array();

		$q1_sr 		= $this->qtrsRange['q1_sr'];
		$q1_er		= $this->qtrsRange['q1_er'];
		
		$q2_sr 		= $this->qtrsRange['q2_sr'];
		$q2_er 		= $this->qtrsRange['q2_er'];
		$q3_sr 		= $this->qtrsRange['q3_sr'];
		$q3_er 		= $this->qtrsRange['q3_er'];
		$q4_sr 		= $this->qtrsRange['q4_sr'];
		$q4_er 		= $this->qtrsRange['q4_er'];
		$q5_sr 		= $this->qtrsRange['q5_sr'];
		$q5_er 		= $this->qtrsRange['q5_er'];
		$cqtr		= $this->qtrsRange['cqtr'];

		$hlist = $this->getImpactMeasures();

		//if ($impact_measures) {

			//foreach ( $impact_measures as $impact_measure_ele ) {
				
				//$hlist[$impact_measure_ele['ID']] = $impact_measure_ele_name['name'];
			//}
		//}

		$nhp_data = $this->getNHPData();

		// Action Object
		$actObj = new Action();
		$nc = array();

		$buObj = SetupGeneric::useModule('organigram');

		foreach ( $nhp_data as $nhp_data_ele ) {

			//dump_array($nhp_data_ele);

			if ( $nhp_data_ele['alert_actionID'] != '' ) {

				$nhp_data_actions 	= explode(",",$nhp_data_ele['alert_actionID']);
				$buid 				= $nhp_data_ele['nearmissHazardFlag'];
				$problemRiskImpact	= $nhp_data_ele['nearmissHazardFlag'];
if ( !in_array($buid,$dlist) )
					$dlist[] = $buid;
			
				foreach ( $nhp_data_actions as $nhp_data_action_ele ) {

					if ( $nhp_data_action_ele != '' ) {

						$actObj->setActionDetails($nhp_data_action_ele,array());
						$action_data = $actObj->viewAction();

						
						
							if($action_data['status'] == '1' && $action_data['doneDate']){
							//echo $action_data['dueDate']."---"; 
							if ($action_data['doneDate'] >= $q1_sr && $action_data['doneDate'] <= $q1_er ) {
									//echo $action_data['dueDate']."---"; 
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q1']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q1']['D']++;
									}else{
										$nc[$buid]['q1']['A']++;
									}
								} else if ( $action_data['doneDate'] >= $q2_sr && $action_data['doneDate'] <= $q2_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q2']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q2']['D']++;
									}else{
										$nc[$buid]['q2']['A']++;
									}
								} else if ( $action_data['doneDate'] >= $q3_sr && $action_data['doneDate'] <= $q3_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q3']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q3']['D']++;
									}else{
										$nc[$buid]['q3']['A']++;
									}
								} else if ($action_data['doneDate'] >= $q4_sr && $action_data['doneDate'] <= $q4_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q4']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q4']['D']++;
									}else{
										$nc[$buid]['q4']['A']++;
									}
								} else if ( $action_data['doneDate'] >= $q5_sr && $action_data['doneDate'] <= $q5_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q5']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q5']['D']++;
									}else{
										$nc[$buid]['q5']['A']++;
									}
								} else{
									if ($action_data['doneDate'] < $q1_sr && $action_data['who'] != 0 && $action_data['whoAU'] != 0 &&  $action_data['approveAU'] == '0' &&  ($action_data['doneDate'] =='' || $action_data['doneDate'] = '1900-01-01')) {
										if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q6']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q6']['D']++;
									}else{
										$nc[$buid]['q6']['A']++;
									}
										}
								}
							}else{
							
							if($action_data['status'] == '1'){
							//echo $action_data['dueDate']."---"; 
							if ($action_data['dueDate'] >= $q1_sr && $action_data['dueDate'] <= $q1_er ) {
									//echo $action_data['dueDate']."---"; 
									if ( $buid == '6') {
										$nc[$buid]['q1']['P']++;
									} else if($buid == '9') {
										$nc[$buid]['q1']['D']++;
									}else{
										$nc[$buid]['q1']['A']++;
									}
								} else if ( $action_data['dueDate'] >= $q2_sr && $action_data['dueDate'] <= $q2_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q2']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q2']['D']++;
									}else{
										$nc[$buid]['q2']['A']++;
									}
								} else if ( $action_data['dueDate'] >= $q3_sr && $action_data['dueDate'] <= $q3_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q3']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q3']['D']++;
									}else{
										$nc[$buid]['q3']['A']++;
									}
								} else if ($action_data['dueDate'] >= $q4_sr && $action_data['dueDate'] <= $q4_er ) {
									if ( $nhp_data_ele['nearmissHazardFlag'] == '6') {
										$nc[$buid]['q4']['P']++;
									} else if($nhp_data_ele['nearmissHazardFlag'] == '9') {
										$nc[$buid]['q4']['D']++;
									}else{
										$nc[$buid]['q4']['A']++;
									}
								} else if ( $action_data['dueDate'] >= $q5_sr && $action_data['dueDate'] <= $q5_er ) {
									if ( $buid == '6') {
										$nc[$buid]['q5']['P']++;
									} else if($buid == '9') {
										$nc[$buid]['q5']['D']++;
									}else{
										$nc[$buid]['q5']['A']++;
									}
								} else{
									if ($action_data['dueDate'] < $q1_sr && $action_data['who'] != 0 && $action_data['whoAU'] != 0 &&  $action_data['approveAU'] == '0' &&  ($action_data['doneDate'] =='' || $action_data['doneDate'] = '1900-01-01')) {
										if ( $buid == '6') {
										$nc[$buid]['q6']['P']++;
									} else if($buid == '9') {
										$nc[$buid]['q6']['D']++;
									}else{
										$nc[$buid]['q6']['A']++;
									}
										}
								}
							}
							
							
							}
								
								
					} else {
						continue;
					}

				} // end foreach $nhp_data_action_ele
			}
		}

		

			return array(
				'hlist' => $hlist,
				'dlist' => $dlist,
				'bu_list' => $bu_list,
				'section_data'=>$nc
				);

	}

	public function getGraphData() {

		$grid_data 	= $this->getData();
		//dump_array($grid_data);
		$dlist 		= $grid_data['dlist'];
		$hlist 		= $grid_data['hlist'];
		$ra 		= $grid_data['section_data'];
		
		$graph = array();
		//dump_array($ra);
		foreach( $dlist as $d ) {
			//foreach( $hlist as $hk=>$hv ) {

				/*$ra[$d][$hk]['q1']['P'] = $ra[$d][$hk]['q2']['P'] = $ra[$d][$hk]['q3']['P'] = 10;
				$ra[$d][$hk]['q1']['D'] = $ra[$d][$hk]['q2']['D'] = $ra[$d][$hk]['q3']['D'] = 20;*/
//dump_array($d);
				$graph['q1']['Mi'] += $ra[$d]['q1']['D'] + $ra[$d]['q6']['D'];
				$graph['q2']['Mi'] += $ra[$d]['q2']['D'];
				$graph['q3']['Mi'] += $ra[$d]['q3']['D'];
				$graph['q4']['Mi'] += $ra[$d]['q4']['D'];

				$graph['q5']['Mi'] += $ra[$d]['q1']['D'] + $ra[$d]['q2']['D'] + $ra[$d]['q3']['D'] + $ra[$d]['q4']['D'] +$ra[$d]['q6']['D'];
				
				$graph['q1']['Ma'] += $ra[$d]['q1']['P'] + $ra[$d]['q6']['P'];
				$graph['q2']['Ma'] += $ra[$d]['q2']['P'];
				$graph['q3']['Ma'] += $ra[$d]['q3']['P'];
				$graph['q4']['Ma'] += $ra[$d]['q4']['P'];

				$graph['q5']['Ma'] += $ra[$d]['q1']['P'] + $ra[$d]['q2']['P'] + $ra[$d]['q3']['P'] + $ra[$d]['q4']['P'] + $ra[$d]['q6']['P'];
				
				
				$graph['q1']['ofi'] += $ra[$d]['q1']['A'] + $ra[$d]['q6']['A'];
				$graph['q2']['ofi'] += $ra[$d]['q2']['A'];
				$graph['q3']['ofi'] += $ra[$d]['q3']['A'];
				$graph['q4']['ofi'] += $ra[$d]['q4']['A'];

				$graph['q5']['ofi'] += $ra[$d]['q1']['A'] + $ra[$d]['q2']['A'] + $ra[$d]['q3']['A'] + $ra[$d]['q4']['A'] + $ra[$d]['q6']['A'];
				//$graph['q6']['A'] += $ra[$d]['q6']['A'];

			//}
		}
//dump_array($graph);
		return $graph;
	}
}