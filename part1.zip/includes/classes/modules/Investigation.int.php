<?php
 /**
  $Id: Investigation.int.php,v 3.11 Thursday, November 04, 2010 8:32:07 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage investigation object
  *
  * This interface will declare the various methods performed
  * by investigation object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 8:00:35 PM>
  */

interface Investigation
{
	/*
	 * This method is used to set investigation information for the respective object
	 */
	public function setInvestigationInfo($p_investigationId,$p_investigationInfo);

	/*
	 * This method is used to add new investigation
	 */
	public function addInvestigation();

	/*
	 * This method is used to edit an investigation
	 */
	public function editInvestigation();

	/*
	 * This method is used to delete an investigation
	 */
	public function deleteInvestigation();

	/*
	 * This method is used to archive an investigation record
	 */
	public function archiveInvestigation();

	/*
	 * This method is used to completely delete an investigation record
	 */
	public function purgeInvestigation();

}