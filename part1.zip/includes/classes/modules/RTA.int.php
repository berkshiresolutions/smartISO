<?php
 /**
  $Id: RTA.int.php,v 3.05 Monday, November 08, 2010 9:51:54 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage RTA object
  *
  * This RTA will declare the various methods performed
  * by RTA object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 8:11:58 PM>
  */

interface RTAint
{
	/*
	 * This method is used to set Nhp information for the respective object
	 */
	public function setRTAInfo($p_RTAId,$p_RTAInfo);

	/*
	 * This method is used to add new RTA
	 */
	public function addRTA();

	/*
	 * This method is used to edit RTA record
	 */
	public function editRTA();

	/*
	 * This method is used to delete RTA record
	 */
	public function deleteRTA();

	/*
	 * This method is used to archive RTA record
	 */
	public function archiveRTA();

	/*
	 * This method is used to completely delete RTA record
	 */
	public function purgeRTA();

}
