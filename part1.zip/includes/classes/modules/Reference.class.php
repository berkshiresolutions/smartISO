<?php
 /**
  $Id: Reference.class.php,v 3.09 Saturday, January 08, 2011 3:28:57 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Monday, October 11, 2010 4:31:04 PM>
  */

class Reference
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * This property contains the module name
	 * @access private
	 */
	private $moduleName;

	/**
	 * This property contains the table name
	 * @access private
	 */
	private $tableName;

	/**
	 * This property contains the table name
	 * @access private
	 */
	private $refrenceInitails;

	/**
	 * Constructor for initializing Reference object
	 * @access public
	 * Modules - DSE,COMPLAINT,EQUIPMENT,CONTRACTOR,MANHANDLING
	 */
	public function __construct() {

		 
$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->moduleMapping			= array(
										'DSE' 				=> 'dse_assessment,DS',
										'COMPLAINT' 		=> 'complaint,CC',
										'EQUIPMENT' 		=> 'equipments,EQ',
										'CONTRACTOR' 		=> 'contractor,CT',
										'MANHANDLING' 		=> 'manual_handling,MH',
										'PARTICIPANT' 		=> 'participant_database,WN'
										);

	}

	public function setReferenceInfo($p_moduleName) {
		$this->moduleName = $p_moduleName;
		$this->setRefenceInitails();
	}

	private function setRefenceInitails() {
		$moduleInfo = $this->moduleMapping[$this->moduleName];
		if ( !empty($moduleInfo) ) {
			$moduleInfoArr = explode(',',$moduleInfo);
			$this->tableName = $moduleInfoArr[0];
			$this->refrenceInitails = $moduleInfoArr[1];
		}
	}

	public function uniqueReferenceNumber() {
		$query = sprintf("SELECT max(uniqueReference) AS newRef FROM %s.%s",_DB_OBJ_FULL,$this->tableName);


		$pStatement = $this->dbHand->prepare($query);
		$pStatement->execute();
		$row = $pStatement->fetch(PDO::FETCH_ASSOC);
		//dump_array($row);

		$strlen = strlen($row['newRef']);
		$job1 = (int) substr($row['newRef'],8,2);
		$job1++;

		if ( $job1  < 10 ) {
			$new_job_suffix = '0'.$job1;
		} else {
			$new_job_suffix = $job1;
		}

		$newUniqueReference = $this->refrenceInitails.date('y').date('m').date('d').$new_job_suffix;
		return $newUniqueReference;
	}
}

?>