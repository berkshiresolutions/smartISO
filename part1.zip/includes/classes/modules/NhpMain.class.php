<?php

/**
  $Id: NhpMain.class.php,v 3.38 Monday, January 31, 2011 10:06:22 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Monday, November 08, 2010 9:52:17 AM>
 */
require_once "Nhp.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class NhpMain implements Nhp {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold Nhp Id
     * @access private
     */
    private $nhpId;

    /**
     * Property to hold Nhp Info
     * @access private
     */
    private $nhpInfo;

    /**
     * Constructor for initializing Nhp object
     * @access public
     */
    public function __construct() {

 
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set Nhp information for the respective object
     */

    public function setNhpInfo($p_NhpId, $p_NhpInfo) {
        $this->nhpId = $p_NhpId;
        $this->nhpInfo = $p_NhpInfo;
    }

    /*
     * This method is used to add new Nhp
     */

    public function addNhp() {

      $sql = sprintf("SELECT * FROM %s.nhp WHERE reference = '%s'", _DB_OBJ_FULL, $this->nhpInfo['reference']);
        $pStatement = $this->dbHand->prepare($sql);

       //$pStatement->bindParam(1,$this->nhpInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (is_array($resultSet) && count($resultSet)>0) {
            throw new ErrorException('Nhp with this Reference # already exists.');
        } else {
         $sql2 = sprintf("INSERT INTO %s.nhp (reference,uniqueReference,whoID,locationID,businessUnitID,date,archive,status,nearmissHazardFlag,signature,nature,who_r,time,che,who_rid,processID,reason,environmental,disposition,subReference)
											VALUES ('%s','%s',%d,%d,%d,'%s','0','0','%s',%d,'%s','%s','%s',%d,%d,%d,'%s','1000','1000',0)", _DB_OBJ_FULL, $this->nhpInfo['reference'], $this->nhpInfo['unique_reference'], $this->nhpInfo['participantID'], $this->nhpInfo['location'], $this->nhpInfo['business_unit'], format_date_for_mysql($this->nhpInfo['date']), $this->nhpInfo['near_miss_hazard_flag'], $this->nhpInfo['check_sign'], $this->nhpInfo['nature'], $this->nhpInfo['who_r'], $this->nhpInfo['time'], $this->nhpInfo['che'], $this->nhpInfo['who_rid'], $this->nhpInfo['process'], $this->nhpInfo['reject']);
            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();

            $this->nhpId = customLastInsertId($this->dbHand, 'nhp', 'ID');
            
           $sql3 = sprintf("INSERT INTO %s.nhp_causes (nhpID ,isUnsafeAct ,unsafeActPercent,lackSkillPercent)
											VALUES (%d,1,100,100)", _DB_OBJ_FULL, $this->nhpId);
            $pStatement3 = $this->dbHand->prepare($sql3);

            $pStatement3->execute();
            
        }
    }

    /*
     * This method is used to edit Nhp record
     */

    public function editNhp() {

        $sql = sprintf(" select * from %s.nhp WHERE ID = %d ", _DB_OBJ_FULL, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);



        $emailObj = new infoEmailHelper();


        if ($data["who_rid"] > 0 && $data["status"] == 0) {
            $participantObj = SetupGeneric::useModule('Participant');

            $participantObj->setItemInfo(array('id' => $data["who_rid"]));
            $partcipantData = $participantObj->displayItemById();
            $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

            $who = array(
                'displayname' => ucwords($contributor_name),
                'email' => $partcipantData['emailAddress']
            );

            $subject = "smart-ISO NCR Email: Your alert is being actioned.";
            $mergeData = array(
                'twoColData' => array(
                    'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $data['reference']),
                    'assignedto' => array('left' => '<strong>Problem:</strong>', 'right' => $data['problemDescription'])
                ),
                'singleColData' => array(
                    'summary' => '<p><BR>Your alert is being actioned.<BR><BR></p>')
            );

            $emailObj->appendInfo($mergeData);


            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');
        }
 

                if ($data["who"] != $this->nhpInfo['participantID'] ) {
            $participantObj = SetupGeneric::useModule('Participant');

            $participantObj->setItemInfo(array('id' => $this->nhpInfo['participantID']));
            $partcipantData = $participantObj->displayItemById();
            $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

            $who = array(
                'displayname' => ucwords($contributor_name),
                'email' => $partcipantData['emailAddress']
            );

            $subject = "smart-ISO NCR Email: You are the new owner of the above NCR.";
            $mergeData = array(
                'twoColData' => array(
                    'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $data['reference']),
                    'assignedto' => array('left' => '<strong>Problem:</strong>', 'right' => $data['problemDescription'])
                ),
                'singleColData' => array(
                    'summary' => '<p><BR>You are the new owner of the above NCR.<BR><BR></p>')
            );

            $emailObj->appendInfo($mergeData);


            $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'purple');
            
        }

    $sql = sprintf(" UPDATE %s.nhp SET whoID = %d,
        locationID=%d,
        businessUnitID=%d,
								date = '%s',
                                                                status = 'A',
								nearmissHazardFlag = '%s',
								signature = %d,
								nature = '%s',
                                                                processid = %d,
                                                                isriskvalid = %d,
								who_r = '%s',
                                                                who_rid = %d,
								time = '%s'
							WHERE ID = %d ", _DB_OBJ_FULL, $this->nhpInfo['participantID'], $this->nhpInfo['location'],$this->nhpInfo['business_unit'],format_date_for_mysql($this->nhpInfo['date']), $this->nhpInfo['near_miss_hazard_flag'], $this->nhpInfo['check_sign'], $this->nhpInfo['nature'], $this->nhpInfo['process'], $this->nhpInfo['risk_valid'], $this->nhpInfo['who_r'], $this->nhpInfo['who_rid'], $this->nhpInfo['time'], $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        
    }

    /**
     * This method is used to manage Problem
     * description,risk_impact
     */
    public function manageProblem() {

        $sql2 = sprintf(" UPDATE %s.nhp SET problemDescription = '%s',
										problemRiskImpact = %d,
										investigationRequired = '%s',
										noInvestigationReqReason = '%s',
                                                                                uploadFilesID = '%s',
										factor = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->nhpInfo['description'], $this->nhpInfo['risk_impact'], $this->nhpInfo['inv_req'], $this->nhpInfo['no_di_reason'], $this->nhpInfo['file'], $this->nhpInfo['factor'], $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->nhpInfo['description']);
          $pStatement2->bindParam(2,$this->nhpInfo['risk_impact']);
          $pStatement2->bindParam(3,$this->nhpId); */

        $pStatement2->execute();
        //dump_array_and_exit($pStatement2->errorInfo());
    }

    /**
     * This method is used to manage Causes
     */
    public function manageCauses() {
        $sql = sprintf("SELECT * FROM %s.nhp_causes WHERE nhpID = %d ", _DB_OBJ_FULL, $this->nhpId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (is_array($resultSet)) {
            // do update
            $this->editCause();
        } else {
            // do insert
            $this->addCause();
        }
    }

        public function manageCausesCW() {
            $userid= getLoggedInUserId();

foreach ($this->nhpInfo["root"] as $key=>$value){
	
	if ($this->nhpInfo["rootid"][$key]>0){
            $sql = sprintf("update  %s.ncr_root_cause set reason='%s',fileids='%s' WHERE ID = %d ", _DB_OBJ_FULL, $value,$this->nhpInfo["file"][$key],$this->nhpInfo["rootid"][$key]);
	}else{
		 $sql = sprintf("insert  %s.ncr_root_cause (reason,ncrid,who,fileids) VALUES ('%s',%d,%d,'%s' )  ", _DB_OBJ_FULL, $value,$this->nhpId,$userid,$this->nhpInfo["file"][$key]);
	}
       $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

}

  
  
    }
    /**
     * This method is used to add cause
     * is_unsafe_act,unsafe_act_percent,unsafe_act_description,lack_skill_percent,lack_skill_description,lack_knowledge_percent,lack_knowledge_description,
     * lack_complaince_percent,lack_complaince_description,is_unsafe_design,unsafe_design_percent,unsafe_design_description,is_faulty_construction,
     * faulty_construction_percent,faulty_construction_description,is_unsafe_condition,unsafe_condition_percent,unsafe_condition_description,
     * is_unsafe_method,unsafe_method_percent,unsafe_method_description
     */
    private function addCause() {
        $sql = sprintf("INSERT INTO %s.nhp_causes (nhpID ,isUnsafeAct ,unsafeActPercent ,UnsafeActDesc ,lackSkillPercent ,lackSkillDesc ,lackKnowledgePercentage ,
										lackKnowledgeDesc ,lackCompliancePercent ,lackComplianceDesc ,isUnsafeDesign ,unsafeDesignPercent ,UnsafeDesignDesc ,
										isFaultyConstruction ,faultyConstructionPercent ,faultyConstructionDesc ,isUnsafeCondition ,unsafeConditionPercent ,
										unsafeConditionDesc ,isUnsafeMethod ,unsafeMethodPercent ,unsafeMethodDesc,root)
									VALUES (%d,'%s',%f,'%s',%f,'%s',%f,'%s',%f,'%s','%s',%f,'%s','%s',%f,'%s','%s',%f,'%s','%s',%f,'%s','%s') ", _DB_OBJ_FULL, $this->nhpId, $this->nhpInfo['is_unsafe_act'], $this->nhpInfo['unsafe_act_percent'], $this->nhpInfo['unsafe_act_description'], $this->nhpInfo['lack_skill_percent'], $this->nhpInfo['lack_skill_description'], $this->nhpInfo['lack_knowledge_percent'], $this->nhpInfo['lack_knowledge_description'], $this->nhpInfo['lack_complaince_percent'], $this->nhpInfo['lack_complaince_description'], $this->nhpInfo['is_unsafe_design'], $this->nhpInfo['unsafe_design_percent'], $this->nhpInfo['unsafe_design_description'], $this->nhpInfo['is_faulty_construction'], $this->nhpInfo['faulty_construction_percent'], $this->nhpInfo['faulty_construction_description'], $this->nhpInfo['is_unsafe_condition'], $this->nhpInfo['unsafe_condition_percent'], $this->nhpInfo['unsafe_condition_description'], $this->nhpInfo['is_unsafe_method'], $this->nhpInfo['unsafe_method_percent'], $this->nhpInfo['unsafe_method_description'], $this->nhpInfo['root']);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->nhpId);
          $pStatement->bindParam(2,$this->nhpInfo['is_unsafe_act']);
          $pStatement->bindParam(3,$this->nhpInfo['unsafe_act_percent']);
          $pStatement->bindParam(4,$this->nhpInfo['unsafe_act_description']);
          $pStatement->bindParam(5,$this->nhpInfo['lack_skill_percent']);
          $pStatement->bindParam(6,$this->nhpInfo['lack_skill_description']);
          $pStatement->bindParam(7,$this->nhpInfo['lack_knowledge_percent']);
          $pStatement->bindParam(8,$this->nhpInfo['lack_knowledge_description']);
          $pStatement->bindParam(9,$this->nhpInfo['lack_complaince_percent']);
          $pStatement->bindParam(10,$this->nhpInfo['lack_complaince_description']);
          $pStatement->bindParam(11,$this->nhpInfo['is_unsafe_design']);
          $pStatement->bindParam(12,$this->nhpInfo['unsafe_design_percent']);
          $pStatement->bindParam(13,$this->nhpInfo['unsafe_design_description']);
          $pStatement->bindParam(14,$this->nhpInfo['is_faulty_construction']);
          $pStatement->bindParam(15,$this->nhpInfo['faulty_construction_percent']);
          $pStatement->bindParam(16,$this->nhpInfo['faulty_construction_description']);
          $pStatement->bindParam(17,$this->nhpInfo['is_unsafe_condition']);
          $pStatement->bindParam(18,$this->nhpInfo['unsafe_condition_percent']);
          $pStatement->bindParam(19,$this->nhpInfo['unsafe_condition_description']);
          $pStatement->bindParam(20,$this->nhpInfo['is_unsafe_method']);
          $pStatement->bindParam(21,$this->nhpInfo['unsafe_method_percent']);
          $pStatement->bindParam(22,$this->nhpInfo['unsafe_method_description']); */

        $pStatement->execute();
    }

    /**
     * This method is used to edit cause
     * is_unsafe_act,unsafe_act_percent,unsafe_act_description,lack_skill_percent,lack_skill_description,lack_knowledge_percent,lack_knowledge_description,
     * lack_complaince_percent,lack_complaince_description,is_unsafe_design,unsafe_design_percent,unsafe_design_description,is_faulty_construction,
     * faulty_construction_percent,faulty_construction_description,is_unsafe_condition,unsafe_condition_percent,unsafe_condition_description,
     * is_unsafe_method,unsafe_method_percent,unsafe_method_description
     */
    private function editCause() {
        $sql = sprintf("UPDATE %s.nhp_causes SET isUnsafeAct = '%s' ,
										unsafeActPercent = %f ,
										UnsafeActDesc = '%s' ,
										lackSkillPercent = %f ,
										lackSkillDesc = '%s' ,
										lackKnowledgePercentage = %f,
										lackKnowledgeDesc = '%s',
										lackCompliancePercent = %f,
										lackComplianceDesc = '%s',
										isUnsafeDesign = '%s',
										unsafeDesignPercent = %f,
										UnsafeDesignDesc  = '%s',
										isFaultyConstruction = '%s',
										faultyConstructionPercent = %f,
										faultyConstructionDesc = '%s',
										isUnsafeCondition = '%s',
										unsafeConditionPercent = %f,
										unsafeConditionDesc = '%s',
										isUnsafeMethod = '%s',
										unsafeMethodPercent = %f,
										unsafeMethodDesc = '%s',
										root = '%s'
									WHERE nhpID = %d ", _DB_OBJ_FULL, $this->nhpInfo['is_unsafe_act'], $this->nhpInfo['unsafe_act_percent'], $this->nhpInfo['unsafe_act_description'], $this->nhpInfo['lack_skill_percent'], $this->nhpInfo['lack_skill_description'], $this->nhpInfo['lack_knowledge_percent'], $this->nhpInfo['lack_knowledge_description'], $this->nhpInfo['lack_complaince_percent'], $this->nhpInfo['lack_complaince_description'], $this->nhpInfo['is_unsafe_design'], $this->nhpInfo['unsafe_design_percent'], $this->nhpInfo['unsafe_design_description'], $this->nhpInfo['is_faulty_construction'], $this->nhpInfo['faulty_construction_percent'], $this->nhpInfo['faulty_construction_description'], $this->nhpInfo['is_unsafe_condition'], $this->nhpInfo['unsafe_condition_percent'], $this->nhpInfo['unsafe_condition_description'], $this->nhpInfo['is_unsafe_method'], $this->nhpInfo['unsafe_method_percent'], $this->nhpInfo['unsafe_method_description'], $this->nhpInfo['root'], $this->nhpId);

        $pStatement = $this->dbHand->prepare($sql);

        /* $pStatement->bindParam(1,$this->nhpInfo['is_unsafe_act']);
          $pStatement->bindParam(2,$this->nhpInfo['unsafe_act_percent']);
          $pStatement->bindParam(3,$this->nhpInfo['unsafe_act_description']);
          $pStatement->bindParam(4,$this->nhpInfo['lack_skill_percent']);
          $pStatement->bindParam(5,$this->nhpInfo['lack_skill_description']);
          $pStatement->bindParam(6,$this->nhpInfo['lack_knowledge_percent']);
          $pStatement->bindParam(7,$this->nhpInfo['lack_knowledge_description']);
          $pStatement->bindParam(8,$this->nhpInfo['lack_complaince_percent']);
          $pStatement->bindParam(9,$this->nhpInfo['lack_complaince_description']);
          $pStatement->bindParam(10,$this->nhpInfo['is_unsafe_design']);
          $pStatement->bindParam(11,$this->nhpInfo['unsafe_design_percent']);
          $pStatement->bindParam(12,$this->nhpInfo['unsafe_design_description']);
          $pStatement->bindParam(13,$this->nhpInfo['is_faulty_construction']);
          $pStatement->bindParam(14,$this->nhpInfo['faulty_construction_percent']);
          $pStatement->bindParam(15,$this->nhpInfo['faulty_construction_description']);
          $pStatement->bindParam(16,$this->nhpInfo['is_unsafe_condition']);
          $pStatement->bindParam(17,$this->nhpInfo['unsafe_condition_percent']);
          $pStatement->bindParam(18,$this->nhpInfo['unsafe_condition_description']);
          $pStatement->bindParam(19,$this->nhpInfo['is_unsafe_method']);
          $pStatement->bindParam(20,$this->nhpInfo['unsafe_method_percent']);
          $pStatement->bindParam(21,$this->nhpInfo['unsafe_method_description']);
          $pStatement->bindParam(22,$this->nhpId); */

        $pStatement->execute();
    }

    /**
     * This method is used to manage Environment
     * environmental
     */
    public function manageEnvironment() {
        $sql2 = sprintf(" UPDATE %s.nhp SET environmental = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->nhpInfo['environmental'], $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->nhpInfo['environmental']);
          $pStatement2->bindParam(2,$this->nhpId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to manage Disposition
     * disposition
     */
    public function manageDisposition() {
        $sql2 = sprintf(" UPDATE %s.nhp SET disposition = %d
									WHERE ID = %d", _DB_OBJ_FULL, $this->nhpInfo['disposition'], $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->nhpInfo['disposition']);
          $pStatement2->bindParam(2,$this->nhpId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to manage action
     * actions = array(array('action'=>'dfg','who'=>'gdfg','due_date'=>'gdfg','action_id'=>23),
     * 					array('action'=>'dfg','who'=>'gdfg','due_date'=>'gdfg','action_id'=>26),
     * 					array('action'=>'dfg','who'=>'gdfg','due_date'=>'gdfg','action_id'=>0));
     */
    public function manageActions() {

      // var_dump ($_POST); 
      // dump_array($this->nhpInfo);exit();
   
        if (is_array($this->nhpInfo['actions'])) {

            $actionHandler = new Action();

			
			//            $sql2a = sprintf("UPDATE %s.actions SET approveAU = 1,donedate='%s' 
			//						WHERE record = %d", _DB_OBJ_FULL, date("Y-m-d"),$this->nhpId);

            //$pStatement2a = $this->dbHand->prepare($sql2a);

            //$pStatement2a->execute();
			
            $action_ids = "";
            
            $save_finish = (int) $_POST['save_finish'];
            $update_save = (int) $_POST['update_save'];
                
            foreach ($this->nhpInfo['actions'] as $value) {


                $action_dat = $actionHandler->viewActionSelectDetail($value['action_id']);

                $this->actionData = array('module_name' => 'nhp', 'record' => $this->nhpId,'description' => $value['action'],
                    'who' => $value['who'], 'whoAU' => $value['whoAU'],'who2AU' => $value['who2AU'], 'due_date' => $value['when'],'element' => 'nhp');

                $when = date('m/d/Y', strtotime($value['when']));
                $whenCheck = date('Y-m-d', strtotime($value['when']));




                if ((int)$value['action_id'] >0) {
                    // do update
                    $this->actionHandling->setActionDetails($value['action_id'], $this->actionData);
                    $this->actionHandling->updateAction2015();
					$action_ids .= $value['action_id'] . ',';
				}else{
                    // do add
                    $this->actionHandling->setActionDetails(0, $this->actionData);
                   $new_action_id = $this->actionHandling->addAction2015();
                      $action_ids .= $new_action_id . ',';
                      
                    if ($update_save == 1){
                        $this->sendAction($new_action_id);
                    }
                  
                }
            }

            $action_ids = rtrim($action_ids, ',');

            $sql2 = sprintf("UPDATE %s.nhp SET actionsID = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $action_ids, $this->nhpId);

            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();

            $sql3 = sprintf("UPDATE %s.nhp SET noActionReason = '%s',noAction = '%s',reason='%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->nhpInfo['no_action_reason'], $this->nhpInfo['no_action'], $this->nhpInfo['reason'], $this->nhpId);

            $pStatement3 = $this->dbHand->prepare($sql3);
            $pStatement3->execute();
             /*dump_array($pStatement3->errorInfo());
              exit; */
        }
    }

    /*
     * This method is used to update nhp process
     * process,is_risk
     */

    public function manageProcess() {

        $sql2 = sprintf(" UPDATE %s.nhp SET processID = %d,
										isRiskValid = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $this->nhpInfo['process'], $this->nhpInfo['is_risk'], $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->nhpInfo['process']);
          $pStatement2->bindParam(2,$this->nhpInfo['is_risk']);
          $pStatement2->bindParam(3,$this->nhpId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to update files id
     */
    public function addFiles() {

        $record_data = $this->viewNhpById();

        $new_files_id_string = $record_data['uploadFilesID'] . ',' . $this->nhpInfo['file_id'];
        $new_files_id_string = ltrim($new_files_id_string, ',');

        $sql2 = sprintf(" UPDATE %s.nhp SET uploadFilesID = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $new_files_id_string, $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$new_files_id_string);
          $pStatement2->bindParam(2,$this->nhpId); */

        $pStatement2->execute();
    }

    /**
     * This method is used to delete file id
     */
    public function deleteFile() {

        $record_data = $this->viewNhpById();

        $files_id_arr = explode(',', $record_data['uploadFilesID']);

        if (is_array($files_id_arr)) {
            foreach ($files_id_arr as $value) {
                if ($value != $this->nhpInfo['file_id']) {
                    $new_files_id_string .= $value . ',';
                }
            }
            $new_files_id_string = rtrim($new_files_id_string, ',');

            $sql2 = sprintf(" UPDATE %s.nhp SET uploadFilesID = '%s'
									WHERE
										ID = %d", _DB_OBJ_FULL, $new_files_id_string, $this->nhpId);

            $pStatement2 = $this->dbHand->prepare($sql2);

            /* $pStatement2->bindParam(1,$new_files_id_string);
              $pStatement2->bindParam(2,$this->nhpId); */

            $pStatement2->execute();
        }
    }

    /*
     * This method is used to delete Nhp record
     */

    public function deleteNhp() {
        
    }

    /*
     * This method is used to archive Nhp record
     */

    public function archiveNhp() {
        $sql2 = sprintf(" UPDATE %s.nhp SET archive = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->nhpInfo['archive'], $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->nhpInfo['archive']);
          $pStatement2->bindParam(2,$this->nhpId); */

        $pStatement2->execute();
    }

    /*
     * This method is used to completely delete Nhp record
     */

    public function purgeNhp() {
        $rec_details = $this->viewNhpById();
        //dump_array($rec_details);
        $action_arr = explode(',', $rec_details['actionsID']);
        //dump_array($action_arr);

        if (is_array($action_arr)) {
            foreach ($action_arr as $value) {
                if ($value != '') {
                    $this->actionHandling->setActionDetails($value, "");
                    $this->actionHandling->deleteAction();
                }
            }
        }

        $sql = sprintf("DELETE FROM %s.nhp_causes WHERE nhpID = %d", _DB_OBJ_FULL, $this->nhpId);

        $pStatement = $this->dbHand->prepare($sql);
        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();

        $sql2 = sprintf("DELETE FROM %s.nhp WHERE ID = %d", _DB_OBJ_FULL, $this->nhpId);

        $pStatement2 = $this->dbHand->prepare($sql2);
        //$pStatement2->bindParam(1,$this->nhpId);
        $pStatement2->execute();
    }

    /**
     * This method is used to get last insert id
     */
    public function lastRecordId() {
        return $this->nhpId;
    }

    /*
     * This method is used to view an nhp record
     */

    public function viewNhpById() {

        $sql = sprintf("SELECT * FROM %s.nhp WHERE ID = %d", _DB_OBJ_FULL, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();
        //dump_array($pStatement->errorInfo());
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet[0];
    }

    /**
     * This method is used to view Causes
     */
    public function viewCauses() {
        $sql = sprintf("SELECT * FROM %s.nhp_causes WHERE nhpID = %d ", _DB_OBJ_FULL, $this->nhpId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet[0];
    }

    /*
     * This method is used to view nhp records
     */

    public function viewNhps($locid=0,$search='') {

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);
if ($locid==0)
    $locstr='';
else
$locstr='and A.locationID='.$locid;

if ($search=='0')
    $filter='';
else{
$filter=" and (A.reference like '%".$search."%' or A.problemDescription like '%".$search."%'";
$filter.=" or BU.buname like '%".$search."%'";
$filter.=" or P.forename like '%".$search."%'";
$filter.=" or P.surname like '%".$search."%'";
$filter.=" or T.name like '%".$search."%'";
$filter.=")";
}
        $sql = sprintf("SELECT A.*,userID,dateTimestamp,T.name,P.forename+' '+P.surname as owner,BU.buName FROM %s.nhp A
            LEFT JOIN %s.ncr_type T ON A.nearmisshazardflag =T.ID
            LEFT JOIN %s.participant_database P ON A.whoID =P.participantID
            LEFT JOIN %s.business_units BU ON A.businessUnitID =BU.buID
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
                        
			WHERE A.archive = '%s' %s and (A.che = 0 OR A.che is null) %s ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive'],$locstr,$filter);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*
     * This method is used to view action records
     */

    
                       public function viewNhpsNew_Action($locid,$search) {

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);
if ($locid==0)
    $locstr='';
else
$locstr='and A.locationID='.$locid;

if ($search=='0')
    $filter='';
else{
$filter=" and (A.reference like '%".$search."%' or A.problemDescription like '%".$search."%'";
$filter.=" or BU.buname like '%".$search."%'";
$filter.=" or P.forename like '%".$search."%'";
$filter.=" or P.surname like '%".$search."%'";
$filter.=" or T.name like '%".$search."%'";
$filter.=")";
}
        $sql = sprintf("SELECT A.*,userID,dateTimestamp,T.name,Q.*  FROM %s.nhp A
             LEFT JOIN %s.ncr_type T ON A.nearmisshazardflag =T.ID
             LEFT JOIN %s.participant_database P ON A.whoID =P.participantID
            LEFT JOIN %s.business_units BU ON A.businessUnitID =BU.buID
             LEFT JOIN %s.actions Q ON (A.ID =Q.record and Q.moduleElement='nhp') 
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' %s AND isNull(A.che,0) = 0 %s ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive'],$locstr,$filter);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }
    
                           public function viewNhpsNew_ActionA($locid,$search) {

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);
if ($locid==0)
    $locstr='';
else
$locstr='and A.locationID='.$locid;

if ($search=='0')
    $filter='';
else{
$filter=" and (A.reference like '%".$search."%' or A.problemDescription like '%".$search."%'";
$filter.=" or BU.buname like '%".$search."%'";
$filter.=" or P.forename like '%".$search."%'";
$filter.=" or P.surname like '%".$search."%'";
$filter.=" or T.name like '%".$search."%'";
$filter.=")";
}
        $sql = sprintf("SELECT A.*,userID,dateTimestamp,T.name,Q.*  FROM %s.nhp A
             LEFT JOIN %s.ncr_type T ON A.nearmisshazardflag =T.ID
             LEFT JOIN %s.participant_database P ON A.whoID =P.participantID
            LEFT JOIN %s.business_units BU ON A.businessUnitID =BU.buID
             LEFT JOIN %s.actions Q ON (A.ID =Q.record and Q.moduleElement='nhp') 
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' %s AND isNull(A.che,0) = 1 %s ORDER BY A.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive'],$locstr,$filter);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }
    
    public function viewActions() {

        $resultSet = $this->viewNhpById();
        $actions = $resultSet['actionsID'];
        $action_details = array();

        if ($actions != '') {
            $actions_id_arr = explode(',', $actions);
            if (is_array($actions_id_arr)) {
                $i = 0;
                foreach ($actions_id_arr as $value) {
                    $this->actionHandling->setActionDetails($value, "");
                    $action_data = $this->actionHandling->viewAction();
                    if ($action_data) {
                        $action_details[$i] = $this->actionHandling->viewAction();
                        $action_details[$i]['action_id'] = $value;
                        $i++;
                    }
                }
            }
        }

        return $action_details;
    }

    public function getOutstandingActionsdeprecated($p_overdue) {

        if ($p_overdue) {
            $data = $this->actionHandling->viewOverdueActions('nhp');
        } else {
            $data = $this->actionHandling->viewAllActionByModule('nhp');
        }

        if (is_array($data)) {
            $i = 0;
            foreach ($data as $value) {

                $action_data = "";
                $search_value1 = $value['ID'];
                $search_value2 = $value['ID'] . ',%';
                $search_value3 = '%,' . $value['ID'];
                $search_value4 = '%,' . $value['ID'] . ',%';

                $sql = sprintf("SELECT M.reference,M.businessUnitID,M.ID AS nhp_id FROM %s.nhp M
											WHERE M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' OR M.actionsID LIKE '%s' ", _DB_OBJ_FULL, $search_value1, $search_value2, $search_value3, $search_value4);

                $pStatement = $this->dbHand->prepare($sql);

                /* $pStatement->bindParam(1,$search_value1);
                  $pStatement->bindParam(2,$search_value2);
                  $pStatement->bindParam(3,$search_value3);
                  $pStatement->bindParam(4,$search_value4); */

                $pStatement->execute();
                $action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

                if (is_array($action_data)) {

                    foreach ($action_data as $value2) {
                        $new_data[$i]['reference'] = $value2['reference'];
                        $new_data[$i]['bu'] = $value2['businessUnitID'];
                        $new_data[$i]['action_id'] = $value['ID'];
                        $new_data[$i]['who'] = $value['who'];
                        $new_data[$i]['due_date'] = $value['dueDate'];
                        $new_data[$i]['action'] = $value['actionDescription'];
                        $new_data[$i]['risk_id'] = $value2['nhp_id'];
                    }
                    $i++;
                }
            }
        }
        return $new_data;
    }

    public function addOutstandingAction() {

        $sql = sprintf("SELECT actionsID FROM %s.nhp WHERE ID = %d ", _DB_OBJ_FULL, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();

        $improvements = $pStatement->fetchColumn();
        $new_improvements = $improvements . ',' . $this->nhpInfo['new_improvement'];

        $sql2 = sprintf("UPDATE %s.nhp SET actionsID = '%s' WHERE ID = %d ", _DB_OBJ_FULL, $new_improvements, $this->nhpId);
        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$new_improvements);
          $pStatement2->bindParam(2,$this->nhpId); */
        $pStatement2->execute();
    }

    protected function getNoOfNhps() {

        $sql = sprintf("SELECT * FROM %s.nhp ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //dump_array($row);
                $bu_id = $row['businessUnitID'];
                $date_time = $row['date'];
                $year = substr($date_time, 0, 4);
                if ($row['nearmissHazardFlag'] == 'N') {
                    $result_set['close_call'][$year][$bu_id] ++;
                } elseif ($row['nearmissHazardFlag'] == 'O') {
                    $result_set['conformance'][$year][$bu_id] ++;
                } elseif ($row['nearmissHazardFlag'] == 'H') {
                    $result_set['hazard'][$year][$bu_id] ++;
                } elseif ($row['nearmissHazardFlag'] == 'V') {
                    $result_set['vol'][$year][$bu_id] ++;
                }
                $result_set['all'][$year][$bu_id] ++;
            }


            return $result_set;
        }
    }

    protected function getNhpType() {

        $sql = sprintf("SELECT * FROM %s.nhp ", _DB_OBJ_FULL);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                $bu_id = $row['businessUnitID'];
                $type = $row['nearmissHazardFlag'];
                //$year = substr($date_time,0,4);

                $result_set[$type][$bu_id] ++;
                //dump_array($result_set);
            }

            return $result_set;
        }
    }

    protected function getGraphDataRisk() {

        $sql = sprintf("SELECT * FROM %s.nhp ", _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();

        if ($no_rows) {

            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {

                $bu_id = $row['businessUnitID'];
                $risk_impact = $row['problemRiskImpact'];
                $disposition = $row['disposition'];
                $date_time = $row['date'];

                $year = substr($date_time, 0, 4);

                if (!empty($risk_impact) && $bu_id) {
                    $result_set['risk'][$year][$bu_id][$risk_impact] ++;
                }

                if (!empty($disposition) && $bu_id) {
                    $result_set['disposition'][$year][$bu_id][$disposition] ++;
                }
            }

            return $result_set;
        }
    }

    protected function getGraphDataCauses() {

        $sql = sprintf("SELECT C.*,N.businessUnitID,N.date FROM %s.nhp_causes C
												INNER JOIN %s.nhp N
											ON N.ID = C.nhpID", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                $bu_id = $row['businessUnitID'];
                $date_time = $row['date'];

                $year = substr($date_time, 0, 4);

                $result_set[$year][$bu_id]['unsafe_act'] += (int) $row['isUnsafeAct'];
                $result_set[$year][$bu_id]['unsafe_design'] += (int) $row['isUnsafeDesign'];
                $result_set[$year][$bu_id]['faulty_construction'] += (int) $row['isFaultyConstruction'];
                $result_set[$year][$bu_id]['unsafe_condition'] += (int) $row['isUnsafeCondition'];
                $result_set[$year][$bu_id]['unsafe_method'] += (int) $row['isUnsafeMethod'];
            }

            return $result_set;
        }
    }

    protected function getGraphDataEnvironment() {

        //$sql = sprintf("SELECT C.*,N.businessUnitID,N.date FROM %s.nhp_causes C
        //	INNER JOIN %s.nhp N
        //ON N.ID = C.nhpID",_DB_OBJ_FULL,_DB_OBJ_FULL);

        $sql = sprintf("SELECT C.*,N.businessUnitID,N.date FROM %s.nhp_options C
												INNER JOIN %s.nhp N
											ON N.ID = C.ID", _DB_OBJ_FULL, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $no_rows = $pStatement->rowCount();
        if ($no_rows) {
            while ($row = $pStatement->fetch(PDO::FETCH_ASSOC)) {
                //$bu_id = $row['businessUnitID'];
                $date_time = $row['date'];

                $year = substr($date_time, 0, 4);
                //dump_array($row);
                if ($row['envSubType'] == 'T') {
                    if ($row['optionLabel'] == 'Fauna/Flora') {
                        $result_set['type']['T']['Fauna/Flora'] ++;
                    }
                    if ($row['optionLabel'] == 'Water Pollution') {
                        $result_set['type']['T']['Water Pollution'] ++;
                    }
                    if ($row['optionLabel'] == 'Noise/Vibration') {
                        $result_set['type']['T']['Noise/Vibration'] ++;
                    }
                    if ($row['optionLabel'] == 'Fire') {
                        $result_set['type']['T']['Fire'] ++;
                    }
                    if ($row['optionLabel'] == 'Gas/Fumes') {
                        $result_set['type']['T']['Gas/Fumes'] ++;
                    }
                    if ($row['optionLabel'] == 'Chemical/Oil Spill') {
                        $result_set['type']['T']['Chemical/Oil Spill'] ++;
                    }
                }
                if ($row['envSubType'] == 'S') {
                    if ($row['optionLabel'] == 'Continuing Downstream') {
                        $result_set['scale']['S']['Continuing Downstream'] ++;
                    }
                    if ($row['optionLabel'] == 'Spreading Downwind') {
                        $result_set['scale']['S']['Spreading Downwind'] ++;
                    }
                    if ($row['optionLabel'] == 'Continuing') {
                        $result_set['scale']['S']['Continuing'] ++;
                    }
                    if ($row['optionLabel'] == 'Reducing') {
                        $result_set['scale']['S']['Reducing'] ++;
                    }
                    if ($row['optionLabel'] == 'Local to Site') {
                        $result_set['scale']['S']['Local to Site'] ++;
                    }
                    if ($row['optionLabel'] == 'Contained on site') {
                        $result_set['scale']['S']['Contained on site'] ++;
                    }
                }
            }

            return $result_set;
        }
    }

    public function updateStatus() {
        $sql = sprintf("UPDATE %s.nhp SET status = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->nhpId);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();
    }

    public function addNhpFile() {
        $files_arr = $this->getNhpFile();
        $files = implode(',', $files_arr);

        $new_files = $files . ',' . $this->nhpInfo['file_id'];

        $sql = sprintf("UPDATE %s.nhp SET uploadFilesID = '%s' WHERE ID = %d", _DB_OBJ_FULL, $new_files, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);
        /* $pStatement->bindParam(1,$new_files);
          $pStatement->bindParam(2,$this->nhpId); */

        $pStatement->execute();
    }

    public function getNhpFile() {

        $sql = sprintf("SELECT uploadFilesID FROM %s.nhp WHERE ID = %d", _DB_OBJ_FULL, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpId);
        $pStatement->execute();
        $resultSet = $pStatement->fetchColumn();

        $files_list = explode(',', $resultSet);
        return $files_list;
    }

    public function sendActionAlerts($p_record_id) {

        $this->nhpId = $p_record_id;

        $nhp_details = $this->viewNhpById();
       

        $record_data = $this->viewActions();

        if (is_array($record_data)) {
            $i = 0;

            $orgObj = SetupGeneric::useModule('Organigram');
            $orgObj->setItemInfo(array('id' => $nhp_details['businessUnitID']));
            $org_data = $orgObj->displayItemById();
            $orgObj = null;

            foreach ($record_data as $value) {

                $email_data[$i]['reference'] = $nhp_details['reference'];
                $email_data[$i]['summary'] = $value['actionDescription'];
                $email_data[$i]['due_date'] = format_date($value['dueDate']);
                $email_data[$i]['who'] = $value['who'];
                $email_data[$i]['whoAU'] = $value['whoAU'];
                $email_data[$i]['problem_description'] = $nhp_details['problemDescription'];
                $email_data[$i]['bu'] = $org_data['buName'];

                //echo $value['ID']; exit;

                $this->actionHandling->updateStatus($value['ID']);
                $i++;
            }
        }

        return $email_data;
    }

    public function searchNhp() {

        $filter = "";

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '0' ",_DB_OBJ_FULL);

        if ($this->nhpInfo['env_type']) {
            $filter .= " AND (A.environmental LIKE '" . $this->nhpInfo['env_type'] . "' OR A.environmental LIKE '" . $this->nhpInfo['env_type'] . ",%' OR ";
            $filter .= " A.environmental LIKE '%," . $this->nhpInfo['env_type'] . "' OR A.environmental LIKE '%," . $this->nhpInfo['env_type'] . ",%')";
        }
        if ($this->nhpInfo['env_scale']) {
            $filter .= " AND (A.environmental LIKE '" . $this->nhpInfo['env_scale'] . "' OR A.environmental LIKE '" . $this->nhpInfo['env_scale'] . ",%' OR ";
            $filter .= " A.environmental LIKE '%," . $this->nhpInfo['env_scale'] . "' OR A.environmental LIKE '%," . $this->nhpInfo['env_scale'] . ",%')";
        }
        if ($this->nhpInfo['disposition']) {
            $filter .= " AND A.disposition = " . $this->nhpInfo['disposition'];
        }

        if ($this->nhpInfo['nearmiss_hazard'] == 'N' || $this->nhpInfo['nearmiss_hazard'] == 'H' || $this->nhpInfo['nearmiss_hazard'] == 'O') {
            $filter .= " AND A.nearmissHazardFlag = '" . $this->nhpInfo['nearmiss_hazard'] . "'";
        }

        if ($this->nhpInfo['start_date'] != '' && $this->nhpInfo['end_date'] != '') {
            $filter .= " AND (dateTimestamp BETWEEN '" . $this->nhpInfo['start_date'] . " 00:00:00.000' AND '" . $this->nhpInfo['end_date'] . " 23:59:59.000')";
            $join_type = 'INNER';
            $date_timestamp_not_null = 'AND dateTimestamp IS NOT NULL';
        } else {
            $join_type = 'LEFT OUTER';
            $date_timestamp_not_null = '';
        }

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.nhp A
				" . $join_type . " JOIN (
					SELECT recID,
						dateTimestamp,
						whoID as userID,
						reference as recordRef,
						role
					FROM %s.module_tracker
					WHERE module = 'NHP'
					AND action = 'add'
					" . $date_timestamp_not_null . "
				) B
				ON recordRef = reference
				WHERE A.archive = '0'", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive']);

        $sql = $sql . $filter . "  ORDER BY A.ID DESC";

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    /*     * *
     * * This method is used to get
     * * listing records for Export
     * */

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'serach') {

            return $this->getSearchExportData();
        } else if ($type == 'full') {
            return $this->getNhpExportDataFull();
        } else {

            return $this->getNhpExportData();
        }
    }

//	public function getPendingMeActions() {
///
    //	$this->sql_query = sprintf("SELECT reference,businessUnitID as buID,actionsID FROM %s.nhp
    //					WHERE actionsID IS NOT NULL
    //					ORDER BY ID DESC",_DB_OBJ_FULL);
    //	return $this->getActionsByFilter(__METHOD__);
//	}
    //private function getPendingMeActions() {
    //	return $this->moduleHandler->getPendingMeActions();
    //}
    public function getNhpExportDataFullDec() {
            $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $this->setNhpInfo(1, array('archive' => $archive_session));
        $nhp_records = $this->viewNhp_Action();
        //dump_array($nhp_records);
        //exit;
        if (!empty($nhp_records)) {

            
        }
        
    }
    public function getNhpExportDataFull($locid,$filter) {

        $heading = array(array('refrence' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Owner', 'due' => 'When', 'log' => 'Log Date', 'loc' => 'Location', 'who_r' => 'Who Reported', '0' => 'Time', 't' => 'Classification', 'n' => 'Nature', '1' => 'Problem Desc.', '2' => 'Problem Risk Impact', 'ins' => 'Detailed Investigation', 'cf' => 'Contributing Factor', 'u' => 'Unsafe Act %', 'ud' => 'Unsafe Act Desc.', 'l' => 'Lack Skill %', 'ld' => 'Lack Skill  Desc.', 'k' => 'Lack Knowledge %', 'kd' => 'Lack Knowledge  Desc.', 'c' => 'Lack Compliance %', 'cd' => 'Lack Compliance  Desc.', 'ud' => 'Unsafe Desgin %', 'udd' => 'Unsafe Desgin Desc.', 'fc' => 'Faulty Construction %', 'fcd' => 'Faulty Construction Desc.', 'uc' => 'Unsafe Condition %', 'ucd' => 'Unsafe Condition Desc.', 'um' => 'Unsafe Method %', 'umd' => 'Unsafe Method Desc.', 'r' => 'Root Cause', '3' => 'Environmental', '4' => 'Disposition', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'adue' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.', 'pr' => 'Process Number', 'rv' => 'Risk Rating still valid', 'root_cause' => 'Root Cause'));
        $p_moduleName = 'Nonconformance nhp';
        $tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
        //echo $tab_type;
        $actTrackObj = new ActionTracker();

        $actTrackObj->setActionTrackerInfo('Nonconformance nhp', $tab_type, $p_dateFilter = '');
        $resultset = $actTrackObj->getActionsForActionTracker();

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $this->setNhpInfo(1, array('archive' => $archive_session));
        
 $filter;
        $nhp_records = $this->viewNhpsNew($locid,$filter);
        //dump_array($nhp_records);
        //exit;
        if (!empty($nhp_records)) {

            foreach ($nhp_records as $resultElement) {
                $orgObj = SetupGeneric::useModule('Organigram');
                $locObj = SetupGeneric::useModule('Locationgram');
                $participantObj = SetupGeneric::useModule('Participant');

                $ac_id = $resultElement['ID'];
                $action_description = compact_action_tracker_description($resultElement['actionDescription']);
                $action_description_full = javascript_safe_string($resultElement['actionDescription']);
                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $resultElement['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $orgObj->setItemInfo(array('id' => $resultElement['businessUnitID']));
                $bu_details = $orgObj->displayItemById();



                $participant_id = $resultElement['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $resultElement['actionsID'],
                ));

                $data_records7 = $type->displayItemById5();
                $type->setItemInfo(array(
                    'id' => $resultElement['ID'],
                ));

                $data_records8 = $type->displayItemById6();
                //dump_array($data_records8);

$root_cause_Arr=$this->get_root_cause($resultElement['ID']);
 $root_cause='';
if(is_array($root_cause_Arr)){
  foreach($root_cause_Arr as $root_row){
      $root_cause.=$root_row["reason"]."\n";
  }

}
$result[$i]['root_cause'] =$root_cause;
                $result[$i]['refrence'] = $resultElement['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['due'] = format_datetime($resultElement['date']);
                $result[$i]['log'] = format_datetime($resultElement['dateTimestamp']);
                $result[$i]['loc'] = $location;
                $result[$i]['who_r'] = $resultElement['who_r'];
                $result[$i]['0'] = $resultElement['time'];
 $result[$i]['t'] = $resultElement['name'];
                if ($resultElement['nearmissHazardFlag'] == '1') {
                    $type22 = 'Close Call';
                }
                if ($resultElement['nearmissHazardFlag'] == '2') {
                    $type22 = 'Contractor';
                }
                if ($resultElement['nearmissHazardFlag'] == '3') {
                    $type22 = 'Design';
                }
                if ($resultElement['nearmissHazardFlag'] == '4') {
                    $type22 = 'Hazard';
                }
                if ($resultElement['nearmissHazardFlag'] == '5') {
                    $type22 = 'Non Conformance';
                }
                if ($resultElement['nearmissHazardFlag'] == '6') {
                    $type22 = 'Vehicle';
                }
                if ($resultElement['nearmissHazardFlag'] == '7') {

                    $type22 = 'Violence or Aggression';
                }
                if ($resultElement['nearmissHazardFlag'] == '8') {
                    $type22 = 'Company';
                }


                if ($resultElement['nature'] == '1') {
                    $nature = 'Environment';
                }
                if ($resultElement['nature'] == '2') {
                    $nature = 'Quailty';
                }
                if ($resultElement['nature'] == '3') {
                    $nature = 'Safety';
                }
                if ($resultElement['nature'] == '4') {
                    $nature = 'Security';
                }
                if ($resultElement['nature'] == '5') {
                    $nature = 'Other';
                }
                //$result[$i]['t'] = $type22;
                $result[$i]['n'] = $nature;
                $result[$i]['1'] = $resultElement['problemDescription'];
                $type->setItemInfo(array(
                    'id' => $resultElement['problemRiskImpact'],
                ));

                $data_records2 = $type->displayItemById2();
                $result[$i]['2'] = $data_records2['name'];
                if ($resultElement['investigationRequired'] == '1') {
                    $ins = 'Yes';
                } else {
                    $ins = 'No';
                }
                $result[$i]['ins'] = $ins;
                $result[$i]['cf'] = $resultElement['factor'];
                $result[$i]['u'] = $data_records8['unsafeActPercent'];
                $result[$i]['ud'] = $data_records8['unsafeActPercent'];
                $result[$i]['l'] = $data_records8['lackSkillPercent'];
                $result[$i]['ld'] = $data_records8['lackSkillPercent'];
                $result[$i]['k'] = $data_records8['lackKnowledgePercentage'];
                $result[$i]['kd'] = $data_records8['lackKnowledgeDesc'];
                $result[$i]['c'] = $data_records8['lackCompliancePercent'];
                $result[$i]['cd'] = $data_records8['lackComplianceDesc'];
                $result[$i]['ud'] = $data_records8['unsafeDesignPercent'];
                $result[$i]['udd'] = $data_records8['UnsafeDesignDesc'];
                $result[$i]['fc'] = $data_records8['faultyConstructionPercent'];
                $result[$i]['fcd'] = $data_records8['faultyConstructionDesc'];
                $result[$i]['uc'] = $data_records8['unsafeConditionPercent'];
                $result[$i]['ucd'] = $data_records8['unsafeConditionDesc'];
                $result[$i]['um'] = $data_records8['unsafeMethodPercent'];
                $result[$i]['umd'] = $data_records8['unsafeMethodDesc'];
                $result[$i]['r'] = $data_records8['root'];

                //$ev = explode(',', $resultElement['environmental']);
                //	$i = 0;
                //foreach($ev as $val){
                $type->setItemInfo(array(
                    'id' => $resultElement['environmental'],
                ));

                $data_records9 = $type->displayItemById7();
//dump_array($data_records9);
//if($data_records9['optionLabel']){
//$eve[$i] = $data_records9['optionLabel'];
//$i++;
//}
                //}
                //dump_array($eve);
                // if($eve){
                // $e = implode(',',$eve);
                // }else{
                // $e ='-';
                // }
                //echo $e;

                $result[$i]['3'] = $data_records9['optionLabel'];
                $type->setItemInfo(array(
                    'id' => $resultElement['disposition'],
                ));

                $data_records10 = $type->displayItemById7();
                $result[$i]['4'] = $data_records10['optionLabel'];
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;
                $i++;
            }
            //dump_array($result);
            //exit;
            $result = array_merge($heading, $result);
            return $result;
        }
		else
		{
			return $heading;
	}
    }

    
  public function getNhpExportDataFullA($locid,$filter) {

        $heading = array(array('refrence' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Owner', 'due' => 'When', 'log' => 'Log Date', 'loc' => 'Location', 'who_r' => 'Who Reported', '0' => 'Time', 't' => 'Classification', 'n' => 'Nature', '1' => 'Problem Desc.', '2' => 'Problem Risk Impact', 'ins' => 'Detailed Investigation', 'cf' => 'Contributing Factor', 'u' => 'Unsafe Act %', 'ud' => 'Unsafe Act Desc.', 'l' => 'Lack Skill %', 'ld' => 'Lack Skill  Desc.', 'k' => 'Lack Knowledge %', 'kd' => 'Lack Knowledge  Desc.', 'c' => 'Lack Compliance %', 'cd' => 'Lack Compliance  Desc.', 'ud' => 'Unsafe Desgin %', 'udd' => 'Unsafe Desgin Desc.', 'fc' => 'Faulty Construction %', 'fcd' => 'Faulty Construction Desc.', 'uc' => 'Unsafe Condition %', 'ucd' => 'Unsafe Condition Desc.', 'um' => 'Unsafe Method %', 'umd' => 'Unsafe Method Desc.', 'r' => 'Root Cause', '3' => 'Environmental', '4' => 'Disposition', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'adue' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.', 'pr' => 'Process Number', 'rv' => 'Risk Rating still valid', 'root_cause' => 'Root Cause'));
        $p_moduleName = 'Nonconformance nhp';
        $tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
        //echo $tab_type;
        $actTrackObj = new ActionTracker();

        $actTrackObj->setActionTrackerInfo('Nonconformance nhp', $tab_type, $p_dateFilter = '');
        $resultset = $actTrackObj->getActionsForActionTracker();

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $this->setNhpInfo(1, array('archive' => $archive_session));
        $nhp_records = $this->viewNhpsNew_Action($locid,$filter);
        //dump_array($nhp_records);
        //exit;
        if (!empty($nhp_records)) {

            foreach ($nhp_records as $resultElement) {
                $orgObj = SetupGeneric::useModule('Organigram');
                $locObj = SetupGeneric::useModule('Locationgram');
                $participantObj = SetupGeneric::useModule('Participant');

                $ac_id = $resultElement['ID'];
                $action_description = compact_action_tracker_description($resultElement['actionDescription']);
                $action_description_full = javascript_safe_string($resultElement['actionDescription']);
                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $resultElement['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $orgObj->setItemInfo(array('id' => $resultElement['businessUnitID']));
                $bu_details = $orgObj->displayItemById();



                $participant_id = $resultElement['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $resultElement['actionsID'],
                ));

                $data_records7 = $type->displayItemById5();
                $type->setItemInfo(array(
                    'id' => $resultElement['ID'],
                ));

                $data_records8 = $type->displayItemById6();
                //dump_array($data_records8);

$root_cause_Arr=$this->get_root_cause($resultElement['ID']);
 $root_cause='';
if(is_array($root_cause_Arr)){
  foreach($root_cause_Arr as $root_row){
      $root_cause.=$root_row["reason"]."\n";
  }

}
$result[$i]['root_cause'] =$root_cause;
                $result[$i]['refrence'] = $resultElement['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['due'] = format_datetime($resultElement['date']);
                $result[$i]['log'] = format_datetime($resultElement['dateTimestamp']);
                $result[$i]['loc'] = $location;
                $result[$i]['who_r'] = $resultElement['who_r'];
                $result[$i]['0'] = $resultElement['time'];
 $result[$i]['t'] = $resultElement['name'];
                if ($resultElement['nearmissHazardFlag'] == '1') {
                    $type22 = 'Close Call';
                }
                if ($resultElement['nearmissHazardFlag'] == '2') {
                    $type22 = 'Contractor';
                }
                if ($resultElement['nearmissHazardFlag'] == '3') {
                    $type22 = 'Design';
                }
                if ($resultElement['nearmissHazardFlag'] == '4') {
                    $type22 = 'Hazard';
                }
                if ($resultElement['nearmissHazardFlag'] == '5') {
                    $type22 = 'Non Conformance';
                }
                if ($resultElement['nearmissHazardFlag'] == '6') {
                    $type22 = 'Vehicle';
                }
                if ($resultElement['nearmissHazardFlag'] == '7') {

                    $type22 = 'Violence or Aggression';
                }
                if ($resultElement['nearmissHazardFlag'] == '8') {
                    $type22 = 'Company';
                }


                if ($resultElement['nature'] == '1') {
                    $nature = 'Environment';
                }
                if ($resultElement['nature'] == '2') {
                    $nature = 'Quailty';
                }
                if ($resultElement['nature'] == '3') {
                    $nature = 'Safety';
                }
                if ($resultElement['nature'] == '4') {
                    $nature = 'Security';
                }
                if ($resultElement['nature'] == '5') {
                    $nature = 'Other';
                }
                //$result[$i]['t'] = $type22;
                $result[$i]['n'] = $nature;
                $result[$i]['1'] = $resultElement['problemDescription'];
                $type->setItemInfo(array(
                    'id' => $resultElement['problemRiskImpact'],
                ));

                $data_records2 = $type->displayItemById2();
                $result[$i]['2'] = $data_records2['name'];
                if ($resultElement['investigationRequired'] == '1') {
                    $ins = 'Yes';
                } else {
                    $ins = 'No';
                }
                $result[$i]['ins'] = $ins;
                $result[$i]['cf'] = $resultElement['factor'];
                $result[$i]['u'] = $data_records8['unsafeActPercent'];
                $result[$i]['ud'] = $data_records8['unsafeActPercent'];
                $result[$i]['l'] = $data_records8['lackSkillPercent'];
                $result[$i]['ld'] = $data_records8['lackSkillPercent'];
                $result[$i]['k'] = $data_records8['lackKnowledgePercentage'];
                $result[$i]['kd'] = $data_records8['lackKnowledgeDesc'];
                $result[$i]['c'] = $data_records8['lackCompliancePercent'];
                $result[$i]['cd'] = $data_records8['lackComplianceDesc'];
                $result[$i]['ud'] = $data_records8['unsafeDesignPercent'];
                $result[$i]['udd'] = $data_records8['UnsafeDesignDesc'];
                $result[$i]['fc'] = $data_records8['faultyConstructionPercent'];
                $result[$i]['fcd'] = $data_records8['faultyConstructionDesc'];
                $result[$i]['uc'] = $data_records8['unsafeConditionPercent'];
                $result[$i]['ucd'] = $data_records8['unsafeConditionDesc'];
                $result[$i]['um'] = $data_records8['unsafeMethodPercent'];
                $result[$i]['umd'] = $data_records8['unsafeMethodDesc'];
                $result[$i]['r'] = $data_records8['root'];

                //$ev = explode(',', $resultElement['environmental']);
                //	$i = 0;
                //foreach($ev as $val){
                $type->setItemInfo(array(
                    'id' => $resultElement['environmental'],
                ));

                $data_records9 = $type->displayItemById7();
//dump_array($data_records9);
//if($data_records9['optionLabel']){
//$eve[$i] = $data_records9['optionLabel'];
//$i++;
//}
                //}
                //dump_array($eve);
                // if($eve){
                // $e = implode(',',$eve);
                // }else{
                // $e ='-';
                // }
                //echo $e;

                $result[$i]['3'] = $data_records9['optionLabel'];
                $type->setItemInfo(array(
                    'id' => $resultElement['disposition'],
                ));

                $data_records10 = $type->displayItemById7();
                $result[$i]['4'] = $data_records10['optionLabel'];
                $result[$i]['a'] = $resultElement['actionDescription'];
                $participant_id = $resultElement['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $resultElement['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($resultElement['dueDate']);
                $result[$i]['do'] = format_datetime($resultElement['doneDate']);
                $result[$i]['dod'] = $resultElement['doneDescription'];
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;
                $i++;
            }
            //dump_array($result);
            //exit;
            $result = array_merge($heading, $result);
            return $result;
        }
		else
		{
			return $heading;
	}
    }
    
    
public function getNhpExportDataAlertFull($locid,$filter) {

        $heading = array(array('refrence' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Owner', 'due' => 'When', 'log' => 'Log Date', 'loc' => 'Location', 'who_r' => 'Who Reported', '0' => 'Time', 't' => 'Classification', 'n' => 'Nature', '1' => 'Problem Desc.', '2' => 'Problem Risk Impact', 'ins' => 'Detailed Investigation', 'cf' => 'Contributing Factor', 'u' => 'Unsafe Act %', 'ud' => 'Unsafe Act Desc.', 'l' => 'Lack Skill %', 'ld' => 'Lack Skill  Desc.', 'k' => 'Lack Knowledge %', 'kd' => 'Lack Knowledge  Desc.', 'c' => 'Lack Compliance %', 'cd' => 'Lack Compliance  Desc.', 'ud' => 'Unsafe Desgin %', 'udd' => 'Unsafe Desgin Desc.', 'fc' => 'Faulty Construction %', 'fcd' => 'Faulty Construction Desc.', 'uc' => 'Unsafe Condition %', 'ucd' => 'Unsafe Condition Desc.', 'um' => 'Unsafe Method %', 'umd' => 'Unsafe Method Desc.', 'r' => 'Root Cause', '3' => 'Environmental', '4' => 'Disposition', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'adue' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.', 'pr' => 'Process Number', 'rv' => 'Risk Rating still valid'));
        $p_moduleName = 'Nonconformance nhp';
        $tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
        //echo $tab_type;
        $actTrackObj = new ActionTracker();

        $actTrackObj->setActionTrackerInfo('Nonconformance nhp', $tab_type, $p_dateFilter = '');
        $resultset = $actTrackObj->getActionsForActionTracker();

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $this->setNhpInfo(1, array('archive' => $archive_session));
        $nhp_records = $this->viewNhpsAlerts($locid,$filter);
        //dump_array($nhp_records);
        //exit;
        if (!empty($nhp_records)) {

            foreach ($nhp_records as $resultElement) {
                $orgObj = SetupGeneric::useModule('Organigram');
                $locObj = SetupGeneric::useModule('Locationgram');
                $participantObj = SetupGeneric::useModule('Participant');

                $ac_id = $resultElement['ID'];
                $action_description = compact_action_tracker_description($resultElement['actionDescription']);
                $action_description_full = javascript_safe_string($resultElement['actionDescription']);
                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $resultElement['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $orgObj->setItemInfo(array('id' => $resultElement['businessUnitID']));
                $bu_details = $orgObj->displayItemById();



                $participant_id = $resultElement['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $resultElement['actionsID'],
                ));

                $data_records7 = $type->displayItemById5();
                $type->setItemInfo(array(
                    'id' => $resultElement['ID'],
                ));

                $data_records8 = $type->displayItemById6();
                //dump_array($data_records8);


                $result[$i]['refrence'] = $resultElement['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['due'] = format_datetime($resultElement['date']);
                $result[$i]['log'] = format_datetime($resultElement['dateTimestamp']);
                $result[$i]['loc'] = $location;
                $result[$i]['who_r'] = $resultElement['who_r'];
                $result[$i]['0'] = $resultElement['time'];
                $result[$i]['t'] = $resultElement['name'];
                if ($resultElement['nearmissHazardFlag'] == '1') {
                    $type22 = 'Close Call';
                }
                if ($resultElement['nearmissHazardFlag'] == '2') {
                    $type22 = 'Contractor';
                }
                if ($resultElement['nearmissHazardFlag'] == '3') {
                    $type22 = 'Design';
                }
                if ($resultElement['nearmissHazardFlag'] == '4') {
                    $type22 = 'Hazard';
                }
                if ($resultElement['nearmissHazardFlag'] == '5') {
                    $type22 = 'Non Conformance';
                }
                if ($resultElement['nearmissHazardFlag'] == '6') {
                    $type22 = 'Vehicle';
                }
                if ($resultElement['nearmissHazardFlag'] == '7') {

                    $type22 = 'Violence or Aggression';
                }
                if ($resultElement['nearmissHazardFlag'] == '8') {
                    $type22 = 'Company';
                }


                if ($resultElement['nature'] == '1') {
                    $nature = 'Environment';
                }
                if ($resultElement['nature'] == '2') {
                    $nature = 'Quailty';
                }
                if ($resultElement['nature'] == '3') {
                    $nature = 'Safety';
                }
                if ($resultElement['nature'] == '4') {
                    $nature = 'Security';
                }
                if ($resultElement['nature'] == '5') {
                    $nature = 'Other';
                }
                //$result[$i]['t'] = $type22;
                $result[$i]['n'] = $nature;
                $result[$i]['1'] = $resultElement['problemDescription'];
                $type->setItemInfo(array(
                    'id' => $resultElement['problemRiskImpact'],
                ));

                $data_records2 = $type->displayItemById2();
                $result[$i]['2'] = $data_records2['name'];
                if ($resultElement['investigationRequired'] == '1') {
                    $ins = 'Yes';
                } else {
                    $ins = 'No';
                }
                $result[$i]['ins'] = $ins;
                $result[$i]['cf'] = $resultElement['factor'];
                $result[$i]['u'] = $data_records8['unsafeActPercent'];
                $result[$i]['ud'] = $data_records8['unsafeActPercent'];
                $result[$i]['l'] = $data_records8['lackSkillPercent'];
                $result[$i]['ld'] = $data_records8['lackSkillPercent'];
                $result[$i]['k'] = $data_records8['lackKnowledgePercentage'];
                $result[$i]['kd'] = $data_records8['lackKnowledgeDesc'];
                $result[$i]['c'] = $data_records8['lackCompliancePercent'];
                $result[$i]['cd'] = $data_records8['lackComplianceDesc'];
                $result[$i]['ud'] = $data_records8['unsafeDesignPercent'];
                $result[$i]['udd'] = $data_records8['UnsafeDesignDesc'];
                $result[$i]['fc'] = $data_records8['faultyConstructionPercent'];
                $result[$i]['fcd'] = $data_records8['faultyConstructionDesc'];
                $result[$i]['uc'] = $data_records8['unsafeConditionPercent'];
                $result[$i]['ucd'] = $data_records8['unsafeConditionDesc'];
                $result[$i]['um'] = $data_records8['unsafeMethodPercent'];
                $result[$i]['umd'] = $data_records8['unsafeMethodDesc'];
                $result[$i]['r'] = $data_records8['root'];

                //$ev = explode(',', $resultElement['environmental']);
                //	$i = 0;
                //foreach($ev as $val){
                $type->setItemInfo(array(
                    'id' => $resultElement['environmental'],
                ));

                $data_records9 = $type->displayItemById7();
//dump_array($data_records9);
//if($data_records9['optionLabel']){
//$eve[$i] = $data_records9['optionLabel'];
//$i++;
//}
                //}
                //dump_array($eve);
                // if($eve){
                // $e = implode(',',$eve);
                // }else{
                // $e ='-';
                // }
                //echo $e;

                $result[$i]['3'] = $data_records9['optionLabel'];
                $type->setItemInfo(array(
                    'id' => $resultElement['disposition'],
                ));

                $data_records10 = $type->displayItemById7();
                $result[$i]['4'] = $data_records10['optionLabel'];
                $result[$i]['a'] = $data_records7['actionDescription'];
                $participant_id = $data_records7['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $data_records7['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($data_records7['dueDate']);
                $result[$i]['do'] = format_datetime($data_records7['doneDate']);
                $result[$i]['dod'] = $data_records7['doneDescription'];
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;
                $i++;
            }
            //dump_array($result);
            //exit;
            $result = array_merge($heading, $result);
            return $result;
        }
		else
		{
			return $heading;
	}

        
    }

    public function getNhpExportDataAlertFullA($locid,$filter) {

        $heading = array(array('refrence' => 'Reference #', 'bu' => 'Business Unit', 'who' => 'Owner', 'due' => 'When', 'log' => 'Log Date', 'loc' => 'Location', 'who_r' => 'Who Reported', '0' => 'Time', 't' => 'Classification', 'n' => 'Nature', '1' => 'Problem Desc.', '2' => 'Problem Risk Impact', 'ins' => 'Detailed Investigation', 'cf' => 'Contributing Factor', 'u' => 'Unsafe Act %', 'ud' => 'Unsafe Act Desc.', 'l' => 'Lack Skill %', 'ld' => 'Lack Skill  Desc.', 'k' => 'Lack Knowledge %', 'kd' => 'Lack Knowledge  Desc.', 'c' => 'Lack Compliance %', 'cd' => 'Lack Compliance  Desc.', 'ud' => 'Unsafe Desgin %', 'udd' => 'Unsafe Desgin Desc.', 'fc' => 'Faulty Construction %', 'fcd' => 'Faulty Construction Desc.', 'uc' => 'Unsafe Condition %', 'ucd' => 'Unsafe Condition Desc.', 'um' => 'Unsafe Method %', 'umd' => 'Unsafe Method Desc.', 'r' => 'Root Cause', '3' => 'Environmental', '4' => 'Disposition', 'a' => 'Action Desc.', 'aw' => 'Action Who', 'awu' => 'Action WhoAU', 'adue' => 'Action Due Date', 'do' => 'Action Done Date', 'dod' => 'Action Done Descp.', 'pr' => 'Process Number', 'rv' => 'Risk Rating still valid'));
        $p_moduleName = 'Nonconformance nhp';
        $tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
        //echo $tab_type;
          $actTrackObj = new ActionTracker();

        $actTrackObj->setActionTrackerInfo('Nonconformance nhp', $tab_type, $p_dateFilter = '');
        $resultset = $actTrackObj->getActionsForActionTracker();

          $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $this->setNhpInfo(1, array('archive' => $archive_session));
        $nhp_records = $this->viewNhpsNew_ActionA($locid,$filter);

        if (is_array($nhp_records)) {
$i=0;
            foreach ($nhp_records as $resultElement) {
                       $orgObj = SetupGeneric::useModule('Organigram');
                $locObj = SetupGeneric::useModule('Locationgram');
                $participantObj = SetupGeneric::useModule('Participant');

                $ac_id = $resultElement['ID'];
                $action_description = compact_action_tracker_description($resultElement['actionDescription']);
                $action_description_full = javascript_safe_string($resultElement['actionDescription']);
                $locObj = SetupGeneric::useModule('Locationgram');
                $locObj->setItemInfo(array('id' => $resultElement['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $orgObj->setItemInfo(array('id' => $resultElement['businessUnitID']));
                $bu_details = $orgObj->displayItemById();



                $participant_id = $resultElement['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $type = SetupGeneric::useModule('IncidenceDetail');
                $type->setItemInfo(array(
                    'id' => $resultElement['actionsID'],
                ));

                $data_records7 = $type->displayItemById5();
                $type->setItemInfo(array(
                    'id' => $resultElement['ID'],
                ));

                $data_records8 = $type->displayItemById6();
                //dump_array($data_records8);

$root_cause_Arr=$this->get_root_cause($resultElement['ID']);
 $root_cause='';
if(is_array($root_cause_Arr)){
  foreach($root_cause_Arr as $root_row){
      $root_cause.=$root_row["reason"]."\n";
  }

}
$result[$i]['root_cause'] =$root_cause;
                $result[$i]['refrence'] = $resultElement['reference'];
                $result[$i]['bu'] = $bu_details['buName'];
                $result[$i]['who'] = $participant_name;
                $result[$i]['due'] = format_datetime($resultElement['date']);
                $result[$i]['log'] = format_datetime($resultElement['dateTimestamp']);
                $result[$i]['loc'] = $location;
                $result[$i]['who_r'] = $resultElement['who_r'];
                $result[$i]['0'] = $resultElement['time'];
 $result[$i]['t'] = $resultElement['name'];
                if ($resultElement['nearmissHazardFlag'] == '1') {
                    $type22 = 'Close Call';
                }
                if ($resultElement['nearmissHazardFlag'] == '2') {
                    $type22 = 'Contractor';
                }
                if ($resultElement['nearmissHazardFlag'] == '3') {
                    $type22 = 'Design';
                }
                if ($resultElement['nearmissHazardFlag'] == '4') {
                    $type22 = 'Hazard';
                }
                if ($resultElement['nearmissHazardFlag'] == '5') {
                    $type22 = 'Non Conformance';
                }
                if ($resultElement['nearmissHazardFlag'] == '6') {
                    $type22 = 'Vehicle';
                }
                if ($resultElement['nearmissHazardFlag'] == '7') {

                    $type22 = 'Violence or Aggression';
                }
                if ($resultElement['nearmissHazardFlag'] == '8') {
                    $type22 = 'Company';
                }


                if ($resultElement['nature'] == '1') {
                    $nature = 'Environment';
                }
                if ($resultElement['nature'] == '2') {
                    $nature = 'Quailty';
                }
                if ($resultElement['nature'] == '3') {
                    $nature = 'Safety';
                }
                if ($resultElement['nature'] == '4') {
                    $nature = 'Security';
                }
                if ($resultElement['nature'] == '5') {
                    $nature = 'Other';
                }
                //$result[$i]['t'] = $type22;
                $result[$i]['n'] = $nature;
                $result[$i]['1'] = $resultElement['problemDescription'];
                $type->setItemInfo(array(
                    'id' => $resultElement['problemRiskImpact'],
                ));

                $data_records2 = $type->displayItemById2();
                $result[$i]['2'] = $data_records2['name'];
                if ($resultElement['investigationRequired'] == '1') {
                    $ins = 'Yes';
                } else {
                    $ins = 'No';
                }
                $result[$i]['ins'] = $ins;
                $result[$i]['cf'] = $resultElement['factor'];
                $result[$i]['u'] = $data_records8['unsafeActPercent'];
                $result[$i]['ud'] = $data_records8['unsafeActPercent'];
                $result[$i]['l'] = $data_records8['lackSkillPercent'];
                $result[$i]['ld'] = $data_records8['lackSkillPercent'];
                $result[$i]['k'] = $data_records8['lackKnowledgePercentage'];
                $result[$i]['kd'] = $data_records8['lackKnowledgeDesc'];
                $result[$i]['c'] = $data_records8['lackCompliancePercent'];
                $result[$i]['cd'] = $data_records8['lackComplianceDesc'];
                $result[$i]['ud'] = $data_records8['unsafeDesignPercent'];
                $result[$i]['udd'] = $data_records8['UnsafeDesignDesc'];
                $result[$i]['fc'] = $data_records8['faultyConstructionPercent'];
                $result[$i]['fcd'] = $data_records8['faultyConstructionDesc'];
                $result[$i]['uc'] = $data_records8['unsafeConditionPercent'];
                $result[$i]['ucd'] = $data_records8['unsafeConditionDesc'];
                $result[$i]['um'] = $data_records8['unsafeMethodPercent'];
                $result[$i]['umd'] = $data_records8['unsafeMethodDesc'];
                $result[$i]['r'] = $data_records8['root'];

                //$ev = explode(',', $resultElement['environmental']);
                //	$i = 0;
                //foreach($ev as $val){
                $type->setItemInfo(array(
                    'id' => $resultElement['environmental'],
                ));

                $data_records9 = $type->displayItemById7();
//dump_array($data_records9);
//if($data_records9['optionLabel']){
//$eve[$i] = $data_records9['optionLabel'];
//$i++;
//}
                //}
                //dump_array($eve);
                // if($eve){
                // $e = implode(',',$eve);
                // }else{
                // $e ='-';
                // }
                //echo $e;

                $result[$i]['3'] = $data_records9['optionLabel'];
                $type->setItemInfo(array(
                    'id' => $resultElement['disposition'],
                ));

                $data_records10 = $type->displayItemById7();
                $result[$i]['4'] = $data_records10['optionLabel'];
                $result[$i]['a'] = $resultElement['actionDescription'];
                $participant_id = $resultElement['who'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name1 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['aw'] = $participant_name1;
                $participant_id = $resultElement['whoAU'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name2 = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                $result[$i]['awu'] = $participant_name2;
                $result[$i]['adue'] = format_datetime($resultElement['dueDate']);
                $result[$i]['do'] = format_datetime($resultElement['doneDate']);
                $result[$i]['dod'] = $resultElement['doneDescription'];
                $result[$i]['pr'] = $value['processID'];
                if ($value['isRiskValid'] == '1') {
                    $rv = 'Yes';
                } else {
                    $rv = 'No';
                }
                $result[$i]['rv'] = $rv;
          $i++;
          }

          $result = array_merge($heading,$result);
          return $result; 
    }else{
    return $heading; 
    }
    }
    /*
     * This method is used to view nhp records
     */

    public function viewNhps2() {

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);

        $sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.nhp A
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s'  ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function viewNhps1($locid,$search) {

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);
if ($locid==0)
    $locstr='';
else
$locstr='and A.locationID='.$locid;

if ($search=='0')
    $filter='';
else{
$filter=" and (A.reference like '%".$search."%' or A.problemDescription like '%".$search."%'";
$filter.=" or BU.buname like '%".$search."%'";
$filter.=" or P.forename like '%".$search."%'";
$filter.=" or P.surname like '%".$search."%'";
$filter.=" or T.name like '%".$search."%'";
$filter.=")";
}
      
        $sql = sprintf("SELECT A.*,userID,dateTimestamp,T.name,P.forename+' '+P.surname as owner,BU.buName  FROM %s.nhp A
             LEFT JOIN %s.ncr_type T ON A.nearmisshazardflag =T.ID
                          LEFT JOIN %s.participant_database P ON A.whoID =P.participantID
            LEFT JOIN %s.business_units BU ON A.businessUnitID =BU.buID
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' %s AND A.che = 1 %s ORDER BY ID DESC", _DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive'],$locstr,$filter);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

     public function viewNhpsAlerts($locid,$search) {

        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);
if ($locid==0)
    $locstr='';
else
$locstr='and A.locationID='.$locid;

if ($search=='0')
    $filter='';
else{
$filter=" and (A.reference like '%".$search."%' or A.problemDescription like '%".$search."%'";
$filter.=" or BU.buname like '%".$search."%'";
$filter.=" or P.forename like '%".$search."%'";
$filter.=" or P.surname like '%".$search."%'";
$filter.=" or T.name like '%".$search."%'";
$filter.=")";
}
        $sql = sprintf("SELECT A.*,userID,dateTimestamp,T.name FROM %s.nhp A
             LEFT JOIN %s.ncr_type T ON A.nearmisshazardflag =T.ID
            LEFT JOIN %s.participant_database P ON A.whoID =P.participantID
            LEFT JOIN %s.business_units BU ON A.businessUnitID =BU.buID
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' %s AND A.che = 1 %s ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive'],$locstr,$filter);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

        public function viewNhpsNew($locid,$search) {
if ($locid==0)
    $locstr='';
else
$locstr='and A.locationID='.$locid;

if ($search=='0')
    $filter='';
else{
$filter=" and (A.reference like '%".$search."%' or A.problemDescription like '%".$search."%'";
$filter.=" or BU.buname like '%".$search."%'";
$filter.=" or P.forename like '%".$search."%'";
$filter.=" or P.surname like '%".$search."%'";
$filter.=" or T.name like '%".$search."%'";
$filter.=")";
}
        //$sql = sprintf("SELECT * FROM %s.nhp WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->nhpInfo['archive']);

        $sql = sprintf("SELECT A.*,userID,dateTimestamp,T.name  FROM %s.nhp A
             LEFT JOIN %s.ncr_type T ON A.nearmisshazardflag =T.ID
             LEFT JOIN %s.participant_database P ON A.whoID =P.participantID
            LEFT JOIN %s.business_units BU ON A.businessUnitID =BU.buID
			LEFT OUTER JOIN (
				SELECT recID,
					dateTimestamp,
					whoID as userID,
					reference as recordRef,
					role
				FROM %s.module_tracker
				WHERE module = 'NHP'
				AND action = 'add'
			) B
			ON recordRef = reference
			WHERE A.archive = '%s' %s AND isNull(A.che,0) = 0 %s ORDER BY ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $this->nhpInfo['archive'],$locstr,$filter);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }
    
    public function getNhpExportData() {

        $heading = array(array('bu' => 'Business Unit', 'refrence' => 'Reference #', 'action' => 'Action', 'due' => 'Due Date', 'done' => 'Done Date'));
        $p_moduleName = 'Nonconformance nhp';
        $tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
        //echo $tab_type;
        $actTrackObj = new ActionTracker();

        $actTrackObj->setActionTrackerInfo('Nonconformance nhp', $tab_type, $p_dateFilter = '');
        $resultset = $actTrackObj->getActionsForActionTracker();
        //dump_array($resultset);
        if (!empty($resultset)) {

            foreach ($resultset as $resultElement) {

                $ac_id = $resultElement['ID'];
                $action_description = compact_action_tracker_description($resultElement['actionDescription']);
                $action_description_full = javascript_safe_string($resultElement['actionDescription']);

                $result[$i]['bu'] = $resultElement['buName'];
                $result[$i]['refrence'] = $resultElement['reference'];
                $result[$i]['action'] = $action_description;
                $result[$i]['due'] = format_datetime($resultElement['dueDate']);
                $result[$i]['done'] = format_datetime($resultElement['doneDate']);
                $i++;
            }
            $result = array_merge($heading, $result);
            return $result;
        }
else{
	return $heading;
}


        /* $orgObj			 = SetupGeneric::useModule('Organigram');
          $locObj			 = SetupGeneric::useModule('Locationgram');
          $participantObj	 = SetupGeneric::useModule('Participant');
          $actTrackObj = new ActionTracker();
          //$actTrack = new ActionTrackerNonconformanceNhp();
          //$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$p_tabType,$p_dateFilter='');
          // $resultset = $actTrackObj->getActionsForActionTracker();
          //dump_array($resultset);
          $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
          $this->setNhpInfo(1,array('archive'=>$archive_session));
          $nhp_records = $this->viewNhps();
          // dump_array($nhp_records);
          if ( count($nhp_records) ) {
          $i=0;
          foreach ($nhp_records as $value ) {
          $action_id = $value['actionsID'];
          $nhp_id = $value['ID'];
          $orgObj->setItemInfo(array('id'=>$value['businessUnitID']));
          $bu_details = $orgObj->displayItemById();

          $locObj->setItemInfo(array('id'=>$value['locationID']));
          $location_data = "";
          $location = $locObj->getFUllLocation();

          $participant_id = $value['whoID'];
          $participantObj->setItemInfo(array('id'=>$participant_id));
          $partcipantData = $participantObj->displayItemById();

          $participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

          $orgObj->setItemInfo(array('id'=>$action_id));
          $action_details = $orgObj->getActionData();
          //foreach($action_details as $key => $val){
          $dueDate =	$action_details['dueDate'];
          $actinDescp =javascript_safe_string($action_details['actionDescription']);
          $doneDescp =	$action_details['doneDate'];
          //dump_array($dueDate);
          //}

          $result[$i]['bu'] = $bu_details['buName'];
          $result[$i]['ref'] = $value['reference'];
          $result[$i]['action'] = $actinDescp;
          $result[$i]['dueDate'] = format_date($dueDate);
          $result[$i]['date']  = format_date($doneDescp);
          $i++;
          }
          }

          $result = array_merge($heading,$result);
          return $result; */
    }

    public function getSearchExportData() {

        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');

        $data_array['env_type'] = $_GET['env_type'];
        $data_array['env_scale'] = $_GET['env_scale'];
        $data_array['disposition'] = $_GET['disposition'];

        $this->setNhpInfo(1, $data_array);
        $nhp_records = $this->searchNhp();

        $heading = array(array('Business Unit', 'Reference #', 'Owner', 'When', 'Location'));

        if (is_array($nhp_records)) {

            foreach ($nhp_records as $element) {

                $orgObj->setItemInfo(array('id' => $element['businessUnitID']));
                $bu_details = $orgObj->displayItemById();
                $business_unit = $bu_details['buName'];

                $locObj->setItemInfo(array('id' => $element['locationID']));
                $location_data = "";
                $location = $locObj->getFUllLocation();
                $location = str_replace(',', '-', $location);

                $participant_id = $element['whoID'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();
                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $date = format_date($element['date']);

                $result[] = array($business_unit, $element['reference'], $participant_name, $date, $location);
            }
        }

        $new_result = array_merge($heading, $result);
        return $new_result;

    }

    /* function is used to send mail to manger of approved record */

    public function getActionTrackerEmailData($p_record_id) {

        $sql2 = sprintf("SELECT * FROM %s.nhp ", _DB_OBJ_FULL);
        $sql2 = $sql2 . " WHERE actionsID LIKE '" . $p_record_id . "' OR actionsID LIKE '%," . $p_record_id . "' OR actionsID LIKE '" . $p_record_id . ",%' OR actionsID LIKE '%," . $p_record_id . ",%' ";

        $pStatement2 = $this->dbHand->prepare($sql2);
        $pStatement2->execute();
        $result = $pStatement2->fetchAll(PDO::FETCH_ASSOC);





        if (is_array($result)) {

            $email_data['bu_id'] = $result[0]['businessUnitID'];
            $email_data['reference'] = $result[0]['reference'];
            $email_data['dueDate'] = $result[0]['date'];
            $email_data['who_id'] = $result[0]['whoID'];
        }


        return $email_data;
    }

    public function getOverDueActions($buStr, $date) {
        $this->sql_query = sprintf("select A.id,N.reference,N.problemDescription,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,B.buName,(P.forename +' '+P.surname) as who_name   from %s.actions A  inner join %s.nhp N on A.record=N.ID left join %s.business_units B on N.businessunitid=B.buID  left join %s.participant_database P on A.currentWho=P.participantID  where modulename = 'nhp' and B.buID in(%s) and approveAU=0 and duedate < '%s'
							ORDER BY N.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $date);
        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getOutstandingActions($buStr, $fdate) {
        $insp_out = SetupGeneric::useModule('InspectionOutstandingAction');
        $outstanding_duration = explode(':', $insp_out->displayItems());

        switch ($outstanding_duration[1]) {
            case 'M' : $interval = '+' . $outstanding_duration[0] . ' MONTH';
                break;
            case 'Y' : $interval = '+' . $outstanding_duration[0] . ' YEAR';
                break;
        }

                $date = date_create($fdate);
        date_add($date, date_interval_create_from_date_string($interval));

        $outstandingDate = date_format($date, "Y-m-d");

        $this->sql_query = sprintf("select A.id,N.reference,N.problemDescription,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.outstandingcomment,B.buName,(P.forename +' '+P.surname) as who_name   from %s.actions A  inner join %s.nhp N on A.record=N.ID left join %s.business_units B on N.businessunitid=B.buID  left join %s.participant_database P on A.currentWho=P.participantID  where modulename = 'nhp' and B.buID in(%s) and approveAU=0  and duedate >=  '%s'
							ORDER BY N.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $buStr, $outstandingDate);
        $pStatement = $this->dbHand->prepare($this->sql_query);


        $pStatement->execute();
        $data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function updateProblem($id, $data) {

        $this->data = $data;
        $this->id = $id;
        $sql2 = sprintf(" UPDATE %s.nhp SET problemDescription = '" . $this->data . "'
									WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->nhpInfo['disposition']);
          $pStatement2->bindParam(2,$this->nhpId); */

        $pStatement2->execute();
    }

    public function updateAction11($id) {

        $ogrObj = SetupGeneric::useModule('Organigram');
        $this->id = $id;
        $duedate = date("Y-m-d", strtotime("+5 day", strtotime($this->nhpInfo["date"])));
        $whomaster = $ogrObj->getManager($this->nhpInfo["participantID"]);

        if (!$whomaster)
            $whomaster["participantID"] = 0;

       $actions="Progress NCR Alert for ".  $this->nhpInfo["action"];
        $sql6 = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,record,moduleElement,who,currentwho,dueDate,whoAU,status)
											VALUES ('nhp','" . $actions . "'," . $this->id . ",'nhp'," . $this->nhpInfo["participantID"] . "," . $this->nhpInfo["participantID"] . ",'" . $duedate . "'," . $whomaster["participantID"] . ",1)", _DB_OBJ_FULL
        );
        $pStatement2 = $this->dbHand->prepare($sql6);

        $pStatement2->execute();

        $this->aId = customLastInsertId( $this->dbHand, 'actions', 'ID');


        $sql2 = sprintf(" UPDATE %s.nhp SET alert_actionID = '" . $this->aId . "'
									WHERE ID =" . $this->id, _DB_OBJ_FULL);

        $pStatement2 = $this->dbHand->prepare($sql2);

        $pStatement2->execute();

        return $this->aId;
    }

    
    public function updateActionINV($id,$data) {

        $ogrObj = SetupGeneric::useModule('Organigram');
        $this->id = $id;
        $duedate = date("Y-m-d", strtotime("+5 day"));
        
        
        $whomaster = $ogrObj->getManager($data["whoID"]);

        if (!$whomaster)
            $whomaster["participantID"] = 0;

       $sql6 = sprintf("INSERT INTO %s.actions (moduleName,actionDescription,record,moduleElement,who,currentwho,dueDate,whoAU,status)
											VALUES ('nhcinvestigation','A detail Investigation required because<BR>" . $data["problemDescription"] . "'," . $this->id . ",'nhp'," . $data["whoID"] . "," . $data["whoID"] . ",'" . $duedate . "'," . $whomaster["participantID"] . ",1)", _DB_OBJ_FULL
        );
        $pStatement2 = $this->dbHand->prepare($sql6);

        $pStatement2->execute();

        $this->aId = customLastInsertId( $this->dbHand, 'actions', 'ID');

       return $this->aId;
    }
    
    public function getBUPremission($buid) {

        $this->buid = $buid;

        $sql = sprintf("SELECT * FROM %s.participant_authorization_stats WHERE sectionName='perm_nc_nhp' AND businessUnit =" . $this->buid, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $row = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $row[0];
    }

    public function sendNCAaction($aid, $reference, $problem,$reason) {
        $this->aid = $aid;
        $emailObj = new actionEmailHelper($this->aid);
        $who = $emailObj->getWhoDetails();
        $sentence = array('sentence' => array("You have an action to carry out the following NCA Action"));
        $emailObj->appendInfo($sentence);

       $actionData=$this->getCompleteActionData($aid);
       $referece= $actionData["problem"];
        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_nhp.php">CLICK</a> Here to View a NCA Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/nhp/add_edit_nhp_details.php?id=' . $this->nhpId . '&c=1">CLICK</a> Here to Carry out a NCA Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $reference
                ),
                'actionid1' => array(
                    'left' => '<strong>Problem/Background</strong>',
                    'right' => $problem
                ),
                'actionid2' => array(
                    'left' => '<strong>Reason/Recommendation</strong>',
                    'right' => $reason
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An NCA Alert Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
    }

        public function sendActions($id, $reference, $problem) {
            $this->nhpId = $id;
            $sql = "SELECT * FROM %s.actions WHERE record=%d and moduleelement='nhp' and  donedate is null";
					
            $psql = sprintf($sql, _DB_OBJ_FULL, $this->nhpId);

            $stmt = $this->dbHand->prepare($psql);

            $stmt->execute();

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);



foreach($result as $data){

    $this->actionHandling->updateStatus($data["ID"]);
        $emailObj = new actionEmailHelper($data["ID"]);
        $who = $emailObj->getWhoDetails();
        $sentence = array('sentence' => array("You have an action to carry out the following NCR Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_nhp.php?id=' . $data["ID"] . '">CLICK</a> Here to View a NCR Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/nhp/add_edit_nhp_details.php?id=' . $this->nhpId . '&c=1">CLICK</a> Here to Carry out a NCR Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $reference
                ),
                'actionid1' => array(
                    'left' => '<strong>Problem Description</strong>',
                    'right' => $problem
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An NCR Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
    }

        }
    
                public function sendAction($id) {
            $this->nhpId = $id;
            $sql = "select N.* from %s.nhp N inner join  %s.actions A on N.ID=A.record where A.ID=%d";
					
            $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

            $stmt = $this->dbHand->prepare($psql);

            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);




    $this->actionHandling->updateStatus($id);
        $emailObj = new actionEmailHelper($id);
        $who = $emailObj->getWhoDetails();
        $sentence = array('sentence' => array("You have an action to carry out the following NCR Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_nhp.php?id=' . $id . '">CLICK</a> Here to View a NCR Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/nhp/add_edit_nhp_details.php?id=' . $result["ID"] . '&c=1">CLICK</a> Here to Carry out a NCR Action'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $result["reference"]
                ),
                'actionid1' => array(
                    'left' => '<strong>Problem Description</strong>',
                    'right' => $result["problemDescription"]
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An NCR Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
 

        }
        
    public function getBUPremissionOld($rec, $aid, $ref, $descp, $id) {
        $this->rec = $rec;
        $this->buid = $id;
        $this->aid = $aid;
        $this->ref = $ref;
        $this->descp = $descp;
        $sql = sprintf("SELECT * FROM %s.participant_authorization_stats WHERE sectionName='perm_nc_nhp' AND businessUnit =" . $this->buid, _DB_OBJ_FULL);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $row = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        foreach ($row as $val) {

            $sql = "SELECT * FROM %s.participant_database
				WHERE
					participantID = %d";
            $psql = sprintf($sql, _DB_OBJ_FULL, $val['participantID']);

            $stmt = $this->dbHand->prepare($psql);

            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $emailObj = new actionEmailHelper($this->aid);
            $who = array(
                'displayname' => ucwords($result['forename'] . ' ' . $result['surname']),
                'email' => $result['emailAddress'],
                'ID' => $result['participantID']
            );

            $sentence = array('sentence' => array("You have an action to carry out the following NCA Action"));
            $emailObj->appendInfo($sentence);

            $data = array(
                'singleColData' => array(
                    'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/nhp/add_edit_alert.php?id=' . $this->rec . '&c=1">CLICK</a> Here to View NCA Action'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $this->ref
                    ),
                    'actionid1' => array(
                        'left' => '<strong>Problem Description</strong>',
                        'right' => $this->descp
                    )
                )
            );


            $emailObj->appendInfo($data);

            $emailObj->sendEmail('An NCA Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
        }



        return $row;
    }

    public function rejectNhp() {

        $sql = sprintf(" select * from %s.nhp WHERE ID = %d ", _DB_OBJ_FULL, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);

        $sql = sprintf(" UPDATE %s.nhp SET noActionReason = '%s',status='R',archive=1
							WHERE ID = %d ", _DB_OBJ_FULL, $this->nhpInfo['reject_reason'], $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $emailObj = new infoEmailHelper();

        $participantObj = SetupGeneric::useModule('Participant');

        $participantObj->setItemInfo(array('id' => $data["who_rid"]));
        $partcipantData = $participantObj->displayItemById();
        $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $who = array(
            'displayname' => ucwords($contributor_name),
            'email' => $partcipantData['emailAddress']
        );

        $subject = "smart-ISO NCR Email: Your alert has been rejected.";
        $mergeData = array(
            'twoColData' => array(
                'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $data['reference']),
                'assignedto' => array('left' => '<strong>Problem:</strong>', 'right' => $data['problemDescription'])
            ),
            'singleColData' => array(
                'summary' => '<p><BR>For the following reasons it was decided to reject this alert.<BR><BR>' . $this->nhpInfo['reject_reason'] . '.</p>')
        );

        $emailObj->appendInfo($mergeData);


        $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');


        $sql = sprintf(" select * from %s.actions WHERE record = %d and modulename='nhp' ", _DB_OBJ_FULL, $this->nhpId);
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();
        $data = $pStatement->fetch(PDO::FETCH_ASSOC);

        $actTrackObj = new ActionTracker();

        $actionId = $data['ID'];
        $done_date = date('Y-m-d');
        $comment = strip_tags($this->nhpInfo['reject_reason']);
        $action_type = strip_tags($_POST['action_type']);
        $action = "An NCR";
        $action_str = "The alert has been rejected";
        $not_complete = 2;



        $actTrackObj->saveActionInformation2($actionId, $done_date, $comment, $action, $action_str, $not_complete);
    }

    public function getCompleteActionData($actionID) {

  $sql = sprintf("select A.id,M.reference,B.buName as lname,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,M.problemDescription as problem,M.ID from %s.actions A  inner join %s.nhp M on a.record=M.ID left join %s.business_units B on M.businessunitid=B.buID where modulename='nhp' and A.ID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $actionID);

        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    public function viewNhp_Action() {

        $archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');
        $this->setNhpInfo(1, array('archive' => $archive_session));

     $sql = sprintf("SELECT N.*,A.*,L.name,B.buName,T.name as classification,M.name as impact FROM %s.nhp N LEFT JOIN %s.locationgram L on N.locationID=L.locID LEFT JOIN %s.business_units B on N.businessUnitID=B.buID LEFT JOIN %s.ncr_type T on N.nearmisshazardflag=T.ID LEFT JOIN %s.impact_measure M on N.problemriskimpact=M.ID LEFT JOIN %s.viewnhpactions A on N.ID=A.record  WHERE N.archive = '%s' ORDER BY A.ID DESC", _DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL, $this->nhpInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['archive']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
}
     public function checkNhp_Ref($reference) {
    $sql = sprintf("SELECT * FROM %s.nhp WHERE reference = '%s'", _DB_OBJ_FULL, $reference);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
if(is_array($resultSet))
        return (count($resultSet)) ;
    else {
    return 0;    
    }

}
     public function updateNcpStatus() {
    $sql = sprintf("update %s.nhp set status='%s' WHERE ID = %d", _DB_OBJ_FULL, $reference);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();



 $sql = sprintf("insert into %s.nhp (nhpID,status,comment,enteredby) VALUES (%d,'%s','%s',%d)", _DB_OBJ_FULL, $reference);
        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
}
    public function getNhp_Action($id) {


    $sql = sprintf("select A.*,P1.forename+' '+P1.surname as name1 ,P2.forename+' '+P2.surname as name2 ,P3.forename+' '+P3.surname as name3 from %s.actions A  left join %s.participant_database P1 on A.who=P1.participantID left join %s.participant_database P2 on A.addapprover=P2.participantID left join %s.participant_database P3 on A.whoAU=P3.participantID where moduleElement='NHP'and record= '%d' ", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }
    
         public function get_root_cause($id) {
     $sql = sprintf("SELECT * FROM %s.ncr_root_cause WHERE ncrid = %d", _DB_OBJ_FULL, $id);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->nhpInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet ;

}
         public function add_root_cause($id,$reason,$who) {
             $sql = sprintf(" INSERT INTO %s.ncr_root_cause (reason,who,ncrid) VALUES('%s',%d, %d)", _DB_OBJ_FULL,$reason,$who, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();


}
         public function edit_root_cause($id,$reason,$who) {
             $sql = sprintf(" UPDATE %s.ncr_root_cause set reason='%s',who=%d where ID=%d", _DB_OBJ_FULL,$reason,$who, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();


}
}
?>