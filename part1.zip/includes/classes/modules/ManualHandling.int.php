<?php
 /**
  $Id: ManualHandling.int.php,v 3.14 Tuesday, October 19, 2010 12:02:34 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Interface to manage Manual Handling object
  *
  * This interface will declare the various methods performed
  * by the manual handling object for operations like add, edit, delete, archive, purge.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Interface
  * @since  Thursday, September 09, 2010 1:01:51 PM>
  */


interface ManualHandlingInterface
{
	/*
	 * to set manual handling information for performing various operations with the manual handling object
	 */
	public function setManualHandlingInfo($p_manualHandlingId,$p_manualHandlingInfo);

	/*
	 * This method is used to add a new manual handling
	 */
	public function addManualHandling();

	/*
	 * This method is used to view the manual handling information.
	 */
	public function viewManualHandling();

	/*
	 * This method is used to edit the manual handling
	 */
	public function editManualHandling();

	/*
	 * This method is used to delete the manual handling
	 */
	public function deleteManualHandling();

	/*
	 * This method is used to archive the manual handling
	 */

	public function archiveManualHandling();

	/*
	 * This method is used to remove the manual handling
	 */
	public function purgeManualHandling();

}