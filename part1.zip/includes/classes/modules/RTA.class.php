<?php

/**
  $Id: RTAMain.class.php,v 3.38 Monday, January 31, 2011 10:06:22 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Monday, November 08, 2010 9:52:17 AM>
 */
require_once "RTA.int.php";
require_once "Action.class.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

class RTA implements RTAint {

    /**
     * Object container for PDO Database resource class
     * @access private
     */
    private $dbHand;

    /**
     * Object container Action class
     * @access private
     */
    private $actionHandling;

    /**
     * property contains action data
     * @access private
     */
    private $actionData;

    /**
     * Property to hold RTA Id
     * @access private
     */
    private $RTAId;

    /**
     * Property to hold RTA Info
     * @access private
     */
    private $RTAInfo;

    /**
     * Constructor for initializing RTA object
     * @access public
     */
    public function __construct() {


        $this->dbHand = DB::connect(_DB_TYPE);
        $this->actionHandling = new Action();
    }

    /*
     * This method is used to set RTA information for the respective object
     */

    public function setRTAInfo($p_RTAId, $p_RTAInfo) {
        $this->RTAId = $p_RTAId;
        $this->RTAInfo = $p_RTAInfo;
    }

    /*
     * This method is used to add new RTA
     */

    public function addRTA() {

        $sql = sprintf("SELECT * FROM %s.RTA WHERE reference = '%s'", _DB_OBJ_FULL, $this->RTAInfo['reference']);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->RTAInfo['reference']);
        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        if (count($resultSet)) {
            throw new ErrorException('RTA with this Reference # already exists.');
        } else {

            $sql2 = sprintf("INSERT INTO %s.RTA (reference, reported_by, owner, datereported, timereported, problem, cause, improvement,location, business,archive,ss_doc,ss_line) 
VALUES ('%s','%d',%d,'%s','%s','%s','%s','%s','%s','%s',0,'%s',%d)", _DB_OBJ_FULL, $this->RTAInfo['reference_number'], $this->RTAInfo['reported'], $this->RTAInfo['owner'], format_date_for_mysql($this->RTAInfo['date']), $this->RTAInfo['time'], $this->RTAInfo['problem'], $this->RTAInfo['cause'], $this->RTAInfo['improvement'], $this->RTAInfo['location'], $this->RTAInfo['business_unit'], $this->RTAInfo['ss_doc'], $this->RTAInfo['ss_line']);

            $pStatement2 = $this->dbHand->prepare($sql2);

            $pStatement2->execute();

            $this->RTAId = customLastInsertId($this->dbHand, 'RTA', 'ID');


            $actions = $this->RTAInfo['actions'];

            foreach ($actions as $value) {
                $this->actionData = array('module_name' => 'RTA', 'record' => $this->RTAId, 'description' => $value['action'],
                    'who' => $value['who'], 'whoAU' => $value['whoAU'], 'who2AU' => $value['who2AU'], 'due_date' => $value['when'], 'element' => 'RTA');


                // do add
                $this->actionHandling->setActionDetails(0, $this->actionData);
                $new_action_id = $this->actionHandling->addAction2015();
            }
        }

        return $this->RTAId;
    }

    /*
     * This method is used to edit RTA record
     */

    public function editRTA() {


        $sql = sprintf(" UPDATE %s.RTA SET reported_by = %d, 
        owner= %d, 
        datereported= '%s', 
        timereported= '%s', 
        problem= '%s',
        cause= '%s',
        improvement= '%s',
        ss_doc= '%s',
        ss_line= '%s'
   WHERE ID = %d ", _DB_OBJ_FULL, $this->RTAInfo['reported'], $this->RTAInfo['owner'], format_date_for_mysql($this->RTAInfo['date']), $this->RTAInfo['time'], $this->RTAInfo['problem'], $this->RTAInfo['cause'], $this->RTAInfo['improvement'], $this->RTAInfo['ss_doc'], $this->RTAInfo['ss_line'], $this->RTAId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();


        $actions = $this->RTAInfo['actions'];

        foreach ($actions as $value) {
            $this->actionData = array('module_name' => 'RTA', 'record' => $this->RTAId, 'description' => $value['action'],
                'who' => $value['who'], 'whoAU' => $value['whoAU'], 'who2AU' => $value['who2AU'], 'due_date' => $value['when'], 'element' => 'RTA');

            if ((int) $value['action_id'] > 0) {
                // do update
                $this->actionHandling->setActionDetails($value['action_id'], $this->actionData);
                $this->actionHandling->updateAction2015();
                $action_ids .= $value['action_id'] . ',';
            } else {
                // do add
                $this->actionHandling->setActionDetails(0, $this->actionData);
                $new_action_id = $this->actionHandling->addAction2015();
                $action_ids .= $new_action_id . ',';

                if ($update_save == 1) {
                    $this->sendAction($new_action_id);
                }
            }
        }
    }

    /*
     * This method is used to delete RTA record
     */

    public function deleteRTA() {
        
    }

    /*
     * This method is used to archive RTA record
     */

    public function archiveRTA() {
        $sql2 = sprintf(" UPDATE %s.RTA SET archive = '%s'
									WHERE ID = %d", _DB_OBJ_FULL, $this->RTAInfo['archive'], $this->RTAId);

        $pStatement2 = $this->dbHand->prepare($sql2);

        /* $pStatement2->bindParam(1,$this->RTAInfo['archive']);
          $pStatement2->bindParam(2,$this->RTAId); */

        $pStatement2->execute();
    }

    /*
     * This method is used to completely delete RTA record
     */

    public function purgeRTA() {
        
    }

    /**
     * This method is used to get last insert id
     */
    public function lastRecordId() {
        return $this->RTAId;
    }

    /*
     * This method is used to view an RTA record
     */

    public function viewRTAById() {

        $sql = sprintf("SELECT * FROM %s.RTA WHERE ID = %d", _DB_OBJ_FULL, $this->RTAId);
        $pStatement = $this->dbHand->prepare($sql);

        //$pStatement->bindParam(1,$this->RTAId);
        $pStatement->execute();
        //dump_array($pStatement->errorInfo());
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet[0];
    }

    /*
     * This method is used to view RTA records
     */

    public function viewRTAs() {

        //$sql = sprintf("SELECT * FROM %s.RTA WHERE archive = '%s' ORDER BY ID DESC",_DB_OBJ_FULL,$this->RTAInfo['archive']);

        $sql = sprintf("SELECT * FROM %s.RTA WHERE archive = '%s' ORDER BY ID DESC", _DB_OBJ_FULL, $this->RTAInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
        $resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $resultSet;
    }

    public function sendActions($id, $reference, $problem) {
        $this->rtaId = $id;
        $sql = "SELECT * FROM %s.actions WHERE record=%d and moduleelement='rta' and  donedate is null";

        $psql = sprintf($sql, _DB_OBJ_FULL, $id);

        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


        foreach ($result as $data) {

            $this->actionHandling->updateStatus($data["ID"]);
            $emailObj = new actionEmailHelper($data["ID"]);
            $who = $emailObj->getWhoDetails();
            $sentence = array('sentence' => array("You have an action to carry out the following RTA Action"));
            $emailObj->appendInfo($sentence);

            $data = array(
                'singleColData' => array(
                    'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/rta.php?id=' . $data["ID"] . '">CLICK</a> Here to View a RTA Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/rta/pdfreport.php?id=' . $this->rtaId . '&back=1">CLICK</a> Here to View the RTA Detail'
                ),
                'twoColData' => array(
                    'actionid' => array(
                        'left' => '<strong>Reference</strong>',
                        'right' => $reference
                    ),
                    'actionid1' => array(
                        'left' => '<strong>Problem</strong>',
                        'right' => $problem
                    )
                )
            );


            $emailObj->appendInfo($data);

            $emailObj->sendEmail('An RTA Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
        }
		
    }

    public function sendAction($id) {
        $this->RTAId = $id;
        $sql = "select N.* from %s.RTA N inner join  %s.actions A on N.ID=A.record where A.ID=%d";

        $psql = sprintf($sql, _DB_OBJ_FULL, _DB_OBJ_FULL, $id);

        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);




        $this->actionHandling->updateStatus($id);
        $emailObj = new actionEmailHelper($id);
        $who = $emailObj->getWhoDetails();
        $sentence = array('sentence' => array("You have an action to carry out the following RTA Action"));
        $emailObj->appendInfo($sentence);

        $data = array(
            'singleColData' => array(
                'click-here-url' => 'Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/non_conf_RTA.php?id=' . $id . '">CLICK</a> Here to View a RTA Action<BR><BR>
							Please <a href="https://' . $_SERVER['HTTP_HOST'] . '/RTA/pdfreport.php?id=' . $result["ID"] . '">CLICK</a> Here to View the RTA Detail'
            ),
            'twoColData' => array(
                'actionid' => array(
                    'left' => '<strong>Reference</strong>',
                    'right' => $result["reference"]
                ),
                'actionid1' => array(
                    'left' => '<strong>Problem</strong>',
                    'right' => $result["problem"]
                )
            )
        );


        $emailObj->appendInfo($data);

        $emailObj->sendEmail('An RTA Action To Be Carried Out', $who, array(), array(), 'me_completed', '', 'grey');
    }

    public function getActions($id) {
        $sql = "select * from %s.actions where moduleelement='rta' and record=%d";

        $psql = sprintf($sql, _DB_OBJ_FULL, $id);

        $stmt = $this->dbHand->prepare($psql);

        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function archive($id) {
        $sql = sprintf("UPDATE %s.rta SET archive = '1' WHERE ID = %d ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function restore($id) {
        echo $sql = sprintf("UPDATE %s.rta SET archive = '0' WHERE ID = %d ", _DB_OBJ_FULL, $id);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function updateStatus() {
        $sql = sprintf("UPDATE %s.rta SET status = '1' WHERE ID = %d ", _DB_OBJ_FULL, $this->RTAId);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

    public function getListingforExport() {

        $type = $_GET['type'];

        if ($type == 'serach') {

            return $this->getSearchExportData();
        } else if ($type == 'full') {
            return $this->getRTAExportDataFull();
        } else {

            return $this->getRTAExportData();
        }
    }

            public function getCompleteActionData($actionID) {
   
      $sql =   sprintf("select A.id,R.Reference,L.name as lname,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,R.problem,Q from %s.actions A  inner join %s.rta R on A.record=S.ID  left join %s.locationgram L on R.location=L.locID  where modulename='RTA' and approveAU=0 and A.ID=%d", _DB_OBJ_FULL,_DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $actionID);
   
        $pStatement = $this->dbHand->prepare($sql);
        $pStatement->execute();

        $result = $pStatement->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    public function getRTAExportData() {
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
         $heading = array(array('reference' => 'Reference #', 'problem' => 'Problem', 'business' => 'Business Unit', 'owner' => 'Owner', 'when' => 'When', 'date' => 'Log Date', 'location' => 'Location'));
       
          $resultset = $this->viewRTAs();
        //dump_array($resultset);
        if (!empty($resultset)) {
            foreach ($resultset as $resultElement) {
                $orgObj->setItemInfo(array('id' => $resultElement['business']));
                $bu_details = $orgObj->displayItemById();
                $ac_id = $resultElement['ID'];
                $problem_description = compact_action_tracker_description($resultElement['problem']);

                $locObj->setItemInfo(array('id' => $resultElement['location']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $participant_id = $resultElement['owner'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                $result[$i]['reference'] = $resultElement['reference'];
                $result[$i]['problem'] = $problem_description;
                $result[$i]['business'] = $bu_details['buName'];
                $result[$i]['owner'] = $participant_name;
                $result[$i]['when'] = format_datetime($resultElement['datereported']);
                $result[$i]['date'] = format_datetime($resultElement['dateentered']);
                $result[$i]['location'] = $location;

                $i++;
            }
            $result = array_merge($heading, $result);
            return $result;
        } else {
            return $heading;
        }
    }

    public function getRTAExportDataFull() {
        $orgObj = SetupGeneric::useModule('Organigram');
        $locObj = SetupGeneric::useModule('Locationgram');
        $participantObj = SetupGeneric::useModule('Participant');
         $heading = array(array('reference' => 'Reference #', 'problem' => 'Problem', 'business' => 'Business Unit', 'owner' => 'Owner', 'when' => 'When', 'date' => 'Log Date', 'location' => 'Location', 'cause' => 'RCA/Cause', 'improvement' => 'Improvement', 'reportedby' => 'Reported By', 'date1' => 'Date', 'time' => 'Time', 'doc' => 'Document', 'line' => 'Line'));
     
        $resultset = $this->viewRTAs();
        //dump_array($resultset);
        if (!empty($resultset)) {
            foreach ($resultset as $resultElement) {
                $orgObj->setItemInfo(array('id' => $resultElement['business']));
                $bu_details = $orgObj->displayItemById();
                $ac_id = $resultElement['ID'];
                $problem_description = compact_action_tracker_description($resultElement['problem']);

                $locObj->setItemInfo(array('id' => $resultElement['location']));
                $location_data = "";
                $location = $locObj->getFUllLocation();

                $participant_id = $resultElement['owner'];
                $participantObj->setItemInfo(array('id' => $participant_id));
                $partcipantData = $participantObj->displayItemById();

                $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

                              $who_id = $resultElement['reported_by'];
                $participantObj->setItemInfo(array('id' => $who_id));
                $partcipantData = $participantObj->displayItemById();

                $who_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
                
                $result[$i]['reference'] = $resultElement['reference'];
                $result[$i]['problem'] = $problem_description;
                $result[$i]['business'] = $bu_details['buName'];
                $result[$i]['owner'] = $participant_name;
                $result[$i]['when'] = format_date($resultElement['datereported']);
                $result[$i]['date'] = format_date($resultElement['dateentered']);
                $result[$i]['location'] = $location;
                $result[$i]['cause'] = $resultElement['cause'];
                $result[$i]['improvement'] = $resultElement['improvement'];
                $result[$i]['reportedby'] = $who_name;
                $result[$i]['date1'] =format_date($resultElement['datereported']);;
                $result[$i]['time'] = substr($resultElement['timereported'], 0,5);
                $result[$i]['doc'] = $resultElement['ss_doc'];
                $result[$i]['line'] = $resultElement['ss_line'];
                $i++;
            }
            $result = array_merge($heading, $result);
            return $result;
        } else {
            return $heading;
        }
    }

}

?>