<?php
 /**
  $Id: ProcessFlow.class.php,v 10.0 Saturday, February 05, 2011 1:26:07 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Wednesday, October 20, 2010 2:57:54 PM>
  */

require_once "ProcessObject.class.php";

class ProcessFlow
{
	private $pfObject;
	private $img;
	private $canvasWidth;
	private $canvasHeight;
	private $lineThickness;
	private $outlineThickness;
	private $noOfAlternatePaths;
	private $processData;
	private $businessUnitColumnWidth;
	private $blockWidth;
	private $blockHeight;
	private $maxLevel;
	private $maxDepth;
	private $colours;
	private $flagShowGrid;
	private $altPathTotal;
	private $objectWidth; // in case of rectangle
	private $objectHeight; // in case of rectangle
	private $objectVertex;  // in case of diamond, traingle
	private $objectGap;

	private $debugMode;

	private $resample;
	private $resamplePercent;

	private $xOffsetAltFirstPath;
	private $xOffsetAltSecondPath;
	private $xOffsetAltThirdPath;
	private $xOffsetAltFourthPath;
	private $subprocessOffset;
	private $businessUnitFontSize;
	private $fontFile;
	private $hasInterProcessReferences;
	private $outputType; // N None, H Horizontal, V Vertical

	private $outputFile; // to save the image
	private $horizontalOffsetPool;
	private $shadeOffset;
	private $hasEndLozenge;
	private $endpos;

	public function __construct($p_debugMode=false,$p_resample=false,$p_type='N') {

		$this->outputType				= $p_type;
		$this->debugMode 				= $p_debugMode;
		$this->visualdebug 		= false;
		$this->resample 					= (boolean) $p_resample;
		$this->resamplePercent 	= 0.60;

		if (!$this->debugMode) {
			header('Content-type: image/png');
		}

		putenv('GDFONTPATH=' . realpath('.'));
		$this->fontFile 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arialbd.ttf';
		$this->fontFile_2 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/arial.ttf';
		$this->fontFile_3 	= realpath(_PATH_PRIVATE_FILES.'../fonts').'/ariblk.ttf';

		$this->canvasWidth					= 0; // in px
		$this->canvasHeight					= 0; // in px
		$this->lineThickness				= 1; // in px, Please do not change this property. It is purely used for calculation only.

        if ( $p_type == 'H' ) {
            $this->outlineThickness				= 3; // in px
        } else {
            $this->outlineThickness				= 1; // in px
        }


		$this->maxLevel = 0; // columns
		$this->maxDepth = 6;

		if ( $this->outputType == 'H' )  {
			$this->businessUnitColumnWidth 		= 380; //in px
			$this->businessUnitFontSize			= 11;

			$this->objectWidth 		= 240;
			$this->objectHeight 	= 90;

			$this->objectGap 		= 45; // in px
		} else {
			$this->businessUnitColumnWidth 		= 280; //in px
			$this->businessUnitFontSize			= 9;

			$this->objectWidth 		= 60;
			$this->objectHeight 	= 30;

			$this->objectGap 		= 15; // in px
		}

		$this->flagShowGrid		= true;
		$this->altPathTotal		= 0;

		$this->business_units 	= array();
		$this->block_information;
		$this->block_data= array();;
		$this->block_path_information_expanded;

		$this->xOffsetMainPath 			= 0;
		$this->xOffsetAltFirstPath 		= 30;
		$this->xOffsetAltSecondPath 	= 15;
		//		$this->xOffsetAltSecondPath 	= 30;
		$this->xOffsetAltThirdPath 		= -15;
		$this->xOffsetAltFourthPath 	= -30;

		$this->yOffsetMainPath 			= 0;
		$this->yOffsetAltFirstPath 		= 35;
		$this->yOffsetAltSecondPath 	= 38;
		$this->yOffsetAltThirdPath 		= 42;
		$this->yOffsetAltFourthPath 	= -30;

		$this->subprocessOffset 		= 5;
		$this->headerHeight 			= 140;

		$this->horizontalOffsetPool					= array();
		$this->horizontalOffsetPool[0]['offset']	= 1;
		$this->horizontalOffsetPool[0]['used']		= 1;
		$this->horizontalOffsetPool[0]['steps']		= array();

		$this->horizontalOffsetPool[1]['offset']	= 5;
		$this->horizontalOffsetPool[1]['used']		= 0;
		$this->horizontalOffsetPool[1]['steps']		= array();

		$this->horizontalOffsetPool[2]['offset']	= -5;
		$this->horizontalOffsetPool[2]['used']		= 0;
		$this->horizontalOffsetPool[2]['steps']		= array();

		$this->horizontalOffsetPool[3]['offset']	= 9;
		$this->horizontalOffsetPool[3]['used']		= 0;
		$this->horizontalOffsetPool[3]['steps']		= array();

		$this->horizontalOffsetPool[4]['offset']	= -9;
		$this->horizontalOffsetPool[4]['used']		= 0;
		$this->horizontalOffsetPool[4]['steps']		= array();

		$this->horizontalOffsetPool[5]['offset']	= 13;
		$this->horizontalOffsetPool[5]['used']		= 0;
		$this->horizontalOffsetPool[5]['steps']		= array();

		$this->horizontalOffsetPool[6]['offset']	= -13;
		$this->horizontalOffsetPool[6]['used']		= 0;
		$this->horizontalOffsetPool[6]['steps']		= array();

		$this->horizontalOffsetPool[7]['offset']	= 17;
		$this->horizontalOffsetPool[7]['used']		= 0;
		$this->horizontalOffsetPool[7]['steps']		= array();

		$this->horizontalOffsetPool[8]['offset']	= -17;
		$this->horizontalOffsetPool[8]['used']		= 0;
		$this->horizontalOffsetPool[8]['steps']		= array();

		$this->horizontalOffsetPool[9]['offset']	= 21;
		$this->horizontalOffsetPool[9]['used']		= 0;
		$this->horizontalOffsetPool[9]['steps']		= array();
		
		$this->horizontalOffsetPool[10]['offset']	= -21;
		$this->horizontalOffsetPool[10]['used']		= 0;
		$this->horizontalOffsetPool[10]['steps']		= array();

		$this->shadeOffset = 5;
	}

	private function getMaxLevel() {

		
			foreach ( $this->blocks_data as $block_ele ) {

				foreach ( $block_ele[level] as $block_level=>$data ) {

					if ( $block_level > $this->maxLevel ) {
						$this->maxLevel = $block_level ;
				}	
				}
			}
		$this->maxLevel--;
		}

	private function getMaxdepth() {

		$interProcessAltPath 	= false;

foreach ( $this->blocks_data as $data_ele ) 
{
$depth+=$data_ele[height];
}



	//	$this->maxDepth 		= count($this->business_units);
$this->maxDepth 		= $depth;

		for ( $i=0;$i<count($this->block_information);$i++) {

			$path_information_arr = explode('~#~',$this->block_information[$i]['path_information']);

			$k = 0;

			if ( count($path_information_arr) ) {
				foreach ( $path_information_arr as $path_information_ele ) {
					$step_data_arr = explode(':',$path_information_ele);

					$this->block_path_information_expanded[$i][$k++] = $step_data_arr;

				} // end foreach loop
			}
		} // end for loop

		if ( $this->hasInterProcessReferences ) {
			$this->maxDepth = $this->maxDepth + 2;
		}
				if ( $this->maxDepth ==1 ) {
			$this->maxDepth =2;
		}
	}

	public function getPFdepth() {
		return $this->maxDepth;
	}

    public function gdecho() {

        $w = 100;
        $h = 100;
        $im = imagecreatetruecolor($w,$h);
        $white = imagecolorallocate($im, 255, 255, 255);

        // Draw a white rectangle
        imagefilledrectangle($im, 4, 4, $w-5, $h-5, $white);

        // Save the image
        imagepng($im);
        imagedestroy($im);
        return true;
    }

	public function setInformation($p_business_units,$p_blocks_information,& $p_procObj,$block_data) {

        //$this->gdecho(); return false;
        $this->pfObject 					= $p_procObj;
		$this->blocks_data 					= $block_data;
		$this->hasEndLozenge				= $this->pfObject->getEndLozengeCount($this->pfObject->getCurrentProcessFlow());
		$this->hasInterProcessReferences 	= false;

		$p_business_units 					= array_unique($p_business_units);

		if ( count($p_business_units) ) {
			$k = 0;
			foreach ( $p_business_units as $p_business_units_ele ) {
				$business_units[chr(65+$k++)] = $p_business_units_ele;
			}
		}

        $this->business_units				= & $business_units;

		$this->block_information 			= $p_blocks_information;
		$this->altPathTotal					= count($this->block_information) - 1;

		if ( count($this->block_information[0]['step_information']) ) {
			foreach ( $this->block_information[0]['step_information'] as $block_information_step_ele ) {
				if ( $block_information_step_ele['intraProcess'] || $block_information_step_ele['interProcess'] ) {
					$this->hasInterProcessReferences = true;
					break;
				}
			}
		}

		// get maximum depth of the process flow
		$this->getMaxdepth();

        $total_paths 			= $this->altPathTotal + 1;

		if ( $this->outputType == 'H' ) {
			$this->blockWidth		= 300;
		} else {
			$this->blockWidth		= 150;
		}
$subhgth=(count($this->block_information)-1)*4; //add abit for alt paths
//		$this->blockHeight		= ($total_paths*$this->objectHeight) + (($total_paths+1)*$this->objectGap); // for 15px gap and 30px per object
		$this->blockHeight		= $this->objectHeight+(2*($this->objectGap+$subhgth)); // for 15px gap and 30px per object
		
		/* Get max level from data */
		$this->getMaxLevel();

		if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
			$this->maxLevel++;       // one extra column for end lozenge
		}

		$this->canvasWidth		= $this->businessUnitColumnWidth + ($this->blockWidth * $this->maxLevel) + $this->lineThickness*($this->maxLevel+2);

		if ( $this->outputType == 'N' )  {
			$this->canvasHeight		= ($this->blockHeight * $this->maxDepth) + $this->lineThickness*($this->maxDepth+2);
		} else {
			$this->canvasHeight		= $this->headerHeight + ($this->blockHeight * $this->maxDepth) + $this->lineThickness*($this->maxDepth+2)+250;
		}

        $this->img = imagecreatetruecolor($this->canvasWidth,$this->canvasHeight)
			  or die('Cannot Initialize new GD image stream');

        //$this->img = @imagecreatetruecolor(100,100);


		$bcolour 		= $this->hex2RGB('#0D830D');
		$bglosscolour 	= $this->hex2RGB('#219B21');
		$bgloss2colour 	= $this->hex2RGB('#63C563');
		$boutputcolour 	= $this->hex2RGB('#EDFCC8');

		$dcolour 		= $this->hex2RGB('#EFB31F');
		$dglosscolour 	= $this->hex2RGB('#F4D27E');
		$dgloss2colour 	= $this->hex2RGB('#F8F0DF');
		$doutputcolour 	= $this->hex2RGB('#FCF0C8');

		$shadcolour 	= $this->hex2RGB('#a1a1a1');
		$shadcolour2 	= $this->hex2RGB('#cccccc');
		$scolour 		= $this->hex2RGB('#8DEEEE');
		$lcolour 		= $this->hex2RGB('#9370DB');
		$mpcolour		= $this->hex2RGB('#000000');
		/*		
		$a1pcolour 		= $this->hex2RGB('#8B8B00');
		$a2pcolour 		= $this->hex2RGB('#CDBE70');
		$a3pcolour 		= $this->hex2RGB('#CDAA7D');
		*/
		$a1pcolour 		= $this->hex2RGB('#C73633');
		$a2pcolour 		= $this->hex2RGB('#0265CB');
		$a3pcolour 		= $this->hex2RGB('#A305BA');
		
		$a4pcolour 		= $this->hex2RGB('#CD3700');
		$a5pcolour 		= $this->hex2RGB('#388E8E');
		$a10pcolour 	= $this->hex2RGB('#CD4002');
		
		$gccolour 		= $this->hex2RGB('#dddddd');
		$txcolour 		= $this->hex2RGB('#202020');
		$bgcolour 		= $this->hex2RGB('#F7F7F7');
		$sbpcolour 		= $this->hex2RGB('#Ff0000');

		$gotocolour 	= $this->hex2RGB('#FF6500');
				
		// colours for CCP and CMS Reference
		$ccpcolour 		= $this->hex2RGB('#Ff0000');
		$ccp1colour     = $this->hex2RGB('#800080');
		$ccpsubcolour 	= $this->hex2RGB('#Ff8000');		
		$cmsrcolour 	= $this->hex2RGB('#ff0000');
		$whitecolour 	= $this->hex2RGB('#ffffff');


		$this->colours['shadow_colour'] 			= imagecolorallocate($this->img,$shadcolour['red'], $shadcolour['green'], $shadcolour['blue']);
		$this->colours['shadow2_colour'] 			= imagecolorallocate($this->img,$shadcolour2['red'], $shadcolour2['green'], $shadcolour2['blue']);
		$this->colours['action_colour'] 			= imagecolorallocate($this->img,$bcolour['red'], $bcolour['green'], $bcolour['blue']);
		$this->colours['action_gloss_colour'] 		= imagecolorallocate($this->img,$bglosscolour['red'], $bglosscolour['green'], $bglosscolour['blue']);
		$this->colours['action_gloss2_colour'] 		= imagecolorallocate($this->img,$bgloss2colour['red'], $bgloss2colour['green'], $bgloss2colour['blue']);
		$this->colours['action_output_colour'] 		= imagecolorallocate($this->img,$boutputcolour['red'], $boutputcolour['green'], $boutputcolour['blue']);


		$this->colours['decision_colour']			= imagecolorallocate($this->img,$dcolour['red'], $dcolour['green'], $dcolour['blue']);
		$this->colours['decision_gloss_colour']		= imagecolorallocate($this->img,$dglosscolour['red'], $dglosscolour['green'], $dglosscolour['blue']);
		$this->colours['decision_gloss2_colour']	= imagecolorallocate($this->img,$dgloss2colour['red'], $dgloss2colour['green'], $dgloss2colour['blue']);
		$this->colours['decision_output_colour']	= imagecolorallocate($this->img,$doutputcolour['red'], $doutputcolour['green'], $doutputcolour['blue']);

		$this->colours['support_colour'] 			= imagecolorallocate($this->img,$scolour['red'], $scolour['green'], $scolour['blue']);
		$this->colours['lozenge_colour'] 			= imagecolorallocate($this->img,$lcolour['red'], $lcolour['green'], $lcolour['blue']);
		$this->colours['main_path_colour'] 			= imagecolorallocate($this->img,$mpcolour['red'], $mpcolour['green'], $mpcolour['blue']);
		$this->colours['alt1_path_colour'] 			= imagecolorallocate($this->img,$a1pcolour['red'], $a1pcolour['green'], $a1pcolour['blue']);
		$this->colours['alt2_path_colour'] 			= imagecolorallocate($this->img,$a2pcolour['red'], $a2pcolour['green'], $a2pcolour['blue']);
		$this->colours['alt3_path_colour'] 			= imagecolorallocate($this->img,$a3pcolour['red'], $a3pcolour['green'], $a3pcolour['blue']);
		$this->colours['alt4_path_colour'] 			= imagecolorallocate($this->img,$a4pcolour['red'], $a4pcolour['green'], $a4pcolour['blue']);
		$this->colours['alt5_path_colour'] 			= imagecolorallocate($this->img,$a5pcolour['red'], $a5pcolour['green'], $a5pcolour['blue']);
		$this->colours['alt10_path_colour'] 		= imagecolorallocate($this->img,$a10pcolour['red'], $a10pcolour['green'], $a10pcolour['blue']);

		$this->colours['grid_colour'] 				= imagecolorallocate($this->img,$gccolour['red'], $gccolour['green'], $gccolour['blue']);
		$this->colours['text_colour'] 				= imagecolorallocate($this->img,$txcolour['red'], $txcolour['green'], $txcolour['blue']);
		$this->colours['background_colour'] 		= imagecolorallocate($this->img,$bgcolour['red'], $bgcolour['green'], $bgcolour['blue']);
		$this->colours['sub_process_colour']		= imagecolorallocate($this->img,$sbpcolour['red'], $sbpcolour['green'], $sbpcolour['blue']);
		$this->colours['alt90_path_colour'] 		= imagecolorallocate($this->img,$gotocolour['red'], $gotocolour['green'], $gotopcolour['blue']);

		$this->colours['ccp_colour']				= imagecolorallocate($this->img,$ccpcolour['red'], $ccpcolour['green'], $ccpcolour['blue']);
		$this->colours['ccp1_colour']				= imagecolorallocate($this->img,$ccp1colour['red'], $ccp1colour['green'], $ccp1colour['blue']);
		$this->colours['ccp_sub_colour']				= imagecolorallocate($this->img,$ccpsubcolour['red'], $ccpsubcolour['green'], $ccpsubcolour['blue']);
		$this->colours['cmsr_colour']				= imagecolorallocate($this->img,$cmsrcolour['red'], $cmsrcolour['green'], $cmsrcolour['blue']);
		$this->colours['white_colour']				= imagecolorallocate($this->img,$whitecolour['red'], $whitecolour['green'], $whitecolour['blue']);

		//imagestring($this->img, 1, 5, 5,  'A Simple Text String',$action_colour);

	}

	private function hex2RGB($hexStr, $returnAsString = false, $seperator = ',') {

		$hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
		$rgbArray = array();

		if (strlen($hexStr) == 6) { //If a proper hex code, convert using bitwise operation. No overhead... faster
			$colorVal = hexdec($hexStr);
			$rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
			$rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
			$rgbArray['blue'] = 0xFF & $colorVal;
		} elseif (strlen($hexStr) == 3) { //if shorthand notation, need some string manipulations
			$rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
			$rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
			$rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
		} else {
			return false; //Invalid hex color code
		}

		return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
	}

    public function showExternalImage($x1, $y1,$type='action') {

        switch ($type) {
            case 'action': $icon_bg_file = _MYROOT.'images/action_bg.png'; break;
            case 'decision': $icon_bg_file = _MYROOT.'images/decision_bg.png'; break;
            case 'support': $icon_bg_file = _MYROOT.'images/support_bg.png'; break;
            case 'ccp1': $icon_bg_file = _MYROOT.'images/ccp1_icon.png'; break;
            case 'ccp2': $icon_bg_file = _MYROOT.'images/ccp2_icon.png'; break;
            case 'ccp3': $icon_bg_file = _MYROOT.'images/ccp3_icon.png'; break;
            case 'cmsr': $icon_bg_file = _MYROOT.'images/cmsr_icon.png'; break;
            case 'sbp': $icon_bg_file = _MYROOT.'images/cmsr_icon.png';
        }

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefrompng($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, $x1-5, $y1, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }
    }

	public function drawCanvas() {
		imagefilledrectangle($this->img,0,0,$this->canvasWidth,$this->canvasHeight,$this->colours['background_colour']);
/*
		if ( $this->outputType == 'H' )  {
imagerectangle($this->img,0,0,$this->canvasHeight-200,$this->canvasWidth,$this->colours['background_colour']);
}
*/
		imagerectangle($this->img,0,0,($this->canvasWidth-$this->lineThickness),($this->canvasHeight-$this->lineThickness),$this->colours['grid_colour']);
		


        if ( $this->outputType == 'H' )  {
			$y1 = $this->lineThickness + $this->headerHeight;
		} else {
			$y1 = 0;
		}

$y1 = 0;

		$y2 = $this->canvasHeight - 1;

		// show grid for idea
		if ($this->flagShowGrid) {

			// vertical
			for ($i=0;$i<$this->maxLevel;$i++) {

                $x1 = $x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
                imageline($this->img,$x1-1,$y1,$x2-1,$y2,$this->colours['grid_colour']);
                imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
                imageline($this->img,$x1+1,$y1,$x2+1,$y2,$this->colours['grid_colour']);
			}


			$x1 = 0;
			$x2 = $this->canvasWidth - 1;

/*
			if ( $this->outputType == 'H' )  {

				$y1 = $y2 = $this->headerHeight;
				imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);
			}
*/
			// horizontal

			
			$y1=0;
			foreach ($this->blocks_data as $data_ele)
			{
				
			$y1 = $y2 = $y1+$this->lineThickness + ($this->blockHeight * $data_ele[height]);
			imageline($this->img,$x1,$y1,$x2,$y2,$this->colours['grid_colour']);	
			}

		}
		
		$y1=15;		

		if ($this->visualdebug) {

			// vertical
			for ($i=0;$i<$this->maxLevel;$i++) {

				$x1 = $x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
				$y1 = 0;
				$y2 = $this->canvasHeight - 1;

				// horizontal
				$yk1 =0;
				$k=1;
				
				
			foreach ($this->blocks_data as $data_ele)
			{ 

					$xk1 = 0;
					$xk2 = $this->canvasWidth - 1;

					//$x2 = $this->lineThickness + $this->businessUnitColumnWidth + ($this->blockWidth * $i);
					$yk1 = $yk2 = $this->lineThickness + ($this->blockHeight * $k);
			$yk1 = $yk2 = $yk1+$this->lineThickness + ($this->blockHeight * $data_ele[height]);
					imagefttext($this->img, 45, 0, $x1+$xk1, $yk1-70, $this->colours['grid_colour'], $this->fontFile,chr($k+64).($i+1));
					$k++;
				}
			}
		}

		// vertical
		$k = 1;
$y1=8;
		foreach ( $this->business_units as $business_unit_ele_key=>$business_unit_ele_value ) {

			$x1 = $this->lineThickness + 6;



			$k++;
			
			$height=$this->blocks_data[$business_unit_ele_key][height];

			$business_unit_arr = explode('|',$business_unit_ele_value);
			$business_unit_name = $business_unit_arr[0];
            //$business_unit_name = $business_unit_arr[0].'-'.$business_unit_arr[1];


			if ( strlen($business_unit_name) > 22 ) {

				$strings 	= wordwrap($business_unit_name, 22, "#", false);
				$string_arr = explode("#",$strings);

				$cy1 = $y1 + 12+(($this->blockHeight*$height)/2)-(9*count($string_arr));

				foreach ( $string_arr as $strele ) {
					//imagestring($this->img, $this->businessUnitFontSize, $x1, $cy1,$strele,$this->colours['text_colour']);
					imagefttext($this->img, $this->businessUnitFontSize,0, $x1, $cy1, $this->colours['text_colour'], $this->fontFile,$strele);
					$cy1 = $cy1 + 18;
				}

			} else {

			 $cy1 = $y1 + $this->blockHeight*$height*0.5-6;
			 $cy1 = $y1+($this->blockHeight*$height*0.5);
				//imagestring($this->img, $this->businessUnitFontSize, $x1, $y1,$business_unit_ele_value,$this->colours['text_colour']);
				imagefttext($this->img, $this->businessUnitFontSize, 0, $x1, $cy1, $this->colours['text_colour'], $this->fontFile,$business_unit_name);
			}
		$y1+=$this->blockHeight*$height;	
		}
		//dump_array($this);
	}

	public function drawObjects() {

		try {
		
		$height=0;
		//imagestring($this->img, 2,200, 100,$this->blockHeight,$this->colours['text_colour']);


		
		$block_cord[x]=$this->businessUnitColumnWidth-($this->objectWidth/2);
		$block_cord[y]=$this->blocks_data[A][height]*$this->blockHeight/2 ;
		
		ProcessObject::DrawObject('LOZENGE',$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'START',$block_step_information);

					foreach ($this->blocks_data as $data_ele)
			{
			foreach($data_ele[level] as $posdatakey=> $posdatavalue) 
			{
			$left=200+$this->blockWidth*$posdatakey;
			$x = ($this->blockWidth - $this->objectWidth)/2;
	
			$block_cord[x]=$this->businessUnitColumnWidth+($posdatakey-1)*$this->blockWidth+$x;
			
			foreach($posdatavalue as $stepkey=> $stepvalue)
			{
			$step=explode("|",$stepvalue);
						if ($step[0]=="EMPTY" || $step[1]=='B')
			continue;
			$offset=$this->getoffset($stepkey,$step[1]);
			
						switch($step[1]) {
						case 'A' : $node_type = 'ACTION'; break;
						case 'D' : $node_type = 'DECISION'; break;
						case 'S' : $node_type = 'SUPPORT'; break;
						case 'STOP' : $node_type = 'LOZENGE'; break;
					}
			
			
$block_step_information=$this->block_information[$step[2]][step_information][$step[0]];			
			
			$block_cord[y]=$height+$data_ele[height]*$this->blockHeight/2 - ($this->objectHeight/2)+($offset*$this->blockHeight);
			
			//imagestring($this->img, 2,$left, $height,$block_cord[y],$this->colours['text_colour']);
			
			ProcessObject::DrawObject($node_type,$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information);
			
				$block_cord[y]=($this->maxDepth-1)*$this->blockHeight;
	if ($step[3]==1)		
	ProcessObject::DrawObject("EXOUTPROCESS",$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information);
		if ($step[3]==2)		
	ProcessObject::DrawObject("EXINPROCESS",$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information);
}
			
			}
			$height+=$this->blockHeight*$data_ele[height];
			}
		
				} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}
		
		}	
	
	
	public function drawObjectsx() {

		try {

			$k = 0;
            foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				foreach ( $block_information_arr as $business_unit_ele_value ) {

					$block_record_granules  = explode(':',$business_unit_ele_value);

					$step_information = $block_step_information[$block_record_granules[3]];

					/*echo $step_information['type'];
					dump_array($block_record_granules);*/

					$context_level = $block_record_granules[0];
					$context_code	= $context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

					if (!$k) {

						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$start_context_code = $context_level.':1:0';

						if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
							// start lozenge
							ProcessObject::DrawObject('LOZENGE',$this,$start_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'START',$block_step_information);
						}

						$k++;
					}

					if ( $block_record_granules[2] == 0 ) {
						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$context_code_main_path = $context_code;
					} else {
						$main_path = false;
						$alt_path = true;
						$lozenge = 'NA';
					}

					$intraprocess_goto_link_data = $this->pfObject->intraprocess_goto_link_information();
					$intraprocess_goto_link = true;

					// code block for intra process flow
					if ( $block_record_granules[5] == 'IN' || $block_record_granules[5] == 'OUT' || $block_record_granules[5] == 'EXIN' || $block_record_granules[5] == 'EXOUT' ) {

						$outer_context_code = chr($this->maxDepth+64).':'.$block_record_granules[1].':0';

						//echo $block_record_granules[4].'->'.$outer_context_code;
						if ( $block_record_granules[6] != $this->pfObject->getCurrentProcessFlow() && ( $block_record_granules[5] == 'EXOUT' || $block_record_granules[5] == 'EXIN' ) ) {
							ProcessObject::DrawObject($block_record_granules[5].'PROCESS',$this,$outer_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$block_record_granules[5],$block_step_information[$block_record_granules[3]],$this->outputType);
						}
					}

					switch($step_information['type']) {
						case 'A' : $node_type = 'ACTION'; break;
						case 'D' : $node_type = 'DECISION'; break;
						case 'S' : $node_type = 'SUPPORT'; break;
						}

					ProcessObject::DrawObject($node_type,$this,$context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
				} // end inner foreach

			} // end outer foreach

			if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
				// stop lozenge
				ProcessObject::DrawObject('LOZENGE',$this,$context_code_main_path,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information[$block_record_granules[3]]);
			}

			// repeat loop for support module
			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				if ( $block_information_ele['support_information'] != '' && count($block_support_information_arr) ) {
					foreach ( $block_support_information_arr as $block_support_information_ele ) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_ele);
						$block_record_granules  = explode(':',$block_support_start_end_information_arr[1]);

						$step_information = $block_step_information[$block_record_granules[3]];
						$support_context_level = $block_record_granules[0];
						$support_context_code	= $support_context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

						if ( $block_record_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';

							$context_code_main_path = $context_code;
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						//if ( $this->outputType == 'N' )  {
							$node_type = 'SUPPORT';
							ProcessObject::DrawObject($node_type,$this,$support_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
						//}
					} // end inner foreach 2*/

				} // end outer foreach
			} // end if


		} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}
	}

	public function drawShadowObjects() {

		try {
		
		$height=0;
		//imagestring($this->img, 2,200, 100,$this->blockHeight,$this->colours['text_colour']);

		
		
		$block_cord[x]=$this->businessUnitColumnWidth-($this->objectWidth/2);
		$block_cord[y]=$this->blocks_data[A][height]*$this->blockHeight/2 ;
		
		ProcessObject::DrawShadowObject('LOZENGE',$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'START',$block_step_information);

					foreach ($this->blocks_data as $data_ele)
			{
			foreach($data_ele[level] as $posdatakey=> $posdatavalue) 
			{
			$left=200+$this->blockWidth*$posdatakey;
			$x = ($this->blockWidth - $this->objectWidth)/2;
	
			$block_cord[x]=$this->businessUnitColumnWidth+($posdatakey-1)*$this->blockWidth+$x;
			
			foreach($posdatavalue as $stepkey=> $stepvalue)
			{
			$step=explode("|",$stepvalue);
			if ($step[0]=="EMPTY" || $step[1]=='B')
			continue;
			$offset=$this->getoffset($stepkey,$step[1]);
			
						switch($step[1]) {
						case 'A' : $node_type = 'ACTION'; break;
						case 'D' : $node_type = 'DECISION'; break;
						case 'S' : $node_type = 'SUPPORT'; break;
						case 'STOP' : $node_type = 'LOZENGE'; break;
					}
			

			$block_cord[y]=$height+$data_ele[height]*$this->blockHeight/2 - ($this->objectHeight/2)+($offset*$this->blockHeight);

			//imagestring($this->img, 2,$left, $height,$block_cord[y],$this->colours['text_colour']);

			ProcessObject::DrawShadowObject($node_type,$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information);

	$block_cord[y]=($this->maxDepth-1)*$this->blockHeight;
	if ($step[3]==1)		
	ProcessObject::DrawShadowObject("EXOUTPROCESS",$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information);
		if ($step[3]==2)		
	ProcessObject::DrawShadowObject("EXINPROCESS",$this,$block_cord,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information);		
			
}
		

		 
			
			}
			$height+=$this->blockHeight*$data_ele[height];
			}
		
				} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}
		
		}
/*
	public function drawShadowObjects() {

		try {

			$k = 0;
			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				foreach ( $block_information_arr as $business_unit_ele_value ) {

					$block_record_granules  = explode(':',$business_unit_ele_value);

					$step_information = $block_step_information[$block_record_granules[3]];

					/*echo $step_information['type'];
					dump_array($block_record_granules);

					$context_level = $block_record_granules[0];
					$context_code	= $context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

					if (!$k) {

						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$start_context_code = $context_level.':1:0';

						if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
							// start lozenge
							ProcessObject::DrawShadowObject('LOZENGE',$this,$start_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'START',$block_step_information);
						}

						$k++;
					}

					if ( $block_record_granules[2] == 0 ) {
						$main_path = true;
						$alt_path = false;
						$lozenge = 'NA';

						$context_code_main_path = $context_code;
					} else {
						$main_path = false;
						$alt_path = true;
						$lozenge = 'NA';
					}

					$intraprocess_goto_link_data = $this->pfObject->intraprocess_goto_link_information();
					$intraprocess_goto_link = true;

					// code block for inter process flow
					if ( $block_record_granules[5] == 'IN' || $block_record_granules[5] == 'OUT' || $block_record_granules[5] == 'EXIN' || $block_record_granules[5] == 'EXOUT' ) {

						$outer_context_code = chr($this->maxDepth+64).':'.$block_record_granules[1].':0';

						//echo $block_record_granules[4].'->'.$outer_context_code;
						if ( $this->outputType == 'N' && $block_record_granules[6] != $this->pfObject->getCurrentProcessFlow() && ( $block_record_granules[5] == 'EXOUT' || $block_record_granules[5] == 'EXIN' )  ) {
							ProcessObject::DrawShadowObject($block_record_granules[5].'PROCESS',$this,$outer_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$block_record_granules[5],$block_step_information[$block_record_granules[3]]);
						}
					}

					switch($step_information['type']) {
						case 'A' : $node_type = 'ACTION'; break;
						case 'D' : $node_type = 'DECISION'; break;
						case 'S' : $node_type = 'SUPPORT'; break;
					}

					ProcessObject::DrawShadowObject($node_type,$this,$context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
				} // end inner foreach

			} // end outer foreach

			if ( $this->outputType == 'N' || $this->outputType == 'H'  )  {
				// stop lozenge
				ProcessObject::DrawObject('LOZENGE',$this,$context_code_main_path,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,'STOP',$block_step_information[$block_record_granules[3]]);
			}

			// repeat loop for support module
			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				if ( $block_information_ele['support_information'] != '' && count($block_support_information_arr) ) {
					foreach ( $block_support_information_arr as $block_support_information_ele ) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_ele);
						$block_record_granules  = explode(':',$block_support_start_end_information_arr[1]);

						$step_information = $block_step_information[$block_record_granules[3]];
						$support_context_level = $block_record_granules[0];
						$support_context_code	= $support_context_level.':'.$block_record_granules[1].':'.$block_record_granules[2];

						if ( $block_record_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';

							$context_code_main_path = $context_code;
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						//if ( $this->outputType == 'N' )  {
							$node_type = 'SUPPORT';
							ProcessObject::DrawShadowObject($node_type,$this,$support_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$block_step_information[$block_record_granules[3]]);
						//}
					} // end inner foreach 2

				} // end outer foreach
			} // end if


		} catch( ErrorException $e ) {
			imagestring($this->img, 2, 5, 5,$e->getMessage(),$this->colours['text_colour']);
		}
	}
/*/
public function drawfooter() {

        /*$logo_file = _MYROOT.'images/logosmall.jpg';

		if ( file_exists($logo_file) ) {

			$src = imagecreatefromjpeg($logo_file);
			$size_information = getimagesize($logo_file);

			// copy
			imagecopy($this->img, $src, 10, 10, 0, 0,$size_information[0], $size_information[1]);

			// free memory
			imagedestroy($src);
		}*/




   $icon_bg_file = _MYROOT.'images/legend1.jpg';
       

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefromjpeg($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 100, $this->canvasHeight-130, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }
		
		 $icon_bg_file = _MYROOT.'images/legend2.jpg';
       

        if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefromjpeg($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 110, $this->canvasHeight-30, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }


}

public function drawHeader() {

$width=1500;

$img=$this->img;
$this->img=imagecreatetruecolor($this->canvasWidth,$this->canvasHeight+200);
imagefilledrectangle($this->img,0,0,$this->canvasWidth,200,$this->colours['background_colour']);
imagecopy($this->img,$img,0,200,0,0,$this->canvasWidth,$this->canvasHeight);

		$process_information = $this->pfObject->getCurrentProcessFlowInformation();

        $label['business_owner'] 	= 'BU Owner:';
        $label['risk_rating'] 		= 'Risk Rating';
		$label['process_ref'] 		= 'Process Ref. :';
		$label['process_desc'] 		= 'Process Desc. :';
		$label['hazard_symbol'] 	= 'Hazard Symbol :';
		$label['control_symbol'] 	= 'Control Symbol :';
$icon_bg_file = _MYROOT.'images/logo.jpg';
   
   
  	$optObj = new Option();
	$updObj = new Upload();

	$logo_file_id = $optObj->getOption('_SU_COMPANY_LOGO');
	$optObj = null;

	$updObj->setFileInfo('company_logo',array('id'=>$logo_file_id));
	$file_details = $updObj->getFileDetails();
	$updObj = null;

	$image_name = $file_details['sysFilename'];

//	$icon_bg_file  = _PUB_PATH.$image_name;

$icon_bg_file = _MYROOT.'pub/'.$image_name; 
   
       
 if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefromjpeg($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($this->img, $src, 25, 0, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }


        imagefttext($this->img, $this->businessUnitFontSize, 0, 25, 70, $this->colours['text_colour'], $this->fontFile,$label['business_owner']);
		////imagefttext($this->img, $this->businessUnitFontSize, 0, 580, 50, $this->colours['text_colour'], $this->fontFile,$label['risk_rating']);


		$p_content_strlen = strlen($process_information['buName']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($this->img, $this->businessUnitFontSize, 0, 110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
		} else {

			$strings 	= substr($process_information['buName'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
				
			
			}

		
		
	

		imagefttext($this->img, $this->businessUnitFontSize, 0, 1000, 70, $this->colours['text_colour'], $this->fontFile,$label['process_ref']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 500, 70, $this->colours['text_colour'], $this->fontFile,$label['process_desc']);

		$p_content_strlen = strlen($process_information['description']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);
		} else {

			$strings 	= substr($process_information['description'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$strings);
				
			
			}

		$p_content_strlen = strlen($process_information['reference']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
				imagefttext($this->img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		} else {

			$strings 	= substr($process_information['reference'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($this->img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
				
			
			}


		//imagefttext($this->img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		//imagefttext($this->img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);



		imagefttext($this->img, $this->businessUnitFontSize, 0, 25, 105, $this->colours['text_colour'], $this->fontFile,$label['hazard_symbol']);
		imagefttext($this->img, $this->businessUnitFontSize, 0, 600, 105, $this->colours['text_colour'], $this->fontFile,$label['control_symbol']);

		$symbols 			= $this->pfObject->getHazardControlSymbols();

		$hazard_symbols		= $symbols['hazard'];
		$control_symbols 	= $symbols['control'];

        ///$hazard_symbols = array('ha2.jpg','ha20.jpg','ha21.jpg','ha22.jpg','ha23.jpg','ha24.jpg','ha25.jpg','ha26.jpg','ha27.jpg');
        ///$control_symbols = array('2.jpg','20.jpg','21.jpg','22.jpg','23.jpg','24.jpg','25.jpg','26.jpg','27.jpg');

		$max_symbol_count 	= 15;
		if ( 1 && count($hazard_symbols) ) {

			$k = 0;
			foreach ( $hazard_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../hazard') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+150)+($k*6);
					imagecopy($this->img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		if ( 1 && count($control_symbols) ) {

			$k = 0;
			foreach ( $control_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../improvement') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+735)+($k*6);
					imagecopy($this->img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		imagefilledrectangle($this->img, $width - 130, 65, $width - 106, 100, $this->colours['action_colour']);
		imagefilledrectangle($this->img, $width - 104, 65, $width - 86, 100, $this->colours['action_colour']);
		imagefilledrectangle($this->img, $width - 84, 65, $width - 55, 100, $this->colours['action_colour']);
		imagefttext($this->img, 24, 0, $width - 130, 95, $this->colours['white_colour'], $this->fontFile,'C I A');

		$risk_rating 		= $this->pfObject->getRiskRating();

        $risk_rating['riskRating1'] = 'R';
		$risk_rating['riskRatingColor1'] = '#00ff00';

		if ( $risk_rating['riskRating1'] != '' && $risk_rating['riskRating1'] != '#' ) {

			$risk_rating_rgb 	= $this->hex2RGB($risk_rating['riskRatingColor1']);
			$risk_rating_colour = imagecolorallocate($this->img,$risk_rating_rgb['red'], $risk_rating_rgb['green'],$risk_rating_rgb['blue']);

            $x = $width - 84;

			imagefilledrectangle($this->img, $x, 20, $x+30, 55, $risk_rating_colour);
			imagefttext($this->img, 24, 0, $x+5, 50, $this->colours['white_colour'], $this->fontFile,$risk_rating['riskRating1']);
		}

	}




	public function drawHeaderpdf() {

        /*$logo_file = _MYROOT.'images/logosmall.jpg';

		if ( file_exists($logo_file) ) {

			$src = imagecreatefromjpeg($logo_file);
			$size_information = getimagesize($logo_file);

			// copy
			imagecopy($this->img, $src, 10, 10, 0, 0,$size_information[0], $size_information[1]);

			// free memory
			imagedestroy($src);
		}*/

		$process_information = $this->pfObject->getCurrentProcessFlowInformation();

        $label['business_owner'] 	= 'BU Owner:';
        $label['risk_rating'] 		= 'Risk Rating';
		$label['process_ref'] 		= 'Process Ref. :';
		$label['process_desc'] 		= 'Process Desc. :';
		$label['hazard_symbol'] 	= 'Hazard Symbol :';
		$label['control_symbol'] 	= 'Control Symbol :';
		

//$icon_bg_file = _MYROOT.'images/logo.jpg';

	$optObj = new Option();
	$updObj = new Upload();

	$logo_file_id = $optObj->getOption('_SU_COMPANY_LOGO');
	$optObj = null;

	$updObj->setFileInfo('company_logo',array('id'=>$logo_file_id));
	$file_details = $updObj->getFileDetails();
	$updObj = null;

	$image_name = $file_details['sysFilename'];

//	$icon_bg_file  = _PUB_PATH.$image_name;

$icon_bg_file = _MYROOT.'pub/'.$image_name;
	
$imgWidth=1500;
$img= imagecreatetruecolor($imgWidth,150)  ; 
imagefilledrectangle($img,0,0,$imgWidth,150,$this->colours['white_colour']);   


 if ( file_exists($icon_bg_file) ) {

            $src = imagecreatefromjpeg($icon_bg_file);
            $size_information = getimagesize($icon_bg_file);

            // copy
            imagecopy($img, $src, 25, 0, 0, 0,$size_information[0], $size_information[1]);

            // free memory
            imagedestroy($src);
        }


        imagefttext($img, $this->businessUnitFontSize, 0, 25, 70, $this->colours['text_colour'], $this->fontFile,$label['business_owner']);
		////imagefttext($this->img, $this->businessUnitFontSize, 0, 580, 50, $this->colours['text_colour'], $this->fontFile,$label['risk_rating']);


		$p_content_strlen = strlen($process_information['buName']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($img, $this->businessUnitFontSize, 0, 110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
		} else {

			$strings 	= substr($process_information['buName'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($img, $this->businessUnitFontSize, 0, 110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['buName']);
				
			
			}

		
		
	

		imagefttext($img, $this->businessUnitFontSize, 0, 1000, 70, $this->colours['text_colour'], $this->fontFile,$label['process_ref']);
		imagefttext($img, $this->businessUnitFontSize, 0, 500, 70, $this->colours['text_colour'], $this->fontFile,$label['process_desc']);

		$p_content_strlen = strlen($process_information['description']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
			imagefttext($img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['description']);
		} else {

			$strings 	= substr($process_information['description'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($img, $this->businessUnitFontSize, 0, 620, 70, $this->colours['text_colour'], $this->fontFile_2,$strings);
				
			
			}

		$p_content_strlen = strlen($process_information['reference']);
		$max_string_length = 35;

		

		if ( $p_content_strlen < $max_string_length ) {
				imagefttext($img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
		} else {

			$strings 	= substr($process_information['reference'],0,35).' ...';
			//$string_arr = explode("#",$strings);

			imagefttext($img, $this->businessUnitFontSize, 0, 1110, 70, $this->colours['text_colour'], $this->fontFile_2,$process_information['reference']);
				
			
			}


		imagefttext($img, $this->businessUnitFontSize, 0, 25, 105, $this->colours['text_colour'], $this->fontFile,$label['hazard_symbol']);
		imagefttext($img, $this->businessUnitFontSize, 0, 600, 105, $this->colours['text_colour'], $this->fontFile,$label['control_symbol']);

		$symbols 			= $this->pfObject->getHazardControlSymbols();

		$hazard_symbols		= $symbols['hazard'];
		$control_symbols 	= $symbols['control'];

		$max_symbol_count 	= 15;
		if ( 1 && count($hazard_symbols) ) {

			$k = 0;
			foreach ( $hazard_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../hazard') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+150)+($k*6);
					imagecopy($img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		if ( 1 && count($control_symbols) ) {

			$k = 0;
			foreach ( $control_symbols as $symbol_ele ) {

				if ( $k > $max_symbol_count ) { break; }

				$symbol_file = realpath(_PATH_PRIVATE_FILES.'../improvement') . '/' . $symbol_ele;

				if ( file_exists($symbol_file) ) {

					$src = imagecreatefromjpeg($symbol_file);
					$size_information = getimagesize($symbol_file);

					$new_width 	= 24;
					$new_height = 24;

					// if resampling is enabled.
					$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
						or die('Cannot Initialize new GD image stream');

					imagecopyresampled($this->imgResampled, $src, 0, 0, 0, 0, $new_width, $new_height,$size_information[0], $size_information[1]);

					// copy
					$x = ($k*$new_width+735)+($k*6);
					imagecopy($img, $this->imgResampled, $x,85, 0, 0,$new_width, $new_height);

					// free memory
					imagedestroy($src);
					//imagedestroy($this->imgResampled);
				}

				$k++;
			}
		}

		imagefilledrectangle($img, $imgWidth - 130, 65, $imgWidth - 106, 100, $this->colours['action_colour']);
		imagefilledrectangle($img, $imgWidth - 104, 65, $imgWidth - 86, 100, $this->colours['action_colour']);
		imagefilledrectangle($img, $imgWidth - 84, 65, $imgWidth - 55, 100, $this->colours['action_colour']);
		imagefttext($img, 24, 0, $imgWidth - 130, 95, $this->colours['white_colour'], $this->fontFile,'C I A');

		$risk_rating 		= $this->pfObject->getRiskRating();

        $risk_rating['riskRating1'] = 'R';
		$risk_rating['riskRatingColor1'] = '#00ff00';

		if ( $risk_rating['riskRating1'] != '' && $risk_rating['riskRating1'] != '#' ) {

			$risk_rating_rgb 	= $this->hex2RGB($risk_rating['riskRatingColor1']);
			$risk_rating_colour = imagecolorallocate($img,$risk_rating_rgb['red'], $risk_rating_rgb['green'],$risk_rating_rgb['blue']);

            $x =$imgWidth - 84;

			imagefilledrectangle($img, $x, 20, $x+30, 55, $risk_rating_colour);
			imagefttext($img, 24, 0, $x+5, 50, $this->colours['white_colour'], $this->fontFile,$risk_rating['riskRating1']);
		}
		
$this->savehdrImage($img);
	}


	public function drawPathsxx() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';

		try {

			foreach ($this->block_information as $block_information_ele ) {
			
				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				//$k = 0;
				$block_information_elements_count 			= count($block_information_arr);
				$block_support_information_elements_count 	= count($block_support_information_arr);

				$processed_start_node = false;
				$processed_end_node = false;

				if (1) {

					// for ($m=1;$m<=($block_information_elements_count+1);$m++) {
					for ($m=2;$m<=$block_information_elements_count;$m++) {

						$start_block_information_arr 	= $block_information_arr[$m-2];
						$end_block_information_arr 		= $block_information_arr[$m-1];
					

						//echo $block_information_arr[$m-2]." : ".$block_information_arr[$m-1]." == ".$block_information_elements_count."<br/>";

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						//echo $block_information_elements_count." ".$block_record_end_granules[4]."<br/>";

						if ( count($block_step_information) > 2 ) {

							ProcessObject::DrawPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}

						if ( $block_record_end_granules[4] ) {

							$block_information_main_arr = explode('~#~',($this->block_information[0]['path_information']));

							if ( $block_record_end_granules[4] == 'END' ) {

								$block_information_end_arr = explode(':',$block_information_main_arr[count($block_information_main_arr)-1]);
								$block_information_end_arr[1]++;

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';
								$new_end_context = $block_information_end_arr[0].':'.$block_information_end_arr[1].':0';

								ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

							} else {

								$matches = explode(":",$block_information_main_arr[$block_record_end_granules[4]-1]);

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';
								$new_end_context = $matches[0].':'.$matches[1].':0';

								ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
							}
						}

						//echo $start_context_code." => ".$end_context_code." -------> ";
						//echo $start_block_information_arr." => ".$end_block_information_arr."<br/>";
					} // end for loop
				}

				// standalone start and end block
				if (0 && $this->outputType == 'N' ) {
					$alt_node_type = 'START';

					$start_block_information_arr 	= $block_information_arr[0];
					$end_block_information_arr 		= $block_information_arr[1];

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$end_block_information_arr		= $start_block_information_arr;
					$start_block_information_arr	= $this->getMainPathNodeData($block_record_start_granules[4]);

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$start_context_level = $block_record_start_granules[0];
					$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

					$end_context_level = $block_record_end_granules[0];
					$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

					$main_path = false;
					$alt_path = true;
					$lozenge = 'NA';

					ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					if ( $block_record_start_granules[2] || $block_record_end_granules[2] ) {

						$alt_node_type = 'END';

						$start_block_information_arr 	= $block_information_arr[1];
						$end_block_information_arr 		= $block_information_arr[0];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);

						$end_block_information_arr		= $this->getMainPathNodeData($block_record_start_granules[4]);

						// for mid air stop
						if ( $block_record_start_granules[4] ) {

							$block_record_start_granules  	= explode(':',$start_block_information_arr);
							$block_record_end_granules  	= explode(':',$end_block_information_arr);

							$start_context_level = $block_record_start_granules[0];
							$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

							$end_context_level = $block_record_end_granules[0];
							$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';

							///commented by davinder on 2011/02/05
							////ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}


					}

				}

				// support path blocks
				if (1) { // && $this->outputType == 'N' ) {

					for ($m=0;$m<$block_support_information_elements_count;$m++) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_arr[$m]);

						$start_block_information_arr 	= $block_support_start_end_information_arr[0];
						$end_block_information_arr 		= $block_support_start_end_information_arr[1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawSupportPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					} // end for loop
				} // end if block

			} // end outer foreach

			// for start and alt path first node;
			$mainpath_information 		= $this->block_information[0]['path_information'];
			$mainpath_node_information 	= explode("~#~",$mainpath_information);

			for ($k=1;$k<count($this->block_information);$k++) {

				$main_path = false;
				$alt_path = true;
				$lozenge = 'NA';

				$path_information 			= $this->block_information[$k]['path_information'];
				$path_node_information 		= explode("~#~",$path_information);

				$end_block = $path_node_information[0];

				$alt_path_first_node 		= explode(":",$end_block);
				
				
				///bob new marker required
				//$start_block_first_node 	= explode(":",$mainpath_node_information[$alt_path_first_node[4]-1]);
			
$start_block_first_node=$this->getMainPathNodeDatabyLevel($alt_path_first_node[4]);
				$start_node_code = $start_block_first_node[0].":".$start_block_first_node[1].":".$start_block_first_node[2];
				$end_node_code = $alt_path_first_node[0].":".$alt_path_first_node[1].":".$alt_path_first_node[2];

				if ( $alt_path_first_node[2] ) {
					$path_info = $start_node_code.'~#~'.$end_node_code;
					ProcessObject::DrawStartCrossPath($this,$path_info,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
				}
			}

		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}


public function drawSecondaryPaths() {
 
	try {
	$k=0;
	foreach ( $this->block_information as $block_information_ele ) {	 
	foreach ( $block_information_ele[step_information] as $step_ele ) { 
	 	 	 if ($step_ele["intraProcess"]==1  && $step_ele['gotoProcessStep']==0)
	 {


			$search_business_unit = $step_ele['buName'].'|'.$step_ele['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);


if ($step_ele["altPathIndex"]==0)
{
		$pos=$this->getStepPos($depth,0,$step_ele['ID']);
			$levels=explode("|",$pos);
			$level=$levels[1];	
}	
else
{
		$pos=$this->getStepPos($depth,0,$step_ele['ID']);
			$levels=explode("|",$pos);
			$level=$this->getoffset($levels[1],"A");	
}
			
			$start_pos[y]=($this->blocks_data[$depth][count])*$this->blockHeight;
			$start_pos[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$start_pos[y]+=$level*$this->blockHeight ;
			$start_pos[x]=$this->businessUnitColumnWidth+($this->blockWidth*$levels[0])-$this->blockWidth*0.5;
			
		
		$end_pos=$this->endpos;

			ProcessObject::DrawInternalPath($this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$k,$alt_path,$step_ele[type]);
$k++;
	 }
	elseif ($step_ele["intraProcess"]==1  && $step_ele["swimID"]==$step_ele["gotoProcess"])
	 {


			$search_business_unit = $step_ele['buName'].'|'.$step_ele['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);

			$pos=$this->getStepPos($depth,0,$step_ele['ID']);
			$levels=explode("|",$pos);
			$level=$this->getoffset($levels[1],"A");
			$start_pos[y]=($this->blocks_data[$depth][count])*$this->blockHeight;
			$start_pos[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$start_pos[y]+=$level*$this->blockHeight ;
			$start_pos[x]=$this->businessUnitColumnWidth+($this->blockWidth*$levels[0])-$this->blockWidth*0.5;
	
		
		$goto_step=$this->pfObject->getStepInformation($step_ele['swimID'],$step_ele['gotoProcessStep']);

			$search_business_unit = $goto_step['buName'].'|'.$goto_step['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);

			$pos=$this->getStepPos($depth,0,$goto_step['ID']);

			$levels=explode("|",$pos);
			$level=$this->getoffset($levels[1],"A");
			$end_pos[y]=($this->blocks_data[$depth][count])*$this->blockHeight;
			$end_pos[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$end_pos[y]+=$level*$this->blockHeight ;
			$end_pos[x]=$this->businessUnitColumnWidth+($this->blockWidth*$levels[0])-$this->blockWidth*0.5;
		
	
		
			
			
			ProcessObject::DrawInternalPath($this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$k,$alt_path,$step_ele[type]);
$k++;
	 }
	 

	 
	 
		}		
}
		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}
	 
	 
	public function drawSecondaryPathsA() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';


		try {

			$crosspaths = array();
			$secondary_nodes_arr = array();

			foreach ( $this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];



				foreach ( $block_information_arr as $block_information_expr ) {

					if ( !preg_match("/^[A-Z]{1,2}:[\d]+:[\d]+:[\d]+:[\d]+:NONE:[\d]+:[\d]+$/",$block_information_expr) ) {
						$secondary_nodes_arr[] = $block_information_expr;
					}
				}
			} // end outer foreach


			// process secondary nodes
			if ( count($secondary_nodes_arr) ) {

				foreach ( $secondary_nodes_arr as $secondary_node_ele ) {

					$node_arr = explode(":",$secondary_node_ele);

					if ( $node_arr != 'EXOUT' && $node_arr != 'EXIN' ) {
						$left_nodes_arr[] 	= $node_arr[3];
						$right_nodes_arr[] 	= $node_arr[7];
					}


					//echo $secondary_node_ele."<br/>";
				}

				/*dump_array($left_nodes_arr);
				dump_array($right_nodes_arr);*/

				$link_information_arr = array('internal'=>array(),'external'=>array());

				$k = 0;
				$l = 0;
				$m = 0;

				foreach ( $left_nodes_arr as $left_nodes_ele ) {
					$key = array_search($left_nodes_ele,$right_nodes_arr);

					if ( !in_array(($secondary_nodes_arr[$k]."~#~".$secondary_nodes_arr[$key]),$link_information_arr['internal']) && !in_array(($secondary_nodes_arr[$key]."~#~".$secondary_nodes_arr[$k]),$link_information_arr['internal']) ) {

						$node_arr = explode(":",$secondary_nodes_arr[$k]);

						if ( $node_arr[5] != 'EXOUT' && $node_arr[5] != 'EXIN' ) {
							$link_information_arr['internal'][$l++] = $secondary_nodes_arr[$k]."~#~".$secondary_nodes_arr[$key];
						}

						if ( $node_arr[5] == 'EXOUT' || $node_arr[5] == 'EXIN' ) {
							$link_information_arr['external'][$m++] = $secondary_nodes_arr[$k];
						}
					}

					//echo $key."<br/>";
					$k++;
				}

				if ( count($link_information_arr['internal']) ) {
					foreach ( $link_information_arr['internal'] as $link_information_internal ) {

						$link_information_internal_arr = explode("~#~",$link_information_internal);

						if ( preg_match("/^[A-Z]{1,2}:[\d]+:[\d]+:[\d]+:END:NONE:[\d]+:[\d]+$/",$link_information_internal_arr[0]) ) {
							continue;
						}

						$p_y_offset = $this->availableHorizontalOffset();
						ProcessObject::DrawNewCrossPath($this,$link_information_internal,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$p_y_offset,$this->outputType);
					}
				}

				if (  count($link_information_arr['external']) ) {
					foreach ( $link_information_arr['external'] as $link_information_external ) {
						ProcessObject::DrawNewExternalPath($this,$link_information_external,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
					}
				}

				//dump_array($link_information_arr);
			}

		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}

	public function drawPathsDeprecated() {

		$main_path = true;
		$alt_path = false;
		$lozenge = 'NA';

		try {

			$crosspaths = array();

			foreach ($this->block_information as $block_information_ele ) {

				$block_information_arr 				= explode('~#~',$block_information_ele['path_information']);
				$block_step_information 			= $block_information_ele['step_information'];
				$block_support_information_arr 		= explode('~#~',$block_information_ele['support_information']);

				//dump_array($block_information_arr);

				//$k = 0;
				$block_information_elements_count 			= count($block_information_arr);
				$block_support_information_elements_count 	= count($block_support_information_arr);

				$processed_start_node = false;
				$processed_end_node = false;

				if (1) {

					// for ($m=1;$m<=($block_information_elements_count+1);$m++) {
					for ($m=2;$m<=$block_information_elements_count;$m++) {

						$start_block_information_arr 	= $block_information_arr[$m-2];
						$end_block_information_arr 		= $block_information_arr[$m-1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

						if ( $block_record_end_granules[4] ) {

							$block_information_main_arr = explode('~#~',($this->block_information[0]['path_information']));

							if ( $block_record_end_granules[4] == 'END' ) {

								$block_information_end_arr = explode(':',$block_information_main_arr[count($block_information_main_arr)-1]);
								$block_information_end_arr[1]++;

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';
								$new_end_context = $block_information_end_arr[0].':'.$block_information_end_arr[1].':0';

								ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

							} else {

								//foreach ( $block_information_main_arr as $block_information_test ) {

									//dump_array($block_information_test);


									/*
									if ( preg_match('/[A-Z]:'.$block_record_end_granules[4].':* /', $block_information_test, $matches) ) {

										if ( $matches[0] != '' ) {

											$main_path = false;
											$alt_path = true;
											$lozenge = 'NA';
											$new_end_context = $matches[0].'0';

											ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
										}
									}*/

									//if ( preg_match('/[A-Z]:'.$block_record_end_granules[4].':*/', $block_information_test, $matches) ) {

										//if ( $matches[0] != '' ) {

											$matches = explode(":",$block_information_main_arr[$block_record_end_granules[4]-1]);

											$main_path = false;
											$alt_path = true;
											$lozenge = 'NA';
											$new_end_context = $matches[0].':'.$matches[1].':0';

											ProcessObject::DrawCrossPath('DECISION',$this,$end_context_code,$new_end_context,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
										//}
									//}
								//}
							}


						}

						//echo $start_context_code." => ".$end_context_code." -------> ";
						//echo $start_block_information_arr." => ".$end_block_information_arr."<br/>";
					} // end for loop
				}

				$intraprocess_goto_link_data = $this->pfObject->intraprocess_goto_link_information();

				$intraprocess_goto_link = true;

				if (1) {// && $this->outputType == 'N') {

				//$y_offset = $this->availableHorizontalOffset();

				// loop for inter process process flow
				for ($m=0;$m<=$block_information_elements_count;$m++) {

				if ( $this->outputType == 'N' ) {
								$start_block_information_arr 		= $block_information_arr[$m];
								$end_block_information_arr 			= $block_information_arr[$m];

								//echo $start_block_information_arr." - ".$end_block_information_arr."<br/>";

								$block_record_start_granules  		= explode(':',$start_block_information_arr);
								$block_record_end_granules  		= explode(':',$end_block_information_arr);

								if ( $block_record_end_granules[5] == 'IN' || $block_record_end_granules[5] == 'OUT' || $block_record_end_granules[5] == 'EXIN' || $block_record_end_granules[5] == 'EXOUT' ) {

									$start_context_code 				= chr($this->maxDepth - 1 + 64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];
									$end_context_code 					= $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

													/*dump_array($start_context_code);
													dump_array($end_context_code);
													echo "-----------------<br/>";*/

									$alt_node_type = $block_record_end_granules[5].'PROCESS';

									$main_path = false;
									$alt_path = true;
									$lozenge = 'NA';

									if ( $block_record_start_granules[6] == $this->pfObject->getCurrentProcessFlow() && $block_record_start_granules[5] == 'OUT' ) {
										//ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									} else {
										//ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									}
								}

								if ( $block_record_end_granules[5] == 'EXIN' || $block_record_end_granules[5] == 'EXOUT' ) {

									$start_context_code = chr($this->maxDepth - 1 + 64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];
									$end_context_code 	= $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

									$alt_node_type = $block_record_end_granules[5].'PROCESS';

									$main_path = false;
									$alt_path = true;
									$lozenge = 'NA';

									if ( $block_record_start_granules[6] == $this->pfObject->getCurrentProcessFlow() && $block_record_start_granules[5] == 'EXOUT' ) {
										ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									} else {
										ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									}
								}
				}

						if ( $block_information_arr[$m] != '' ) {
							$crosspaths[] 		= $block_information_arr[$m].":".$y_offset;
						}

					} // end for loop


					// loop for intraprocess inter path

					/*for ($m=0;$m<=$block_information_elements_count;$m++) {

						if ( $block_information_arr[$m] != '' ) {
							$crosspaths[] 		= $block_information_arr[$m];
						}

					}*/ // end for loop


				} // end if

				// standalone start and end block
				if (1 && $this->outputType == 'N' ) {
					$alt_node_type = 'START';

					$start_block_information_arr 	= $block_information_arr[0];
					$end_block_information_arr 		= $block_information_arr[1];

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$end_block_information_arr		= $start_block_information_arr;
					$start_block_information_arr	= $this->getMainPathNodeData($block_record_start_granules[4]);

					$block_record_start_granules  	= explode(':',$start_block_information_arr);
					$block_record_end_granules  	= explode(':',$end_block_information_arr);

					$start_context_level = $block_record_start_granules[0];
					$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2];

					$end_context_level = $block_record_end_granules[0];
					$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2];

					$main_path = false;
					$alt_path = true;
					$lozenge = 'NA';

					ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					if ( $block_record_start_granules[2] || $block_record_end_granules[2] ) {

						$alt_node_type = 'END';

						$start_block_information_arr 	= $block_information_arr[1];
						$end_block_information_arr 		= $block_information_arr[0];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);

						$end_block_information_arr		= $this->getMainPathNodeData($block_record_start_granules[4]);

						// for mid air stop
						if ( $block_record_start_granules[4] ) {

							$block_record_start_granules  	= explode(':',$start_block_information_arr);
							$block_record_end_granules  	= explode(':',$end_block_information_arr);

							$start_context_level = $block_record_start_granules[0];
							$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

							$end_context_level = $block_record_end_granules[0];
							$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';

							///commented by davinder on 2011/02/05
							////ProcessObject::DrawCrossPath($alt_node_type,$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);
						}


					}

				}

				// support path blocks
				if (1) { // && $this->outputType == 'N' ) {

					for ($m=0;$m<$block_support_information_elements_count;$m++) {

						$block_support_start_end_information_arr 	= explode('=>',$block_support_information_arr[$m]);

						$start_block_information_arr 	= $block_support_start_end_information_arr[0];
						$end_block_information_arr 		= $block_support_start_end_information_arr[1];

						$block_record_start_granules  	= explode(':',$start_block_information_arr);
						$block_record_end_granules  	= explode(':',$end_block_information_arr);

						$start_context_level = $block_record_start_granules[0];
						$start_context_code	= $start_context_level.':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];

						$end_context_level = $block_record_end_granules[0];
						$end_context_code	= $end_context_level.':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

						if ( $block_record_start_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						if ( $block_record_end_granules[2] == 0 ) {
							$main_path = true;
							$alt_path = false;
							$lozenge = 'NA';
						} else {
							$main_path = false;
							$alt_path = true;
							$lozenge = 'NA';
						}

						ProcessObject::DrawSupportPath('DECISION',$this,$start_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge);

					} // end for loop
				} // end if block

			} // end outer foreach

			//dump_array($crosspaths);

			$crosspaths_count = count($crosspaths);
			$processed_crosspaths = array();

			if ( $crosspaths_count ) {

				foreach ( $crosspaths as $crosspath_ele ) {
					foreach ( $crosspaths as $crosspath_ele_two ) {

						$main_path = false;
						$alt_path = true;
						$lozenge = 'NA';

						if ( $crosspath_ele != $crosspath_ele_two && !in_array(($crosspath_ele.$crosspath_ele_two),$processed_crosspaths) && !in_array(($crosspath_ele_two.$crosspath_ele),$processed_crosspaths) ) {

							$processed_crosspaths[] = $crosspath_ele.$crosspath_ele_two;

							$block_record_start_granules	= explode(":",$crosspath_ele);
							$block_record_end_granules		= explode(":",$crosspath_ele_two);

							$alt_node_type = $block_record_end_granules[5].'PROCESS';

							/*if ( $block_record_end_granules[5] == 'IN' ) {
								$y_offset = 0;
							} else {*/

							/*}*/

							if ( $block_record_start_granules[7] == $block_record_end_granules[3] ) {

								$y_offset = $this->availableHorizontalOffset();

								$alt_node_type1 = $block_record_start_granules[5].'PROCESS';
								$alt_node_type2 = $block_record_end_granules[5].'PROCESS';

								/*echo "alt_node_type1 ".$alt_node_type1." -> ";
								echo "alt_node_type2 ".$alt_node_type2;
								echo "<br/>";*/

								$main_path = false;
								$alt_path = true;
								$lozenge = 'NA';

								$start_context_code	= $block_record_start_granules[0].':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];
								$end_context_code =	 $block_record_end_granules[0].':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];
								$bottom_start_context_code = chr($this->maxDepth-1+64).':'.$block_record_start_granules[1].':'.$block_record_start_granules[2].':'.$block_record_start_granules[6];
								$bottom_end_context_code = chr($this->maxDepth-1+64).':'.$block_record_end_granules[1].':'.$block_record_end_granules[2].':'.$block_record_end_granules[6];

								//echo $alt_node_type1.'-'.$alt_node_type2."<br/>";

								if ( ($alt_node_type1 == 'INPROCESS' && $alt_node_type2 == 'OUTPROCESS') || ($alt_node_type2 == 'INPROCESS' && $alt_node_type1 == 'OUTPROCESS') ) {
									ProcessObject::DrawCrossPath($alt_node_type1,$this,$bottom_start_context_code,$start_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
									ProcessObject::DrawCrossPath($alt_node_type2,$this,$bottom_end_context_code,$end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$lozenge,$y_offset);
								}

								ProcessObject::DrawHorizontalPath($alt_node_type2,$this,$bottom_start_context_code,$bottom_end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$y_offset);

//								ProcessObject::DrawHorizontalPath($alt_node_type1,$this,$bottom_start_context_code,$bottom_end_context_code,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$y_offset);

								/*$str = $crosspath_ele.' - '.$crosspath_ele_two;
								if ( !isset($_SESSION['a']) ) {
									$_SESSION['a'] = 50;
								}

								$_SESSION['a'] = $_SESSION['a'] + 10;
								imagestring($this->img, 2, 5, $_SESSION['a'],$str,$this->colours['text_colour']);*/

								//echo "<br/>";
							}
						}
					}
				}
			}
		} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
	}

	public function showImage() {

        // execute this block if debugMode is disabled.
		if (!$this->debugMode) {

			// if resampling is enabled.
			if ( $this->resample ) {

				// Get new dimensions
				$new_width 	= $this->canvasWidth * $this->resamplePercent;
				$new_height = $this->canvasHeight * $this->resamplePercent;


				// if resampling is enabled.
				$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
					or die('Cannot Initialize new GD image stream');

				imagecopyresampled($this->imgResampled, $this->img, 0, 0, 0, 0, $new_width, $new_height, $this->canvasWidth, $this->canvasHeight);

				// Output
				imagepng($this->imgResampled);

			} else {
                if ( $this->outputType == 'H' ) {
					$this->drawHeader();
					$this->drawfooter();
				}

				imagepng($this->img);
			}
		}
	}

	public function showImagepdf() {

        // execute this block if debugMode is disabled.
		if (!$this->debugMode) {

			// if resampling is enabled.
			if ( $this->resample ) {

				// Get new dimensions
				$new_width 	= $this->canvasWidth * $this->resamplePercent;
				$new_height = $this->canvasHeight * $this->resamplePercent;


				// if resampling is enabled.
				$this->imgResampled = @imagecreatetruecolor($new_width,$new_height)
					or die('Cannot Initialize new GD image stream');

				imagecopyresampled($this->imgResampled, $this->img, 0, 0, 0, 0, $new_width, $new_height, $this->canvasWidth, $this->canvasHeight);

				// Output
				imagepng($this->imgResampled);

			} else {
                if ( $this->outputType == 'H' ) {
					$this->drawHeaderpdf();
					}

				imagepng($this->img);
			}
		}
	}
	public function saveImage() {

		$process_details = $this->pfObject->getCurrentProcessFlowInformation();
		$this->outputFile = "process_flow_horizontal_".$process_details['swimID'].".png";
		$output_file_path = realpath("../private_files/process_flow")."/".$this->outputFile;

		// if resampling is enabled.
		if (!$this->debugMode) {

			if ( function_exists(imagepng) ) {
				if ( file_exists($output_file_path) ) {
					unlink($output_file_path);
				}
				//
				//imagepng($this->img);
				imagepng($this->img,$output_file_path);
			}

		}
	}

public function savehdrImage($img) {

		$process_details = $this->pfObject->getCurrentProcessFlowInformation();
		$this->outputFile = "process_flow_horizontal_".$process_details['swimID']."hdr.png";
		$output_file_path = realpath("../private_files/process_flow")."/".$this->outputFile;



		
				if ( file_exists($output_file_path) ) {
					unlink($output_file_path);
				}

				imagepng($img,$output_file_path);
		

		}
		
	public function getSavedImageName() {
		return $this->outputFile;
	}

	public function __destruct() {

		if (!$this->debugMode) {
			imagedestroy($this->img);
		}
	}

	public function __call($name,$arguments) {

		$propertyname = strtolower(substr($name,3,1)).substr($name,4);

		return $this->$propertyname;
	}

	public function getColour($p_code) {
		return $this->colours[$p_code];
	}

	public function getOutType() {
		return $this->outputType;
	}
	public function getResource() {
		return $this->img;
	}

	public function getPathcolour($p_pathno) {

		$p_pathno = (int) $p_pathno;

		if (!$p_pathno) {
			return $this->colours['main_path_colour'];
		} else {
			return $this->colours['alt'.$p_pathno.'_path_colour'];
		}
	}

	public function getMainPathNodeData($node) {

		if ( $node < 1 ) {
			$node = 1;
		}

		$block_information_arr 		= explode('~#~',$this->block_information[0]['path_information']);
		$block_step_information 	= $block_information_ele['step_information'];

		return $block_information_arr[$node-1];
	}


	
	
	public function saveNodeCoordinates($p_step_no,$p_coordinates) {
		$this->pfObject->saveNodeCoordinates($p_step_no,$p_coordinates);
	}

	public function saveProcessInOutCoordinates($p_step_no,$p_coordinates) {
		$this->pfObject->saveProcessInOutCoordinates($p_step_no,$p_coordinates);
	}

	public function getSbpRef($p_sub) {
	$subarray=$this->pfObject->displayProcessFlowById($p_sub);
	return $subarray["reference"];
	}

	public function getccps($p_sub) {
	$subarray=$this->pfObject->checkChildCcps($p_sub,1);
	return $subarray;
	}

	public function availableHorizontalOffset() {

		$k = 0;

		foreach ( $this->horizontalOffsetPool as $offset_ele ) {

			if ( !$offset_ele['used'] ) {
				$this->horizontalOffsetPool[$k]['used'] = 1;
				return $offset_ele['offset'];
			}

			$k++;
		}
	}
	
	
		public function getMainPathNodeDatabyLevel($level) {
//picks first level in code
		if ( $level < 1 ) {
			$level = 1;
		}


		$block_information_arr 		= explode('~#~',$this->block_information[0]['path_information']);
		
		foreach ( $block_information_arr as $nodes_ele ) {
					$nodes_arr = explode(':',$nodes_ele);

if ($nodes_arr[1] == $level)	
{
return 	$nodes_arr;
}
		}
		
		return $nodes_arr;
	}
	
	
	public function getoffset($level,$type){
	if ($level%2 == 1)
	{
	if ($type=='S')
	return ($level+1)/2; //support goes to bottom
	else
	return ($level+1)/-2;
	}
	else
	return $level/2;
	}


public function drawPaths() {
try {
//start
$start_pos[x]=0;

			
			$block_step_information	= $this->block_information[0]['step_information'];
			foreach ($block_step_information as $step_ele ) {
			if ($step_ele[type] == 'D')
				$offset=10;
				else
				$offset=0;

			
			if ($start_pos[x]==0)	
			{
			if ( $this->outputType == 'H' )  
			$start_pos[x]=$this->businessUnitColumnWidth-20;
			else
			$start_pos[x]=$this->businessUnitColumnWidth+20;
			$end_pos[x]=$this->businessUnitColumnWidth+(($this->blockWidth-$this->objectWidth)/2)-$offset;
			$start_pos[y]=3+$this->blocks_data[A][height]*$this->blockHeight/2 ;
			$end_pos[y]=$start_pos[y];
			ProcessObject::DrawPath('DECISION',$this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$step_ele[type]);	
			

			if ($step_ele['interProcess'] >0)
			{
			$start_posext=$end_pos;
			$start_posext[x]+=50;
			$start_posext[y]+=$this->objectHeight/2;
			$end_posext=$start_posext;
			$end_posext[y]=($this->maxDepth-1)*$this->blockHeight;

			ProcessObject::DrawExternalPath($this,$start_posext,$end_posext,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$step_ele['interProcess']);
			}
			}
		else
			{
			 
			$search_business_unit = $step_ele['buName'].'|'.$step_ele['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);

			if ($step_ele[type] =='S')
{						
			$start_possupport=$end_pos;
			$start_possupport[x]+=12;
			$start_possupport[y]+=($this->objectHeight/2);
			$end_possupport=$start_possupport;

			$pos=$this->getStepPos($depth,$step_ele['stepLevel'],$step_ele['ID']);
			$levels=explode("|",$pos);
			$level=$this->getoffset($levels[1],'S');
			
			$end_possupport[y]=($this->blocks_data[$depth][count])*$this->blockHeight;
			$end_possupport[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$end_possupport[y]+=$level*$this->blockHeight ;
		
			ProcessObject::DrawSupportPath('DECISION',$this,$start_possupport,$end_possupport,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$step_ele[type]);	
			}	
			else
			{						
			$start_pos=$end_pos;
			$start_pos[x]+=$this->objectWidth;
			$end_pos[x]+=$this->blockWidth-$offset;
			$end_pos[y]=3+$this->blocks_data[$depth][count]*$this->blockHeight+$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			ProcessObject::DrawPath('DECISION',$this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$step_ele[type]);	

			if ($step_ele['interProcess'] >0)
			{
			$start_posext=$end_pos;
			$start_posext[x]+=50;
			$start_posext[y]+=$this->objectHeight/2;
			$end_posext=$start_posext;
			$end_posext[y]=($this->maxDepth-1)*$this->blockHeight;

			ProcessObject::DrawExternalPath($this,$start_posext,$end_posext,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$step_ele['interProcess']);
			}

			}

	
}
		
$end_pos[x]+=$offset;
	
}
//to stop	
$end_pos[x]+=$offset;
			$start_pos=$end_pos;
			$start_pos[x]+=$this->objectWidth;
			if ( $this->outputType == 'H' ) 
			$end_pos[x]+=$this->blockWidth+20-$offset;
			else
			$end_pos[x]+=$this->blockWidth-$offset;
			ProcessObject::DrawPath('DECISION',$this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$alt_path,$step_ele[type]);
			
$stop=$end_pos;
$this->endpos=$stop;			
//altpaths?????		count of altpaths

for ($x=1;$x<count($this->block_information);$x++)
{	
 	$start_pos[x]=0;	
$direction=1;//left-right;
$p_y_offset = $this->availableHorizontalOffset();	
	$block_step_information	= $this->block_information[$x]['step_information'];	


	
		
				foreach ($block_step_information as $step_ele ) {
	
				if ($start_pos[x]==0)	
			{
			 if ($step_ele[startAltPath] ==0)
			 {
			
			 $start_ele=$this->pfObject->getstartAltPath($step_ele[swimID],$x,$step_ele[ID]);
			 }
			 else
			 $start_ele=$this->pfObject->getStepInformation($step_ele[swimID],$step_ele[startAltPath]);

			$search_business_unit = $start_ele['buName'].'|'.$start_ele['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);



			$pos=$this->getStepPos($depth,0,$start_ele['ID']);
			$levels=explode("|",$pos);
			$level_new=$this->getoffset($levels[1],$start_ele[type]);
			

			
			$start_pos[y]=3+($this->blocks_data[$depth][count])*$this->blockHeight;
			$start_pos[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$start_pos[y]+=$level_new*$this->blockHeight ;
			$start_pos[x]=$this->businessUnitColumnWidth+($this->blockWidth*$levels[0])-$this->blockWidth*0.5;

					
			$search_business_unit = $step_ele['buName'].'|'.$step_ele['buID'];
			$depth1 = array_search(ucfirst($search_business_unit),$this->business_units);

			$direction=$this->getAltPathDirection($depth1,$step_ele[ID]) ;
			
				if ($step_ele[type] == 'D' && $direction==1)
				$offset=-10;
				elseif ($step_ele[type] == 'D' )
				$offset=10;
				else
				$offset=0;


			$pos1=$this->getStepPos($depth1,0,$step_ele['ID']);
			$levels1=explode("|",$pos1);
			$level_new1=$this->getoffset($levels1[1],$step_ele[type])	;		
			
			$end_pos[y]=($this->blocks_data[$depth1][count])*$this->blockHeight;
			$end_pos[y]+=$this->blocks_data[$depth1][height]*$this->blockHeight/2 ;
			$end_pos[y]+=$level_new1*$this->blockHeight+3; 
			$end_pos[x]=$this->businessUnitColumnWidth+($this->blockWidth*$levels1[0])-$this->blockWidth*0.5-($this->objectWidth*0.5)+$offset-2;
			$crossover=0;
			
			if ($direction==-1)
			{
							$end_pos[x]+=$this->objectWidth+9;
							
			//check for crossover at start	
if (count($block_step_information)>1)
{			
			$step_ele2=	next($block_step_information);
			prev($block_step_information);
			}
			else
			$step_ele2=$step_ele;
			
			
			$search_business_unit = $step_ele2['buName'].'|'.$step_ele2['buID'];
			$depth2 = array_search(ucfirst($search_business_unit),$this->business_units);

			$pos2=$this->getStepPos($depth2,0,$step_ele2['ID']);

			$levels2=explode("|",$pos2);
			$level_new2=$this->getoffset($levels2[1],$step_ele2[type])	;		
			$testpos=($this->blocks_data[$depth2][count])*$this->blockHeight;
			$testpos+=$this->blocks_data[$depth2][height]*$this->blockHeight/2 ;
			$testpos+=$level_new2*$this->blockHeight+3; 
		
if ($end_pos[y]<$start_pos[y] &&	$end_pos[y]<$testpos && $end_pos[x]>$start_pos[x])	
$crossover=-1;
if ($end_pos[y]>$start_pos[y] &&	$end_pos[y]>$testpos && $end_pos[x]>$start_pos[x])	
$crossover=1;	
			}	


			ProcessObject::DrawStartAltPath($this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$x,$step_ele[type],$p_y_offset,$direction,$crossover);	
			$end_pos[x]-=$offset;
			}
		else
			{
	
	
	
			if ($step_ele[type] == 'D')
				$offset=10;
				else
				$offset=0;
			
			$search_business_unit = $step_ele['buName'].'|'.$step_ele['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);

			if ($step_ele[type] =='S')
{						
			$start_possupport=$end_pos;
			$start_possupport[x]+=12;
			$start_possupport[y]+=($this->objectHeight/2);
			$end_possupport=$start_possupport;
			
			$pos=$this->getStepPos($depth,$step_ele['stepLevel'],$step_ele['ID']);
			$levels=explode("|",$pos);
			$level=$this->getoffset($levels[1],'S');
			
			$end_possupport[y]=($this->blocks_data[$depth][count])*$this->blockHeight;
			$end_possupport[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$end_possupport[y]+=$level*$this->blockHeight ;
		
		
			ProcessObject::DrawSupportPath('DECISION',$this,$start_possupport,$end_possupport,$this->objectWidth,$this->objectHeight,$main_path,$x,$step_ele[type]);	
			}	
			else
			{						
			$start_pos=$end_pos;

			$start_pos[x]+=($this->objectWidth*$direction);

			$pos=$this->getStepPos($depth,0,$step_ele['ID']);
			$levels=explode("|",$pos);

			$level=$this->getoffset($levels[1],$step_ele['type']);

			$end_pos[x]+=($this->blockWidth-$offset)*$direction;
			
			$end_pos[y]=3+$this->blocks_data[$depth][count]*$this->blockHeight+$this->blocks_data[$depth][height]*$this->blockHeight/2 +$level*$this->blockHeight ;


			ProcessObject::DrawAltPath($this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$x,$step_ele[type],$p_y_offset,$direction);	




			}
		
		}		
	}	

if($step_ele[endLozenge]==1)
{
$start_pos=$end_pos;
$start_pos[x]+=$this->objectWidth;
$end_pos=$stop;
ProcessObject::DrawAltStop($this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$x,$step_ele[type],$p_y_offset);
}


if($step_ele[endAltPath]>0)
{
$start_pos=$end_pos;
$start_pos[x]+=($this->objectWidth*$direction);

 $stop_ele=$this->pfObject->getStepInformation($step_ele[swimID],$step_ele[endAltPath]);

			$search_business_unit = $stop_ele['buName'].'|'.$stop_ele['buID'];
			$depth = array_search(ucfirst($search_business_unit),$this->business_units);
			
	
			$pos=$this->getStepPos($depth,0,$stop_ele['ID']);
			$levels=explode("|",$pos);
			$level_new=$this->getoffset($levels[1],$stop_ele[type]);
			
		
			$end_pos[y]=($this->blocks_data[$depth][count])*$this->blockHeight;
			$end_pos[y]+=$this->blocks_data[$depth][height]*$this->blockHeight/2 ;
			$end_pos[y]+=$level_new*$this->blockHeight ;
			$end_pos[x]=$this->businessUnitColumnWidth+($this->blockWidth*$levels[0])-$this->blockWidth*0.5;		
				if ( $this->outputType == 'H' and  $end_pos[y]<$start_pos[y]) 
				$end_pos[y]+=20;


ProcessObject::DrawAltEnd($this,$start_pos,$end_pos,$this->objectWidth,$this->objectHeight,$main_path,$x,$step_ele[type],$p_y_offset,$direction);
}

				
}


} catch( ErrorException $e ) {
			imagestring($this->img, 20, 20, 205,$e->getMessage(),$this->colours['text_colour']);
		}
}


public function getStepPos($block,$level=0,$id) {


 if ($level==0)
 {
foreach($this->blocks_data[$block][level] as $level=>$levelval)

{
foreach($levelval as $stepdata=>$stepval)
 {

$step=explode("|",$stepval);
if ($step[0]==$id)
return $level."|".$stepdata;
}
}	
}
else
{
foreach($this->blocks_data[$block][level][$level] as $stepdata=>$stepval)
 {
  
$step=explode("|",$stepval);
if ($step[0]==$id)
return $level."|".$stepdata;
}
}
}

public function getAltPathDirection($block,$id) {

foreach($this->blocks_data[$block][level] as $level=>$levelval)

{
foreach($levelval as $stepdata=>$stepval)
 {
$step=explode("|",$stepval);
if ($step[0]==$id)
return $step[6];
}
}	
}
public function getendpos()
{
	return $this->endpos;
}
}
?>