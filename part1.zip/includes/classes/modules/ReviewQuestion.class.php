<?php

/**
  $Id: ReviewQuestion.class.php,v 6.67 Monday, January 31, 2011 4:29:06 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Review object used to manage operation related to review
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Classes
 * @since  Monday, September 13, 2010 5:30:32 PM>
 */
class ReviewQuestion {
    /*
     * Object container for PDO Database resource class
     * @access private
     */

    private $dbHand;
    private $dbHand2;
    private $dbHand3;

    /*
     * This property will hold the value of ID of review under process.
     * @access private
     */
    private $reviewID;
    private $recordID;
    private $request_for;
    private $question_index;
    private $question_identifier;
    private $question_recommendation;
    private $question_answer;
    private $standards_query_string;

    public function __construct() {

      
$this->dbHand 			= DB::connect(_DB_TYPE);
        $this->dbHand2 = DB::connect(_DB_TYPE);
        $this->dbHand3 = DB::connect(_DB_TYPE);

        $this->reviewID = Session::getSessionField('review_id');
    }

    public function goToQuestion() {
        
    }

    public function loadQuestion() {
        
    }

    public function getQuestionList() {

        $sql = sprintf("SELECT questions
				FROM %s.review_master
				WHERE reviewID = %d", _DB_OBJ_FULL, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        $questions = explode(',', $rec['questions']);
        $questionsCount = count($questions);

        $questionList = array();

        for ($i = 0; $i < $questionsCount; $i++) {
            $k = $i + 1;
            $questionList[$k] = $questions[$i];
        } // end for

        return $questionList;
    }

    public function getCL($std, $ques) {
        $this->std = $std;
        $this->ques = $ques;
        $sql = sprintf("SELECT * FROM %s.review_question_metadata
				WHERE standardID = " . $this->std . " AND questionID =" . $this->ques, _DB_OBJ_FULL);


        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$this->reviewID);

        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        return $rec;
    }

    public function setQuestionInfo($p_questionIndex, $p_questionIdentifier, $p_questionRecommendation, $p_standardsQueryString) {

        $this->question_index = (int) strip_tags($p_questionIndex);
        $this->question_identifier = (int) strip_tags($p_questionIdentifier);
        $this->question_recommendation = addslashes(strip_tags($p_questionRecommendation));
        $standards_query_string = strip_tags($p_standardsQueryString);
        //die($p_questionRecommendation);
        $standards_query_string_arr = explode('|', $standards_query_string);

        if (count($standards_query_string_arr)) {
            foreach ($standards_query_string_arr as $standards_query_string_ele) {

                list($key, $value) = explode(':', $standards_query_string_ele);

                $this->standards_query_string[$key] = $value;
            }
        }
    }

    public function setActionInfoMse($question_index, $question_identifier, $data) {
        $this->question_index = (int) $question_index;
        $this->question_identifier = (int) $question_identifier;
        $this->action_data = $data;
    }

    public function setQuestionInfoMse($p_questionIndex, $p_questionIdentifier, $p_questionReason, $p_answer,$fileref) {

        $this->question_index = (int) strip_tags($p_questionIndex);
        $this->question_identifier = (int) strip_tags($p_questionIdentifier);
        $this->question_reason = addslashes(strip_tags($p_questionReason));
        $this->question_answer = (int) strip_tags($p_answer);
        $this->fileref = (int) $fileref;
    }

    public function getQuestionInfo($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT * FROM %s.review_questions
				WHERE ID = %d", _DB_OBJ_FULL, $p_questionIdentifier);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$p_questionIdentifier);
        $stmt->execute();

        $sql = sprintf("SELECT standardID,code FROM %s.review_question_metadata
				WHERE questionID = %d", _DB_OBJ_FULL, $p_questionIdentifier);

        $stmt_sec = $this->dbHand2->prepare($sql);
        //$stmt_sec->bindParam(1,$p_questionIdentifier);
        $stmt_sec->execute();

        $std_arr = array();

        while ($rec = $stmt_sec->fetch(PDO::FETCH_ASSOC)) {

            $code = $rec['code'];

            $code_stats = $this->getStandardCodeDescription($rec['standardID'], $code);

            $code_title = ucfirst($code_stats['title']);
            $code_description = ucfirst($code_stats['description']);

            /* hardcoding done to avoid extra query to database. */
            if ($rec['standardID'] == 52) {
                $std_arr['section_heading52'] = $code_stats['title']; //$this->getMsrCodeHeading($std_arr['section_heading_code']);
            }

            if ($rec['standardID'] == 7) {
                $std_arr['section_heading_code'] = substr($code, 0, 1);
                $std_arr['section_heading'] = $code_stats['description']; //$this->getMsrCodeHeading($std_arr['section_heading_code']);
            }

            if ($code_description == "") {
                $std_arr['standard_' . $rec['standardID']] = 'Not Available';
            } else {
                $std_arr['standard_' . $rec['standardID']] = str_replace("\\r\\n", "<br/>", $code_description);
                $std_arr['standard_' . $rec['standardID']] = str_replace("\\n", "<br/>", $std_arr['standard_' . $rec['standardID']]);
            }
        }

        return array_merge($stmt->fetch(PDO::FETCH_ASSOC), $std_arr);
    }

    public function getAnswerInfo($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = %d AND questionID = %d", _DB_OBJ_FULL, $this->reviewID, $p_questionIdentifier);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);

        return $rec;
    }

    public function getQuestionInfoMse($p_questionIdentifier, $p_questionIndex) {

        $p_questionIdentifier = (int) $p_questionIdentifier;
        $p_questionIndex = (int) $p_questionIndex;

        $sql = sprintf("SELECT * FROM %s.review_questions_mse
				WHERE ID = %d", _DB_OBJ_FULL, $p_questionIdentifier);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$p_questionIdentifier);
        $stmt->execute();

        $main_data = $stmt->fetch(PDO::FETCH_ASSOC);

        //      $sql = sprintf("select mainCategory from %s.management_element_parent_cats C inner join %s.management_elements E on c.catID=E.mainCatID where eid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $main_data['eid']);
        $sql = sprintf("select E.*,D1.name as subsection,D1.code as subsectioncode,D2.name as section from %s.management_elements E inner join %s.msr_departments D1 on E.mainCatID=D1.id left join %s.msr_departments D2 on D1.pid=D2.id where E.eid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $main_data['eid']);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $sec_data = $stmt->fetch(PDO::FETCH_ASSOC);
        $headings = array('section_heading' => $sec_data['section'], 'sub_section_heading' => $sec_data['subsectioncode'].' - '.$sec_data['subsection'], 'extracodes' => $sec_data['extracodes']);
        return array_merge($main_data, $headings);
    }

        public function getQuestionInfoICR($p_questionIdentifier, $p_questionIndex) {

        $p_questionIdentifier = (int) $p_questionIdentifier;
        $p_questionIndex = (int) $p_questionIndex;

        $sql = sprintf("SELECT * FROM %s.review_questions_mse
				WHERE ID = %d", _DB_OBJ_FULL, $p_questionIdentifier);

        $stmt = $this->dbHand->prepare($sql);
        //$stmt->bindParam(1,$p_questionIdentifier);
        $stmt->execute();

        $main_data = $stmt->fetch(PDO::FETCH_ASSOC);

        //      $sql = sprintf("select mainCategory from %s.management_element_parent_cats C inner join %s.management_elements E on c.catID=E.mainCatID where eid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $main_data['eid']);
        $sql = sprintf("select E.*,D1.name as subsection,D1.code as subsectioncode,D2.name as section from %s.management_elements E inner join %s.msr_departments D1 on E.mainCatID=D1.id left join %s.msr_departments D2 on D1.pid=D2.id where E.eid=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $main_data['eid']);
        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();
        $sec_data = $stmt->fetch(PDO::FETCH_ASSOC);
        $headings = array('section_heading' => $sec_data['section'], 'sub_section_heading' => $sec_data['subsectioncode'].' - '.$sec_data['subsection'], 'extracodes' => $sec_data['extracodes']);
        return array_merge($main_data, $headings);
    }
    
    private function getStandardCodeDescription($p_stdId, $p_code) {

        if ($p_stdId == 52) {
            $p_code = substr($p_code, 0, 1);
        }
        if ($p_stdId == 7) {
            $p_code = substr($p_code, 0, 1);
        }
        $sql = sprintf("SELECT name as title,description FROM %s.msr_departments
				WHERE sID = '%s' AND code = '%s'", _DB_OBJ_FULL, $p_stdId, $p_code);
        //echo $sql."<br/>";

        $stmt_sec = $this->dbHand3->prepare($sql);
        //$stmt_sec->bindParam(1,$p_code);
        $stmt_sec->execute();

        return $stmt_sec->fetch(PDO::FETCH_ASSOC);
    }

    private function getMsrCodeHeading($p_code) {

        $sql = sprintf("SELECT description FROM %s.msr_departments
				WHERE SUBSTRING(code,1,1) = ?", _DB_OBJ_FULL, $p_code);

        $stmt_sec = $this->dbHand->prepare($sql);
        //$stmt_sec->bindParam(1,$p_code);
        $stmt_sec->execute();

        $rec = $stmt_sec->fetch(PDO::FETCH_ASSOC);

        return $rec['description'];
    }

    public function setReviewID($p_review_id) {
        $this->reviewID = $p_review_id;
    }

    public function getQuestionAnswerInfo($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT questionID,answer,recommendation,standardID,fullname FROM %s.review_answers R INNER JOIN %s.quality_standards Q
				ON Q.sID = R.standardID WHERE questionID = %d AND reviewID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_questionIdentifier, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();

        $result_string = '';

        while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

            if ($result['standardID'] == 52) {
                $recomm_string = "recomm:" . str_replace(':', ' ', $result['recommendation']);
            }


            $result_string .= "#";
            $result_string .= str_replace(' ', '_', strtolower($result['fullname'])) . ":" . $result['answer'];
        }

        $final_string = $recomm_string . $result_string;

        return $final_string;
    }

    public function getQuestionAnswerInfoNew($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT questionID,answer,recommendation,reason,msr_reason,standardID,fullname FROM %s.review_answers R INNER JOIN %s.quality_standards Q
				ON Q.sID = R.standardID WHERE questionID = %d AND reviewID = %d", _DB_OBJ_FULL, _DB_OBJ_FULL, $p_questionIdentifier, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();

        $result_string = '';

        while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

            if ($result['standardID'] == 52) {
                $results['recomm'] = $result['recommendation'];
                $results['reason'] = $result['reason'];
                $results['msr_reason'] = $result['msr_reason'];
            }
            $results[$result['standardID']] = $result['answer'];
        }



        return $results;
    }

    public function getQuestionAnswerInfoMse($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT questionID,answer,recommendation,reason,standardID,ID FROM %s.review_answers
					   WHERE questionID = %d AND reviewID = %d", _DB_OBJ_FULL, $p_questionIdentifier, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getQuestionAnswerInfoICR($p_questionIdentifier) {

        $p_questionIdentifier = (int) $p_questionIdentifier;

        $sql = sprintf("SELECT questionID,answer,recommendation,reason,standardID,ID FROM %s.review_answers
					   WHERE questionID = %d AND reviewID = %d", _DB_OBJ_FULL, $p_questionIdentifier, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
        /* $stmt->bindParam(1,$p_questionIdentifier);
          $stmt->bindParam(2,$this->reviewID); */
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    
    private function getStandardId($ele_key) {

        $ele_key = str_replace('_', ' ', $ele_key);

        $sql = sprintf("SELECT sID FROM %s.quality_standards WHERE fullname = '" . strtoupper($ele_key) . "' ", _DB_OBJ_FULL);

        $stmt = $this->dbHand->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result['sID'];
    }

    public function saveQuestionAnswer($reason = '', $msr_reason = 0) {
        $this->reason = $reason;
        $this->msr_reason = $msr_reason;

        if (count($this->standards_query_string)) {

            //   dump_array($this->standards_query_string)	;

            foreach ($this->standards_query_string as $ele_key => $ele_val) {


                //$already_exists = false;

                if ($ele_val == '') {
                    //	 $ele_val=$this->standards_query_string['msr']; sets all buttons whether clicked or not
                    continue;
                }

                $stdID = $this->getStandardId($ele_key);

                $sql = sprintf("SELECT * FROM %s.review_answers
						WHERE reviewID = " . $this->reviewID . "
						AND questionID = " . $this->question_identifier . "
						AND standardID = " . $stdID, _DB_OBJ_FULL);
                $stmt = $this->dbHand->prepare($sql);

                $stmt->execute();

                $already_exists = $stmt->fetchAll(PDO::FETCH_ASSOC);

                //dump_array($already_exists);


                if ($already_exists) {

                    $sql = sprintf("UPDATE %s.review_answers
							SET
								answer = '%s',
								recommendation = '%s',
								reason = '%s',
                                                                msr_reason = '%d'
							WHERE
								reviewID = %d
							AND
								questionID = %d
							AND
								standardID = %d"
                            , _DB_OBJ_FULL
                            , $ele_val
                            , $this->question_recommendation
                            , $this->reason
                            , $this->msr_reason
                            , $this->reviewID
                            , $this->question_identifier
                            , $stdID);

                    $stmt = $this->dbHand->prepare($sql);
                    $stmt->execute();
                } else {

                    //echo "dfgfdgfdg";
                   $sql11 = sprintf("INSERT INTO %s.review_answers (reviewID,questionID,answer,standardID,recommendation,reason,msr_reason)
						VALUES (%d, %d, '%s', %d, '%s','%s','%d')"
                            , _DB_OBJ_FULL
                            , $this->reviewID
                            , $this->question_identifier
                            , $ele_val
                            , $stdID
                            , $this->question_recommendation
                            , $this->reason
                            , $this->msr_reason);

                    $stmt = $this->dbHand->prepare($sql11);

                    $stmt->execute();
                }
            }
        }
        
    }

    public function saveQuestionAnswerNew($reason = '', $msr_reason = 0, $stdValues) {
        $this->reason = $reason;
        $this->msr_reason = $msr_reason;

        foreach ($stdValues as $ele_key => $ele_val) {

            $sql = sprintf("SELECT * FROM %s.review_answers
						WHERE reviewID = " . $this->reviewID . "
						AND questionID = " . $this->question_identifier . "
						AND standardID = " . $ele_key, _DB_OBJ_FULL);
            $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();

            $already_exists = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($already_exists) {

                $sql = sprintf("UPDATE %s.review_answers
							SET
								answer = '%s',
								recommendation = '%s',
								reason = '%s',
                                                                msr_reason = '%d'
							WHERE
								reviewID = %d
							AND
								questionID = %d
							AND
								standardID = %d"
                        , _DB_OBJ_FULL
                        , $ele_val
                        , $this->question_recommendation
                        , $this->reason
                        , $this->msr_reason
                        , $this->reviewID
                        , $this->question_identifier
                        , $ele_key);

                $stmt = $this->dbHand->prepare($sql);
                $stmt->execute();
            } else {


                $sql11 = sprintf("INSERT INTO %s.review_answers (reviewID,questionID,answer,standardID,recommendation,reason,msr_reason)
						VALUES (%d, %d, '%s', %d, '%s','%s','%d')"
                        , _DB_OBJ_FULL
                        , $this->reviewID
                        , $this->question_identifier
                        , $ele_val
                        , $ele_key
                        , $this->question_recommendation
                        , $this->reason
                        , $this->msr_reason);

                $stmt = $this->dbHand->prepare($sql11);

                $stmt->execute();
            }
        }
    }

    public function saveQuestionAnswerMse() {

        $stdID = 52; // acts as placeholder

        $already_exists = false;

      $sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = " . $this->reviewID . "
				AND questionID = " . $this->question_identifier . "
				AND standardID = " . $stdID, _DB_OBJ_FULL);

        if ($res = $this->dbHand->query($sql)) {

            $this->recordID=$res->fetchColumn(7);
            /* Check the number of rows that match the SELECT statement */
            if ($this->recordID > 0) {
                $already_exists = true;
                
            }
        }

        $res = null;

        if ($already_exists) {

         $sql = sprintf("UPDATE %s.review_answers
					SET
						answer = '%s',
						reason = '%s'
					WHERE
						reviewID = %d
					AND
						questionID = %d
					AND
						standardID = %d"
                    , _DB_OBJ_FULL
                    , $this->question_answer
                    , $this->question_reason
                    , $this->reviewID
                    , $this->question_identifier
                    , $stdID);

            $stmt = $this->dbHand->prepare($sql);

            $stmt->execute();
        } else {

            $sql = sprintf("INSERT INTO %s.review_answers (reviewID,questionID,answer,standardID,reason,recommendation)
					VALUES (%d, %d, '%s', %d, '%s','')"
                    , _DB_OBJ_FULL
                    , $this->reviewID
                    , $this->question_identifier
                    , $this->question_answer
                    , $stdID
                    , $this->question_reason);


            $stmt = $this->dbHand->prepare($sql);

            //if ( $this->question_answer != '' ) {
            $stmt->execute();
            $this->recordID = customLastInsertId($this->dbHand, 'review_answers', 'ID');
            //}
        }
 
        $this->moveFiles();
    }

    public function getAttemptedQuestionStats($p_reviewID = 0) {

        $standardID = 52;

        if ($this->reviewID) {
            $p_reviewID = $this->reviewID;
        }

        $sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = %d
				AND standardID = %d"
                , _DB_OBJ_FULL
                , $p_reviewID
                , $standardID);

        $stmt = $this->dbHand->prepare($sql);

        $stmt->execute();

        return count($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public function getSectionQuestionStats() {

        $sql = sprintf("SELECT count( * ) AS ROWS,SUBSTRING( M.code, 1, 1 ) FROM %s.review_questions Q
				INNER JOIN $s.review_question_metadata M ON Q.id = M.questionID
				WHERE M.standardID = 52
				GROUP BY SUBSTRING( M.code, 1, 1 )", _DB_OBJ_FULL, _DB_OBJ_FULL);
    }

    public function getAttemptedSectionQuestionStats($p_sectionHeadingCode) {

        /*
          SELECT ID,SUBSTRING(M.code,1,1) FROM `review_questions` Q INNER JOIN review_question_metadata M ON Q.id = M.questionID WHERE M.standardID = 52
         */

        $sql = sprintf("SELECT questions FROM %s.review_master
				WHERE reviewID = %d", _DB_OBJ_FULL, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->reviewID); */

        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        $allquestions = "'" . str_replace(",", "','", $rec['questions']) . "'";

        $standardID = 52;

        $sql = sprintf("SELECT * FROM %s.review_answers
				WHERE reviewID = %d
				AND standardID = %d"
                , _DB_OBJ_FULL
                , $this->reviewID
                , $standardID);

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->reviewID);
          $stmt->bindParam(2,$standardID); */

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $answered_questions = array();

        foreach ($result as $result_ele) {
            $answered_questions[] = $result_ele['questionID'];
        }

        if (count($answered_questions)) {
            $answered_questions_list = implode("','", $answered_questions);
            $answered_questions_list = "'" . $answered_questions_list . "'";
        }

       if ( _DB_TYPE != 'mysql' ) {
            $sql = sprintf("SELECT count(*) FROM %s.review_question_metadata
				WHERE questionID IN (%s)
				AND standardID = %d
				AND SUBSTRING(code,1,1) = '%s'"
                    , _DB_OBJ_FULL
                    , $answered_questions_list
                    , 7 //master reference MSR
                    , $p_sectionHeadingCode);
        } else {
            $sql = sprintf("SELECT count(*) FROM %s.review_question_metadata
				WHERE questionID IN (%s)
				AND standardID = %d
				AND substr(code,1,1) = '%s'"
                    , _DB_OBJ_FULL
                    , $answered_questions_list
                    , 7 //master reference MSR
                    , $p_sectionHeadingCode);
        }

        $stmt = $this->dbHand->prepare($sql);

        /* $stmt->bindParam(1,$this->reviewID);
          $stmt->bindParam(2,$standardID); */

        $stmt->execute();
        $count = $stmt->fetchColumn();
        return $count;
    }

    public function getStandardCodeDescriptionX($p_stdId) {

        if ($p_stdId == 52) {
            $p_code = substr($p_code, 0, 1);
        }

        $sql = sprintf("SELECT * FROM %s.msr_departments
				WHERE sID = '%s' ", _DB_OBJ_FULL, $p_stdId);
        //echo $sql."<br/>";

        $stmt_sec = $this->dbHand3->prepare($sql);
        //$stmt_sec->bindParam(1,$p_code);
        $stmt_sec->execute();

        return $stmt_sec->fetchAll(PDO::FETCH_ASSOC);
    }

    public function continueReview() {
        
    }

    public function getStandardDataforMSR($p_question, $reqStds) {

        $sql = sprintf("select M.standardID,M.code,M.code,D.name,Q.fullname,D.description from %s.quality_standards Q left join %s.review_question_metadata M on M.standardID=Q.sID left join %s.msr_departments D on (M.standardID=D.sid and M.code=D.code) where questionid=%d and Q.sID IN (%s) order by Q.[rank]", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $p_question, $reqStds);

        $stmt = $this->dbHand3->prepare($sql);
        $stmt->execute();
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($res as $data) {
            $result[$data["standardID"]] = $data;
            if ($data["description"] == '')
                $result[$data["standardID"]]["description"] = "Not Available";
            else
                $result[$data["standardID"]]["description"] = str_replace("\n", "<BR>", $data["description"]);
        }


        return $result;
    }

    public function saveICRAction() {

        $actObj = new Action();

        $action_data = array('module_name' => 'ICR_Action', 'description' => $this->action_data['msrac_action_val'],
            'who' => $this->action_data['msrac_who_val'], 'whoAU' => $this->action_data['msrac_whoAU_val'], 'who2AU' => $this->action_data['msrac_whoAU2_val'], 'due_date' => $this->action_data['msrac_when_val'], 'record' => $this->action_data['record'], 'element' => $this->action_data['element']);


        if ($this->action_data["id"] =='')
        {
                                $actObj->setActionDetails(0, $action_data);
         $action_id = $actObj->addAction2015();

        }
        else{
                  $actObj->setActionDetails($this->action_data["id"], $action_data);
            $action_id = $actObj->updateAction2015();
        }
    }

    public function getNewAnswerID() {
        return customLastInsertId($this->dbHand, "review_answers", "ID");
    }

    public function getActionInfoMse($p_ID) {
    $participantObj 	= 	SetupGeneric::useModule('Participant');
        $sql = sprintf("select * from %s.actions where record=%d and moduleelement='%s'", _DB_OBJ_FULL, $p_ID, "review_answers");
        $stmt = $this->dbHand3->prepare($sql);
        $stmt->execute();
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        $participantObj->setItemInfo(array('id'=>$res['who']));
        $display=$participantObj->displayItemById();
	$res["displaywho"]	=$display['forename']." ".$display['surname'] ;
        $participantObj->setItemInfo(array('id'=>$res['whoAU']));
        $display=$participantObj->displayItemById();
	$res["displaywhoAU"]	=$display['forename']." ".$display['surname'] ;
        $participantObj->setItemInfo(array('id'=>$res['addapprover']));
        $display=$participantObj->displayItemById();
	$res["displaywho2AU"]	=$display['forename']." ".$display['surname'] ;

        
        return $res;
    }
    
    public function getActionInfoICR($p_ID) {
    $participantObj 	= 	SetupGeneric::useModule('Participant');
      $sql = sprintf("select * from %s.actions where record=%d and moduleelement='%s'", _DB_OBJ_FULL, $p_ID, "review_answers");
        $stmt = $this->dbHand3->prepare($sql);
        $stmt->execute();
        $i=0;
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach($results as $res){
        $participantObj->setItemInfo(array('id'=>$res['who']));
        $display=$participantObj->displayItemById();
	$res1[$i]["displaywho"]	=$display['forename']." ".$display['surname'] ;
        $participantObj->setItemInfo(array('id'=>$res['whoAU']));
        $display=$participantObj->displayItemById();
	$res1[$i]["displaywhoAU"]	=$display['forename']." ".$display['surname'] ;
        $participantObj->setItemInfo(array('id'=>$res['addapprover']));
        $display=$participantObj->displayItemById();
	$res1[$i]["displaywho2AU"]	=$display['forename']." ".$display['surname'] ;
        $res1[$i]=$res;
        $res1[$i]["dueDate"] = $actionInfo['dueDate'] == '' ? '' : format_date($actionInfo['dueDate']);
        $i++;
    }
   
        return $res1;
    }
    
    public function  getMSEReportData($p_aid){
    $this->reviewID=$p_aid;
        $sql = sprintf("SELECT questions FROM %s.review_master
				WHERE reviewID = %d", _DB_OBJ_FULL, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
 
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        $questions = $rec['questions'];
        
     $sql = sprintf("select Q.*,D.code,D.name,A.answer,A.reason,A.ID from %s.review_questions_mse Q 
            inner join %s.management_elements E on Q.eid=E.eID 
            inner join %s.msr_departments D on E.mainCatID=D.ID 
            left join %s.review_answers A on (a.reviewid=%d and Q.ID=A.questionID) where  q.ID in (%s) order by D.code",
                _DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL, $this->reviewID,$questions);

             $stmt = $this->dbHand->prepare($sql);
 
        $stmt->execute();

        $recdata = $stmt->fetchAll(PDO::FETCH_ASSOC);
       
       return $recdata;
       

    }
    
     public function  getICRReportData($p_aid){
    $this->reviewID=$p_aid;
        $sql = sprintf("SELECT questions FROM %s.review_master
				WHERE reviewID = %d", _DB_OBJ_FULL, $this->reviewID);

        $stmt = $this->dbHand->prepare($sql);
 
        $stmt->execute();

        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
        $questions = $rec['questions'];
        
     $sql = sprintf("select Q.*,D.code,D.name,A.answer,A.reason,A.ID from %s.review_questions_mse Q 
            inner join %s.management_elements E on Q.eid=E.eID 
            inner join %s.msr_departments D on E.mainCatID=D.ID 
            left join %s.review_answers A on (a.reviewid=%d and Q.ID=A.questionID) where  q.ID in (%s) order by D.code",
                _DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL, $this->reviewID,$questions);

             $stmt = $this->dbHand->prepare($sql);
 
        $stmt->execute();

        $recdata = $stmt->fetchAll(PDO::FETCH_ASSOC);
       
       return $recdata;
       

    }
    
      private function moveFiles() {
      $rec_id = $this->fileref;


        $module = 'system_review';

        $path = _MYROOT . 'tmp/' . $module ;
        //exit;

        $log_file = $path . '/script' . $rec_id . '.log';

        if (file_exists($log_file)) {

            $log = fopen($log_file, 'r');
            $contents = fread($log, filesize($log_file));
            fclose($log);

            $file_records = explode("\n", $contents);

            $objFile = new Upload();
            //$this = new RiskAssessment();

            if (count($file_records)) {
                foreach ($file_records as $value) {
                    if ($value != '') {

                        $file_details_arr = explode('~#~', $value);
                        $file_path = $path . '/' . $file_details_arr[1];

                        if (file_exists($file_path)) {

                            $file_type = mime_content_type($file_path);

                            $file_details = array('user_file_name' => $file_details_arr[2], 'file_type' => $file_type);
                            $objFile->setFileInfo($module, $file_details);
                            $objFile->setBogusDetails($file_details);
                            $objFile->uploadifyAddFileDb();
                            $sys_file_name = $objFile->uploadifySysFileName();

                            $new_file_path = _PATH_PUB . $module . '/' . $sys_file_name;
                            //	echo "<br/>";

                            if (copy($file_path, $new_file_path)) {

                                $objFile->updateUploadifyFileName();
                                $file_id = $objFile->getLastFileId();

                                if ($file_id) {
                                    $this->addReviewFiles($rec_id,$file_id);
                                }

                                unlink($file_path);
                            }
                        }
                    }
                }
            }


            unlink($log_file);
        }
    }
       public function addReviewFiles($questID,$fileID) {

        $sql = sprintf("INSERT INTO %s.review_files (questionID,uploadedFileID) VALUES (%d,%d)"
                , _DB_OBJ_FULL
                , $this->recordID
                , $fileID);

        $pStatement = $this->dbHand->prepare($sql);

        $pStatement->execute();
    }

        public function getFile($questionid) {

     $sql = sprintf("select usrfilename from %s.uploaded_files U inner join %s.review_files F on U.fileid=F.uploadedFileID where F.questionID=%d", _DB_OBJ_FULL, _DB_OBJ_FULL, $questionid);
             $stmt = $this->dbHand->prepare($sql);
 
        $stmt->execute();

        $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);


foreach( $resultSet as $row){

       $files_list .= $row["usrfilename"].", ";
}
        return $files_list;
    }
}

?>