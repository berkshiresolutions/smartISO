<?php

class DashboardXml {

	private $fileName;
	private $moduleName;
	private $blocks;
	private $pendingColor;
	private $doneColor;
	private $statType;
	// CODESIGN2 ALLOWED STORING XML AS TEXT IN CLASS
	private $xmlData;

	public function __construct() {
		$this->xmlData = '';
		$this->fileName = 'generic';
		$this->moduleName = 'generic';
		$this->pendingColor = 'EEC999';
		$this->doneColor = 'BA9DEF';
		$this->pendingColorCurrentSession = 'F39E31';
		$this->pendingColorTotalSession = 'E3860D';
		$this->doneColorCurrentSession = '63547F';
		$this->doneColorTotalSession = '4E445F';
	}

	public function setBlocksInfo($p_blocks) {
		//	dump_array($p_blocks);
		$this->blocks['q1'] = $p_blocks['q1'];
		$this->blocks['q2'] = $p_blocks['q2'];
		$this->blocks['q3'] = $p_blocks['q3'];
		$this->blocks['q4'] = $p_blocks['q4'];
		$this->blocks['q5'] = $p_blocks['q5'];
	    $this->blocks['q6'] = $p_blocks['q6'];

		$this->statType = $p_blocks['stat_type'];
	}

	public function setModuleName($p_modulename) {

		$this->moduleName = $p_modulename;
	}

	public function setFileName($p_filename) {
		$this->fileName = $p_filename.'.xml';
	}
	public function setBUname($selected_bu) {
		$this->bu = $selected_bu;
		
					
	}
	
	// CODESIGN2 Additional Function to retrieve XML content
	public function getXMLContent($sanitize=true) {
		$tmp = $this->xmlData;
		if($sanitize) {
			$tmp = str_replace("  ","",$tmp); // Remove Spaces
			$tmp = str_replace("\t","",$tmp); // Remove Tab Chars
			$tmp = str_replace("\n","",$tmp); // Remove Newline Chars
			$tmp = str_replace("\r","",$tmp); // Remove Return Chars
			$tmp = str_replace("'",'"',$tmp); // Single Quotes to Double
		}
		return $tmp;
	}
	
	// CODESIGN2 MOVED XML CONTENT GENERATION TO SEPARATE FUNCTION FROM XML SAVING
	public function genXmlContent($p_data) {
		$this->xmlData = ''; // works for re-generating ;)
		$caption = ucwords(str_replace('_',' ',substr($this->fileName,0,-4)));
		
		$organoObj = SetupGeneric::useModule('Organigram');
		$organoObj->setItemInfo(array('id'=>$this->bu));
					$business_unit_arr = $organoObj->displayItemByIdForMSR();
					//dump_array($business_unit_arr['buName']);

		if ( $caption == 'Nhp' ) {
			$caption = 'NCR';
		} else if ( $caption == 'Nhp Investigation' ) {
			$caption = 'NCR Investigation';
		} else if ( $caption == 'Msr' ) {
			$caption = 'MSR Actions';
		} else if ( $caption == 'Risk' ) {
			$caption = 'Risk Assessment(Process)';
		} else if ( $caption == 'Incidence' ) {
			$caption = 'Incident';
		}else if ( $caption == 'Incidence Investigation' ) {
			$caption = 'Incident Investigation';
		}else if ( $caption == 'Document'  && _CANDW == 0) {
			$caption = 'Document Alerts';
                }else if ( $caption == 'Document'  && _CANDW == 1) {
			$caption = 'Document Changes';
		}else if ( $caption == 'EquipmentC' ) {
			$caption = 'Equipment Calibration';
		}else if ( $caption == 'EquipmentM' ) {
			$caption = 'Equipment Maintenance';
		}else if ( $caption == 'Alert' ) {
			$caption = 'NCR-Non Conformity';
		}else if ( $caption == 'Load' ) {
			$caption = 'Manual Handling';
		}else if ( $caption == 'Red' ) {
			$caption = 'Risk Priority Action - Red';
		}else if ( $caption == 'Green' ) {
			$caption = 'Risk Priority Action - Green';
		}else if ( $caption == 'Amber' ) {
			$caption = 'Risk Priority Action - Amber';
		}else if ( $caption == 'Purple' ) {
			$caption = 'Risk Priority Action - Purple';
		}else if ( $caption == 'Service' ) {
			$caption = 'smart Fleet - Service';
		}else if ( $caption == 'Ins' ) {
			$caption = 'smart Fleet - Inspection';
		}else if ( $caption == 'Man' ) {
			$caption = 'Library Manager';
		}else if ( $caption == 'Inspection' ) {
			$caption = 'Critical Audit';
		}

        if($business_unit_arr['buName']){
		$caption =($caption.' For '.$business_unit_arr['buName']);
		}else{
		
		$caption =($caption.' For All');
		}

		switch ($this->statType) {
			case 'Q': $xAxisNameLabel = 'Quarters'; break;
			case 'M': $xAxisNameLabel = 'Months'; break;
			case 'W': $xAxisNameLabel = 'Weeks'; break;
			default: $xAxisNameLabel = 'Quarters'; break;
		}
		
		//dump_array($p_data);
        // echo $caption;
		// only two lines edited in this class by CODESIGN2 are this line and the line found below!
		$xml_data = "<chart exportAction='download' exportFileName='.$caption.' exportEnabled='1' exportAtClient='0' exportHandler='/includes/chartExport/FCExporter.php' palette='5' caption='".$caption."' xAxisName='".$xAxisNameLabel."' yAxisName='Actions' numberPrefix='' showValues='0'  rotateValues='1' >";
		$xml_data .= "<categories>
						<category label='".$this->blocks['q1']."' />
						<category label='".$this->blocks['q2']."' />
						<category label='".$this->blocks['q3']."' />
						<category label='".$this->blocks['q4']."' />
						<category label='".$this->blocks['q5']."' />
						
					</categories>";
		 if($p_data['q1']['Ma'] || $p_data['q2']['Ma'] || $p_data['q3']['Ma'] || $p_data['q4']['Ma'] || $p_data['q5']['Ma']){
		
		$xml_data .= "<dataset seriesname='Major' color='".$this->pendingColor."' >
			<set value='".$p_data['q1']['Ma']."' color='".$this->pendingColorCurrentSession."'/>
			<set value='".$p_data['q2']['Ma']."' />
			<set value='".$p_data['q3']['Ma']."' />
			<set value='".$p_data['q4']['Ma']."' />
			<set value='".$p_data['q5']['Ma']."' color='".$this->pendingColorTotalSession."'/>
		</dataset>";
		} else {
        if($p_data['q1']['P'] || $p_data['q2']['P'] || $p_data['q3']['P'] || $p_data['q4']['P'] || $p_data['q5']['P']){
		
		$xml_data .= "<dataset seriesname='Pending' color='".$this->pendingColor."' >
			<set value='".$p_data['q1']['P']."' color='".$this->pendingColorCurrentSession."'/>
			<set value='".$p_data['q2']['P']."' />
			<set value='".$p_data['q3']['P']."' />
			<set value='".$p_data['q4']['P']."' />
			<set value='".$p_data['q5']['P']."' color='".$this->pendingColorTotalSession."'/>
		</dataset>";
		
		
		}else{
		
		$xml_data .= "<dataset seriesname='Pending' color='".$this->pendingColor."' >
			<set value='0' color='".$this->pendingColorCurrentSession."'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='0' color='".$this->pendingColorTotalSession."'/>
		</dataset>";
		
		
		}
		
		}
		if($p_data['q1']['Mi'] || $p_data['q2']['Mi'] || $p_data['q3']['Mi'] || $p_data['q4']['Mi'] || $p_data['q5']['Mi']){
		$xml_data .= "<dataset seriesname='Minor' color='".$this->doneColor."'  >
			<set value='".$p_data['q1']['Mi']."'  color='".$this->doneColorCurrentSession."'/>
			<set value='".$p_data['q2']['Mi']."' />
			<set value='".$p_data['q3']['Mi']."' />
			<set value='".$p_data['q4']['Mi']."' />
			<set value='".$p_data['q5']['Mi']."'  color='".$this->doneColorTotalSession."'/>
			
		</dataset>";
		
		} else{
		
		if($p_data['q1']['D'] || $p_data['q2']['D'] || $p_data['q3']['D'] || $p_data['q4']['D'] || $p_data['q5']['D']){
		
		$xml_data .= "<dataset seriesname='Done' color='".$this->doneColor."'  >
			<set value='".$p_data['q1']['D']."'  color='".$this->doneColorCurrentSession."'/>
			<set value='".$p_data['q2']['D']."' />
			<set value='".$p_data['q3']['D']."' />
			<set value='".$p_data['q4']['D']."' />
			<set value='".$p_data['q5']['D']."'  color='".$this->doneColorTotalSession."'/>
			
		</dataset>";
		
		
		}else{
		
		if($p_data['q1']['Mi'] == '0') {
		
		
		
		$xml_data .= "<dataset seriesname='Minor' color='".$this->doneColor."'  >
			<set value='0'  color='".$this->doneColorCurrentSession."'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='0'  color='".$this->doneColorTotalSession."'/>
			
		</dataset>";
		}else{
		
		
		$xml_data .= "<dataset seriesname='Done' color='".$this->doneColor."'  >
			<set value='0'  color='".$this->doneColorCurrentSession."'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='0'  color='".$this->doneColorTotalSession."'/>
			
		</dataset>";
		
		}
		
		
		
		
		}
		
		}
		
		
		if($p_data['q1']['ofi'] || $p_data['q2']['ofi'] || $p_data['q3']['ofi'] || $p_data['q4']['ofi'] || $p_data['q5']['ofi']){
		$xml_data .= "<dataset seriesname='OFI' color='#ff0000'  >
				<set value='".$p_data['q1']['ofi']."' />
			<set value='".$p_data['q2']['ofi']."' />
			<set value='".$p_data['q3']['ofi']."' />
			<set value='".$p_data['q4']['ofi']."' />
			<set value='".$p_data['q5']['ofi']."'  />
			
		</dataset>";
		} else {
        if($p_data['q6']['A']){
		$xml_data .= "<dataset seriesname='Overdue' color='#ff0000'  >
			<set value='".$p_data['q6']['A']."' />
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='".$p_data['q6']['A']."' />
			
		</dataset>";
		
		}else{
		
		$xml_data .= "<dataset seriesname='Overdue' color='#ff0000' >
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='0' />
			
		</dataset>";
		
		
		}
		
		}
	
		
		
		//echo $caption;
		/*if($caption == 'NHC For All'){
		
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='12' color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='12' color='#FF0000'/>
			
		</dataset>";
		}else if($caption == 'Incident For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='18' color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='18'  color='#FF0000'/>
			
		</dataset>";
		
		}else if($caption == 'Incident Investigation For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='8' color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='8'  color='#FF0000'/>
			
		</dataset>";
		
		}else if($caption == 'NHC Investigation For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='5'  color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='5'  color='#FF0000'/>
			
		</dataset>";
		
		}else if($caption == 'MSR Actions For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='7'  color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='7'  color='#FF0000'/>
			
		</dataset>";
		
		}else if($caption == 'Inspection For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='3'  color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='3'  color='#FF0000'/>
			
		</dataset>";
		
		}else if($caption == 'Contract For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='11'  color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='11'  color='#FF0000'/>
			
		</dataset>";
		
		}else if($caption == 'Risk Assessment(Process) For All'){
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='".$p_data['q6']['A']."' color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='10'  color='#FF0000'/>
			
		</dataset>";
		
		}else{
		$xml_data .= "<dataset seriesname='Overdue' color='".$this->doneColor."'  showValues='1'>
			<set value='0'  color='#FF0000'/>
			<set value='0' />
			<set value='0' />
			<set value='0' />
			<set value='0'  color='#FF0000'/>
			
		</dataset>";
		}*/
		

		$xml_data .= "</chart>";
		$this->xmlData = $xml_data;
	}
	
	// CODESIGN2 MOVED XML CONTENT GENERATION TO SEPARATE FUNCTION FROM XML SAVING & DEDICATED THIS FUNCTION TO SAVING
	public function saveXmlContent($p_data) {
		if( (strpos($this->xmlData,'<chart') == FALSE) || (strpos($this->xmlData,'</chart>') == FALSE) ){
			$this->genXmlContent($p_data);
		}
		
		$filename = _PATH_PRIVATE_FILES."../".$this->moduleName.'/'.$this->fileName;

		$fp = fopen($filename,'w+');
		if ($fp) {

			fwrite($fp,$this->xmlData,strlen($this->xmlData));
			fclose($fp);
		}
	}

	public function getFileURL() {

		return _URL_PRIVATE_FILES."../".$this->moduleName.'/'.$this->fileName;
	}


}
?>