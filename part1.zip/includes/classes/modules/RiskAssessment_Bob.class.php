<?php
 /**
  $Id: RiskAssessment.class.php,v 4.89 Friday, February 04, 2011 3:27:36 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, October 29, 2010 4:00:58 PM>
  */

require_once "RiskAssessment.int.php";
require_once "Action.class.php";

class RiskAssessment implements RiskAssessmentInterface
{
	/**
	 * Object container for PDO Database resource class
	 * @access private
	 */
	private $dbHand;

	/**
	 * Object container Action class
	 * @access private
	 */
	private $actionHandling;

	/**
	 * property contains action data
	 * @access private
	 */
	private $actionData;

	/**
	 *Property to hold Risk Id
	 *@access private
	 */
	private $RiskId;

	/**
	 *Property to hold Risk Info
	 *@access private
	 */
	private $RiskInfo;


	/**
	 * Constructor for initializing Risk object
	 * @access public
	 */
	public function __construct() {

		$this->dbHand 			= DB::connect(_DB_TYPE);
		$this->actionHandling	= new Action();
	}

	/*
	 * to set risk assessment information for performing various operations with an risk assessment object
	 */
	public function setRiskInfo($p_RiskAssessmentId,$p_RiskAssessmentInfo) {

		$this->RiskId 	= $p_RiskAssessmentId;
		$this->RiskInfo = $p_RiskAssessmentInfo;
	}

	/*
	 * This method is used to get list of process for risk assessment.
	 */
	public function getRiskAssessmentProcesses() {

        $sql = sprintf("SELECT S.*,B.buName FROM %s.swimlane S
				INNER JOIN %s.business_units B
				ON S.buID = B.buID
				ORDER BY S.swimID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		return $pStatement->fetchAll(PDO::FETCH_ASSOC);
	}

	/*
	 * This method is used to get list of steps by process
	 */
	public function getStepsByProcess() {

		$sql = sprintf("SELECT * FROM %s.swimlane_data WHERE swimID = %d and type != 'D' 
				ORDER BY altPathIndex, stepLevel,ID ASC",_DB_OBJ_FULL,$this->RiskInfo['process_id']);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->RiskInfo['process_id']);*/
		$pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);

        return $result;
	}

    public function getStepsByStatus() {

        $old_value = $this->RiskInfo['archive'];

        $this->RiskInfo['archive'] = 1;
        $archived_hazards = count($this->getHazardsByProcessStep());

        $this->RiskInfo['archive'] = 0;
        $active_hazards = count($this->getHazardsByProcessStep());

        $this->RiskInfo['archive'] = $old_value;

        return array(
                     'archived_hazards' => $archived_hazards,
                     'active_hazards' => $active_hazards,
                     'total_hazards' => $active_hazards+$archived_hazards,
                    );
    }

	/*
	 * This method is used to get hazards by process step
	 */
	public function getHazardsByProcessStep() {

        if ( $this->RiskInfo['step_id'] == 0 || $this->RiskInfo['step_id'] == null ) {
            $sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND archive = '%s'"
						,_DB_OBJ_FULL
						,$this->RiskInfo['process_id']
						,$this->RiskInfo['archive']);

        } else {

            /*$sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d AND archive = '%s'"
                    ,_DB_OBJ_FULL
                    ,$this->RiskInfo['process_id']
                    ,$this->RiskInfo['step_id']
                    ,$this->RiskInfo['archive']);*/

			$sql = sprintf("SELECT A.*,A.whoID,dateTimestamp FROM %s.risk A
				LEFT OUTER JOIN (
					SELECT B.*,C.swimID
					FROM %s.module_tracker B
					INNER JOIN %s.swimlane C
					ON B.reference = C.reference
					WHERE module = 'RISK'
					AND action = 'add'
				) D
				ON swimID = processID
				WHERE processID = %d AND processStepID = %d AND A.archive = '%s' ORDER BY ID DESC",
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				$this->RiskInfo['process_id'],
				$this->RiskInfo['step_id'],
				$this->RiskInfo['archive']);

        }	
		

        $pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['process_id']);
		$pStatement->bindParam(2,$this->RiskInfo['step_id']);
		$pStatement->bindParam(3,$this->RiskInfo['archive']);*/

		$pStatement->execute();

		return $pStatement->fetchAll(PDO::FETCH_ASSOC);
	}

	/*
	 * This method is used to get hazards by process step
	 */
	public function getHazardsByProcessStepLogDate() {

		$date_filter = '';

		if ( $this->RiskInfo['start_date'] != '' && $this->RiskInfo['end_date'] != '' ) {
			$date_filter = " AND (dateTimestamp IS NULL OR dateTimestamp BETWEEN '".$this->RiskInfo['start_date']."' AND '".$this->RiskInfo['end_date']."')";
		}

		/*$sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d AND archive = '%s'"
				,_DB_OBJ_FULL
				,$this->RiskInfo['process_id']
				,$this->RiskInfo['step_id']
				,$this->RiskInfo['archive']);*/

		$sql = sprintf("SELECT A.*,userID,dateTimestamp FROM %s.risk A
				LEFT OUTER JOIN (
					SELECT B.*,C.swimID
					FROM %s.recordTracking B
					INNER JOIN %s.[swimlane] C
					ON B.recordRef = C.reference
					WHERE moduleName = 'RA'
					AND action = 'add'
				) D
				ON swimID = processID
				WHERE processID = %d AND processStepID = %d
				AND A.archive = '%s'
				$date_filter
				ORDER BY ID DESC",
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				_DB_OBJ_FULL,
				$this->RiskInfo['process_id'],
				$this->RiskInfo['step_id'],
				$this->RiskInfo['archive']);

        $pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['process_id']);
		$pStatement->bindParam(2,$this->RiskInfo['step_id']);
		$pStatement->bindParam(3,$this->RiskInfo['archive']);*/

		$pStatement->execute();

		return $pStatement->fetchAll(PDO::FETCH_ASSOC);
	}

	/*
	 * This method is used to get hazards by process step
	 */
	public function archiveRisk() {

		$sql = sprintf("UPDATE %s.risk SET archive = '%s' WHERE ID = %d"
					,_DB_OBJ_FULL
					,$this->RiskInfo['archive']
					,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['archive']);
		$pStatement->bindParam(2,$this->RiskId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to get step Details
	 */
	public function getProcessStepDetails() {

		$sql = sprintf("SELECT * FROM %s.swimlane_data
				WHERE swimID = %d
				AND ID = %d"
				,_DB_OBJ_FULL
				,$this->RiskInfo['process_id']
				,$this->RiskInfo['step_id']);

		$stmt 	= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->RiskInfo['process_id']);
		$stmt->bindParam(2,$this->RiskInfo['step_id']);*/

		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	/*
	 * This method is used to add new hazard for a risk process assessment
	 * process_id,process_step_id,hazard_classification,hazards,secondary_hazard,hazard_symbol,hazard_summary
	 */
	public function addHazardAssessment() {

		$sql = sprintf("INSERT INTO %s.risk (processID,processStepID,hazardClassificationID,hazardsID,secondaryHazardID,hazardSymbols,
						hazardSummary,status,dseAssessment,
							archive,whoID,buID,processReference)
								VALUES (%d, %d, %d,'%s','%s','%s','%s','0','%s','0',%d,%d,'%s') "
								,_DB_OBJ_FULL
								,$this->RiskInfo['process_id']
								,$this->RiskInfo['process_step_id']
								,$this->RiskInfo['hazard_classification']
								,$this->RiskInfo['hazards']
								,$this->RiskInfo['secondary_hazard']
								,$this->RiskInfo['hazard_symbol']
								,$this->RiskInfo['hazard_summary']
								,$this->RiskInfo['dse_assessments']
								,$this->RiskInfo['who_id']
								,$this->RiskInfo['process_bu_id']
								,$this->RiskInfo['process_reference']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['process_id']);
		$pStatement->bindParam(2,$this->RiskInfo['process_step_id']);
		$pStatement->bindParam(3,$this->RiskInfo['hazard_classification']);
		$pStatement->bindParam(4,$this->RiskInfo['hazards']);
		$pStatement->bindParam(5,$this->RiskInfo['secondary_hazard']);
		$pStatement->bindParam(6,$this->RiskInfo['hazard_symbol']);
		$pStatement->bindParam(7,$this->RiskInfo['hazard_summary']);
		$pStatement->bindParam(8,$this->RiskInfo['dse_assessments']);*/

		$pStatement->execute();
		//dump_array_and_exit($pStatement->errorInfo());
		/*dump_array($pStatement->errorInfo());
		exit;*/

		$this->RiskId = customLastInsertId( $this->dbHand,'risk','ID');

		$this->moveFiles('hazard');
	}

	/*
	 * This method is used to edit hazard for a risk process assessment
	 */
	public function editHazardAssessment() {

		$sql = sprintf("UPDATE %s.risk SET hazardClassificationID = %d,
									hazardsID = '%s',
									secondaryHazardID = '%s',
									hazardSymbols = '%s',
									hazardSummary = '%s',
									dseAssessment = '%s',
									whoID = %d
								WHERE ID = %d"
								,_DB_OBJ_FULL
								,$this->RiskInfo['hazard_classification']
								,$this->RiskInfo['hazards']
								,$this->RiskInfo['secondary_hazard']
								,$this->RiskInfo['hazard_symbol']
								,$this->RiskInfo['hazard_summary']
								,$this->RiskInfo['dse_assessments']
								,$this->RiskInfo['who_id']
								,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['hazard_classification']);
		$pStatement->bindParam(2,$this->RiskInfo['hazards']);
		$pStatement->bindParam(3,$this->RiskInfo['secondary_hazard']);
		$pStatement->bindParam(4,$this->RiskInfo['hazard_symbol']);
		$pStatement->bindParam(5,$this->RiskInfo['hazard_summary']);
		$pStatement->bindParam(6,$this->RiskInfo['dse_assessments']);
		$pStatement->bindParam(7,$this->RiskId);*/

		$pStatement->execute();
		$this->moveFiles('hazard');
	}

	/**
	 * This method is used to manage Control Tab data
	 */
	public function updateControl() {

		$sql = sprintf("UPDATE %s.risk SET controlAlongPath = %d,
									controlAtWorker = %d,
									controlSymbols = '%s',
									controlSummary = '%s'
								WHERE ID = %d "
								,_DB_OBJ_FULL
								,$this->RiskInfo['along_path']
								,$this->RiskInfo['at_worker']
								,$this->RiskInfo['control_symbol']
								,$this->RiskInfo['control_summary']
								,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['along_path']);
		$pStatement->bindParam(2,$this->RiskInfo['at_worker']);
		$pStatement->bindParam(3,$this->RiskInfo['control_symbol']);
		$pStatement->bindParam(4,$this->RiskInfo['control_summary']);
		$pStatement->bindParam(5,$this->RiskId);*/

		$pStatement->execute();
		$this->moveFiles('control');
	}

	public function updateOverruleReason() {

		$sql = sprintf("UPDATE %s.risk SET overrulereason = '%s' 
								WHERE ID = %d "
								,_DB_OBJ_FULL
								,$this->RiskInfo['overrulereason']
								,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();
	}
	
	/**
	 * This method is used to manage Risk Rating 1
	 *
	 * Array Variables : likelihood,impact,risk_rating,risk_rating_color
	 */
	public function manageRiskRating1() {

		$sql = sprintf("UPDATE %s.risk SET likelihood1 = %d ,
									impact1 = %d,
									riskRating1 = '%s',
									riskRatingColor1 = '%s'
									WHERE ID = %d "
									,_DB_OBJ_FULL
									,$this->RiskInfo['likelihood']
									,$this->RiskInfo['impact']
									,$this->RiskInfo['risk_rating']
									,$this->RiskInfo['risk_rating_color']
									,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['likelihood']);
		$pStatement->bindParam(2,$this->RiskInfo['impact']);
		$pStatement->bindParam(3,$this->RiskInfo['risk_rating']);
		$pStatement->bindParam(4,$this->RiskInfo['risk_rating_color']);
		$pStatement->bindParam(5,$this->RiskId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage improvement
	 *
	 * Array Variables : source,path,worker,no_improvement,improvement_reason,improvement_ids = array(),
	 * improvement = array()
	 */
	public function manageImprovement() {

		$sql = sprintf("UPDATE %s.risk SET improvementAtSource = '%s' ,
									improvementAlongPath = '%s',
									improvementAtWorker = '%s',
									noImprovement = '%s',
									improvementReason = '%s',
									eliminateHazard = '%s'
									WHERE ID = %d "
									,_DB_OBJ_FULL
									,$this->RiskInfo['source']
									,$this->RiskInfo['path']
									,$this->RiskInfo['worker']
									,$this->RiskInfo['no_improvement']
									,$this->RiskInfo['improvement_reason']
									,$this->RiskInfo['eliminate_hazard']
									,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['source']);
		$pStatement->bindParam(2,$this->RiskInfo['path']);
		$pStatement->bindParam(3,$this->RiskInfo['worker']);
		$pStatement->bindParam(4,$this->RiskInfo['no_improvement']);
		$pStatement->bindParam(5,$this->RiskInfo['improvement_reason']);
		$pStatement->bindParam(6,$this->RiskId);*/

		$pStatement->execute();

		if ( count($this->RiskInfo['improvement_ids']) ) {
			$improvement_ids = "";
			foreach ( $this->RiskInfo['improvement_ids'] as $key=>$value ) {


				$imp_desc = smartisoAddslashes($this->RiskInfo['improvement'][$key]);


				if ( !$value ) {
					// add action
					$this->actionData = array('module_name'=>'risk','description'=>$imp_desc,'who'=>0,'due_date'=>'01/01/1900');
					$this->actionHandling->setActionDetails(0,$this->actionData);
					$action_id = $this->actionHandling->addAction();
					$improvements .= $action_id.',';

				} else {

					// update action
					$this->actionHandling->setActionDetails($value,"");
					$improvement = $this->actionHandling->viewAction();
					$improvement['dueDate'];

					$imp_date = $improvement['dueDate'] == '1900-01-01' ? '01/01/1900' : format_date($improvement['dueDate']);

					$this->actionData = array('description'=>$imp_desc,'who'=>$improvement['who'],'due_date'=>$imp_date);
					$this->actionHandling->setActionDetails($value,$this->actionData);
					$action_id = $this->actionHandling->updateAction();
					$improvements .= $value.',';
				}
			}

			$improvements = rtrim($improvements,',');
		}

		if ( $this->RiskInfo['no_improvement'] ) {
			$risk_data = $this->viewHazardAssessment();

			//echo $risk_data['improvements'];

			if ( $risk_data['improvements'] != "" || $risk_data['improvements'] != 0) {

				$improvements_arr = explode(',',$risk_data['improvements']);
				if ( count($improvements_arr) ) {
					foreach ($improvements_arr as $value ) {
						$this->actionHandling->setActionDetails($value,"");
						$improvement = $this->actionHandling->deleteAction();
					}
				}

			}

			$improvements = 0;

		} else {

			$improvements_reason = "";

			$sql = sprintf("UPDATE %s.risk SET improvementReason = '%s'
									WHERE ID = %d "
									,_DB_OBJ_FULL
									,$improvements_reason
									,$this->RiskId);

			$pStatement = $this->dbHand->prepare($sql);

			/*$pStatement->bindParam(1,$improvements_reason);
			$pStatement->bindParam(2,$this->RiskId);*/

			$pStatement->execute();
		}


		$sql = sprintf("UPDATE %s.risk SET improvements = '%s'
						WHERE ID = %d "
						,_DB_OBJ_FULL
						,$improvements
						,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$improvements);
		$pStatement->bindParam(2,$this->RiskId);*/

		$pStatement->execute();

		$this->moveFiles('improvement');

	}

	/**
	 * This method is used to manage risk rating 2
	 *
	 * Array Variables : likelihood,impact,risk_rating,risk_rating_color
	 */
	public function manageRiskRating2() {

		$sql = sprintf("UPDATE %s.risk SET likelihood2 = '%s' ,
						impact2 = '%s',
						riskRating2 = '%s',
						riskRatingColor2 = '%s'
						WHERE ID = %d "
						,_DB_OBJ_FULL
						,$this->RiskInfo['likelihood']
						,$this->RiskInfo['impact']
						,$this->RiskInfo['risk_rating']
						,$this->RiskInfo['risk_rating_color']
						,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['likelihood']);
		$pStatement->bindParam(2,$this->RiskInfo['impact']);
		$pStatement->bindParam(3,$this->RiskInfo['risk_rating']);
		$pStatement->bindParam(4,$this->RiskInfo['risk_rating_color']);
		$pStatement->bindParam(5,$this->RiskId);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to manage priority
	 *
	 * Array Variables : time_trouble,net_impact,priority
	 */
	public function managePriority() {

		$sql = sprintf("UPDATE %s.risk SET timeTrouble = '%s' ,
					netImpact = '%s',
					priority = '%s'
					WHERE ID = %d "
				,_DB_OBJ_FULL
				,$this->RiskInfo['time_trouble']
				,$this->RiskInfo['net_impact']
				,$this->RiskInfo['priority']
				,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['time_trouble']);
		$pStatement->bindParam(2,$this->RiskInfo['net_impact']);
		$pStatement->bindParam(3,$this->RiskInfo['priority']);
		$pStatement->bindParam(4,$this->RiskId);*/

		$pStatement->execute();
	}

	/**
	* This method is used to manage action
	*
	* Array Variables : improvement,who,when,improvement_id
	*/
	public function manageAction() {
		$this->actionData = array('description'=>$this->RiskInfo['improvement'],'who'=>$this->RiskInfo['who'],'whoAU'=>$this->RiskInfo['whoAU'],
								  'due_date'=>$this->RiskInfo['when'],'overrulereason'=>$this->RiskInfo['overrulereason']);
		$this->actionHandling->setActionDetails($this->RiskInfo['improvement_id'],$this->actionData);
		$action_id = $this->actionHandling->updateAction();

	}

	/**
	* This method is used to manage action
	*
	* Array Variables : status
	*/
	public function updateStatus() {
		$sql = sprintf("UPDATE %s.risk SET status = '1' WHERE ID = %d "
					   ,_DB_OBJ_FULL
					   ,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskId);*/
		$pStatement->execute();

	}

	/*
	 * This method is used to view hazard assessment
	 */
	public function viewHazardAssessment() {

		$sql = sprintf("SELECT * FROM %s.risk WHERE ID = %d",_DB_OBJ_FULL,$this->RiskId);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskId);*/

		$pStatement->execute();

		return $pStatement->fetch(PDO::FETCH_ASSOC);
	}

	/**
	 * This method is used to view the improvement Risk information.
	 */
	public function viewImprovementRisk() {

		$sql = sprintf("SELECT improvementAtSource,improvementAlongPath,improvementAtWorker,improvements,noImprovement,improvementReason
					   FROM %s.risk WHERE ID = %d ",_DB_OBJ_FULL,$this->RiskId);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskId);*/
		$pStatement->execute();

		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($resultSet) ) {

			if ( $resultSet[0]['improvements'] != "" ) {

				$improvement_arr = explode(',',$resultSet[0]['improvements']);

				if ( count($improvement_arr) ) {
					foreach ($improvement_arr as $value ) {
						$this->actionHandling->setActionDetails($value,"");
						$improvement = $this->actionHandling->viewAction();
						$riskImprovements[$value] = $improvement;
					}
				}

				$resultSet[0]['improvements'] = $riskImprovements;
			}
		}
		return $resultSet[0];
	}

	public function secondaryHazardCount($p_archive_flag=0) {

		$sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d AND archive = '%s'"
					   ,_DB_OBJ_FULL
					   ,$this->RiskInfo['process_id']
					   ,$this->RiskInfo['step_id']
					   ,$p_archive_flag);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskInfo['process_id']);
		$pStatement->bindParam(2,$this->RiskInfo['step_id']);*/

		$pStatement->execute();
		$num_rows = (int) $pStatement->rowCount();
		$sec_hazard_count = 0;

		if ( $num_rows ) {
			while ( $row = $pStatement->fetch(PDO::FETCH_ASSOC) ) {

				//dump_array($row);
				$sec_hazards = 0;
				if ( $row['secondaryHazardID'] != '' ) {
					$sec_hazards = explode(',',$row['secondaryHazardID']);
					$sec_hazard_count += count($sec_hazards);
				}
			}
		}

		return $sec_hazard_count;
	}

	public function completedActions() {

		$sql = sprintf("SELECT * FROM %s.risk
					   WHERE processID = %d AND processStepID = %d AND status = '%s' "
					   ,_DB_OBJ_FULL
					   ,$this->RiskInfo['process_id']
						,$this->RiskInfo['step_id']
						,$this->RiskInfo['status']);

		$pStatement = $this->dbHand->prepare($sql);
		/*$pStatement->bindParam(1,$this->RiskInfo['process_id']);
		$pStatement->bindParam(2,$this->RiskInfo['step_id']);
		$pStatement->bindParam(3,$this->RiskInfo['status']);*/

		$pStatement->execute();

		return count($pStatement->fetchAll(PDO::FETCH_ASSOC));
	}


	public function openOverdueActions() {

		$recordOpen 	= 0;
		$recordOverdue 	= 0;

		$sql = sprintf("SELECT improvements
					FROM %s.risk
					WHERE processID = %d AND processStepID = %d"
					,_DB_OBJ_FULL
					,$this->RiskInfo['process_id']
					,$this->RiskInfo['step_id']);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$record = $pStatement->fetchALL(PDO::FETCH_ASSOC);

		foreach ( $record as $record_ele )  {
			if ( !is_null($record_ele['improvements']) ) {

				$sql = sprintf("
					SELECT count(*) FROM %s.actions
					WHERE moduleName = 'risk'
					AND dueDate >= ".customCurrentDate()."
					AND approve = '0'
					AND ID IN (%s)"
					,_DB_OBJ_FULL
					,$record_ele['improvements']);

				$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();

				$recordOpen = (int) $pStatement->fetchColumn();

				$sql = sprintf("
					SELECT count(*) FROM %s.actions
					WHERE moduleName = 'risk'
					AND dueDate < ".customCurrentDate()."
					AND approve = '0'
					AND ID IN (%s)"
					,_DB_OBJ_FULL
					,$record_ele['improvements']);

				$pStatement = $this->dbHand->prepare($sql);
				$pStatement->execute();

				$recordOverdue = $pStatement->fetchColumn();
			}
		}

		return array('open'=>$recordOpen, 'overdue'=>$recordOverdue);
	}

	public function lastRecordid() {
		return $this->RiskId;
	}

	public function getNextId() {

		if ( _DB_TYPE == 'mssql' ) {
			$new_id = customLastInsertId( $this->dbHand,'risk','ID');

			return ($new_id+1);
		} else {
			$sql = sprintf("SHOW TABLE STATUS LIKE %s.risk",_DB_OBJ_FULL);
			$pStatement = $this->dbHand->prepare($sql);
			$pStatement->execute();
			$result_set = $pStatement->fetch(PDO::FETCH_ASSOC);
			return $result_set['Auto_increment'];
		}
	}

	public function addRiskFiles() {

		$sql = sprintf("INSERT INTO %s.risk_files (riskID,section,uploadedFileID) VALUES (%d,'%s',%d)"
					   ,_DB_OBJ_FULL
					   ,$this->RiskId
						,$this->RiskInfo['identifier']
						,$this->RiskInfo['file_id']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskId);
		$pStatement->bindParam(2,$this->RiskInfo['identifier']);
		$pStatement->bindParam(3,$this->RiskInfo['file_id']);*/

		$pStatement->execute();
	}

	/**
	 * This method is used to get risk files
	 * equip id, identifier
	 */
	public function getRiskFile() {

		$sql = sprintf("SELECT * FROM %s.risk_files WHERE riskID = %d AND section = '%s'"
					   ,_DB_OBJ_FULL
					   ,$this->RiskId
					   ,$this->RiskInfo['identifier']);

		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskId);
		$pStatement->bindParam(2,$this->RiskInfo['identifier']);*/

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
		return $resultSet;
	}

	public function deleteRiskFiles() {

		$sql = sprintf("DELETE FROM %s.risk_files WHERE riskID = %d",_DB_OBJ_FULL,$this->RiskId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->RiskId);

		$pStatement->execute();
	}

	/**
	 * This method is used to get risk files
	 * file id
	 */
	public function getRiskFileDetails() {

		$sql = sprintf("SELECT * FROM %s.risk_files WHERE ID = %d",_DB_OBJ_FULL,$this->RiskId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->RiskId);

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet[0];
	}

	public function deleteRiskFile() {

		$sql = sprintf("DELETE FROM %s.risk_files WHERE ID = %d",_DB_OBJ_FULL,$this->RiskId);
		$pStatement = $this->dbHand->prepare($sql);

		//$pStatement->bindParam(1,$this->RiskId);

		$pStatement->execute();
	}

	public function getControlHazardSummary($p_risk_id,$p_step_id) {

		$sql = sprintf("SELECT * FROM %s.risk WHERE processID = %d AND processStepID = %d ",_DB_OBJ_FULL,$p_risk_id,$p_step_id);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$p_risk_id);
		$pStatement->bindParam(2,$p_step_id);*/

		$pStatement->execute();
		$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		return $resultSet[0];
	}

	/*
	 * This method is used to get list of process for process dropdown.
	 */
	public function getProcessesForDropdown() {

		$sql = sprintf("SELECT S.* FROM %s.swimlane S
				INNER JOIN %s.business_units B
					ON S.buID = B.buID
				ORDER BY reference,uniqueReference ASC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$result_all = $pStatement->fetchAll(PDO::FETCH_ASSOC) ;

		if ( count($result_all) ) {
			$i=0;
			foreach ( $result_all as $result ) {

				//dump_array($result);
				$row[$i]['id'] = $result['swimID'];
				$row[$i]['reference'] = $result['reference'];
				$row[$i]['description'] = $result['description'];

				if ( _DB_TYPE == 'mssql' ) {
					$sql1 = sprintf("SELECT TOP 1 riskRating1,riskRatingColor1 FROM %s.risk WHERE riskRating1 != '' AND riskRatingColor1 != '' AND processID = %d",_DB_OBJ_FULL,$result['swimID']);
				} else {
					$sql1 = sprintf("SELECT riskRating1,riskRatingColor1 FROM %s.risk WHERE riskRating1 != '' AND riskRatingColor1 != '' AND processID = %d LIMIT 0,1",_DB_OBJ_FULL,$result['swimID']);
				}


				$pStatement1 = $this->dbHand->prepare($sql1);

				/*$pStatement1->bindParam(1,$result['swimID']);*/
				$pStatement1->execute();

				$risk_result = $pStatement1->fetchAll(PDO::FETCH_ASSOC);

				if ( count($risk_result) ) {
					$row[$i]['risk_value'] = $risk_result[0]['riskRating1'] == "" ? '#' : $risk_result[0]['riskRating1'];
					$row[$i]['risk_color'] = $risk_result[0]['riskRatingColor1'] == "" ? '#ccc' : $risk_result[0]['riskRatingColor1'];
				} else {
					$row[$i]['risk_value'] = '#';
					$row[$i]['risk_color'] = '#ccc';
				}

				$i++;


			}
		}


		return $row;
	}

	public function getOutstandingActions($p_overdue) {

		if ( $p_overdue ) {
			$data = $this->actionHandling->viewOverdueActions('risk');
		} else {
			$data = $this->actionHandling->viewAllActionByModule('risk');
		}



		if ( count($data) ) {
			$i= 0;
			foreach ( $data as $value ) {

				$action_data = "";
				$search_value1 = $value['ID'];
				$search_value2 = $value['ID'].',%';
				$search_value3 = '%,'.$value['ID'];
				$search_value4 = '%,'.$value['ID'].',%';

				$sql = sprintf("SELECT I.reference,I.buID,M.ID AS risk_id FROM %s.swimlane I
								INNER JOIN %s.risk M
									ON M.processID=I.swimID
								WHERE M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' OR M.improvements LIKE '%s' "
								,_DB_OBJ_FULL,
								_DB_OBJ_FULL,
								$search_value1
								,$search_value2
								,$search_value3
								,$search_value4);

				$pStatement = $this->dbHand->prepare($sql);

				/*$pStatement->bindParam(1,$search_value1);
				$pStatement->bindParam(2,$search_value2);
				$pStatement->bindParam(3,$search_value3);
				$pStatement->bindParam(4,$search_value4);*/

				$pStatement->execute();
				$action_data = $pStatement->fetchAll(PDO::FETCH_ASSOC);

				if ( count($action_data) ) {

					foreach ( $action_data as $value2 ) {
						$new_data[$i]['reference']		 = $value2['reference'];
						$new_data[$i]['bu']				 = $value2['buID'];
						$new_data[$i]['action_id']		 = $value['ID'];
						$new_data[$i]['who']			 = $value['who'];
						$new_data[$i]['due_date']		 = $value['dueDate'];
						$new_data[$i]['action']			 = $value['actionDescription'];
						$new_data[$i]['risk_id']		 = $value2['risk_id'];
					}
					$i++;
				}

			}
		}
		return $new_data;
	}

	public function addOutstandingAction() {

		$sql = sprintf("SELECT improvements FROM %s.risk WHERE ID = %d ",_DB_OBJ_FULL,$this->RiskId);
		$pStatement = $this->dbHand->prepare($sql);

		/*$pStatement->bindParam(1,$this->RiskId);*/
		$pStatement->execute();

		$improvements = $pStatement->fetchColumn();
		$new_improvements = $improvements.','.$this->RiskInfo['new_improvement'];

		$sql2 = sprintf("UPDATE risk SET improvements = '%s' WHERE ID = %d ",$new_improvements,$this->RiskId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		/*$pStatement2->bindParam(1,$new_improvements);
		$pStatement2->bindParam(2,$this->RiskId);*/
		$pStatement2->execute();
	}



	public function sendActionAlerts($p_record_id) {

		$this->RiskId = $p_record_id;

		$record_data = $this->viewHazardAssessment();

		$improvement_data = $this->viewImprovementRisk();

		$objProcessMaster 	= new ProcessFlowMaster();
		$process_data = $objProcessMaster->displayProcessFlowById($record_data['processID']);

		$process_details['process_title'] = $process_data['reference'];
		$process_details['description'] = $process_data['description'];

		if ( count($improvement_data['improvements']) ) {
			$i = 0;
			foreach ( $improvement_data['improvements'] as $value ) {

				$email_data[$i]					 	= $process_details;
				$email_data[$i]['summary']		 	= $value['actionDescription'];
				$email_data[$i]['due_date']		 	= format_date($value['dueDate']);
				$email_data[$i]['who']			 	= $value['who'];
				$email_data[$i]['whoAU']			 	= $value['whoAU'];
				$email_data[$i]['hazard_summary']	= $record_data['hazardSummary'];
				$email_data[$i]['control_summary']	= $record_data['controlSummary'];

				$this->actionHandling->updateStatus($value['ID']);
				$i++;
			}
		}

		return $email_data;
	}

	public function sendInvalidAssessmentAlert($p_record_id) {

		$pfObj = new ProcessFlowMaster();
		$processdata = $pfObj->displayProcessFlowById($p_record_id);

		$email_data['process_id']	 = $processdata['swimID'];
		$email_data['process_ref']	 = $processdata['reference'];
		$email_data['process_desc']	 = $processdata['description'];
		$email_data['process_bu']	 = $processdata['buName'];
		$email_data['who']			 = $processdata['whoID'];

		$email_data_final[0] = $email_data;

		return $email_data_final;

		//dump_array($processdata);
	}

	public function getRiskRecordsDse() {

		$sql = sprintf("SELECT * FROM %s.risk ",_DB_OBJ_FULL);

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);

		if ( count($records) ) {
			foreach ( $records as $value ) {
				if ( $value['dseAssessment'] != '' && $value['dseAssessment'] != 0 ) {
					$process_no = $value['processID'];
					$graph_data[$process_no] = $value['dseAssessment'];
				}

			}
		}

		//dump_array($graph_data);
		return $graph_data;
	}

	public function deleteStepAssessment() {
		$step_data = $this->viewHazardAssessment();
		$files = $this->getRiskFileDetails();

		if ( $step_data['improvements'] != '' ) {
			$action_arr = explode(',',$step_data['improvements']);
			if ( count($action_arr) ) {
				foreach( $action_arr as $value ) {
					$this->actionHandling->setActionDetails($value,"");
					$this->actionHandling->deleteAction();
				}
			}
		}

		if ( count($files) ) {
			$objFile = new Upload();
			foreach ( $files as $value ) {
				$objFile->setFileInfo('process_risk_assessment',array('id'=>$value['uploadedFileID'],'destination'=>'process_risk_assessment'));
				$objFile->delete_file();
			}
		}

		$sql1 = sprintf("DELETE FROM %s.risk_files WHERE riskID = %d",_DB_OBJ_FULL,$this->RiskId);
		$pStatement1 = $this->dbHand->prepare($sql1);

		//$pStatement1->bindParam(1,$this->RiskId);
		$pStatement1->execute();

		$sql2 = sprintf("DELETE FROM %s.risk WHERE ID = %d",_DB_OBJ_FULL,$this->RiskId);
		$pStatement2 = $this->dbHand->prepare($sql2);

		//$pStatement2->bindParam(1,$this->RiskId);
		$pStatement2->execute();

	}

	private function moveFiles($p_identifier) {
		$rec_id = $this->RiskId;

		$module = 'process_risk_assessment';

		$path = _MYROOT.'tmp/'.$module.'/'.$p_identifier;
		//exit;

		$log_file = $path.'/script'.$rec_id.'.log';

		if ( file_exists($log_file) ) {

			$log = fopen($log_file, 'r');
			$contents = fread($log, filesize($log_file));
			fclose($log);

			$file_records = explode("\n",$contents);

			$objFile = new Upload();
			//$this = new RiskAssessment();

			if ( count($file_records) ) {
				foreach ( $file_records as $value ) {
					if ( $value != '' ) {

						$file_details_arr = explode('~#~',$value);
						$file_path = $path.'/'.$file_details_arr[1];

						if ( file_exists($file_path)) {

							$file_type = mime_content_type($file_path);

							$file_details = array('user_file_name'=>$file_details_arr[2],'file_type'=>$file_type);
							$objFile->setFileInfo($module,$file_details);
							$objFile->setBogusDetails($file_details);
							$objFile->uploadifyAddFileDb();
							$sys_file_name = $objFile->uploadifySysFileName();

							$new_file_path = _PATH_PUB.$module.'/'.$sys_file_name;
							//	echo "<br/>";

							if ( copy($file_path,$new_file_path )) {

								$objFile->updateUploadifyFileName();
								$file_id = $objFile->getLastFileId();

								if ($file_id ) {
									$data_array = array('file_id'=>$file_id,'identifier'=>$p_identifier);
									$this->setRiskInfo($rec_id,$data_array);
									$this->addRiskFiles();
								}

								unlink($file_path);
							}
						}
					}
				}
			}


			unlink($log_file);

		}


	}

	public function copyRiskAssessmentByBu($source_process,$sel_business_unit) {

		$procObj = new ProcessFlowMaster();

		if ( is_array($sel_business_unit) ) {

			$process_data = $procObj->displayProcessFlowById($source_process);

			$process_mapping = array();

			// create processes
			foreach ( $sel_business_unit as $business_unit_ele ) {

				$unique_reference_number = UniqueReference::getNumber('PROCESSFLOW');

				$procObj->setProcessMasterInfo(0,$business_unit_ele,$unique_reference_number,$unique_reference_number,$process_data['description'],$process_data['swimID'],$source_process);
				$process_id 	= $procObj->addProcessMaster(true);
				$process_mapping[$business_unit_ele] = $process_id;
			}

			//dump_array($process_mapping);

			$tables = array();

			$tables[] 	= 'risk';
			$tables[]	= 'risk_files';

			foreach ( $tables as $table_ele ) {

					$table_ele_arr = explode("_",$table_ele);

					$method_name = '';

					foreach ( $table_ele_arr as $table_ele_arr_ele ) {
						$method_name .= ucfirst($table_ele_arr_ele);
					}

					$method_name = 'copyRA'.$method_name;

					foreach ( $process_mapping as $p_dest_process ) {

						//echo "call $method_name $source_process $p_dest_process<br/>";
						$this->$method_name($source_process,$p_dest_process);
					}


			}

			$proObj = null;
		}
	}

	public function copyRiskAssessmentByBuDeprecatedjan($p_sourceBuID,$p_destinationBuID,$p_sel_processes) {

		$procObj = new ProcessFlowMaster();

		if ( is_array($p_sel_processes) ) {
			$process_data = $procObj->getProcessBySelProcess($p_sel_processes);
		} else {
			$process_data = $procObj->getProcessByBuID($p_sourceBuID);
		}

		$unique_reference_number = UniqueReference::getNumber('PROCESSFLOW');

		$process_mapping = array();

		// create processes
		foreach ( $process_data as $process_data_ele ) {
			$procObj->setProcessMasterInfo(0,$p_destinationBuID,$unique_reference_number,$unique_reference_number,$process_data_ele['description'],$process_data_ele['swimID'],$process_data_ele['parentSwimID']);
			$process_id 	= $procObj->addProcessMaster(true);
			$process_mapping[$process_data_ele['swimID']] = $process_id;
		}

		$tables = array();

		$tables[] 	= 'risk';
		$tables[]	= 'risk_files';

		foreach ( $tables as $table_ele ) {
			$method_name_arr = explode('_',$table_ele);

			$method_name = '';

			foreach ( $method_name_arr as $method_name_ele ) {
				$method_name .= ucfirst($method_name_ele);
			}

			$method_name = 'copyRA'.$method_name;

			foreach ( $process_mapping as $p_src_process=>$p_dest_process ) {
				$this->$method_name($p_src_process,$p_dest_process);
			}
		}

		$proObj = null;

	}

	private function copyRARisk($p_src_process,$p_dest_process) {

		$sql = sprintf("SELECT * FROM %s.risk
				WHERE processID = %d
				ORDER BY ID ASC",_DB_OBJ_FULL,$p_src_process);

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->sourceProcessFlow);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $result_ele ) {

			$ins = sprintf("INSERT %s.risk (processID,
							processStepID,
							hazardClassificationID,
							dseAssessment,
							hazardsID,
							secondaryHazardID,
							hazardSymbols,
							hazardSummary,
							controlAlongPath,
							controlAtWorker,
							controlSymbols,
							controlSummary,
							likelihood1,
							impact1,
							riskRating1,
							riskRatingColor1,
							improvementAtSource,
							improvementAlongPath,
							improvementAtWorker,
							improvements,
							noImprovement,
							improvementReason,
							likelihood2,
							impact2,
							riskRating2,
							riskRatingColor2,
							timeTrouble,
							netImpact,
							priority,
							status,
							archive,
							whoID,
							overrulereason)
							VALUES(%d, %d, %d, '%s', %d,
							'%s', '%s', '%s', %d, %d,
							'%s', '%s', %d, %d, '%s',
							'%s', '%s', '%s', '%s', '%s',
							'%s', '%s', %d, %d, '%s',
							'%s', %d, %d, '%s', '%s',
							'%s', %d,'%s')",
							_DB_OBJ_FULL,
							$p_dest_process,$result_ele['processStepID'],$result_ele['hazardClassificationID'],	$result_ele['dseAssessment'], $result_ele['hazardsID'],
							$result_ele['secondaryHazardID'],$result_ele['hazardSymbols'],$result_ele['hazardSummary'],$result_ele['controlAlongPath'],	$result_ele['controlAtWorker'],
							$result_ele['controlSymbols'],$result_ele['controlSummary'],$result_ele['likelihood1'],$result_ele['impact1'],$result_ele['riskRating1'],
							$result_ele['riskRatingColor1'],$result_ele['improvementAtSource'],$result_ele['improvementAlongPath'],	$result_ele['improvementAtWorker'],$result_ele['improvements'],
							$result_ele['noImprovement'],$result_ele['improvementReason'],$result_ele['likelihood2'],$result_ele['impact2'],$result_ele['riskRating2'],
							$result_ele['riskRatingColor2'],$result_ele['timeTrouble'],	$result_ele['netImpact'],$result_ele['priority'],$result_ele['status'],
							$result_ele['archive'],	$result_ele['whoID'],$result_ele['overrulereason']);

			$stmt_ins 	= $this->dbHand->prepare($ins);
			//echo $ins;
			//echo "<br/>";
			//$stmt_ins->execute();
		}

	}

	private function copyRARiskFiles() {

		$sql = sprintf("SELECT * FROM %s.risk_files
				WHERE riskID = %d
				ORDER BY ID ASC",_DB_OBJ_FULL,$p_src_process);

		$stmt 		= $this->dbHand->prepare($sql);

		/*$stmt->bindParam(1,$this->sourceProcessFlow);*/
		$stmt->execute();

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ( $result as $result_ele ) {

			$ins = sprintf("INSERT %s.risk_files (
						    riskID,
							section,
							uploadedFileID)
							VALUES(%d, '%s', %d)",
							_DB_OBJ_FULL,
							$result_ele['riskID'],$result_ele['section'], $result_ele['uploadedFileID']);

			$stmt_ins 	= $this->dbHand->prepare($ins);
			$stmt_ins->execute();
		}

	}

	public function getListingforExport($p_identifier) {

		$p_identifier_arr = explode('#',$p_identifier);
		$p_identifier = $p_identifier_arr[0];

		switch($p_identifier) {
			case 1 : $reportdata = $this->exportMainList(); break;
			case 2 : $reportdata = $this->exportProcessSetp(); break;
			case 3 : $reportdata = $this->exportAssessments(); break;
		}

		return $reportdata;
	}

	private function exportMainList() {

		$participantObj	 	= SetupGeneric::useModule('Participant');

		$heading = array(array('refrence'=>'Reference #','bu'=>'Business Unit','who'=>'Who', 'desc'=>'Description'));

		$RiskData 	= $this->getRiskAssessmentProcesses();
		$processFlowCount	= count($RiskData);

		if ($processFlowCount) {
			$i=0;
			foreach ( $RiskData as $RiskDataEle ) {

				$participant_id = $RiskDataEle['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

				$process_ref = preg_replace('/PF/','PR',$RiskDataEle['reference']);

				$result[$i]['ref']	 = $process_ref;
				$result[$i]['bu']	 = $RiskDataEle['buName'];
				$result[$i]['who']	 = $participant_name;
				$result[$i]['desc']	 = str_replace(',','',$RiskDataEle['description']);

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
	}

	private function exportProcessSetp() {

		$heading = array(array('Step'=>'Step','desc'=>'Description','ph'=>'Primary Hazards','sh'=>'Secondary Hazards','cr'=>'Completed RA',
							   'oa'=>'Open Actions','ova'=>'Overdue Actions'));


		$p_process = $_GET['process_id'];

		$this->setRiskInfo(0,array('process_id'=>$p_process));
		$RiskData 	= $this->getStepsByProcess();
		$processFlowCount	= count($RiskData);

		if ($processFlowCount) {
			$i=0;
			foreach ( $RiskData as $RiskDataEle ) {

				$this->setRiskInfo(0,array('process_id'=>$p_process,'step_id'=>$RiskDataEle['ID'],'archive'=>'0'));
				$data = $this->getHazardsByProcessStep();

				$step_assessment_counts = (int) count($data);

				$secondary_hazards = $this->secondaryHazardCount();

				$this->setRiskInfo(0,array('process_id'=>$p_process,'step_id'=>$RiskDataEle['ID'],'status'=>0));
				$open_actions = $this->openActions();

				$this->setRiskInfo(0,array('process_id'=>$p_process,'step_id'=>$RiskDataEle['ID'],'status'=>1));
				$completed_actions = $this->openActions();



				$result[$i]['step'] = ($i+1);
				$result[$i]['desc'] = str_replace(',','',$RiskDataEle['descQues']);
				$result[$i]['ph'] = $step_assessment_counts;
				$result[$i]['sh'] = $secondary_hazards;
				$result[$i]['cr'] = $completed_actions;
				$result[$i]['oa'] = $open_actions;
				$result[$i]['ova'] = '0';

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
	}

	private function exportAssessments() {

		$heading = array(array('Step'=>'S. No.','hzd'=>'Hazard','who'=>'Who','hs'=>'Hazard Summary'));


		$p_process	 = $_GET['process_id'];
		$step_id	 = $_GET['step_id'];

		$participantObj	 	= SetupGeneric::useModule('Participant');
		$hazardClass = SetupGeneric::useModule('HazardClassification');

		$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');

		$this->setRiskInfo(0,array('process_id'=>$p_process,'step_id'=>$step_id,'archive'=>$archive_session));
		$data = $this->getHazardsByProcessStep();

		if ( count($data) ) {
			$i=0;
			foreach ( $data as $value ) {

				$hazardClass->setItemInfo(array(
												'id'=>$value['hazardClassificationID']
												));
				$dataPrimaryHazard = $hazardClass->displayCategoryById();

				$participant_id = $value['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];



				$result[$i]['step'] = ($i+1);
				$result[$i]['hzd'] = $dataPrimaryHazard['primaryHazard'];
				$result[$i]['who'] = $participant_name;
				$result[$i]['hs'] = str_replace(',','',$value['hazardSummary']);

				$i++;
			}
		}

		$result = array_merge($heading,$result);
		return $result;
	}

	public function getAllRiskAssessments() {
		$sql = sprintf("SELECT * FROM %s.risk ORDER By ID DESC",_DB_OBJ_FULL);

		$stmt 	= $this->dbHand->prepare($sql);
		$stmt->execute();

		$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $records;
	}

	public function getEmailData($p_record_id) {

		$sql = sprintf("SELECT * FROM %s.risk ",_DB_OBJ_FULL);
		$sql = $sql." WHERE improvements LIKE '".$p_record_id."' OR improvements LIKE '%,".$p_record_id."' OR improvements LIKE '".$p_record_id.",%' OR improvements LIKE '%,".$p_record_id.",%' ";

		$pStatement = $this->dbHand->prepare($sql);
		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);

		if ( $result ) {

			$mail_data['bu_id']				 = $result['buID'];
			$mail_data['process_no']		 = $result['processReference'];
			$mail_data['hazard']			 = $result['hazardSummary'];

		}

		return $mail_data;
	}

	public function updateStepStatus() {
		$sql = sprintf("UPDATE %s.swimlane_data SET assessmentDone='%s',assessmentReason = '%s' WHERE ID = %d",_DB_OBJ_FULL,
					   $this->RiskInfo['done'],$this->RiskInfo['reason'],$this->RiskInfo['step_id']);

		$stmt 	= $this->dbHand->prepare($sql);
		$stmt->execute();
	}

	public function eliminateHazard() {
		$sql = sprintf("SELECT * FROM %s.risk WHERE ",_DB_OBJ_FULL);

		$sql .= " improvements LIKE '".$this->RiskInfo['action_id']."' OR improvements LIKE '".$this->RiskInfo['action_id'].",%' OR
		improvements LIKE '%,".$this->RiskInfo['action_id']."' OR improvements LIKE '%,".$this->RiskInfo['action_id'].",%'";

		$stmt 	= $this->dbHand->prepare($sql);
		$stmt->execute();

		$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ( count($data) ) {
			$this->setRiskInfo($data[0]['ID'],array('archive'=>'1'));
			$this->archiveRisk();
		}
	}
}
?>