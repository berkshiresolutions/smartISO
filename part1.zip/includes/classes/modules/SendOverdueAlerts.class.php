<?php
 /**
  $Id: SendActionAlerts.class.php,v 3.17 Friday, February 04, 2011 3:21:19 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Alert Class
  * @since  Saturday, December 04, 2010 4:17:45 PM>
  */
class SendOverdueAlerts extends Email
{
	private $moduleName;
	private $mailData;
	private $participantObj;
	private $emailObj;
	private $moduleClassobj;

	public function __construct($p_module,$p_mail_data) {

		$this->moduleName = $p_module;
		$this->mailData = $p_mail_data;
		$this->participantObj = SetupGeneric::useModule('Participant');
	}

	public function sendAlerts() {
		/*$dyn_function_name = ucwords($this->moduleName).'Alerts';
		$this->$dyn_function_name();*/
		/*dump_array($this->mailData);
		exit;*/


		if ( $dyn_function_name == 'InspectionAlerts' ) {

			switch ( $this->mailData[0]['tab'] ) {
				case 2: $this->moduleName = 'INSPECTIONC'; break;
				case 3: $this->moduleName = 'INSPECTIONR'; break;
				case 4: $this->moduleName = 'INSPECTIONM'; break;
				case 5: $this->moduleName = 'INSPECTIONH'; break;
				case 6: $this->moduleName = 'INSPECTIONAH'; break;
			}
		}

		$this->formatData();
		/*dump_array($this->mailData);
		exit;*/

		$email_token =  strtoupper($this->moduleName);

		if ( $this->mailData['email'] != '' ) {

			//dump_array($value);
			$this->emailObj = new Email('html');
			try {

				$this->emailObj->addRecipient($this->mailData['who'],$this->mailData['email'],$this->mailData['salutation']);
				$this->emailObj->generateEmail('OVERDUEACTIONS',$this->mailData);
				$this->emailObj->send(true);

			} catch (ErrorException $e) {
				$e->getMessage();
			}
		}

		//return $this->mailData;
		//exit;
	}

	private function formatData() {
		
		//echo $this->mailData['module'];
		switch($this->moduleName) {
			case 'risk' : $this->mailData['module']				 = 'Risk Assessment'; break;
			case 'risk27k' : $this->mailData['module']			 = 'Risk27K'; break;
			case 'incidence' : $this->mailData['module']		 = 'Incidence'; break;
			case 'investigation' : $this->mailData['module']	 = 'Investigation'; break;
			case 'nhc' : $this->mailData['module']				 = 'NHC'; break;
			case 'dse' : $this->mailData['module']				 = 'DSE Assessment'; break;
			case 'mh' : $this->mailData['module']				 = 'Manual Handling'; break;
			case 'inspection' : $this->mailData['module']		 = 'Inspection'; break;
		}
		$this->mailData['reference']	 = $this->mailData['reference'];
		$this->mailData['summary']		 = $this->mailData['actionDescription'];
		$this->mailData['due_date']		 = $this->mailData['dueDate'];
		$this->mailData['who']			 = $this->mailData['who'];

		$this->participantObj->setItemInfo(array(
						'id'=>$this->mailData['who']
						));

		$participant_details	= $this->participantObj->displayItemById();

		if ( $participant_details['gender'] == 'F' ) {
			$salutation = 'Ms.';
		} else {
			$salutation = 'Mr.';
		}


		$this->mailData['who'] = $participant_details['forename'].' '.$participant_details['surname'];
		$this->mailData['email'] = $participant_details['emailAddress'];
		$this->mailData['salutation'] = $salutation;
		
		
	}
 }
?>