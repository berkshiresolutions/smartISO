<?php
 /**
  $Id: ActionTrackerInspection.class.php,v 3.78 Tuesday, February 01, 2011 5:46:36 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerInsp extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;
        
            public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
        $this->sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,I.ID from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on I.locationid=L.locID  where modulename='inspectionD'  and A.status=1  and currentWho=%d and approveAU=0
							ORDER BY I.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
        $this->sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentwho,I.ID from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on I.locationid=L.locID  where modulename='inspectionD'  and A.status=1 and A.who=%d and approveAU=1
							ORDER BY I.ID DESC",  _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


        return $this->getActionsByFilter(__METHOD__);
    }

    public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();


        if (isAdministrator()) {
			
			$this->sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on I.locationid=L.locID where modulename='inspectionD'   and approveAU=0 and not currentWho=%d
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);        
} else {
		$this->sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on I.locationid=L.locID  where modulename='inspectionD'  and approveAU=0 and whoAU=%d
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

        return $this->getActionsByFilter(__METHOD__);
    }

    public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {
	             $this->sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on I.locationid=L.locID  where modulename='inspectionD'  and approveAU=1 and not A.who=%d
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
             $this->sql_query = sprintf("select A.id,I.reference,L.name,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,A.currentWho,I.ID from %s.actions A  left join %s.Inspection I on A.record=I.ID left join %s.locationgram L on I.locationid=L.locID  where modulename='inspectionD'  and approveAU=1 and whoAU=%d
							ORDER BY M.ID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }
       
        return $this->getActionsByFilter(__METHOD__);
    }

    private function getActionsByFilter($p_callingMethod) {

        $USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
        //echo $calling_method;

        $pStatement = $this->dbHand->prepare($this->sql_query);
        $pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
    }
}