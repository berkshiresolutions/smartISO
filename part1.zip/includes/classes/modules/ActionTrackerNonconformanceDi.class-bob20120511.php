<?php
 /**
  $Id: ActionTrackerNonconformanceDi.class.php,v 3.47 Wednesday, January 26, 2011 6:07:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerNonconformanceDi extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;

	public function getPendingMeActions() {

		$this->sql_query = sprintf("SELECT M.reference,N.buID,M.actionsID FROM %s.investigation M
								   INNER JOIN %s.incidence N ON N.ID=M.incID
							WHERE M.actionsID IS NOT NULL
							ORDER BY M.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedMeActions() {

		$this->sql_query = sprintf("SELECT M.reference,N.buID,M.actionsID FROM %s.investigation M
								   INNER JOIN %s.incidence N ON N.ID=M.incID
							WHERE M.actionsID IS NOT NULL
							ORDER BY M.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getPendingOtherActions() {

		$this->sql_query = sprintf("SELECT M.reference,N.buID,M.actionsID FROM %s.investigation M
								   INNER JOIN %s.incidence N ON N.ID=M.incID
							WHERE M.actionsID IS NOT NULL
							ORDER BY M.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedOtherActions() {

		$this->sql_query = sprintf("SELECT M.reference,N.buID,M.actionsID FROM %s.investigation M
								   INNER JOIN %s.incidence N ON N.ID=M.incID
							WHERE M.actionsID IS NOT NULL
							ORDER BY M.ID DESC",_DB_OBJ_FULL,_DB_OBJ_FULL);

		return $this->getActionsByFilter(__METHOD__);
	}

	private function getActionsByFilter($p_callingMethod) {

		$USER_ID = getLoggedInUserId();

		$p_callingMethod_arr 	= explode('::',$p_callingMethod);
		$calling_method 		= $p_callingMethod_arr[1];
		//echo $calling_method;

		$pStatement = $this->dbHand->prepare($this->sql_query);

		$pStatement->execute();

		$result 				=  $pStatement->fetchAll(PDO::FETCH_ASSOC);
		$this->new_resultset 	= array();

		$organoObj = SetupGeneric::useModule('Organigram');

		if ( $result ) {
			foreach ( $result as $result_element ) {

				if ( $result_element['actionsID'] != '' ) {

					$actions_arr = explode(',',$result_element['actionsID']);

					foreach ( $actions_arr as $actions_ele ) {

						$organoObj->setItemInfo(array('id'=>$result_element['buID']));
						$business_unit_arr = $organoObj->displayItemByIdForMSR();

						$this->new_resultset[$actions_ele] = array('reference'=>$result_element['reference']
																  ,'buID'=>$result_element['buID']
																  ,'buName'=>$business_unit_arr['buName']);
					}

				}
			}
		}

		$organoObj = null;

		$module_info = array();
		//dump_array($module_info);

		//echo $calling_method;

		if ($this->moduleInfo) {

			$participantObj = SetupGeneric::useModule('participant');

			foreach ( $this->moduleInfo as $module_element ) {

				$participantObj->setItemInfo(array('id'=>$module_element['who']));
				$participant_arr 				= $participantObj->displayItemMaininfoById();
				$module_element['who_name'] 	= $participant_arr['forename'].' '.$participant_arr['surname'];

				$module_element['approve'] = (int) $module_element['approve'];

				if ( $calling_method == 'getPendingMeActions' ) {

					if ( ( $USER_ID == $module_element['who'] || $USER_ID == $module_element['whoAU'] ) && !$module_element['approve'] ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getPendingOtherActions' ) {

					if ( $USER_ID != $module_element['who'] && $module_element['who'] != 0 && !$module_element['approve'] ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedMeActions' ) {

					if ( ( $USER_ID == $module_element['who'] || $USER_ID == $module_element['whoAU'] ) && $module_element['approve'] ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				} else if ( $calling_method == 'getCompletedOtherActions' ) {

					if ( $USER_ID != $module_element['who'] && $module_element['who'] != 0 && $module_element['approve'] ) {
						$module_info[$module_element['ID']] = $module_element;
					}
				}
			}
		}

		//dump_array($this->new_resultset);

		ksort($module_info);
		$module_info = array_reverse($module_info,true);
		ksort($this->new_resultset);

		array_walk( $module_info,array($this,'combine_actions_with_data'));

		return $module_info;

	}

	private function combine_actions_with_data( $item,$key) {

		$item['reference'] 		= $this->new_resultset[$key]['reference'];
        $item['buID'] 			= $this->new_resultset[$key]['buID'];
		$item['buName'] 		= $this->new_resultset[$key]['buName'];
	}
}