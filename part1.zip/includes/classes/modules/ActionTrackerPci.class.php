<?php
 /**
  $Id: ActionTrackerNonconformanceInc.class.php,v 3.51 Wednesday, January 26, 2011 5:58:26 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Classes
  * @since  Friday, November 19, 2010 4:50:09 PM>
  */


require_once "ActionTracker.abs.php";

class ActionTrackerPci extends AbstractActionTracker
{

	private $new_resultset;
	private $sql_query;

	public function getPendingMeActions() {
        $USER_ID = getLoggedInUserId();
		$this->sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,S.swimID from %s.actions A  inner join %s.swimlane S on A.record=S.swimID  left join %s.business_units B on S.buid=B.buID where modulename='pci'  and A.status=1  and currentWho=%d and approveAU=0
   						ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedMeActions() {
        $USER_ID = getLoggedInUserId();
		$this->sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,S.swimID from %s.actions A  inner join %s.swimlane S on A.record=S.swimID  left join %s.business_units B on S.buid=B.buID where modulename='pci' and A.who=%d and approveAU=1
  							ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);


		return $this->getActionsByFilter(__METHOD__);
	}

	public function getPendingOtherActions() {
        $USER_ID = getLoggedInUserId();


        if (isAdministrator()) {
					$this->sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.swimID from %s.actions A  inner join %s.swimlane S on A.record=S.swimID  left join %s.business_units B on S.buid=B.buID where modulename='pci'  and A.status=1   and approveAU=0 and not currentWho=%d
							ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
                       		$this->sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.currentWho,S.swimID from %s.actions A  inner join %s.swimlane S on A.record=S.swimID left join %s.business_units B on S.buid=B.buID where modulename='pci'  and A.status=1  and approveAU=0 and whoAU=%d
							ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

		return $this->getActionsByFilter(__METHOD__);
	}

	public function getCompletedOtherActions() {
        $USER_ID = getLoggedInUserId();
        if (isAdministrator()) {

			$this->sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,S.swimID from %s.actions A  inner join %s.pci_answer S on a.record=S.ID left join %s.business_units B on S.buid=B.buID where modulename='pci'  and approveAU=1 and not A.who=%d
							ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        } else {
         			 $this->sql_query = sprintf("select A.id,S.reference,B.buName,S.description,A.who,A.dueDate,A.doneDate,A.addapprover,A.app2date,A.actionDescription,A.whoAU,S.swimID from %s.actions A  inner join %s.swimlane S on A.record=S.swimID left join %s.business_units B on S.buid=B.buID where modulename='pci'  and approveAU=1 and whoAU=%d
							ORDER BY S.swimID DESC", _DB_OBJ_FULL, _DB_OBJ_FULL, _DB_OBJ_FULL, $USER_ID);
        }

		return $this->getActionsByFilter(__METHOD__);
	}

	private function getActionsByFilter($p_callingMethod) {

		$USER_ID = getLoggedInUserId();

        $p_callingMethod_arr = explode('::', $p_callingMethod);
        $calling_method = $p_callingMethod_arr[1];
		//echo $calling_method;

		$pStatement = $this->dbHand->prepare($this->sql_query);
		$pStatement->execute();

        $result = $pStatement->fetchAll(PDO::FETCH_ASSOC);


        return $result;
					}
				}
