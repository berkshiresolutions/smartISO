<?php
 /**
  $Id: Db.class.php,v 3.22 Monday, February 07, 2011 5:47:11 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @subpackage Classes
  * @since  Saturday, August 14, 2010 5:56:58 PM>
  */

/**
 * A setup class for managing smartlaw setup operations, this is grouped with
 * other classes in the "Smartiso" package and
 * is part of "Classes" and "Setup" subpackage
 */
class DB
{

	public static function connect($p_db_type) {

		if ( $p_db_type == 'mysql' ) {
      //print_r('use mysql');
			try {
				return new PDO("mysql:host="._DB_HOST.";dbname="._DB_NAME,_DB_USER,_DB_PASS,array(PDO::ATTR_PERSISTENT => true));
			} catch (PDOException $e) {
				return "Error!: " . $e->getMessage() . "<br/>";
			}
		} else if ( $p_db_type == 'mssql' ) {
      //print_r('use mssql');
			try {
				return new PDO('odbc:' . _DB_ODBC_OBJ,_DB_USER,_DB_PASS);
				//return new PDO("mssql:host="._DB_HOST.";dbname="._DB_NAME,_DB_USER,_DB_PASS,array(PDO::ATTR_PERSISTENT => true));
			} catch (PDOException $e) {
				return "Error!: " . $e->getMessage() . "<br/>";
			}
		} else if ($p_db_type == 'sqlsrv') {

        //print_r('use slq srv');
        try {
			
          return new PDO( 'sqlsrv:server=localhost; Database='._DB_NAME, _DB_USER,_DB_PASS);
        } catch (PDOException $e) {
          return "Error!: " . $e->getMessage() . "<br/>";
        }

    }


	}
}
?>