<?php
/**
  $Id: access_control.inc.php,v 4.17 Friday, February 04, 2011 2:51:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Access Control
  * @since  Wednesday, November 10, 2010 6:22:41 PM>
  */




/* to check nspection frequency */
$url_arr =  explode('/',$_SERVER['SCRIPT_NAME']);
//print_r($url_arr);
//echo basename($url_arr[2]);
if ( $url_arr[1] == 'inspection' ) {

	$inspObj = new InspectionMain();
	$outObj = new OutstandingActions();
	$insp_frq = SetupGeneric::useModule('Inspection');
	$inspection_id = $_GET['id'];

	$inspObj->setInspectionInfo($inspection_id,"");
	$inspection_data = $inspObj->viewInspectionById();

	$ADDITIONAL_HAZARD_PRESENT = false;
	$OUTSTANDING_PRESENT = false;

	$action = $_SESSION['action'];

	/****** outstanding actions ******/

	$outstanding_actions_count = 0;
	$modules = array('Inspection'=>'inspectionMain','Risk'=>'riskAssessment','Risk 27k'=>'risk27k',
						 'Incidence'=>'IncidenceMain','Investigation'=>'InvestigationMain',
						 'NHC'=>'NhpMain','DSE'=>'DseAssessment','Manual Handling'=>'ManualHandling');

	foreach ( $modules as $modName=>$modVal ) {
		$overdue_actions = '';
		$overdue_actions = $outObj->getModuleActions($modVal,false,$inspection_data['buID']);
if (is_array($overdue_actions))
		$outstanding_actions_count += count($overdue_actions);
	}
	//$outstanding_actions = $inspObj->getTotalOutstandingActions(1);
	if ( $outstanding_actions_count ) {
		$OUTSTANDING_PRESENT = true;
	}

	/***********/

	/****** overdue actions ******/
	$overdue_actions_count = 0;
	$modules = array('Inspection'=>'inspectionMain','Risk'=>'riskAssessment','Risk 27k'=>'risk27k',
						 'Incidence'=>'IncidenceMain','Investigation'=>'InvestigationMain',
						 'NHC'=>'NhpMain','DSE'=>'DseAssessment','Manual Handling'=>'ManualHandling');

	foreach ( $modules as $modName=>$modVal ) {
		$overdue_actions = '';
               
		$overdue_actions = $outObj->getModuleActions($modVal,true,$inspection_data['buID']);
if (is_array($overdue_actions))
		$overdue_actions_count += count($overdue_actions);
	}
	//$overdue_actions = $inspObj->getTotalOutstandingActions(3);
        
	if ( $overdue_actions_count ) {
		$OVERDUE_PRESENT = true;
	}

	/***********/

	if ( $inspection_id ) {
		/* get inspection details */
		$inspection_id = $_GET['id'];
		$inspObj->setInspectionInfo($inspection_id,"");
		$inspection_data = $inspObj->viewInspectionById();
		/*****************/

		/* Check frequency */
		$data = $insp_frq->displayFrequencyItemByBuId($inspection_data['buID']);
		$freq_flag = $inspObj->ispectionFrequencies($data,$inspection_data['whenDate']);

		$insp_count = $inspObj->getInspectionCountByBu($inspection_data['buID']);

		/* Additional hazard count */
		$inspObj->setInspectionInfo($inspection_id,array('section'=>6));
		$additional_hazards = $inspObj->getAddtionalHazardCount();
		/***********************/

		$ADDITIONAL_HAZARD_PRESENT = false;

		if ( $additional_hazards ) {
			$ADDITIONAL_HAZARD_PRESENT = true;
		}

	}

	if ( $url_arr[2] == 'add_edit_additional_hazard.php' ) {

		$ADDITIONAL_HAZARD_PRESENT = true;
	}

}

$script_name = $_SERVER['SCRIPT_NAME'];
$script_name_arr = explode('/',$script_name);


/* to close the popup window on session out*/
if ($_HIDE_HTTP_HEADER && $script_name_arr[1] != 'authentication') {

	if ( !isLoggedIn() ) {

		$script = "<script>if (window.opener && !window.opener.closed) {
						window.opener.location.reload();
					}
						self.close();
					</script>";
		echo $script;
		exit;
	}
}

/* redirected to login page when logged out*/
if ( $script_name_arr[1] != 'authentication' ) {

	//$USER_NAME 		= Session::getSessionField('SESS_USER_NAME');

	if ( !isLoggedIn() ) {
	$_SESSION['SMARTISO_PATH'] = $_SERVER["REQUEST_URI"];
		redirection(_MYSECURESERVER.'/authentication/login.php');
	}
}

$USER_LEVEL = getUserAccessLevel();// Session::getSessionField('SESS_USER_LEVEL');
//echo $USER_LEVEL;
if ($USER_LEVEL == 1) {
    $PERMISSIONS['PERM_PF'] = true;
    $PERMISSIONS['PERM_MSR'] = true;
    $PERMISSIONS['PERM_ISR'] = true;
    $PERMISSIONS['PERM_RISK'] = true;
    $PERMISSIONS['PERM_INV'] = true;
    $PERMISSIONS['PERM_INSP'] = true;
    $PERMISSIONS['PERM_NHC'] = true;
    $PERMISSIONS['PERM_CMS'] = true;
    $PERMISSIONS['PERM_CONT'] = true;
    $PERMISSIONS['PERM_CC'] = _ALLOW_CUST_COMPLAINT == 1 ? true : false;
    $PERMISSIONS['PERM_DSE'] = true;
    $PERMISSIONS['PERM_EQ'] = true;
    $PERMISSIONS['PERM_MH'] = true;
    $PERMISSIONS['PERM_SL'] = true;
    $PERMISSIONS['PERM_TG'] = true;
    $PERMISSIONS['PERM_TM'] = true;
    $PERMISSIONS['PERM_FD'] = true;
    $PERMISSIONS['PERM_EM'] = true;
    $PERMISSIONS['PERM_CNTRB'] = true;
    $PERMISSIONS['PERM_ACCREP'] = true;
    $PERMISSIONS['PERM_DOC'] = true;
    $PERMISSIONS['PERM_DOC_VIEW'] = true;
    $PERMISSIONS['PERM_INC'] = true;
    $PERMISSIONS['PERM_INC_ING'] = true;
    $PERMISSIONS['PERM_NHC_ING'] = true;
    $PERMISSIONS['PERM_FLEET'] = true;
    $PERMISSIONS['PERM_SMART'] = true;
    $PERMISSIONS['RISK27K'] = true;
    $PERMISSIONS['SOA'] = _ALLOW_SOA == 1 ? true : false;
    $PERMISSIONS['INS'] = true;
    $PERMISSIONS['PERM_PERSON'] = true;
    $PERMISSIONS['PERM_BCA'] = _ALLOW_BCP == 1 ? true : false;
    $PERMISSIONS['PERM_BCP'] = _ALLOW_BCP == 1 ? true : false;
    $PERMISSIONS['PERM_BCPI'] = _ALLOW_BCP == 1 ? true : false;
    $PERMISSIONS['PERM_PCI'] = _ALLOW_PCI == 1 ? true : false;
    $PERMISSIONS['PERM_HOC'] = true;
    $PERMISSIONS['PERM_TE'] = true;
    $PERMISSIONS['PERM_IE'] = true;
    $PERMISSIONS['PERM_COM'] = true;
    $PERMISSIONS['PERM_LAW'] = true;
    $PERMISSIONS['PERM_GOV'] = true;
    $PERMISSIONS['PERM_LV'] = true;
    $PERMISSIONS['PERM_LIB'] = true;
}
if ( $USER_LEVEL != 1 ) {
	/* permission system */
	$user_id = Session::getSessionField('SESS_USER_REC_ID');

	$PERMISSIONS['PERM_PF']			 = false;
	$PERMISSIONS['PERM_MSR']		 = false;
	$PERMISSIONS['PERM_ISR']		 = false;
	$PERMISSIONS['PERM_RISK']		 = false;
	$PERMISSIONS['PERM_INV']		 = false;
	$PERMISSIONS['PERM_INSP']		 = false;
	$PERMISSIONS['PERM_NHC']		 = false;
	$PERMISSIONS['PERM_CMS']		 = false;
	$PERMISSIONS['PERM_CONT']		 = false;
	$PERMISSIONS['PERM_CC']			 = false;
	$PERMISSIONS['PERM_DSE']		 = false;
	$PERMISSIONS['PERM_EQ']			 = false;
	$PERMISSIONS['PERM_MH']			 = false;
	$PERMISSIONS['PERM_SL']			 = false;
	$PERMISSIONS['PERM_TG']			 = false;
	$PERMISSIONS['PERM_TM']			 = false;
	$PERMISSIONS['PERM_FD']			 = false;
	$PERMISSIONS['PERM_EM']			 = false;
	$PERMISSIONS['PERM_CNTRB']		 = false;
        $PERMISSIONS['PERM_PCI']		 = false;
	$PERMISSIONS['PERM_INC']		 = false;
	$PERMISSIONS['PERM_INC_ING']	 = false;
	$PERMISSIONS['PERM_NHC_ING']	 = false;
	$PERMISSIONS['PERM_FLEET']	 = false;
	$PERMISSIONS['PERM_SMART']	 = false;
	$PERMISSIONS['RISK27K']	 = false;
	$PERMISSIONS['SOA']	 = false;
	$PERMISSIONS['INS']	 = false;
	$PERMISSIONS['PERM_PERSON']	 = false;
	$PERMISSIONS['PERM_BCP']	 = false;
        
	$authObj = SetupGeneric::useModule('AuthorizedUser');
	$authObj->setItemInfo(array('id'=>$user_id));
	$perm_data = $authObj->displayItems();
	
	$authObj->setItemInfo(array('id'=>$user_id));
	$perm_data_loc = $authObj->displayLocations();
	//dump_array($perm_data_loc);
	if(count($perm_data_loc) ){
			foreach ( $perm_data_loc as $value ) {
		if ( $value['sectionName'] == 'risk27k' && $value['sectionActive'] ) {
				$PERMISSIONS['RISK27K'] = true;

			}
		if ( $value['sectionName'] == 'SOA' && $value['sectionActive'] ) {
				$PERMISSIONS['SOA'] = _ALLOW_SOA == 1 ? true : false;

			}
			if ( $value['sectionName'] == 'inspection' && $value['sectionActive'] ) {
				$PERMISSIONS['INS'] = true;

			}
		}
		
		
	}

	$perm_data_law = $authObj->displayLawStds();


//	dump_array($perm_data_law);

	if(count($perm_data_law) ){
	$PERMISSIONS['PERM_SL'] = true;

			}

	// perm_doc is used for investigation

	if ( count($perm_data) ) {
	//dump_array($perm_data);
		foreach ( $perm_data as $value ) {
                        $value['sectionName'] = strtolower($value['sectionName']);
		
			if ( $value['sectionName'] == 'perm_pflow' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_PF'] = true;

			} else if ( $value['sectionName'] == 'perm_msr' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_MSR'] = true;

			} else if ( $value['sectionName'] == 'perm_isr' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_ISR'] = true;

			} else if ( $value['sectionName'] == 'perm_risk' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_RISK'] = true;

			} else if ( $value['sectionName'] == 'perm_doc' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_DOC'] = true;

			} else if ( $value['sectionName'] == 'perm_insp' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_INSP'] = true;

			} else if ( $value['sectionName'] == 'perm_nc_inc' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_INC'] = true;

			} else if ( $value['sectionName'] == 'perm_nc_nhp' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_NHC'] = true;

			} else if ( $value['sectionName'] == 'perm_ing_inc' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_INC_ING'] = true;

			} else if ( $value['sectionName'] == 'perm_ing_nhp' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_NHC_ING'] = true;

			} else if ( $value['sectionName'] == 'perm_cms' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_CMS'] = true;

			} else if ( $value['sectionName'] == 'perm_contr' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_CONT'] = true;

			} else if ( $value['sectionName'] == 'perm_cc' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_CC'] = _ALLOW_CUST_COMPLAINT == 1 ? true : false;

			} else if ( $value['sectionName'] == 'perm_dse' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_DSE'] = true;

			} else if ( $value['sectionName'] == 'perm_equip' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_EQ'] = true;

			} else if ( $value['sectionName'] == 'perm_manual' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_MH'] = true;

			//} else if ( $value['sectionName'] == 'perm_slaw' && $value['sectionActive'] ) {
			//	$PERMISSIONS['PERM_SL'] = true;

			} else if ( $value['sectionName'] == 'perm_train' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_TG'] = true;

			} else if ( $value['sectionName'] == 'perm_mgr_train' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_TM'] = true;

			} else if ( $value['sectionName'] == 'perm_mgr_equip' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_EM'] = true;

			} else if ( $value['sectionName'] == 'perm_cntrb' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_CNTRB'] = true;
			} else if ( $value['sectionName'] == 'perm_pci' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_PCI'] = _ALLOW_PCI == 1 ? true : false;
			}else if ( $value['sectionName'] == 'perm_fleet' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_FLEET'] = true;

			}else if ( $value['sectionName'] == 'perm_smart' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_SMART'] = true;
			}else if ( $value['sectionName'] == 'perm_person' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_PERSON'] = true;
			}else if ( $value['sectionName'] == 'perm_bcp' && $value['sectionActive'] ) {
				$PERMISSIONS['PERM_BCP'] = _ALLOW_BCP == 1 ? true : false;
			}
		}
	}

	$current_url 	= $_SERVER['SCRIPT_NAME'];
	$url_arr = explode('/',$current_url);
	//dump_array($url_arr);
	$redirection = false;


	$equipment_files = array('equipment_listing.php','manage_equipment_manufacturer.php','manage_equipment_details_new.php','manage_equipment_maintenance.php',
							 'manage_equipment_calibration.php','records_equipment.php','ajax_get_equip_class_code.php','ajax_get_files.php');

	// redirection('/not_allowed.php');

	switch($url_arr[1]) {

		case 'process_risk_assessment':
			if ( $PERMISSIONS['PERM_RISK'] ) {
				$redirection = true;
			}
		break;
		case 'inspection':
			if ( $PERMISSIONS['INS'] ) {
				$redirection = true;
			}
		break;
		case 'locationgram':
			if ( $PERMISSIONS['RISK27K'] ) {
				$redirection = true;
			}
		break;
		case 'risk27k':
			
			if ( $PERMISSIONS['RISK27K'] ) {
				$redirection = true;
			}
		break;
		case 'locationgram':
			if ( $PERMISSIONS['SOA'] ) {
				$redirection = true;
			}
		break;
		case 'soa':
			
			if ( $PERMISSIONS['SOA'] ) {
				$redirection = true;
			}
		break;
			case 'smart_bcp':
			
			if ( $PERMISSIONS['PERM_BCP'] ) {
				$redirection = true;
			}
		break;
		case 'incidence':
			if ( $PERMISSIONS['PERM_INC']) {

				
				       $redirection = true;
			
			}
		break;
		
			
		case 'nhp':
			if ($url_arr[2] == 'add_edit_alert.php' ){
				$redirection = true;
			}	
			elseif ( $PERMISSIONS['PERM_NHC'] ) {
				$redirection = true;
			}
		
	
		break;
		case 'investigation':
			if ( $PERMISSIONS['PERM_INC_ING'] ) {
				$redirection = true;
			}
		break;
		case 'nhc_investigation':
			if ( $PERMISSIONS['PERM_NHC_ING'] ) {
				$redirection = true;
			}
		break;
		case 'documents':
			//if ( $PERMISSIONS['PERM_DOC'] ) {
				$redirection = true;
			//}
		break;
		case 'contracts':
			if ( $PERMISSIONS['PERM_CONT'] ) {
				$redirection = true;
			}
		case 'Contracts':
			if ( $PERMISSIONS['PERM_CONT'] ) {
				$redirection = true;
			}
		case 'contractors':
			if ( $PERMISSIONS['PERM_CONT'] ) {
				$redirection = true;
			}
		break;
		case 'reviews':
			if ( $PERMISSIONS['PERM_CONT'] ) {
				$redirection = true;
			}
		break;
		
		case 'dse_assessment':
			if ( $PERMISSIONS['PERM_DSE'] ) {
				$redirection = true;
			}
		break;
		case 'equipment':
			if ( $PERMISSIONS['PERM_EQ'] ) {
				$redirection = true;
			}
		break;
		case 'manual_handling':
			if ( $PERMISSIONS['PERM_MH'] ) {
				$redirection = true;
			}
		break;
		case 'smart_law':
			if ($url_arr[2] == 'index.php' || $url_arr[2] == 'records.php' ){
				$redirection = true;
			}	
			elseif ( $PERMISSIONS['PERM_SL'] ) {
				$redirection = true;
			}
		break;
		case 'training':
			if ( $PERMISSIONS['PERM_TG'] ) {
				$redirection = true;
			}
		break;
            case 'smart_induct':
				$redirection = true;
		break;
		case 'setup':

                    
			if ( $url_arr[3] == 'training' ||  in_array($url_arr[3],$equipment_files)  ) {

				if ( $url_arr[3] == 'training' ) {

					if ( $PERMISSIONS['PERM_TM'] ) {
						$redirection = true;
					}
				} else {

					if ( $PERMISSIONS['PERM_EM'] ) {
						$redirection = true;
					}
				}

			} //else {
			//	$redirection = false;
			//}
			if ( $url_arr[3] == 'manage_training_users.php' || $url_arr[3] == 'records_manage_training_users.php' ) {
				if ( $PERMISSIONS['PERM_TM'] ) {
					$redirection = true;
				}
			}
		break;
		case 'process_flow':
			if ( $PERMISSIONS['PERM_PF'] ) {
				$redirection = true;
			}
		break;
		case 'system_review':
			if ( $PERMISSIONS['PERM_MSR'] || $PERMISSIONS['PERM_ISR'] ) {
				$redirection = true;
			}
		break;
		case 'action_tracker':

			if ( $USER_LEVEL == 2 || $USER_LEVEL == 3 ) {
				$redirection = true;
			}

			if ( ( $url_arr[2] == 'contributor_listing.php' && $USER_LEVEL == 2) ) {
				$redirection = false;
				if ( $PERMISSIONS['PERM_CNTRB'] ) {
					$redirection = true;
				}
			}

			if ( ( $url_arr[2] == 'doc_control.php') ) {
				$redirection = false;
				if ( $PERMISSIONS['PERM_DOC'] ) {
					$redirection = true;
				}
			}


		break;
		case 'manage_cms':
			if ( $PERMISSIONS['PERM_CMS'] ) {
				$redirection = true;
			}
		break;
		

		
		
		case 'vehicle':
			if ($url_arr[2] == 'perform_servicing.php' || $url_arr[2] == 'daily_inspection.php' || $url_arr[2] == 'monthly_inspection.php'){
				$redirection = true;
			}	
			elseif ( $PERMISSIONS['PERM_FLEET'] ||  $PERMISSIONS['PERM_SMART'] ) {
				$redirection = true;
			}
		break;
		
		
		
		case 'index.php':
				$redirection = true;
		break;
		
		case 'ajax_publish.php':
				$redirection = true;
		break;
		

		case 'not_allowed.php':
				$redirection = true;
		break;
		
		
		case 'authentication':
				$redirection = true;
		break;
		case 'setup/standard/ajax_bu_has_manager.php':
				$redirection = true;
		break;
	     case 'organigram':
				$redirection = true;
		break;
		case 'ajax_participants.php':
				$redirection = true;
		break;
		case 'ajax_track_record.php':
				$redirection = true;
				
		break;
		
		case 'ajax_participants_worksno.php':
				$redirection = true;
		break;
	   case 'ajax_get_location_business.php':
				$redirection = true;
		break;
		case 'download_file.php':
				if ( $USER_LEVEL == 2 ) {
					$redirection = true;
				}
		break;
		case 'welcome_user.php':
				if ( $USER_LEVEL == 3 ) {
					$redirection = true;
				}
		break;
		case 'testing':
				$redirection = true;
		break;
		case 'repos':
				$redirection = true;
		break;
	}

	/**
	 *
	 * Special cases for setup permissions
	 * Added by davinder on March 29, 2011
	 *
	 */
	
	// $_SERVER['SCRIPT_NAME'];
	//case 'vehicle':
			//if ( $PERMISSIONS['PERM_FLEET']) {
		
	//	var_dump($PERMISSIONS);
	//	exit();
			
        if(($_SERVER['SCRIPT_NAME'] == '/download_file_risk.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/add_vechile.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/pop_view_type.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/pop_add_type.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/pop_view_make.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/pop_add_make.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/pop_view_model.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/pop_add_model.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/restore_type.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/restore_make.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/restore_model.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/restore_service.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/restore_inspection.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/restore_frequency.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_add_vehicle.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/vehicle_frequency.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_vechile_detail.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_add_frequency.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_add_frequency.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_vehicle_detail.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_vehicle_model.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/vehicle_detail.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_vehicle_detail.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_list_service.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_list_inspection.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/ajax_get_make_data.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/vehicle_model.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_add_vechile.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/list_service.php'  || $_SERVER['SCRIPT_NAME'] == '/setup/management/list_inspection.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/add_service.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/add_inspection.php')&& ($PERMISSIONS['PERM_SMART'] || $PERMISSIONS['PERM_FLEET'] || Session::getSessionField('SESS_SO_A1') ) ){
                $redirection = true;
        }
				
			//}
			//break;
	if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/authorised_user_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_authorised_user.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/manage_permissions.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_manage_permissions_bu.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_manage_permissions_md.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_manage_permissions_ms.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_manage_permissions_rm.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_manage_permissions_sp.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/log_record.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_log_record.php') && Session::getSessionField('SESS_SO_A1') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/upload_company_logo.php') && Session::getSessionField('SESS_SO_A2') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/show_default_page_after_login.php') && Session::getSessionField('SESS_SO_A3') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/set_alert_email_dates.php') && Session::getSessionField('SESS_SO_A4') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/employment_type_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_employment_type.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/manage_employment_type.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/employement_type_csv.php') && Session::getSessionField('SESS_SO_A5') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/locationgram.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/ajax_organigram_list.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/ajax_locationgram.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/tree_locationgram.php' ) && Session::getSessionField('SESS_SO_A6') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/organigram.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/tree.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/organigram_allocate_positions.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/set_oragnigram_date.php' ) && Session::getSessionField('SESS_SO_A7') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/organigram_color_setup.php' ) && Session::getSessionField('SESS_SO_A8') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/participants_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_participants.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/change_password.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/participants_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/manage_participants.php' ) && Session::getSessionField('SESS_SO_A9') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/standard/upload_startup_screen_image.php' ) && Session::getSessionField('SESS_SO_A10') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/manage_document_control_type.php' ) && Session::getSessionField('SESS_SO_B1') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/document_classification_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_document_classification.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/document_classification_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_document_classification.php' ) && Session::getSessionField('SESS_SO_B2') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/equipment_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_equipment.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_equipment_manufacturer.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_equipment_details_new.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_equipment_maintenance.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_equipment_calibration.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/import_data_equip' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_generic_record.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/csv_import_instructions_equip.php'  || $_SERVER['SCRIPT_NAME'] == '/setup/management/equipment_setup_csv.php' ) && Session::getSessionField('SESS_SO_B3') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/equipment_classification_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_equipment_classification.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_equipment_classification.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_equipment_classification.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == 'equipment_classification_csv.php' ) && Session::getSessionField('SESS_SO_B4') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/internal_audit.php' ) && Session::getSessionField('SESS_SO_B5') ) {
		$redirection = true;
	} else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/management_elements_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_management_elements.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_management_elements.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_mse_list.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/management_element_export_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/import_data.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/csv_import_instructions.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_management_elements.php' ) && Session::getSessionField('SESS_SO_B6') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/management_element_setup.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_management_element_setup.php' ) && Session::getSessionField('SESS_SO_B7') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_smart_law.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_smart_law.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_csv.php' ) && Session::getSessionField('SESS_SO_B8') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/select_audit_standards.php' ) && Session::getSessionField('SESS_SO_B9') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_course_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/record_manage_course.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/incidence_manage_course.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/trainingcourse_csv.php') && Session::getSessionField('SESS_SO_B10') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_instructor_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/record_manage_instructor.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_training_instructor.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/training_instructor_csv.php') && Session::getSessionField('SESS_SO_B10') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/room_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/record_room.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_training_rooms.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/training_room_csv.php') && Session::getSessionField('SESS_SO_B10') ) {
		$redirection = true;
	}else if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/manage_document_control_type.php' ) && Session::getSessionField('SESS_SO_B1') ) {
		$redirection = true;
	}
	else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/control_measures_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_control_measures.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/manage_control_measures.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/control_csv.php') && Session::getSessionField('SESS_SO_C1') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/hazards_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_hazards.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/manage_hazards.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/hazards_csv.php') && Session::getSessionField('SESS_SO_C2') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/inspection_hazard.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_inspection_hazard.php' ) && Session::getSessionField('SESS_SO_C3') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/impact_measures_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/change_impact.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_impact measures.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/impact_measures_csv.php' ) && Session::getSessionField('SESS_SO_C4') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/type_treatment_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/accident_occured_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/part_body_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/nature_of_injury_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/additional_factor_listing.php'
				  || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_type_treatment.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_accident_occured.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_part_body.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_nature_of_injury.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_additional_factor.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/incidence_type_treatment.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/incidence_accident_occured.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/incidence_part_body.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/incidence_nature_of_injury.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/incidence_additional_factor.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/type_treatment_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/accident_occured_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/part_of_body_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/nature_injury_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/additional_factor_csv.php' ) && Session::getSessionField('SESS_SO_C5') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/inspection_frequency.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/process_riskrating.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/outstanding_action.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_inspection_frequency.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/ajax_get_bu_childs.php' ) && Session::getSessionField('SESS_SO_C6') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/incident_analysis_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/immediate_causes_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/basic_causes_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/inadequacies_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_incident_analysis.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/incident_analysis_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_immediate_causes.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/immediate_causes_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_basic_causes.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/basic_causes_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_basic_causes.php' ) && Session::getSessionField('SESS_SO_C7') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/net_impact_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_net_impact.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/net_impact_csv.php' ) && Session::getSessionField('SESS_SO_C8') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/environmental_type_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/environmental_scale_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/disposition_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_environmental_type.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/environmental_type_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_environmental_scale.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/environmental_scale_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_disposition.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/disposition_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php') && Session::getSessionField('SESS_SO_C9') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/hazard_lists.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_hazard_lists.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/manage_hazard_list.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/manage_hazard_all.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/import_data_hazard.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/records_hazard_lists.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' ) && Session::getSessionField('SESS_SO_C10') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/risk_action_priority.php' ) && Session::getSessionField('SESS_SO_C11') ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/bcp_listing.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_desi.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/add_desi.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/email_new.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/restore_rat.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_rat.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/add_rat.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/listing_rat.php' )) {
		$redirection = true;
	}else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/listing_c.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/listing_r.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/nature_listing.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/add_c.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/add_r.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/nature_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/add_nature.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_nature.php' )) {
		$redirection = true;
	}else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/risk/restore_nature.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/restore_bcp.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/rec_csv.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/cric_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/desi_csv.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_r.php' || $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_c.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/risk/record_nature.php' )) {
		$redirection = true;
	}

	/*********** training users ***************/
	$training_authObj = SetupGeneric::useModule('TrainingUser');
	$training_user = (int) $training_authObj->getIssuerPermission(Session::getSessionField('SESS_USER_REC_ID'));
	if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_course_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/record_manage_course.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/incidence_manage_course.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/trainingcourse_csv.php') && $training_user ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_instructor_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/record_manage_instructor.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_training_instructor.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/training_instructor_csv.php') && $training_user ) {
		$redirection = true;
	} else if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/room_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/record_room.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_training_rooms.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/training/training_room_csv.php') && $training_user ) {
		$redirection = true;
	} else if ( $_SERVER['SCRIPT_NAME'] == '/setup/management/training/manage_email_setup.php' && $training_user ) {
		$redirection = true;
	}
	/********************************************/

if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_smart_law.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_smart_law.php' || $_SERVER['SCRIPT_NAME'] == '/setup/delete_record_generic.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_csv.php' ) && $PERMISSIONS['PERM_SL']) {
		$redirection = true;
}

if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/standard/participants_listing.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/records_participants.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/change_password.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/view_history.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/participants_csv.php' || $_SERVER['SCRIPT_NAME'] == '/setup/standard/manage_participants.php' ) && $PERMISSIONS['PERM_PERSON']) {
		$redirection = true;
}

if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/smartlaw_nature.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_smartlaw_nature.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_smartlaw_nature.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_nature_csv.php' ) && $PERMISSIONS['PERM_SL']) {
		$redirection = true;
}

if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/smartlaw_level.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_smartlaw_level.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_smartlaw_level.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_level_csv.php' ) && $PERMISSIONS['PERM_SL']) {
		$redirection = true;
}

if ( ( $_SERVER['SCRIPT_NAME'] == '/setup/management/smartlaw_subject.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/records_smartlaw_subject.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/manage_smartlaw_subject.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/smart_law_subject_csv.php' ) && $PERMISSIONS['PERM_SL']) {
		$redirection = true;
}

if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/manage_smartlaw_config.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/ajax_related_law_list.php'|| $_SERVER['SCRIPT_NAME'] == '/setup/management/ajax_add_smart_law.php') && $PERMISSIONS['PERM_SL']) {
		$redirection = true;
}
if ( ($_SERVER['SCRIPT_NAME'] == '/setup/management/archive_smartlaw_record.php' ||  $_SERVER['SCRIPT_NAME'] == '/setup/management/archive_smartlaw_level_record.php' || $_SERVER['SCRIPT_NAME'] == '/setup/management/archive_smartlaw_nature_record.php'|| $_SERVER['SCRIPT_NAME'] == '/setup/management/archive_smartlaw_subject_record.php') && $PERMISSIONS['PERM_SL']) {
		$redirection = true;
}

if ( ($_SERVER['SCRIPT_NAME'] == '/system_review/reject.php' ||  $_SERVER['SCRIPT_NAME'] == '/system_review/approved.php' ) && $user_id==21 ) {
		$redirection = true;
}

if ( ( $_SERVER['SCRIPT_NAME'] == '/ajax_get_assest.php' ) && $PERMISSIONS['RISK27K']) {

		$redirection = true;
}

//induct
if (  $_SERVER['SCRIPT_NAME'] == '/process_risk_assessment/r1ReportPdf.php' || $_SERVER['SCRIPT_NAME'] == '/process_flow/generate_process_flow_horizontal_pdf.php'){

		$redirection = true;
}


	/**
	 * Special cases ends here
	 */

	if ( !$redirection ) {
		redirection('/not_allowed.php');
	}

}

//$_SESSION['SESS_MODULE_NAME'] = $url_arr[1];

include ($_SERVER['DOCUMENT_ROOT'].'/includes/classes/UserActivityLog.class.php');
$log = new UserActivityLog($url_arr[1]);

/*Doc issuer details */
$authObj = SetupGeneric::useModule('AuthorizedUser');
$participantObj	 	= 		SetupGeneric::useModule('Participant');

$doc_issuer	= $authObj->getIssuerPermission('perm_doc');

$participant_id = $doc_issuer;
$participantObj->setItemInfo(array('id'=>$participant_id));
$partcipantData = $participantObj->displayItemById();

//dump_array($partcipantData);

$_SESSION['DOC_ISSUER_EMAIL']		 = $partcipantData['emailAddress'];
//$_SESSION['DOC_ISSUER_EMAIL']		 = 'just_sanjeev86@yahoo.co.in';
$_SESSION['DOC_ISSUER_ID']			 = $partcipantData['participantID'];
$_SESSION['DOC_ISSUER_NAME']		 = $partcipantData['forename'].' '.$partcipantData['surname'];
$_SESSION['DOC_ISSUER_SALUTATION']	 = trim($partcipantData['gender']) == 'F' ? 'Ms' : 'Mr.' ;
/***********************/

/*************** training manager *********************/
$training_manager	= $authObj->getIssuerPermission('perm_mgr_train');


?>