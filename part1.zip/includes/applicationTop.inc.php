<?php
 /**
  $Id: applicationTop.inc.php,v 3.58 Tuesday, January 11, 2011 4:59:56 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This is used to initialize and setup various paths for the software
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Generic
  * @since  Monday, August 16, 2010 11:31:08 AM>
  */
ob_start("ob_gzhandler");

$DOCUMENT_ROOT = str_replace('\\', '/',$_SERVER['DOCUMENT_ROOT']);
$DOCUMENT_ROOT_ARR = explode('/',$DOCUMENT_ROOT);

$DOCUMENT_ROOT_CNT = count($DOCUMENT_ROOT_ARR);
array_pop($DOCUMENT_ROOT_ARR);
 $DOCUMENT_ROOT_ARR = implode('/',$DOCUMENT_ROOT_ARR);
define('_MYPRIVATEROOT',$DOCUMENT_ROOT_ARR);

require_once _MYPRIVATEROOT."/includes/config.inc.php";


// secure function
include_once _MYPRIVATEINCLUDES . "functions.inc.php";

// non secure user defined functions
include_once _MYINCLUDES . "functions.inc.php";

// to show success messages
include_once _MYINCLUDES.'success_messages.php';

require_once _MYPRIVATECLASSES . "Db.class.php";
require_once _MYPRIVATECLASSES . "setup/Setup.class.php";

if ( !defined(_VENDOR_SMARTY) ) {
	require_once _VENDOR_SMARTY."Smarty.class.php";
	//require _VENDOR_SMARTY."SmartyTest.class.php";

	$smarty = new Smarty;

	$smarty->template_dir = _THEME_FOLDERPATH._THEME.'/templates';
	$smarty->compile_dir = _THEME_FOLDERPATH._THEME.'/templates_c';
	//$smarty->cache_dir = _THEME_FOLDER._THEME.'/cache';
	$smarty->config_dir = _MYINCLUDES.'/smarty_configs';

	$smarty->assign('employee_participant',_EMPLOYEE_PARTICIPANT);
	$smarty->assign('delete_label',_DELETE_LABEL);
	$smarty->assign('_ACTION_MAIL_SUBJECT',_ACTION_MAIL_SUBJECT);
	$smarty->assign('_ARCHIVED_RECORDS_LABEL',_ARCHIVED_RECORDS_LABEL);
	$smarty->assign('_ACTIVE_RECORDS_LABEL',_ACTIVE_RECORDS_LABEL);
	$smarty->assign('_EDIT_LABEL',_EDIT_LABEL);
	$smarty->assign('_REVIEW_LABEL',_REVIEW_LABEL);
	$smarty->assign('_EXPORT_CSV_LABEL',_EXPORT_CSV_LABEL);
	$smarty->assign('_ADVANCE_SEARCH_LABEL',_ADVANCE_SEARCH_LABEL);
	$smarty->assign('_GRAPH_LABEL',_GRAPH_LABEL);
	$smarty->assign('_RESTORE_LABEL',_RESTORE_LABEL);
	$smarty->assign('_HISTORY',_HISTORY_LABEL);
	$smarty->assign('_AU_WHO',_AU_WHO);


	$USER_ADMIN_AUTHORISED_USER = isAdministrator() || isAuthorisedUser();

	if ( $USER_ADMIN_AUTHORISED_USER ) {
		$smarty->assign('_USER_ADMIN_AUTHORISED_USER',1);
	} else {
		$smarty->assign('_USER_ADMIN_AUTHORISED_USER',0);
	}

	$smarty->assign('_IS_ADMINISTRATOR',0);
	$smarty->assign('_IS_AUTHORISED_USER',0);
	$smarty->assign('_IS_BASIC_USER',0);

	if ( isAdministrator() ) {
		$smarty->assign('_IS_ADMINISTRATOR',1);
	}

	if ( isAuthorisedUser() ) {
		$smarty->assign('_IS_AUTHORISED_USER',1);
	}

	if ( isBasicUser() ) {
		$smarty->assign('_IS_BASIC_USER',1);
	}

}

 $image = '/images/add7.png';
 $image1 = '/images/edit7.png';
 $image2 = '/images/archive7(1).png';


 $image3 = '/images/export7.png';
 $image4 = '/images/save6.png';
 $image5 = '/images/key7.png';
 $image6 = '/images/cancel7.png';
 $image7 = '/images/reset8.png';
 $image8 = '/images/upload8.png';
 $image9 = '/images/back8.png';
 
 $image10 = '/images/m8(1).png';
 $image11 = '/images/archives8.png';
 $image12 = '/images/activate8(1).png';
 $image13 = '/images/changeorder8.png';
 
  $image14 = '/images/access details.png';
 $image15 = '/images/action.png';
 $image16 = '/images/activate9.png';
 $image17 = '/images/active records.png';
 
  $image18 = '/images/add another.png';
 $image19 = '/images/changepassword.png';
 $image20 = '/images/deactivate9.png';
 $image21 = '/images/history.png';
 	$imagef2= '/images/F2.png';
	 $smarty->assign('imagef2',$imagef2);
 
  $image22 = '/images/manage permission.png';
 $image23 = '/images/restore7.png';
 $image24 = '/images/timelog.png';
 
   $imager1 = '/images/r1(1).png';
 $imager2 = '/images/r2(1).png';
 $imager3 = '/images/r3(1).png';
   $imager4 = '/images/r4(1).png';
 $imager5 = '/images/r5(1).png';
 $imager6 = '/images/r6(1).png';
 
  $imagematrix = '/images/matrix.png';
  $imageflow= '/images/process flow(1).png';
   $imageht= '/images/html.png';
    $imagep= '/images/pdf H.png';
    $imagetrend = '/images/trend_graph_white.png';
    

	$imagempuu= '/images/pdf MU.png';
	$imagecc= '/images/continue white.png';
	$imagegr= '/images/graph7.png';
	$imagegap= '/images/g(1).png';
	$imageskip= '/images/skip.png';
	$imagef1= '/images/f1.png';
	$imageanswer= '/images/answer 1.png';
	$imagefb= '/images/button/first.png';
	$imagenb= '/images/button/next.png';
	$imagepb= '/images/button/previous.png';
	$imagelb= '/images/button/last.png';
	$imagere= '/images/review8.png';
        $imageview= '/images/view8(1).png';
	$smarty->assign('imagere',$imagere);
	 $smarty->assign('imagefb',$imagefb);
	 	 $smarty->assign('imageanswer',$imageanswer);
	  $smarty->assign('imagenb',$imagenb);
	   $smarty->assign('imagepb',$imagepb);
	   $smarty->assign('imagef1',$imagef1);
	   	   $smarty->assign('imagelb',$imagelb);
 $smarty->assign('imager1',$imager1);
$smarty->assign('imager2',$imager2);
$smarty->assign('imager3',$imager3);
$smarty->assign('imager4',$imager4);
$smarty->assign('imager5',$imager5);
$smarty->assign('imager6',$imager6); 
$smarty->assign('imagematrix',$imagematrix);    
 $smarty->assign('imageflow',$imageflow);      
  $smarty->assign('imageht',$imageht);
  $smarty->assign('imagep',$imagep); 
 $smarty->assign('imagempuu',$imagempuu);   
 $smarty->assign('imagecc',$imagecc); 
 $smarty->assign('imagegr',$imagegr); 
 $smarty->assign('imagegap',$imagegap); 
   	$smarty->assign('imageskip',$imageskip); 
    	$smarty->assign('imageview',$imageview);   
$smarty->assign('image',$image);
$smarty->assign('image1',$image1);
$smarty->assign('image2',$image2);
$smarty->assign('image3',$image3);
$smarty->assign('image4',$image4);
$smarty->assign('image5',$image5);
$smarty->assign('image6',$image6);
$smarty->assign('image7',$image7);
$smarty->assign('image8',$image8);	
$smarty->assign('image9',$image9);	
$smarty->assign('image10',$image10);
$smarty->assign('image11',$image11);	
$smarty->assign('image12',$image12);	
$smarty->assign('image13',$image13);

$smarty->assign('imagead',$image14);
$smarty->assign('imagea',$image15);	
$smarty->assign('imageac',$image16);	
$smarty->assign('imagear',$image17);

$smarty->assign('imageaa',$image18);
$smarty->assign('imagec',$image19);	
$smarty->assign('imagede',$image20);	
$smarty->assign('imageh',$image21);

$smarty->assign('imagemp',$image22);	
$smarty->assign('imager',$image23);	
$smarty->assign('imaget',$image24);
$smarty->assign('imagetrend',$imagetrend);
$column=2;
// to start a session
Session::StartSession();

if ( !$_HIDE_ACCESS_CONTROL ) {
	require_once _MYPRIVATEROOT.'/includes/access_control.inc.php';
}

if (!$_HIDE_HTTP_HEADER) {

	/*
	 * To Turn of page caching
	 */

	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	require_once _MYROOT."header.inc.php";
}


if ($_SHOW_GUEST_HTTP_HEADER) {

	/*
	 * To Turn of page caching
	 */

	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	require_once _MYROOT."header_guest.inc.php";
}


foreach ( $_SERVER as $server_key=>$server_ele ) {

	$dynamic_string = '_SMARTISO_'.$server_key;
	$$dynamic_string = $server_ele;
}

if ( _PHP_SELF != '/inspection/report.php' ) {
	if ( $_SHOW_POP_REPORT_HEADER ) {
		require_once _MYROOT.'popup_report_header.inc.php';
	}
}

//require_once _MYPRIVATEINCLUDES."/graph.config.inc.php";
if (_FIREPHP_ENABLED) {
	require_once _MYPRIVATECLASSES.'/firephp/fb.php';
}


/*
 * User Activity log pan software.
 */
//require_once "../includes/saveApplicationLog.inc.php";