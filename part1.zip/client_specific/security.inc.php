<?php

define('_SECURITY_SALT', 'abracdabra');