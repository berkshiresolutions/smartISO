<?php
define('_TRACK_PERFORMANCE',FALSE);
define('_LIVE_MODE',TRUE);
define('_FIREPHP_ENABLED',FALSE);
define('_DISPLAY_FULL_TABLE',TRUE);
#define('_SW_DIR','/dev/');
define('_SW_DIR','');
define('_LIVE_TIME_ZONE',TRUE);

if (_LIVE_TIME_ZONE) {
	setlocale(LC_ALL,'en_UK');
	putenv("TZ=Europe/Dublin");
} else {
	setlocale(LC_ALL,'en_IN');
	putenv("TZ=Asia/Calcutta");
}

define('_HTTPS_STATUS',$_SERVER['HTTPS']);
define('_SITE_ADMIN_EMAIL','dsrai@gmail.com');
define('_SITE_RETURN_EMAIL','no-reply@smart-test.smart-iso.net');

//define('_DB_TYPE','mssql');
define('_DB_TYPE','sqlsrv');
define('_CURRENCY','&euro;');

if ( _LIVE_MODE ) {
      error_reporting(0);
	//error_reporting(E_ALL&~E_NOTICE);
	//ini_set('display_errors',1);
	######################### Live Server Settings ##########################
	if ( _HTTPS_STATUS == 'on' ) {
		define('_MYSERVER','https://SI-NG.smart-iso.net');
		define('_MYSECURESERVER','https://SI-NG.smart-iso.net');
	} else {
		define('_MYSERVER','https://SI-NG.smart-iso.net');
		define('_MYSECURESERVER','https://SI-NG.smart-iso.net');
	}

	define('_DB_HOST','localhost');
	//define('_DB_HOST','localhost\sqlexpress');
	define('_DB_USER','userISO');
	define('_DB_PASS','userISO');
	//define('_DB_NAME','dbISO');
	//define('_DB_ODBC_OBJ','alpha2');

	//define('_DB_ODBC_OBJ','rsagen3');
	///define('_DB_NAME','dbRSATest');
	define('_DB_NAME','dbSING');
} else {
	######################### Local Settings ##########################
	error_reporting(E_ALL&~E_NOTICE);
	///define('_MYSERVER','http://gen3sql.smart-iso.com');
	///define('_MYSECURESERVER','http://gen3sql.smart-iso.com');

	//define('_MYSERVER','http://91.151.209.181:81');
	//define('_MYSECURESERVER','http://91.151.209.181:81');

	if ( _DB_TYPE == 'mssql' ) {

		define('_DB_HOST','192.168.1.48');
		define('_DB_USER','userISO');
		define('_DB_PASS','userISO');

		define('_DB_ODBC_OBJ','rsagen3');
		define('_DB_NAME','dbRSA');

	} else if ( _DB_TYPE == 'mysql' ) {

		define('_DB_HOST','localhost');
		define('_DB_USER','root');
		define('_DB_PASS','ehsindia');
		define('_DB_NAME','sm3_firstdraft');
	}

	/*
	define('_DB_HOST','localhost');
	define('_DB_USER','root');
	define('_DB_PASS','ehsindia');
	define('_DB_NAME','sm3_firstdraft');
	*/
}
