<?php

define('_LOGIN_SCREEN_WELCOME_TEXT', 'Welcome to <span style="font-size:24px">SING </SPAN>');
define('_RSA_TRAINING',0);
define('_ACCIDENT_AUTHORISED_USER',0);
define('_ACCIDENT_AUTHORISED_REPORTER',0);
define('_SELECT_TEST_CENTER',0);
define('_TRAINING_V2',0);
define('_ALLOW_INDUCT',1);
define('_PERMAMENT_LOGO',0);
define('_SMART_EM',0);
define('_GHL', 0);
define('_CANDW', 0);
define('_BETA', 0);
define('_ALLOW_BCP', 1);

define('_ALLOW_ASSET', 1);
define('_ALLOW_CUST_COMPLAINT', 1);
define('_ALLOW_DSE', 1);
define('_ALLOW_MANUAL_HANDLING', 1);
define('_ALLOW_GRP_POLICY', 0); 
define('_ALLOW_COMMS_MGR', 1); 
define('_ALLOW_CONTEXT_ANALYSIS', 1); 
define('_ALLOW_FLEET', 1);
define('_ALLOW_SOA', 1);
define('_ALLOW_LAW', 1);
define('_ALLOW_PCI', 1);
define('_ALLOW_RISK27K', 0);
define('_ALLOW_RISK', 1);
define('_ALLOW_REPORT', 0);
define('_ALLOW_TRAIN', 1);
define('_ALLOW_GOV', 1);
define('_ALLOW_CONTRACTS', 1); 
define('_ALLOW_RTA', 0);
define('_NCR2', 1);

// setting default theme
if (isset($_COOKIE['smartTheme'])) {
	define('_THEME', $_COOKIE['smartTheme']);
} else {
	define('_THEME', 'default');
}