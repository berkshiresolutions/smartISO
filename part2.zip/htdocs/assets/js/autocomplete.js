$(document).ready(function(){


jQuery('.autofillP').autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/participants',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "forename+' '+surname", 'value'  : request.term, 'func'  : 'like'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.fullname,
						id  : item.participantID
							}
						}));
					}	
				})
	},
	select :function(event,ui){
	$("#who").val(ui.item.label);
	$("#who_hidden").val(ui.item.id);
	}
	
	});

jQuery('.autofillT').autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/tutors',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "fname+' '+lname", 'value'  : request.term, 'func'  : 'like'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.fullname,
						id  : item.participantID
							}
						}));
					}	
				})
	},
	select :function(event,ui){
	$("#who").val(ui.item.label);
	$("#who_hidden").val(ui.item.id);
	}
	
	});
	
jQuery('.autofillPW').autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/participants',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "forename+' '+surname", 'value'  : request.term, 'func'  : 'like'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.fullname,
						id  : item.participantID,
						worksNo  : item.worksNumber
							}
						}));
					}	
				})
	},
	select :function(event,ui){
var ind=jQuery(this).attr('rel');

	$("#participant_"+ind).val(ui.item.label);
	$("#participant_"+ind+"_hidden").val(ui.item.id);
	$("#worksNumber_"+ind).val(ui.item.worksNo);
	}
	
	});

	jQuery('.autofillPW1').autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/participants',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "forename+' '+surname", 'value'  : request.term, 'func'  : 'like'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.fullname,
						id  : item.participantID,
						worksNo  : item.worksNumber
							}
						}));
					}	
				})
	},
	select :function(event,ui){

window.location.href = ('/train/personalrecord/'+ui.item.id);

	}
	
	});
	
	
jQuery(document).on("keydown.autocomplete",".autofillPV",function(e){
jQuery(this).autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/participants',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "forename+' '+surname", 'value'  : request.term, 'func'  : 'like'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.fullname,
						id  : item.participantID,
						worksNo  : item.worksNumber
							}
						}));
					}	
				})
	},
	select :function(event,ui){
var ind=jQuery(this).attr('rel');

	$("#participant_"+ind).val(ui.item.label);
	$("#participant_"+ind+"_hidden").val(ui.item.id);
	$("#worksNumber_"+ind).val(ui.item.worksNo);
	}
	
	});
});

jQuery('.autofillR').autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/search',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "roomNo", 'value'  : request.term, 'func'  : 'like', 'tbl'  : 'trng_room'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.roomNo,
						id  : item.rID,
						capacity  : item.capacity

							}
						}));
					}	
				})
	},
	select :function(event,ui){
	$("#room").val(ui.item.label);
	$("#room_id").val(ui.item.id);
	$("#max_room_seats").val(ui.item.capacity);
        
        var participantCnt = jQuery('#participantAllocation').find('.row').length;
            if (participantCnt <1 ){
                $("#add_participant_btn").click();
                }

        
        
        
	}
	
	});

jQuery('.autofillI').autocomplete({
 	 	source: function(request,response)
	{
		jQuery.ajax({
		'url':'/json/search',
		'datatype': 'json',
		'type': 'POST',
		'data': { 'field' : "fname+' '+lname", 'value'  : request.term, 'func'  : 'like', 'tbl'  : 'trng_instructor'},
		'success':function(data) {
		 	newdata=SIparser(data);
				response($.map(newdata.message,function(item){
					return {
						label  : item.fname+' '+item.lname,
						id  : item.insID
						

							}
						}));
					}	
				})
	},
	select :function(event,ui){
	$("#instructor").val(ui.item.label);
	$("#instructor_id").val(ui.item.id);
	
	}
	
	});



function SIparser(data){	
var retdata;
retdata=JSON.parse(data);
return retdata;
	}

function roomChecker(datain){
alert("eeeeee");
}

function httpOpenq(type,func,url,arg,target){	
alert(type);
	}


			window.httpOpen = function(type,url,arg,target) {
			window.open(url);
	};
	});

