<?php
 /**
  $Id: change_email_address.php,v 3.06 Thursday, January 20, 2011 6:41:21 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Authentication
  * @since  Monday, November 29, 2010 12:15:26 PM>
  */

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'authentication/change_email_address.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$objAuth = new Authentication();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

    $email = $_POST['email_address'];
    
    $objAuth->setLoginInfo('','','','',$email);
    $objAuth->changeEmailAddress();
    redirection('?e=6');
}

$email_arr = $objAuth->getEmailAddress();
$email_address = $email_arr['emailAddress'];

$smarty->assign('email_address',$email_address);
$smarty->display('authentication/change_email_address.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>