<?php
 /**
  $Id: ajax_check_authentication.php,v 3.60 Wednesday, December 01, 2010 7:02:38 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Load next question from database of specific audit
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage System Review
  * @since  Friday, September 17, 2010 6:13:50 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$authObj = new Authentication();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$user_name			= $_REQUEST['username'];
	$user_pswd			= $_REQUEST['password'];
	$remember_user		= $_REQUEST['remember_user'];

	$authObj->setLoginInfo($user_name,$user_pswd);

	if ( $authObj->isInfoProvided() ) {

		$user_id = $authObj->authenticateUser();

		if ( $user_id ) {
			//set cookie for 30 days
			if ( $remember_user == 1 ) {
				setcookie('username',$user_name,time()+60*60*24*30);
			}
			echo $user_id;
		} else {
			echo -1;
		}

	} else {
		echo -1;
	}
}
?>