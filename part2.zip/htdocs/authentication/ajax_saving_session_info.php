<?php
 /**
  $Id: ajax_saving_session_info.php,v 3.77 Tuesday, February 01, 2011 2:37:24 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Load next question from database of specific audit
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage System Review
  * @since  Friday, September 17, 2010 6:13:50 PM>
  */
$_HIDE_HTTP_HEADER = true;

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

	require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

	$user_name 	= $_POST['username'];
	$user_id 	= $_POST['uid'];

	/*$user_name 	= $_GET['username'];
	$user_id 	= $_GET['uid']; */

	if ( $user_name && $user_id ) {

		$participantObj 		= SetupGeneric::useModule('Participant');
		$participantObj->setItemInfo(array('id'=>$user_id));
		$participant_data 		= $participantObj->displayItemById();

		Session::saveSessionField('SESS_USER_NAME',$user_name);
		Session::saveSessionField('SESS_USER_REC_ID',$user_id);
		Session::saveSessionField('SESS_FULLNAME',ucwords($participant_data['forename'].' '.$participant_data['surname']));
		Session::saveSessionField('SESS_USER_EMAIL',$participant_data['emailAddress']);
		Session::saveSessionField('SESS_USER_LEVEL',$participant_data['accessLevel']);

		$miscObj 	= new Misc();

		$allowed_sections = $miscObj->getSharedSectByID($user_id);
		$miscObj = null;

		if ( count($allowed_sections) ) {
			foreach ( $allowed_sections as $allowed_sections_ele ) {
				Session::saveSessionField('SESS_SO_'.$allowed_sections_ele,1);
			}
		}

		if ( $participant_data['active'] ) {
			//echo 1;

			if ( $participant_data['accessLevel'] != 1 ) {

				$authObj = SetupGeneric::useModule('AuthorizedUser');
				$authObj->setItemInfo(array('id'=>$user_id));
				$perm_data = $authObj->displayItems();

				$DOC_ISSUER = 0;
				$TRG_MGR = 0;
				$EQP_MGR = 0;

				//dump_array($perm_data);


				if ( count($perm_data) ) {

					$participant_level = 2;
					$url_redirect = '/';

					$DOC_ISSUER = 0;
					$TRG_MGR = 0;
					$EQP_MGR = 0;

					foreach ( $perm_data as $value ) {
						if ( ( $value['sectionName'] == 'perm_doc' ) && $value['sectionActive'] ) {
							$DOC_ISSUER = 1;
						} else if ( $value['sectionName'] == 'perm_mgr_train' && $value['sectionActive'] ) {
							$TRG_MGR = 1;
						} else if ( $value['sectionName'] == 'perm_mgr_equip' && $value['sectionActive'] ) {
							$EQP_MGR = 1;
						}
					}

				} else if ( !count($perm_data) ) {

					$participant_level = 3;
					$url_redirect = '/welcome_user.php';

					$DOC_ISSUER = 0;
					$TRG_MGR = 0;
					$EQP_MGR = 0;

				}

				$participantObj->setItemInfo(array('id'=>$user_id,'level'=>$participant_level));
				$participant_data 		= $participantObj->updateLevel();

				Session::saveSessionField('SESS_USER_LEVEL',$participant_level);

			} else {

				$DOC_ISSUER = 1;
				$TRG_MGR = 1;
				$EQP_MGR = 1;

				$eqObj = SetupGeneric::useModule('DefaultPage');
				$disp = $eqObj->displayItems();

				$url_redirect = "/";

				switch ($disp) {

					case 1: $url_redirect = "/";	break;

					case 2 : $url_redirect = "/documents/";	break;

					case 3 : $url_redirect = "/action_tracker/";	break;
				}
			}

if(strlen($_SESSION['SMARTISO_PATH'])>2)

			//if ($_SESSION['SMARTISO_PATH'])
			{
			$url_redirect=$_SESSION['SMARTISO_PATH'];
			unset($_SESSION['SMARTISO_PATH']);
			}

			Session::saveSessionField('URL',$url_redirect);

			Session::saveSessionField('DOC_ISSUER',$DOC_ISSUER);
			Session::saveSessionField('TRG_MGR',$TRG_MGR);
			Session::saveSessionField('EQP_MGR',$EQP_MGR);

			echo $url_redirect;

		} else {
			echo -2;
		}

	} else {
		echo -1;
	}
} else {
	echo -1;
}
?>