<?php
 /**
  $Id: logout.php,v 3.04 Thursday, November 25, 2010 1:06:21 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Authentication
  * @since  Wednesday, November 24, 2010 7:16:50 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

Session::destroySession();

redirection('/authentication/login.php');

?>