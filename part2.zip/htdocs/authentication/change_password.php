<?php
 /**
  $Id: change_password.php,v 3.08 Thursday, January 20, 2011 6:40:44 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Authentication
  * @since  Saturday, November 27, 2010 10:30:05 AM>
  */
 
// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'authentication/change_password.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

//Session::getSessionField('SESS_USER_REC_ID');

$objAuth = new Authentication();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
	
	//dump_array($_POST);
	
	$old_password		= $_POST['old_password'];
	$new_password		= $_POST['new_password'];
	$confirm_password	= $_POST['confirm_password'];
	
	$objAuth->setLoginInfo('',$old_password,$new_password,$confirm_password);
	
	try {
		$objAuth->changePassword();
	} catch ( ErrorException $e ) {
		$error_message =  $e->getMessage();
	}
}

$smarty->assign('error_message',$error_message);
$smarty->display('authentication/change_password.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>