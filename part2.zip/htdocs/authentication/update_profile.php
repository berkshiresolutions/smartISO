<?php
 /**
  $Id: manage_participants.php,v 4.58 Tuesday, February 01, 2011 5:14:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is used to edit participant details.
  *
  * Long description
  * Long description
  *
  * @author  Hemandeep Singh
  * @package Smartiso
  * @subpackage Setup
  * @since  Friday, September 17, 2010 3:55:12 PM>
  */
$class_participants = "selected_tab"; //For selected tabs
$LAST_BREAD_CRUM = "Participants"; // for current breadcrums

$_PAGE_VALIDATION_SCRIPT = 'email_check.js';
$_PAGE_VALIDATION_SCRIPT2 = 'authentication/update_profile.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$eqObj = SetupGeneric::useModule('Participant');
$partid		= getLoggedInUserId();
$miscObj  = new Misc();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$record_id				= $partid;
	$surname				= $_POST['surname'];
	$dateofbirth			= $_POST['date_of_birth'];
	$email					= $_POST['email'];
	$forename				= $_POST['forename'];
	$gender					= $_POST['gender'];
	//dump_array($_POST);
	$eqObj->setItemInfo(array(
						    'id' => $record_id,
							'forename' => $forename,
							'surname' => $surname,
							'date_of_birth' => $dateofbirth,
							'gender' => $gender,
							'email_address' => $email
							));

	$e=0;


	try {
		$eqObj->editItem();
		$e = 2;
	} catch ( ErrorException $e ) {
		echo $e->getMessage();
	}



	// Save data in db
	if ( $e ) {
		redirection("update_profile.php?e=".$e);
	}

}

//echo $partid;
if ( $partid ) {

	$eqObj->setItemInfo(array(
						    'id'=>$partid
							));

	$participant	= $eqObj->displayItemById();

	$participant_data['works_number'] 		=	$participant['worksNumber'];
	$participant_data['forename'] 			=	$participant['forename'];
	$participant_data['surname'] 			= 	$participant['surname'];
	$participant_data['date_of_birth'] 		= 	format_date($participant['dateOfBirth']);
	$participant_data['email'] 				= 	$participant['emailAddress'];

	$participant_data['gender'] 			= 	$participant['gender'];

	$participant_data['login_name'] 		= 	$participant['username'];

	$template_file = 'update_profile.tpl';

}

$smarty->assign('current_date',$miscObj->getCurDate());
$smarty->assign('participant_data',$participant_data);
$smarty->assign('active_inactive',$active_inactive);

$smarty->display('authentication/'.$template_file);

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>