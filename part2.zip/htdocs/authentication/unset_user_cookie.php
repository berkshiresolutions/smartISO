<?php
 /**
  $Id: unset_user_cookie.php,v 3.04 Saturday, November 27, 2010 10:06:47 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Authentication
  * @since  Friday, November 26, 2010 7:01:47 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

setcookie('username','',time()-10);
redirection('login.php');
?>