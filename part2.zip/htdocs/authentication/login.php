<?php
 /**
  $Id: login.php,v 3.34 Wednesday, December 08, 2010 5:53:36 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Login page
  *
  * This page will be entry point to the software.
  * User will be prompted for username and password.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Authentication
  * @since  Wednesday, September 15, 2010 5:38:18 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'authentication/login.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

// Check database connectivity
checkDatabaseConnection();

$username = $_COOKIE['username'];
Session::saveSessionField('SESS_USER_REC_ID',0);
$optionObj	 = new Option();
$col=$optionObj->getOption('_SU_LOGIN_COLOUR');
$ht=$optionObj->getOption('_SU_LOGIN_HEIGHT');
//$smarty->assign('_LOGIN_SCREEN_WELCOME_TEXT',_LOGIN_SCREEN_WELCOME_TEXT);
$smarty->assign('username',$username);
$smarty->assign('_LOGIN_SCREEN_WELCOME_TEXT',_LOGIN_SCREEN_WELCOME_TEXT);
$smarty->assign('boxcolour',$col);
$smarty->assign('imageht',$ht);
$smarty->assign('boxht',200+$ht);
$smarty->assign('datein',microtime());
$smarty->display('authentication/login1.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>