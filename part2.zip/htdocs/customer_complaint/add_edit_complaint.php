<?php
 /**
  $Id: add_edit_complaint.php,v 4.38 Monday, December 06, 2010 2:41:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Customer complaint
  * @since  Saturday, September 11, 2010 5:41:11 PM>
  */

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'customer_complaint/customer_complaint.js';
$_PAGE_VALIDATION_SCRIPT2 = 'common_script.js';

$LAST_BREAD_CRUM = "Customer Complaint"; // for current breadcrums

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$objComplaint = new Complaint();
$locObj = SetupGeneric::useModule('Locationgram');
$participantObj = SetupGeneric::useModule('Participant');

$objComplaint_nature   = SetupGeneric::useModule('ComplaintNature');
$records 		= $objComplaint_nature->displayItems();

$objComplaint_cat   = SetupGeneric::useModule('ComplaintCategory');
$complaint_cat 		= $objComplaint_cat->displayItems();
$objReference = new UniqueReference();
$impact = SetupGeneric::useModule('ImpactMeasure');
$impact_records = $impact->displayItems();
//dump_array($complaint_cat);



//dump_array($_POST);
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$record =  $_POST['id'];

	$save_finish 	 = (int) $_POST['save_finish'];

	$complaint_data = array(
								'location'=>$_POST['location'],
								'consider_risk'=>$_POST['consider_risk'],
								'description'=>$_POST['description'],
								'is_phone'=>(int) $_POST['phone_checkbox'],
								'is_fax'=>(int) $_POST['fax'],
								'is_person'=>(int) $_POST['is_person'],
								'is_email'=>(int) $_POST['is_email'],
								'is_letter'=>(int) $_POST['letter'],
								'first_name'=>$_POST['first_name'],
								'last_name'=>$_POST['last_name'],
								'relationship'=>$_POST['relation'],
								'address'=>$_POST['address'],
								'phone'=>$_POST['phone'],
								'email'=>$_POST['email'],
								'complaint_nature'=>(int) $_POST['nature_complaint'],
								'likelihood'=>$_POST['likelihood'],
								'impact'=>(int) $_POST['impact_problem'],
								'risk_rating'=>$_POST['risk_value'],
								'risk_color'=>$_POST['risk_background_color'],
								'complaint_category'=>$_POST['company_category'],
								'investigation'=>(int) $_POST['investigation'],
								'action'=>$_POST['action'],
								'who'=>$_POST['who_hidden'],
								'when'=>$_POST['when']
							);

	if ( $record ) {
		//dump_array($complaint_data);
		$objComplaint->setComplaintInfo($record,$complaint_data);
		$objComplaint->editComplaint();
	} else {
		$complaint_data['reference'] = $_POST['reference_number'];
		$complaint_data['unique_reference'] = $uniqueRefrence;
		$objComplaint->setComplaintInfo(0,$complaint_data);
		$objComplaint->addComplaint();
		$record = $objComplaint->lastrecordId();
	}

	if ( $save_finish ) {

		$objComplaint->updateStatus();
		$objAlert = new SendActionAlerts('complaint',$record);
		$objAlert->sendAlerts();
	}

	redirection("index.php?e=1");
}

if (is_array($records) ) {
	foreach ($records as $key=>$value) {
		$nature_complaint[$value['compNatureID']]	=	$value['name'];
	}
}

if (is_array($complaint_cat) ) {
	foreach ($complaint_cat as $key=>$value) {
		$complaint_category[$value['compCatID']]	=	$value['name'];
	}
}

if (is_array($impact_records) ) {
	foreach ($impact_records as $key=>$value) {
		$impact_arr[$value['ID']]	=	$value['name'];
	}
}


$likelihood_arr = array(
							1=>"Virtually Certain",
							2=>"Very Likely",
							3=>"Likely",
							4=>"Unlikely",
							5=>"Very Unlikely",
							6=>"Almost Impossible"
						);

$risk_rating = 'H';

if($risk_rating == '#'){
	$risk_rating = 'I';
}
switch ($risk_rating) {
			case 'I': $risk_bgcolor = "#ff0000"; break;
			case 'H': $risk_bgcolor = "#ff0000"; break;
			case 'M': $risk_bgcolor = "#ffbf00"; break;
			case 'L': $risk_bgcolor = "#00ff00"; break;
			case 'T': $risk_bgcolor = "#684398"; break;
			default : $risk_bgcolor = "#ff0000";
		}

$record_id = $_GET['id'];

$objComplaint->setComplaintInfo($record_id,"");
$data = $objComplaint->viewComplaint();
//dump_array($data);

$date_time = $data['time'];
$data_time_array = explode(" ",$date_time);

$date = $data_time_array[0];
$time = $data_time_array[1];

if(isset($_GET['id'])) {

	/* participant details*/
	$participantObj->setItemInfo(array(
						    'id'=>$data['who']
							));

	$participant_details	= $participantObj->displayItemById();


	$row['refrence_number'] = $data['reference'];
	$row['consider_risk'] = $data['considerRisk'];
	$row['complaint_description'] = $data['complaintDescription'];
	$selected_location = $data['locationId'];
	$row['cur_date'] = format_date($date);
	$row['cur_time'] = $time;
	$row['fname'] = $data['firstName'];
	$row['lname'] = $data['lastName'];
	$row['relation'] = $data['relationshipClient'];
	$row['phone'] = $data['phoneNumber'];
	$row['email'] = $data['emailAddress'];
	$row['address'] = $data['address'];
	$row['nature_complaint'] = $data['complaintNature'];
	$row['likelihood'] = $data['likelihood'];
	$row['impact'] = $data['impact'];
	$row['complaint_category'] = $data['complaintCategory'];
	$row['action'] = $data['action'];
	$row['when'] = format_date($data['when']);
	$row['who_display'] = $participant_details['forename'].' '.$participant_details['surname'];
	$row['who'] = $data['who'];
	$row['phone_check'] = $data['isPhone'];
	$row['email_check'] = $data['isEmail'];
	$row['fax_check'] = $data['isFax'];
	$row['person_check'] = $data['isPerson'];
	$row['letter_check'] = $data['isLetter'];
	$row['investigation_check'] = $data['isInvestigation'];
	$risk_rating = $data['riskRating'];
	$risk_bgcolor = $data['riskRatingColor'];
	$action = "Edit";

	if ($row['when'] == "00/00/0000") {
		$row['when'] = "";
	}

} else {
	$row['cur_date'] = date('m/d/Y');
	$row['cur_time'] = date('h:i');
       $uniqueRefrence = $objReference->getUniqueNumber('COMPLAINT');
	$row['refrence_number'] = $uniqueRefrence;
	$action = "Add";
	$selected_location = 0;

}

$location_data = $locObj->getLocations($selected_location);

$smarty->assign('id',$record_id);
$smarty->assign('action',$action);
$smarty->assign('row',$row);
$smarty->assign('locs',$location_data);
$smarty->assign('impact',$impact_arr);
$smarty->assign('complaint_category',$complaint_category);
$smarty->assign('risk_value',$risk_rating);
$smarty->assign('risk_background_color',$risk_bgcolor);
$smarty->assign('nature_complaint',$nature_complaint);
$smarty->assign('likelihood',$likelihood_arr);
//$smarty->debugging=true;
$smarty->display('customer_complaint/add_edit_complaint.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>