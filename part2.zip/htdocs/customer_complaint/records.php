<?php
 /**
  $Id: records.php,v 3.67 Thursday, December 02, 2010 6:15:09 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Customer complaint
  * @since  Saturday, September 11, 2010 5:42:36 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once _MYINCLUDES."record_listing_page.inc.php";

$objComplaint = new Complaint();
$data = $objComplaint->viewAllComplaints();

//dump_array($data);

?>

<input type='hidden' name='selected_radio' id='selected_radio' value='0'>
<table cellpadding="2" cellspacing="4" border="0" class="display" id="module_records">
	<thead>
		<tr style='color:#fff'>
			<th width='3%'>&nbsp;</th>
			<th width='20%'>Reference #</th>
			<th width='28%'>Description</th>
			<th width='20%'>When</th>
			<th width='22%'>Location</th>
			<th width='2%'>&nbsp;</th>
		</tr>
	</thead>
	<tbody>
		<?php
                if (is_array($data)){
		foreach($data as $row){
			if ( $row['when'] == "0000-00-00" ) {
				$date = format_date(date('m/d/Y'));
			} else {
				$date = format_date($row['when']);
			}
			$locationObj	=SetupGeneric::useModule('Locationgram');
			$locationObj->setItemInfo(array('id'=>$row['locationId']));
				$location_data = "";
				$location = $locationObj->getFUllLocation();
		?>
		<tr >
			<td class='record_row' rel='<?php echo $row['ID']?>'><input type='radio' name='record_radio' id='record_radio<?php echo $row['ID']?>' class='choose_radio' value='<?php echo $row['ID']?>'></td>
			<td class='record_row' rel='<?php echo $row['ID']?>'><label for='record_radio<?php echo $row['ID']?>'><?php echo $row['reference'] ?></label></td>
			<td class='record_row' rel='<?php echo $row['ID']?>'><?php echo $row['complaintDescription'] ?></td>
			<td  class='record_row' rel='<?php echo $row['ID']?>' align='center'><?php echo $date ?></td>
			<td class='record_row' rel='<?php echo $row['ID']?>'><?php echo $location ?></td>
			<td  class='record_row' rel='<?php echo $row['ID']?>' align='center'><?php echo format_date($row['when']); ?></td>
		</tr>
		<?php
}
		} ?>
	</tbody>
	<tfoot>
		<tr>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
		</tr>
	</tfoot>
</table>