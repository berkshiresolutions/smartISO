<?php
 /**
  $Id: report.php,v 3.12 Wednesday, November 24, 2010 3:08:26 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * for customer-complaint report
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Saturday, November 20, 2010 10:51:04 AM>
  */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$repObj = & new Report('html');
$repObj->setFilters(array('id'=>$_GET['id']));
$repObj->generateReport('CUSTOMERCOMLAINT');
$repObj->displayReport();


require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
