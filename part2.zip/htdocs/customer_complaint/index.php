<?php
 /**
  $Id: index.php,v 3.10 Wednesday, November 24, 2010 3:36:30 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Customer complaint
  * @since  Saturday, September 11, 2010 5:42:28 PM>
  */


// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'customer_complaint/index.js';
$_PAGE_VALIDATION_SCRIPT2 = '../jquery.rangeFilter.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$smarty->display('customer_complaint/index.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>