<?php

mail('lpc@smart-iso.com','message in a bottle','here is my message');