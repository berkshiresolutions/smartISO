<?php
	//debugging
	//error_reporting(E_ALL);
	//ini_set('display_errors', '1');
class Alert {

	private $live_server;
	private $html_mail;
	private $domain = _MYSERVER;
	//private $dbObject;

	public function __construct($p_type,$p_module) {
	
		//$classname = ucfirst($p_type).'Alert';
		$classname = strtolower($p_type).'Alert';
		//$this->dbObject = $p_db_obj;  //BOB never called removes warning

		include_once "../../includes/classes/cron/type".$classname.'.php';

		$mod_module = ucwords($p_module);
		//$mod_module = str_replace(' ','',$mod_module);

		$classnameCap = ucfirst($classname);

		$this->otype = new $classnameCap($mod_module,$this->domain);

		$this->otype->live_server = false;
		$this->otype->html_mail = true;

		return $this->otype;
	}


}
?>