<?php

$_HIDE_HTTP_HEADER = true;
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$bcp = new BCPMain();
$id = $_GET['id'];
$bcp->sendWarningInitiateEmails($id);

?>

   
