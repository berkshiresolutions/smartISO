<?php
//exit(); // uncomment when gurveers script is applied
//STANDARD HEADERS FOR CRON
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';



// COMPLETELY NEW WAY OF DOING THINGS (SHOULD WORK SMARTER...)
$modules = array(
	array('contract','callback'=>contractEmailDecorator::getCallback() )
	
);
//$module_name = 'DOCUMENT';
echoLn("pre-action alert");
include("actionalert.php");

foreach($modules as $module_dets) {
	$module_name = current($module_dets);
	echoLn( sprintf( "sending %s e-mails", $module_name ) );
	$emailTypes = array('blue','yellow','red','mgr');


	foreach($emailTypes as $type) {
		$alert = new Alert("{$type}Action",$module_name);
		echoLn("<span style='margin-left: 3em'>$type object created</span>");
	
		$alert->send($module_dets['callback']);
		//$alert->generate_email();
		//$alert->send_email();
		$alert = null;
		echoLn("<span style='margin-left: 3em'>$type sent</span>");
	}
}
function documentEmailContent($actionId) {
    echo $actionId."... documentEmailContent Called\r\n<br>";
}
function echoLn($what){
	echo $what."<br>";
}


class contractEmailDecorator {
    public static function getCallback() {
        return 'contractEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                        $objCon = new Contract();
        $reviewdata=$objCon->getActionsbyID($id);

        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/contracts.php?filter_date=">CLICK</a> Here to Contract Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>$reviewdata['ID'])));

        return $data;
    }

}
?>