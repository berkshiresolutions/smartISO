<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'trainapproval';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/cron/typeblue'.$module_name."Alert.php";


$alert = new BluetrainapprovalAlert();
?>