<?php

//STANDARD HEADERS FOR CRON
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

// COMPLETELY NEW WAY OF DOING THINGS (SHOULD WORK SMARTER...)
$modules = array('DOCUMENT','DOCUMENTALERT','DOCUMENTCONTRIBRESPONSE','smartlawI','smartlawC','smartlawR','smartlawD','smartlawT','smartlawreview');

//$module_name = 'DOCUMENT';
    
echoLn("pre-action alert");
include("actionalert.php");

foreach($modules as $module_name) {
	echoLn("sending $module_name e-mails");
	$emailTypes = array('blue','yellow','red','mgr');

	foreach($emailTypes as $type) {
		$alert = new Alert("{$type}Action",$module_name);
		
		echoLn("<span style='margin-left: 3em'>$type object created</span>");
	
		$alert->send();
		//$alert->generate_email();
		//$alert->send_email();
		$alert = null;
		echoLn("<span style='margin-left: 3em'>$type sent</span>");
	}
}

function echoLn($what){
	echo $what."<br>";
}

?>