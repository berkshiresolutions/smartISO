<?php
ini_set('max_execution_time', 0); //0=NOLIMIT
set_time_limit (0);
$id=$_GET["id"];
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$bcp=new BCPMain();
$bcp->sendWarningInitiateEmails($id);
exit();
?>
   
