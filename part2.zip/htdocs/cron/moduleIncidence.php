<?php
class Incidence {

	protected $alert_mail_days;
	public $result_set;
	public $action_url = "/action_tracker/non_conf_inc.php";
	private $dbObject;
	private $miscObj;
	private $participantObj;

	public function __construct($p_alert_mail_days,$p_misc_obj) {

		$this->alert_mail_days = $p_alert_mail_days;
		$this->result_set = array();
		$this->miscObj = $p_misc_obj;
		$this->actionObj = new Action();
		$this->participantObj	 	= SetupGeneric::useModule('Participant');

		/*if ( $p_alert_mail_days < 0 ) {
			$sql = "SELECT action_desc,action_who,action_when,done_date FROM `incidence_action`
				WHERE approved = '0'
				AND DATE_ADD(action_when,INTERVAL 1 DAY) = CURDATE()
				AND ( done_date = '0000-00-00' OR done_date IS NULL )
				ORDER BY action_who DESC";
		} else {
			$sql = "SELECT action_desc,action_who,action_when,done_date FROM `incidence_action`
				WHERE approved = '0'
				AND DATE_ADD(action_when,INTERVAL -".$this->alert_mail_days." DAY) = CURDATE()
				AND ( done_date = '0000-00-00' OR done_date IS NULL )
				ORDER BY action_who DESC";
		}*/

		$actions = $this->actionObj->viewCronByModule('incidence');
		//dump_array($actions);

		$current_date = $this->miscObj->getCurDate();

		/*echo $sql;

		exit;*/

		if (is_array($actions) ) {
			$k = 0;
			foreach ( $actions as $rec ) {

				if ( $p_alert_mail_days < 0 ) {
					$check_date = $this->miscObj->makeCustomDate($rec['dueDate'],'1','DAY');
				} else {
					$check_date = $this->miscObj->makeCustomDate($rec['dueDate'],'-'.$this->alert_mail_days,'DAY');
				}

				/*echo $current_date.'--'.$check_date.'###########'.$rec['dueDate'].'%%%%%%%%%%%'.$p_alert_mail_days;
				echo "<br/>";*/

				if ( $current_date != $check_date ) {
					continue;
				}

				$this->participantObj->setItemInfo(array('id'=>$rec['who']));
				$partcipantData = $this->participantObj->displayItemById();

				$this->result_set[$k]['action_desc'] 		= $rec['actionDescription'];

				$this->result_set[$k]['action_when'] 		= format_date($rec['dueDate']);
				$this->result_set[$k]['action_donedate'] 	= $rec['doneDate'];

				$this->result_set[$k]['action_who'] 		= ucwords($partcipantData['forename'].' '.$partcipantData['surname']);
				$this->result_set[$k]['action_email'] 		= $partcipantData['emailAddress'];
				$this->result_set[$k]['action_who_id'] 		= $partcipantData['participantID'];

				$this->result_set[$k++]['assignee']			= $rec['who'];
			}
		}
		return $this->result_set;
	}
}