<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$trngObj = new Training();
$participantObj	 	= SetupGeneric::useModule('Participant');
$objTrainingCourse  	= SetupGeneric::useModule('TrainingCourse');
$objAuth = SetupGeneric::useModule('AuthorizedUser');
$trng_mgrs = $objAuth->getIssuerPermission('perm_mgr_train',true);
//dump_array($trng_mgr);

$records = $trngObj->getCronData();
//dump_array($records);

$unique_records = array();

if ( count($records) ) {
	foreach ( $records as $value ) {
		$key = $value['courseID'].'_'.$value['assignDate'];
		$new_array[$key][$value['ID']] = $value;
	}
}

dump_array($new_array);
exit;

if ( count($new_array) ) {
	$email_data = "<table cellpadding='2' cellspacing='0' border='0' width='100%'>";
	foreach ( $new_array as $keyT=>$valueT ) {
		
		$course_id_date = explode('_',$keyT);
		
		$objTrainingCourse->setItemInfo(array('id'=>$course_id_date[0]));
		$courseData = $objTrainingCourse->displayItemById();
		
		//dump_array($courseData);
		
		$email_data .= "<tr><td colspan='4'>&nbsp;</td></tr>";
		$email_data .= "<tr bgcolor='#cccccc'><td colspan='3' class='heading_small'><b>Course Ref:</b> ";
		$email_data .= stripslashes($courseData['refNumber'])."&nbsp;&nbsp;<b>Course Name:</b> ".stripslashes($courseData['title'])."&nbsp;&nbsp;";
		$email_data .= "<b>Due Date:</b> ".format_date($course_id_date[1])."</td></tr>";
		$email_data .= "<tr bgcolor='#dedede'><td><b>Works No.</b></td><td class='normaltext'><b>First Name</b></td><td class='normaltext'><b>Last Name</b></td></tr>";
				
				
		
		if ( count($valueT) ) {
			foreach ( $valueT as $valueInd ) {
				//dump_array($valueInd);

				$p_name = $valueInd['participantName'];
				
				$last_name = $first_name = '';
				
				$name_arr = explode(' ',$p_name);
				$name_arr_count = count($name_arr);
				if ( $name_arr_count ) {
					for($i=1;$i<=($name_arr_count-1);$i++) {
						$last_name .= $name_arr[$i].' ';
					}
				}
				$last_name = trim($last_name,' ');
				$first_name = $name_arr[0];

				$email_data .= "<tr><td>".$valueInd['worksNumber']."</td><td class='normaltext'>";
				$email_data .= $first_name."</td><td class='normaltext'>".$last_name."</td></tr>";
			}
		}
	}
	$email_data .= "<tr><td></td><td></td></tr><tr><td>Regards</td><td></td></tr><tr><td>Smart-Iso</td><td></td></tr></table>";;
}

echo $email_data;

if ( count($trng_mgrs) ) {
	foreach( $trng_mgrs as $valueP ) {
		$participantObj->setItemInfo(array('id'=>$valueP['participantID']));
		$partcipantData = $participantObj->displayItemById();
		
		if ( $partcipantData['emailAddress'] != '' ) {
			@mail($partcipantData['emailAddress'],'Training Notification for upcoming training',$email_data,"Content-Type: TEXT/HTML\nFrom: no-reply@smart-iso.net");
			@mail('sanjeev24125@hotmail.com','Training Notification for upcoming training',$email_data,"Content-Type: TEXT/HTML\nFrom: no-reply@smart-iso.net");
		}
		
	}
}
exit;

?>