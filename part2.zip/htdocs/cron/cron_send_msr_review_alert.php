<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'MSRReviews';

include("actionAlert.php");

$alert = new Alert('blueMSRReviews',$module_name);
$alert = null;

?>