<?php
class ContributorDuedate {

	protected $alert_mail_days;
	public $result_set;
	public $action_url = "/company/personal_action_tracker/sdms1.php?through=email";
	private $miscObj;
	private $dbHand;
	private $participantObj;
	private $objFile;

	public function __construct($p_alert_mail_days,$p_misc_obj,$p_identifier) {

		$this->alert_mail_days = $p_alert_mail_days;
		$this->result_set = array();
		$this->miscObj = $p_misc_obj;
		 
		$this->dbHand = DB::connect(_DB_TYPE);
		 		
		$this->participantObj	 	= SetupGeneric::useModule('Participant');
		$this->objFile = new Upload();

		$current_date = $this->miscObj->getCurDate();

		$sql = sprintf("SELECT *,A.documentID AS doc_id FROM %s.cms_documents A, %s.cms_documents_metadata C, %s.cms_documents_contributors D
			WHERE A.cmsdocID = C.cmsdocID AND A.cmsdocID = D.cmsdocID
			AND D.passed = '0'
			AND A.status = 'U'
			AND ( C.dateApproved = '1900-01-01' OR C.dateApproved IS NULL )",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);

		$pStatement2 = $this->dbHand->prepare($sql);
		$pStatement2->execute();
		$records = $pStatement2->fetchAll(PDO::FETCH_ASSOC);

		//dump_array($records);

		if ( count($records) ) {
			$k = 0;
			foreach($records as $rec) {

				if ( $p_alert_mail_days < 0 ) {
					$check_date = $this->miscObj->makeCustomDate($rec['contribDueDate'],'1','DAY');
				} else {
					$check_date = $this->miscObj->makeCustomDate($rec['contribDueDate'],'-'.$this->alert_mail_days,'DAY');
				}

				/*echo $current_date.'----------'.$check_date.'&&&&&&&&&&&&&&&&&'.$rec['contribDueDate'];
				echo "<br/>";*/

				if ( $current_date != $check_date ) {
					continue;
				}

				$this->participantObj->setItemInfo(array('id'=>$rec['initiatedByParticipant']));
				$partcipantData = $this->participantObj->displayItemById();

				// $this->objFile

				$this->objFile->setFileInfo('incidence',array('id'=>$rec['doc_id']));
				$single_files_data = $this->objFile->getFileDetails();
				$doc_name = $single_files_data['usrFilename'];



				$this->result_set[$k]['action_desc'] 		= $rec['comments'];

				$this->result_set[$k]['action_when'] 		= format_date($rec['contribDueDate']);
				$this->result_set[$k]['action_donedate'] 	= $rec['dateApproved'] == '1900-01-01' ? '' : $rec['dateApproved'];

				$this->result_set[$k]['dep_code']			= $rec['fileReference'];
				$this->result_set[$k]['usr_filename']		= $single_files_data['usrFilename'];
				$this->result_set[$k]['sys_filename']		= $single_files_data['sysFilename'];
				$this->result_set[$k]['ver_new']			= $rec['versionNew'];
				$this->result_set[$k]['ver_old']			= $rec['versionOld'];
				$this->result_set[$k]['file_reference']		= $rec['fileReference'];
				$this->result_set[$k]['title']				= $rec['title'];
				$this->result_set[$k]['desc']				= $rec['description'];
				$this->result_set[$k]['dtype']				= $rec['documentType'];
				$this->result_set[$k]['dtype_sub']			= $rec['documentSubType'];
				$this->result_set[$k]['date_initiated']		= format_date($rec['dateInitiated']);
				$this->result_set[$k]['initiated_by']		= ucwords($partcipantData['forename'].' '.$partcipantData['surname']);
				$this->result_set[$k]['pages']				= $rec['pages'];

				$this->participantObj->setItemInfo(array('id'=>$rec['authParticipantID']));
				$partcipantData_send = $this->participantObj->displayItemById();

				$this->result_set[$k]['action_who'] 		= ucwords($partcipantData_send['forename'].' '.$partcipantData_send['surname']);
				$this->result_set[$k]['action_email'] 		= $partcipantData_send['emailAddress'];
				$this->result_set[$k]['action_who_id'] 		= $partcipantData_send['participantID'];

				$this->result_set[$k++]['assignee']			= $rec['authParticipantID'];

			}
		}

		return $this->result_set;
	}
}