<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name =  'risk assessment';

include("actionAlert.php");

$alert = new Alert('blue',$module_name);
$alert->generate_email();
$alert->send_email();
$alert = null;

$alert = new Alert('yellow',$module_name);
$alert->generate_email();
$alert->send_email();
$alert = null;

$alert = new Alert('red',$module_name);
$alert->generate_email();
$alert->send_email();
$alert = null;

$alert = new Alert('redmgr',$module_name);
$alert->generate_email();
$alert->send_email();
$alert = null;
?>