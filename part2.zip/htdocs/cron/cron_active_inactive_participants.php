<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
 
		$dbh = DB::connect(_DB_TYPE);


$current_date = customCurrentDate();

if ( _DB_TYPE == 'mysql') {
	$def_date = '0000-00-00';
} else {
	$def_date = '1900-01-01';
}

$upd2 = sprintf("UPDATE %s.participant_database
		SET active = '0'
		WHERE active = '1' AND
		(leavingDate < %s AND leavingDate != '%s')
		OR
		(joiningDate > %s AND joiningDate != '%s')",_DB_OBJ_FULL,$current_date,$def_date,$current_date,$def_date);

$upd1 = sprintf("UPDATE %s.participant_database
		SET active = '1'
		WHERE active = '0'
		AND joiningDate < %s
		AND leavingDate > %s",_DB_OBJ_FULL,$current_date,$current_date);

$pStatement1 = $dbh->prepare($upd1);
$pStatement2 = $dbh->prepare($upd2);

$pStatement1->execute();
$pStatement2->execute();
?>