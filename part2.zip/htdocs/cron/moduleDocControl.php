<?php
class DocControl {

	protected $alert_mail_days;
	public $result_set;
	public $action_url = "/company/personal_action_tracker/sdms.php?through=email";
	private $miscObj;
	private $dbHand;
	private $participantObj;
	private $objFile;

	public function __construct($p_alert_mail_days,$p_misc_obj,$p_identifier) {

		$this->alert_mail_days = $p_alert_mail_days;
		$this->result_set = array();
		$this->miscObj = $p_misc_obj;
 
		$this->dbHand = DB::connect(_DB_TYPE);
		$this->participantObj	 	= SetupGeneric::useModule('Participant');
		$this->objFile = new Upload();

		$current_date = $this->miscObj->getCurDate();

		$sql = sprintf("SELECT *,A.documentID AS doc_id FROM %s.cms_documents A, %s.cms_documents_metadata C
			WHERE A.cmsdocID = C.cmsdocID
			AND A.status = 'U'
			AND ( C.dateApproved = '1900-01-01' OR C.dateApproved IS NULL )",_DB_OBJ_FULL,_DB_OBJ_FULL);

		$pStatement2 = $this->dbHand->prepare($sql);
		$pStatement2->execute();
		$records = $pStatement2->fetchAll(PDO::FETCH_ASSOC);


		if ( count($records) ) {
			$k = 0;
			foreach($records as $rec) {

				if ( $p_alert_mail_days < 0 ) {
					$check_date = $this->miscObj->makeCustomDate($rec['dateInitiated'],'1','DAY');
				} else {
					$check_date = $this->miscObj->makeCustomDate($rec['dateInitiated'],'-'.$this->alert_mail_days,'DAY');
				}

				/*echo $current_date.'----------'.$check_date.'&&&&&&&&&&&&&&&&&'.$rec['contribDueDate'];
				echo "<br/>";*/

				if ( $current_date != $check_date ) {
					continue;
				}

				$this->participantObj->setItemInfo(array('id'=>$rec['initiatedByParticipant']));
				$partcipantData_send = $this->participantObj->displayItemById();

				$this->result_set[$k]['action_desc'] 		= $rec['actionSummary'];

				$this->result_set[$k]['action_when'] 		= format_date($rec['dateInitiated']);
				$this->result_set[$k]['action_donedate'] 	= $rec['dateApproved'] == '1900-01-01' ? '' : $rec['dateApproved'];

				$this->result_set[$k]['action_who'] 		= ucwords($partcipantData_send['forename'].' '.$partcipantData_send['surname']);
				$this->result_set[$k]['action_email'] 		= $partcipantData_send['emailAddress'];
				$this->result_set[$k]['action_who_id'] 		= $partcipantData_send['participantID'];

				$this->result_set[$k++]['assignee']			= $rec['initiatedByParticipant'];
			}
		}

		return $this->result_set;
	}
}