<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'inspectionna';

include("actionAlert.php");

$alert = new Alert('blueInspectionna',$module_name);


?>