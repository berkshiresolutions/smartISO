<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'inspectionhaz';

include("actionAlert.php");

$alert = new Alert('blueinspectionhaz',$module_name);


?>