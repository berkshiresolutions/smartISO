<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$module_name = 'doc control';

include("actionAlert.php");

$alert = new Alert('blue',$module_name);

?>