<?php
class Contractreview {

	protected $alert_mail_days;
	public $result_set;
	public $action_url = "/action_tracker/non_conf_inc.php";
	private $dbObject;
	private $miscObj;
	private $participantObj;

	public function __construct($p_alert_mail_days,$p_misc_obj) {
/*
		$this->alert_mail_days = $p_alert_mail_days;
		$this->result_set = array();
		$this->miscObj = $p_misc_obj;
		$this->actionObj = new Action();
		$this->participantObj	 	= SetupGeneric::useModule('Participant');

		$actions = $this->actionObj->viewCronByModule('contractreview');
		//dump_array($actions);

		$current_date = $this->miscObj->getCurDate();


		if (is_array($actions) ) {
			$k = 0;
			foreach ( $actions as $rec ) {

				if ( $p_alert_mail_days < 0 ) {
					$check_date = $this->miscObj->makeCustomDate($rec['dueDate'],'1','DAY');
				} else {
					$check_date = $this->miscObj->makeCustomDate($rec['dueDate'],'-'.$this->alert_mail_days,'DAY');
				}



				if ( $current_date != $check_date ) {
					continue;
				}

				$this->participantObj->setItemInfo(array('id'=>$rec['who']));
				$partcipantData = $this->participantObj->displayItemById();

				$this->result_set[$k]['action_desc'] 		= $rec['actionDescription'];

				$this->result_set[$k]['action_when'] 		= format_date($rec['dueDate']);
				$this->result_set[$k]['action_donedate'] 	= $rec['doneDate'];

				$this->result_set[$k]['action_who'] 		= ucwords($partcipantData['forename'].' '.$partcipantData['surname']);
				$this->result_set[$k]['action_email'] 		= $partcipantData['emailAddress'];
				$this->result_set[$k]['action_who_id'] 		= $partcipantData['participantID'];

				$this->result_set[$k++]['assignee']			= $rec['who'];
			}
		}
		*/
		return $this->result_set;
	}
}