<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'library';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/cron/archive'.$module_name.".php";
$libObj= new LibArchive();
$libObj->UpdateArchives();
?>