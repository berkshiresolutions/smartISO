<?php
//exit(); // uncomment when gurveers script is applied
//STANDARD HEADERS FOR CRON
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';



// COMPLETELY NEW WAY OF DOING THINGS (SHOULD WORK SMARTER...)
$modules = array(
	array('smartlawC','callback'=>smartlawCEmailDecorator::getCallback() )
	,array('smartlawT','callback'=>smartlawTEmailDecorator::getCallback() )
	,array('smartlawD','callback'=>smartlawDEmailDecorator::getCallback() )
	,array('smartlawR','callback'=>smartlawREmailDecorator::getCallback() )
	,array('smartlawI','callback'=>smartlawIEmailDecorator::getCallback() )
	,array('smartlawreview','callback'=>smartlawReviewEmailDecorator::getCallback() )
		
);
//$module_name = 'DOCUMENT';
echoLn("pre-action alert");
include("actionalert.php");

foreach($modules as $module_dets) {
	$module_name = current($module_dets);
	echoLn( sprintf( "sending %s e-mails", $module_name ) );
	$emailTypes = array('blue','yellow','red','mgr');


	foreach($emailTypes as $type) {
		$alert = new Alert("{$type}Action",$module_name);
		echoLn("<span style='margin-left: 3em'>$type object created</span>");
	
		$alert->send($module_dets['callback']);
		//$alert->generate_email();
		//$alert->send_email();
		$alert = null;
		echoLn("<span style='margin-left: 3em'>$type sent</span>");
	}
}
function documentEmailContent($actionId) {
    echo $actionId."... documentEmailContent Called\r\n<br>";
}
function echoLn($what){
	echo $what."<br>";
}


class smartlawCEmailDecorator {
    public static function getCallback() {
        return 'smartlawCEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                        $objSL = new SmartLaw();
        $reviewdata=$objSL->getActionsbyID($id);
  //              return array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'));
        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Communication Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Referencennnnn</strong>','right'=>$reviewdata['reference']." ".$reviewdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$reviewdata['slsLegislation'])));
        return $data;
    }
}
class smartlawTEmailDecorator {
    public static function getCallback() {
        return 'smartlawTEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                        $objSL = new SmartLaw();
        $reviewdata=$objSL->getActionsbyID($id);
  //              return array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'));
        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Training Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Referencellll</strong>','right'=>$reviewdata['reference']." ".$reviewdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$reviewdata['slsLegislation'])));
 

return $data;
    }
}

class smartlawDEmailDecorator {
    public static function getCallback() {
        return 'smartlawDEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                        $objSL = new SmartLaw();
        $reviewdata=$objSL->getActionsbyID($id);
  //              return array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'));
        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Documented Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Referencejjjj</strong>','right'=>$reviewdata['reference']." ".$reviewdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$reviewdata['slsLegislation'])));
 

return $data;
    }
}

class smartlawREmailDecorator {
    public static function getCallback() {
        return 'smartlawREmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                        $objSL = new SmartLaw();
        $reviewdata=$objSL->getActionsbyID($id);
  //              return array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'));
        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Relevent Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Referencehhhh</strong>','right'=>$reviewdata['reference']." ".$reviewdata['slyear']),'description'=>array('left'=>'<strong>itle</strong>','right'=>$reviewdata['slsLegislation'])));
    
return $data;
        }
}

class smartlawIEmailDecorator {
    public static function getCallback() {
        return 'smartlawIEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                $objSL = new SmartLaw();
        $reviewdata=$objSL->getActionsbyID($id);
		//dump_array($reviewdata);
  //              return array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'));
        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Interpreted Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Referencefffff</strong>','right'=>$reviewdata['reference']." ".$reviewdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$reviewdata['slsLegislation'])));
   

return $data;
        }
}

class smartlawreviewEmailDecorator {
    public static function getCallback() {
        return 'smartlawreviewEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
        $objSL = new SmartLaw();
        $reviewdata=$objSL->getReviewActionsbyID($id);
		//dump_array($reviewdata);
  //              return array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'));
        $data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Alert'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Referenceuuu</strong>','right'=>$reviewdata['reference']." ".$reviewdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$reviewdata['slsLegislation'])));
 
        
    
        return $data;
    }
}

?>