<?php
//$_HIDE_HTTP_HEADER = true;
//
//require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$orgObj				= SetupGeneric::useModule('Organigram');
$participantObj	 	= SetupGeneric::useModule('Participant');

// getParticipant // buID
$managers = $orgObj->getAllPosts();
//dump_array($managers);
$newline = "\n";

$xmlstr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".$newline;
$xmlstr .= "<hierarchy>".$newline;

if ( count($managers) ) {
	
	$xmlstr .= "\t<participants>".$newline;
	
	foreach($managers as $rec ) {
        
        $participantObj->setItemInfo(array('id'=>$rec['participantID']));
		$person_info = $participantObj->displayItemById();

        //dump_array($person_info);
        $manager_name 	= $person_info['forename'].' '.$person_info['surname'];
		
		$manager_name 	= $manager_name != ' ' ? ucwords($manager_name) : '-'; 
		$manager_email 	= $person_info['emailAddress'] != '' ? $person_info['emailAddress'] : '-';
		
		$mgrstr = "\t\t\t<managerbusinessUnitId>".$rec['buID']."</managerbusinessUnitId>".$newline;
		$mgrstr .= "\t\t\t<managerpositionName>".$rec['positionName']."</managerpositionName>".$newline;
		$mgrstr .= "\t\t\t<managerId>".$rec['participantID']."</managerId>".$newline;
		$mgrstr .= "\t\t\t<managerName>".$manager_name."</managerName>".$newline;
		$mgrstr .= "\t\t\t<managerEmail>".$manager_email."</managerEmail>".$newline;
		
		
        
        $orgObj->setItemInfo(array('id'=>$rec['buID']));
		$bu_participants = $orgObj->getParticipant();
		
		if ( count($bu_participants) && $bu_participants ) {
			
			foreach( $bu_participants as $rec2 ) {
				
				$participantObj->setItemInfo(array('id'=>$rec2['participantID']));
                $person_info_participant = $participantObj->displayItemById();
				
				if ( $person_info_participant['emailAddress'] != '' ) {
				
					$xmlstr .= "\t\t<participant>".$newline;
					$xmlstr .= "\t\t\t<participantId>".$rec2['participantID']."</participantId>".$newline;
					$xmlstr .= "\t\t\t<participantName>".ucwords($person_info_participant['forename']." ".$person_info_participant['surname'])."</participantName>".$newline;
					$xmlstr .= "\t\t\t<participantEmail>".$person_info_participant['emailAddress']."</participantEmail>".$newline;
					$xmlstr .= $mgrstr;
					$xmlstr .= "\t\t</participant>".$newline;
					
				}
				
			} // end inner while
			
		} // end inner if 
		
		
	} // end while
	
	$xmlstr .= "\t</participants>".$newline;
} // end if


$xmlstr .= "</hierarchy>".$newline;
//echo $xmlstr;

$orgObj				= NULL;
$participantObj	 	= NULL;
?>