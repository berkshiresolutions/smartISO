<?php
//exit(); // uncomment when gurveers script is applied
//STANDARD HEADERS FOR CRON
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';



// COMPLETELY NEW WAY OF DOING THINGS (SHOULD WORK SMARTER...)
$modules = array(
	array('contractreview','callback'=>contractreviewEmailDecorator::getCallback() )
	
);
//$module_name = 'DOCUMENT';
echoLn("pre-action review alert");
include("actionalert.php");

foreach($modules as $module_dets) {
	$module_name = current($module_dets);
	echoLn( sprintf( "sending %s e-mails", $module_name ) );
//	$emailTypes = array('blue','yellow','red','mgr');
//new types for contract should be replaced and contract reviews moved to normal actions/action tracker
	$emailTypes = array('contractreviewmgr');

	foreach($emailTypes as $type) {
		$alert = new Alert("{$type}Action",$module_name);
		echoLn("<span style='margin-left: 3em'>$type object created</span>");
	
		$alert->send($module_dets['callback']);
		//$alert->generate_email();
		//$alert->send_email();
		$alert = null;
		echoLn("<span style='margin-left: 3em'>$type sent</span>");
	}
}
function documentEmailContent($actionId) {
    echo $actionId."... documentEmailContent Called\r\n<br>";
}
function echoLn($what){
	echo $what."<br>";
	//return $what;
}


class contractreviewEmailDecorator {
    public static function getCallback() {
        return 'contractreviewEmailDecorator::decorate';
    }
    public static function decorate($id) {
        echo "$id decorated...\r\n<br>";
                        $objCon = new Contract();
        $reviewdata=$objCon->getReviewsbyID($id);
		
	//$n  = 	$this->echoLn();
	//echo $n;
	
//}

//$emailTypes = array('contractreviewblue','contractreviewyellow','contractreviewred','contractreviewmgr');
		//dump_array($type);
	//foreach($emailTypes as $type) {
	
	
		  $data=array('singleColData'=>array('summary'=>'You are receiving this managers alert email because the above mentioned contract review is overdue for the contract manager listed above.','click-here-url'=>''),'twoColData'=>array('authorizing'=>array('left'=>'<strong></strong>','right'=>""),'summy'=>array('left'=>'<strong>Summary:</strong>','right'=>"The above contract is overdue for review for the above assigned person")  ));
		   return $data;
	
      

       
	//}
    }

}
?>