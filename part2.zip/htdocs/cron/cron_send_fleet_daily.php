<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'vehicle';

include("actionAlert.php");
//echo "dsfdsfsd";
$alert = new Alert('fleetdaily',$module_name);
$alert->generate_email();
$alert->send_email();
$alert = null;

?>