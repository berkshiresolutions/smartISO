<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL=true;
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$msg.="BEGIN:VCALENDAR\n";
$msg.="VERSION:2.0\n";
$msg.="PRODID:-//Foobar Corporation//NONSGML Foobar//EN\n";
$msg.="METHOD:REQUEST\n"; // requied by Outlook
$msg.="BEGIN:VEVENT\n";
$msg.="UID:".date('Ymd').'T'.date('His')."-".rand()."-example.com\n"; // required by Outlok
$msg.="DTSTAMP:".date('Ymd').'T'.date('His')."\n"; // required by Outlook
$msg.="DTSTART:20140513T000000\n"; 
$msg.="SUMMARY:TESTsss\n";
$msg.="DESCRIPTION: this is just a test\n";
$msg.="END:VEVENT\n";
$msg.="END:VCALENDAR\n";


$headers  = 'Content-Type: multipart/alternative' . "\r\n";
$headers .= 'Content-Type: text/Calendar method=REQUEST' . "\r\n";
$headers .= 'Content-Disposition: inline; filename=calendar.ics ' . "\r\n";

$headers .= 'From: rsa@smart-iso.net' . "\r\n";
$subject="testing ffffff";

mail("robertabery@btinternet.com",$subject,stripslashes($msg),$headers);

?>