<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'manual handling';
include("actionAlert.php");

$module_names = array('manual handlingT','manual handlingL','manual handlingE','manual handlingI');

foreach ( $module_names as $value ) {

    $alert = new Alert('blue',$value);
    $alert->generate_email();
    $alert->send_email();
    $alert = null;

    $alert = new Alert('yellow',$value);
    $alert->generate_email();
    $alert->send_email();
    $alert = null;

    $alert = new Alert('red',$value);
    $alert->generate_email();
    $alert->send_email();
    $alert = null;

    $alert = new Alert('redmgr',$value);
    $alert->generate_email();
    $alert->send_email();
    $alert = null;

}


?>