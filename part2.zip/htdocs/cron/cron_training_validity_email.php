<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$trnObj 		= new TrainingValidEmail();
$course_data 	= $trnObj->getSoonInvalidCourseData();

//dump_array($course_data);

$miscObj 		= new Misc();

//$current_date 	= '2011-05-07';
$current_date 	= $miscObj->getCurDate();
$miscObj		= null;

if ( count($course_data[$current_date]) ) {

	// for trainee
	if ( is_array($course_data[$current_date]['T']) ) {
		foreach ( $course_data[$current_date]['T'] as $course_ele_val ) {

			$optObj = new Email('html');

			// Add Recipients to send email to
			$optObj->addRecipient($course_ele_val['participantName'],$course_ele_val['trainee_email'],$course_ele_val['salutation']);

			$optObj->generateEmailFromData('TRAINING_INVALID_COURSE',array(
																'FULLHOSTNAME'=>_MYSERVER,
																'COURSE_REF'=>$course_ele_val['reference'],
																'COURSE_NAME'=>$course_ele_val['title'],
																'DATE_COMPLETED'=>format_date($course_ele_val['completeDate']),
																'DATE_INVALID'=>format_date($course_ele_val['course_valid_till_date'])
																));
			$optObj->send();
		}
	}

	// for managers

	if ( 0 && is_array($course_data[$current_date]['M']) ) {
		foreach ( $course_data[$current_date]['M'] as $course_ele_val ) {

			$optObj = new Email('html');

			// Add Recipients to send email to
			$optObj->addRecipient($course_ele_val['participantName'],$course_ele_val['trainee_email'],'Mr.');

			$optObj->generateEmailFromData('TRAINING_INVALID_COURSE',array(
																'FULLHOSTNAME'=>_MYSERVER,
																'COURSE_REF'=>$course_ele_val['reference'],
																'COURSE_NAME'=>$course_ele_val['courseName'],
																'DATE_COMPLETED'=>$course_ele_val['completeDate'],
																'DATE_INVALID'=>$course_ele_val['course_valid_till_date']
																));
			$optObj->send();
		}
	}
}
?>