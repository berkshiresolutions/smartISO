<?php
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'investigation';

include("actionAlert.php");

$alert = new Alert('blueInvestigation',$module_name);

?>