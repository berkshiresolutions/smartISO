<?php
 /**
  $Id: risk_action_priority.php,v 3.53 Tuesday, December 28, 2010 4:23:39 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * @author  Anil <simurg@gmail.com>
  * @package Smartiso
  * @subpackage Setup
  * @since  Wednesday, September 15, 2010 7:42:06 PM>
  */

$_HIDE_HTTP_HEADER = true;
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$objDocType = SetupGeneric::useModule('DeleteTrail');
$miscObj		=	new Misc();

$delete_trail = $objDocType->displayItems();
$delete_trail_arr = explode(':',$delete_trail);

$present_date = $miscObj->getCurDate();

$all_recs = $miscObj->getTrailRecords();
//dump_array($all_recs);

if ( count($all_recs) ) {
	foreach ( $all_recs as $val ) {
		$check_date = $miscObj->makeCustomDate($val['addedOn'],$delete_trail_arr[1],$delete_trail_arr[0]);
		
		if ( $check_date == $present_date ) {
			switch($val['moduleName']) {
				case 'RA' : $moduleObj = new RiskAssessment();
							$moduleObj->setRiskInfo($val['recordID'],"");
							$moduleObj->deleteStepAssessment();
					break;
				case 'INSP' : $moduleObj = new InspectionMain();
							  $moduleObj->setInspectionInfo($val['recordID'],"");
							 $moduleObj->purgeInspection();
					break;
				case 'INCD' : $moduleObj = new IncidenceMain();
							  $moduleObj->setIncidenceInfo($val['recordID'],"");
							 $moduleObj->purgeIncidence();
					break;
				case 'INVG' : $moduleObj = new InvestigationMain();
							  $moduleObj->setInvestigationInfo($val['recordID'],"");
							 $moduleObj->purgeInvestigation();
					break;
				case 'NHC' : $moduleObj = new NhpMain();
							 $moduleObj->setNhpInfo($val['recordID'],"");
							 $moduleObj->purgeNhp();
					break;
				case 'MH' : $moduleObj = new ManualHandling();
							$moduleObj->setManualHandlingInfo($val['recordID'],"");
							 $moduleObj->deleteManualHandling();
					break;
				case 'CT' : $moduleObj = new Contractor();
							$moduleObj->setContractorInfo($val['recordID'],1,"");
							 $moduleObj->purgeContractor();
					break;
				case 'DSE' : $moduleObj = new DseAssessment();
							 $moduleObj->setDseAssessmentInfo($val['recordID'],"");
							 $moduleObj->purgeDseAssessment();
					break;
				case 'TRG' : $moduleObj = new Training();
							 $moduleObj->setTraineeInfo($val['recordID'],"");
							 $moduleObj->deleteCourseAssignedTrainee();
					break;
			}
			
			$miscObj->deleteArchivedRecordInfo(array('module'=>$val['moduleName'],'rec_id'=>$val['recordID'])); 
		}
	}
}
?>