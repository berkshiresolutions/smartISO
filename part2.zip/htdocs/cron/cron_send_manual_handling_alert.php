<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$module_name = 'manualhandling';
include("actionAlert.php");

//$module_names = array('manualhandlingT','manualhandlingL','manualhandlingE','manualhandlingI');

//foreach ( $module_names as $value ) {
$alert = new Alert('bluemanualhandling',$module_name);

 //   $alert = null;

//}


?>