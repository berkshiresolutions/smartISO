<?php

/**
* This file is used to audit graph
*
*
* 
* @author Sanjeev Krishan
* @package Smartiso
* @subpackage audit
* @since  20 aug, 2010 IST
* @version 0.1 
*/

$filter['id']='';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

include(_MYCLASSES.'graph/graphs.php');
include(_MYCLASSES.'graph/audit.php');

$audit = new AuditGraph($filter);
$graph_data = $audit->exportGraphData();

$graph = new Graphs('horizontal','audit',$graph_data);

//dump_array($graph);

$smarty->assign('chart_object','audit_chart');
$smarty->assign('chart_height',$graph->graph_height);
$smarty->assign('chart_width',$graph->graph_width);
$smarty->assign('chart_backgroundcolor','#FFFFFF');
$smarty->assign('data_file',$graph->xml_data_file);
$smarty->assign('setting_file',$graph->graph_settings_file);

$smarty->display('audit/graph.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>