<?php
 /**
  $Id: records.php,v 3.49 Tuesday, December 14, 2010 12:31:36 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, September 07, 2010 12:01:16 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once _MYINCLUDES."record_listing_page.inc.php";

$contractObj 		= new Contract();
$optObj 		= new Option();

$participantObj	 	= SetupGeneric::useModule('Participant');
$archive_session 	= (int) Session::getSessionField('ARCHIVE_RECORDS');
$archive_data 		= array('archive'=>$archive_session);

$contractObj->setContractInfo(0,1,$archive_data,40,60);
$contractObj->contractsInfo['archive']=$archive_session;

$isShortTermOrTender  = $_GET['isShortTermOrTender'];
if($isShortTermOrTender == "")
{
	$isShortTermOrTender ="-1";
}
$buID  = $_GET['buID'];


if($buID){
	$records = $contractObj->getAllBUContracts($buID);
}elseif($isShortTermOrTender == 2 || $isShortTermOrTender == 1 || $isShortTermOrTender == 0){
$records = $contractObj->getAllContracts($isShortTermOrTender);
}
else{
	$records = $contractObj->viewAllContracts();
}

$USER_ID = getLoggedInUserId();
$USER_LEVEL=getUserAccessLevel();

$eqObj = SetupGeneric::useModule('Email');
$email	= $eqObj->displayItems();

//  print "<pre>"; print_r($records);

//echo $USER_ADMIN_AUTHORISED_USER ;
// dump_array($records);
?>

<input type='hidden' name='admin' id='admin' value='<?php echo $USER_ADMIN_AUTHORISED_USER?>'>
<input type='hidden' name='selected_radio' id='selected_radio' value='0'>
<input type='hidden' name='selected_user' id='selected_user' value='0'>
<input type='hidden' name='current_user' id='current_user' value='<?php echo $USER_ID?>'>

<table cellpadding="2" cellspacing="4" border="0" class="display" id="module_records">

	<thead>
		<tr style='color:#fff'>
			<th width='3%'>&nbsp;</th>
			<th width='10%'>Contract Ref</th>
			<th width='20%'>Goods/Service Contract Provision</th>
			<th width='15%'>Business Unit</th>
			<th width='*'>Contract Manager</th>
			<th width='15%'>Q/T</th>
			<th width='5%'>End Date</th>
			<th width='15%'>Supplier</th>
			<th width='15%'>Review Due Date</th>
			
		</tr>
	</thead>
	<tbody>
		<?php
	
	$quarter=$contractObj->getquarter(date('Y'),date('m'),date('d'));

	if ($offset_quarter["quarter"] ==4)
		$offset_day=7*$contractObj->getDetailedContractReviewOffset();
	else
		$offset_day=7*$contractObj->getStandardContractReviewOffset();
		
				$blue_value = '#CC1100';
				$yellow_value = '#FF3333';
				$red_value = '#EEB4B4';
				
				
				
		if ( count($records) ) {
			foreach ( $records as $value ) {


 if ($USER_LEVEL== 1 || $USER_ID==$value["contractManagerID"]  || $USER_ID==$value["managerApproverID"]  || $USER_ID==$value["directorApproverID"] || $USER_ID==$value["reviewer"])
{
				$participant_id = $value['contractManagerID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
				$businessUnit = $contractObj->getBusinessUnit($value['buID']);
				$contractorName = '';
				$useApprovedContractor = $value['useApprovedContractor'];
				if ($useApprovedContractor) {
					$dbHand = DB::connect(_DB_TYPE);
					$sql = sprintf("SELECT * FROM %s.contractor WHERE ID = %d",_DB_OBJ_FULL,$useApprovedContractor);
					$pStatement = $dbHand->prepare($sql);
					$pStatement->execute();
					$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
					$contractorName = $resultSet[0]['companyName'];
				}




switch($value['shortTermOrTender']) 
{
	case 2:
	$quote='OJEU Notice';break;
	case 1:
	$quote='Tender';break;
	default :
	$quote='Quote';break;
	
}
/*			
				$quarterCovered="";
				$nowMonth = intval(date('m'));
				if ($nowMonth >= 1 && $nowMonth <= 3) $quarterCovered = 1;
				else if ($nowMonth >= 4 && $nowMonth <= 6) $quarterCovered = 2;
				else if ($nowMonth >= 7 && $nowMonth <= 9) $quarterCovered = 3;
				else if ($nowMonth >= 10 && $nowMonth <= 12) $quarterCovered = 4;
*/

				$quarterCovered=$quarter["quarter"];

				$qc = $quarterCovered;
				$yc = intval(date('Y'));

$f1f2 = 1;
				$dbHand = DB::connect(_DB_TYPE);
				$sql = sprintf("SELECT approved FROM %s.contract_review WHERE contractID = %d AND quarterCovered = %d AND yearCovered = %d AND f1f2 = %d",_DB_OBJ_FULL,$value['ID'],$qc,$yc,$f1f2);
				$pStatement = $dbHand->prepare($sql);
				$pStatement->execute();
				$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
				$approvedF1 = $resultSet[0]['approved'];

$f1f2 =2;
				$sql = sprintf("SELECT approved FROM %s.contract_review WHERE contractID = %d AND quarterCovered = %d AND yearCovered = %d AND f1f2 = %d",_DB_OBJ_FULL,$value['ID'],$qc,$yc,$f1f2);
				$pStatement = $dbHand->prepare($sql);
				$pStatement->execute();
				$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
				$approvedF2 = $resultSet[0]['approved'];




				$reviewEndDate = strtotime($value['reviewDueDate']);
				$reviewDate = strtotime($value['reviewDate']);
				$today = time();
				$yellowdays = strtotime ( '-'.$email['yellow_value'].' day' , $reviewEndDate ) ;
				$bluedays = strtotime ( '-'.$email['blue_value'].' day' , $reviewEndDate) ;
				$reddays = strtotime ( '-'.$email['red_value'].' day' , $reviewEndDate) ;

				 //echo "reviewEndDate=".date ( 'Y-m-j' , $reviewEndDate )." reviewDate=".date ( 'Y-m-j' , $reviewDate )." today=".date ( 'Y-m-j' , $today )." 3day=".date ( 'Y-m-j' , $yellowdays )." 5day=".date ( 'Y-m-j' , $bluedays )."<br>"; 
				$outstandingReviewsCheck=1;
				if	($approvedF1==1)
				{
					$bg 	   = "";
					$outstandingReviewsCheck=0;
					
				}
				elseif ($value['reviewCompleteDate'] != "")
				{
					$bg 	   = "#804040";
				}
				elseif ($today >= $bluedays+$offset_day && $today < $yellowdays+$offset_day)
				{
					$bg 	   = '#7294BF';
					//print "blue";
				}	
				elseif ($today >= $yellowdays+$offset_day && $today < $reddays+$offset_day)
				{
					$bg 	   = '#FFF000';
					//print "Yesllo";
				}
				elseif($today >= $reddays+$offset_day)
				{
					$bg 	   = '#FF0000';
					$outstandingReviewsCheck=0;
				}
				else
				{
					$bg 	   = '';
				}
				


?>


				<tr  class='record_row' rel='<?php echo $value['ID'] ?>'>
					<td width='3%' style="background: <?php echo $bg; ?>">
<input type='radio' name='record_radio' id="record_radio<?php echo $value['ID']?>" rel ="<?php echo $value['reference']?>" contractorName="<?php echo $contractorName ?>" approvedFone="<?php echo $approvedF1?>" approvedSecond="<?php echo $approvedF2?>" admin="<?php echo $USER_LEVEL?>" approvedSecond="<?php echo $approvedF2?>" quarter='<?php echo $qc?>' user='<?php echo $participant_id?>' class='choose_radio' value='<?php echo $value['ID']?>'></td>

					<td ><?php echo $value['reference']?></td>
					<td><?php echo $value['contractName']?></td>
					<td><?php echo $businessUnit?></td>
					<td><?php echo $participant_name?></td>
					<td><?php echo ($quote ); ?></td>
					<td align='center'><?php echo format_date($value['endDate']) ?></td>
					<td><?php echo $contractorName ?></td>
					<td><?php echo format_date($value['reviewDueDate']) ?></td>
				</tr>
			<?php }
			}
		}
		?>
	</tbody>
	<tfoot>
		<tr>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
		
		</tr>
	</tfoot>
</table>
