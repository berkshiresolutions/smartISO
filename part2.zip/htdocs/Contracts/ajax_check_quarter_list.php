<?php
 /**
  $Id: ajax_get_files.php,v 3.02 Wednesday, October 27, 2010 9:21:29 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, October 26, 2010 5:14:03 PM>
  */
$_HIDE_HTTP_HEADER = true;


require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';



	$f1f2	=$_GET['f1f2'];
	$id	=$_GET['rec_id'];

$contractInfo["f1f2"]=$f1f2;
$contractObj	= new Contract();
$contractObj->setContractInfo($id,0,$contractInfo);
$options=$contractObj->getAvailableReviews();

/*
foreach ($partarry as $value) {
				$participantObj->setItemInfo(array('id'=>$value));
				$partcipantData = $participantObj->displayItemById();

	if ($partcipantData['participantID'] )
		$options .= "<option value=".$value." >".$partcipantData['forename']." ".$partcipantData['surname']."</option>\n";
	
			
}
*/

if (is_array($options))
echo 1;
else
echo $options;
			

?>