<?php
 /**
  $Id: contractor_risk_assessment.php,v 4.63 Thursday, December 09, 2010 1:11:25 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the risk assessment section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Thursday, October 07, 2010 7:10:44 PM>
  */

$class_risk_assessment = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Risk Assessment"; // for current breadcrums

$cid = (int) $_GET['cid'];

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,5,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {
	//dump_array($_POST);
	$data_array['contractor_id'] 							= $_POST['cid'];
	$data_array['carried_risk_assessments'] 				= $_POST['risk_assessments_min_impact'];
	$data_array['carry_chemical'] 							= $_POST['chemical_risk_assessments'];
	$data_array['carry_manual_handling'] 					= $_POST['manual_handling_risk_assessments'];
	$data_array['carry_noise_exposure'] 					= $_POST['noise_risk_assessments'];
	$data_array['carry_lead_exposure'] 						= $_POST['lead_risk_assessments'];
	$data_array['carry_asbestos'] 							= $_POST['asbestos_risk_assessments'];
	$data_array['carry_display_screen'] 					= $_POST['display_equip_risk_assessments'];
	$data_array['detailed_method_statements'] 				= $_POST['method_statements'];
	$data_array['routine_pre_during'] 						= $_POST['contract_meetings'];

	$reason['min_impact_resaon']							= $_POST['min_impact_upload_reason'];
	$reason['chemical_risk_resaon']							= $_POST['chemical_risk_upload_reason'];
	$reason['manual_handling_reason']						= $_POST['manual_handling_risk_upload_reason'];
	$reason['noise_risk_reason']					   		= $_POST['noise_risk_upload_reason'];
	$reason['lead_risk_reason']					    		= $_POST['yes_lead_risk_upload_reason'];
	$reason['asbestos_reason']					    		= $_POST['asbestos_risk_upload_reason'];
	$reason['display_equip_reason']				    		= $_POST['display_equip_risk_upload_reason'];
	$reason['method_reason']					    		= $_POST['method_statements_upload_reason'];
	$reason['contract_reason']					    		= $_POST['contract_meetings_upload_reason'];

	$section_record_id 	= $_POST['section_record_id'];
	$record_id 			= $data_array['contractor_id'];

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,5,$data_array);
		$contractorObj->editContractor();
	} else {
		//do insert
		$contractorObj->setContractorInfo(0,5,$data_array);
		$contractorObj->addContractor();
		if ( count($reason) ) {
			$contractorObj->deleteContractorReason();
			foreach($reason as $key=>$value) {
				$reason_data_array = array('identifier'=>$key,'reason'=>$value);
				$contractorObj->setContractorInfo($record_id,5,$reason_data_array);
				$contractorObj->addContractorReason();
			}
		}
	}
	redirection("contractor_consultation.php?cid=".$record_id);
}

/* Current contractor record id */
$smarty->assign('cid', $cid);

$contractorObj->setContractorInfo($cid,5,'');
$data_contractor = $contractorObj->viewContractor();
//dump_array($data_contractor);exit;
$contractorObj->setContractorInfo($cid,5,'');

$data_reason	=	$contractorObj->getContractorReason();
//dump_array($data_reason);
if ( count($data_reason) ) {
	foreach($data_reason as $key=>$value) {
		$reason_array[$value['subSection']] = $value['reason'];

	} //dump_array($reason_array);
}

//dump_array($data_contractor);
//echo $action;
if($action == 'edit') {

	$edit_data['section_record_id'] 					= $data_contractor['ID'];
	$edit_data['risk_assessments_min_impact'] 			= $data_contractor['carriedRiskAssessments'];
	$edit_data['chemical_risk_assessments'] 			= $data_contractor['carryChemical'];
	$edit_data['manual_handling_risk_assessments'] 		= $data_contractor['carryManualHandling'];
	$edit_data['noise_risk_assessments'] 				= $data_contractor['carryNoiseExposure'];
	$edit_data['lead_risk_assessments'] 				= $data_contractor['carryLeadExposure'];
	$edit_data['asbestos_risk_assessments'] 			= $data_contractor['carryAsbestos'];
	$edit_data['display_equip_risk_assessments'] 		= $data_contractor['carryDisplayScreen'];
	$edit_data['method_statements'] 					= $data_contractor['detailedMethodStatements'];
	$edit_data['contract_meetings'] 					= $data_contractor['routinePreDuringPost'];
	$edit_reason['min_impact_resaon'] 					= $reason_array['min_impact_resaon'];
	$edit_reason['chemical_risk_resaon'] 				= $reason_array['chemical_risk_resaon'];
	$edit_reason['manual_handling_reason'] 				= $reason_array['manual_handling_reas'];
	$edit_reason['noise_risk_reason'] 					= $reason_array['noise_risk_reason'];
	$edit_reason['lead_risk_reason'] 					= $reason_array['lead_risk_reason'];
	$edit_reason['asbestos_reason'] 					= $reason_array['asbestos_reason'];
	$edit_reason['display_equip_reason'] 				= $reason_array['display_equip_reason'];
	$edit_reason['method_reason'] 						= $reason_array['method_reason'];
	$edit_reason['contract_reason'] 					= $reason_array['contract_reason'];

$smarty->assign('edit_data', $edit_data);
$smarty->assign('edit_reason', $edit_reason);
} else {

	$risk_assessments_min_impact            = "";
	$chemical_risk_assessments              = "";
	$manual_handling_risk_assessments       = "";
	$noise_risk_assessments                 = "";
	$lead_risk_assessments                  = "";
	$asbestos_risk_assessments              = "";
	$display_equip_risk_assessments         = "";
	$method_statements                      = "";
	$contract_meetings                      = "";
}

$smarty->assign('cid', $cid);
$smarty->assign('section_record_id', $section_record_id);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);


$smarty->display($CURRENT_MODULE.'/contractor_risk_assessment.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>