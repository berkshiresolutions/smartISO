<?php
 /**
  $Id: personalRecordCrtPdf.php,v 3.05 Wednesday, January 05, 2011 11:50:32 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Main Report pdf
  * @since  Monday, January 03, 2011 12:20:18 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

require _MYPRIVATEROOT."/includes/vendors/fpdf/class.fpdf_table.php";
require _MYPRIVATEROOT."/includes/vendors/fpdf/table_def.inc";


require _MYCLASSES."report/contractsModReport.class.php";

$data_array['id']		= $_GET['id'];
$data_array['type']		= 'R2';
$data_array['tender']		= $_GET['tender'];
$data_array['bu']		= $_GET['bu'];


//$filters = array('type'=>'main','id'=>$_GET['id']);
$modObj = new contractsModReport($data_array);
$modData = $modObj->getData();
//dump_array($modData);
//exit;

/* company logo */

$eqObj		 = new Upload();
$optionObj	 = new Option();

$eqObj->setFileInfo('company_logo',"");
$file_details = $eqObj->getFileDetailsByModule();

$company_logo = $file_details['sysFilename'];

$pdf=new FPDF_TABLE('L');
$pdf->SetAutoPageBreak(true, 10);
$pdf->SetTopMargin(10);
$pdf->AddPage();

$columns = 6; //four columns

$pdf->SetStyle("p","times","",10,"130,0,30");
$pdf->SetStyle("pb","times","B",11,"130,0,30");
$pdf->SetStyle("t1","arial","",11,"254,252,222");
$pdf->SetStyle("t1","arial","",11,"0,151,200");
$pdf->SetStyle("t2","arial","",11,"0,151,200");
$pdf->SetStyle("t3","times","B",14,"203,0,48");
$pdf->SetStyle("t4","arial","BI",11,"0,151,200");
$pdf->SetStyle("hh","times","B",11,"255,189,12");
$pdf->SetStyle("font","helvetica","",10,"0,0,255");
$pdf->SetStyle("style","helvetica","BI",10,"0,0,220");
$pdf->SetStyle("size","times","BI",13,"0,0,120");
$pdf->SetStyle("color","times","BI",13,"0,255,255");

//we initialize the table class
$pdf->Table_Init($columns, true, true);
$table_default_table_type = array(
					'TB_ALIGN' => 'L',
					'L_MARGIN' => 5,
					'BRD_COLOR' => array(0,92,177),
					'BRD_SIZE' => '0',
					);

// print header once
$date = date("M d, Y");

$pdf->SetFont('Times','',10);
$pdf->SetTitle(strtoupper($std_type)." generated on $date");
$pdf->Cell(5,5,strtoupper($std_type)."     Generated on $date",0,1);
$pdf->Cell(5,5,strtoupper($std_type)."     Smart-ISO - Contracts R2".$modData["tender"],0,1);

$table_subtype = $table_default_table_type;
$pdf->Set_Table_Type($table_subtype);
define('_REPORT_HEADING','Contracts Report');
//TABLE HEADER SETTINGS

$header_subtype = $table_default_header_type;
for($i=0; $i<$columns; $i++) $header_type[$i] = $table_default_header_type;

$header_type[0]['WIDTH'] = 45;
$header_type[1]['WIDTH'] = 50;
$header_type[2]['WIDTH'] = 50;
$header_type[3]['WIDTH'] = 45;
$header_type[4]['WIDTH'] = 40;
$header_type[5]['WIDTH'] = 40;


$header_type[0]['TEXT'] = _REPORT_HEADING;
$header_type[0]['T_SIZE'] = "11";
$header_type[0]['BG_COLOR'] = array(104,67,152);
$header_type[0]['T_COLOR'] = array(255,186,6);
$header_type[0]['T_ALIGN'] = 'C';

$header_type[0]['COLSPAN'] = "6";

//set the header type

/* colorurs */
$light_purple = array(175,153,216);
$dark_purple = array(126,103,168);
$grey = array(204,204,204);
/**/


$pdf->Set_Header_Type($header_type);

$pdf->Draw_Header();

//TABLE DATA SETTINGS
	$data_subtype = $table_default_data_type;

	$data_type = Array();//reset the array
	for ($i=0; $i<$columns; $i++) $data_type[$i] = $data_subtype;

	$pdf->Set_Data_Type($data_type);

	$hfsize = 9;
	$colspan = 1;

	$headfsize = 11;


	$index_y = 0;
	$index_x = 0;
	$data = Array();


				$data[$index_y][$index_x]['TEXT'] = 'Reference';
				$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

				$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
				$data[$index_y][$index_x]['BG_COLOR'] = $light_purple;
				$data[$index_y][$index_x]['T_ALIGN'] = 'L';
				$data[$index_y][$index_x]['V_ALIGN'] = 'T';

				$index_x++;
				$data[$index_y][$index_x]['TEXT'] = 'Contract Name';
				$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

				$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
				$data[$index_y][$index_x]['BG_COLOR'] = $light_purple;
				$data[$index_y][$index_x]['T_ALIGN'] = 'L';
				$data[$index_y][$index_x]['V_ALIGN'] = 'T';

				$index_x++;
				$data[$index_y][$index_x]['TEXT'] = 'Details';
				$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

				$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
				$data[$index_y][$index_x]['BG_COLOR'] = $light_purple;
				$data[$index_y][$index_x]['T_ALIGN'] = 'L';
				$data[$index_y][$index_x]['V_ALIGN'] = 'T';
				
			
				$index_x++;
				$data[$index_y][$index_x]['TEXT'] = 'Contract Manager';
				$data[$index_y][$index_x]['T_SIZE'] = $headfsize;
				$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
				$data[$index_y][$index_x]['BG_COLOR'] = $light_purple;
				$data[$index_y][$index_x]['T_ALIGN'] = 'L';
				$data[$index_y][$index_x]['V_ALIGN'] = 'T';

				$index_x++;
				$data[$index_y][$index_x]['TEXT'] = 'Company name';
				$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

				$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
				$data[$index_y][$index_x]['BG_COLOR'] = $light_purple;
				$data[$index_y][$index_x]['T_ALIGN'] = 'L';
				$data[$index_y][$index_x]['V_ALIGN'] = 'T';
				
			
				$index_x++;
				$data[$index_y][$index_x]['TEXT'] = 'Review Due Date';
				$data[$index_y][$index_x]['T_SIZE'] = $headfsize;
				$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
				$data[$index_y][$index_x]['BG_COLOR'] = $light_purple;
				$data[$index_y][$index_x]['T_ALIGN'] = 'L';
				$data[$index_y][$index_x]['V_ALIGN'] = 'T';

$index_y++;
$i=0;
	if (is_array($modData) ) {
            
		foreach( $modData as $value) {
if(!isset($value["reference"]))
    continue;
			$index_x=0;			
								$data[$index_y][$index_x]['TEXT'] = $value['reference'];
								$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

								$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
								$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
								$data[$index_y][$index_x]['T_ALIGN'] = 'L';
								$data[$index_y][$index_x]['V_ALIGN'] = 'T';
								$index_x++;
								$data[$index_y][$index_x]['TEXT'] = $value['contractName'];
								$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
								$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
								$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
								$data[$index_y][$index_x]['T_ALIGN'] = 'L';
								$data[$index_y][$index_x]['V_ALIGN'] = 'T';
								$index_x++;
								$data[$index_y][$index_x]['TEXT'] = $value['detail'];
								$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
								$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
								$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
								$data[$index_y][$index_x]['T_ALIGN'] = 'L';
								$data[$index_y][$index_x]['V_ALIGN'] = 'T';
								$index_x++;
								$data[$index_y][$index_x]['TEXT'] = $value['whoID'];
								$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
								$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
								$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
								$data[$index_y][$index_x]['T_ALIGN'] = 'L';
								$data[$index_y][$index_x]['V_ALIGN'] = 'T';
								$index_x++;
								$data[$index_y][$index_x]['TEXT'] = $value['companyName'];
								$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
								$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
								$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
								$data[$index_y][$index_x]['T_ALIGN'] = 'L';
								$data[$index_y][$index_x]['V_ALIGN'] = 'T';
								$index_x++;
								$data[$index_y][$index_x]['TEXT'] = $value['reviewDueDate'];
								$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
								$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
								$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
								$data[$index_y][$index_x]['T_ALIGN'] = 'L';
								$data[$index_y][$index_x]['V_ALIGN'] = 'T';
								$index_x++;
								$index_y++;
$i++;
															}
						}


				

	$data_count = count($data);

	for ($k=0;$k<$data_count;$k++) {
		$pdf->Draw_Data($data[$k]);
	}

$pdf->Ln(2);
$pdf->Output('','I');

?>
