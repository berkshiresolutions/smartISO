<?php
 /**
  $Id: reportR3.php,v 3.06 Wednesday, January 05, 2011 3:10:42 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage DSE
  * @since  Thursday, November 25, 2010 3:26:06 PM>
  */

$LAST_BREAD_CRUM = "Report R3";

$_PAGE_VALIDATION_SCRIPT = 'contract/report.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$record_id	= (int) $_GET['id'];


$repObj = new Report('html');
$repObj->setFilters(array('id'=>$record_id,'type'=>'R3','heading'=>true));
$repObj->generateReport('CONTRACTR3');

$repObj->displayReport();

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
