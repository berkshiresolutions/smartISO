<?php
 /**
  $Id: ajax_participants.php,v 3.22 Saturday, January 29, 2011 12:08:03 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$str = strip_tags($_GET['str']);
$eqObj = SetupGeneric::useModule('Participant');

$eqObj->setItemInfo(array(
						    'id' => 1,
							'forename' => $str,
							));

$data = $eqObj->displayItemByForename();

$records = array();

if (count($data) ) {
	$i=0;
	foreach ($data as $value) {
		$participant_id = $value['participantID'];
		$shift_work = (int) $value['shiftWork'];
		$records[$i]['id'] = $participant_id.'#!#'.$shift_work.'#!#'.$value['gender'].'#!#'.$value['forename'].'#!#'.$value['surname'].'#!#'.$value['worksNumber'].'#!#'.$value['emailAddress'];
		$records[$i]['name'] = $value['forename'].' '.$value['surname'].' - '.$value['worksNumber'];
		$records[$i]['worksno'] = $value['worksNumber'];
		$i++;
	}
}

$resultset = array('records' => $records);

echo json_encode($resultset);
?>