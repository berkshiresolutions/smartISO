<?php
 /**
  $Id: contractor_insurance.php,v 3.19 Wednesday, December 29, 2010 1:25:54 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the insurance section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Friday, October 08, 2010 6:25:12 PM>
  */

$class_insurance = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Insurance"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,9,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {
	//dump_array($_POST);
	$data_array['contractor_id'] 						= $_POST['cid'];
	$data_array['employers_insurer_name'] 				= $_POST['employers_insurer_name'];
	$data_array['employers_certificate_no'] 			= $_POST['employers_certificate_no'];
	$data_array['employers_sum_assured'] 				= $_POST['employers_sum_assured'];
	$data_array['employers_expiry_date'] 				= $_POST['employers_expiry_date'];
	$data_array['public_insurer_name'] 					= $_POST['public_insurer_name'];
	$data_array['public_certificate_no'] 				= $_POST['public_certificate_no'];
	$data_array['public_sum_assured'] 					= $_POST['public_sum_assured'];
	$data_array['public_expiry_date'] 					= $_POST['public_expiry_date'];
	$data_array['activities_expose_employees'] 			= $_POST['radio_health_surveillance'];
	$data_array['provide_first_aiders'] 				= $_POST['radio_first_aid'];
	$data_array['fire_risk_assessments'] 				= $_POST['radio_fire_precautions'];


	$section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,9,$data_array);
		$contractorObj->editContractor();
	} else {
		//do insert
		$contractorObj->setContractorInfo(0,9,$data_array);
		$contractorObj->addContractor();
	}

	redirection("contractor_documents.php?cid=".$record_id);

}

/* Current contractor record id */
$smarty->assign('cid', $cid);

$data = $contractorObj->viewContractor();
//dump_array($data);exit;
if($action == 'edit') {

	$employer_expiry_date	= $data['employersLiabilityExpiryDate'] == '--' ? '' : format_date($data['employersLiabilityExpiryDate']);
	/*echo $employer_expiry_date;
	echo 'exit';exit;*/
	$public_expiry_date		= $data['publicLiabilityExpiryDate'] == '--' ? '' : format_date($data['publicLiabilityExpiryDate']);

	$edit_data['section_record_id'] 							= $data['ID'];
	$edit_data['employers_insurer_name'] 						= smartisoStripslashes($data['employersLiabilityInsurerName']);
	$edit_data['employers_certificate_no'] 						= smartisoStripslashes($data['employersLiabilityCertificateNo']);
	$edit_data['employers_sum_assured'] 						= smartisoStripslashes($data['employersLiabilitySumAssured']);
	$edit_data['employers_expiry_date'] 						= $employer_expiry_date;
	$edit_data['public_insurer_name'] 							= smartisoStripslashes($data['publicLiabilityInsurerName']);
	$edit_data['public_certificate_no'] 						= smartisoStripslashes($data['publicLiabilityCertificateNo']);
	$edit_data['public_sum_assured'] 							= smartisoStripslashes($data['publicLiabilitySumAssured']);
	$edit_data['public_expiry_date'] 							= $public_expiry_date;
	$edit_data['radio_health_surveillance'] 					= $data['activitiesExposeEmployees'];
	$edit_data['radio_first_aid'] 								= $data['provideFirstAiders'];
	$edit_data['radio_fire_precautions'] 						= $data['fireRiskAssessments'];

	//dump_array($edit_data);

} else {

	$edit_data['section_record_id']        		= "";
	$edit_data['employers_insurer_name']       	= "";
	$edit_data['employers_certificate_no']      = "";
	$edit_data['employers_sum_assured']         = "";

	$edit_data['employers_expiry_date']         = "";
	$edit_data['public_insurer_name']        	= "";
	$edit_data['public_certificate_no']         = "";
	$edit_data['public_sum_assured']            = "";

	$edit_data['public_expiry_date']            = "";
	$edit_data['radio_health_surveillance']     = "";
	$edit_data['radio_first_aid']               = "";
	$edit_data['radio_fire_precautions'] 		= "";

}
//dump_array($edit_data);
$smarty->assign('cid', $cid);
$smarty->assign('edit_data', $edit_data);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

$smarty->display($CURRENT_MODULE.'/contractor_insurance.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>