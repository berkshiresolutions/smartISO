<?php
 /**
  $Id: r1ReportPdf.php,v 3.03 Tuesday, January 04, 2011 9:45:49 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Main Report pdf
  * @since  Monday, January 03, 2011 12:20:18 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

require _MYPRIVATEROOT."/includes/vendors/fpdf/class.fpdf_table.php";
require _MYPRIVATEROOT."/includes/vendors/fpdf/table_def.inc";


require _MYCLASSES."report/contractsModReport.class.php";

$data_array['id']		= $_GET['id'];
$data_array['type']		= 'R1';

//$filters = array('type'=>'main','id'=>$_GET['id']);
$modObj = new contractsModReport($data_array);
$modData = $modObj->getData();
//dump_array($modData);
//exit;



/* company logo */

$eqObj		 = new Upload();
$optionObj	 = new Option();


$eqObj->setFileInfo('company_logo',"");
$file_details = $eqObj->getFileDetailsByModule();

$company_logo = $file_details['sysFilename'];

$pdf=new FPDF_TABLE('L');
$pdf->SetAutoPageBreak(true, 10);
$pdf->SetTopMargin(10);
$pdf->AddPage();

$columns = 4; //four columns

$pdf->SetStyle("p","times","",10,"130,0,30");
$pdf->SetStyle("pb","times","B",11,"130,0,30");
$pdf->SetStyle("t1","arial","",11,"254,252,222");
$pdf->SetStyle("t1","arial","",11,"0,151,200");
$pdf->SetStyle("t2","arial","",11,"0,151,200");
$pdf->SetStyle("t3","times","B",14,"203,0,48");
$pdf->SetStyle("t4","arial","BI",11,"0,151,200");
$pdf->SetStyle("hh","times","B",11,"255,189,12");
$pdf->SetStyle("font","helvetica","",10,"0,0,255");
$pdf->SetStyle("style","helvetica","BI",10,"0,0,220");
$pdf->SetStyle("size","times","BI",13,"0,0,120");
$pdf->SetStyle("color","times","BI",13,"0,255,255");

//we initialize the table class
$pdf->Table_Init($columns, true, true);
$table_default_table_type = array(
					'TB_ALIGN' => 'L',
					'L_MARGIN' => 5,
					'BRD_COLOR' => array(0,92,177),
					'BRD_SIZE' => '0',
					);

// print header once
$date = date("M d, Y");

$pdf->SetFont('Times','',10);
$pdf->SetTitle(strtoupper($std_type)." generated on $date");
$pdf->Cell(5,5,strtoupper($std_type)."     Generated on $date",0,1);
$pdf->Cell(5,5,strtoupper($std_type)."     Smart-ISO - Contractor Report",0,1);

$table_subtype = $table_default_table_type;
$pdf->Set_Table_Type($table_subtype);
define('_REPORT_HEADING','Report');
//TABLE HEADER SETTINGS

$header_subtype = $table_default_header_type;
for($i=0; $i<$columns; $i++) $header_type[$i] = $table_default_header_type;

$header_type[0]['WIDTH'] = 65;
$header_type[1]['WIDTH'] = 65;
$header_type[2]['WIDTH'] = 45;
$header_type[3]['WIDTH'] = 85;

$header_type[0]['TEXT'] = _REPORT_HEADING;
$header_type[0]['T_SIZE'] = "11";
$header_type[0]['BG_COLOR'] = array(104,67,152);
$header_type[0]['T_COLOR'] = array(255,186,6);
$header_type[0]['T_ALIGN'] = 'C';

$header_type[0]['COLSPAN'] = "4";

//set the header type

/* colorurs */
$light_purple = array(175,153,216);
$dark_purple = array(126,103,168);
$grey = array(204,204,204);
$white = array(255,255,255);
$amber = array(255,128,0);
/**/


$pdf->Set_Header_Type($header_type);

$pdf->Draw_Header();

//TABLE DATA SETTINGS
	$data_subtype = $table_default_data_type;

	$data_type = Array();//reset the array
	for ($i=0; $i<$columns; $i++) $data_type[$i] = $data_subtype;

	$pdf->Set_Data_Type($data_type);

	$hfsize = 9;
	$colspan = 1;

	$headfsize = 11;


	$index_y = 0;
	$index_x = 0;
	$data = Array();


$data[$index_y][$index_x]['TEXT'] = "Contract Details";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Reference #";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['reference'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Goods/Service Contract Provision";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['contractName'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x++;
	$index_y++;

	$index_x = 0;
	$data[$index_y][$index_x]['TEXT'] = "Location";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['location'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Business";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['business'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x = 0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "Type";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['type'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Contract Manager";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['cm'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	
	$index_x = 0;
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "Manager Approver";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['ma'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Director Approver";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['da'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	
	$index_x = 0;
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Contract Start Date";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['startDate'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Contract End Date";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['endDate'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	
	$index_x = 0;
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Review Date";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['reviewDueDate'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Total Value";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['totalValue'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	
	$index_x = 0;
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Details";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['detail'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Remarks";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['remarks'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x++;
	$index_y++;

	$index_x = 0;


	//Process Details

	$data[$index_y][$index_x]['TEXT'] = "Supplier Details";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Reference #";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['reference'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Company Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['companyName'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x++;
	$index_y++;


	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Contact Person";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['contactPerson'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Address";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['address'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';



	$index_x = 0;
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Email";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['emailAddress'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Location";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['location'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x = 0;
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "Date";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['date'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Business Unit";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['business'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x = 0;
	$index_y++;
	

	$data[$index_y][$index_x]['TEXT'] = "Telephone";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['telephoneNumber'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x++;
	

	$data[$index_y][$index_x]['TEXT'] = "Fax";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["cdetails"]['fax'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	
	$index_x = 0;
	$index_y++;
	
   // if ($modData["cdetails"]['approve_by_tender'] != 1){ 

//stops output for Joe/John
if ($modData["cdetails"]['approve_by_tender'] == 11){ 



	$data[$index_y][$index_x]['TEXT'] = "Management of Health & Safety, Environment And Quality (HSE&Q)";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "1.1 Who is resposible for HSE&Q in your company?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Health & Safety)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["responsibleHealthSafetyName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["responsibleHealthSafetyName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Health & Safety)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["responsibleHealthSafetyPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["responsibleHealthSafetyPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Environment-Protection)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["responsibleEnvironmentProtectionName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["responsibleEnvironmentProtectionName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Environment-Protection)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["responsibleEnvironmentProtectionPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["responsibleEnvironmentProtectionPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Quality)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["responsibleQualityName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["responsibleQualityName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Quality)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["responsibleQualityPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["responsibleQualityPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	



	$data[$index_y][$index_x]['TEXT'] = "1.2 Who provides competent advice and guidance on HSE&Q in your company?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Name(Health & Safety)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["competentHealthSafetyName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["competentHealthSafetyName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Health & Safety)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["competentHealthSafetyPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["competentHealthSafetyPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Environment-Protection)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["competentEnvironmentProtectionName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["competentEnvironmentProtectionName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Environment-Protection)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["competentEnvironmentProtectionPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["competentEnvironmentProtectionPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Quality)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["competentQualityName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["competentQualityName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Quality)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["competentQualityPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["competentQualityPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "1.3 How many employees are there in your company?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	
	$data[$index_y][$index_x]['TEXT'] = "Full Time";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["employeesFullTime"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["employeesFullTime"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Part Time";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["employeesPartTime"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["employeesPartTime"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;


	$data[$index_y][$index_x]['TEXT'] = "1.4 Will you be engaging any self-employed person(s) on this contract?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["engagingSelfEmployedPersons"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["engagingSelfEmployedPersons"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "If yes, how many?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["engagingSelfEmployedPersonsCount"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["engagingSelfEmployedPersonsCount"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "1.5 if known, complete details below:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Trade";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_3"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_3"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_4"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_4"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_5"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_5"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_5"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_5"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_6"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_6"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_6"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_6"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_7"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_7"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_7"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_7"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsName_8"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsName_8"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["managescore"]["completeDetailsTrade_8"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["manage"]["completeDetailsTrade_8"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;


		$data[$index_y][$index_x]['TEXT'] = "1.6 If Yes to 1.4 State how you intend to:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;


$data[$index_y][$index_x]['TEXT'] = "Assess their HSE&Q competency";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["assessCompetency_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["assessCompetency_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Communuicate HSE&Q issues";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["communicateIssues_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["communicateIssues_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["assessCompetency_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["assessCompetency_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["communicateIssues_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["communicateIssues_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["assessCompetency_3"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["assessCompetency_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["communicateIssues_3"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["communicateIssues_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;





	
	$data[$index_y][$index_x]['TEXT'] = "1.7 Where you use Sub-Contracting companies, do you assess their compliance and management of:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

$data[$index_y][$index_x]['TEXT'] = "Health & Safety";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["assessHealthSafety"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["assessHealthSafety"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Environment-Protection";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["assessEnvironmentProtection"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["assessEnvironmentProtection"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;	
	$data[$index_y][$index_x]['TEXT'] = "1.8 If Yes to 1.7 State how do you undertake the assessment:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["undertakeAssessment_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["undertakeAssessment_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["undertakeAssessment_4"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["undertakeAssessment_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["undertakeAssessment_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["undertakeAssessment_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["undertakeAssessment_5"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["undertakeAssessment_5"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["undertakeAssessment_3"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["undertakeAssessment_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["undertakeAssessment_6"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["undertakeAssessment_6"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
	
	$data[$index_y][$index_x]['TEXT'] = "1.9 Who will be the person(s) responsible for HSE&Q on this contract?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
		$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "Name(Health & Safety)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["responsibleHealthSafetyName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["responsibleHealthSafetyName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Health & Safety)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["responsibleHealthSafetyPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["responsibleHealthSafetyPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Environment-Protection)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["responsibleEnvironmentProtectionName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["responsibleEnvironmentProtectionName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Environment-Protection)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["responsibleEnvironmentProtectionPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["responsibleEnvironmentProtectionPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Name(Quality)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["responsibleQualityName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["responsibleQualityName"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Position(Quality)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["competencyscore"]["responsibleQualityPosition"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["competency"]["responsibleQualityPosition"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	
	
	$index_y++;
	$index_x = 0;
	
	
	$data[$index_y][$index_x]['TEXT'] = "1.10 Are  you a member of a Trade Association or Health & Safety organisation?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "If yes, give details below";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociation"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociation"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x = 0;
	$index_y++;


		$data[$index_y][$index_x]['TEXT'] = "Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociationName_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociationName_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociationName_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociationName_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Address";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociationAddress_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociationAddress_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Address";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociationAddress_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociationAddress_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Membership Ref";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociationMemberRef_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociationMemberRef_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "Mmebership Ref";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["tradeAssociationMemberRef_2"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["tradeAssociationMemberRef_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	
	
	$index_y++;
	$index_x = 0;


	$data[$index_y][$index_x]['TEXT'] = "1.11 Does your company hold any of the following ISO/OHSAS Certification?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";

	
		$index_x = 0;
	$index_y++;


		$data[$index_y][$index_x]['TEXT'] = "9001: 2000";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["iso9001"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["iso9001"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["iso9001Reason"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["iso9001Reason"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "14001";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["iso14001"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["iso14001"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["iso14001Reason"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["iso14001Reason"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "18001";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["iso18001"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["iso18001"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["iso18001Reason"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["iso18001Reason"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_y++;
	$index_x = 0;	
	
	
	
	
	$data[$index_y][$index_x]['TEXT'] = "Continous Improvment";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "2.1 Should there be a way to improve the project-design change, materials used, methods of work etc? Do you have a system for bringing such matters to our attention?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "If yes, please attach example(s) to this questionnaire";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["continuousImprovement"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_y++;
	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["continuousImprovement"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_y++;
	$index_x = 0;
	
	$data[$index_y][$index_x]['TEXT'] = "Policies, Procedures and Assessments";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "3.1 Do you have the following policies?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "If so, please attach a copy of the latest issue(s) to this questionnaire";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	
		$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Health & Safety";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["healthSafetyPolicy"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["healthSafetyPolicy"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Environmental Policy";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["environmentalPolicy"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["environmentalPolicy"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "Quality Policy";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["qualityPolicy"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["qualityPolicy"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;
	
	
	
	$data[$index_y][$index_x]['TEXT'] = "3.2 Do you have written HSE&Q procedures, work instructions or rules?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "If so, please examples relating to the type of work you are bidding for";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["policyscore"]["workInstructions"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_x++;

	
	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
		$index_x++;
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["policy"]["workInstructions"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_y++;
	$index_x = 0;



	$data[$index_y][$index_x]['TEXT'] = "3.3 Have you carried out risk assessments to minimise the impact on personnel, equipment and the environment in developing procedures and work instructions?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";

	
	$index_y++;
	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "e.g. vibration, manual handling, working at heights, control of substances hazardous to health, lifting operations etc.) If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carriedRiskAssessments"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carriedRiskAssessments"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
		
	$data[$index_y][$index_x]['TEXT'] = "3.4 Do you carry out chemical risk assessments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carryChemical"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carryChemical"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "3.5 Do you carry out manual handling risk assessments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";

	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carryManualHandling"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carryManualHandling"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "3.6 Do you carry out Noise exposure risk assessments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carryNoiseExposure"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carryNoiseExposure"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
		
	$data[$index_y][$index_x]['TEXT'] = "3.7 Do you carry out lead exposure risk assessments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";


	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carryLeadExposure"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carryLeadExposure"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "3.8 Do you carry out asbestos risk assessments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";

	
		$index_y++;
	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carryAsbestos"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carryAsbestos"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
	
	$data[$index_y][$index_x]['TEXT'] = "3.9 Do you carry out Display Screen Equipment risk assessments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["carryDisplayScreen"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["carryDisplayScreen"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
		
	$data[$index_y][$index_x]['TEXT'] = "3.10 Do you prepare detailed method statements for all significant work undertaken?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["detailedMethodStatements"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["detailedMethodStatements"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "3.11 Do you undertake routine pre-during-post contract meetings?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";


	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples relating to the type of work you are bidding for.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["riskscore"]["routinePreDuringPost"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["risk"]["routinePreDuringPost"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
		$data[$index_y][$index_x]['TEXT'] = "Consultation with Employees";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

		$data[$index_y][$index_x]['TEXT'] = "Do you formally consult with your employees on:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	$data[$index_y][$index_x]['TEXT'] = "(Please attach examples of safety committee minutes, notes of meetings or other evidence of how you have consulted with your employees.)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	
	$data[$index_y][$index_x]['TEXT'] = "4.1 Health and Safety issues";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["consultHealthSafety"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
		$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["consultHealthSafety"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x = 0;
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "4.2 Environmental issues";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["consultEnvironmental"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
		$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["consultEnvironmental"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x = 0;
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "4.3 Quality issues";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["consultQuality"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
		$index_x+=3;

	
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["consultQuality"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x = 0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "4.4 If you do not have formal arrangements, please explain in the box below what consultation you do and how you do it?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["formalArrangements_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["formalArrangements_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["formalArrangements_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["formalArrangements_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Training";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "5.1  What specific HSE&Q training has the person(s) named in 1.2 received to date?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["trainingPerson_1_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
		$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_1_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_1_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_1_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_1_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;


	$data[$index_y][$index_x]['TEXT'] = "5.2  What specific HSE&Q qualifications has the person(s) named in 1.2?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["qualificationsPerson_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["qualificationsPerson_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["qualificationsPerson_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["qualificationsPerson_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["qualificationsPerson_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "5.3 What specific HSE&Q training has the person(s) named in 1.7 received to date?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["trainingPerson_2_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_y++;
	
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_2_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_2_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_2_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
			$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["trainingPerson_2_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	
	$data[$index_y][$index_x]['TEXT'] = "5.4 Have you issued current Health and Safety Handbooks or written instructions to your Employees?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["handbooks"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;	
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["handbooks"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);

	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "Please give details below & attach copies.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["consultscore"]["handbooksComment_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["handbooksComment_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["handbooksComment_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["handbooksComment_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["consult"]["handbooksComment_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
	
		$data[$index_y][$index_x]['TEXT'] = "5.5 Describe the Health and Safety training given to Managers/Supervisors and Operatives in th e last 3 years?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
		
	$data[$index_y][$index_x]['TEXT'] = "Managers/Supervisors";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["trainscore"]["managersSupervisors_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;	
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["managersSupervisors_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["train"]["managersSupervisors_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["managersSupervisors_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["managersSupervisors_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
	
		$data[$index_y][$index_x]['TEXT'] = "Operatives";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["trainscore"]["operatives_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;	
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["operatives_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["train"]["operatives_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["operatives_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["operatives_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
	
	
	
		$data[$index_y][$index_x]['TEXT'] = "Competency";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	$data[$index_y][$index_x]['TEXT'] = "6.1 In what types of work do you regard yourself and your employees competent - relating specifically to this contract?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["trainscore"]["competentRelating_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;	
	
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["competentRelatings_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["train"]["competentRelating_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["competentRelating_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["competentRelating_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
	


		$data[$index_y][$index_x]['TEXT'] = "Monitoring, Audit and Policy Review";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "7.1 Please describe how your Company undertakes formal reviews of Health & safety, Environmental and Quality Performance?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["trainscore"]["formalReviews_1"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;	
	
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["formalReviews_1"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = $modData["train"]["formalReviews_2"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["formalReviews_3"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
		$data[$index_y][$index_x]['TEXT'] = $modData["train"]["formalReviews_4"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
		$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "Maintenance of Work Equipment";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	
	$data[$index_y][$index_x]['TEXT'] = "8.1 Do you have a system of routine inspection, testing and maintence for the following equipments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Attach example(s) where possible especially of test & calibration records.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "Electrical";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["electrical"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["electrical"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "Pneumatic";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["pneumatic"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["pneumatic"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
		$data[$index_y][$index_x]['TEXT'] = "Hydraulic";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["hydraulic"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["hydraulic"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
	
			$data[$index_y][$index_x]['TEXT'] = "Access equipments(e.g. ladders, towers, scaffolds)";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["accessEquipments"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["accessEquipments"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
		
					$data[$index_y][$index_x]['TEXT'] = "Gas Monitors";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["gasMonitors"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["gasMonitors"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
	
						$data[$index_y][$index_x]['TEXT'] = "Special Test Equipments";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["specialTestEquipments"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["specialTestEquipments"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
			
	$data[$index_y][$index_x]['TEXT'] = "8.2  Do you undertake portable appliance testing on all portable electrical equipments?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "If so, please attach evidence.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";

		$index_y++;
						$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["electricEquipments"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["electricEquipments"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
		


	$data[$index_y][$index_x]['TEXT'] = "8.3 Is there specific guidance on work equipment for employees that covers their use as well as inspection, testing & mainentance, including vibration e,g, trigger time?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	
		$data[$index_y][$index_x]['TEXT'] = "If so, please attach examples especially on PPE issue and maintenance.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";

		$index_y++;
						$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["workEquipment"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["workEquipment"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
		
		$data[$index_y][$index_x]['TEXT'] = "Accident";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	
	$data[$index_y][$index_x]['TEXT'] = "9.1  In the past 3 years, how many accidents have substained during your work activities?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "To you and/or your employees?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "To other persons?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	
	$index_y++;
$index_x=0;
		$data[$index_y][$index_x]['TEXT'] = "No. of accidents";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["employeesNoAccident"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["employeesNoAccident"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "No. of accidents";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["personsNoAccident"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["personsNoAccident"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

$index_x=0;
		$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "Fatality";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["employeesFatality"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["employeesFatality"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Fatality";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["personsFatality"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["personsFatality"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

$index_x=0;
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "Major";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["employeesMajor"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["employeesMajor"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Major";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["personsMajor"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["personsMajor"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

$index_x=0;
		$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "Over 3 days lost time";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["employeesLostTime"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["employeesLostTime"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Over 3 days lost time";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["maintscore"]["personsLostTime"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["personsLostTime"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

$index_x=0;
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "9.2  Do you know the Statutory requirements regarding the reporting of accidents and/or dangerous occurrences(RIDDOR)?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["maintscore"]["reportingAccidents"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["maintscore"]["reportingAccidents"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["reportingAccidents"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);


	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
$index_x=0;
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "Legal Action";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	
	$data[$index_y][$index_x]['TEXT'] = "10.1 Have you or your company ever been prosecuted in connection with Health & Safety or Environment?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "If yes, please attach details including remedial measures taken.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["maintscore"]["prosecutedConnection"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["prosecutedConnection"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);


	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
$index_x=0;
	$index_y++;


	$data[$index_y][$index_x]['TEXT'] = "10.2  Have you or your company ever been served a prohibition notice by an enforcing authority?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "If yes, please attach details including remedial measures taken.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["maintscore"]["prohibitionNotice"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["prohibitionNotice"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);


	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
$index_x=0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "10.3 Have you or your company ever been served an improvement notice by an enforcing authority?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "If yes, please attach details including remedial measures taken.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["maintscore"]["improvementNotice"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;

	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["maint"]["improvementNotice"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);


	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
$index_x=0;
	$index_y++;
		
			$data[$index_y][$index_x]['TEXT'] = "Insurance";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

$index_x = 0;
	$data[$index_y][$index_x]['TEXT'] = "(You are required to provide copies of insurance certificates which will be validated with the insurer.) ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
		
	$data[$index_y][$index_x]['TEXT'] = "11.1 Provide your Employers Liability Insurance Details:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "2";

$index_x +=2;
	
	$data[$index_y][$index_x]['TEXT'] = "Provide your Public Liability Insurance Details:";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "2";
	$index_y++;
	$index_x = 0;
	$data[$index_y][$index_x]['TEXT'] = "Insurer Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["insurescore"]["employersLiabilityInsurerName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['employersLiabilityInsurerName'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Insurer Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	if ($modData["insurescore"]["publicLiabilityInsurerName"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['publicLiabilityInsurerName'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';



	$index_x = 0;
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "Certificate No.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['employersLiabilityCertificateNo'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Certificate No.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['publicLiabilityCertificateNo'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x = 0;
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "Sum Assured";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['employersLiabilitySumAssured'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Sum Assured";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['publicLiabilitySumAssured'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x = 0;
	$index_y++;
	
			$data[$index_y][$index_x]['TEXT'] = "Expiry Date";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['employersLiabilityExpiryDate'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "Expiry Date";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["insure"]['publicLiabilityExpiryDate'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_y++;
	$index_x = 0;
	
	
$data[$index_y][$index_x]['TEXT'] = "Health Surveillance";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "12.1 Where your bisiness activies expose employees to hazards such as lead,asbestos,noise,vibration,chemical, dust etc. Do you have a health surveillance programme?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

		$data[$index_y][$index_x]['TEXT'] = "If yes, please attach evidence.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";

		$index_y++;
						$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["insurescore"]["activitiesExposeEmployees"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["insure"]["activitiesExposeEmployees"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
			
			$data[$index_y][$index_x]['TEXT'] = "First Aid";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "13.1 Do you provide (HSE Approved) First Aiders,facilities and equipment on site and review the arrangements regularly to ensure their adequacy)?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
						$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["insurescore"]["provideFirstAiders"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["insure"]["provideFirstAiders"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
			
			$data[$index_y][$index_x]['TEXT'] = "First Aid";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	
			$data[$index_y][$index_x]['TEXT'] = "Fire Precaution";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;

	$data[$index_y][$index_x]['TEXT'] = "14.1 Do you complete, record and where applicable, review fire risk assessments for the workplace,including evacuation procedures?";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
		
			$data[$index_y][$index_x]['TEXT'] = "If yes, please attach samples of such documents.";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";

		$index_y++;
						$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["insurescore"]["fireRiskAssessments"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["insure"]["fireRiskAssessments"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
				$data[$index_y][$index_x]['TEXT'] = "Documents";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;	
	
	
				$data[$index_y][$index_x]['TEXT'] = "15.1 Company Details";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;	
	
	$data[$index_y][$index_x]['TEXT'] = "Company Name";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['companyName'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_y++;

	$index_x = 0;


	$data[$index_y][$index_x]['TEXT'] = "Address";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['address'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';



	$index_x = 0;
	$index_y++;
	$data[$index_y][$index_x]['TEXT'] = "Telephone";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['telephoneNumber'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x = 0;
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "Email";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['emailAddress'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;



	$data[$index_y][$index_x]['TEXT'] = "Fax";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["details"]['fax'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	
	$index_x = 0;
	$index_y++;
	
	
					$data[$index_y][$index_x]['TEXT'] = "15.2 I enclose the following documents and sample documents : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
	
	$data[$index_y][$index_x]['TEXT'] = "Sub-Contractors Questionnaire Form Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["subContractorsQuestionnaire"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["subContractorsQuestionnaire"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
		
		$data[$index_y][$index_x]['TEXT'] = "Evidence of Continuous Improvement Systems Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["continuousImprovement"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["continuousImprovement"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
			$data[$index_y][$index_x]['TEXT'] = "Health & Safety Policy Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["healthSafetyPolicy"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["healthSafetyPolicy"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
				$data[$index_y][$index_x]['TEXT'] = "Environmental Policy Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["environmentalPolicy"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["environmentalPolicy"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
					$data[$index_y][$index_x]['TEXT'] = "Quality Policy Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["qualityPolicy"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["qualityPolicy"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
						$data[$index_y][$index_x]['TEXT'] = "Health & Safety Procedures, Work Instructions and Site Rules Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["healthSafetyProcedures"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["healthSafetyProcedures"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
							$data[$index_y][$index_x]['TEXT'] = "Environmental Procedures, Work Instructions and Site Rules Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["environmentalProcedures"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["environmentalProcedures"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
	
								$data[$index_y][$index_x]['TEXT'] = "Quality Procedures, Work Instructions and Site Rules Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["qualityProcedures"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["qualityProcedures"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
		
										$data[$index_y][$index_x]['TEXT'] = "Examples of Relevant Risk Assessments Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["examplesRelevantRisk"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["examplesRelevantRisk"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;
		
												$data[$index_y][$index_x]['TEXT'] = "Examples of Relevant Method Statements Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["examplesRelevantMethod"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["examplesRelevantMethod"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
		
													$data[$index_y][$index_x]['TEXT'] = "Example Documentation Regarding Consultation with Employees Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["exampleDocumentation"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["exampleDocumentation"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
														$data[$index_y][$index_x]['TEXT'] = "Employee Health & Safety Handbook or Written Instructions Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["employeeHealthSafety"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["employeeHealthSafety"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;			
		
															$data[$index_y][$index_x]['TEXT'] = "Copies of Training Certificates for Relevant Personnel Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["trainingCertificates"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["trainingCertificates"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
		
																$data[$index_y][$index_x]['TEXT'] = "Examples of Work Equipment Maintenance and Test Records Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["workEquipment"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["workEquipment"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;			
	
																	$data[$index_y][$index_x]['TEXT'] = "Examples of Portable Appliance Testing Records Ref :";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["portableAppliance"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["portableAppliance"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
	
																		$data[$index_y][$index_x]['TEXT'] = "Examples of Employee Guidance Documentation for Work Equipment Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["employeeGuidanceDocumentation"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["employeeGuidanceDocumentation"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
	
	$data[$index_y][$index_x]['TEXT'] = "Copy of Public Liability Insurance Certificate Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["publicLiabilityInsurance"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["publicLiabilityInsurance"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;			
					
		$data[$index_y][$index_x]['TEXT'] = "Copy of Employers Liability Insurance Certificate Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["employersLiabilityInsurance"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["employersLiabilityInsurance"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;							


		$data[$index_y][$index_x]['TEXT'] = "Example Evidence of Health Surveillance Undertaken Ref : ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["evidenceHealthSurveillance"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["evidenceHealthSurveillance"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;							
	
			$data[$index_y][$index_x]['TEXT'] = "Example Fire Risk Assessment Ref :  ";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
if ($modData["docsscore"]["fireRiskAssessment"])
	$data[$index_y][$index_x]['BG_COLOR'] = $amber;
	else
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "3";
	$index_x+=3;
		$data[$index_y][$index_x]['TEXT'] = $modData["docs"]["fireRiskAssessment"];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = $white;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x=0;
		$index_y++;	
	
				$data[$index_y][$index_x]['TEXT'] = "Assessment Completed by:";
	$data[$index_y][$index_x]['T_SIZE'] = $headfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;

	$index_x = 0;
	
		$data[$index_y][$index_x]['TEXT'] = "Job Title";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["docs"]['jobTitle'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = "When";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["docs"]['docWhen'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';

	$index_x=0;
	$index_y++;

			$data[$index_y][$index_x]['TEXT'] = "Who";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;

	$data[$index_y][$index_x]['TEXT'] = $modData["docs"]['who'];
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;

	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_x++;


	$index_x++;
	$index_y++;
	
	
	
	
	
	$data[$index_y][$index_x]['TEXT'] = "";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(0,0,0);
	$data[$index_y][$index_x]['BG_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['T_ALIGN'] = 'L';
	$index_y++;

	$index_x = 0;
	
	}
	
	else{
/*
	$data[$index_y][$index_x]['TEXT'] = "Approved by Tender";
	$data[$index_y][$index_x]['T_SIZE'] = $hfsize;
	$data[$index_y][$index_x]['T_COLOR'] = array(255,255,255);
	$data[$index_y][$index_x]['BG_COLOR'] = $dark_purple;
	$data[$index_y][$index_x]['T_ALIGN'] = 'C';
		$data[$index_y][$index_x]['COLSPAN'] = "4";
	$index_y++;
*/
	$index_x = 0;
	}
	
			
	$data_count = count($data);

	for ($k=0;$k<$data_count;$k++) {
		$pdf->Draw_Data($data[$k]);
	}

$pdf->Ln(2);
$pdf->Output('','I');

?>
