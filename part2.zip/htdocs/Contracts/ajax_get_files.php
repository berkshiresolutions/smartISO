<?php
 /**
  $Id: ajax_get_files.php,v 3.02 Wednesday, October 27, 2010 9:21:29 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, October 26, 2010 5:14:03 PM>
  */
$_HIDE_HTTP_HEADER = true;


require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$contractorObj = new Contractor();
$objFile = new Upload();

$cid = (int) $_GET['cid'];
$section_identifier = $_GET['section'];
$tab = $_GET['tab'];

$action = $_GET['action'];
if ( $action == 'delete' && isset($_GET['delete_id'])) {
	$contractorObj->setContractorInfo($_GET['delete_id'],4,"");
	$single_files_data = $contractorObj->getContractorFileDetails();

	$objFile->setFileInfo('contractor',array('id'=>$single_files_data['filesID'],'destination'=>'contractor'));
	$file_detail = $objFile->delete_file();

	$contractorObj->deleteContractorFiles();
}

$contractorObj->setContractorInfo($cid,$tab,array('identifier'=>$section_identifier));
$files_data = $contractorObj->getContractorFiles();

$block_height = 0;
$files = "";
//$files .= "<script src='/includes/js/validations/contractor/manage_files.js'></script>";
$files .= "<p class='popupHeader'>Uploaded Files</p>";
$files .= "<ul><li>";
$files .= "<div class='dse_popup'>";

if ( count($files_data) ) {

	foreach ( $files_data as $value ) {

		$objFile->setFileInfo('contractor',array('id'=>$value['filesID']));
		$file_detail = $objFile->getFileDetails();
		//$files .= $value['id'].'~!'.$file_detail['usrFilename'].'~!'.$file_detail['sysFilename'].'##!!';
		$files .= "<p><label style='padding-left:15px'><a href='javascript:void(0)' onclick=\"window.open('../download_file.php?fn=".$file_detail['sysFilename']."&un=".$file_detail['usrFilename']."&module=contractor','mywindow')\">".$file_detail['usrFilename']."</a></label>";
		$files .= "<label style='width:20%;float:right'><a href='javascript:void(0)' rel='".$value['id']."' class='delete_file'>Delete</a></label></p>";
		$block_height = $block_height + 20;
	}

} else {
	$files .= "<p>No Files</p>";
}

$files .= "</li></ul></div>";
	$files .= "<div class='new_button1'>";
		$files .= "<ul>";

		$files .= "<li><a href='javascript:void(0)' class='close_comment_box' id='close' title='Cancel'><img src='/images/cancel7.png' width='24px' height='24px'></a></li>";
		
		$files .= "</ul>";
	$files .= "</div>";
//$files .= "<p style='text-align:right;padding-top:25px;padding-right:15px'><a href='javascript:void(0)' class='close_comment_box'>Close</a></p>";

echo $files.'##!'.$block_height;
?>