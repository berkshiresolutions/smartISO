<?php
 /**
  $Id: index.php,v 3.61 Thursday, February 03, 2011 2:41:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Wednesday, September 29, 2010 2:17:35 PM>
  */



// load jquery validation script file

//$_PAGE_VALIDATION_SCRIPT 	= 'smart_bcp/report.js';
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


header('Content-type: application/vnd.ms-word');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=Report_R3.doc');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

		
		
require _MYCLASSES."report/contractsModReport.class.php";



$filters = array('type'=>'R3');
$modObj = new contractsModReport($filters);
$modData = $modObj->getData();
	
	//dump_array($modData);
	//exit;

$eqObj		 = new Upload();
$optionObj	 = new Option();

$eqObj->setFileInfo('company_logo',"");
$file_details = $eqObj->getFileDetailsByModule();
$company_logo = $file_details['sysFilename'];

//$fn = fopen('Report_R3.doc','w');
?>



	<table cellspacing='0' cellpadding='0' width='100%' border='1'>
	
	
	
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
            <td><img src=<?php echo  "http://".$_SERVER['HTTP_HOST']."/pub/".$company_logo ?> ></td>
            <td colspan='4' style='color:white'>Report R3</td>
		</tr>
	
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
	<td style='color:white'>Reference</td>
	<td style='color:white'>Contract</td>
	<td style='color:white'>Detail</td>
	<td style='color:white'>Contract Manager</td>

	</tr>
	
	<?php 
	foreach($modData as $k=>$v){  ?>
	<tr style='border: 1px solid;'>
	<td>
	

	<?php echo $v['reference'] ?>
	
	
	</td>
	<td>
	
	<?php echo $v['contractName'] ?>
	</td>
	<td>
	
	<?php echo $v['detail'] ?>
	</td>
	<td>
	<?php echo $v['whoID'] ?>
	</td>

	</tr>
	
	<?php }

	

	
	?>
	
	
	</table>


<?php

//fclose($fn);





//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>