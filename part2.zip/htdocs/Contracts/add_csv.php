<?php
 /**
  $Id: PHP-4.php,v 3.01 Friday, January 14, 2011 5:17:46 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <gurnam_84@hotmail.com>
  * @package Smartiso
  * @subpackage DSE
  * @since  Friday, January 14, 2011 5:17:46 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$objExport = new ExportData('ContractFull','csv');
$objExport->downloadFile();

?>