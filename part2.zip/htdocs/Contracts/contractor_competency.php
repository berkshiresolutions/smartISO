<?php
 /**
  $Id: contractor_competency.php,v 3.44 Saturday, December 04, 2010 3:36:10 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  *  This file is for adding/editing the competency section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Thursday, October 07, 2010 12:41:33 PM>
  */

$class_competency = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Competency"; // for current breadcrums



// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,3,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	$data_array['contractor_id'] 					= $_POST['cid'];
	$data_array['assess_competency1'] 				= $_POST['hseq_competency_1'];
	$data_array['assess_competency2'] 				= $_POST['hseq_competency_2'];
	$data_array['assess_competency3'] 				= $_POST['hseq_competency_3'];
	$data_array['communicate_issues1'] 				= $_POST['hseq_issues_1'];
	$data_array['communicate_issues2'] 				= $_POST['hseq_issues_2'];
	$data_array['communicate_issues3'] 				= $_POST['hseq_issues_3'];
	$data_array['assess_health_safety'] 			= $_POST['radio_health_safety'];
	$data_array['assess_environment_protection'] 	= $_POST['radio_environment_protection'];
	$data_array['undertake_assessment1'] 			= $_POST['assessment_1'];
	$data_array['undertake_assessment2'] 			= $_POST['assessment_2'];
	$data_array['undertake_assessment3'] 			= $_POST['assessment_3'];
	$data_array['undertake_assessment4'] 			= $_POST['assessment_4'];
	$data_array['undertake_assessment5'] 			= $_POST['assessment_5'];
	$data_array['undertake_assessment6'] 			= $_POST['assessment_6'];
	$data_array['responsible_health_name'] 			= $_POST['health_safety_name'];
	$data_array['responsible_environment_name'] 	= $_POST['environment_protection_name'];
	$data_array['responsible_environment_position'] = $_POST['environment_protection_position'];
	$data_array['responsible_quality_name'] 		= $_POST['quality_name'];
	$data_array['responsible_quality_position'] 	= $_POST['quality_position'];
	$data_array['responsible_health_position'] 		= $_POST['health_safety_position'];


	$section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,3,$data_array);
		$contractorObj->editContractor();
	} else {
		//do insert
		$contractorObj->setContractorInfo(0,3,$data_array);
		$contractorObj->addContractor();
	}

	redirection("contractor_policy.php?cid=".$record_id);

}
/* Current contractor record id */
$smarty->assign('cid', $cid);

$data = $contractorObj->viewContractor();


/* For edit mode*/
if ( $action == 'edit' ) {

	$edit_data['section_record_id'] 				= $data['ID'];
	$edit_data['hseq_competency_1'] 				= smartisoStripslashes($data['assessCompetency_1']);
	$edit_data['hseq_competency_2'] 				= smartisoStripslashes($data['assessCompetency_2']);
	$edit_data['hseq_competency_3'] 				= smartisoStripslashes($data['assessCompetency_3']);
	$edit_data['hseq_issues_1'] 					= smartisoStripslashes($data['communicateIssues_1']);
	$edit_data['hseq_issues_2'] 					= smartisoStripslashes($data['communicateIssues_2']);
	$edit_data['hseq_issues_3'] 					= smartisoStripslashes($data['communicateIssues_3']);
	$edit_data['radio_health_safety'] 				= $data['assessHealthSafety'];
	$edit_data['radio_environment_protection'] 		= $data['assessEnvironmentProtection'];
	$edit_data['assessment_1'] 						= smartisoStripslashes($data['undertakeAssessment_1']);
	$edit_data['assessment_2'] 						= smartisoStripslashes($data['undertakeAssessment_2']);
	$edit_data['assessment_3'] 						= smartisoStripslashes($data['undertakeAssessment_3']);
	$edit_data['assessment_4'] 						= smartisoStripslashes($data['undertakeAssessment_4']);
	$edit_data['assessment_5'] 						= smartisoStripslashes($data['undertakeAssessment_5']);
	$edit_data['assessment_6'] 						= smartisoStripslashes($data['undertakeAssessment_6']);
	$edit_data['health_safety_name'] 				= smartisoStripslashes($data['responsibleHealthSafetyName']);
	$edit_data['health_safety_position'] 			= smartisoStripslashes($data['responsibleHealthSafetyPosition']);
	$edit_data['environment_protection_name'] 		= smartisoStripslashes($data['responsibleEnvironmentProtectionName']);
	$edit_data['environment_protection_position'] 	= smartisoStripslashes($data['responsibleEnvironmentProtectionPosition']);
	$edit_data['quality_name'] 						= smartisoStripslashes($data['responsibleQualityName']);
	$edit_data['quality_position'] 					= smartisoStripslashes($data['responsibleQualityPosition']);

	//dump_array($edit_data);

} else {

	$how_you_intend['hseq_competency']         = "";
	$how_you_intend['hseq_issues']             = "";

	$undertaking_assessment[]                  = "";

	$persons_responsible_hseq['name']          = "";
	$persons_responsible_hseq['position']      = "";

	$yes_status_health_safety                  = "unchecked";
	$no_status_health_safety                   = "unchecked";
	$yes_status_environment_protection         = "unchecked";
	$no_status_environment_protection          = "unchecked";

	$edit_data['radio_health_safety'] 				= "";

}

$smarty->assign('edit_data',$edit_data);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

$smarty->display($CURRENT_MODULE."/contractor_competency.tpl");

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>