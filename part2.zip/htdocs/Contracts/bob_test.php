<?php
 /**
  $Id: ajax_get_files.php,v 3.02 Wednesday, October 27, 2010 9:21:29 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, October 26, 2010 5:14:03 PM>
  */
$_HIDE_HTTP_HEADER = true;


require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$contractObj	= new Contract();

$options=$contractObj->getquarter(2013,5,12);

dump_array($options);
			

?>