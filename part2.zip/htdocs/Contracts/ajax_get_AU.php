<?php
 /**
  $Id: ajax_get_files.php,v 3.02 Wednesday, October 27, 2010 9:21:29 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, October 26, 2010 5:14:03 PM>
  */
$_HIDE_HTTP_HEADER = true;


require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$eqObj = SetupGeneric::useModule('Participant');
$orgObj = SetupGeneric::useModule('Organigram');
$authObj = SetupGeneric::useModule('AuthorizedUser');
		$parentbuID	=$_GET['buID'];
			$pf_au			= 		$authObj->getIssuerPermissionBu('perm_contr',$parentbuID,1);

		$parentnewbuID = -1;

		while ($parentbuID != $parentnewbuID)	
		{
		$parentnewbuID = $parentbuID; 

		$parentbuID	=$orgObj->getParentBU($parentnewbuID);
	
		$pf_au1		= 		$authObj->getIssuerPermissionBu('perm_contr',$parentbuID,1);
$pf_au=array_merge($pf_au,$pf_au1);
		}	

	foreach ($pf_au as $value) {
		$participant_id = $value['participantID'];
	$partarry[$participant_id]= $participant_id;
}

$getLoggedInUser=getLoggedInUserId();
$partarry[$getLoggedInUser]= $getLoggedInUser;


foreach ($partarry as $value) {
				$participantObj->setItemInfo(array('id'=>$value));
				$partcipantData = $participantObj->displayItemById();

	if ($partcipantData['participantID'] )
		$options .= "<option value=".$value." >".$partcipantData['forename']." ".$partcipantData['surname']."</option>\n";
	
			
}



echo $options;
			

?>