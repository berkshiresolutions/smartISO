<?php
/**
 $Id: add_edit_contractor.php,v 4.20 Thursday, February 10, 2011 4:04:41 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh
 * @package Smartiso
 * @subpackage Contractors
 * @since  Tuesday, September 07, 2010 12:38:00 PM>
 */

$class_company_details = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Contract Details"; // for current breadcrums


// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contract/add_edit_contract.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$orgObj 			= SetupGeneric::useModule('Organigram');
$objRef 			= new UniqueReference();
$miscObj			= new Misc();

$cid 				= (int) $_GET['cid'];
$locObj			 	= SetupGeneric::useModule('Locationgram');
$contractorObj 			= new Contract();

$contractorObj->setContractInfo($cid,1,"");
$action = Session::getSessionField('action');

Session::getSessionField('record_id');

$sql = sprintf("SELECT * FROM %s.participant_database", _DB_OBJ_FULL);
$dbHand = DB::connect(_DB_TYPE);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$participants = '';
$participansArr = array();
$participansDetailsArr = array();
while (($row = $pStatement->fetch(PDO::FETCH_ASSOC))) {
	$id = $row['participantID'];
	$name = $row['forename'];
	$surname = $row['surname'];
	if ($surname) $name .= ' ' . $surname;
	$participants .= '<option value="' . $id . '">' . $name . '</option>';
	$participansArr[$id] = $name;
	$participansDetailsArr[$id] = $name.' ('.$id.')';
}


if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	//dump_array($_POST);exit;
	//echo $date = $_POST['date'] != '' ? date('Y-m-d', strtotime($_POST['date'])) : '1900-01-01';

	$data_array['contractName'] 		= $_POST['contract_title'];
	$data_array['shortTermOrTender'] 	= (int) $_POST['shortTermOrTender'];
	$data_array['detail']				= $_POST['detail'];
	$data_array['buID'] 				= $_POST['business_unit'];
	$data_array['startDate']			= $_POST['startDate'];
	$data_array['endDate']			    = $_POST['endDate'];
	$data_array['reviewDate']			=$_POST['reviewDate'];
	$data_array['reviewDate']			=date('m/d/Y');
	$data_array['reviewDueDate']		=$_POST['reviewDueDate'];
	$data_array['totalValue']			= $_POST['contract_value'];
	$data_array['remarks']			    = $_POST['remarks'];
	$data_array['location']			    = $_POST['location'];
$data_array['ISflag']			    = isset($_POST['ISflag']) ? 1 : 0 ;
$data_array['bcp']			    = isset($_POST['bcp']) ? 1 : 0 ;	

	//$data_array['useApprovedContractor']	= $_POST['record_radio'];
	if ($_POST['useApprovedContractorCheck']) {
		$contractor = $_POST['useApprovedContractor'];
		$sIndex = strrpos($contractor, '(') + 1;
		$eIndex = strrpos($contractor, ')');
 		$data_array['useApprovedContractor']	= substr($contractor, $sIndex, $eIndex - $sIndex); 

		$dbHand = DB::connect(_DB_TYPE);
		$sql = sprintf("SELECT * FROM %s.contractor WHERE uniqueReference = '%s'", _DB_OBJ_FULL, $data_array['useApprovedContractor']);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$value = $pStatement->fetch(PDO::FETCH_ASSOC);

		$data_array['useApprovedContractor'] = $value['ID'];

	}
	if ($_POST['contract_manager']) {
		$cm = $_POST['contract_manager'];
		$sIndex = strrpos($cm, '(') + 1;
		$eIndex = strrpos($cm, ')');
		$data_array['contractManagerID']	= substr($cm, $sIndex, $eIndex - $sIndex);
	}
	if ($_POST['manager_approver']) {
		$cm = $_POST['manager_approver'];
		$sIndex = strrpos($cm, '(') + 1;
		$eIndex = strrpos($cm, ')');
		$data_array['managerApproverID']	= substr($cm, $sIndex, $eIndex - $sIndex);
	}
	if ($_POST['director_approver']) {
		$cm = $_POST['director_approver'];
		$sIndex = strrpos($cm, '(') + 1;
		$eIndex = strrpos($cm, ')');
		$data_array['directorApproverID']	= substr($cm, $sIndex, $eIndex - $sIndex);
	}

	$data_array['contractManagerID'] 		= $_POST['contract_manage_hidden'];
	$data_array['managerApproverID'] 		= $_POST['manager_approver_hidden'];
	$data_array['directorApproverID'] 		= $_POST['director_approver_hidden'];
	//$data_array['unique_reference'] 		= $_POST['unique_reference'];
	//$data_array['trg'] 						= (int) $_POST['trg'];

	$record_id = (int) $_POST['cid'];
	//print $record_id;
	
	// dump_array($_POST);exit;


	if ( $record_id ) {
		$contractorObj->setContractInfo($record_id,1,$data_array);
		$contractorObj->editContract();
	} else {
		//$data_array['unique_reference'] 	= $_POST['unique_reference'];
		$data_array['reference'] 		= $_POST['reference_number'];


		$contractorObj->setContractInfo(0,1,$data_array);
		$contractorObj->addContract();
		//$miscObj->saveRecordAction(array('module'=>'CT','ref'=>$data_array['reference'],'action'=>'add')); // for tracking record actions
		 $record_id = $contractorObj->getCurrentRecordId();
	}



	//echo (!$_POST['record_radio']);exit;
	if($data_array['useApprovedContractor'] != '') redirection("index.php?e=6"); else {
		
		$_SESSION['Contract']['OnHold'] = $_POST['contract_title'];
		$_SESSION['Contract']['OnHoldContractManager'] 	= $participansArr[$_POST['contract_manager']];
		$_SESSION['Contract']['OnHoldContractManagerID'] 	= $_POST['contract_manage_hidden'];
		$_SESSION['Contract']['OnHoldContractTender'] 	= $data_array['shortTermOrTender'];
		$_SESSION['Contract']['OnHoldBU'] 	= $_POST['business_unit'];
		$_SESSION['Contract']['OnHoldCM'] 	= $_POST['contract_manage_hidden'];
		
		// redirection("../contracts/add_edit_contractor.php");
		redirection("index.php?e=6");
	}
}


/* Current contractor record id */
$smarty->assign('cid', $cid);

echo "<script src='/includes/js/validations/email_check.js'></script>";
echo "<script src='/includes/js/validations/check_numeric.js'></script>";

$data = $contractorObj->viewContract();
//dump_array($data);exit();
/* edit mode */

if ( $cid ) {

	 $contractor_add['reference_number']		= $data['reference'];
	 $contractor_add['buID']                    =(int) $data['buID'];
	 $contractor_add['totalValue']               =number_format($data['totalValue'],2,'.','');
	 $contractor_add['detail']                  = $data['detail'];
	 $contractor_add['contractName']            = $data['contractName'];
	 $contractor_add['remarks']                 = $data['remarks'];
	 $contractor_add['short_term_or_tender']	= (int)$data['shortTermOrTender'];
	 $contractor_add['company_name']			= smartisoStripslashes($data['companyName']);
	 $contractor_add['address'] 				= smartisoStripslashes($data['address']);
	 $contractor_add['telephone']				= $data['telephoneNumber'];
	 $contractor_add['email'] 					= $data['emailAddress'];
	 $contractor_add['location'] 				= $data['location'];
	 $contractor_add['contact_person'] 			= smartisoStripslashes($data['contactPerson']);
	 $contractor_add['start_date'] 				= format_date($data['startDate']);
	 $contractor_add['revieQtrFDate'] 			= format_date($data['reviewDueDate']);
	 $contractor_add['reviewDate'] 				= format_date($data['reviewDate']);
	 $contractor_add['end_date'] 				= format_date($data['endDate']);
	 $contractor_add['fax'] 					= $data['fax'];
         $contractor_add['ISflag'] 					= $data['ISFlag'];
         $contractor_add['bcp'] 					= $data['BCP'];
	//$contractor_add['TRG'] 					= $data['TRG'] == '1' ? 'checked' : '';
	 $contractor_add['approvedbytender'] 		= $data['useApprovedContractor'] >  0 ? 'checked' : '';
	 $selected               					= $data['buID'];

	
	

		$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$data['contractManagerID']);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$contractManager = $resultSet['forename'] . ' ' . $resultSet['surname'];

		$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$data['managerApproverID']);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$managerApprover = $resultSet['forename'] . ' ' . $resultSet['surname'];

		$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$data['directorApproverID']);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$directorApprover = $resultSet['forename'] . ' ' . $resultSet['surname'];



	$miscObj->saveRecordAction(array('module'=>'CT','ref'=>$data['reference'],'action'=>'edit')); 

	$contractor_add['contractManagerName'] = $contractManager;
	$contractor_add['managerApproverName'] = $managerApprover;
	$contractor_add['directorApproverName'] = $directorApprover;

	$contractor_add['contract_manage'] = $data['contractManagerID'];
	$contractor_add['manager_approver'] = $data['managerApproverID'];
	$contractor_add['director_approver'] = $data['directorApproverID'];

	if($data['useApprovedContractor'] >  0 ){
		$sqlc = sprintf("SELECT * FROM %s.contractor where ID=%d", _DB_OBJ_FULL,$data['useApprovedContractor']);
		$dbHandc = DB::connect(_DB_TYPE);
		$pStatementc = $dbHandc->prepare($sqlc);
		$pStatementc->execute();
		$rowc = $pStatementc->fetch(PDO::FETCH_ASSOC);
		$contractor_add['useApprovedContractor'] = $rowc['companyName'].' ('.$rowc['reference'].')';

	}
	 


} else {
   $unique_reference 	= $objRef->getUniqueNumber('CONTRACT');
    
	$contractor_add['reference_number'] = $unique_reference;
	$contractor_add['buID'] = 0;
	$contractor_add['totalValue']="";
	$contractor_add['short_term_or_tender'] = 0;
	$contractor_add['company_name'] = "";
	$contractor_add['address'] = "";
	$contractor_add['telephone'] = "";
	$contractor_add['email'] = "";
	$contractor_add['location'] = 0;
	$contractor_add['contact_person'] = "";
	$contractor_add['start_date'] = date('m/d/Y');
	$contractor_add['end_date'] = date('m/d/Y');
	$contractor_add['reviewDate'] =  date('m/d/Y');



$quarter=$contractorObj->getquarter(date('Y'),date('m'),date('d'));


$contractor_add['revieQtrFDate']=$quarter['month']."/".$quarter['day']."/".date('Y');

$smarty->assign('contractor_add', $contractor_add);

//**********************************************************

	$contractor_add['fax'] = "";
	$contractor_add['unique_refrence']	= $unique_reference;
	$selected  = 0;
	$contractor_add['detail']                 = "";
	$contractor_add['contractName']           = "";
	$contractor_add['remarks'] = "" ;
	$contractor_add['contractManager'] = "";
	$contractor_add['managerApprover'] = "";
	$contractor_add['directorApprover'] = "";
	$contractor_add['approvedbytender'] = 0;
}

$smarty->assign('selected',$selected);
$business_units = $orgObj->getBusinessUnits($selected,true,true);
//echo htmlspecialchars($business_units);

//$contract_manager = $orgObj->getContractManager($selected);

$location_data = $locObj->getLocations($contractor_add['location']);

//print "<pre>";


$smarty->assign('unique_refrence', $unique_refrence);
$smarty->assign('contractor_add', $contractor_add);
$smarty->assign('location', $location_data);

$smarty->assign('business_units',$business_units);

$smarty->assign('participants',$participants);

$session_action = Session::getSessionField('action');

$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);
//$smarty->debugging=true;
$smarty->display($CURRENT_MODULE.'/add_edit_contract.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>

