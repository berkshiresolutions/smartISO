 /**
  $Id: add_edit_contractor.js,v 3.48 Saturday, December 18, 2010 12:28:53 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, September 07, 2010 12:39:19 PM>
  */

(function($) {
	$(document).ready(function () {
		$.hideError();
		
		$('.participants').participant({
			//'url' : '../ajax_participants.php'
			'url' : '../ajax_participants2.php'
		});
		
		$('.approvedContractors').participant({
			//'url' : '../ajax_participants.php'
			'url' : '../contractors/ajax_contractors.php'
		});


		var alert_msg	= Object();

		alert_msg.confirm_reference			= 'Please enter the reference number.';
		alert_msg.confirm_email				= 'Please enter the email address.';
		alert_msg.confirm_valid_email		= 'Please enter a valid email address.';
		alert_msg.confirm_company_name		= 'Please enter the contract title.';
		alert_msg.confirm_contact_person	= 'Please enter the contact person.';
		alert_msg.confirm_phone				= 'Please enter the telephone number.';
		alert_msg.confirm_valid_date		= 'Please enter the a valid date.';
		alert_msg.confirm_valid_phone		= 'Please enter a valid telephone number.';

		$('.save_record').click(function() {

			$.hideError();

			record_id 		= $('#cid').val();
			refrence_val 	= $('#reference_number').val();
			company_name 	= $('#contract_title').val();

			if ( company_name == '') {
				$.showError(alert_msg.confirm_company_name);
				$('#contract_title').focus();
				return false;
			}
alert ($('#startDate').val() );
			if ( $('#startDate').val() == ''){
				$.showError(alert_msg.confirm_valid_date);
				$('#startDate').focus();
				return false;
			}




			if ( record_id == 0 ) {
				if ( refrence_val == '') {
					$.showError(alert_msg.confirm_reference);
					$('#reference_number').focus();
					return false;
				}
			}

			document.contractor_company_details.submit();
		});

		$('.cancel_record').click(function() {

			alert_msg = "Are you sure you want to cancel this Contract record?";

			var task_val = $('#task').val();
			var record_id = $('#cid').val();

								jConfirm('Can you confirm this?', 'Confirmation', function(r) {
												if (r) {
																if ( task_val == 'add' ) {
																				$.get('delete_restore_record.php', {'rec_id':record_id, 'purge_record':1});
																}

															document.location.href = 'index.php';
												} else {
																return false;
												}
											},'Yes','No');
		});


			$('#primary_hazard_class').change(function() {
				parent_hazard_id = $(this).val();

				if ( parent_hazard_id == 17 ) {
					$('.dse_block').show();
				} else {
					$('.dse_block').hide();
				}

				$.get('ajax_get_sub_hazards.php',{parent_id:parent_hazard_id},function(data) {
					$('#hazard').html(data);
				});
			});
			

		$('.business_unit').change(function(){
	 ajax_url='ajax_get_AU.php?buID='+$('#business_unit').val();
			$.get(ajax_url,function(data){
		//	 $('#hazard').html(data);
			$('#contract_manager').html(data);	
			});
	
		})
		
		$('.back_button').click(function() {

			SM_back();
		});

		$('.reset_button').click(function () {

			$('form').clearForm();
		})
	});
	
	// contractors
	
	var $tender = $('#_tender');
	
	var $contractors = $('#record_container');
	$contractors.css('display', 'none');
	
	$('#useApprovedContractorCheck').change(function() {
		var checked = $(this).attr('checked');
		$('#useApprovedContractor').css('display', (checked ? 'block' : 'none'));
		$('#dynamic_participant_list').css('display', (checked ? 'block' : 'none'));
	});
	
	/*$('#p_useApprovedContractor input').change(function() {
		var checked = $(this).attr('checked');
		$contractors.css('display', (checked ? 'block' : 'none'));
		var $tr = $contractors.find('tr');
		var tender = $tender.attr('checked');
		$tr.each(function() {
			var $trThis = $(this);
			var $td = $trThis.find('td');
			var count = $td.size();
			if (count <= 0) return;
			var innerHTML = $td[count - 1].innerHTML;
			if (tender) {
				$trThis.css('display', (innerHTML.indexOf('#800080') >= 0 ? 'table-row' : 'none'));
			} else {
				$trThis.css('display', (innerHTML.indexOf('#800080') >= 0 ? 'none' : 'table-row'));
			}
		});
	});*/
	
	/*$.get('../contractors/records.php',loadTable);
	
	function loadTable(data) {

		$('#record_container').html(data);
		var oTable = $('#module_records').dataTable({
				"bStateSave": true,
				"sPaginationType": "full_numbers",
				//"range_search": true,
				"sScrollY": "280px",
				"aoColumnDefs": [
						{ "bSortable": false, "aTargets": [0] }]
		});

		$('.datepicker').datepicker({
			changeMonth: true,
			changeYear: true
		});

		/* Add event listeners to the two range filtering inputs */
		//$('.ui-corner-all').click( function() { oTable.fnDraw(); } );
		//$('.ui-corner-all').click( function() { oTable.fnDraw(); } );
	//}

})(jQuery);
