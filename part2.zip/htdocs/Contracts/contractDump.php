<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$locObj	= SetupGeneric::useModule('Locationgram');
$contractorObj = new Contract();

$contractorObj->setContractInfo(0,1,"");
//$action = Session::getSessionField('action');

$data = $contractorObj->viewContract();
	
$thisContractQuarter = $contractorObj->getquarter(date('Y'),date('m'),date('d'));
//var_dump($thisContractQuarter);
echo "This contract Quarter = ".$thisContractQuarter['quarter'].",".$thisContractQuarter['year']."<br/>";
echo "So showing quarters ".implode(",", range(1,$thisContractQuarter['quarter']))." for ".$thisContractQuarter['year']."<br/>";

$dbHand = DB::connect(_DB_TYPE);
$reviewData = array();
foreach(array($thisContractQuarter['year']-1,$thisContractQuarter['year'],$thisContractQuarter['year']+1) as $year) {
	$reviewData[$year] = array();
	foreach(range(1,4) as $qtr) {
		$sql = sprintf( 
			'SELECT * FROM %s.contract_review WHERE yearCovered = %d AND quarterCovered = %d AND archive != 1', 
			_DB_OBJ_FULL, 
			$year,
			$qtr
		);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		if($pStatement->errorCode() == 0) {
			$tmp = array();
			// now for each contract quarter we make sure these are mapped
			foreach( $pStatement->fetchAll(PDO::FETCH_ASSOC) as $contractReview) {
				 $tmp[$contractReview['contractID']] = $contractReview;
			}
			$reviewData[$year][$qtr]=$tmp;
		}
	}
}
echo "<pre>";
foreach($reviewData as $yearNum=>$yearData) {
	echo '<h6>'.$yearNum."</h6><br/>\r\n";
	foreach($yearData as $qtrNum=>$qtrData) {
		echo "\t<b>".$qtrNum."</b><br/>\r\n";
		foreach($qtrData as $contract) {
			echo "\t\t".$contract['contractID'].' = '.$contract['ID'].(($contract['daApproved'] == 1) ? ' Done' : ( ( $contract['yearCovered'] < $thisContractQuarter['year'] ) ? ' Outstanding' : (($contract['yearCovered'] > $thisContractQuarter['year']) ? ' Pending' : (($contract['quarterCovered'] < $thisContractQuarter['quarter']) ? ' Outstanding' : ' Pending' ) ) ) ).(($contract['archive'] == 1) ? ' Archived' : '')."<br/>\r\n";
		}
	}
}
echo "</pre>";


echo '<pre>'.var_export($reviewData,true).'</pre>';
echo $days = date( 'z', strtotime( $data['startDate'] ) );

echo $days = date( 'z', strtotime( '2012-06-05' ) );
