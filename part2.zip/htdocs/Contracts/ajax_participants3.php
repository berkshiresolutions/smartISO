<?php
 /**
  $Id: ajax_participants.php,v 3.22 Saturday, January 29, 2011 12:08:03 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$str = strip_tags($_GET['str']);
/*
$eqObj = SetupGeneric::useModule('Participant');
$eqObj->setItemInfo(array(
						  'id' => 1,
						'forename' => $str,
						));

$data = $eqObj->displayItemByForename();

$dbHand = DB::connect(_DB_TYPE);
//$sql = "SELECT * FROM " . _DB_OBJ_FULL . ".participant_database WHERE forename LIKE '" . $str . "%' ORDER BY forename";
$sql = "SELECT distinct D.participantID,D.surname,D.forename FROM ". _DB_OBJ_FULL .".participant_database D
				INNER JOIN
					"._DB_OBJ_FULL.".participant_meta_data M
				ON
					D.participantID = M.participantID
				INNER JOIN
					"._DB_OBJ_FULL.".participant_authorization_stats N
				ON
					D.participantID = N.participantID
				WHERE forename LIKE '".$str."%' AND sectionName = 'perm_contr' AND sectionActive=1  ORDER BY forename";
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();

*/


$eqObj = SetupGeneric::useModule('Participant');
$orgObj = SetupGeneric::useModule('Organigram');
$authObj = SetupGeneric::useModule('AuthorizedUser');
		$parentbuID	=$_GET['buID'];
			$pf_au			= 		$authObj->getIssuerPermissionBu('perm_contr',$parentbuID,1);

		$parentnewbuID = -1;

		while ($parentbuID != $parentnewbuID)	
		{
		$parentnewbuID = $parentbuID; 

		$parentbuID	=$orgObj->getParentBU($parentnewbuID);
	
		$pf_au1		= 		$authObj->getIssuerPermissionBu('perm_contr',$parentbuID,1);
$pf_au=array_merge($pf_au,$pf_au1);
		}	

	foreach ($pf_au as $value) {
		$participant_id = $value['participantID'];
	$partarry[$participant_id]= $participant_id;
}

$getLoggedInUser=getLoggedInUserId();
$partarry[$getLoggedInUser]= $getLoggedInUser;



$records = array();

$i=0;


foreach ($partarry as $value) {
				$participantObj->setItemInfo(array('id'=>$value));
				$value = $participantObj->displayItemById();
				if ($_GET['str'])
				{
				$pos=stripos($value['forename'],$str);
			
				if ($pos !== 0)
				continue;
}
	$id = $value['participantID'];
	$records[$i]['id'] = $id;
	$records[$i]['name'] = $value['forename'] . ' ' . $value['surname'] . '';
	$i++;
}

$resultset = array('records' => $records);

echo json_encode($resultset);
?>