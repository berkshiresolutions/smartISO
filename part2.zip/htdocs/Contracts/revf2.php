<?php
 /**
  $Id: contractor_management.php,v 4.03 Saturday, December 04, 2010 2:53:31 PM ehsindia Exp $
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the management section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractor
  * @since  Wednesday, October 06, 2010 6:39:34 PM>
  */

$class_management = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Detailed Review"; // for current breadcrums
$sourceupload = $_SERVER['DOCUMENT_ROOT']."/images/uploads/";

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contract/revf2.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

@session_start();
$USER_ID = getLoggedInUserId();
//$reviewer = $_SESSION['SMARTISO_SESS_USER_REC_ID'];
$reviewer = $USER_ID;
if ($_GET['id'])
$cid = (int) $_GET['id'];
else
$cid = (int) $_GET['cid'];

$f1f2 = 2;
//review and edit use different parameters

$contractorObj = new Contract();
$contractorObjEval = new ContractorEval();

$contractInfo["f1f2"]=$f1f2;


$contractorObj->setContractInfo($cid,1,$contractInfo);
$action = Session::getSessionField('action');
$objParticipant 	= 		SetupGeneric::useModule('Participant');

$contractReviewObj = new ContractReview();

$contractdata = $contractorObj->viewContract();

$today=strtotime(date("Y-m-d"));

$start_date=strtotime($contractdata["startDate"]);

//$dataReviews=$contractorObj->getReviewData();


$startDateArr=explode("-",$contractdata["startDate"]);
/*
$startDateArr[0]=1;
$startDateArr[1]=12;
$startDateArr[2]=2011;
*/

$quarterstart=$contractorObj->getquarter($startDateArr[0],$startDateArr[1],$startDateArr[2]);
$yearstart=$startDateArr[2];

if ($start_date>$today)
{
$qtrarray[$quarterstart["year"].$quarterstart["quarter"]]="Quarter ".$quarterstart["quarter"]." - ".$quarterstart["year"];
}
else
{
$quarter=$contractorObj->getquarter(date('Y'),date('m'),date('d'));
$qtrarray=$contractorObj->getAvailableReviews();
}
/*
$stop=$quarter["year"]*10+$quarter["quarter"];

$current=$quarterstart["year"]*10+$quarterstart["quarter"];

//$year=$quarterstart["year"];
//$qtr=$quarterstart["quarter"];

$year=(int)($current/10);
$qtr=$current%10;

if (!$dataReviews[$current])
$qtrarray[$current]="Quarter ".$qtr." - ".$year;
while ($current < $stop)
{
if ($qtr %4==0)	
{
$year++;
$qtr=1;
}
else
$qtr++;	

$current=$year*10+$qtr;
if (!$dataReviews[$current])
$qtrarray[$current]="Quarter ".$qtr." - ".$year;

}

}

*/


$quarterCovered=$quarter["quarter"];
/*
$nowMonth = intval(date('m'));
if ($nowMonth >= 1 && $nowMonth <= 3) $quarterCovered = 1;
else if ($nowMonth >= 4 && $nowMonth <= 6) $quarterCovered = 2;
else if ($nowMonth >= 7 && $nowMonth <= 9) $quarterCovered = 3;
else if ($nowMonth >= 10 && $nowMonth <= 12) $quarterCovered = 4;
*/
$qc = $quarterCovered;
$yc = intval($quarter["year"]);
/*$qc--;
if ($qc == 0) {
	$qc = 4;
	$yc--;
}*/

$dbHand = DB::connect(_DB_TYPE);
$sql = sprintf("SELECT * FROM %s.contract_review WHERE contractID = %d AND quarterCovered = %d AND yearCovered = %d AND f1f2 = %d",_DB_OBJ_FULL,$cid,$qc,$yc,$f1f2);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$existingReview = $pStatement->fetch(PDO::FETCH_ASSOC);
$existingReviewID = $existingReview['ID'];

$review_id=$existingReview["review_ID"];

$contractorObj->setContractInfo($cid,1,$existingReview);
$outstanding=$contractorObj->getPreviousCNCR();


$fileNameUpload	= unserialize($existingReview['files_invoice']);
$smarty->assign('fileNameUpload', $fileNameUpload);

$fileNameUploadMeetings	= unserialize($existingReview['files_meeting']);
$smarty->assign('fileNameUploadMeetings', $fileNameUploadMeetings);

$fileNameUploadDate	= unserialize($existingReview['meeting_date']);
$smarty->assign('fileNameUploadDate', $fileNameUploadDate);


$existingContractReviewID = $existingReview['ID'];
$contractStillValid = $existingReview['contractStillValid'];
$annualValue = $existingReview['contractAnnualValue'];
$amountPaidInCurrentFinancialYear = $existingReview['amountPaidInCurrentFinancialYear'];
$disputedInvoices = $existingReview['disputedInvoices'];
$disputedInvoicesComment = $existingReview['disputedInvoicesComment'];
$complaints = $existingReview['complaints'];
if (!$existingReview['nonConformances']) $existingReview['nonConformances'] = 0;
if (!$existingReview['cleared']) $existingReview['cleared'] = 0;
if (!$existingReview['outstanding']) $existingReview['outstanding'] = 0;

$kpiNames = array('productQuality', 'serviceQuality', 'onTimeDelivery', 'knowledge', 'reputation', 'customerFocus', 'customerService', 'responsiveness',
		'healthAndQuality', 'finance');
$kpis = array();

$kpiNamesText = array(1=>'Product Quality', 2=>'Service Quality',3=>'Health and Quality',4=> 'On time Delivery', 5=>'Knowledge', 6=>'Reputation', 7=>'Customer Focus',8=> 'Customer Service',9=> 'Responsiveness');

$actions=$contractorObj->getContractActions($review_id,2);

foreach ($kpiNamesText as $key=>$value)
{
$actions[$key]['name']=$value;
if (!$actions[$key][0]['score'])
$actions[$key][0]['score']=1;

$total+=$actions[$key][0]['score'];

}

$kpis=$actions;

ksort($kpis);
/* Current contractor record id */

$smarty->assign('contractID', $cid);
$data = $contractorObj->viewContract();


$contractor_add['company_name']	= smartisoStripslashes($data['companyName']);
$contractor_add['manager']=$data['whoID'];
$smarty->assign('problems', $problems);
$smarty->assign('suggested_action', $suggested_action);
$smarty->assign('suggested_action_id', $suggested_action_id);
$smarty->assign('item_listing', $kpis);
$smarty->assign('average', $total/9);
$smarty->assign('contractor_add', $contractor_add);

$sql = sprintf("SELECT C.reference AS reference,contractName, contractManagerID, managerApproverID, directorApproverID FROM %s.contract C LEFT JOIN %s.contractor D ON C.useApprovedContractor = D.ID WHERE C.ID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$cid);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
$resultSetX = $resultSet;



$ref = $resultSet['reference'];
$cm = $resultSet['contractManagerID'];
$ca = $resultSet['contractManagerID'];
$ma = $resultSet['managerApproverID'];
$da = $resultSet['directorApproverID'];

$contractNo = $resultSet['reference'];
$ContractTitle = $resultSet['contractName'];





//if($_SESSION['SMARTISO_SESS_USER_REC_ID'] == $ca)
if($USER_ID == $ca)
{
	$CmFlagForReject = false;
}
else
{
	$CmFlagForReject = true;
}
//if($_SESSION['SMARTISO_SESS_USER_REC_ID'] == $da)
if($USER_ID == $da)
{
	$daFlag = true;
}
$smarty->assign('daFlag', $daFlag);

$smarty->assign('CmFlagForReject', $CmFlagForReject);





$approved = false;

if (!$existingReview['ID']) {
	$existingReview['saveEnabled'] = true;
	$existingReview['finishEnabled'] = true;
	$existingReview['approvalEnabled'] = true;
} else {
	if ($reviewer == 33 || $reviewer == $cm) {
		$cmFinished = $existingReview['cmFinished'];
		$existingReview['saveEnabled'] = !$cmFinished;
		$existingReview['finishEnabled'] = !$cmFinished;
		$existingReview['approvalEnabled'] = $cmFinished && !($approved = $existingReview['cmApproved']);
	}
	if ($reviewer == 33 || ($reviewer != $cm && $reviewer == $ma) || ($approved && $reviewer == $ma)) {
		$existingReview['saveEnabled'] = false;
		$existingReview['finishEnabled'] = false;
		$existingReview['approvalEnabled'] = !($approved = $existingReview['maApproved']);
	}
	if ($reviewer == 33 || ($reviewer != $ma && $reviewer == $da) || ($approved && $reviewer == $da)) {
		$existingReview['saveEnabled'] = false;
		$existingReview['finishEnabled'] = false;
		$existingReview['approvalEnabled'] = !$existingReview['daApproved'];
	}
}

$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$da);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
$directorApprover = $resultSet['forename'] . ' ' . $resultSet['surname'];
$directoremailAddress = $resultSet['emailAddress'];

$sql = sprintf("SELECT * , D.companyName as companyNamescontractor FROM %s.contract C LEFT JOIN %s.contractor D ON C.useApprovedContractor = D.ID WHERE C.ID = %d",_DB_OBJ_FULL,_DB_OBJ_FULL,$cid);



$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
$resultSet['reference'] = $ref;
$resultSet['directorApprover'] = $directorApprover;
$resultSet['contractAnnualValue'] = $annualValue;
$resultSet['amountPaidInCurrentFinancialYear'] = $amountPaidInCurrentFinancialYear;
$resultSet['disputedInvoices'] = $disputedInvoices;
$resultSet['disputedInvoicesComment'] = $disputedInvoicesComment;
$resultSet['complaints'] = $complaints;
$resultSet['contractStillValid'] = $contractStillValid;
$companyNamescontractor = $resultSet['companyNamescontractor'];


@session_start();
//$resultSet['reviewer'] = $_SESSION['SMARTISO_SESS_FULLNAME'];
if ($existingReview['ID']) 
$resultSet['reviewID'] = $existingReview['ID'];

$resultSet['reviewDate'] = date('Y-m-d');
$resultSet['quarterCovered'] = $quarterCovered;
$resultSetY = $resultSet;

foreach ($existingReview as $k => $v) {
	$resultSet[$k] = $v;
}

foreach ($resultSet as $k => $v) {
	//echo $k , ' = ' , $v , '; ';
}

$objParticipant->setItemInfo(array('id'=>$existingReview["reviewer"]));
$participant_data = $objParticipant->displayItemById();
$resultSet['reviewer'] = trim($participant_data['forename'].' '.$participant_data['surname']);


$smarty->assign('outstanding', $outstanding);
$smarty->assign('existingReview', $existingReview);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {
	

	$emails = array('bepranav11@hotmail.com', 'AidanCowan@rsa.ie', 'jrm@smart-iso.com', 'jgg@smart-iso.com');
	
	$contractID = $cid;
	
	$quarterCovered = $_POST['quarterCovered']%10;
	$yearCovered = (int)($_POST['quarterCovered']/10);
	
	$reviewID = $_POST['reviewID'];
	//$quarterCovered = $_POST['quarterCovered'];
	//$yearCovered = date('Y');
	$amountPaidInCurrentFinancialYear = $_POST['amountPaidInCurrentFinancialYear'];
	$reviewDate = $_POST['reviewDate'];

	$sql = sprintf("SELECT * FROM %s.contract_review_date WHERE quarter = 4 ORDER BY quarter",_DB_OBJ_FULL);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
	$resultSetyy = $pStatement->fetch(PDO::FETCH_ASSOC);

	$reviewEndDate =  $resultSetyy['month']."/".$resultSetyy['day']."/".$resultSetyy['year'];
	$contractStillValid = $_POST['contractStillValid'];
	$contractAnnualValue = $_POST['contractAnnualValue'];
	$disputedInvoices = $_POST['disputedInvoices'];
	$disputedInvoicesComment = $_POST['disputedInvoicesComments'];
	$contractReviewMeetings = $_POST['contractReviewMeetings'];
	$complaints = $_POST['complaints'];
	$score_average = (float)$_POST['average'];
	$qtr_spend = (float)$_POST['qtr_spend'];
	
	$sql = sprintf("SELECT * FROM %s.contract WHERE ID = %d", _DB_OBJ_FULL, $cid);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
	$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
	$contractNumber = $resultSet['reference'];
	
	$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = (SELECT contractManagerID FROM %s.contract WHERE ID = %d)", _DB_OBJ_FULL, _DB_OBJ_FULL, $cid);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
	$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
	//
	//$email = $resultSet['emailAddress'];
	
	$sql = sprintf("SELECT * FROM %s.contractor WHERE ID = (SELECT useApprovedContractor FROM %s.contract WHERE ID = %d)", _DB_OBJ_FULL, _DB_OBJ_FULL, $cid);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
	$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
	$contractorName = $resultSet['companyName'];
	
	$finished = $_POST['finish'];
	$body = '';
	foreach ($kpiNames as $kpiName) {
		$field = $kpiName;
		$kpis[$field] = $_POST[$field];

		$field = $kpiName . 'CNCR';
		$kpis[$field] = $_POST[$field];

		$field = $kpiName . 'Comment';
		$kpis[$field] = $_POST[$field];
		
		if (!$finished) continue;

		if (!$_POST[$kpiName . 'CNCR']) continue;

		$body .= 'KPI: ' . $kpiName . "\r\n";
	}
	
	if ($body) {
		$finished = false;
		
		$subject = 'Raise CNCR';
		$body2 = 'Contract #: ' . $contractNumber . "\r\n";
		$body2 .= 'Contractor Name: ' . $contractorName . "\r\n";
		$body2 .= $body;
		$body = $body2;

		foreach ($emails as $emai) {
			mail($emai, $subject, $body);
		}
	}
	
	$evaluate = array();
	for ($i = 1; $i <= 10; $i++) {
		$evaluate[$i] = $_POST['evaluate' . $i];
	}
	
	// Code for files upload  // files_invoice
	


	$filename = $fileNameUploadMeetings ;
	$filenameDate = $fileNameUploadDate ;
	if(count($_FILES["item_file_meetings"]['name']) > 0) { //check if any file uploaded
			
			$GLOBALS['msg'] = ""; //initiate the global message fileNameUploadDate
			for($j=0; $j < count($_FILES["item_file_meetings"]['name']); $j++) { //loop the uploaded file array
				$filen = $_FILES["item_file_meetings"]['name']["$j"]; //file name
				if($filen!="")
				{
					$filenameDate[] = $_POST['meetingsDate'][$j];
					$uniqid = uniqid();
					$filename[] = $uniqid."_".$filen;
					$path = $sourceupload.$uniqid."_".$filen; 
						
					if(move_uploaded_file($_FILES["item_file_meetings"]['tmp_name']["$j"],$path)) { //upload the file
						$GLOBALS['msg'] .= "File# ".($j+1)." ($filen) uploaded successfully<br>"; //Success message
					}
				}
			}
		

		
	}

	$fileNameUploadMeetings = serialize($filename);
	$fileNameUploadDate = serialize($filenameDate);





	//print_r($_FILES["item_file"]);exit;
	$filenames = $fileNameUpload ;
	if(count($_FILES["item_file"]['name']) > 0) { //check if any file uploaded
			
			$GLOBALS['msg'] = ""; //initiate the global message
			for($j=0; $j < count($_FILES["item_file"]['name']); $j++) { //loop the uploaded file array
				$filen = $_FILES["item_file"]['name']["$j"]; //file name
				if($filen!="")
				{
					$uniqid = uniqid();
					$filenames[] = $uniqid."_".$filen;
					$path = $sourceupload.$uniqid."_".$filen; 

					if(move_uploaded_file($_FILES["item_file"]['tmp_name']["$j"],$path)) { //upload the file
						$GLOBALS['msg'] .= "File# ".($j+1)." ($filen) uploaded successfully<br>"; //Success message
					}
				}
			}
		

		
	}
	$filenameupload = serialize($filenames);





	$dbHand = DB::connect(_DB_TYPE);
	
	$sql = sprintf("SELECT * FROM %s.contract_review WHERE ID = '%s'", _DB_OBJ_FULL, $reviewID);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
	$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
	$exists = $resultSet;
	
	if (!$exists) {
		$sql = sprintf("INSERT INTO %s.contract_review (ID, contractID, f1f2,
			quarterCovered, yearCovered, reviewer, reviewDate, reviewEndDate,
			contractAnnualValue, disputedInvoices, disputedInvoicesComment,

			healthAndQuality, healthAndQualityCNCR, healthAndQualityComment,
			finance, financeCNCR, financeComment,
			contractReviewMeetings, complaints,
			amountPaidInCurrentFinancialYear, contractStillValid,
			evaluate1, evaluate2, evaluate3, evaluate4, evaluate5,
			evaluate6, evaluate7, evaluate8, evaluate9, evaluate10,

			productQuality, productQualityCNCR, productQualityComment,
			serviceQuality, serviceQualityCNCR, serviceQualityComment,
			onTimeDelivery, onTimeDeliveryCNCR, onTimeDeliveryComment,
			knowledge, knowledgeCNCR, knowledgeComment,
			reputation, reputationCNCR, reputationComment,
			customerFocus, customerFocusCNCR, customerFocusComment,
			customerService, customerServiceCNCR, customerServiceComment,
			responsiveness, responsivenessCNCR, responsivenessComment,notes, files_invoice , files_meeting , meeting_date,archive,score_average,approved,qtr_spend)
			VALUES ('%s', %d, %d,
				%d, %d, %d, '%s', '%s',
				%f, %d, '%s',

				%d, %d, '%s',
				%d, %d, '%s',
				'%s', '%s',
				%f, %d,
				'%s', '%s', '%s', '%s', '%s',
				'%s', '%s', '%s', '%s', '%s',

				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s',
				%d, %d, '%s','%s','%s','%s','%s','%d',%f,1,%f)",

				_DB_OBJ_FULL, $reviewID, $contractID, $f1f2,
				$quarterCovered, $yearCovered, $reviewer, $reviewDate, $reviewEndDate,
				$contractAnnualValue, $disputedInvoices, str_replace("'"."`",$disputedInvoicesComment),

				$kpis['healthAndQuality'], $kpis['healthAndQualityCNCR'], str_replace("'"."`",$kpis['healthAndQualityComment']),
				$kpis['finance'], $kpis['financeCNCR'], str_replace("'"."`",$kpis['financeComment']),
				str_replace("'"."`",$contractReviewMeetings), str_replace("'"."`",$complaints),
				$amountPaidInCurrentFinancialYear, $contractStillValid,
				str_replace("'"."`",$evaluate[1]), str_replace("'"."`",$evaluate[2]), str_replace("'"."`",$evaluate[3]), str_replace("'"."`",$evaluate[4]), str_replace("'"."`",$evaluate[5]),
				str_replace("'"."`",$evaluate[6]), str_replace("'"."`",$evaluate[7]), str_replace("'"."`",$evaluate[8]), str_replace("'"."`",$evaluate[9]), str_replace("'"."`",$evaluate[10]),

				$kpis['productQuality'], $kpis['productQualityCNCR'], str_replace("'"."`",$kpis['productQualityComment']),
				$kpis['serviceQuality'], $kpis['serviceQualityCNCR'], str_replace("'"."`",$kpis['serviceQualityComment']),
				$kpis['onTimeDelivery'], $kpis['onTimeDeliveryCNCR'], str_replace("'"."`",$kpis['onTimeDeliveryComment']),
				$kpis['knowledge'], $kpis['knowledgeCNCR'], str_replace("'"."`",$kpis['knowledgeComment']),
				$kpis['reputation'], $kpis['reputationCNCR'], str_replace("'"."`",$kpis['reputationComment']),
				$kpis['customerFocus'], $kpis['customerFocusCNCR'], str_replace("'"."`",$kpis['customerFocusComment']),
				$kpis['customerService'], $kpis['customerServiceCNCR'], str_replace("'"."`",$kpis['customerServiceComment']),
				$kpis['responsiveness'], $kpis['responsivenessCNCR'], str_replace("'"."`",$kpis['responsivenessComment']),str_replace("'"."`",$_POST['notes']),
				str_replace("'"."`",$filenameupload),str_replace("'"."`",$fileNameUploadMeetings),str_replace("'"."`",$fileNameUploadDate),'0',$score_average,$qtr_spend);
	} else {
		$sql = sprintf("UPDATE %s.contract_review SET ID = '%s', contractID = %d, f1f2 = %d,
			quarterCovered = %d, yearCovered = %d, reviewer = %d, reviewDate = '%s', reviewEndDate = '%s',
			contractAnnualValue = %f, disputedInvoices = %d, disputedInvoicesComment = '%s',

			healthAndQuality = %d, healthAndQualityCNCR = %d, healthAndQualityComment = '%s',
			finance = %d, financeCNCR = %d, financeComment = '%s',
			contractReviewMeetings = '%s', complaints = '%s',
			amountPaidInCurrentFinancialYear = %f, contractStillValid = %d,
			evaluate1 = '%s', evaluate2 = '%s', evaluate3 = '%s', evaluate4 = '%s', evaluate5 = '%s',
			evaluate6 = '%s', evaluate7 = '%s', evaluate8 = '%s', evaluate9 = '%s', evaluate10 = '%s',

			productQuality = %d, productQualityCNCR = %d, productQualityComment = '%s',
			serviceQuality = %d, serviceQualityCNCR = %d, serviceQualityComment = '%s',
			onTimeDelivery = %d, onTimeDeliveryCNCR = %d, onTimeDeliveryComment = '%s',
			knowledge = %d, knowledgeCNCR = %d, knowledgeComment = '%s',
			reputation = %d, reputationCNCR = %d, reputationComment = '%s',
			customerFocus = %d, customerFocusCNCR = %d, customerFocusComment = '%s',
			customerService = %d, customerServiceCNCR = %d, customerServiceComment = '%s',
			responsiveness = %d, responsivenessCNCR = %d, responsivenessComment = '%s', notes = '%s'
			, files_invoice = '%s' , files_meeting = '%s', meeting_date = '%s', score_average = %f, qtr_spend = %f
			WHERE ID = '%s'",

				_DB_OBJ_FULL, $reviewID, $contractID, $f1f2,
				$quarterCovered, $yearCovered, $reviewer, $reviewDate, $reviewEndDate,
				$contractAnnualValue, $disputedInvoices, $disputedInvoicesComment,

				$kpis['healthAndQuality'], $kpis['healthAndQualityCNCR'], $kpis['healthAndQualityComment'],
				$kpis['finance'], $kpis['financeCNCR'], $kpis['financeComment'],
				$contractReviewMeetings, $complaints,
				$amountPaidInCurrentFinancialYear, $contractStillValid,
				$evaluate[1], $evaluate[2], $evaluate[3], $evaluate[4], $evaluate[5],
				$evaluate[6], $evaluate[7], $evaluate[8], $evaluate[9], $evaluate[10],

				$kpis['productQuality'], $kpis['productQualityCNCR'], $kpis['productQualityComment'],
				$kpis['serviceQuality'], $kpis['serviceQualityCNCR'], $kpis['serviceQualityComment'],
				$kpis['onTimeDelivery'], $kpis['onTimeDeliveryCNCR'], $kpis['onTimeDeliveryComment'],
				$kpis['knowledge'], $kpis['knowledgeCNCR'], $kpis['knowledgeComment'],
				$kpis['reputation'], $kpis['reputationCNCR'], $kpis['reputationComment'],
				$kpis['customerFocus'], $kpis['customerFocusCNCR'], $kpis['customerFocusComment'],
				$kpis['customerService'], $kpis['customerServiceCNCR'], $kpis['customerServiceComment'],
				$kpis['responsiveness'], $kpis['responsivenessCNCR'], $kpis['responsivenessComment'],$_POST['notes'],
				$filenameupload,$fileNameUploadMeetings,$fileNameUploadDate,$score_average,$qtr_spend,
				$reviewID);
	}


	
	$reject = $_POST['reject'];
	if ($reject) {
		$columnName = '';
		if (!$existingReview['cmApproved']) {
			$columnName = 'cm';
		}
		else if (!$existingReview['maApproved']) {
			$columnName = 'ma';
		}
		else if (!$existingReview['daApproved']) {
			$columnName = 'da';
		}
		$columnName .= 'Rejected';
		
			$dbHand = DB::connect(_DB_TYPE);
		$sql = sprintf("UPDATE %s.contract_review SET " . $columnName . " = 1, notes ='%s' WHERE ID = '%s'", _DB_OBJ_FULL,$_POST['notes'], $existingContractReviewID);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
 

//Rejected mail send to CM Start

$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$ca);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$contractManager = $resultSet['forename'] . ' ' . $resultSet['surname'];
		$contractAddress = $resultSet['emailAddress'];

$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$ma);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$managerApprover = $resultSet['forename'] . ' ' . $resultSet['surname'];
		$manageremailAddress = $resultSet['emailAddress'];

						
						$mail_address=$contractAddress;
						$name = $contractManager;
						$YYYYYY = $contractManager;
						$FromName = $managerApprover;
						
					//	if($_SESSION['SMARTISO_SESS_USER_REC_ID']==$da)
						if($USER_ID==$da)
						{
							$FromName = $directorApprover;
	
						}
						//else if($_SESSION['SMARTISO_SESS_USER_REC_ID']==$ma)		
						else if($USER_ID==$ma)					
						{
							$FromName = $managerApprover;
						}
						
						
						//$mail_address="sumerpal@gmail.com";
						$salutation = trim($partcipantData['gender']) == 'F' ? 'Ms' : 'Mr.' ;
						$email_data['user_name']=$name;
						$email_data['YYYYYY']=$FromName;
						$email_data['ContractNo']=$contractNo;
						$email_data['ContractorName']=$contractorName  ;
						$email_data['Reviews']="Detailed review ";
						$email_data['ContractTital']=$ContractTitle;
						$email_data['Reviewer']=$YYYYYY;
						$email_data['URL']=$_SERVER['HTTP_REFERER'];
						$email_data['Notes']=$_POST['notes'];
						$email_data['Reject']='1';

						//print $mail_address."<pre>";print_r($email_data);exit;
						//$_SESSION['SMARTISO_SESS_USER_REC_ID']!=$da;

						$objEmail = new Email('html');
						if ( $mail_address!= '')
						 {
							try {
							$objEmail->addRecipient($name,$mail_address,$salutation);
							
							$objEmail->generateEmail('REVIEWREJECT',$email_data);

							$objEmail->send(true);
							} catch (ErrorException $e) {

								$e->getMessage();
							}
						}




//Rejected mail send to CM End 
		
		redirection("index.php");
	}
	
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
		$contractorObj->writecontractlog($sql,4);
if (!$exists)
		$reviewID= (int)customLastInsertId($dbHand,'contract_review','review_ID');
else
	       $reviewID=(int)$exists["review_ID"];
$existingContractReviewID = $reviewID;


	$action_count = $_POST['list_count'];
	for ( $i=1; $i<=$action_count; $i++ ) {

		$subsection			= $i;
		$review_id			= $reviewID;
		$record_id			= $_POST['review_id_'.$i];
		$action_id			= $_POST['action_id_'.$i];
		$action_check		= $_POST['action_check_'.$i];
		$action				= $_POST['action_'.$i];
		$problem				= $_POST['problem_'.$i];
		$assigned			= $_POST['assigned_'.$i.'_hidden'];
		$au					= $_POST['au_'.$i.'_hidden'];
		$when				= $_POST['when_'.$i];
		$score				= $_POST['score_'.$i];




		$data = array('review_id'=>$review_id,'record_id'=>$record_id,'action_id'=>$action_id,'section_id'=>2,'question_id'=>$i,'action_check'=>$action_check,'problem'=>$problem,'action'=>$action,'who'=>$assigned,'whoAU'=>$au,'when'=>$when,'score'=>$score,'cncr'=>$action_check);


				$contractorObj->setContractInfo($record_id,1,$data);
				$contractorObj->addReviewActions();

		
	}


	$approval = $_POST['approval'];
	if ($finished || $approval) {

		$dateComplete = date('Y-m-d');
		//$objAlert = new SendActionAlerts('contractReviewF1',$review_id);
		//$objAlert->sendAlerts();

		$columnName = '';
		if (!$existingReview['cmApproved']) {
			$columnName = 'cm';
		}
		else if (!$existingReview['maApproved']) {
			$columnName = 'ma';
		}
		else if (!$existingReview['daApproved']) {
			$columnName = 'da';
		}
		$columnName .= ($finished ? 'Finished' : ($approval ? 'Approved' : ''));
		


	//	if($_SESSION['SMARTISO_SESS_USER_REC_ID']==$da)
		if($USER_ID==$da)
		{
			$setvar = ", reviewCompleteDate='".$dateComplete."'";
		}

		$dbHand = DB::connect(_DB_TYPE);
		$sql = sprintf("UPDATE %s.contract_review SET " . $columnName . " = 1 ".$setvar." WHERE review_id = '%s'", _DB_OBJ_FULL, $existingContractReviewID);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
	
	$contractorObj->writecontractlog($sql,5);

	
		
		$subject = 'Contract Review Submitted for your Approval';
		$body = 'Review #: ' . $reviewID . "\r\n";
		$body .= "Type of Review: Detailed\r\n";
		$body .= 'Contract #: ' . $resultSetX['reference'] . "\r\n";
		$body .= 'Goods/Service Contract Provision: ' . $resultSetY['contractName'] . "\r\n";
		$body .= 'Contractor Name: ' . $contractorName . "\r\n";
		$body .= 'Reviewer: ' . $_SESSION['SMARTISO_SESS_FULLNAME'] . "\r\n";
		$body .= "\r\n";
		$body .= trim($_SESSION['SMARTISO_SESS_FULLNAME']) . ' has completed their review of the subject contract and has submitted the review for your approval.' . "\r\n";
		$body .= "\r\n";
		$body .= 'Link: ' . _MYSERVER. '/contracts/revf' . $f1f2 . '.php?id=' . $cid;

		$dbHand = DB::connect(_DB_TYPE);
		$sql = sprintf("UPDATE %s.contract_review SET approved = '1' , notes ='%s'  WHERE review_ID = '%s'", _DB_OBJ_FULL,$_POST['notes'], $existingContractReviewID);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$contractorObj->writecontractlog($sql,6);
		$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$ca);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$contractManager = $resultSet['forename'] . ' ' . $resultSet['surname'];
		$contractAddress = $resultSet['emailAddress'];

		$sql = sprintf("SELECT * FROM %s.participant_database WHERE participantID = %d",_DB_OBJ_FULL,$ma);
		$pStatement = $dbHand->prepare($sql);
		$pStatement->execute();
		$resultSet = $pStatement->fetch(PDO::FETCH_ASSOC);
		$managerApprover = $resultSet['forename'] . ' ' . $resultSet['surname'];
		$manageremailAddress = $resultSet['emailAddress'];

		//$manageremailAddress = $resultSet['emailAddress'];
					/*
						Mail feature Start 
					*/
						$name=$directorApprover;
						$mail_address=$manageremailAddress;
							$name = $managerApprover;
							$ZZZZZZ = "Manager Approver";
							$YYYYYY = $contractManager;
						//print $_SESSION['SMARTISO_SESS_USER_REC_ID']."====".$ca."====".$ma."====".$da;
//						if($_SESSION['SMARTISO_SESS_USER_REC_ID']==$ca)
						if($USER_ID==$ca)
						{
							$mail_address=$manageremailAddress;
							$name = $managerApprover;
							$ZZZZZZ = "Manager Approver";
							$YYYYYY = $contractManager;
	
						}
						//else if($_SESSION['SMARTISO_SESS_USER_REC_ID']==$ma)	
						else if($USER_ID==$ma)					
						{
							$mail_address=$directoremailAddress;
							$name = $directorApprover;
							$YYYYYY = $managerApprover;
							$ZZZZZZ = "Director Approver";
						}

						//$mail_address="sumerpal@gmail.com";
						$salutation = trim($partcipantData['gender']) == 'F' ? 'Ms' : 'Mr.' ;
						$email_data['Subject'] = 'Contract Review Submitted for your Approval';
						$email_data['user_name']=$name;
						$email_data['YYYYYY']=$YYYYYY;
						$email_data['ZZZZZZ']=$ZZZZZZ;
						$email_data['ContractNo']=$contractNo;
						$email_data['ContractorName']=$contractorName;
						$email_data['Reviews']="Detailed review ";
						$email_data['ContractTitle']=$ContractTitle;
						$email_data['Reviewer']=$YYYYYY;
						
						
						$url=str_replace('contracts','reviews',$_SERVER['HTTP_REFERER']);
						$url.="&reviewid=".$review_id;
						$email_data['URL']=$url;
						$email_data['who']=$ma;
						$email_data['summary']='<BR>This review has been completed by '.$YYYYYY.'. It has been submitted for your approval as <B>Manager Approver<B>' ;

						$contractorObj->sendEmail(0,$email_data);
						
						
						
						//$email_data['URL']=$_SERVER['HTTP_REFERER'];
						// print $mail_address."<pre>";print_r($email_data);exit;
						// print "<pre>";print_r($email_data);exit;$_SESSION['SMARTISO_SESS_USER_REC_ID']!=$da
/*
						$objEmail = new Email('html');
						if ( $mail_address!= '')
						 {
							try {
							$objEmail->addRecipient($name,$mail_address,$salutation);
							
							$objEmail->generateEmail('REVIEWFIRST',$email_data);

							$objEmail->send(true);
							} catch (ErrorException $e) {

								$e->getMessage();
							}
						}
*/
					/*
						Mail feature End
					*/



		
	}
	if($_POST['checkvalue']=="fileupload")
	{
		redirection("/contracts/revf2.php?id=".$_GET['id']);
	}

	redirection("index.php");

}
	$sql = sprintf("SELECT * FROM %s.contract_review_date WHERE quarter = ".$quarterCovered." ORDER BY quarter",_DB_OBJ_FULL);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();
	$resultSeta = $pStatement->fetch(PDO::FETCH_ASSOC);
	
	$contractor_add['reviewStartDate']=$resultSeta['month']."/".$resultSeta['day']."/".date('Y');

	$contractor_add['reviewDueDate'] =  $contractor_add['reviewStartDate'];

if (!$existingReview['ID']) 
{
	$uniqueObj = new UniqueReference();
	$resultSet['reviewID'] = $uniqueObj->getUniqueNumber('REVIEW');
}
 
          
$smarty->assign('contract', $resultSet);
$smarty->assign('quarters',$qtrarray);	
$smarty->assign('contractor_add', $contractor_add);
$smarty->display($CURRENT_MODULE."/revf2.tpl");

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
