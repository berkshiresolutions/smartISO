<?php
 /**
  $Id: delete_restore_record.php,v 3.28 Tuesday, December 14, 2010 12:34:47 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * This file is used to delete records for Incidence Details
  *
  * Long description
  * Long description
  *
  * @author  Anil
  * @package Smartiso
  * @subpackage Contractor
  * @since  Monday, November 15, 2010 03:51:09 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$moduleObj		=  new Contract();
$record_id      = (int) $_GET['rec_id'];


$archive_flag = 1;

if ( isset($_GET['restore']) ) {
	$archive_flag = 0;
}


if ( $record_id ) {

	if ( isset($_GET['purge_record']) ) {

		try {
			
				$moduleObj->setContractInfo($record_id,1,"");
				$moduleObj->purgeContract();
			} catch ( ErrorException $e ) {
				echo $e->getMessage();
			}


	} else {

		try {
			
				$moduleObj->setContractInfo($record_id,1,array('archive'=>$archive_flag));
				$moduleObj->archiveContract();
			} catch ( ErrorException $e ) {
				echo $e->getMessage();
			}

	}

}

?>
