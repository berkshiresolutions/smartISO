<?php
 /**
  $Id: reportR1.php,v 3.08 Sunday, January 30, 2011 10:50:01 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage DSE
  * @since  Monday, November 22, 2010 1:27:24 PM>
  */

$LAST_BREAD_CRUM = "Report R1";

$_PAGE_VALIDATION_SCRIPT = 'contract/report.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$record_id	= (int) $_GET['id'];


$repObj = new Report('html');
$repObj->setFilters(array('id'=>$record_id,'type'=>'R1','heading'=>true));
$repObj->generateReport('CONTRACTR1');

$repObj->displayReport();

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
