<?php
 /**
  $Id: contractor_maintenance.php,v 3.54 Tuesday, November 02, 2010 12:24:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the maintenance section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Friday, October 08, 2010 3:46:03 PM>
  */

$class_maintenance = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Maintenance"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,8,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	$data_array['contractor_id'] 						= $_POST['cid'];
	$data_array['electrical'] 							= $_POST['radio_electrical_equipments'];
	$data_array['access_equipments'] 					= $_POST['radio_access_equipments'];
	$data_array['pneumatic'] 							= $_POST['radio_pneumatic_equipments'];
	$data_array['gas_monitors'] 						= $_POST['radio_gas_monitors'];
	$data_array['hydraulic'] 							= $_POST['radio_hydraulic_equipments'];
	$data_array['special_equipments'] 					= $_POST['radio_test_equipments'];
	$data_array['electric_equipments'] 					= $_POST['radio_testing_electric_equipments'];
	$data_array['work_equipment'] 						= $_POST['radio_work_equipment_guidance'];
	$data_array['employees_accident'] 					= $_POST['employees_no_of_accidents'];
	$data_array['employees_fatality'] 					= $_POST['employees_fatality'];
	$data_array['employees_major'] 						= $_POST['employees_major'];
	$data_array['employees_lost_time'] 					= $_POST['employees_lost_time'];
	$data_array['persons_accident'] 					= $_POST['others_no_of_accidents'];
	$data_array['persons_fatality'] 					= $_POST['others_fatality'];
	$data_array['persons_major'] 						= $_POST['others_major'];
	$data_array['persons_lost_time'] 					= $_POST['others_lost_time'];
	$data_array['reporting_accidents'] 					= $_POST['radio_statutory_requirements'];
	$data_array['prosecuted_connection'] 				= $_POST['radio_prosecuted_health_safety'];
	$data_array['prohibition_otice'] 					= $_POST['radio_prohibition_notice'];
	$data_array['improvement_notice'] 					= $_POST['radio_improvement_notice'];

	$reason['electrical_equip_reason'] 					= $_POST['electrical_equipments_upload_reason'];
	$reason['pneumatic_reason'] 						= $_POST['pneumatic_equipments_upload_reason'];
	$reason['hydraulic_reason'] 						= $_POST['hydraulic_equipments_upload_reason'];
	$reason['access_reason'] 							= $_POST['access_equipments_upload_reason'];
	$reason['gas_reason'] 								= $_POST['gas_monitors_upload_reason'];
	$reason['test_reason'] 								= $_POST['test_equipments_upload_reason'];

	$section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,8,$data_array);
		$contractorObj->editContractor();

	} else {
		//do insert
		$contractorObj->setContractorInfo(0,8,$data_array);
		$contractorObj->addContractor();
		if ( count($reason) ) {
			$contractorObj->deleteContractorReason();
			foreach($reason as $key=>$value) {
				$reason_data_array = array('identifier'=>$key,'reason'=>$value);
				$contractorObj->setContractorInfo($record_id,8,$reason_data_array);
				$contractorObj->addContractorReason();
			}
		}

	}
	redirection("contractor_insurance.php?cid=".$record_id);
}

/* Current contractor record id */
$smarty->assign('cid', $cid);

$data = $contractorObj->viewContractor();

$contractorObj->setContractorInfo($cid,8,'');

$data_reason	=	$contractorObj->getContractorReason();

if ( count($data_reason) ) {

	foreach($data_reason as $key=>$value) {
		$reason_array[$value['subSection']] = $value['reason'];
	}

}

if($action == 'edit') {

	$edit_data['section_record_id'] 							= $data['ID'];
	$edit_data['radio_electrical_equipments'] 					= $data['electrical'];
	$edit_data['radio_access_equipments'] 						= $data['accessEquipments'];
	$edit_data['radio_pneumatic_equipments'] 					= $data['pneumatic'];
	$edit_data['radio_gas_monitors'] 							= $data['gasMonitors'];
	$edit_data['radio_hydraulic_equipments'] 					= $data['hydraulic'];
	$edit_data['radio_test_equipments'] 						= $data['specialTestEquipments'];
	$edit_data['radio_testing_electric_equipments'] 			= $data['electricEquipments'];
	$edit_data['radio_work_equipment_guidance'] 				= $data['workEquipment'];
	$edit_data['employees_no_of_accidents'] 					= smartisoStripslashes($data['employeesNoAccident']);
	$edit_data['employees_fatality'] 							= smartisoStripslashes($data['employeesFatality']);
	$edit_data['employees_major'] 								= smartisoStripslashes($data['employeesMajor']);
	$edit_data['employees_lost_time'] 							= smartisoStripslashes($data['employeesLostTime']);
	$edit_data['others_no_of_accidents'] 						= smartisoStripslashes($data['personsNoAccident']);
	$edit_data['others_fatality'] 								= smartisoStripslashes($data['personsFatality']);
	$edit_data['others_major'] 									= smartisoStripslashes($data['personsMajor']);
	$edit_data['others_lost_time'] 								= smartisoStripslashes($data['personsLostTime']);
	$edit_data['radio_statutory_requirements'] 					= $data['reportingAccidents'];
	$edit_data['radio_prosecuted_health_safety'] 				= $data['prosecutedConnection'];
	$edit_data['radio_prohibition_notice'] 						= $data['prohibitionNotice'];
	$edit_data['radio_improvement_notice'] 						= $data['improvementNotice'];

	$edit_reason['electrical_equip_rea'] 						= $reason_array['electrical_equip_rea'];
	$edit_reason['pneumatic_reason'] 							= $reason_array['pneumatic_reason'];
	$edit_reason['hydraulic_reason'] 							= $reason_array['hydraulic_reason'];
	$edit_reason['access_reason'] 								= $reason_array['access_reason'];
	$edit_reason['test_reason'] 								= $reason_array['test_reason'];
	$edit_reason['gas_reason'] 									= $reason_array['gas_reason'];

	$smarty->assign('edit_data', $edit_data);
	$smarty->assign('edit_reason', $edit_reason);
} else {

	$employees['no_of_accidents']            = "";
	$employees['fatality']                   = "";
	$employees['major']                      = "";
	$employees['lost_time']                  = "";

	$others_persons['no_of_accidents']       = "";
	$others_persons['fatality']              = "";
	$others_persons['major']                 = "";
	$others_persons['lost_time']             = "";

	$radio_electrical_equipments             = "";
	$radio_pneumatic_equipments              = "";
	$radio_hydraulic_equipments              = "";
	$radio_access_equipments                 = "";
	$radio_gas_monitors                      = "";
	$radio_test_equipments                   = "";
	$radio_testing_electric_equipments       = "";
	$radio_work_equipment_guidance           = "";
	$radio_statutory_requirements            = "";
	$radio_prosecuted_health_safety          = "";
	$radio_prohibition_notice                = "";
	$radio_improvement_notice                = "";

}

$smarty->assign('cid', $cid);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

$smarty->display($CURRENT_MODULE.'/contractor_maintenance.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>