<?php
 /**
  $Id: upload_reason.php,v 3.15 Tuesday, November 02, 2010 12:14:31 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Wednesday, September 08, 2010 10:44:01 AM>
  */

	$_HIDE_HTTP_HEADER = true;
	$_SHOW_GUEST_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$objFile = new Upload();
$contractorObj = new Contractor();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
	//dump_array($_FILES);
	//dump_array($_POST);
	//exit;

	$cid = $_POST['cid'];
	$section_identifier = $_POST['identifier'];
	$tab = $_POST['tab'];

	$_FILES['upload_document']['destination'] = 'contractor';

	$objFile->setFileInfo('contractor',$_FILES['upload_document']);
	$objFile->add_file();
	$file_id = $objFile->getLastFileId();
	if ($file_id ) {

		$data_array = array('tab'=>$tab, 'identifier'=>$section_identifier,'file_ids'=>$file_id);

		$contractorObj->setContractorInfo($cid,1,$data_array);
		$contractorObj->addContractorFiles();

	}

}

$cid = $_GET['record_id'];
$section_identifier = $_GET['section'];
$tab = $_GET['tab'];

$smarty->assign('cid',$cid);
$smarty->assign('identifier',$section_identifier);
$smarty->assign('tab',$tab);

$smarty->display('upload_document.tpl');
?>