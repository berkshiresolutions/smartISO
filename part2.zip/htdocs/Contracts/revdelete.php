<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$ID = $_REQUEST['id'];
$flag = $_REQUEST['flag'];
$filename = $_REQUEST['filename'];

$dbHand = DB::connect(_DB_TYPE);
$sql = sprintf("SELECT * FROM %s.contract_review WHERE ID = '%s' ",_DB_OBJ_FULL,$ID);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$existingReview = $pStatement->fetch(PDO::FETCH_ASSOC);

// print "<pre>"; print_r($existingReview);


if($existingReview['files_invoice']!="" && $flag =="invoice")
{
	$fileNameUpload	= unserialize($existingReview['files_invoice']);
	//print "<pre>"; print_r($fileNameUpload);
	$fileNameUploadnew = array();
	foreach($fileNameUpload as $key => $value)
	{
		if($value==$filename)
		{
			continue;
		}
		$fileNameUploadnew[]=$value;
	}

	//print_r($fileNameUploadnew);
	$fileNameUpload	= serialize($fileNameUploadnew);
	$sql = sprintf("UPDATE %s.contract_review SET files_invoice ='%s' WHERE ID = '%s'", _DB_OBJ_FULL,$fileNameUpload, $ID);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();

}


if($existingReview['files_meeting']!="" && $flag =="meetings")
{
	$fileNameUpload	= unserialize($existingReview['files_meeting']);
	$meeting_date	= unserialize($existingReview['meeting_date']);
	//print "<pre>"; print_r($fileNameUpload);
	$fileNameUploadnew = array();
	$meeting_datenew = array();
	foreach($fileNameUpload as $key => $value)
	{
		if($value==$filename)
		{
			continue;
		}
		$fileNameUploadnew[]=$value;
		$meeting_datenew[]=$meeting_date[$key];
	}

	//print_r($fileNameUploadnew);
	$fileNameUpload	= serialize($fileNameUploadnew);
	$meeting_date	= serialize($meeting_datenew);
	$sql = sprintf("UPDATE %s.contract_review SET files_meeting ='%s',meeting_date ='%s' WHERE ID = '%s'", _DB_OBJ_FULL,$fileNameUpload,$meeting_date,$ID);
	$pStatement = $dbHand->prepare($sql);
	$pStatement->execute();

}




redirection($_SERVER['HTTP_REFERER']);

?>
