<?php
 /**
  $Id: contractor_management.php,v 4.03 Saturday, December 04, 2010 2:53:31 PM ehsindia Exp $
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the management section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractor
  * @since  Wednesday, October 06, 2010 6:39:34 PM>
  */

$class_management = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Evaluation"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/add_edit_contractor_eval.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$cid = (int) $_GET['id'];
$contractorObj = new Contractor();
$contractorObjEval = new ContractorEval();
$contractorObj->setContractorInfo($cid,1,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {


$data_array['contractorid'] 			= $_POST['cid'];
$data_array['whoID'] 					= $_POST['who_reported'];
$data_array['dateAdded'] 				= $_POST['when_reported'];
$data_array['task'] 					= $_POST['task_details'];
$data_array['rating'] 					= $_POST['radio_level_state'];

$email_array['company'] 			= $_POST['company_hidden'];
$email_array['task'] 					= $data_array['task'] ;
$email_array['rating'] 					= $data_array['rating'];
$email_array['company_manager'] 			= $_POST['company_manager_hidden'];
$problems 				= $_POST['problems'];
$suggested_action 		= $_POST['suggested_action'];


	//do insert
		$contractorObjEval->setContractorEvalInfo(0,$data_array);
		$contractorObjEval->addContractorEval();




		$counter=count($problems);
		
		
	if ($problems[0] !="")	
	{
		for($x=0;$x<$counter;$x++)
		{
		$data_array		 =	array('problems'=>smartisoAddslashes($problems[$x]),'suggested_action'=>smartisoAddslashes($suggested_action[$x]));
		$y=$x+1;
		$email_array['data'].="Problem ".$y."<BR><BR>".smartisoAddslashes($problems[$x])."<BR>Suggested Action<BR><BR>".smartisoAddslashes($suggested_action[$x]) ."<BR><BR><BR>";	
		
		$contractorObjEval->setContractorEvalInfo(0,$data_array);
		$contractorObjEval->addContractorEvalProblems();
		}
		}


 if ( $data_array['rating'] <3 ) {


            $emailObj = new Email('html');
            $partObj = SetupGeneric::useModule('Participant');



                $partObj->setItemInfo(array('id'=>$email_array['company_manager']  ));
                $specific_au_data = $partObj->displayItemById();

                if ( $specific_au_data['gender'] == 'f' ) {
                    $salutation = 'Ms.';
                } else {
                    $salutation = 'Mr.';
                }

            $fullname = ucwords($specific_au_data['forename'].' '.$specific_au_data['surname']);
            $emailObj->addRecipient($fullname,$specific_au_data['emailAddress'],$salutation);
//$emailObj->addRecipient($fullname,'suziabery@tiscali.co.uk',$salutation);

            $emailObj->generateEmail('CONTRACTOR_EVALUATION_REP_AU_ALERT',$email_array);
            $emailObj->send(_LIVE_MODE);

}

	redirection("index.php");

}
		$suggested_action[]="";
		$problems[]="";
		$suggested_action_id[]=1;


/* Current contractor record id */

$smarty->assign('cid', $cid);
$data = $contractorObj->viewContractor();

$contractor_add['company_name']	= smartisoStripslashes($data['companyName']);
$contractor_add['manager']=$data['whoID'];
$smarty->assign('problems', $problems);
$smarty->assign('suggested_action', $suggested_action);
$smarty->assign('suggested_action_id', $suggested_action_id);


$smarty->assign('contractor_add', $contractor_add);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

$smarty->display($CURRENT_MODULE."/contractor_evaluation.tpl");

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>