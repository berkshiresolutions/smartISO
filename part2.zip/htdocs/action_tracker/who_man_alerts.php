<?php
 /**
  $Id: replace_document.php,v 3.74 Thursday, January 20, 2011 4:14:14 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/who_man_alerts.js';
$_PAGE_VALIDATION_SCRIPT2 = 'common_script.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';

//echo	$document_id = (int) $_GET['document_id'];
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

$action_id 	= (int) $_POST['alert_id'];
$date   	= strip_tags($_POST['done_date']);
$who_id 	= (int) $_POST['who_hidden'];
$whoAU 	= (int) $_POST['whoAU_hidden'];
$route      	= (int) $_POST['route'];
$comment 	=  $_POST['reason_replace'];
$action = strip_tags($_POST['action']);
$action_str = strip_tags($_POST['action_str']);
$atObj 		= new ActionTracker();

$actObj 		= new Action();
$actObj->updatehistory($action_id);

switch ($route){
    case 1: $atObj->approveAlert($action_id,$date,$comment,$module);break;
    case 2: $atObj->updateReject($action_id,$date,$comment,$action,$action_str);break;
    case 3: $atObj->updateApp2($action_id, $date, $comment, $whoAU, $action, $action_str);break;
    case 4: $atObj->updateReassigned($action_id,$date,$comment,$who_id,$action,$action_str);break;
}


	

//exit();
	$smarty->assign('js',1);
	$smarty->assign('e',2);

} else {

	$alert_id 	= (int) $_GET['alert_id'];
        $alert_type 	= explode("|", $_GET['act_type']);
        
	$smarty->assign('alert_id',$alert_id);
        $smarty->assign('action',$alert_type[0]);
        $smarty->assign('action_str',$alert_type[1]);

}

$smarty->display('action_tracker/who_man_alerts.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';