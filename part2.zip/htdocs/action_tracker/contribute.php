<?php
 /**
  $Id: contribute.php,v 3.42 Thursday, January 20, 2011 6:07:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Contributor
  * @since  Saturday, November 20, 2010 8:07:01 PM>
  */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/contributor.js';

$doc_id 	= isset($_GET['doc_id']) ==true ? (int) $_GET['doc_id'] : 0;
$contid 	= isset($_GET['contid']) ==true ? (int) $_GET['contid'] : 0;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$docObj = new Documents();
        $objFile = new Upload();
	$participantObj = SetupGeneric::useModule('Participant');

	$document_info 					= $docObj->getDocumentInformation($_POST['doID']);


	$conObj								= new DocumentContributor();
 
	$contributor['file_info'] 			= $_POST['file_reference'];;
	$contributor['contid'] 				= $_POST['contid'];
	$contributor['doID'] 				= $_POST['doID'];
	$contributor['comments'] 			= $_POST['comments'];
	$contributor['authorize'] 			= $_POST['authorize'];

	if ( empty($contributor['authorize']) ) {
		$contributor['authorize'] = 'N';
	}
	
        $participantObj->setItemInfo(array('id'=>getLoggedInUserId()));
                
	$condata = $participantObj->displayDoc();
        
	if ($contributor['authorize'] == 'N')
		$contmessage="Contributor ".ucwords($condata['forename'].' '.$condata['surname'])." has Not Approved";
	else
		$contmessage="Contributor ".ucwords($condata['forename'].' '.$condata['surname'])." has Approved";
		
	


    if ($_POST['filedata']) {
        $fileArr = $_POST['filedata'];
        $fileNameArr = $_POST['filename'];

 
        foreach($fileArr as $key=>$file) {
                $contributor["file_id"] = $objFile->moveNewFile($file, 'contributors', $fileNameArr[$key]);
                 
                $objFile->setFileInfo('contributors',array('id'=>$contributor["file_id"]));
		$file_details = $objFile->getFileDetails();

		$file = _PATH_PUB.'contributors/'.$file_details['sysFilename'];

		$attachment=array('name'=>$file_details['usrFilename'],'file'=>$file);

	}
    }

	$conObj->setContributorInfo($contributor['contid'],$contributor);
	$upld_file_id =$conObj->saveContributorReply();
	
	$message =$contmessage." the document." ;
	$docObj->saveDocumentLog($contributor['doID'],$message,$contributor['comments']);


 	$emailObj = new infoEmailHelper();
	$document = $docObj->getDocumentInformation($contributor['doID']);
  	

	$participantObj->setItemInfo(array('id'=>$document['docIssuer']));
	$data = $participantObj->displayDoc();


	
    $subject = "smart-ISO Contributor Response";
    
	$who = array(
				'displayname' => ucwords($data['forename'].' '.$data['surname']),
				'email' => $data['emailAddress']
		);
		
            $strL="";
    $strR="";
	$mergeData = array(
	'twoColData'=>array(
		'actionid'=>array('left'=>'<strong>File Reference:</strong>','right'=>$document['fileReference']),
            		'assignedto'=>array('left'=>$strL,'right'=>$strR),
		'authorizing1'=>array('left'=>'<strong>Document Name:</strong>','right'=>$document['title']),
		'description'=>array('left'=>'<strong>Document Description:</strong>','right'=>$document['description']),
		'contributor'=>array('left'=>'<strong>Contributor:</strong>','right'=>ucwords($condata['forename'].' '.$condata['surname']))
        ),
	'singleColData'=>array(
        'summary'=>'<p><strong>'.$contmessage.' the above stated document</strong></p><BR><p><strong>Reason</STRONG><BR>'.$contributor['comments']
		)
					);

                $emailObj->appendInfo($mergeData);

				
                $emailObj->sendEmail($subject,$who,array(),array(),'me_completed','','grey',$attachment);
				
      
	
	$d = $conObj->emailFire($contributor['doID']);
	

	if($d){
	//echo "yyyyyyyyyyy";
	$url = basename($_SERVER['PHP_SELF'])."?js=1&e=1";

	redirection($url);
	}else{
	
	//echo "sdfdsf";
	$participantObj = SetupGeneric::useModule('Participant');
	$participantObj->setItemInfo(array('id'=>$document['initiatedByParticipant']));
	
	$data = $participantObj->displayAlertDoc();
	
	$docObj = new Documents();
$document_info 					= $docObj->getDocumentInformation($_POST['doID']);


$participant_id = $document_info['docIssuer'];
	$participantObj->setItemInfo(array('id'=>$participant_id));
	
	$data = $participantObj->displayDoc();





		 $emailObj = new infoEmailHelper();
$document 					= $docObj->getDocumentInformation($contributor['doID']);
		 //dump_array($document);
		//foreach($data as $value){
		 // dump_array($value['emailAddress']);
		  $subject = "smart-ISO Document Available for Publishing Review";
$who = array(
				'displayname' => ucwords($data['forename'].' '.$data['surname']),
				'email' => $data['emailAddress']
		);

if ($_POST["alert"] == 1)	{	
    $alertID=$conObj->getAlert($contid);

	$url='doc_control_alert.php?id='.$alertID["alertID"].'&filter_date= ';
}
else
		$url='doc_control.php?id='.$_POST["contid"].'&filter_date= ';


    $strL="";
    $strR="";

$mergeData = array(
'twoColData'=>array(
'actionid'=>array('left'=>'<strong>File Reference:</strong>','right'=>$document['fileReference']),
    	'assignedto'=>array('left'=>$strL,'right'=>$strR),
			'authorizing1'=>array('left'=>'<strong>Document Name:</strong>','right'=>$document['title']),
			'description'=>array('left'=>'<strong>Document Description:</strong>','right'=>$document['description'])

 
                    ),
'singleColData'=>array(
                            'summary'=>'<p><strong>The above stated document has received contribution from all the contributors</strong></p>',
                            'url'=>'<P>Please <a href= "https://' . $_SERVER['HTTP_HOST'] .'/action_tracker/'.$url.' ">CLICK</a> Here to review contributors response.</p>')
					);

                $emailObj->appendInfo($mergeData);

				
                $emailObj->sendEmail($subject,$who,array(),array(),'me_completed','','grey');
                
			

		

	$url = basename($_SERVER['PHP_SELF'])."?js=1&e=1";

	redirection($url);
	
	
	}
	

} else {

	$js 				= (int) $_GET['js'];
	$e 					= (int) $_GET['e'];

	if ($js) {

		$smarty->assign('js',$js);
		$smarty->assign('e',$e);

	} else {

		$docObj					= new Documents();
		$document_information 	= $docObj->getDocumentInformation($doc_id);
		
		
		
		//dump_array($document_information);

	$conObj								= new DocumentContributor();
	//echo $contid;
	$document_duedate 	= $conObj->viewDueDate($contid);

		$participantObj = SetupGeneric::useModule('Participant');
	$participantObj->setItemInfo(array('id'=>$document_information['docIssuer']));
	
	$data = $participantObj->displayDoc();
	

		$smarty->assign('who',$data['forename']." ".$data['surname']);
		$smarty->assign('document_information',$document_information);
		$smarty->assign('contid',$contid);
		$smarty->assign('due',format_date($document_duedate['contribDueDate']));
		$smarty->assign('passe',$document_duedate['passed']);
		$smarty->assign('comment',$document_duedate['comments']);
		$smarty->assign('alert',(int)$document_duedate['alert']);
		$smarty->assign('doID',$document_duedate['cmsdocID']);
                $smarty->assign('reply',$document_duedate['reply']);
			$docObj					= new Documents();
		$document_in 	= $docObj->getDocumentInformation($document_duedate['cmsdocID']);
		
		
		$objFile = new Upload();
			$objFile->setFileInfo('contributors',array('id'=>$document_duedate['documentID']));
			$file_detail = $objFile->getFileDetails();
			
		//dump_array($file_detail);
		$smarty->assign('file_detail',$file_detail);
	}
        if($document_duedate['passed']==0)
            $smarty->display('action_tracker/contribute.tpl');
        else {
        	$smarty->display('action_tracker/contributeview.tpl');    
        }
        require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
}