<?php
/**
  $Id: equipment_csv.php,v 3.02 Saturday, May 19, 2018 6:34:04 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2011 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <gurnam_84@hotmail.com>
 * @package Smartiso
 * @subpackage Equipment
 * @since  Saturday, May 19, 2018 5:44:40 PM>
 */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];


/*

header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=document.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');
$fn = fopen('document_alerts.xls', 'w');

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];

$optObj = new Option();
$selected_grp = $optObj->getOption('_SU_GRP_POLICY');

$USER_ID = getLoggedInUserId();
$grp = $USER_ID == $selected_grp ? true : false;
$level = getUserAccessLevel();
$action_tracker_module_name = 'Documents';

if ($level == 1) {
    $is_admin = true;
}


$docObj = new Documents();


$scopeObj = SetupGeneric::useModule('DocScope');
$scopeArr = $scopeObj->displayItems();

$scope[0] = "&nbsp;-&nbsp;";
foreach ($scopeArr as $scope_ele) {

    $scope[$scope_ele["ID"]] = "[" . $scope_ele['scope'] . "]";
}

$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

$documents = $docObj->getDocAlerts();
$documentsCount = count($documents);
?>
<table cellspacing='0' cellpadding='0' width='100%' border='1'>

    <tr style='border: 1px solid;background: #360036;color: #fff;font-weight:bold;font-family:arial,sans-serif;'>

        <td >Reference</td>
        <td>Document</td>
        <td>Alert Comment</td>
        <td>Actions</td>      


    </tr>
<?php
if ($documentsCount) {


    foreach ($documents as $documentItem) {

        if (!$grp && $documentItem['documentSubType'] == "G")
            continue;
        $document_code_info = $docObj->getSectionByStandardAndCode('52', $documentItem['fileReference']);
        $rel = $documentItem['cmsdocID'];
        $section_ref = $document_information['fileReference'] . " " . $document_code_info['name'];

        if ($documentItem['documentSubType'] == "W")
            $document = '[WI]';
        elseif ($documentItem['documentSubType'] == "G")
            $document = '[GP]';
        else
            $document = '[' . $documentItem['documentType'] . ']';

        $document .= $scope[$documentItem['scope']] . '&nbsp;&nbsp;<a href="/documents/download.php?src=' . $documentItem['documentID'] . '&name=' . $documentItem['title'] . '">' . $documentItem['title'] . '</a> Ver <a href="javascript:void(0)" class="action view_version" rel=' . $rel . '>' . $documentItem['versionNew'];

        if ($version_type == 'minor_version')
            $document .="." . intval($documentItem['versionMinor']) . '</a>';
        else
            $document .='</a>';

        echo "<tr>";
        echo "<td title=" . $document_code_info['name'] . ">" . $documentItem['fileReference'] . "</td>";
        echo "<td>" . $document . "</td>";
        echo "<td>" . $documentItem['alertComment'] . "</td><td>";
        echo "<a href='javascript: void(0)' class='action reject' rel='" . $rel . "' rela='" . $documentItem['alertID'] . "'>Reject</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
        echo "<a href='javascript: void(0)' class='action no_change' rel='" . $rel . "' rela='" . $documentItem['alertID'] . "'>No change</a>&nbsp;&nbsp;|&nbsp;&nbsp;";

        $contributors = $docObj->getDocumentContributors($rel);
        $document_status = "";
        if ($contributors) {

            $contributor_replied_a = 0;
            $contributor_replied_na = 0;
            $contributor_replied = 0;
            $contributor_count = count($contributors);

            foreach ($contributors as $contributor) {
                switch ($contributor['passed']) {
                    case 1: $contributor_replied_a++;
                        $contributor_replied++;
                        break;
                    case 2: $contributor_replied_na++;
                        $contributor_replied++;
                        break;
                }
            }

            if ($contributor_replied == 0) {

                $document_status = "Wait for Contributors's response";
            } else if ($contributor_replied < $contributor_count) {

                $document_status = "Sent to contributors";
            } else if ($contributor_replied == $contributor_replied_a) {

                $document_status = "Approved by contributors";
                //   } else if ($contributor_replied == $contributor_replied_na) {
            } else {
                $document_status = "Not approved by contributors";
            }

            echo "<a href='javascript: void(0)' class='action contribute_doc' title='" . $document_status . "' rel='" . $rel . "' rela='" . $documentItem['alertID'] . "'>Contribution Status</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
        } else {
            echo "<a href='javascript: void(0)' class='action contribute_doc' rel='" . $rel . "' rela='" . $documentItem['alertID'] . "'>Send For Contribution</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
        }




        //echo "<a href='javascript: void(0)' class='action contribute_doc' rel='".$rel."'>Send For Contribution</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
        echo "<a href='javascript: void(0)' class='action change_doc' rel='" . $rel . "' rela='" . $documentItem['alertID'] . "'>Replace</a> &nbsp;&nbsp;";


        echo "</td></tr>";
    }
    
} 
?>
</table>
 <?php
    fclose($fn);
    
*/    
    

require_once dirname(__FILE__) . '/../php_excel/Classes/PHPExcel.php';
// Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
// Set document properties
    $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
    
    

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];

$optObj = new Option();
$selected_grp = $optObj->getOption('_SU_GRP_POLICY');

$USER_ID = getLoggedInUserId();
$grp = $USER_ID == $selected_grp ? true : false;
$level = getUserAccessLevel();
$action_tracker_module_name = 'Documents';

if ($level == 1) {
    $is_admin = true;
}

$docObj = new Documents();
$scopeObj = SetupGeneric::useModule('DocScope');
$scopeArr = $scopeObj->displayItems();
$scope[0] = "&nbsp;-&nbsp;";
foreach ($scopeArr as $scope_ele) {
    $scope[$scope_ele["ID"]] = "[" . $scope_ele['scope'] . "]";}

$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$data = $docObj->getDocAlerts();
$documentsCount = count($documents);





    
$headerStyle = array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '360036'),
            'border' => false,
        ),
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF'),
        )
    );
    $borderStyle = array('borders' =>
        array('outline' =>
            array('style' => PHPExcel_Style_Border::BORDER_THICK,
                'color' => array('argb' => '360036'),),),);

    $rowCount = 1;
    $customTitle = array('Nature of Injury ');

    
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, 'Reference')
            ->SetCellValue('B' . $rowCount, 'Document')
            ->SetCellValue('C' . $rowCount, 'Alert Comment')
            ->SetCellValue('D' . $rowCount, 'Actions');

    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($headerStyle);
    $borderColumn = (intval($column) - 1 );
    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($borderStyle);

    $i = 2;
    if ($data) {
        foreach ($data as $documentItem) {
            
            
       if (!$grp && $documentItem['documentSubType'] == "G")
            continue;
        $document_code_info = $docObj->getSectionByStandardAndCode('52', $documentItem['fileReference']);
        $rel = $documentItem['cmsdocID'];
        $section_ref = $document_information['fileReference'] . " " . $document_code_info['name'];

        if ($documentItem['documentSubType'] == "W")
            $document = '[WI]';
        elseif ($documentItem['documentSubType'] == "G")
            $document = '[GP]';
        else
            $document = '[' . $documentItem['documentType'] . '] ';

        $document .= $scope[$documentItem['scope']] . ''. $documentItem['title'] . '  Ver  ' . $documentItem['versionNew'];

        if ($version_type == 'minor_version')
            $document .= "." . intval($documentItem['versionMinor']) . '';
        else
            $document .= '';



        $contributors = $docObj->getDocumentContributors($rel);
        $document_status = "";
        if ($contributors) {

            $contributor_replied_a = 0;
            $contributor_replied_na = 0;
            $contributor_replied = 0;
            $contributor_count = count($contributors);

            foreach ($contributors as $contributor) {
                switch ($contributor['passed']) {
                    case 1: $contributor_replied_a++;
                        $contributor_replied++;
                        break;
                    case 2: $contributor_replied_na++;
                        $contributor_replied++;
                        break;
                }
            }

            if ($contributor_replied == 0) {

                $document_status = "Wait for Contributors's response";
            } else if ($contributor_replied < $contributor_count) {

                $document_status = "Sent to contributors";
            } else if ($contributor_replied == $contributor_replied_a) {

                $document_status = "Approved by contributors";
               
            } else {
                $document_status = "Not approved by contributors";
            }

            
        } else {
            $document_status="Send For Contribution";
        }

        $objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $documentItem['fileReference'])
                    ->setCellValue('B' . $i, $document)
                    ->setCellValue('C' . $i,  $documentItem['alertComment'])
                    ->setCellValue('D' . $i, $document_status);
              $i++;             
              
        }
    }
   

// Rename worksheet
    $objPHPExcel->getActiveSheet()->setTitle('Simple');
    $objPHPExcel->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="document_alerts.xls"');
    header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
    header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;    
    
    
    
    
    
    
    
    

//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
    ?>