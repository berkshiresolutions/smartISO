<?php
/**
 $Id: record_smart_law_assign_others_pending.php,v 3.13 Thursday, February 03, 2011 12:37:43 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Smart Law - Assigned to others(pending) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Saturday, September 25, 2010 12:04:59 PM>
*/

$is_admin = true;

$si				= "SI";
$type			= "Relevant";
$action			= "action";
$assigned_to	= "gurnam";
$when			= "June 26 2010";

echo "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='12%'>SI</th>
			<th width='13%'>Type</th>
			<th width='19%'>Action</th>
			<th width='13%'>Assigned to</th>
			<th width='13%'>When</th>
			<th width='20%'>Completed Date/Comment</th>";
			if ($is_admin) {
				echo "<th width='10%'>Approved</th>";
			}
		echo "</tr>
	</thead>

	<tbody>";
	for ($i=1;$i<=15;$i++) {
		echo "<tr>";
			echo "<td>".$si."</td>";
			echo "<td>".$type."</td>";
			echo "<td>".$action."</td>";
			echo "<td>".$assigned_to."</td>";
			echo "<td>".$when."</td>";
			echo "<td>
					<input type='text' name='done_date_{$i}' id='done_date_{$i}' size='20' class='datepicker' />
					<span><a href='javascript:void(0)'>Done</a></span>
				</td>";
			if ($is_admin) {
				echo "<td><input type='checkbox' name='approved_{$i}' id='approved_{$i}' value='{$i}' /></td>";
			}
		echo "</tr>";
	}
	echo "</tbody>

	<tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>";
			if ($is_admin) {
				echo "<td>&nbsp;</td>";
			}
		echo "</tr>
	</tfoot>
</table>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";

echo "<b>Note :</b> To view full action, click the corresponding box.";
?>