<?php
 /**
$Id: record_gap_filling.php,v 4.23 Saturday, January 29, 2011 6:09:59 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file gets data from database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Thursday, September 16, 2010 5:15:10 PM>
 */

$_HIDE_HTTP_HEADER = true;

$showtype 		= strip_tags($_GET['showtype']);

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$gapObj = new ReviewGap();

if ( $showtype == 'me_pending' ) {
	$result	= $gapObj->getGapQuestionActionTracker(true,0);
} elseif ( $showtype == 'other_completed' ) {
	$result	= $gapObj->getGapQuestionActionTracker(false,1);
} elseif ( $showtype == 'me_completed' ) {
	$result	= $gapObj->getGapQuestionActionTracker(true,1);
} else {
	$result	= $gapObj->getGapQuestionActionTracker(false,0);
}
$result_count = count($result);

$listdata = '';

$listdata .= "<table class='display' id='module_records'>";
$listdata .= "<thead><tr><th width='30%'>Document</th><th width='20%'>Business Unit</th><th width='20%'>Comment</th>";
$listdata .= "<th width='10%'>When</th>";

if ( $showtype == 'other_pending' ) {
	$listdata .= "<th width='10%'>Assigned to</th>";
}

$listdata .= "<th width='5%'>Action</th></tr>";
$listdata .= "</thead><tbody>";

	if ($result_count) {

		$orgObj = SetupGeneric::useModule('Organigram');
		$partObj = SetupGeneric::useModule('Participant');

		$jsdata = '';

		foreach ( $result as $resultEle ) {

			$partObj->setItemInfo(array('id'=>$resultEle['participantID']));
			$participant = $partObj->displayItemMaininfoById();
			$participant_name = ucwords($participant['forename'].' '.$participant['surname']);

			//$listdata .= "<tr><td>BU: ".$resultEle['buID']."</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";

			// get business unit information
			$orgObj->setItemInfo(array('id'=>$resultEle['buID']));
			$bu_info 		= $orgObj->displayItemById();

			switch ($resultEle['typeID']) {
				case 2: $document_type = 'Do'; break;
				case 4: $document_type = 'Pr'; break;
				case 3: $document_type = 'Ex'; break;
				case 1: $document_type = 'Fo'; break;
			}

			if ( $resultEle['whenDate'] != '' && $resultEle['whenDate'] != '1901-01-01' ) {
				$when_date = format_date($resultEle['whenDate']);
			} else {
				$when_date = '-';
			}

			$description = substr(ucfirst($resultEle['description']),0,50);
			$description_full = addslashes(ucfirst($resultEle['description']));

			$jsdata .= "$('.showdesc_".$resultEle['ID']."').smartLightBox({heading: 'Comment for [".$document_type."] ".$resultEle['displayName']."',writeMode : false,width: '500',   height: '200',description : '".$description_full."'});\n";

			$listdata .= "<tr>";
			$listdata .= "<td><a href='view_doc_gap_filling_listing.php?audit_id={$resultEle['reviewID']}&docid={$resultEle['ID']}'>[{$document_type}] ".$resultEle['displayName']."</a></td>";
			$listdata .= "<td>".$bu_info['buName']."</td>";
			$listdata .= "<td><a class='showdesc_".$resultEle['ID']."'>".$description."</a></td>";
			$listdata .= "<td>".$when_date."</td>";

			if ( $showtype == 'other_pending' ) {
				$listdata .= "<td>$participant_name</td>";
			}

			$listdata .= "<td><a href='view_doc_gap_filling_listing.php?audit_id={$resultEle['reviewID']}&docid={$resultEle['ID']}'>View</a></td></tr>";
		}

		$listdata .= "<script> (function($) { $(document).ready(function () {";
		$listdata .= $jsdata;
		$listdata .= "});})(jQuery);	</script>";

		$orgObj = null;
	}

$listdata .= "</tbody>";

$listdata .= "<tfoot><tr>";
$listdata .= "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";

if ( $showtype == 'other_pending' ) {
	$listdata .= "<td>&nbsp;</td>";
}

$listdata .= "</tr></tfoot></table>";

$listdata .= "<br/><br/><address><b>Note:</b><br/>Click on comment to view full comment.</address>";

echo $listdata;
?>