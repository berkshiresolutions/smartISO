<?php
 /**
  $Id: record_contributor.php,v 3.44 Saturday, January 29, 2011 6:45:53 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Contributor
  * @since  Saturday, November 20, 2010 7:20:55 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];
$selected = (int)$_GET['id'];
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'Documents';

if ( $level == 1 ) {
	$is_admin = true;
}


$docObj = new Documents();
$optObj	= new Option();
$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');

$documents = $docObj->getDocAlerts();
$documentsCount = count($documents);

echo "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='5%'>Reference</th>
			<th width='45%'>Document</th>
			<th width='50%'>Actions</th>
		</tr>
	</thead>
	<tbody>";


if ( $documentsCount ) {

if($documentItem['cmsdocID']  == $selected)     
$highlight="style='background-color:lightyellow'";
else
$highlight=" ";

	foreach ( $documents as $documentItem ) {
			$document_code_info   = $docObj->getSectionByStandardAndCode('52',$documentItem['fileReference']);
			$rel = $documentItem['cmsdocID'];
			$section_ref	= $document_information['fileReference']." ".$document_code_info['name'];
if ($documentItem['documentSubType']=="W")
                           $document	= '[WI]&nbsp;&nbsp;<a href="/documents/download.php?src='.$documentItem['documentID'].'&name='.$documentItem['title'].'">'.$documentItem['title'].'</a> Ver <a href="javascript:void(0)" class="action view_version" rel='.$rel.'>'.$documentItem['versionNew'];
else
                        $document	= '['.$documentItem['documentType'].']&nbsp;&nbsp;<a href="/documents/download.php?src='.$documentItem['documentID'].'&name='.$documentItem['title'].'">'.$documentItem['title'].'</a> Ver <a href="javascript:void(0)" class="action view_version" rel='.$rel.'>'.$documentItem['versionNew'];
if ($version_type=='minor_version')
    $document		.=".".intval($documentItem['versionMinor']).'</a>';
else 
    $document		.='</a>';

        		echo "<tr>";
			echo "<td ".$highlight." title=".$document_code_info['name'].">".$documentItem['fileReference']."</td>";
			echo "<td ".$highlight.">".$document."</td><td>";
                        echo "<a href='javascript: void(0)' class='action view_alerts' rel='".$rel."'>Alerts</a>";

			echo "</td></tr>";
	}
	 // end for
} // end if

echo "</tbody><tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</tfoot>
</table>";

//echo $listdata;