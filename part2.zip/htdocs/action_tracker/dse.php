<?php
/**
 $Id: dse.php,v 3.12 Tuesday, February 01, 2011 3:30:31 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for DSE - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Tuesday, September 21, 2010 3:55:59 PM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/dse.js';

if (isset($_GET['menu']) && (int)$_GET['menu'] == 2)
$class_viewatt = "selected_tab"    ;
else 
$class_viewat = "selected_tab"    ;
$LAST_BREAD_CRUM = "DSE"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/dse.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>