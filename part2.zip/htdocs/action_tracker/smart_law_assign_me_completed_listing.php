<?php
/**
 $Id: smart_law_assign_me_completed_listing.php,v 3.05 Wednesday, September 29, 2010 6:25:00 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Smart Law - Assigned to me(completed).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Saturday, September 25, 2010 11:45:12 AM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/smart_law_assign_me_completed.js';

$class_smart_law  = "selected_tab"; //current tab
$LAST_BREAD_CRUM  = "Smart Law"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/smart_law_assign_me_completed.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>