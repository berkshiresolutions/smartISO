<?php
 /**
  $Id: index.php,v 3.61 Thursday, February 03, 2011 2:41:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Wednesday, September 29, 2010 2:17:35 PM>
  */

//header('location: /index_new.php');
//exit();

//redirects ro the new form  /Bob


// load jquery validation script file
$class_viewat = "selected_tab";
$_PAGE_VALIDATION_SCRIPT 	= 'action_tracker/index.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
Session::saveSessionField('menu_state',1);
set_time_limit(180);

$actTrackObj 	= new ActionTracker();

//$tabs 			= array('me_pending','other_pending','me_completed','other_completed');

$user_level = getUserAccessLevel();
if ( $user_level == 1 ) {
	$tabs 			= array('me_pending','other_pending');
} else  {
	$tabs 			= array('me_pending');
}

$modules 		= array('risk'=>'risk',
				 'risk27k'=>'risk27k',
                                  'SOA'=>'SOA',
				 'dse'=>'DSE',
				 'inspC'=>'inspection ccp',
				 'inspH'=>'inspection hazard',
				 'inspR'=>'inspection risk',
				 'nonc_inc'=>'Nonconformance inc',
				 'nonc_inv'=>'Nonconformance di',
				 'nonc_nhp'=>'Nonconformance nhp',
				 'cc'=>'complaint',
				 //'doc'=>'Doc Control',
				 'cont'=>'Contributor',
				 'gapA'=>'gap act',
				 'manhE'=>'manualhandling env',
				 'manhI'=>'manualhandling ind',
				 'manhL'=>'manualhandling load',
				 'manhT'=>'manualhandling task',
				 'contract'=>'contract',
				 'slaw'=>'smart law',
				 'slawreview'=>'smart law review',
				 'nhc_inv'=>'NHC Inv'
				
				
				 
				 


				
				 //'vehicleService'=>'Service'
				);



foreach ( $modules as $keyMod=>$valueMod ) {
	$keyMod_count = 0;

	if ( $keyMod == 'cont' || $keyMod == 'doc' ) {

		$actTrackObj->setActionTrackerInfo($valueMod,$tabs[0]);
		$resultset = $actTrackObj->getActionsForActionTracker();
			//dump_array($resultset);
		//echo isAdministrator().'->'.$PERMISSIONS['PERM_DOC'].'<br/>';

		if ( (isAdministrator() || $PERMISSIONS['PERM_DOC']) && ($keyMod == 'doc' || $keyMod == 'cont' )) {
			$keyMod_count = count($resultset);
		} else {
			$keyMod_count = 0;
		}

		/*echo $valueMod.'=>'.$keyMod_count;
		echo "<br/>";*/

	} else {
	
	//dump_array($valueMod);

		foreach ( $tabs as $valueTab ) {

			$actTrackObj->setActionTrackerInfo($valueMod,$valueTab);
			$resultset = $actTrackObj->getActionsForActionTracker();

			$keyMod_count += count($resultset);
			//echo "--";
		}
	}
	
	
	$smarty->assign($keyMod,$keyMod_count);
}



$gapObj = new ReviewGap();
$result	= $gapObj->getGapQuestionActionTracker(true,date('Y-m-d'));
$result_other	= $gapObj->getGapQuestionActionTracker(false,date('Y-m-d'));

$gap_count =  count($result) + count($result_other);

$smarty->assign('gap_count',(int) $gap_count);

$dt_val = $_GET['dt_val'];
if ( $dt_val == '' ) {
	$date_arr = array(date('m'),date('Y'),date('d'));
} else {
	$dt_val_arr = explode('-',$dt_val);
	$date_arr = array($dt_val_arr[1],$dt_val_arr[0],$dt_val_arr[2]);
}

$objAction= new Action();
$counter=$objAction->getActionCount();
$smarty->assign('counter',$counter);
$smarty->assign('title',"Action Tracker");
$smarty->assign('menu',"1");
$smarty->assign('user_level',$user_level);
$smarty->assign('PERMISSIONS',$PERMISSIONS);
$smarty->display('action_tracker/index.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>