<?php
 /**
  $Id: ajax_get_contibutors.php,v 3.06 Thursday, January 20, 2011 6:07:13 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contributor status
  * @since  Wednesday, January 19, 2011 7:41:57 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$partObj		= 	SetupGeneric::useModule('Participant');

$id		= (int) $_GET['id'];
$actObj= new Action();
$action=$actObj->viewAction3($id);
$wholink=$action["who"];
$i==0;
                        while($wholink>0 && $i<6) {
                            $whomaster = $partObj->getManagerDetails($wholink);
                            if ($whomaster["participantID"]>0)
                            $managers[$whomaster["participantID"]]=array('id'=>$whomaster["participantID"],'name'=>$whomaster["forename"]." ".$whomaster["surname"]);
                           $wholink = $whomaster["participantID"];
                            $i++;
                        }
 $admin=$partObj->getAdminDetails();
  $managers[]=array('id'=>$admin["participantID"],'name'=>$admin["forename"]." ".$admin["surname"]);


	$resultset = array('records' => $managers);
	echo json_encode($resultset);



?>