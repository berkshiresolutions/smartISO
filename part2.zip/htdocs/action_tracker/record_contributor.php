<?php
 /**
  $Id: record_contributor.php,v 3.44 Saturday, January 29, 2011 6:45:53 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Contributor
  * @since  Saturday, November 20, 2010 7:20:55 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];
 $selected = (int)$_GET['id'];
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'DSE';

if ( $level == 1 ) {
	$is_admin = true;
}

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$docObj = new Documents();

$contribObj = new DocumentContributor();
$documents = $contribObj->viewAssignedDocuments($filter_date);
//$documentsCount = count($documents);
$scopeObj = SetupGeneric::useModule('DocScope');
$scopeArr = $scopeObj->displayItems();

$scope[0]="&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele ) {
                
                $scope[$scope_ele["ID"]]="[".$scope_ele['scope']."]";
  
        }

     		$code51=$docObj->getListDocument51();

$listdata1 = "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='15%'>Section Reference</th>
			<th width='20%'>Document</th>
		<th width='10%'>Who</th>   

			<th width='20%'>Comment</th>
			<th width='13%'>Due Date</th>
                        <th width='10%'>Alert</th>
			<th width='11%'>Action</th>
		</tr>
	</thead>
	<tbody>";
if (_CANDW == 1)
$listdata=str_replace("Alert","Change",$listdata1) ;
else 
$listdata=$listdata1 ;
	            $optionObj = new Option();
    $red = $optionObj->getOption('_SU_EMAIL_REDMAIL');
    $yellow = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
    $green = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
//	var_dump($documents);
if ( is_array($documents) ) {
	foreach ( $documents as $documentItem ) {

		if ( $documentItem['cmsdocID'] ) {

			$document_information 	= $docObj->getDocumentInformation($documentItem['cmsdocID']);

			$document_metadata 		= $docObj->getDocumentMetadata($documentItem['cmsdocID']);

			$document_code_info   = $docObj->getSectionByStandardAndCode('11',$document_information['fileReference']);
       
            $participantObj->setItemInfo(array('id' => $documentItem['authParticipantID']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

            $str = (strtotime($documentItem['contribDueDate'])) - strtotime(date("M d Y "));
            $dateinc = floor($str / 3600 / 24);
      

            $change_bg_color = "";
        if ($dateinc > $green) {
            $change_bg_color = "";
        } else if ($dateinc > $yellow) {
            $change_bg_color = "style='background-color:green;COLOR:WHITE'";
        } else if ($dateinc > $red) {
            $change_bg_color = "style='background-color:#F4A460;COLOR:WHITE'";
        } else {
            $change_bg_color = "style='background-color:red;COLOR:WHITE'";
        }
		
                        $section_ref	= $document_information['fileReference']." ".$document_code_info['name'];
			if ($document_information['documentSubType']=="W")
                           $document	= '[WI]';
else
                        $document		= '['.$document_information['documentType'].']';
$rel=$document_information['cmsdocID'];
if($documentItem['contributorID']  == $selected)     
$highlight="style='background-color:lightyellow'";
else
$highlight=" ";
$alert=$documentItem['alert']==1 ? "Yes" :"No";
if ($document_information['fileReference']=="4.5" && $document_information['code27002']>0)
				$codes51 =$code51[$document_information['code27002']];
			else
				$codes51 =" ";
     //  $document.= $scope[$document_information['scope']].'&nbsp;&nbsp;<a href="/documents/download.php?src='.$document_information['documentID'].'&name='.$document_information['title'].'">' . $document_information['title'].'</a> Ver <a href="javascript:void(0)">'.$document_information['versionNew'].'</a> '.$codes51;
 $document.= $scope[$document_information['scope']].'&nbsp;&nbsp;<a href="/documents/download.php?src='.$document_information['documentID'].'&name='.$document_information['title'].'">' .$document_information['reference'].'&nbsp;&nbsp;-&nbsp;&nbsp;'. $document_information['title'].'</a> Ver <a href="javascript:void(0)" class="action view_version" rel=' . $rel . '>'.$document_information['versionNew'].'</a> '.$codes51;
         
	 
			$comment 		= $documentItem['comments'] == '' ? '-' : smartisoStripslashes($documentItem['comments']);
			$due_date		= format_date($documentItem['contribDueDate']);

			$listdata .= "<tr>";
			$listdata .= "<td " . $change_bg_color . " >".$section_ref."</td>";
			$listdata .= "<td ".$highlight.">".$document."</td>";
                        $listdata .= "<td ".$highlight.">".$who_name."</td>";
			$listdata .= "<td ".$highlight.">".$comment."</td>";
			$listdata .= "<td ".$highlight.">".$due_date."</td>";
                        $listdata .= "<td ".$highlight.">".$alert."</td>";
			$listdata .= "<td ".$highlight."><a href='javascript:void(0)' class='contributor_action' rel='".$documentItem['contributorID']."|".$documentItem['cmsdocID']."' alert='".$documentItem['alert']."'>Action</a></td>";
			$listdata .= "</tr>";
		}
	} // end for
} // end if

$listdata .= "</tbody><tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</tfoot>
</table>";

echo $listdata;