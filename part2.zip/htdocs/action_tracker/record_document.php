<?php

/**
  $Id: record_contributor.php,v 3.44 Saturday, January 29, 2011 6:45:53 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Contributor
 * @since  Saturday, November 20, 2010 7:20:55 PM>
 */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
    $optObj = new Option();

    $selected_grp = $optObj->getOption('_SU_GRP_POLICY');
   
    
$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];
$selected = (int)$_GET['id'];
$USER_ID = getLoggedInUserId();
$grp = $USER_ID==$selected_grp ? true : false;

$level = getUserAccessLevel();
$action_tracker_module_name = 'Documents';

if ($level == 1) {
    $is_admin = true;
}


$docObj = new Documents();

$scopeObj = SetupGeneric::useModule('DocScope');
$scopeArr = $scopeObj->displayItems();

$scope[0]="&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele ) {
                
                $scope[$scope_ele["ID"]]="[".$scope_ele['scope']."]";
  
        }

		$code51=$docObj->getListDocument51();
                
  
$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$documents = $docObj->getDocumentListActionTracker();
if (is_array($documents))
$documentsCount = count($documents);
else {
$documentsCount =0;
}
echo "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='5%'>Reference</th>
			<th width='45%'>Document</th>
			<th width='50%'>Actions</th>
		</tr>
	</thead>
	<tbody>";


if ($documentsCount) {
    foreach ($documents as $document) {

        foreach ($document as $documentItem) {


    if(!$grp  && $documentItem['documentSubType'] == "G")
        continue;
            $document_code_info = $docObj->getSectionByStandardAndCode('52', $documentItem['fileReference']);
            $rel = $documentItem['cmsdocID'];
            $section_ref = $document_information['fileReference'] . " " . $document_code_info['name'];
			
	if($documentItem['cmsdocID']  == $selected)     
$highlight="style='background-color:lightyellow'";
else
$highlight=" ";		
            if ($documentItem['documentSubType'] == "W")
                $document = '[WI]';
            elseif ($documentItem['documentSubType']== "G")
                $document = '[GP]';
            else
                $document = '[' . $documentItem['documentType'] . ']';
if (_CANDW)
            $document .= $scope[$documentItem['scope']].'&nbsp;&nbsp;<a href="/documents/download.php?src=' .$documentItem['documentID'].'  -  ' .  $documentItem['documentID'] . '&name=' . $documentItem['title'] . '">'  . $documentItem['reference'] .'&nbsp;&nbsp;-&nbsp;&nbsp;' . $documentItem['title'] . '</a> Ver <a href="javascript:void(0)" class="action view_version" rel=' . $rel . '>' . $documentItem['versionNew'];
else
          $document .= $scope[$documentItem['scope']].'&nbsp;&nbsp;<a href="/documents/download.php?src=' .$documentItem['documentID'].'  -  ' .  $documentItem['documentID'] . '&name=' . $documentItem['title'] . '">&nbsp;&nbsp;-&nbsp;&nbsp;' . $documentItem['title'] . '</a> Ver <a href="javascript:void(0)" class="action view_version" rel=' . $rel . '>' . $documentItem['versionNew'];

            if ($version_type == 'minor_version')
                $document .="." . intval($documentItem['versionMinor']) . '</a>';
            else
                $document .='</a>';
            echo "<tr>";
if ($documentItem['fileReference']=="4.5" && $documentItem['code27002']>0)
				$codes51 =$code51[$documentItem['code27002']];
			else
				$codes51 =" ";
            if ($documentItem['status'] == 'I') {
                echo "<td ".$highlight." title=" . $document_code_info['name'] . " style='background-color:blue'>" . $documentItem['fileReference'] . "</td>";
                echo "<td ".$highlight.">" . $document ."  ". $codes51."</td><td>";
                echo "<a href='javascript: void(0)' class='action no_change' rel='" . $rel . "'>No change</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
            } else {
                echo "<td ".$highlight." title=" . $document_code_info['name'] . ">" . $documentItem['fileReference'] . "</td>";
                echo "<td ".$highlight.">" . $document ."  ".$codes51. "</td><td ".$highlight.">";
                echo "<a href='javascript: void(0)' class='action reject_document' rel='" . $rel . "'>Reject</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
            }
            echo "<a href='javascript: void(0)' class='action move_doc' rel='" . $rel . "'>Move</a> &nbsp;&nbsp;|&nbsp;&nbsp;";
            $contributors = $docObj->getDocumentContributors($rel);
            $document_status = "";
            if ($contributors) {

                $contributor_replied_a = 0;
                $contributor_replied_na = 0;
                $contributor_replied = 0;
                $contributor_count = count($contributors);

                foreach ($contributors as $contributor) {
                    switch ($contributor['passed']) {
                        case 1: $contributor_replied_a++;
                            $contributor_replied++;
                            break;
                        case 2: $contributor_replied_na++;
                            $contributor_replied++;
                            break;
                    }
                }

                if ($contributor_replied == 0) {

                    $document_status = "Wait for Contributors's response";
                } else if ($contributor_replied < $contributor_count) {

                    $document_status = "Sent to contributors";
                } else if ($contributor_replied == $contributor_replied_a) {

                    $document_status = "Approved by contributors";
                    //   } else if ($contributor_replied == $contributor_replied_na) {
                } else {
                    $document_status = "Not approved by contributors";
                }

                echo "<a href='javascript: void(0)' class='action contribute_doc' title='" . $document_status . "' rel='" . $rel . "'>Contribution Status</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
            } else {
                echo "<a href='javascript: void(0)' class='action contribute_doc' rel='" . $rel . "'>Send For Contribution</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
            }




            //echo "<a href='javascript: void(0)' class='action contribute_doc' rel='".$rel."'>Send For Contribution</a>&nbsp;&nbsp;|&nbsp;&nbsp;";
            echo "<a href='javascript: void(0)' class='action change_doc' rel='" . $rel . "'>Change</a> &nbsp;&nbsp;";
            if ($documentItem['status'] != 'I')
                echo "|&nbsp;&nbsp; <a href='javascript: void(0)' class='action publish_doc' rel='" . $rel . "'>Publish</a>";
            echo "</td></tr>";
        }
    } // end for
} // end if

echo "</tbody><tfoot>
		<tr>
			<td>&nbsp;</td>

			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</tfoot>
</table>";

//echo $listdata;