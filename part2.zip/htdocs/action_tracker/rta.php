<?php
/**
 $Id: non_conf_nhp.php,v 3.11 Friday, January 28, 2011 11:03:15 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Non-conformance(NHP) - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Friday, September 24, 2010 11:58:57 AM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/rta.js';

$class_non_conformance_nhp = "selected_tab"; //current tab
$LAST_BREAD_CRUM = "RTA"; // for current breadcrumbs

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/rta.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>