<?php
 /**
  $Id: save_action_information.php,v 3.83 Monday, December 13, 2010 4:13:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * for testing purpose only
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Monday, August 16, 2010 11:24:04 AM>
  */

$_HIDE_HTTP_HEADER = true;
//require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/email/newEmail.php';
//require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/emailer.php';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$actTrackObj = new ActionTracker();
$smartlawObj = new smartLaw();

 $actionId 		= (int) $_GET['action_id'];
$done_date 		= format_date_for_mysql(strip_tags($_GET['done_date']));

$comment 		= strip_tags($_GET['comment']);
$action_type 	= strip_tags($_GET['action_type']);

		$p_value =str_replace("'","`",$comment);
		$data=$smartlawObj->updateAction($done_date,$p_value,$actionId);

try {
	if ( $action_type == 'save_date' ) {
	 	$emailObj =	new actionEmailHelper($actionId);


		$who=$emailObj->getAUDetails();

	if($data["record"])
		{
	$slawdata = $smartlawObj->displayId($data["record"]);
}	
	
else
{
		$slawdata = $smartlawObj->getActionsbyID($actionId);
}
 $actionIdggg 		= (int) $_GET['action_id'];
//dump_array($slawdata);
  $actionTMP = new Action($actionIdggg);
        
		$actionTMP->setActionDetails($actionIdggg,null);
		$thactionDetails = $actionTMP->viewAction();
//dump_array($thactionDetails);

//exit;
		if($thactionDetails['moduleName'] == 'smartlawreview'){
		
		
			$data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlawreview.php?filter_date=">CLICK</a> Here to View smart Law Review Action'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>$slawdata['reference']." ".$slawdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$slawdata['slsLegislation'])));
		} else{
			$data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/smartlaw.php?filter_date=">CLICK</a> Here to View smart Law Review Action'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>$slawdata['reference']." ".$slawdata['slyear']),'description'=>array('left'=>'<strong>Title</strong>','right'=>$slawdata['slsLegislation'])));
		}	
		
			
		$emailObj->appendInfo($data);
		
		$emailObj->sendEmail('A smart law Action To Be Approved',$who,array(),array(),'me_completed','','grey');
			echo 1;
	 
//		$actTrackObj->saveActionInformation($actionId,$done_date,$comment);
	} else if ( $action_type == 'approve' ) {
		$actTrackObj->approveCompletedAction($actionId);
		$smartlawObj->updateStatus($actionId);
		echo 1;
	} else if ( $action_type == 'au_approve' ) {
		$actTrackObj->approveAUApprovedAction($actionId);
		$smartlawObj->updateStatus($actionId);
		echo 1;
	}
	
} catch ( ErrorException $e ) {
	echo $e->getMessage();
}

?>