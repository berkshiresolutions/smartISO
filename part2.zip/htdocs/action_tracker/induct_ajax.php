<?php
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/smart_induct/inductToggles.class.php';

//error_reporting(E_ALL);
//ini_set('display_errors', 'On');
//ini_set('html_errors', 'On');

$action_type = (in_array($_GET['action_type'],array('au_approve','save_date')) ? $_GET['action_type'] : 'au_approve');
$action = intval($_GET['action_id']);

switch($action_type) {
	case 'au_approve':
		$res = inductToggles::authActionTracker($action, true, true);
		break;
	case 'save_date':
		$comment = isset($_GET['comment']) ? urldecode($_GET['comment']) : '';
		$date = isset($_GET['done_date']) ? urldecode($_GET['done_date']) : date('m/d/Y');
		$res = inductToggles::markCompleteActionTracker($action,$date,$comment);
		break;
	default:
		$res = false;
}
echo $res?'1':'Authorization Error';          