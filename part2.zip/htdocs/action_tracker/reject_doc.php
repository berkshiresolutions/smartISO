<?php
 /**
  $Id: replace_document.php,v 3.74 Thursday, January 20, 2011 4:14:14 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/nochange_doc.js';

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';
$docObj 	= new Documents();
//echo	$document_id = (int) $_GET['document_id'];
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {


	$doc_id = (int) $_POST['doc_id'];
	$alert_id = (int) $_POST['alert_id'];


$docclassObj 					= SetupGeneric::useModule('DocClassification');
$document_classification 		= $docclassObj->displayItems();
$optObj							= new Option();
$miscObj 						= new Misc();
$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$document_types 				= $miscObj->getDocumentTypes();
$optObj							= null;
$miscObj 						= null;
$participantObj				 	= SetupGeneric::useModule('Participant');

$emailObj = new infoEmailHelper();
$document_info 					= $docObj->getDocumentInformation($doc_id);
$document_contributors 			= $docObj->getDocumentContributors($doc_id);

$participant_id = $document_info['initiatedByParticipant'];
$participantObj->setItemInfo(array('id'=>$participant_id));
$partcipantData = $participantObj->displayItemById();

$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
$initiated_by 	= $participant_name == ' ' ? '-' : $participant_name;



if ($version_type == 'minor_version'){
    $document_info_simple['version']=$document_info['versionNew'].".".$document_info['versionMinor']; 
}else{
    $document_info_simple['version']=$document_info['versionNew'];
}

$version_type = $version_type == 'minor_version' ? 'Version' : $version_type;
$version_type = str_replace('_',' ',$version_type);

$document_info_simple['code'] 			= $document_info['fileReference'];
$document_info_simple['document']		= "<a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=".$file_detail['sysFilename']."&un=".$file_detail['usrFilename']."&module=contributors','mywindow')\">".$file_detail['usrFilename']."</a>";
$document_info_simple['name'] 			= ucfirst($document_info['title']);
$document_info_simple['description']            = ucfirst($document_info['description']);
$document_info_simple['type'] 			= $document_types[$document_info['documentType']];
$document_info_simple['initiated'] 		= format_date($document_info['dateInitiated']);
$document_info_simple['initiated_by']           = $initiated_by;
$document_info_simple['approved_date']          = $document_info[''];
$document_info_simple['approved_by']            = $document_info[''];
$document_info_simple['action_summary']         = ucfirst($document_info['actionSummary']);
$document_info_simple['pages'] 			= $document_info['pages'];

$document['alert_id'] 				= $alert_id;

$docObj->setDocumentInfo($document);
$alert_details = $docObj->getAlertDetails();
$partObj 			= SetupGeneric::useModule('Participant');
$partObj->setItemInfo(array('id'=>$alert_details[0]['alertRaisedBy']));
$partcipantData = $partObj->displayItemById();

$who = array(
				'displayname' => ucwords($partcipantData['forename'].' '.$partcipantDatal['surname']),
				'email' => $partcipantData['emailAddress']
		);


		
		                   if (_CANDW == 1)
                       $subject = "smart-ISO Document Change raised";
                   else
		    $subject = "smart-ISO Document Alert raised";
		 		 
$mergeData = array(
'twoColData'=>array(
'actionid'=>array('left'=>'<strong>File Reference:</strong>','right'=>$document_info_simple['code']),
			'assignedto'=>array('left'=>'<strong>Document Name:</strong>','right'=>$document_info_simple['name']),
			'authorizing1'=>array('left'=>'<strong>Document Description:</strong>','right'=>$document_info_simple['description']),
			'due'=>array('left'=>'<strong>Document Type:</strong>','right'=>$document_info_simple['type']), 
            'initBy'=> array('left' => '<strong>Initiated By:</strong>','right' => $document_info_simple['initiated_by']),
			'version'=>array('left'=>'<strong>Version:</strong>','right'=>$document_info_simple['version']), 
			'page'=> array('left' => '<strong>Pages:</strong>','right' => $document_info_simple['pages'])

                    ),
'singleColData'=>array(
                            'summary'=>'<p><strong>Reason</strong><br>'.$_POST['reason_replace'].'<BR>The document is unchanged</p>')
					);

                $emailObj->appendInfo($mergeData);


                $emailObj->sendEmail($subject,$who,array(),array(),'me_completed','','grey');
if(_CANDW==1)
    $message = "The Change has been Rejected by Doc. Publisher/Manager";
else
$message = "The Alert has been Rejected by Doc. Publisher/Manager";
$docObj->saveDocumentLog($doc_id,$message,$_POST['reason_replace']);
$docObj->saveDisagree($_POST['alert_id'],$_POST['reason_replace']);


	$url = basename($_SERVER['PHP_SELF'])."?js=1&e=2";
    // echo $url ;
	redirection($url);
}

$js 				= (int) $_GET['js'];
$e 					= (int) $_GET['e'];
$u 					= (int) $_GET['u'];

if ($js) {

	$smarty->assign('js',$js);
	$smarty->assign('e',$e);

} else {

	$orgObj 							= SetupGeneric::useModule('Organigram');
	$docClassObj						= SetupGeneric::useModule('DocClassification');
	$miscObj							= new Misc();

	$optObj								= new Option();
	$version_type 						= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
	$doc_id 							= (int) $_GET['document_id'];
        $alert_id 							= (int) $_GET['alert_id'];
	$version_data 						= '';
	$doc_class_options					= '';
	$row_data							= array();

	$business_units 					= $orgObj->getBusinessUnits($selected);
	$document_classification 			= $docClassObj->displayItems1();

	$document_information 				= $docObj->getDocumentInformation($doc_id);
	$document_types 					= $miscObj->getDocumentTypes();

	$row_data['doc_id'] 				= $doc_id;
        $row_data['alert_id'] 				= $alert_id;
	$row_data['version_old'] 			= $document_information['versionOld'];
	$row_data['version_new'] 			= $document_information['versionMinor'] != '' ? $document_information['versionNew'].'.'.intval($document_information['versionMinor']) : $document_information['versionNew'];
	$row_data['file_reference'] 		= $document_information['fileReference'];
	$row_data['document_name'] 			= $document_information['title'];
	$row_data['document_desc'] 			= ucfirst($document_information['description']);
	$row_data['document_type_long']		= $document_types[$document_information['documentType']];
	$row_data['document_type']			= $document_information['documentType'];
	$row_data['pages'] 					= $document_information['pages'];
	$row_data['buID'] 					= $document_information['buID'];
	$row_data['doc_control'] 			= $document_information['docControl'];
	$row_data['date_initiated']			= $document_information['dateInitiated'];
	$row_data['initiated_by_part']		= $document_information['initiatedByParticipant'];
	$row_data['standard_id']			= $document_information['standardID'];
	$row_data['is_gap_document']		= $document_information['isGapDocument'];

if ($document_classification) {

		$doc_class_options .= "<option value=''>-- Select --</option>";

		foreach ( $document_classification as $document_class_ele => $document_class_val ) {
		
		//dump_array($document_class_val);
		
		if($document_class_val['action'] == 'Active'){
		$doc_class_options .= "<option value='".$document_class_ele."'>".$document_class_val['opValue']."</option>";
		}
		
		
			
		}
	}

	if ( $version_type == 'version' || $version_type == 'minor_version' ) {

		$version_data .= "<option value='0'>--</option>";

		for ($i=1;$i<=10;$i++) {
			$version_data .= "<option value='".$i."'>".$i."</option>";
		}
		$version_type_text = 'version';

	} else if ( $version_type == 'revision' ) {

		$version_data .= "<option value=''>--</option>";

		for ($i=65;$i<=70;$i++) {
			$version_data .= "<option value='".chr($i)."'>".chr($i)."</option>";
		}

		$version_type_text = $version_type;
	}

	$smarty->assign('document_classification',$doc_class_options);
	$smarty->assign('row_data',$row_data);
	$smarty->assign('u',$u);
	$smarty->assign('post_script_name','reject_doc.php');
	$smarty->assign('business_units',$business_units);
	$smarty->assign('version_type',ucfirst(str_replace('_',' ',$version_type)));
	$smarty->assign('version_type_text',ucfirst($version_type_text));
	$smarty->assign('version_data',$version_data);
}

$smarty->display('action_tracker/reject_doc.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';