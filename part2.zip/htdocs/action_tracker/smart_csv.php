<?php
 /**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <gurnam_84@hotmail.com>
  * @package Smartiso
  * @subpackage Equipment
  * @since  Friday, January 14, 2011 5:44:40 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];
header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=inspection.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

$fn = fopen('inspection.xls','w');
//$objExport = new ExportData('nhpactionexport','csv');
//$objExport->downloadFile();

$bcp		=		new RiskActionExport();
$data1 = $bcp->getListingforExport();


?>
<table cellspacing='0' cellpadding='0' width='100%' border='1'>
	
	<tr style='border: 1px solid;'>
	
	
	<td>Reference</td>
	<td >Inspection Name</td>
	<td>Frequency</td>
	<td >Action</td>
	<td >Due Date</td>
	<td > Assigned To</td>
	<td >Done Date</td>
	</tr>

	</table>
	<?php

fclose($fn);





//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>