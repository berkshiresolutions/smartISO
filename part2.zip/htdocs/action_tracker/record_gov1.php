<?php
/**
 $Id: record_risk_assessment.php,v 5.17 Thursday, February 03, 2011 12:37:43 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Risk - Assigned to me(pending) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Monday, September 20, 2010 11:41:04 AM>
*/
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
$participantObj = SetupGeneric::useModule('participant');
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'gov1';

$filter_date = $_GET['filter_date'];
$selected = $_GET['id'];
if ( $level == 1 ) {
	$is_admin = true;
}

$show_au_approve = true;

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
	$show_au_approve = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$show_done_date = true;

if ( $tab_type == 'other_pending' && $level != 1 ) {
	$show_done_date = false;
}

$actTrackObj = new ActionTracker();

try {

	$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$tab_type,$filter_date);
	$resultset = $actTrackObj->getActionsForActionTracker();

	$listdata = "<form class='action_tracker_listing' name='risk_form' method='post'>";
	$listdata .= "<table class='display' id='module_records'><thead><tr>
	<th width='13%'>Reference</th>

				<th width='18%'>Problem</th>
				<th width='16%'>Actions</th>
				<th width='10%'>Due Date</th>";

if ($show_participant_name) {
        $listdata .= "<th width='10%'>Assigned to</th>";
    }

    $listdata .= "<th width='15%'>Completed Date</th>";

    $listdata .= "<th width='7%' title='2nd Approver to Verify for Effectiveness'>VfE</th>";

    $listdata .= "<th width='5%' title='Manager to Verify for Effectiveness'>Verify</th>";

	$listdata .= "</tr></thead><tbody>";

	$jsdata = $jsdata_second = $jsdata_third = '';

            $optionObj = new Option();
    $red = $optionObj->getOption('_SU_EMAIL_REDMAIL');
    $yellow = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
    $green = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
    
    
	foreach ( $resultset as $resultElementKey=>$resultElement ) {
			//dump_array($resultElement);
		$ac_id = $resultElement['id'];
  if($ac_id  == $selected)     
$highlight="style='background-color:lightyellow'";
else
$highlight=" ";  
                 $str = (strtotime($resultElement['dueDate'])) - strtotime(date("M d Y "));
        $dateinc = floor($str / 3600 / 24);

        if ($tab_type == 'me_completed' || $tab_type == 'other_completed') {
            $change_bg_color = "";
        } else if ($dateinc > $green) {
            $change_bg_color = "";
        } else if ($dateinc > $yellow) {
            $change_bg_color = "style='background-color:green;COLOR:WHITE'";
        } else if ($dateinc > $red) {
            $change_bg_color = "style='background-color:#F4A460;COLOR:WHITE'";
        } else {
            $change_bg_color = "style='background-color:red;COLOR:WHITE'";
        }
        
		$summary 			= compact_action_tracker_description($resultElement['problem']);
		$action_description 		= compact_action_tracker_description($resultElement['actionDescription']);

                $record_id		        = $resultElement['reviewID'];
                
		$listdata .= "<tr>";
		$listdata .= "<td " . $change_bg_color . " >";
                $listdata .= "<a href='javascript:void(0)' class='act_goto' rel=" . $record_id . " >".$resultElement['uniqueReference']."</a></td>";

		$listdata .= "<td ".$highlight.">".$summary."</td>";

		$listdata .= "<td ".$highlight."><a href='javascript:void(0)' class='showaction' rel=" . $ac_id . " >" . $action_description . "</a></td>";
       
		$listdata .="<td ".$highlight.">".format_date($resultElement['dueDate'])."</td>";

        if ($show_participant_name) {
            $participantObj->setItemInfo(array('id' => $resultElement['currentWho']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

            $listdata .= "<td ".$highlight.">" . $who_name . "</td>";
        }

        if ($tab_type == 'me_completed' || $tab_type == 'other_completed') {
            $participantObj->setItemInfo(array('id' => $resultElement['who']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
            $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";
            if ((int) $resultElement['addapprover'] > 0) {
                $participantObj->setItemInfo(array('id' => $resultElement['addapprover']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='show2appcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";
            } else {
                $listdata .="<td ".$highlight.">&nbsp;-&nbsp;</td>";
            }


            $participantObj->setItemInfo(array('id' => $resultElement['whoAU']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
            $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showapprovecomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";"</td>";
        } elseif ($tab_type == 'me_pending' || $is_admin) {
                      if ($resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00') {

                $listdata .="<td ".$highlight.">&nbsp;<a href='javascript:void(0)' class='act_done' rel=" . $ac_id . "  >Close Action</a></td><TD ".$highlight."></td><TD ".$highlight."></td>";
            } elseif (( $resultElement['app2date'] == '' || $resultElement['app2date'] == '0000-00-00' ) && (int) $resultElement['addapprover'] > 0) {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD ".$highlight.">&nbsp;<a href='javascript:void(0)' class='act_2_approve' rel='" . $ac_id . "'  >Close Action</a></td><TD ".$highlight."></td>";
            } else {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                
                $participantObj->setItemInfo(array('id' => $resultElement['addapprover']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who2app_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                
                if ((int) $resultElement['addapprover'] > 0) {

                    $app2Text = $who2app_name . " - " . format_date($resultElement['doneDate']). "<a class='show2appcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";;
                } else {
                    $app2Text = " - ";
                }
                $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD ".$highlight.">" . $app2Text . "</td><TD ".$highlight.">&nbsp;<a href='javascript:void(0)' class='final_approval' rel='" . $ac_id . "'  >Close Action</a></td>";
            }
        } else {
            if ($resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00') {

                $listdata .="<td ".$highlight.">&nbsp;Pending</td><TD ".$highlight."></td><TD ".$highlight."></td>";
            } elseif (( $resultElement['app2date'] == '' || $resultElement['app2date'] == '0000-00-00' ) && (int) $resultElement['addapprover'] > 0) {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD ".$highlight.">&nbsp;Pending</td><TD ".$highlight."></td>";
            } else {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

                $participantObj->setItemInfo(array('id' => $resultElement['addapprover']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who2app_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

                if ((int) $resultElement['addapprover'] > 0) {

                    $app2Text = $who2app_name . " - " . format_date($resultElement['doneDate']). "<a class='show2appcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";;
                } else {
                    $app2Text = " - ";
                }
                $listdata .="<td ".$highlight.">" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD ".$highlight.">" . $app2Text . "</td><TD ".$highlight.">&nbsp;Pending</td>";
            }
        }
	}
	$listdata .= "</tbody><tfoot><tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>

				<td>&nbsp;</td>
<td>&nbsp;</td>
				<td>&nbsp;</td>";

	if ($is_admin) {
		$listdata .= "<td>&nbsp;</td>";
	}
	$listdata .= "</tr></tfoot></table></form>";
	$listdata .= "<div class='footnote'><b>Note :</b> To view full Hazard/Action, click the corresponding box.</div>";

	$listdata .= "<script> (function($) { $(document).ready(function () {";
	$listdata .= $jsdata;
	$listdata .= $jsdata_second;
	$listdata .= $jsdata_third;
	$listdata .= "$('.datepicker').datepicker({changeMonth: true,changeYear: true});";
	$listdata .= "});})(jQuery);	</script>";

} catch ( ErrorException $e ) {
	$listdata = $e->getMessage();
}

echo $listdata;
?>