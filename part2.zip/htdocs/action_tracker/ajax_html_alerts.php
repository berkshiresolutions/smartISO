<?php    
 
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$docObj 		= new Documents();
$participantObj	= 		SetupGeneric::useModule('Participant');
  $id=$_GET["id"]; 


$docData=$docObj->getDocData($id); 

$type=array('P'=>'Presentation','F'=>'Form','E'=>'Explanation','D'=>'Document')	;	

$document_version_info_html = "<input type='hidden' id='countref' value=".$id.">";
$document_version_info_html .= "<input type='hidden' id='ref' value=".$docData['fileReference'].">";
$document_version_info_html .= "<input type='hidden' id='cmsref' value=".$docData['cmsdocID'].">";
		                $document_version_info_html .= "<table width='100%' cellpadding='2'>";
                        $document_version_info_html .= "<tr>";

                        $document_version_info_html .= "<td width='45%'>File Reference</td>";
                        $document_version_info_html .= "<td width='55%'><a href='javascript: void(0)' class='download_file' rel='".$docData['documentID']. "|" .$docData['title']. "''>";
                        $document_version_info_html .= $docData['fileReference']. "</a></td>";



                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Document Name</td>";
                        $document_version_info_html .= "<td width='55%'><a href='javascript: void(0)' class='download_file' rel='".$docData['documentID']. "|" .$docData['title']. "''>";
                        $document_version_info_html .= $docData['title']. "</a></td>";


                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Document Description</td>";
                        $document_version_info_html .= "<td>" .$docData['description']. "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Document Type</td>";
                        $document_version_info_html .= "<td>"  .$type[$docData['documentType']] ."</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Initiated By</td>";
                        $document_version_info_html .= "<td>"  .$docData['name1'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

//                        version_ext = '';
  //                      if (document_node_information['version_extended'] != undefined && document_node_information['version_extended'] != '') {
    //                        version_ext = document_node_information['version_extended'] + '.';
      //                  }

//                        version_revision_label = 'Version';

//                        if (document_node_information['version_revision'] != undefined && document_node_information['version_revision'] == 'R') {
  //                          version_revision_label = 'Revision';
    //                    }

                        //$document_version_info_html .= "<td>" + version_revision_label + "</td>";
//                        $document_version_info_html .= "<td>" + document_node_information['version_new'] + "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Document Classification</td>";
                        $document_version_info_html .= "<td>" .$docData['classification'] ."</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Date Published/Approved</td>";
                      $document_version_info_html .= "<td>" .$docData['dateApproved'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Published/Approved By</td>";
                        $document_version_info_html .= "<td>" .$docData['name2'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Pages</td>";
                        $document_version_info_html .= "<td>" .$docData['pages'] . "</td>";

                        $document_version_info_html .= "</tr>";



                        $document_version_info_html .= "</table>"; 
						
						$docData=$docObj->getDocumentAlerts($id) ;
	
						$document_version_info_html .= "<table class='cont1' width='100%' cellpadding='4' cellspacing='1'>";
                        $document_version_info_html .= "<tr>";

                        $document_version_info_html .= "<th width='100%' colspan='7' align='center' style='background-color: #ddd; height:25px'>Raised alerts on this document</th>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<th width='15%' style='background-color: #eee' align='left'>Alert by</th>";
                        $document_version_info_html .= "<th width='15%' style='background-color: #eee' align='left'>Comment</th>";
                        $document_version_info_html .= "<th width='15%' style='background-color: #eee' align='left'>Document Uploaded</th>";
                        $document_version_info_html .= "<th width='15%' style='background-color: #eee' align='center'>When</th>";
                        $document_version_info_html .= "<th width='15%' style='background-color: #eee' align='center'>Status</th>";
                        $document_version_info_html .= "<th width='15%' style='background-color: #eee' align='left'>Doc Publisher's Reply</th>";
                        $document_version_info_html .=  "<th width='15%' style='background-color: #eee' align='center'>Action</th>";
						$document_version_info_html .= "</tr>";
					
						foreach($docData as $data){	
							 if ($data['alertStatus'] !='N')
						 		continue;
						 		
						 	    $document_alerts_vad_common_html = "";

                                $document_alerts_vad_common_html .= "<tr>";
                                $document_alerts_vad_common_html .= "<td width='45%'>Alert By</td><td width='55%'>" .$data['name']. "</td>";

                                $document_alerts_vad_common_html .= "</tr><tr>";

                                $document_alerts_vad_common_html .= "<td>Why alert raised?</td><td>".$data['alertComment']. "</td>";

                                $document_alerts_vad_common_html .= "</tr><tr>";

                                $document_alerts_vad_common_html .= "<td>Document Upload</td><td><a href='javascript: void(0)' class='download_file' rel='".$data['documentID']. "|" .$data['usrFilename']."'>".$data['usrFilename']. "</a></td>";

                                $document_alerts_vad_common_html .= "</tr><tr>";

                                $document_alerts_vad_common_html .= "<td>When</td><td>".$data['alertWhen']."</td>";
                                $document_alerts_vad_common_html .= "</tr>";	
						 		
							$document_version_info_html .= "<tr>";	
							$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='left'>" .$data['name']. "</td>";
                        	$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='left'>" .$data['alertComment']. "</td>";
                        	$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='left'><a href='javascript: void(0)' class='download_file' rel='".$data['documentID']. "|" .$data['usrFilename']. "'>" .$data['usrFilename']. "</td>";

                        	$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='center'>" .$data['alertWhen']. "</td>";
                        	$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='center'>" .$data['alertStatus']. "</td>";
                        	$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='left'>" .$data['reply']. "</td>";
                        //$document_version_info_html .= "<td width='15%' style='background-color: #eee' align='center'><a href='javascript: void(0)' class='alert_view' rel='".$data['alertID']. "'>View</a></td>";
						  $document_version_info_html .= "<td width='15%' style='background-color: #eee' align='center'><a href='javascript: void(0)' id='alert_agree".$data['alertID']."' class='alert_agree' rel='".$data['alertID']. "'>Agree</a>&nbsp|&nbsp;";

							   
								$document_version_info_html .= "<a href='javascript: void(0)' id='alert_disagree".$data['alertID']. "' class='alert_disagree' rel='".$data['alertID']. "'>Reject</a></TD>";
							$document_version_info_html .= "</tr>";
							
							///new items
							
							// agree block




				
							
							
							
                                $document_version_info_html1 .= "<div class='cont3 cont3_" .$data['alertID']. " ehsFormFull' style='display:none'>";
                                $document_version_info_html1 .= "<table width='100%'>";
                                $document_version_info_html1 .= "<tr><th width='100%' colspan='2' align='center' style='background-color: #ddd; height:25px'>Document</th></tr>";

                                $document_version_info_html1 .=  "</tr>";

                                $document_version_info_html1 .=  $document_alerts_vad_common_html;

                                $document_version_info_html1 .= "</table>";

                                $document_version_info_html1 .= "<ul>";

                                $document_version_info_html1 .= "<li><p><label for='alert_comment'>Reason why the Alert was agreed?</label>";
                                $document_version_info_html1 .= "<textarea class='mandatory' name='alert_comment' id='alert_comment_agree_" .$data['alertID']."' rows='2' cols='47'></textarea></p></li>";
                                
                                $document_version_info_html1 .= "<li><p>Agree - This means that the alert raised has been accepted and that appropriate action WILL be taken even if this means taking any submitted document and updating it and then replacing existing document in the DMS";
								$document_version_info_html1 .= "</p></li>";
								$document_version_info_html1 .= "<li><p>Accept and Replace - This means that not only is the alert accepted but also that the document supplied as a replacement will be uploaded to document control as would be the case of an update action";
								$document_version_info_html1 .= "</p></li>";
							  
							  

							  $document_version_info_html1 .= "</ul>";
							 

							if($data['usrFilename'] == ''){
								$document_version_info_html1 .= "<div  class='agre'  style='border:0px solid red;padding-left:620px;'>";
								$document_version_info_html1 .= "<ul >";
								$document_version_info_html1 .=  "<li    style='font-size:11px;'><a href='javascript: void(0)' style='font-family: verdana;'   class='alert_save_agree' rel='" .$data['alertID']. "'><b>Agree</b></a>&nbsp;&nbsp;&nbsp;<a href='javascript: void(0)' class='alert_listing' style='font-family: verdana;'   rel='" .$data['alertID']."'><b>Back</b></a></li>";
							 

							
							}else{
							  $document_version_info_html1 .= "<div  class='agre'  style='border:0px solid red;padding-left:500px;'>";
                                                             $document_version_info_html1 .= "<ul>";  

                                
									$document_version_info_html1 .=   "<li  style='font-size:11px'><input type='hidden' name='ref' id='ref' value='".$data['file_reference']."' /><a href='javascript: void(0)' style='font-family: verdana; ' class='alert_save_agree' rel='" .$data['alertID']. "' alt='".$data['documentID']. "|" .$data['usrFilename']. "'  \"><b>Accept & Replace</b></a>&nbsp;&nbsp;&nbsp;<a href='javascript: void(0)' style='font-family: verdana;' class='alert_save_agree' rel='" .$data['alertID']. "'><b>Agree</b></a>&nbsp;&nbsp;&nbsp;<a href='javascript: void(0)' style='font-family: verdana;' class='alert_listing' rel='" .$data['alertID']. "'><b>Back</b></a></li>";
							}		
								$document_version_info_html1 .= "</ul>";
                                                                $document_version_info_html1 .= "</div>";
                                $document_version_info_html1 .= "</div>";
                                // agree block ends
                                // disagree block
                                $document_version_info_html1 .= "<div class='cont4 cont4_" .$data['alertID']. " ehsFormFull' style='display:none'>";
                                $document_version_info_html1 .= "<table width='100%'>";
                                $document_version_info_html1 .= "<tr><th width='100%' colspan='2' align='center' style='background-color: #ddd; height:25px'>Disagree with alert on this document</th></tr>";
                                $document_version_info_html1 .= "</tr>";

                                $document_version_info_html1 .= $document_alerts_vad_common_html;
                                $document_version_info_html1 .= "</table>";


                                $document_version_info_html1 .= "<ul>";

                                $document_version_info_html1 .= "<li><p><label for='alert_comment'>Reason why the Alert was rejected?</label>";
                                $document_version_info_html1 .= "<textarea class='mandatory' name='alert_comment' id='alert_comment_disagree_" .$data['alertID']."' rows='2' cols='47'>" .$data['reply']. "</textarea></p></li>";
                               $document_version_info_html1 .= "</ul>";
							   $document_version_info_html1 .= "<div class='agre' style='border:0px solid red;padding-left:620px;padding-top:160px;' class='smartLightBoxContainerButtons'>";
							   $document_version_info_html1 .= "<ul>";

                                 $document_version_info_html1 .= "<li style='font-size:11px;'><a href='javascript: void(0)'  style='font-family: verdana;' class='alert_save_disagree' rel='" .$data['alertID'].  "'><b>Reject</b></a>&nbsp;&nbsp;&nbsp;<a href='javascript: void(0)' style='font-family: verdana;'  class='alert_listing' rel='" .$data['alertID']. "'><b>Back</b></a></li>";
                                $document_version_info_html1 .= "</ul>";
                                $document_version_info_html1 .= "</div>";
                                  $document_version_info_html1 .= "</div>";
                                // disagree block ends
                           
							
							//end newitems
							
							
							
							}

                        $document_version_info_html .= "</table>".$document_version_info_html1;
                        echo $document_version_info_html;
                        
?>