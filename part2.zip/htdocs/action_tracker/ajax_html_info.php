<?php    
 
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$docObj 		= new Documents();
$participantObj	= 		SetupGeneric::useModule('Participant');
  $id=$_GET["id"];
$docData=$docObj->getDocData($id); 

$docCont=$docObj->getDocumentContributors($id); 

$type=array('P'=>'Presentation','F'=>'Form','E'=>'Explanation','D'=>'Document')	;	


		        $document_version_info_html = "<table width='100%' cellpadding='2'>";
                        $document_version_info_html .= "<tr>";

                        $document_version_info_html .= "<td width='45%'>File Reference</td>";

                        $document_version_info_html .= "<td width='55%'><a href='/documents/download.php?src=".$docData['documentID']."&name=".$docData['title']."''>" ;
 
                        $document_version_info_html .= $docData['fileReference']. "</a></td>";

                        
                        $document_version_info_html .= "</tr><tr>";
                        $document_version_info_html .= "<td>Document Name</td>";
                        $document_version_info_html .= "<td><a href='/documents/download.php?src=".$docData['documentID']."&name=".$docData['title']."''>" .$docData['title'] . "</a></td>";

                        $document_version_info_html .= "</tr><tr>";
                        
                        $document_version_info_html .= "<td>Document Description</td>";
                        $document_version_info_html .= "<td>" .$docData['description']. "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Document Type</td>";
                        $document_version_info_html .= "<td>"  .$type[$docData['documentType']] ."</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Initiated By</td>";
                        $document_version_info_html .= "<td>"  .$docData['name1'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

//                        version_ext = '';
  //                      if (document_node_information['version_extended'] != undefined && document_node_information['version_extended'] != '') {
    //                        version_ext = document_node_information['version_extended'] + '.';
      //                  }

//                        version_revision_label = 'Version';

//                        if (document_node_information['version_revision'] != undefined && document_node_information['version_revision'] == 'R') {
  //                          version_revision_label = 'Revision';
    //                    }

                        //$document_version_info_html .= "<td>" + version_revision_label + "</td>";
//                        $document_version_info_html .= "<td>" + document_node_information['version_new'] + "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Document Classification</td>";
                        $document_version_info_html .= "<td>" .$docData['classification'] ."</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Date Published/Approved</td>";
                        if ($docData['dateApproved']== '1900-01-01')
                            $document_version_info_html .= "<td> - </td>";
                        else
                      $document_version_info_html .= "<td>" .$docData['dateApproved'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Published/Approved By</td>";
                        $document_version_info_html .= "<td>" .$docData['name2'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td>Pages</td>";
                        $document_version_info_html .= "<td>" .$docData['pages'] . "</td>";

                        $document_version_info_html .= "</tr><tr>";

                        $document_version_info_html .= "<td colspan='2'>Contributor's Comments</td>";

                        $document_version_info_html .= "</tr>";

					if ($docCont){
                         foreach($docCont as $datac) {

                           $document_version_info_html .= "<tr>";
																				
                            $document_version_info_html .= "<td>" .$datac['name'] . "</td>";
                            $document_version_info_html .= "<td>" .$datac['comments'] . "</td>";

                            $document_version_info_html .= "</tr>";
                       }
}
                        $document_version_info_html .= "</table>";
                        echo $document_version_info_html;
                        
?>