<?php
 /**
  $Id: doc_control.php,v 3.52 Saturday, January 29, 2011 3:14:17 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:23:04 PM>
  */

 // load jquery script file

$_PAGE_VALIDATION_SCRIPT 	= 'documents/index.js';
$_PAGE_VALIDATION_SCRIPT2 	= '../jquery.jtree.js';

$_PAGE_POPUP_WINDOW 		= 'popWindowDocumentRejectComment';

$class_doc_control = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "doc control"; // for current breadcrums

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

//$default_standard			= 11; // CMS 9k default tab
$default_standard			= 52; // !MS SL default tab
$tree_context				= 'action_tracker';
$xmlfile 					= 'documents.xml';

echo "<link rel='stylesheet' type='text/css' href='/themes/default/css/jtree.css'>";

$smarty->assign('default_standard',$default_standard);
$smarty->assign('tree_context',$tree_context);

$smarty->display('action_tracker/doc_control.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>