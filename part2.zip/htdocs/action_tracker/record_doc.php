<?php
/**
 $Id: record_insp_ccp.php,v 3.39 Thursday, February 03, 2011 12:37:42 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Inspection(CCP) - Assigned to me(pending) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Tuesday, September 21, 2010 6:33:47 PM>
*/

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


try {

	$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$tab_type,$filter_date);
	$resultset = $actTrackObj->getActionsForActionTracker();

	$listdata = "<form class='action_tracker_listing' name='risk_form' method='post'>";
	$listdata .= "<table class='display' id='module_records'><thead><tr>
				<th width='13%'>Business Unit</th>
				<th width='12%'>Reference No.</th>
				<th width='16%'>Step</th>
				<th width='16%'>Action</th>
				<th width='10%'>Due Date</th>";



	$listdata .= "</tr></thead><tbody>";



	foreach ( $resultset as $resultElement ) {


		$listdata .= "<tr>";
		$listdata .= "<td>".$resultElement['buName']."</td>";
		$listdata .= "<td>".$resultElement['reference']."</td>";
		$listdata .="<td>".$resultElement['step']."</td>";

		$listdata .= "<td>";
		$listdata .= "<a href='javascript:void(0)' class='showaction' rel='".$ac_id."'>".$action_description."</a>";
		$listdata .= "</td>";

		$listdata .="<td>".format_date($resultElement['dueDate'])."</td>";

		}

		
		$listdata .= "</tbody><tfoot><tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>";


	$listdata .= "</tr></tfoot></table></form>";
	$listdata .= "<div class='footnote'><b>Note :</b> To view full Action, click the corresponding box.</div>";


} catch ( ErrorException $e ) {
	$listdata = $e->getMessage();
}

echo $listdata;
?>