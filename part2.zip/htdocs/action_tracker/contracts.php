<?php
/**
 $Id: manual_hand_env.php,v 3.11 Friday, November 26, 2010 4:52:21 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Manual Handling(Environmental) - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Monday, September 27, 2010 6:53:33 PM>
*/

// load jquery validation script file
//$_PAGE_VALIDATION_SCRIPT = 'action_tracker/manual_hand_env.js';
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/contracts.js';

$class_contracts = "selected_tab"; //current tab
$LAST_BREAD_CRUM = "Contracts"; // for current breadcrumbs

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

//$smarty->display('action_tracker/manual_hand_env.tpl');
$smarty->display('action_tracker/contracts.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>