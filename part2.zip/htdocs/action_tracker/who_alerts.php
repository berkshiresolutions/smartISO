<?php
 /**
  $Id: replace_document.php,v 3.74 Thursday, January 20, 2011 4:14:14 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/who_alerts.js';
$_PAGE_VALIDATION_SCRIPT2 = 'common_script.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';

//echo	$document_id = (int) $_GET['document_id'];
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

$actTrackObj = new ActionTracker();
$actObj = new Action();

$actionId = $_POST['alert_id'];
$done_date = format_date_for_mysql(strip_tags($_POST['done_date']));
$comment = strip_tags($_POST['reason_replace']);
$action_type = strip_tags($_POST['action_type']);
$action = "A ".strip_tags($_POST['action']);
$action_str = strip_tags($_POST['action_str']);
$not_complete = $_POST['not_complete'];

if (strip_tags($_POST['action'])=='BCP'){
	$bcpObj = new BCPMain();
       
	$bcpObj->notifyBIAlert($actionId);
}

try {
            $optionObj = new Option();
$level= getUserAccessLevel();
$adminClose= $optionObj->getOption('_SU_ADMIN_CLOSE');
$actObj->updatehistory($actionId);

if ($level== 1 && $adminClose == 1){
 	$actTrackObj->saveActionInformationAdmin($actionId, $done_date, $comment,$action,$action_str,$not_complete);   
}else{
 	$actTrackObj->saveActionInformation2($actionId, $done_date, $comment,$action,$action_str,$not_complete,"Actioned");   
}


		} catch (ErrorException $e) {
			echo $e->getMessage();
		}
	

	echo 1;

	$smarty->assign('js',1);
	$smarty->assign('e',2);

} else {

	
        $alert_id 	= (int) $_GET['alert_id'];
        
        $alert_type 	= explode("|", $_GET['act_type']);
        if ($alert_type[2]){
            $classname=$alert_type[2];
            $class=new $classname();
          
        $row=$class->getCompleteActionData($alert_id);
        $smarty->assign('row',$row);
        }
	$smarty->assign('alert_id',$alert_id);
        $smarty->assign('action',$alert_type[0]);
        $smarty->assign('action_str',$alert_type[1]);
}

$smarty->display('action_tracker/who_alerts.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';