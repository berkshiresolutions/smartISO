<?php
 /**
  $Id: save_action_information.php,v 3.83 Monday, December 13, 2010 4:13:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * for testing purpose only
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Monday, August 16, 2010 11:24:04 AM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$objRiskAssessment 	= new RiskAssessment();

$actionId 		= (int) $_GET['action_id'];
$objRiskAssessment->setRiskInfo(0,array('action_id'=>$actionId));
		
try {
	
	$objRiskAssessment->eliminateHazard();

	echo 1;
} catch ( ErrorException $e ) {
	echo $e->getMessage();
}
?>