<?php
 /**
  $Id: fetched.php,v 3.09 Tuesday, December 21, 2010 3:12:25 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage
  * @since  Tuesday, December 21, 2010 2:53:36 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$partObj = SetupGeneric::useModule('Participant');
$data = $partObj->displayPublishData1();

/*
if($data){
			
				foreach ($data as $key1 => $value1){
					foreach ($data as $key2 => $value2){
						
							if($data[$key1]['participantID'] == $data[$key2]['participantID'] && $key1 != $key2){
					
								$data[$key2]['value']+=$data[$key1]['value'];
								$key2 = $key1;
								
								unset($data[$key1]);
							
								
						}
					}
				
				}
			
		   }

/*
[participantID] => 5
[uniqueReference] => WN10102307
[worksNumber] => WN10102304
[username] => WN10102304
[passwd] => 514b8174ae32b81733993887a4afbc11
[forename] => aaaaaaaa
[surname] => aaaaaaa
*/

$json_data = array();

if ( count($data) ) {

	$k = 0;
	foreach ( $data as $rec ) {

		if ( !$rec['active'] &&	$rec['accessLevel'] == 3 ) {
			continue;
		}

		$json_data[$k]['caption'] = ucfirst($rec['forename'])." ".ucfirst($rec['surname'])." - ".$rec['worksNumber'];
		$json_data[$k]['value'] 	= $rec['participantID'];

		$k++;
	} // end foreach
} // end if

echo json_encode($json_data);
?>