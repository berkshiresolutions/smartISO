<?php
 /**
  $Id: doc_control_status.php,v 3.02 Thursday, September 16, 2010 10:44:33 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  * This file is for editing the document - status under
  * doc control section.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Thursday, September 16, 2010 10:43:14 AM>
  */

$cid = (int) $_GET['cid'];

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$smarty->display('action_tracker/doc_control_status.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>