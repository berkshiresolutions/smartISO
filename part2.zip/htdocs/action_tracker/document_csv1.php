<?php
 /**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <gurnam_84@hotmail.com>
  * @package Smartiso
  * @subpackage Equipment
  * @since  Friday, January 14, 2011 5:44:40 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];

/*
header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=document.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

$fn = fopen('document.xls','w');
//$objExport = new ExportData('nhpactionexport','csv');
//$objExport->downloadFile();

$bcp		=		new ContributorActionExport();
$data = $bcp->getListingforExport();
//dump_array($data);
//exit;
?>
<table cellspacing='0' cellpadding='0' width='100%' border='1'>
	
	<tr style='border: 1px solid;background: #360036;color: #fff;font-weight:bold;font-family:arial,sans-serif;'>
	
	<td >Section Reference</td>
	<td>Document</td>

	
	</tr>
	<?php 
	foreach($data as $v){
	?>
	<tr style='border: 1px solid;'>
	
	<td ><?php echo $v['section']; ?></td>
	<td><?php echo $v['document']; ?></td>
	
	
	</tr>
	<?php 
	}
	?>
	</table>
	<?php

fclose($fn);

*/



require_once dirname(__FILE__) . '/../php_excel/Classes/PHPExcel.php';
// Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
// Set document properties
    $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
    
    

   $optObj = new Option();

    $selected_grp = $optObj->getOption('_SU_GRP_POLICY');
   
    $objPHPExcel->getActiveSheet()
            ->getStyle('A1:O1')
            ->applyFromArray(
                    array(
                        'fill' => array(
                            'type' => PHPExcel_Style_Fill::FILL_SOLID,
                            'color' => array('rgb' => '7E3C92')
                        )
                    )
    );
   
        $styleArray = array(
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF')
    ));
$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];

$USER_ID = getLoggedInUserId();
$grp = $USER_ID==$selected_grp ? true : false;

$level = getUserAccessLevel();
$action_tracker_module_name = 'Documents';

if ($level == 1) {
    $is_admin = true;
}


$docObj = new Documents();

$scopeObj = SetupGeneric::useModule('DocScope');
$scopeArr = $scopeObj->displayItems();

$scope[0]="&nbsp;-&nbsp;";
        foreach ($scopeArr as $scope_ele ) {
                
                $scope[$scope_ele["ID"]]="[".$scope_ele['scope']."]";
  
        }

$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$data = $docObj->getDocumentListActionTracker();


    
$headerStyle = array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '360036'),
            'border' => false,
        ),
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF'),
        )
    );
    $borderStyle = array('borders' =>
        array('outline' =>
            array('style' => PHPExcel_Style_Border::BORDER_THICK,
                'color' => array('argb' => '360036'),),),);

    $rowCount = 1;
    $customTitle = array('Nature of Injury ');

    
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, 'Reference')
            ->SetCellValue('B' . $rowCount, 'Document')
            ->SetCellValue('C' . $rowCount, 'Actions');

    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($headerStyle);
    $borderColumn = (intval($column) - 1 );
    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($borderStyle);

    $i = 2;
    if ($data) {
        foreach ($data as $document) {
        foreach ($document as $documentItem) {

            
            
       if (!$grp && $documentItem['documentSubType'] == "G")
            continue;
        $document_code_info = $docObj->getSectionByStandardAndCode('52', $documentItem['fileReference']);
        $rel = $documentItem['cmsdocID'];
        $section_ref = $document_information['fileReference'] . " " . $document_code_info['name'];

        if ($documentItem['documentSubType'] == "W")
            $document = '[WI]';
        elseif ($documentItem['documentSubType'] == "G")
            $document = '[GP]';
        else
            $document = '[' . $documentItem['documentType'] . '] ';

        $document .= $scope[$documentItem['scope']] . ''. $documentItem['title'] . '  Ver  ' . $documentItem['versionNew'];

        if ($version_type == 'minor_version')
            $document .= "." . intval($documentItem['versionMinor']) . '';
        else
            $document .= '';



        $contributors = $docObj->getDocumentContributors($rel);
        $document_status = "";
        if ($contributors) {

            $contributor_replied_a = 0;
            $contributor_replied_na = 0;
            $contributor_replied = 0;
            $contributor_count = count($contributors);

            foreach ($contributors as $contributor) {
                switch ($contributor['passed']) {
                    case 1: $contributor_replied_a++;
                        $contributor_replied++;
                        break;
                    case 2: $contributor_replied_na++;
                        $contributor_replied++;
                        break;
                }
            }

            if ($contributor_replied == 0) {

                $document_status = "Wait for Contributors's response";
            } else if ($contributor_replied < $contributor_count) {

                $document_status = "Sent to contributors";
            } else if ($contributor_replied == $contributor_replied_a) {

                $document_status = "Approved by contributors";
               
            } else {
                $document_status = "Not approved by contributors";
            }

            
        } else {
            $document_status="Send For Contribution";
        }

        $objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $documentItem['fileReference'])
                    ->setCellValue('B' . $i, $document)                  
                    ->setCellValue('C' . $i, $document_status);
              $i++;             
              
        }
    }
    }
   
//$objPHPExcel->getActiveSheet()->getColumnDimension('A:C')->setAutoSize(false);
$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth("12");
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth("25");
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth("35");


$objPHPExcel->getActiveSheet()->getStyle('A1:C1')->applyFromArray($styleArray);

    $objPHPExcel->getActiveSheet()->setTitle('Simple');
    $objPHPExcel->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="document.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); 
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); 
    header('Cache-Control: cache, must-revalidate'); 
    header('Pragma: public'); 
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;   




//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>