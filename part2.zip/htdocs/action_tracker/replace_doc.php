<?php

/**
  $Id: replace_document.php,v 3.74 Thursday, January 20, 2011 4:14:14 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Documents
 * @since  Thursday, November 11, 2010 1:22:46 PM>
 */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/replace_doc.js';

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$docObj = new Documents();
$participantObj	= 		SetupGeneric::useModule('Participant');
//echo	$document_id = (int) $_GET['document_id'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//echo	$document_id = (int) $_GET['document_id'];



    $document['file_info'] = $_FILES['file'];

    if ($_POST['document_class'] == 'CONFIDENTIAL') {

        $c = 'C';
    }
    if ($_POST['document_class'] == 'UNCLASSIFIED') {

        $c = 'U';
    }
    if ($_POST['document_class'] == 'SECRET') {

        $c = 'S';
    }
    if ($_POST['document_class'] == 'RESTRICTED') {

        $c = 'R';
    }
    if ($_POST['document_class'] == 'TOP_SECRET') {

        $c = 'T';
    }

    $document['path_id'] = $_POST['path_id'];
    $document['doc_id'] = $_POST['doc_id'];
    $document['check_type'] = $_POST['alerttype'];
    $document['version'] = $_POST['version'];
    $document['version_minor'] = $_POST['version_extended'];
    $document['version_old'] = $_POST['version_old'];

    $document['document_class'] = $c;
    $document['business_unit'] = $_POST['business_unit'];
    $document['version_notes'] = $_POST['version_notes'];
    $document['pages'] = $_POST['pages'];
    $document['altStd'] = 9;
    $document['STOWcode'] = $_POST['stow'];

    $document['reason_for_update'] = $_POST['reason_replace'];
    $document['file_reference'] = $_POST['file_reference'];
    //if ($_POST['path_name']) {
    //    $document['document_name'] = $_POST['path_name'];
    //} else {
        $document['document_name'] = $_POST['document_name'];
    //}
    $document['document_description'] = $_POST['document_description'];
    $document['document_type'] = $_POST['document_type'];
    $document['scope'] = $_POST['scope'];
    $document['date_initiated'] = $_POST['date_initiated'];
    $document['initiated_by'] = $_POST['initiated_by_hidden'];
    //$documemt['v']			= 
    $document['action_summary'] = '';

    if (empty($document['check_document'])) {
        $document['check_document'] = 'N';
    }


    $action = 'Updated';

    $docObj->documentRecordHistory($document['doc_id'], $action);

    $docObj->setDocumentInfo($document);


    $doc_upload_id = $docObj->uploadDocument();

    if ($doc_upload_id != 0) {
        $updObj = new Upload();
        $updObj->setFileInfo('documents', array('id' => $doc_upload_id));
        $file_details = $updObj->getFileDetails();

        $file = _PATH_PUB . 'documents/' . $file_details['sysFilename'];
    }
//$docObj->authorizeDocument($doc_upload_id, date("Y-m-d"), getLoggedInUserId()) ;
    $docObj->updateArchiveA($_POST['doc_id']);

    if ($_POST['path_id']) {

        $url = basename($_SERVER['PHP_SELF']) . "?js=3&e=2";
    } else {
        $url = basename($_SERVER['PHP_SELF']) . "?js=1&e=2";
    }


    redirection($url);
}

$js = (int) $_GET['js'];
$e = (int) $_GET['e'];
$u = (int) $_GET['u'];

if ($js) {

    $smarty->assign('js', $js);
    $smarty->assign('e', $e);
} else {

    $orgObj = SetupGeneric::useModule('Organigram');
    $docClassObj = SetupGeneric::useModule('DocClassification');
    $documentObj = new Documents();
        $scopeObj = SetupGeneric::useModule('DocScope');
    $miscObj = new Misc();

    $optObj = new Option();
    $version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
    
    
    $doc_id = (int) $_GET['document_id'];
    $version_data = '';
    $doc_class_options = '';
    $row_data = array();


    $document_classification = $docClassObj->displayItems1();

        
    $document_information = $docObj->getDocumentInformation($doc_id);
    $document_types = $miscObj->getDocumentTypes();

    $row_data['doc_id'] = $doc_id;


    $row_data['version_new'] = $document_information['versionNew'];
    $row_data['version_minor'] = intval($document_information['versionMinor']);
   if ($version_type == 'minor_version')
        $row_data['version_old'] = $row_data['version_new'] . "." . $row_data['version_minor'];
    else
        $row_data['version_old'] = $row_data['version_new'];

    $row_data['file_reference'] = $document_information['fileReference'];
    $row_data['document_name'] = $document_information['title'];
    $row_data['document_desc'] = ucfirst($document_information['description']);
    $row_data['document_type_long'] = $document_types[$document_information['documentType']];
    $row_data['document_type'] = $document_information['documentType'];
    $row_data['document_subtype'] = $document_information['documentSubType'];
    $row_data['pages'] = $document_information['pages'];
    $row_data['buID'] = $document_information['buID'];
    $row_data['reference'] = $document_information['reference'];
    $row_data['doc_control'] = $document_information['docControl'];
    $row_data['date_initiated'] = $document_information['dateInitiated'];
    $row_data['initiated_by_part'] = $document_information['initiatedByParticipant'];
    $row_data['standard_id'] = $document_information['standardID'];
    $row_data['is_gap_document'] = $document_information['isGapDocument'];
    $row_data['documentID'] = $document_information['documentID'];
    $row_data['classification'] = $document_information['classification'];
    $row_data['alerttype'] = substr($document_information['alertType'], 0, 6) == 'change' ? $document_information['alertType'] : 'alert';
    $row_data['scope'] = $document_information['scope'];
    $selected_standards = $optObj->getOption('_SU_STANDARDS_CHOOSEN');
    $stdArr = explode("~", $selected_standards);

    if (in_array(9, $stdArr)) {
        $STOW = true;
        $stow_data = $documentObj->getSTOWList($row_data['file_reference']);
    } else
        $STOW = false;
    
     $scopeArr = $scopeObj->displayItems();
    
        $scope .= "<option value=''>-- Select --</option>";

        foreach ($scopeArr as $scope_ele ) {

            $selclass = $scope_ele["ID"] == $row_data['scope'] ? " selected " : "";

           
                $scope .= "<option value='" . $scope_ele["ID"] ."' ".$selclass.">" . $scope_ele['scope'] . "</option>";
           
        }
    
    $business_units = $orgObj->getBusinessUnits($row_data['buID']);

    $checkr['td'] = $row_data['document_type'] == 'D' ? 'checked' : '';
    $checkr['tp'] = $row_data['document_type'] == 'P' ? 'checked' : '';
    $checkr['te'] = $row_data['document_type'] == 'E' ? 'checked' : '';
    $checkr['tf'] = $row_data['document_type'] == 'F' ? 'checked' : '';

    $checkr['sp'] = $row_data['document_subtype'] == 'P' ? 'checked' : '';
    $checkr['sw'] = $row_data['document_subtype'] == 'W' ? 'checked' : '';
    $checkr['sy'] = $row_data['document_subtype'] == 'Y' ? 'checked' : '';
    $checkr['sr'] = $row_data['document_subtype'] == 'R' ? 'checked' : '';

    if ($document_classification) {

        $doc_class_options .= "<option value=''>-- Select --</option>";

        foreach ($document_classification as $document_class_ele => $document_class_val) {

            //dump_array($document_class_val);

            if ($document_class_val['action'] == 'Active') {

                $selclass = substr($document_class_ele, 0, 1) == $row_data['classification'] ? "selected" : "";


                $doc_class_options .= "<option value='" . $document_class_ele . "' " . $selclass . ">" . $document_class_val['opValue'] . "</option>";
            }
        }
    }

//{*had to swap in prog because of how written originally*]
    if ($version_type == 'minor_version') {
        $anum = is_numeric($row_data['version_new']) ? $row_data['version_new'] : 0;
        //$version_data .= "<option value='0'>--</option>";
        $version_data .= "<option value='" . $anum . "' selected>" . $anum . "</option>";
        for ($i = 0; $i < 20; $i++) {
            $anum++;
            $version_data .= "<option value='" . $anum . "'>" . $anum . "</option>";
        }
        $anum = is_numeric($row_data['version_minor']) ? $row_data['version_minor'] : 0;
        //$version_data .= "<option value='0'>--</option>";
        $version_datamin .= "<option value='" . $anum . "'>" . $anum . "</option>";
        for ($i = 0; $i < 20; $i++) {
            $anum++;
            if ($i == 0)
                $version_datamin .= "<option value='" . $anum . "' selected>" . $anum . "</option>";
            else
                $version_datamin .= "<option value='" . $anum . "'>" . $anum . "</option>";
        }
        $version_type_text = 'version';
    }


    if ($version_type == 'version') {
        $anum = is_numeric($row_data['version_new']) ? $row_data['version_new'] : 0;
        //$version_data .= "<option value='0'>--</option>";
        $version_data .= "<option value='" . $anum . "'>" . $anum . "</option>";
        for ($i = 0; $i < 20; $i++) {
            $anum++;
            if ($i == 0)
                $version_data .= "<option value='" . $anum . "' selected>" . $anum . "</option>";
            else
                $version_data .= "<option value='" . $anum . "'>" . $anum . "</option>";
        }
        $version_type_text = 'version';
    }

    if ($version_type == 'revision') {
        $anum = is_numeric($row_data['version_new']) ? "A" : $row_data['version_new'];
        //$version_data .= "<option value=''>--</option>";
        $version_data .= "<option value='" . $anum . "'>" . $anum . "</option>";
        for ($i = 0; $i < 20; $i++) {
            $anum++;
            if ($i == 0)
                $version_data .= "<option value='" . $anum . "' selected>" . $anum . "</option>";
            else
                $version_data .= "<option value='" . $anum . "'>" . $anum . "</option>";
        }

        $version_type_text = $version_type;
    }

    $path = $_GET['path'];
    if ($path) {
        $row_data['file_reference'] = strip_tags($_GET['code']);
        $row_data['file_reference'] = str_replace('_', '.', $row_data['file_reference']);

        $path = explode("|", $path);
        //echo $path['0'];

        $path_ex = explode(".", $path['1']);
        //echo $path_ex['1'];
        //echo $_SERVER['DOCUMENT_ROOT'];
        $full_path = $_SERVER['DOCUMENT_ROOT'] . "/pub/documents/sys_documents_" . $path['0'] . "." . $path_ex['1'];
    }


    $smarty->assign('path_id', $path['0']);
    $smarty->assign('path_name', $path['1']);
    $smarty->assign('full_path', $full_path);
    //dump_array($row_data);

    $id = getLoggedInUserId();
    $participantObj->setItemInfo(array('id' => $id));

    $data = $participantObj->displayDoc();
//dump_array($data);
    $name = $data['forename'] . ' ' . $data['surname'];

    $smarty->assign('id', $id);
    $smarty->assign('name', $name);
    $smarty->assign('document_classification', $doc_class_options);
    $smarty->assign('row_data', $row_data);
    $smarty->assign('u', $u);
    $smarty->assign('post_script_name', 'replace_doc.php');
    $smarty->assign('business_units', $business_units);
    $smarty->assign('version_type', ucfirst(str_replace('_', ' ', $version_type)));
    $smarty->assign('version_type_text', ucfirst($version_type_text));
    $smarty->assign('version_data', $version_data);
    $smarty->assign('version_datamin', $version_datamin);
    $smarty->assign('checkr', $checkr);
    $smarty->assign('scope', $scope);
    $smarty->assign('STOW', $STOW);
    $smarty->assign('stow_data', $stow_data);
}

$smarty->display('action_tracker/replace_doc.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
