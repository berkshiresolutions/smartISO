<?php
/**
 $Id: non_conf_inc.php,v 3.15 Tuesday, February 01, 2011 12:23:59 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Non-conformance(Incidence) - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Thursday, September 23, 2010 4:33:34 PM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/equipment_main.js';

if (isset($_GET['menu']) && (int)$_GET['menu'] == 2)
$class_viewatt = "selected_tab"    ;
else 
$class_viewat = "selected_tab"    ;
$LAST_BREAD_CRUM = "Asset Mainteance"; // for current breadcrumbs

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

 $filter_date = $_GET['filter_date'];
  $fil = explode(".", $filter_date);
  $smarty->assign('type_v',$fil[1]);

$smarty->display('action_tracker/equipment_main.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>