<?php
 /**
  $Id: calendar.php,v 3.38 Thursday, February 03, 2011 2:41:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Saturday, December 18, 2010 8:21:06 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$output = '';
$month = $_GET['month'];
$year = $_GET['year'];
$sel_day = $_GET['sel_day'];

$count_update = $_GET['count_update'];

if($month == '' && $year == '') {
	$time = time();
	$month = date('n',$time);
    $year = date('Y',$time);
}

$date = getdate(mktime(0,0,0,$month,1,$year));
$today = getdate();
$hours = $today['hours'];
$mins = $today['minutes'];
$secs = $today['seconds'];

if(strlen($hours)<2) $hours="0".$hours;
if(strlen($mins)<2) $mins="0".$mins;
if(strlen($secs)<2) $secs="0".$secs;

$days=date("t",mktime(0,0,0,$month,1,$year));
$start = $date['wday']+1;
$name = $date['month'];
$year2 = $date['year'];
$offset = $days + $start - 1;

if($month==12) {
	$next=1;
	$nexty=$year + 1;
} else {
	$next=$month + 1;
	$nexty=$year;
}

if($month==1) {
	$prev=12;
	$prevy=$year - 1;
} else {
	$prev=$month - 1;
	$prevy=$year;
}

if ($sel_day!=undefined)
{
	$show_day	= $sel_day;
}
elseif ($name==$today[month])
{
	$show_day	= $today[mday];

}

if($offset <= 28) $weeks=28;
elseif($offset > 35) $weeks = 42;
else $weeks = 35;


$output .= "<table cellspacing='1' border='0' cellpadding='2' width='250'>
<tr class='calhead' style='background-color:#003399'>
	<td style=\"text-align:center\"><a href='javascript:navigate($prev,$prevy,1)'><img src='/images/calLeft.gif' alt='Next Month' title='Previous Month'></a></td>
	<td colspan='5'><div style=\"text-align:center\">$name $year2</div></td>
	<td style=\"text-align:center\"><a href='javascript:navigate($next,$nexty,1)'><img src='/images/calRight.gif' alt='Next Month' title='Next Month'></a></td>
</tr>
<tr class='dayhead'>
	<td class='day_head'>Sun</td>
	<td class='day_head'>Mon</td>
	<td class='day_head'>Tue</td>
	<td class='day_head'>Wed</td>
	<td class='day_head'>Thu</td>
	<td class='day_head'>Fri</td>
	<td class='day_head'>Sat</td>
</tr>";

$col=1;
$cur=1;
$next=0;

for($i=1;$i<=$weeks;$i++) {
	if($next==3) $next=0;
	if($col==1) $output.="<tr class='dayrow'>";

	if ($cur==$show_day) {
		if ( $count_update ) {
			$bgcolor = "style='background-color: #eeeeee'";
		} else {
			$bgcolor = "style='background-color: #ffffff'";
		}
	} else {
		$bgcolor = "style='background-color: #ffffff'";
	}

	$output.="<td valign='top' $bgcolor onMouseOver=\"this.className='dayover'\" onMouseOut=\"this.className='dayout'\">";

	if($i <= ($days+($start-1)) && $i >= $start) {

		$output.="<div class='day'><b>";

		$output.="<a class='link'";

		$output.="href='javascript: navigate_val($month,$year,$cur)'>$cur</a></b></div></td>";


		//$output.="$cur</b></div></td>";

		$cur++;
		$col++;

	} else {
		$output.="&nbsp;</td>";
		$col++;
	}

    if($col==8) {
	    $output.="</tr>";
	    $col=1;
    }
}

$output.="</table>";

$send_date = $year."-".$month."-".$show_day;

$actTrackObj = new ActionTracker();

//$tabs 			= array('me_pending','other_pending','me_completed','other_completed');
$user_level = getUserAccessLevel();
if ( $user_level == 1 ) {
	$tabs 			= array('me_pending','other_pending');
} else  {
	$tabs 			= array('me_pending');
}


$modules 		= array(
				'risk'=>'risk',
				 'risk27k'=>'risk27k',
				 'dse'=>'DSE',
				 'inspC'=>'inspection ccp',
				 'inspH'=>'inspection hazard',
				 'inspM'=>'inspection management',
				 'inspR'=>'inspection risk',
				 'nonc_inc'=>'Nonconformance inc',
				 'nonc_inv'=>'Nonconformance di',
				 'nonc_nhp'=>'Nonconformance nhp',
				 'cc'=>'complaint',
				 'doc'=>'Doc Control',
				 'cont'=>'Contributor',
				 'manhE'=>'manualhandling env',
				 'manhI'=>'manualhandling ind',
				 'manhL'=>'manualhandling load',
				 'manhT'=>'manualhandling task',
				 'gap'=>'gap',
				 'nhc_inv'=>'NHC Inv');

$output	.= "~|~".$send_date;

$count_update = (int) $count_update;
if ( $count_update ) {
	$check_date = $send_date;
} else {
	$check_date = '';
}

foreach ( $modules as $keyMod=>$valueMod ) {
	$keyMod_count = 0;

	if ( $keyMod == 'cont' || $keyMod == 'doc' ) {

		$actTrackObj->setActionTrackerInfo($valueMod,$tabs[0],$check_date);
		$resultset = $actTrackObj->getActionsForActionTracker();

		$keyMod_count = count($resultset);
	} else if ( $keyMod == 'gap' ) {

		$gapObj = new ReviewGap();
		$result	= $gapObj->getGapQuestionActionTracker(true,$check_date);
		$result_other	= $gapObj->getGapQuestionActionTracker(false,$check_date);

		$keyMod_count =  count($result) + count($result_other);

	} else {
		foreach ( $tabs as $valueTab ) {

			$actTrackObj->setActionTrackerInfo($valueMod,$valueTab,$check_date);
			$resultset = $actTrackObj->getActionsForActionTracker();

			$keyMod_count += count($resultset);
			//echo "--";
		}
	}

	//$output	.= "~|~".$keyMod.':'.$keyMod_count;
	$output	.= "~|~".$keyMod_count;
}

$output	.= "~|~".$count_update."~|~".$check_date;

echo $output;

?>
