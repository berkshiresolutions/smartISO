<?php
 /**
  $Id: ajax_action_mail.php,v 3.15 Tuesday, February 01, 2011 2:39:46 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Anil 
  * @package Smartiso
  * @subpackage Alert Class
  * @since  Saturday, December 04, 2010 4:17:45 PM>
  */
 
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/actionEmail.php';
echo $action_id = (int) $_GET['id'];
 $ref =  $_GET['ref'];
$module_name = strip_tags($_GET['module_name']);

$emailObj =	new actionEmailHelper($action_id);
		//$who=$emailObj->getwhoDetails();
			
			//$sentence=array('sentence'=>array("You have an action to carry out the following risk Action"));	
		//$emailObj->appendInfo($sentence);
			
		//$data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/">CLICK</a> Here to View Risk  Action'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>'')));
			

		//$emailObj->appendInfo($data);
		//$emailObj->sendEmail('A Risk Action To Be Carried Out',$who,array(),array(),'me_completed','','grey');

		$whoAU =$emailObj->getAUDetails();
	
		//$slawdata = $this->getActionsbyID($action_id);

		$sentence=array('sentence'=>array("You have an action to approve the following risk Action"));	
		$emailObj->appendInfo($sentence);
			
		$data=array('singleColData'=>array('click-here-url'=>'Please <a href="http://'.$_SERVER['HTTP_HOST'].'/action_tracker/">CLICK</a> Here to View Risk Action'),'twoColData'=>array('actionid'=>array('left'=>'<strong>Reference</strong>','right'=>$ref)));
			

		$emailObj->appendInfo($data);
		
		//$emailObj->sendEmail('A Risk Action To Be Approved',$whoAU,array(),array(),'me_completed','','grey');

//$emailobj = new SendEmailAction($module_name,$action_id);
//$emailobj->sendMails();
 
?>