<?php
/**
$Id: ajax_update_tracker.php,v 5.15 Saturday, January 29, 2011 12:13:10 PM ehsindia Exp $  *
*
* smart-ISO, Smart Auditing Software Solutions
* http://www.smart-iso.com
* Copyright (c) 2010 smart-ISO
* Released under the Smartiso License
*
*
* Short description
* This file accesses data from the database.
*
* Long description
*
* @author  Gurnam Singh <simurgrai@gmail.com>
* @package Smartiso
* @subpackage Action tracker
* @since  Friday, September 17, 2010 11:51:29 AM>
*/

$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$gapObj = new ReviewGap();

$audit_id 		= (int) $_GET['audit_id'];
$doc_id 		= (int) $_GET['doc_id'];
$question_id 	= (int) $_GET['question_id'];

$gapObj->updateGapTracker($audit_id,$doc_id,$question_id);
