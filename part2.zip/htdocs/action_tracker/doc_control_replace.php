<?php
 /**
  $Id: doc_control_replace.php,v 3.02 Thursday, September 16, 2010 10:43:08 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  * This file is for editing the document under
  * doc control section in management systems.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Thursday, September 16, 2010 10:42:06 AM>
  */

$cid = (int) $_GET['cid'];

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$file_ref = 4.1;
$doc_name = "General Requirements";
$doc_description = "Description";
$doc_type = "Document";
$old_version = 3;

$doc_classification = array(
								1=>"Top Secret",
								2=>"Secret",
								3=>"Confidential",
								4=>"Restricted",
								5=>"Unclassified"
							);

for ($i=1;$i<=9;$i++) {
	$version[$i] = $i;
}

$smarty->assign('cid', $cid);
$smarty->assign('file_ref', $file_ref);
$smarty->assign('doc_name', $doc_name);
$smarty->assign('doc_description', $doc_description);
$smarty->assign('doc_type', $doc_type);
$smarty->assign('old_version', $old_version);
$smarty->assign('doc_classification', $doc_classification);
$smarty->assign('version', $version);
$smarty->display('action_tracker/doc_control_replace.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>