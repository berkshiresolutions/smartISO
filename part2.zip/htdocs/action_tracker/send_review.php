<?php
 /**
  $Id: raise_alert.php,v 3.77 Thursday, January 20, 2011 4:15:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/send_review.js';

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';
$docObj = new Documents();
$docreviewObj = new DocumentReview();
$updObj = new Upload();
$participantObj				 	= SetupGeneric::useModule('Participant');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
var_dump($_POST);
	$document['file_info'] 				= $_FILES['file'];
	$document['doc_id'] 				= $_POST['doc_id'];
	$document['document_comment'] 		= $_POST['document_comment'];
	$document['review_raised_by']		= getLoggedInUserId();
        $document['reviewer'] 				= $_POST['reviewer'];
        $review_id=(int)$_POST["review_id"];
	$docObj->setDocumentInfo($document);
	//$upld_file_id = $docObj->raiseDocumentAlert();
	
	


	$document['email_type'] = 'review';
	
               if ($_POST['filedata']) {
        $fileArr = $_POST['filedata'];
        $fileNameArr = $_POST['filename'];
        foreach($fileArr as $key=>$file) {

            $document["file_id"] = $updObj ->moveNewFile($file, 'documents', $fileNameArr[$key]);
        }
    }
      	$docreviewObj->setReviewInfo($review_id,$document);
$docreviewObj->updateReviewer() ;
         
      
	
	$emailObj = new infoEmailHelper();
	$part_id = $document['alert_raised_by'];
$participantObj->setItemInfo(array('id'=>$part_id));
$partcip = $participantObj->displayItemById();

$attachment=array();
$partt_name = $partcip['forename'].' '.$partcip['surname'];

	if ( $document["file_id"] != 0 ) {


		$updObj->setFileInfo('documents',array('id'=>$document["file_id"]));
		$file_details = $updObj->getFileDetails();
                


		$file = _PATH_PUB.'documents/'.$file_details['sysFilename'];
		//$emailObj->addAttachment($file);
		$attachment=array('name'=>$file_details['usrFilename'],'file'=>$file);
	}

	$document['doc_info'] 					= $docObj->getDocumentInformation($document['doc_id']);
	
	//dump_array($document['doc_info']);
	
	
		 $document_contributors 	= array();


$docclassObj 					= SetupGeneric::useModule('DocClassification');
$document_classification 		= $docclassObj->displayItems();
$optObj							= new Option();
$miscObj 						= new Misc();
$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$document_types 				= $miscObj->getDocumentTypes();
$optObj							= null;
$miscObj 						= null;
$participantObj				 	= SetupGeneric::useModule('Participant');
$objFile						= new Upload();

$document_info 					= $docObj->getDocumentInformation($document['doc_id']);
$meta_info 					= $docObj->getDocumentInformationMetaData($document['doc_id']);
$document_contributors 			= $docObj->getDocumentContributors($document['doc_id']);

$participant_id = $document_info["initiatedByParticipant"];
$participantObj->setItemInfo(array('id'=>$participant_id));
$partcipantData = $participantObj->displayItemById();

$risk27kObj			=		new Risk27k();
//echo $res['initiatedByParticipant'];
$risk27kObj->setRisk27kInfo($participant_id,$data);
$data_email = $risk27kObj	->participantData();


$who = array(
				'displayname' => ucwords($data_email['forename'].' '.$data_email['surname']),
				'email' => $data_email['emailAddress']
		);
	// exit;
$participantObj->setItemInfo(array('id'=>$document_info["initiatedByParticipant"]));
$partcipantData = $participantObj->displayItemById();
$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
$initiated_by 	= $participant_name == ' ' ? '-' : $participant_name;
$part_id = getLoggedInUserId();
$participantObj->setItemInfo(array('id'=>$part_id));
$partData = $participantObj->displayItemById();

$part_name = $partData['forename'].' '.$partData['surname'];
$approve_by 	= $part_name == ' ' ? '-' : $part_name;


$docreviewObj->setReviewProgress($reviewid ,1) ;



$objFile->setFileInfo('contributors',array('id'=>$document_info['documentID']));
$file_detail = $objFile->getFileDetails();


$message = "A Review has been sent to ".$participant_name;
$docObj->saveDocumentLog($document['doc_id'],$message,$document['document_comment']);


//dump_array($document_info);
$version_type = $version_type == 'minor_version' ? 'Version' : $version_type;
$version_type = str_replace('_',' ',$version_type);

$document_info_simple['code'] 			= $document_info['fileReference'];
$document_info_simple['reference'] 		= $document_info['reference'];
$document_info_simple['document']		= "<a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=".$file_detail['sysFilename']."&un=".$file_detail['usrFilename']."&module=contributors','mywindow')\">".$file_detail['usrFilename']."</a>";
$document_info_simple['name'] 			= ucfirst($document_info['title']);
$document_info_simple['description'] 	= ucfirst($document_info['description']);
$document_info_simple['type'] 			= $document_types[$document_info['documentType']];
$document_info_simple['initiated'] 		= format_date($document_info['dateInitiated']);
$document_info_simple['initiated_by'] 	= $initiated_by;
$document_info_simple['version_type']	= ucfirst($version_type);

if ($version_type == 'minor_version'){
    $document_info_simple['version']=$document_info['versionNew'].".".$document_info['versionMinor']; 
}else{
    $document_info_simple['version']=$document_info['versionNew'];
}


$document_info_simple['approved_date']	= $meta_info['dateApproved'];
$document_info_simple['approved_by'] 	= $aprrove_by;
$document_info_simple['action_summary'] = ucfirst($document_info['actionSummary']);
$document_info_simple['pages'] 			= $document_info['pages'];



		   $name		= ucwords($value['forename'].' '.$value['surname']);

		    $subject = "smart-ISO Document Review";
                          $alertStr1="Review to be carried out";
                           $alertStr2="Why review raised?";
    $strL="";
    $strR="";
$mergeData = array(
'twoColData'=>array(
'actionid'=>array('left'=>'<strong>File Reference:</strong>','right'=>$document_info_simple['code']),
    'assignedto'=>array('left'=>$strL,'right'=>$strR),
			'authorizing1'=>array('left'=>'<strong>Document Name:</strong>','right'=>$document_info_simple['name']),
			'due'=>array('left'=>'<strong>Document Description:</strong>','right'=>$document_info_simple['description']),
			'doctype'=>array('left'=>'<strong>Document Type:</strong>','right'=>$document_info_simple['type']), 
            'initBy'=> array('left' => '<strong>Initiated By:</strong>','right' => $document_info_simple['initiated_by']),
			'version'=>array('left'=>'<strong>Version:</strong>','right'=>$document_info_simple['version']), 
            'dateIssued'=> array('left' => '<strong>Date Published/Approved:</strong>','right' => $document_info_simple['initiated']),
			'issued'=> array('left' => '<strong>Published/Approved By:</strong>','right' => $document_info_simple['approved_by']),
			'page'=> array('left' => '<strong>Pages:</strong>','right' => $document_info_simple['pages']),
			'alertBy'=> array('left' => '<strong>'.$alertStr1.'</strong>','right' => $partt_name)

                    ),
'singleColData'=>array(
                            'summary'=>'<p><strong>'.$alertStr2.'</strong><br>'.$document['document_comment'].'</p>',
                            'url'=>'Please <a href= "https://' . $_SERVER['HTTP_HOST'] .'/action_tracker/doc_review_alert.php?id='.$reviewid.'">CLICK</a> Here to view review</p>')
					);

                $emailObj->appendInfo($mergeData);
			
                $emailObj->sendEmail($subject,$who,array(),array(),'me_completed','','grey',$attachment);


	$url = basename($_SERVER['PHP_SELF'])."?js=1&e=1";

	redirection($url);
}

$js 				= (int) $_GET['js'];
$e 					= (int) $_GET['e'];
$doc_id				= (int) $_GET['document_id'];
$alert_id				= (int) $_GET['alert_id'];
if ($js) {

	$smarty->assign('js',$js);
	$smarty->assign('e',$e);

} else {

	$smarty->assign('doc_id',$doc_id);
	$smarty->assign('post_script_name','send_review.php');
}




$docclassObj 					= SetupGeneric::useModule('DocClassification');
$document_classification 		= $docclassObj->displayItems();
$optObj							= new Option();
$miscObj 						= new Misc();
$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$document_types 				= $miscObj->getDocumentTypes();
$optObj							= null;
$miscObj 						= null;
$participantObj				 	= SetupGeneric::useModule('Participant');
$objFile						= new Upload();

$document_info 					= $docObj->getDocumentInformation($doc_id);

$meta_info 					= $docObj->getDocumentInformationMetaData($doc_id);


$participant_id = $document_info['initiatedByParticipant'];
$participantObj->setItemInfo(array('id'=>$participant_id));
$partcipantData = $participantObj->displayItemById();

$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
$initiated_by 	= $participant_name == ' ' ? '-' : $participant_name;

$part_id = $meta_info['approvedBy'];
$participantObj->setItemInfo(array('id'=>$part_id));
$partData = $participantObj->displayItemById();

$part_name = $partData['forename'].' '.$partData['surname'];
$aprrove_by 	= $part_name == ' ' ? '-' : $part_name;



$objFile->setFileInfo('contributors',array('id'=>$document_info['documentID']));
$file_detail = $objFile->getFileDetails();




$document_info_simple['version'] = $version_type == 'minor_version' ? $document_info['versionNew'].".".$document_info['versionMinor']: $document_info['versionNew'];
$version_type = $version_type == 'minor_version' ? 'Version' : $version_type;
$version_type = str_replace('_',' ',$version_type);

$document_info_simple['code'] 			= $document_info['fileReference'];
$document_info_simple['reference'] 		= $document_info['reference'];
$document_info_simple['document']		= "<a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=".$file_detail['sysFilename']."&un=".$file_detail['usrFilename']."&module=contributors','mywindow')\">".$file_detail['usrFilename']."</a>";
$document_info_simple['name'] 			= ucfirst($document_info['title']);
$document_info_simple['description'] 	= ucfirst($document_info['description']);
$document_info_simple['type'] 			= $document_types[$document_info['documentType']];
$document_info_simple['initiated'] 		= format_date($document_info['dateInitiated']);
$document_info_simple['initiated_by'] 	= $initiated_by;
$document_info_simple['version_type']	= ucfirst($version_type);
//$document_info_simple['version'] 		= $document_info['versionNew'];
$document_info_simple['approved_date']	= $meta_info['dateApproved'];
$document_info_simple['approved_by'] 	= $aprrove_by;
$document_info_simple['action_summary'] = ucfirst($document_info['actionSummary']);
$document_info_simple['pages'] 			= $document_info['pages'];

if ($document_classification) {

	foreach ( $document_classification as $document_class_ele => $document_class_val ) {

		if ( substr($document_class_ele,0,1) == $document_info['classification'] ) {
			$document_info_simple['classification'] = $document_class_val;
			break;
		}
	}
}
$smarty->assign('reviewer',$participant_id);
$smarty->assign('review_id',$alert_id);
$smarty->assign('row_data',$document_info_simple);
$smarty->assign('document_contributors',$doc_contributors);
$smarty->assign('business_units',$business_units);
//$smarty->debugging=true;
$smarty->display('action_tracker/send_review.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';