<?php
 /**
  $Id: save_action_information.php,v 3.83 Monday, December 13, 2010 4:13:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * for testing purpose only
  *
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Monday, August 16, 2010 11:24:04 AM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$actTrackObj = new ActionTracker();


echo $id_action = (int) $_GET['id'];
echo $id_module =  $_GET['module_name'];
//$actTrackObj->saveDueDatess($id_action,$id_module);
$sql = sprintf("SELECT dueDate FROM %s.actions WHERE ID = ".$id_action." AND module=".$id_module,_DB_OBJ_FULL);

		        $pStatement = $this->dbHand->prepare($sql);

		$pStatement->execute();

		$result = $pStatement->fetch(PDO::FETCH_ASSOC);
		exit; 
		list($year,$month,$day) = (explode("-",$result));
$alert_mail_days = 1;
$days = ($month + $alert_mail_days);

$reviewdate=date('Y-m-d',strtotime("+ ".$alert_mail_days." month"));

$sql2 = sprintf("UPDATE %s.actions
				SET
				dueDate = '".$reviewdate."'
				WHERE ID = ".$this->id." AND module=".$this->module,_DB_OBJ_FULL);
$stmt = $this->dbHand->prepare($sql2);

		/*$stmt->bindParam(1,$approve);
		$stmt->bindParam(2,$p_actionId);*/

$stmt->execute();

echo 1;
?>