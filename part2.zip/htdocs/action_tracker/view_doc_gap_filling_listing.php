<?php
/**
$Id: view_doc_gap_filling_listing.php,v 3.48 Saturday, January 29, 2011 12:13:09 PM ehsindia Exp $  *
*
* smart-ISO, Smart Auditing Software Solutions
* http://www.smart-iso.com
* Copyright (c) 2010 smart-ISO
* Released under the Smartiso License
*
*
* Short description
* This file displays data for assigned documents.
*
* Long description
*
* @author  Gurnam Singh <simurgrai@gmail.com>
* @package Smartiso
* @subpackage Action tracker
* @since  Friday, September 17, 2010 12:30:51 PM>
*/
$LAST_BREAD_CRUM = "Gap filling"; // for current breadcrums
$class_gap_filling = 'selected_tab'; //for selcted tabs
// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/view_doc_gap_filling.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");
//dump_array($_POST);

$docid 		= (int) $_GET['docid'];
$audit_id 	= (int) $_GET['audit_id'];

$gapObj 	= new ReviewGap();

$selected_questions = $gapObj->getGapTrackerRecord($audit_id,$docid);
$document_code 		= $gapObj->getDocumentCode($docid);

$smarty->assign('audit_id',$audit_id);
$smarty->assign('docid',$docid);
$smarty->assign('document_code',$document_code);
//$smarty->assign('selected_questions',$selected_questions);

//$smarty->debugging = true;

$smarty->display('action_tracker/view_doc_gap_filling.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>