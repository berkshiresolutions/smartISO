<?php    
 
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$actObj 		= new ActionTracker();

$id=$_GET["id"];
$whotype=$_GET["whotype"];
$data=$actObj->getComments($id); 
if (isset($data[$whotype]))
echo $data[$whotype];
else 
    echo "No Entry";
                        
?>