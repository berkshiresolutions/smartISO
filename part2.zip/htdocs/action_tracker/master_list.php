<?php
 /**
  $Id: index.php,v 3.61 Thursday, February 03, 2011 2:41:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Wednesday, September 29, 2010 2:17:35 PM>
  */


//redirects ro the new form  /Bob


// load jquery validation script file

$_PAGE_VALIDATION_SCRIPT 	= 'action_tracker/master_list.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

set_time_limit(180);

$actTrackObj 	= new ActionTracker();
$authObj = SetupGeneric::useModule('AuthorizedUser');
$actionsObj = new Action();
$counter=$actionsObj->getActionListCount();



foreach($counter as $key =>$value){

    switch ($value['moduleName']){
        
        case "bcp" : $counter[$key]["url"]='record_bcp.php';$counter[$key]["title"]='BCP';$counter[$key]["code"]='BCP|master_list.php';break;
        case "bia" : $counter[$key]["url"]='record_bia.php';$counter[$key]["title"]='BIA';$counter[$key]["code"]='BIA|master_list.php';break;
        case "Communications" : $counter[$key]["url"]='record_commsmgr.php';$counter[$key]["title"]='Library';$counter[$key]["code"]='Library Manager|master_list.php';break;
        case "compliance_alert" : $counter[$key]["url"]='record_compliance.php';$counter[$key]["title"]='Compliance';$counter[$key]["code"]='CP|master_list.php';break;
        case "ComplianceAlert" : $counter[$key]["url"]='record_compliancealert.php';$counter[$key]["title"]='Compliance Issue';$counter[$key]["code"]='CPA|master_list.php';break;
        case "complaint" : $counter[$key]["url"]='record_customer_comp.php';$counter[$key]["title"]='Complaint';$counter[$key]["code"]='customer complaint|master_list.php';break;
        case "Context" : $counter[$key]["url"]='record_question.php';$counter[$key]["title"]='Context';$counter[$key]["code"]='Context Analysis|master_list.php|question';break;
        case "EquipmentC" : $counter[$key]["url"]='record_cali.php';$counter[$key]["title"]='Equip Cal';$counter[$key]["code"]='Calibration|master_list.php';break;
        case "EquipmentM" : $counter[$key]["url"]='record_main.php';$counter[$key]["title"]='Equip Maint';$counter[$key]["code"]='Maintenance|master_list.php';break;
            case "incidence" : $counter[$key]["url"]='records_incidence.php';$counter[$key]["title"]='Incidence';$counter[$key]["code"]='Incidence|master_list.php';break;
         case "MSE_Action" : $counter[$key]["url"]='record_mse.php';$counter[$key]["title"]='MSE Audits???';$counter[$key]["code"]='MSE|master_list.php';break;
        case "nhp" : $counter[$key]["url"]='record_non_conf_nhp.php';$counter[$key]["title"]='NCR';$counter[$key]["code"]='NCR|master_list.php|NHPMain';break;
            case "investigation" : $counter[$key]["url"]='records_investigation.php';$counter[$key]["title"]='Investigation';$counter[$key]["code"]='BCP|master_list.php';break;
        case "gov_action" : $counter[$key]["url"]='record_gov.php';$counter[$key]["title"]='Governance Audit';$counter[$key]["code"]='GOV|master_list.php';break;
            case "gov1_action" : $counter[$key]["url"]='record_gov1.php';$counter[$key]["title"]='Governance Observation';$counter[$key]["code"]='GOV1|master_list.php';break;
            case "gov2_action" : $counter[$key]["url"]='record_gov2.php';$counter[$key]["title"]='Governance Interview';$counter[$key]["code"]='GOV2|master_list.php';break;
        case "InspectionDue" : $counter[$key]["url"]='record_insp_due.php';$counter[$key]["title"]='Inspection Due';$counter[$key]["code"]='Inspection|master_list.php';break;
        case "manual_handlingT" : $counter[$key]["url"]='record_manual_hand_task.php';$counter[$key]["title"]='Man Handle Task';$counter[$key]["code"]='Man Hand|master_list.php';break;
        case "manual_handlingL" : $counter[$key]["url"]='record_manual_hand_load.php';$counter[$key]["title"]='Man Handle Load';$counter[$key]["code"]='Man Hand|master_list.php';break;
        case "manual_handlingI" : $counter[$key]["url"]='record_manual_hand_ind.php';$counter[$key]["title"]='Man Handle Ind';$counter[$key]["code"]='Man Hand|master_list.php';break;
        case "manual_handlingE" : $counter[$key]["url"]='record_manual_hand_env.php';$counter[$key]["title"]='Man Handle Env';$counter[$key]["code"]='Man Hand|master_list.php';break;
            case "isa_action" : $counter[$key]["url"]='record_isa.php';$counter[$key]["title"]='ISA Audits???';$counter[$key]["code"]='ISA|master_list.php';break;
        case "PF" : $counter[$key]["url"]='record_pfs.php';$counter[$key]["title"]='Process Flow';$counter[$key]["code"]='PF|master_list.php';break;
            case "risk" : $counter[$key]["url"]='record_risk_assessment.php';$counter[$key]["title"]='Risk';$counter[$key]["code"]='Risk|master_list.php';break;
            case "risk27K" : $counter[$key]["url"]='record_risk27k_assessment.php';$counter[$key]["title"]='Risk 27K';$counter[$key]["code"]='Risk 27K|master_list.php';break;
            case "smartlaw" : $counter[$key]["url"]='record_smartlaw.php';$counter[$key]["title"]='Law??';$counter[$key]["code"]='Law|master_list.php';break;    
            case "SmartlawI" : $counter[$key]["url"]='record_smartlaw.php';$counter[$key]["title"]='Law??';$counter[$key]["code"]='Law|master_list.php';break;  
       case "smartlawreview" : $counter[$key]["url"]='record_smartlawreview.php';$counter[$key]["title"]='Law Review';$counter[$key]["code"]='Law|master_list.php';break;
        case "SOA" : $counter[$key]["url"]='record_soa_assessment.php';$counter[$key]["title"]='SOA';$counter[$key]["code"]='SOA|master.php|SOA'; break;  
       case "template" : $counter[$key]["url"]='record_compliance.php';$counter[$key]["title"]='Templates';$counter[$key]["code"]='Templates|master_list.php';break; 
    }
    if ($key == 0)
  $firsturl=$counter[0]["url"];
}
$user_level = getUserAccessLevel();

	$tabs 			= array('me_pending');




	
	$smarty->assign(firsturl,$firsturl);


$smarty->assign('group',$counter);

$smarty->display('action_tracker/master_list.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>