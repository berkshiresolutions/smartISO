<?php
 /**
  $Id: contributor_action.php,v 3.03 Wednesday, September 29, 2010 2:17:47 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  * This file is for editing the action under
  * contributor section in management systems.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Thursday, September 16, 2010 10:40:49 AM>
  */

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/contributor_action.js';

$cid = (int) $_GET['cid'];

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$uploaded_document = "text.xls";

$smarty->assign('cid', $cid);
$smarty->assign('uploaded_document', $uploaded_document);
$smarty->display('action_tracker/contributor_action.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>