<?php
/**
 $Id: record_risk27k_assessment.php,v 5.22 Thursday, February 03, 2011 12:37:43 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Risk - Assigned to me(pending) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Monday, September 20, 2010 11:41:04 AM>
*/
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'risk27k';

$filter_date = $_GET['filter_date'];

if ( $level == 1 ) {
	$is_admin = true;
}

$show_au_approve = true;

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
	$show_au_approve = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$show_done_date = true;

if ( $tab_type == 'other_pending' && $level != 1 ) {
	$show_done_date = false;
}

$actTrackObj = new ActionTracker();

try {

	$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$tab_type,$filter_date);
	$resultset = $actTrackObj->getActionsForActionTracker();

	$listdata = "<form class='action_tracker_listing' name='risk_form' method='post'>";
	$listdata .= "<table class='display' id='module_records'><thead><tr>
				<th width='13%'>Business Unit</th>
				<th width='12%'>Reference No.</th>
				<th width='16%'>Threat</th>
				<th width='16%'>Action</th>
				<th width='10%'>Due Date</th>";

	if ($show_participant_name) {
		$listdata .= "<th width='10%'>Assigned to</th>";
	}

	if ( $show_done_date ) {
		$listdata .= "<th width='15%'>Completed Date</th>";
	}

	if ( $show_au_approve ) {
		$listdata .= "<th width='7%'>"._AU_APPROVE_ACTION_TRACKER_LABEL."</th>";
	}

	if ($is_admin) {
		$listdata .= "<th width='5%'>Approve</th>";
	}

	$listdata .= "</tr></thead><tbody>";

	$jsdata 			= '';
	$jsdata_sec 		= '';

	foreach ( $resultset as $resultElement ) {

		$ac_id = $resultElement['ID'];

		$threat_summary 			= compact_action_tracker_description($resultElement['threatsSummary']);
		$action_description 		= compact_action_tracker_description($resultElement['actionDescription']);

		$threat_summary_full 		= javascript_safe_string($resultElement['threatsSummary']);
		$action_description_full 	= javascript_safe_string($resultElement['actionDescription']);


		$listdata .= "<tr>";
		$listdata .= "<td>".$resultElement['buName']."</td>";
		$listdata .= "<td>".$resultElement['reference']."</td>";

		$listdata .= "<td>";
		$listdata .= "<a href='javascript:void(0)' class='showthreat_".$ac_id."'>".$threat_summary."</a>";
		$listdata .= "</td>";
		$listdata .= "<td>";
		$listdata .= "<a href='javascript:void(0)' class='showaction_".$ac_id."'>".$action_description."</a>";
		$listdata .= "</td>";
		$listdata .="<td>".format_date($resultElement['dueDate'])."</td>";

		if ($show_participant_name) {
			$listdata .= "<td>".$resultElement['who_name']."</td>";
		}

		if ( $show_done_date ) {
			if ( $tab_type == 'me_completed' || $tab_type == 'other_completed' ) {
				$listdata .="<td>".format_date($resultElement['doneDate'])."&nbsp;&nbsp;<a href='javascript:void(0)' class='showcomment_".$ac_id."'>[AC]</a></td>";

			} else {

				if ( $resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00' ) {

					if ( $resultElement['who'] == getLoggedInUserId() ) {
						$listdata .="<td>
								<input type='text' name='done_date_".$ac_id."' id='done_date_".$ac_id."' size='20' class='datepicker dateText' />
								&nbsp;<a href='javascript:void(0)' class='smartlightbox act_done' alt='".$ac_id."'  rel='map_with:action_done_comment_".$ac_id."'>Done</a>
								<input type='hidden' class='action_done_comment_".$ac_id."' name='action_done_comment_".$ac_id."' id='action_done_comment_".$ac_id."' value='{$resultElement['doneDescription']}'/>
							</td>";
					} else {
						$listdata .= "<td>Not completed yet</td>";
					}
				} else {
					$listdata .="<td>".format_date($resultElement['doneDate'])."&nbsp;&nbsp;<a href='javascript:void(0)' class='showcomment_".$ac_id."'>[AC]</a></td>";
				}
			}
		}


		$action_comment = javascript_safe_string($resultElement['doneDescription']);

		$jsdata .= "$('.showcomment_".$ac_id."').smartLightBox({heading: 'Comment/Reason',writeMode : false,width: '500',height: '200',description : '".$action_comment."'});\n";
		$jsdata_sec .= "$('.showthreat_".$ac_id."').smartLightBox({heading: 'Threat Summary for ".$resultElement['reference']."',writeMode : false,width: '500',   height: '200',description : '".$threat_summary_full."'});\n";
		$jsdata_third .= "$('.showaction_".$ac_id."').smartLightBox({heading: 'Action for ".$resultElement['reference']."',writeMode : false,width: '500',   height: '200',description : '".$action_description_full."'});\n";

		if ( $resultElement['approveAU'] == 0 && ( $tab_type == 'me_pending' || $tab_type == 'other_pending' ) ) {
			if ( $resultElement['whoAU'] == getLoggedInUserId() ) {
				if ( $resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00' ) {
					$listdata .= "<td></td>";
				} else {
					$listdata .= "<td><input type='checkbox' class='au_approve_action' name='au_approve_".$ac_id."' id='au_approve_".$ac_id."' value='".$ac_id."' /></td>";
				}
			} else {
				if ( $resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00' ) {
					$listdata .= "<td></td>";
				} else {
					$listdata .= "<td>Pending</td>";
				}
			}
		} else {
			if ( $show_au_approve ) {
				$listdata .= "<td>Approved</td>";
			}
		}

		if ($is_admin) {
			if ( $resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00' ) {
				$listdata .= "<td></td>";
			} else {
				if ( $resultElement['approveAU'] == 0 ) {
					$listdata .= "<td></td>";
				} else {
					$listdata .= "<td><input type='checkbox' class='approve_action' name='approve_".$ac_id."' id='approve_".$ac_id."' value='".$ac_id."' /></td>";
				}
			}
		}

		$listdata .= "<input type='hidden' name='done_date_db_".$ac_id."' id='done_date_db_".$ac_id."'value='".$done_date."' />";
		$listdata .= "<input type='hidden' name='action_done_comment_".$ac_id."' id='action_done_comment_".$ac_id."' value='action done no ".$ac_id."'>";
		$listdata .= "</tr>";
	}

	$listdata .= "</tbody><tfoot><tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>";

	if ($is_admin) {
		$listdata .= "<td>&nbsp;</td>";
	}
	$listdata .= "</tr></tfoot></table></form>";
	$listdata .= "<div class='footnote'><b>Note :</b> To view full Threat/Action, click the corresponding box.</div>";

	$listdata .= "<script> (function($) { $(document).ready(function () {";
	$listdata .= $jsdata;
	$listdata .= $jsdata_sec;
	$listdata .= $jsdata_third;
	$listdata .= "$('.datepicker').datepicker({changeMonth: true,changeYear: true});";
	$listdata .= "});})(jQuery);	</script>";

} catch ( ErrorException $e ) {
	$listdata = $e->getMessage();
}

echo $listdata;
?>