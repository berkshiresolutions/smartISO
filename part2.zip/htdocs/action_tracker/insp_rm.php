<?php
/**
 $Id: insp_rm.php,v 3.08 Wednesday, November 24, 2010 1:28:01 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Inspection(RM) - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Thursday, September 23, 2010 10:42:16 AM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/insp_rm.js';

$class_inspection_rm = "selected_tab"; //current tab
$LAST_BREAD_CRUM = "Inspection (RM)"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/insp_rm.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>