<?php
 /**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <gurnam_84@hotmail.com>
  * @package Smartiso
  * @subpackage Equipment
  * @since  Friday, January 14, 2011 5:44:40 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];
header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=service.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

$fn = fopen('service.xls','w');
$is_admin = false;
$show_participant_name = false;


$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);


$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'Nonconformance inc'; // do not change this string

//$filter_date = $_GET['filter_date'];


if ( $level == 1 ) {
	$is_admin = true;
}

$show_au_approve = true;

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
	$show_au_approve = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$show_done_date = true;

if ( $tab_type == 'other_pending' && $level != 1 ) {
	$show_done_date = true;
}
$vehicleObj = new Vehicle();
$actTrackObj = new ActionTracker();
$vehicleObj->setVehicleInfo(0,"");



	$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$tab_type,$filter_date);
	$resultset = $actTrackObj->getActionsForActionTracker();
	
	
	$result = $vehicleObj->viewActionService1();



?>
<table cellspacing='0' cellpadding='0' width='100%' border='1'>
	
	<tr style='border: 1px solid;'>
	
	
	<td>Reference</td>
	<td >Service Name</td>
	<td>Mileage</td>
	<td >Action</td>
	<td >Due Date</td>
	<td > Assigned To</td>
	<td >Done Date</td>
	</tr>
<?php 
	foreach($result as $v){
		$ac_id = $v['ID'];
			$name_who = $actTrackObj->getNameWhoAU($v['who']);
	 $vehicleObj->setVehicleInfo($v['ID'],'');
	 
	 $data_a = $vehicleObj->viewVehicleServieA();
	 foreach($data_a as $val){
	 
	 $vehicleObj->setVehicleInfo($val['vID'],'');
	$data = $vehicleObj->viewVehicle();
	?>
	<tr style='border: 1px solid;'>

	<td><?php echo $data['uniqueReference']; ?></td>
		<td><?php echo $val['servicingRequired']; ?></td>
			<td><?php echo $val['services']; ?></td>
	<td ><?php echo $v['actionDescription']; ?></td>
	<td ><?php echo $v['dueDate']; ?></td>
	<td ><?php echo $name_who; ?></td>
	<td ><?php echo $v['done']; ?></td>
	</tr>
	<?php 
	}
	}
	?>
	</table>
	<?php

fclose($fn);





//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>