<?php
 /**
  $Id: set_oragnigram_date.php,v 3.36 Thursday, February 10, 2011 4:16:49 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ogranigram msr date setup
  * @since  Monday, December 13, 2010 6:16:27 PM>
  */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;
$_PAGE_VALIDATION_SCRIPT2 = '/action_tracker/filter_c.js';

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$orgObj 		= SetupGeneric::useModule('Organigram');
$mseListObj 	= SetupGeneric::useModule('ManagementElementList');
$msePermObj 	= SetupGeneric::useModule('ManagementElementPermission');

$url_bu_id 	= (int) $_GET['id'];
$type 		= strip_tags($_GET['type']);

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$type_flag 	= $_POST['type_flag'];
	$bu_id 		= $_POST['bu_id'];
	$disc 		= $_POST['disc'];

	//
	
	
	$ac = $orgObj->displayLocationWho($bu_id);
	$orgObj->deleteAction($bu_id);
	
	foreach($ac as $val){
	
	$bui = $orgObj->getReportBu($val['participantID']);
	$buiM = $orgObj->getReportBu1($bui['reportToBuID']);
	
	$locObj 			= SetupGeneric::useModule('Locationgram');

	$locObj->setItemInfo(array('id'=>$bu_id));
	$loc = $locObj->displaylocationByPid();
	//dump_array($loc);
	//$name[$loc['locID']] = $loc['name'];
$da = format_date($_POST['when_date']);
//dump_array($val);
//exit;
	$d = "A Critical Audit is due for ".$loc['name']." on ".$da;
	$orgObj->setItemInfo(array('id'=>$bu_id,'who'=>$val['participantID'],'whoAU'=>$buiM['participantID'],'module'=>'InspectionDue','dueDate'=>$_POST['when_date'],'descp'=>$d,'idt'=>$bu_id));
	$orgObj->addAction();
	
	}

		$orgObj->setItemInfo(array('id'=>$bu_id,'frequency'=>$_POST['frequency'],'when'=>$_POST['when_date']));
		$orgObj->updateLoc();


	echo "<script>window.opener.location.href='inspection_loco.php?t=3';window.close();</script>";
}

$orgObj->setItemInfo(array('id'=>$url_bu_id));
$data = $orgObj->displayItemByIdForMSR();

if ($type == 'MSR' ) {

	$date = $data['whenMsr'] == '0000-00-00' ? date('m/d/Y') : format_date($data['whenMsr']);
	$date = $date == '01/01/1900' ? date('m/d/Y') : $date;
	$date = $date == '//' ? date('m/d/Y') : $date;
	$return_value = $msr_date."#!".$data['optionA'];

} else {

	$date = $data['whenIsr'] == '0000-00-00' ? date('m/d/Y') : format_date($data['whenIsr']);
	$date = $date == '01/01/1900' ? date('m/d/Y') : $date;
	$date = $date == '//' ? date('m/d/Y') : $date;
	$return_value = $isr_date."#!".$data['optionB'];

	$month 		= '';
	$stow 		= '';
	$mselist 	= '';

	switch ($data['optionB']) {
		case 1:	$month = 'checked';	break;
		case 2:	$stow = 'checked'; break;
		case 3:	$mselist = 'checked'; break;
	}
}

// to get rid of  '-'
if ( $date == '-' ) {
	$date = '';
}

$bu_details = $orgObj->displayItemById();
$mse_list_id = $msePermObj->displayItemByBuID($url_bu_id);

if ( $mse_list_id ) {
	$smarty->assign('bu_has_mselist',true);

	$mseListObj->setItemInfo(array('id'=>$mse_list_id));
	$listInfo = $mseListObj->displayItemById();
	$smarty->assign('mselist_title',$listInfo['name']);
	$smarty->assign('mselist_id',$mse_list_id);
} else {
	$smarty->assign('bu_has_mselist',false);
}

$locObj 			= SetupGeneric::useModule('Locationgram');

	$locObj->setItemInfo(array('id'=>$url_bu_id));
	$loc = $locObj->displaylocationByPid();
	//dump_array($loc);
	//$name[$loc['locID']] = $loc['name'];
$loc_date = format_date($loc['dateLoc']);

if($loc_date == '01/01/1970'){
			$loc_date  = $today = date("m/d/Y");
}
$smarty->assign('bu_id',$url_bu_id);
$smarty->assign('bu_name',$loc['name']);
$smarty->assign('bu',$loc['businessUnit']);
$smarty->assign('type',$type);
$smarty->assign('date',$loc_date);
$smarty->assign('month',$month);
$smarty->assign('stow',$stow);
$smarty->assign('mselist',$mselist);
$smarty->assign('isr_opt',$data['optionB']);
$smarty->assign('type_data',array('1'=> 'Risk','2'=>'SOA'));
$smarty->assign('color',array('a'=> 'All','1'=>'Red','2'=>'Green','3'=>'Amber','4'=>'Purple'));
$smarty->assign('sel_frq',$data['optionA']);

$smarty->display('set_p.tpl');
require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>