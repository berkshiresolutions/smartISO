<?php
/**
 $Id: customer_comp.php,v 3.06 Thursday, December 09, 2010 9:36:23 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Customer Complaint - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Friday, September 24, 2010 6:14:42 PM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/customer_comp.js';

$class_customer_complaint = "selected_tab"; //current tab
$LAST_BREAD_CRUM		  = "Customer Complaint"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/customer_comp.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>