<?php
 /**
  $Id: replace_document.php,v 3.74 Thursday, January 20, 2011 4:14:14 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/alert_status_change.js';
$_PAGE_VALIDATION_SCRIPT2 = 'common_script.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';
$atObj 		= new ActionTracker();

$actObj 		= new Action();
//echo	$document_id = (int) $_GET['document_id'];
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

$action_id 	= (int) $_POST['alert_id'];
$date   	= strip_tags($_POST['done_date']);
$who_id 	= (int) $_POST['who_hidden'];
$whoAU 	= (int) $_POST['whoAU_hidden'];
$manager 	= (int) $_POST['manager'];
$route      	=  $_POST['route'];
$status      	=  $_POST['status'];
$actionstatus      	=  $_POST['actionstatus'];
$actionstatus      	=  'non_conf_nhp.php';
$comment 	=  $_POST['reason_replace'];
$action = strip_tags($_POST['action']);
$action_str = strip_tags($_POST['action_str']);

$actObj->updatehistory($action_id);

switch ($status){
    case 1: $atObj->approveAlert($action_id,$date,$comment,$module);break;
    case 2: $atObj->updateReject($action_id,$date,$comment,$action,$action_str);break;
    case 3: $atObj->updateApp2($action_id, $date, $comment, $whoAU, $action, $action_str);break;
    case 4: $atObj->updateReassign($action_id,$date,$comment,$who_id,$action,$action_str);break;
    case 'Edit Action': $atObj->updateEditAction($action_id,$date,$comment,$action,$actionstatus);break;
    case 'Cancelled' : $atObj->updateCancelled($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Delayed' : $atObj->updateDelayed($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'On Hold' : $atObj->updateOnHold($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Comment' : $atObj->updateComment($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Waiting for Resources' : $atObj->updateWFR($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Change Due Date' : $atObj->updateChangeDate($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Actioned' : $atObj->updateActioned($action_id,$date,$comment,$who_id,$actionstatus,0,$action);break;
                                            
    case 'Verified' : $atObj->updateVerified($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Completed' : $atObj->updateCompleted($action_id,$date,$comment,$who_id,$action,$actionstatus);break;
    case 'Rejected': $atObj->updateReject($action_id,$date,$comment,$action,$actionstatus);break;
    case 'Reassigned': $atObj->updateReassigned($action_id,$date,$comment,$who_id,$action,$actionstatus);break;

    case 'In Progress': $atObj->updateInProgress($action_id,$date,$comment,$action,$actionstatus);break;
    case 'Escalated': $atObj->updateEscalated($action_id,$date,$comment,$manager,$action,$actionstatus);break;
}





	$smarty->assign('js',1);
	$smarty->assign('e',2);

} else {

	$alert_id 	= (int) $_GET['alert_id'];
        $alert_type 	= explode("|", $_GET['act_type']);
        
        
        $actdata=$actObj->viewAction3($alert_id);
  //      var_dump($actdata);
	$smarty->assign('alert_id',$alert_id);
        $smarty->assign('alert_data',$actdata);
        $smarty->assign('action',$alert_type[0]);
        $smarty->assign('action_str',$alert_type[1]);

}
//$smarty->debugger=true;
$smarty->display('action_tracker/alert_status_change_admin.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';