<?php
/**
$Id: record_view_doc_gap_filling.php,v 5.30 Saturday, January 29, 2011 12:13:10 PM ehsindia Exp $  *
*
* smart-ISO, Smart Auditing Software Solutions
* http://www.smart-iso.com
* Copyright (c) 2010 smart-ISO
* Released under the Smartiso License
*
*
* Short description
* This file accesses data from the database.
*
* Long description
*
* @author  Gurnam Singh <simurgrai@gmail.com>
* @package Smartiso
* @subpackage Action tracker
* @since  Friday, September 17, 2010 11:51:29 AM>
*/

$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$gapObj = new ReviewGap();

$audit_id 	= (int) $_GET['audit_id'];
$docid 	= (int) $_GET['docid'];

$result	= $gapObj->getGapQuestionActionTrackerByDocument($audit_id,$docid);
$selected_questions = $gapObj->getGapTrackerRecord($audit_id,$docid);
 $document_info 		= $gapObj->getDocumentInfoByID($docid);
$document_code 		= $gapObj->getDocumentCode($docid);
$document_name		= $document_info['displayName'];
//dump_array($document_code);
$listdata = '';

$listdata .= "<form name='form_document' id='form_document' action='' method='post'>";
$listdata .= "<label>Document: <a href='javascript:void(0)' class='download_file' rel='{$docid}'>{$document_name} [{$document_code}]</a></label>";
$listdata .= "<label style='text-align: right;float:right'>Opened/Amended/Saved/Uploaded <input type='checkbox' class='upload_document' name='doc_uploaded' id='doc_uploaded' value='1' /></label>";

$listdata .= "<input type='hidden' name='cid' id='cid' value='$cid' />";
$listdata .= "<input type='hidden' name='document_code' id='document_code' value='$document_code' />";
$listdata .= "<table class='display' id='module_records'>
		<thead>
			<tr>
				<th width='80%'>Question</th>
				<th>Read Questions & Recommendations</th>
			</tr>
		</thead><tbody>";

$check_all_count 	= count($result);
$checks_count 		= 0;

	if ($result) {

		$question_list = '';

		foreach ( $result as $resultEleKey=>$resultEleValue ) {

			//dump_array($resultEleValue);

			if ( $resultEleValue['recommendation'] != '' ) {
				$recommendation = addslashes($resultEleValue['recommendation']);
			} else {
				$recommendation = 'No Recommendation';
			}

			$listdata .= "<tr>";
			$listdata .= "<td alt='sssssss' title='".$recommendation."'>".$resultEleValue['question']."</td>";

			$checked = '';

			if ( in_array($resultEleKey,$selected_questions) ) {
				$checked = 'checked';
				$checks_count++;
			} else {
				$checked = '';
			}

			$listdata .= "<td><input type='checkbox' {$checked} rel='{$audit_id}|{$docid}|{$resultEleKey}' class='update_tracker' name='ques_{$resultEleKey}' id='ques_{$resultEleKey}' value='{$resultEleKey}' /></td>";
			$listdata .= "</tr>";

			if ( $question_list == '' ) {
				$question_list = $resultEleKey;
			} else {
				$question_list .= "~".$resultEleKey;
			}

		}
	}

	$listdata .= "</tbody><tfoot>";

	$listdata .= "<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
		</tfoot>";

	$listdata .= "</table></form><br/><br/><br/><br/><br/><br/>";

	if ( $check_all_count == $checks_count ) {
		$check_all_flag = 'checked disabled';
	}

	$listdata .= "<span>Read all questions</span>&nbsp;&nbsp;<input {$check_all_flag} type='checkbox' rel='{$audit_id}|{$docid}|{$question_list}' class='update_tracker_all' name='ques_all' id='ques_all' value='{$question_list}' />";


	$listdata .= "<br/><br/><address><b>Note:</b><br/>Place mouse over the question to see the recommendation.</address>";


echo $listdata;
?>

<script>
//<![CDATA[
(function($) {
	/*
	$(document).ready(function() {

		<?php
		echo "var file_ref  = '".$file_ref."';\n";
		echo "var file_name = '".$file_name."';\n";
		?>
		doc_id = $('#cid').val();
		//alert(doc_id);
		$('#doc_uploaded').click(function() {
			check_val = $(this).attr('checked');
			if (check_val) {
				window.open('gap_filling_upload_doc.php?docid='+doc_id+'&doc_ref='+file_ref+'&doc_name='+file_name+'','upload_doc_form','height=400,width=600');
			}
		});

		$('.save_record').click(function() {
			document.form_document.submit();
		});
	});
	*/
})(jQuery);
//]]>
</script>