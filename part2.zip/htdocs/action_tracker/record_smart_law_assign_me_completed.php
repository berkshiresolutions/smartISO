<?php
/**
 $Id: record_smart_law_assign_me_completed.php,v 3.11 Thursday, February 03, 2011 12:37:43 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Smart Law - Assigned to me(completed) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Saturday, September 25, 2010 11:37:58 AM>
*/

$si				= "SI";
$type			= "Relevant";
$action			= "action";
$when			= "June 26 2010";
$done_date		= "May 16 2010";

echo "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='15%'>SI</th>
			<th width='18%'>Type</th>
			<th width='27%'>Action</th>
			<th width='18%'>When</th>
			<th width='22%'>Completed Date/Comment</th>";
		echo "</tr>
	</thead>

	<tbody>";
	for ($i=1;$i<=15;$i++) {
		echo "<tr>";
			echo "<td>".$si."</td>";
			echo "<td>".$type."</td>";
			echo "<td>".$action."</td>";
			echo "<td>".$when."</td>";
			echo "<td>".$done_date." <a href='javascript:void(0)'>[AC]</a></td>";
		echo "</tr>";
	}
	echo "</tbody>

	<tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</tfoot>
</table>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

<b>Note :</b> To view action comments, click the corresponding link.";
?>