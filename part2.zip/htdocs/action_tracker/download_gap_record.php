<?php
/**
$Id: record_view_doc_gap_filling.php,v 5.23 Saturday, January 15, 2011 3:38:40 PM ehsindia Exp $  *
*
* smart-ISO, Smart Auditing Software Solutions
* http://www.smart-iso.com
* Copyright (c) 2010 smart-ISO
* Released under the Smartiso License
*
*
* Short description
* This file accesses data from the database.
*
* Long description
*
* @author  Gurnam Singh <simurgrai@gmail.com>
* @package Smartiso
* @subpackage Action tracker
* @since  Friday, September 17, 2010 11:51:29 AM>
*/

$_HIDE_HTTP_HEADER = true;
$_SHOW_POP_REPORT_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$audit_id 	= (int) $_GET['audit_id'];
$docid 	= (int) $_GET['doc_id'];


$repObj = new Report('html');
$repObj->setFilters(array('audit_id'=>$audit_id,'doc_id'=>$docid));
$repObj->generateReport('GAPFILL');
$repObj->displayReport();

?>