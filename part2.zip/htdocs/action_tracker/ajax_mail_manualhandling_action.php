<?php
 /**
  $Id: SendActionAlerts.class.php,v 3.14 Saturday, January 29, 2011 3:22:31 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Anil 
  * @package Smartiso
  * @subpackage Alert Class
  * @since  Saturday, December 04, 2010 4:17:45 PM>
  */
 $_HIDE_HTTP_HEADER = true;

 require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
 $action_id = (int) $_GET['id'];
 $module_name = strip_tags($_GET['module_name']);
 $emailobj = new SendEmailAction($module_name,$action_id);
 $emailobj->sendMails();
 
 
 
?>