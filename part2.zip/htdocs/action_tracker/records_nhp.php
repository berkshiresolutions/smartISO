<?php
/**
 $Id: records_nhp.php,v 3.13 Saturday, January 29, 2011 6:10:00 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Non-conformance(NHP) - Assigned to me(pending) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Friday, September 24, 2010 11:55:39 AM>
*/

$is_admin = false;
$show_participant_name = false;

$type = $_GET['showtype'];
$type = $type == "" ? 'me_pending' : $type;

$filter_date = $_GET['filter_date'];

$level = 1;

if ( $level == 1 ) {
	$is_admin = true;
}

if($type == 'other_completed' || $type == 'me_completed') {
	$is_admin = false;
}

if ( $type == 'other_pending' || $type == 'other_completed' ) {
	$show_participant_name = true;
}

$reference_no		= "PF0920001";
$business_unit		= "Finance";
$action				= "action";
$due_date	 		= "June 26 2010";
$done_date		= "Aug 23 1986";

echo "<form name='nhp_form' method='post'>";
echo "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='16%'>Reference #</th>
			<th width='16%'>Business Unit</th>
			<th width='20%'>Action</th>
			<th width='16%'>Due Date</th>";
			if($show_participant_name) {
				echo "<th width='17%'>Assigned to</th>";
			}
			echo "<th width='15%'>Done Date/Comment</th>";
			if ($is_admin) {
				echo "<th width='7%'>Approved</th>";
			}
		echo "</tr>
	</thead>

	<tbody>";
	for ($i=1;$i<=15;$i++) {
		echo "<tr>";
			echo "<td>".$reference_no."</td>";
			echo "<td>".$business_unit."</td>";
			echo "<td>".$action."</td>";
			echo "<td>".$due_date."</td>";
			if($show_participant_name) {
				echo "<td>sanjeev krishan Bansal</td>";
			}
			if ( $type == 'me_completed' || $type == 'other_completed' ) {
				echo "<td>".$done_date."done date here<a href='javascript:void(0)' class='view_action_done' alt='action_done_comment_".$i."'>[AC]</a></td>";
			} else {
				if($done_date == "" || $done_date == "0000-00-00") {
					echo "<td>
							<input type='text' name='done_date_".$i."' id='done_date_".$i."' size='20' class='datepicker dateText' />
							<span><a href='javascript:void(0)' class='lightbox' alt='action_done_comment_".$i."' >Done</a></span>
						</td>";
				} else {
					echo "<td>
							".$done_date."<a href='javascript:void(0)' class='view_action_done' alt='action_done_comment_".$i."'>[AC]</a>
						</td>";
				}
			}

			if ($is_admin) {
				echo "<td><input type='checkbox' class='approve_it' name='approved_".$i."' id='approved_".$i."' value='".$i."' /></td>";
			}
			echo "<input type='hidden' name='done_date_db_".$i."' id='done_date_db_".$i."'value='".$done_date."' />";
			echo "<input type='hidden' name='action_done_comment_".$i."' id='action_done_comment_".$i."' value='action done no ".$i."'>";
		echo "</tr>";
	}
	echo "</tbody>

	<tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>";
			if ($is_admin) {
				echo "<td>&nbsp;</td>";
			}
		echo "</tr>
	</tfoot>
</table></form>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";

echo "<b>Note :</b> To view full Hazard/Action, click the corresponding box.";
?>