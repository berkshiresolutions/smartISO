<?php
 /**
  $Id: record_contributor.php,v 3.44 Saturday, January 29, 2011 6:45:53 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Contributor
  * @since  Saturday, November 20, 2010 7:20:55 PM>
  */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);

$filter_date = $_GET['filter_date'];

$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'DSE';

if ( $level == 1 ) {
	$is_admin = true;
}

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$docObj = new Documents();

$contribObj = new DocumentContributor();
$documents = $contribObj->viewAssignedDocuments1($filter_date);
$documentsCount = count($documents);

$listdata = "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='23%'>Section Reference</th>
			<th width='26%'>Document</th>
                        <th width='10%'>Who</th>
			<th width='27%'>Comment</th>
			<th width='13%'>Due Date</th>
			<th width='11%'>Action</th>
		</tr>
	</thead>
	<tbody>";

if ( $documentsCount ) {
	foreach ( $documents as $documentItem ) {

		if ( $documentItem['cmsdocID'] ) {

			$document_information 	= $docObj->getDocumentInformation($documentItem['cmsdocID']);
			$document_metadata 		= $docObj->getDocumentMetadata($documentItem['cmsdocID']);

			$document_code_info   = $docObj->getSectionByStandardAndCode('11',$document_information['fileReference']);

			$section_ref	= $document_information['fileReference']." ".$document_code_info['name'];
			$document		= '['.$document_information['documentType'].']&nbsp;&nbsp;<a href="/documents/download.php?src='.$document_information['documentID'].'&name='.$document_information['title'].'">'.$document_information['reference'].'&nbsp;&nbsp;-&nbsp;&nbsp;'.$document_information['title'].'</a> Ver <a href="javascript:void(0)">'.$document_information['versionNew'].'</a>';

                        $participantObj->setItemInfo(array('id' => $documentItem['authParticipantID']));
                        $participant_arr = $participantObj->displayItemMaininfoById();
                        $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
            
			$comment 		= $documentItem['comments'] == '' ? '-' : smartisoStripslashes($documentItem['comments']);
			$due_date		= format_date($documentItem['contribDueDate']);

			$listdata .= "<tr>";
			$listdata .= "<td>".$section_ref."</td>";
			$listdata .= "<td>".$document."</td>";
                        $listdata .= "<td>".$who_name."</td>";
			$listdata .= "<td>".$comment."</td>";
			$listdata .= "<td>".$due_date."</td>";
			$listdata .= "<td><a href='javascript:void(0)' class='contributor_action' rel='".$documentItem['contributorID']."|".$documentItem['cmsdocID']."'>View</a></td>";
			$listdata .= "</tr>";
		}
	} // end for
} // end if

$listdata .= "</tbody><tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</tfoot>
</table>";

echo $listdata;