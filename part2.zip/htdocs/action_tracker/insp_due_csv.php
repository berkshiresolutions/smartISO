<?php
 /**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <gurnam_84@hotmail.com>
  * @package Smartiso
  * @subpackage Equipment
  * @since  Friday, January 14, 2011 5:44:40 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];
//$objExport = new ExportData('inspectionccp','csv');
//$objExport->downloadFile();


require_once dirname(__FILE__) . '/../php_excel/Classes/PHPExcel.php';
// Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
// Set document properties
    $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
    
    

$bcp		=		new InspectionDueActionExport();
$data = $bcp->getListingforExport();
 
 
$headerStyle = array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '360036'),
            'border' => false,
        ),
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF'),
        )
    );
    $styleArray = array(
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF')
    ));
    $borderStyle = array('borders' =>
        array('outline' =>
            array('style' => PHPExcel_Style_Border::BORDER_THICK,
                'color' => array('argb' => '360036'),),),);
    $rowCount = 1; 

    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, 'Location')
            ->SetCellValue('B' . $rowCount, 'Reference No.')            
            ->SetCellValue('C' . $rowCount, 'Action')           
            ->SetCellValue('D' . $rowCount, 'Due Date')
            ->SetCellValue('E' . $rowCount, 'Assigned To')
            ->SetCellValue('F' . $rowCount, 'Done Date');

    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($headerStyle);
    $borderColumn = (intval($column) - 1 );
    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($borderStyle);
     
    
    $i = 2;
    if ($data) {
        foreach ($data as $value) {     
            $objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $value['name'])
                    ->setCellValue('B' . $i, $value['refrence'])                   
                    ->setCellValue('C' . $i, $value['action'])
                    ->setCellValue('D' . $i, $value['due'])
                    ->setCellValue('E' . $i, $value['assigned'])
                    ->setCellValue('F' . $i, $value['done']);
              $i++;             
              
        }
    }


//    $objPHPExcel->getActiveSheet()->getColumnDimension('A:F')->setAutoSize(false);
$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth("12");
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth("15");





$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($styleArray);

$objPHPExcel->getActiveSheet()->setAutoFilter('A1:F1');
    $objPHPExcel->getActiveSheet()->setTitle('Simple');
    $objPHPExcel->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Inspection_Due.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); 
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); 
    header('Cache-Control: cache, must-revalidate');
    header('Pragma: public'); 
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;




//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
