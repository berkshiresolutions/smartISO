<?php

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/induct_action.js';

$class_induct_action = "selected_tab"; //current tab
$LAST_BREAD_CRUM = "Induct Action"; // for current breadcrum


require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->assign('level','admin');

$specific_id = isset($_GET['actionID']) ?intval($_GET['actionID']) : 0; // CODESIGN2 SPECIFIC ACTION INPUT VIA URL
$tab_name = ( (isset($_GET['tab'])) && (in_array($_GET['tab'],array('me_pending','other_pending','me_completed','other_completed'))) ) ? $_GET['tab'] : 'me_pending'; // CODESIGN2 SPECIFIC TAB INPUT VIA URL

$smarty->assign('activeTabName',$tab_name);
$smarty->assign('activeRecordNum',$specific_id);
$smarty->assign('action_tracker_module','Induct');

$smarty->display('action_tracker/induct_action.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>