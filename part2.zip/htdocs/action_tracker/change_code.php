<?php
 /**
  $Id: assign_contributors.php,v 4.37 Thursday, January 27, 2011 6:02:23 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/change_code.js';

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$docObj = new Documents();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
	
	dump_array_and_exit($_POST);
exit;
	$context_form 			= $_POST['context_form'];
	$document['doc_id'] 		= $_POST['doc_id'];
	$document['document_comment']   = $_POST['document_comment'];

	$docObj->changeCode($document['doc_id']);

		
		$url = basename($_SERVER['PHP_SELF'])."?js=1&e=1";
	
	$action = 'Replaced';
	$docObj->documentRecordHistory($document['doc_id'],$action);

	redirection($url);
}

$js 				= (int) $_GET['js'];
$e 					= (int) $_GET['e'];
$doc_id				= (int) $_GET['doc_id'];

if ($js) {

	$smarty->assign('js',$js);
	$smarty->assign('e',$e);

} else {
$doc_id=$_GET["document_id"];
	$smarty->assign('doc_id',$doc_id);
	$smarty->assign('post_script_name','raise_alert.php');
}



$docclassObj 					= SetupGeneric::useModule('DocClassification');
$optObj						= new Option();
$document_info 					= $docObj->getDocumentInformation($doc_id);

$document_info_simple['code'] 			= $document_info['fileReference'];
$document_info_simple['document']		= $document_info['documentID'];
$document_info_simple['name'] 			= ucfirst($document_info['title']);
$document_info_simple['code27002']		= $document_info['code27002'];

$selected_standards = $optObj->getOption('_SU_STANDARDS_CHOOSEN');
    $stdArr = explode("~", $selected_standards);

    
    if (in_array(9, $stdArr)) {
        $STOW = true;
        $msr_STOW_code= $docObj->getLinkedCode(9,$doc_id);
        $stow_data = $docObj->getSTOWList($document_info['fileReference'],$msr_STOW_code);
    } else
        $STOW = false;

$msr_data = $docObj->getMSRList($document_info['fileReference']);

        $code51Data=$docObj->getDocument51();
    
    foreach($code51Data as $code51){
        $code51dd[$code51["ID"]]="A".$code51["code"]." ".$code51["name"];
    }
    
    $smarty->assign('code51', $code51dd);
$smarty->assign('row_data',$document_info_simple);
$smarty->assign('SCRIPT_PATH',_SCRIPT_PATH);
$smarty->assign('STOW', $STOW);
$smarty->assign('stow_data', $stow_data);
$smarty->assign('msr_data', $msr_data);
$smarty->assign('id',$id);


$smarty->display('action_tracker/change_code.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';