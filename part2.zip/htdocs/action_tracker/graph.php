<?php
 /**
  $Id: graph.php,v 3.15 Monday, January 31, 2011 4:05:49 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage System Reviews
  * @since  Friday, November 26, 2010 6:35:58 PM>
  */

//$class_activity_details = "selected_tab"; // for selected tab
$class_contributor = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Graph"; // for current breadcrums

$_PAGE_VALIDATION_SCRIPT = 'system_review/graphLive.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

include(_MYCLASSES.'graph/graphs.php');
include(_MYCLASSES.'graph/documents.php');


$filter['review_id'] = $_GET['aid'];
$filter['std_id'] = $_GET['sid'] == '' ? 7 : $_GET['sid'];

$selected_year_value = $filter['year'].'&bu='.$filter['bu'];

$current_year = date('Y')-3;
for( $i=0;$i<=3;$i++ ) {

	$key = $current_year.'&bu='.$filter['bu'];
	$year_array[$key] = $current_year;
	$current_year++;
}


$stdObj 					= SetupGeneric::useModule('Standard');
$active_standards 			= $stdObj->getActiveStandards();
$active_standards_count 	= count($active_standards);
$default_standard			=  $filter['std_id']; // CMS 9k default tab
$standards 					= array();

if ( strip_tags($_GET['type']) == '' ) {
	$graph_display_type = 'column';
} else {
	$graph_display_type = strip_tags($_GET['type']);
}


$choosenStandards		= $stdObj->displayItems();

$heading = "";

if ($active_standards_count) {

	$k = 2;
	foreach ( $active_standards as $active_standards_ele ) {

		if ( @in_array($active_standards_ele['sID'],$choosenStandards) || $active_standards_ele['sID'] == 11 || $active_standards_ele['sID'] == 7 ) {

			//if ( strtolower($active_standards_ele['fullname']) == 'msr' || strtolower($active_standards_ele['fullname']) == 'cms 9k' || strtolower($active_standards_ele['fullname']) == 'iso 22000' || strtolower($active_standards_ele['fullname']) == 'osa 18001' ) {

				if ( strtolower($active_standards_ele['fullname']) != 'msr' && strtolower($active_standards_ele['fullname']) != 'cms 9k' ) {
					$standards[$k++]	= array('title'=>$active_standards_ele['fullname'],'sid'=>$active_standards_ele['sID']);
				}

				/*if ( strtolower($active_standards_ele['fullname']) == 'cms 9k' ) {
					$standards[1] 		= array('title'=>$active_standards_ele['fullname'],'sid'=>$active_standards_ele['sID']);
				}*/

				if ( strtolower($active_standards_ele['fullname']) == 'msr' ) {
					$standards[0] 		= array('title'=>$active_standards_ele['fullname'],'sid'=>$active_standards_ele['sID']);
				}

				if ( $filter['std_id'] == $active_standards_ele['sID'] ) {
					$heading = $active_standards_ele['fullname'];
				}
			//}

		}
	}

	ksort($standards);
}

$filter['heading'] = 'Contributors';

$incidence = new DocumentsGraph();
$incidence->setFilter($filter);
$incidence->processData();
$graph_data = $incidence->exportGraphData();
//$graph_data[] = $graph_da;
//dump_array($graph_data);
//echo $graph_display_type;
$graph = new Graphs($graph_display_type,'audit',$graph_data);



$smarty->assign('default_standard',$default_standard);
$smarty->assign('graph_display_type',$graph_display_type);

$smarty->assign('audit_id',$_GET['aid']);
$smarty->assign('current_std',$filter['std_id']);
$smarty->assign('years_data',$year_array);
$smarty->assign('selected_year',$selected_year_value);
$smarty->assign('chart_type',$graph->getGraphType());
$smarty->assign('chart_object','audit_chart');
$smarty->assign('chart_height',$graph->graph_height);
$smarty->assign('chart_width',$graph->graph_width);
$smarty->assign('chart_backgroundcolor','#FFFFFF');
$smarty->assign('data_file',$graph->xml_data_file);
$smarty->assign('setting_file',$graph->graph_settings_file);
$smarty->assign('review_id',$filter['review_id']);

$smarty->display('documents/main.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>