<?php
/**
 $Id: insp_ccp.php,v 3.09 Thursday, December 16, 2010 10:48:56 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Inspection(CCP) - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Tuesday, September 21, 2010 6:46:47 PM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/smart_bcp.js';

$class_bcp = "selected_tab"; //current tab
$LAST_BREAD_CRUM = "BCP Risk Action"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/smart_bcp.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>