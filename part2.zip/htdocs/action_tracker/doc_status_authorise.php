<?php
 /**
  $Id: doc_status_authorise.php,v 3.02 Thursday, September 16, 2010 10:45:27 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Thursday, September 16, 2010 10:44:37 AM>
  */

$cid = (int) $_GET['cid'];

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

//dump_array($_POST);
$smarty->display('action_tracker/doc_status_authorise.tpl');
require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>