<?php    

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$soaObj 		= new SOA();

$code=substr($_GET["code"],2,100);
$data=$soaObj->getAnswer27002Data($code);; 

echo str_replace("’","`",$data["description"]);
                        
?>