<?php
/**
 $Id: insp_me.php,v 3.08 Friday, November 26, 2010 12:03:24 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Inspection(ME) - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Thursday, September 23, 2010 12:14:31 PM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/insp_me.js';

$class_inspection_me = "selected_tab"; //current tab
$LAST_BREAD_CRUM = "Inspection (ME)"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/insp_me.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>