<?php
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false; 
$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
//echo "<!-- Date + 5 days: ".DateTime::createFromFormat( 'd/m/Y', date('d/m/Y') )->add( new DateInterval('P'.(33).'D') )->format('d/m/Y')." -->";
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'induct';

$filter_date = $_GET['filter_date'];

if ( $level == 1 ) {
	$is_admin = true;
}

$show_au_approve = true;

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
	$show_au_approve = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$show_done_date = true;

if ( $tab_type == 'other_pending' && $level != 1 ) {
	$show_done_date = false;
}

$actTrackObj = new ActionTracker();
echo "<!-- Tab Type: $tab_type -->";
echo "<!-- Filter Date: $filter_date -->";

try {

	$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$tab_type,$filter_date);
	$resultset = $actTrackObj->getActionsForActionTracker();

	// echo $tab_type;
	// dump_array($resultset);

	$listdata = "<form class='action_tracker_listing' name='risk_form' method='post'>";
	$listdata .= "<table class='display' id='module_records'><thead><tr>
				<th width='13%'>Business Unit</th>
				<th width='12%'>Type</th>
				<th width='32%'>Actions</th>
				<th width='10%'>Due Date</th>";

	if ($show_participant_name) {
		$listdata .= "<th width='17%'>Assigned to</th>";
	}

	if ( $show_done_date ) {
		$listdata .= "<th width='15%'>Completed Date</th>";
	}

	if ( $show_au_approve ) {
		$listdata .= "<th width='7%'>"._AU_APPROVE_ACTION_TRACKER_LABEL."</th>";
	}

	if ($is_admin) {
		$listdata .= "<th width='5%'>Approve</th>";
	}

	$listdata .= "</tr></thead><tbody>";

	$jsdata = $jsdata_second = $jsdata_third = '';

	$specific_id = isset($_GET['actionID']) ?intval($_GET['actionID']) : 0; // CODESIGN2 SPECIFIC ACTION INPUT VIA URL
	
	foreach ( $resultset as $resultElementKey=>$resultElement ) {
		//if(empty($resultElement['ID'])){ continue; }
		//dump_array($resultset);
		echo "<!-- [$resultElementKey]= ".var_export($resultElement,true)." -->";
		
		$ac_id = $resultElement['actionData']['ID'];
		
		
		if(($specific_id > 0) && ($ac_id != $specific_id)) { continue; } // CODESIGN2 ACTION SKIP IF SPECIFIED
		
		
		$question_summary 				= $resultElement['recordType'];
		$recommendation_summary 		= compact_action_tracker_description($resultElement['actionData']['recommendation']);
		$action_description 			= $resultElement['description'];

		$question_summary_full 			= javascript_safe_string($resultElement['actionData']['question']);
		$recommendation_summary_full 	= javascript_safe_string($resultElement['actionData']['recommendation']);
		$action_description_full 		= explode(':|:',javascript_safe_string($resultElement['actionData']['actionDescription']));
		$action_description_full	=	$action_description_full[1];
		$buTxt = $resultElement['buName'];
		$listdata .= "<tr>";
		$listdata .= "<td>".(strlen($buTxt) > 2 ? $buTxt : 'N/A')/*."<!-- ".var_export($resultElement['actionData'],true)." -->"*/."</td>";
		$listdata .= "<td><a href='javascript:void(0)' class='showquestion_".$ac_id."'>".$question_summary."</a></td>";
		$listdata .="<td><a href='javascript:void(0)' class='showaction_".$ac_id."'>".$action_description."</a></td>";
		$listdata .="<td>".( str_replace( '1990-01-01','N/A',date( 'Y-m-d', max(strtotime( '1990-01-01' ), strtotime($resultElement['actionData']['dueDate'])) ) ) )."</td>";

		if ($show_participant_name) {
			$listdata .= "<td>".$resultElement['actionData']['who_name']."</td>";
		}

		if ( $show_done_date ) {
			if ( $tab_type == 'me_completed' || $tab_type == 'other_completed' ) {
				//$listdata .="<td>".format_date($resultElement['actionData']['doneDate'])."&nbsp;&nbsp;<a href='javascript:void(0)' class='showcomment_".$ac_id."'>[AC]</a></td>";
				$listdata .= "<td>";
				$listdata .= ( str_replace( '1990-01-01','N/A',date( 'Y-m-d', max(strtotime( '1990-01-01' ), strtotime($resultElement['actionData']['doneDate'])) ) ) );
				$listdata .= '<a href="javascript:void(0)" class="showcomment_'.$ac_id.'">[AC]</a>';
				$listdata .= "</td>";
			} else {

				if ( $resultElement['actionData']['doneDate'] == '' || $resultElement['actionData']['doneDate'] == '0000-00-00' || $resultElement['actionData']['doneDate'] == '1970-01-01') {

					if ( $resultElement['actionData']['who'] == getLoggedInUserId()|| getLoggedInUserId() == 33 ) {
						$listdata .="<td>
								<input type='text' name='done_date_".$ac_id."' id='done_date_".$ac_id."' size='20' class='datepicker dateText' />
								&nbsp;<a href='javascript:void(0)' class='smartlightbox act_done' alt='".$ac_id."'  rel='map_with:action_done_comment_".$ac_id."'>Done</a>
								<input type='hidden' class='action_done_comment_".$ac_id."' name='action_done_comment_".$ac_id."' id='action_done_comment_".$ac_id."' value='{$resultElement['actionData']['doneDescription']}'/>
							</td>";
					} else {
						$listdata .= "<td>Not completed yet</td>";
					}
				} else {
					// $listdata .="<td>".format_date($resultElement['actionData']['doneDate'])."&nbsp;&nbsp;<a href='javascript:void(0)' class='showcomment_".$ac_id."'>[AC]</a></td>";
					$listdata .="<td>";
					$listdata .= ( str_replace( '1990-01-01','N/A',date( 'Y-m-d', max(strtotime( '1990-01-01' ), strtotime($resultElement['actionData']['doneDate'])) ) ) );
					$listdata .= '<a href="javascript:void(0)" class="showcomment_'.$ac_id.'">[AC]</a>';
					$listdata .= "</td>";
				}
			}
		}

		$action_comment = javascript_safe_string($resultElement['actionData']['doneDescription']);

		$jsdata .= "\n$('.showcomment_".$ac_id."').smartLightBox({heading: 'Comment/Reason',writeMode : false,width: '500',height: '200',description : '".$action_comment."'});";
		$jsdata_second .= "\n$('.showquestion_".$ac_id."').smartLightBox({heading: 'Question',writeMode : false,width: '500',height: '200',description : '".$question_summary_full."'});";
		$jsdata_third .= "\n$('.showaction_".$ac_id."').smartLightBox({heading: 'Actions',writeMode : false,width: '500',height: '200',description : '".$action_description_full."'});";
		$jsdata_fourth .= "\n$('.showrecommendation_".$ac_id."').smartLightBox({heading: 'Recommendation',writeMode : false,width: '500',height: '200',description : '".$recommendation_summary_full."'});";

		if ( $resultElement['actionData']['approveAU'] == 0 && ( $tab_type == 'me_pending' || $tab_type == 'other_pending' ) ) {
			if ( $resultElement['actionData']['whoAU'] == getLoggedInUserId() || getLoggedInUserId() == 33) {
				if ( $resultElement['actionData']['doneDate'] == '' || $resultElement['actionData']['doneDate'] == '0000-00-00' || $resultElement['actionData']['doneDate'] == '1970-01-01' ) {
					$listdata .= "<td></td>";
				} else {
					$listdata .= "<td><input type='checkbox' class='au_approve_action' name='au_approve_".$ac_id."' id='au_approve_".$ac_id."' value='".$ac_id."' /></td>";
				}
			} else {
				if ( $resultElement['actionData']['doneDate'] == '' || $resultElement['actionData']['doneDate'] == '0000-00-00' || $resultElement['actionData']['doneDate'] == '1970-01-01' ) {
					$listdata .= "<td></td>";
				} else {
					$listdata .= "<td>Pending</td>";
				}
			}
		} else {
			if ( $show_au_approve ) {
				$listdata .= "<td>Approved</td>";
			}
		}

		if ($is_admin) {
			if ( $resultElement['actionData']['doneDate'] == '' || $resultElement['actionData']['doneDate'] == '0000-00-00' || $resultElement['actionData']['doneDate'] == '1970-01-01' ) {
				$listdata .= "<td></td>";
			} else {
				if ( $resultElement['actionData']['actionData']['approveAU'] == 0 ) {
					$listdata .= "<td></td>";
				} else {
					$listdata .= "<td><input type='checkbox' class='approve_action' name='approve_".$ac_id."' id='approve_".$ac_id."' value='".$ac_id."' /></td>";
				}
			}
		}

		$listdata .= "<input type='hidden' name='done_date_db_".$ac_id."' id='done_date_db_".$ac_id."'value='".$done_date."' />";
		$listdata .= "<input type='hidden' name='action_done_comment_".$ac_id."' id='action_done_comment_".$ac_id."' value='".$resultElement['actionData']['doneDescription']."'>";
		$listdata .= "</tr>";
	}

	$listdata .= "</tbody>";

	$listdata .= "</table></form>";
	$listdata .= "<div class='footnote'><b>Note :</b> To view full Question / Recommendation / Action, click the corresponding box.</div>";

	$listdata .= "<script> (function($) { $(document).ready(function () {";
	$listdata .= $jsdata;
	$listdata .= $jsdata_second;
	$listdata .= $jsdata_third;
	$listdata .= $jsdata_fourth;
	$listdata .= "$('.datepicker').datepicker({changeMonth: true,changeYear: true});";
	$listdata .= "});})(jQuery);	</script>";

} catch ( ErrorException $e ) {
	$listdata = $e->getMessage();
}

echo $listdata;
?>