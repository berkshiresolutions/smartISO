<?php
/**
 $Id: record_non_conf_inc.php,v 3.36 Thursday, February 03, 2011 12:37:43 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Non-conformance(Incidence) - Assigned to me(pending) from the database.
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Thursday, September 23, 2010 4:24:32 PM>
*/

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
$participantObj = SetupGeneric::useModule('participant');
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'Nonconformance inc'; // do not change this string

$filter_date = $_GET['filter_date'];

if ( $level == 1 ) {
	$is_admin = true;
}

$show_au_approve = true;

if ( $tab_type == 'other_completed' || $tab_type == 'me_completed' ) {
	$is_admin = false;
	$show_au_approve = false;
} else if ( $tab_type == 'other_pending' || $tab_type == 'other_completed' ) {
	$show_participant_name = true;
}

$show_done_date = true;

if ( $tab_type == 'other_pending' && $level != 1 ) {
	$show_done_date = false;
}

$actTrackObj = new ActionTracker();

try {

	$actTrackObj->setActionTrackerInfo($action_tracker_module_name,$tab_type,$filter_date);
	$resultset = $actTrackObj->getActionsForActionTracker();

	$listdata = "<form class='action_tracker_listing' name='risk_form' method='post'>";
	$listdata .= "<table class='display' id='module_records'><thead><tr>
				<th width='10%'>Business Unit</th>
				<th width='10%'>Reference No.</th>
				<th width='16%'>Action</th>
				<th width='8%'>Due Date</th>";

	if ($show_participant_name) {
		$listdata .= "<th width='10%'>Assigned to</th>";
	}

		$listdata .= "<th width='15%'>Completed Date</th>";

    $listdata .= "<th width='7%' title='2nd Approver to Verify for Effectiveness'>VfE</th>";

    $listdata .= "<th width='5%' title='Manager to Verify for Effectiveness'>Verify</th>";

	$listdata .= "</tr></thead><tbody>";

	$jsdata = $jsdata_second = $jsdata_third = '';
         $optionObj = new Option();
    $red = $optionObj->getOption('_SU_EMAIL_REDMAIL');
    $yellow = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
    $green = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
 
	foreach ( $resultset as $resultElement ) {
		

                 $str = (strtotime($resultElement['dueDate'])) - strtotime(date("M d Y "));
        $dateinc = floor($str / 3600 / 24);

        if ($tab_type == 'me_completed' || $tab_type == 'other_completed') {
            $change_bg_color = "";
        } else if ($dateinc > $green) {
            $change_bg_color = "";
        } else if ($dateinc > $yellow) {
            $change_bg_color = "style='background-color:green;COLOR:WHITE'";
        } else if ($dateinc > $red) {
            $change_bg_color = "style='background-color:#F4A460;COLOR:WHITE'";
        } else {
            $change_bg_color = "style='background-color:red;COLOR:WHITE'";
        }
	
            
		$ac_id = $resultElement['id'];
		$action_description 		= compact_action_tracker_description($resultElement['actionDescription']);
		$action_description_full 	= javascript_safe_string($resultElement['actionDescription']);

		$listdata .= "<tr>";
                $listdata .= "<td " . $change_bg_color . " >";
		$listdata .= "<a href='javascript:void(0)' class='act_goto' rel=" . $resultElement['ID'] . " >".$resultElement['buName']."</a></td>";
		$listdata .= "<td>".$resultElement['reference']."</td>";
		$listdata .="<td>";
		$listdata .="<a href='javascript:void(0)' class='showaction' rel='".$ac_id."'>".$action_description."</a>";
		$listdata .="</td>";
		$listdata .="<td>".format_date($resultElement['dueDate'])."</td>";

        if ($show_participant_name) {
            $participantObj->setItemInfo(array('id' => $resultElement['currentWho']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

            $listdata .= "<td>" . $who_name . "</td>";
        }

        if ($tab_type == 'me_completed' || $tab_type == 'other_completed') {
            $participantObj->setItemInfo(array('id' => $resultElement['who']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
            $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";
            if ((int) $resultElement['addapprover'] > 0) {
                $participantObj->setItemInfo(array('id' => $resultElement['addapprover']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='show2appcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";
            } else {
                $listdata .="<td>&nbsp;-&nbsp;</td>";
		}


            $participantObj->setItemInfo(array('id' => $resultElement['whoAU']));
            $participant_arr = $participantObj->displayItemMaininfoById();
            $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
            $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showapprovecomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";"</td>";
        } elseif ($tab_type == 'me_pending' || $is_admin) {
                      if ($resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00') {

                $listdata .="<td>&nbsp;<a href='javascript:void(0)' class='act_done' rel=" . $ac_id . "  >Action</a></td><TD></td><TD></td>";
            } elseif (( $resultElement['app2date'] == '' || $resultElement['app2date'] == '0000-00-00' ) && (int) $resultElement['addapprover'] > 0) {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD>&nbsp;<a href='javascript:void(0)' class='act_2_approve' rel='" . $ac_id . "'  >Action</a></td><TD></td>";
					} else {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

                $participantObj->setItemInfo(array('id' => $resultElement['addapprover']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who2app_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

                if ((int) $resultElement['addapprover'] > 0) {

                    $app2Text = $who2app_name . " - " . format_date($resultElement['doneDate']). "<a class='show2appcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";;
				} else {
                    $app2Text = " - ";
				}
                $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD>" . $app2Text . "</td><TD>&nbsp;<a href='javascript:void(0)' class='final_approval' rel='" . $ac_id . "'  >Action</a></td>";
            }
			} else {
            if ($resultElement['doneDate'] == '' || $resultElement['doneDate'] == '0000-00-00') {

                $listdata .="<td>&nbsp;Pending</td><TD></td><TD></td>";
            } elseif (( $resultElement['app2date'] == '' || $resultElement['app2date'] == '0000-00-00' ) && (int) $resultElement['addapprover'] > 0) {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];
                $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD>&nbsp;Pending</td><TD></td>";
				} else {
                $participantObj->setItemInfo(array('id' => $resultElement['who']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

                $participantObj->setItemInfo(array('id' => $resultElement['addapprover']));
                $participant_arr = $participantObj->displayItemMaininfoById();
                $who2app_name = $participant_arr['forename'] . ' ' . $participant_arr['surname'];

                if ((int) $resultElement['addapprover'] > 0) {

                    $app2Text = $who2app_name . " - " . format_date($resultElement['doneDate']). "<a class='show2appcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td>";;
				} else {
                    $app2Text = " - ";
				}
                $listdata .="<td>" . $who_name . " - " . format_date($resultElement['doneDate']) . "<a class='showcomment' rel=" . $ac_id . " href='javascript:void(0)'>[AC]</a></td><TD>" . $app2Text . "</td><TD>&nbsp;Pending</td>";
			}
		}
	}
	$listdata .= "</tbody><tfoot><tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>";

	if ($is_admin) {
		$listdata .= "<td>&nbsp;</td>";
	}
	$listdata .= "</tr></tfoot></table></form>";
	$listdata .= "<div class='footnote'><b>Note :</b> To view full Action, click the corresponding box.</div>";

	$listdata .= "<script> (function($) { $(document).ready(function () {";
	$listdata .= $jsdata;
	$listdata .= $jsdata_second;
	$listdata .= $jsdata_third;
	$listdata .= "$('.datepicker').datepicker({changeMonth: true,changeYear: true});";
	$listdata .= "});})(jQuery);	</script>";

} catch ( ErrorException $e ) {
	$listdata = $e->getMessage();
}

echo $listdata;
?>