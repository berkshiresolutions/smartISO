<?php
/**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2011 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <gurnam_84@hotmail.com>
 * @package Smartiso
 * @subpackage Equipment
 * @since  Friday, January 14, 2011 5:44:40 PM>
 */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];
/*
header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=Observation.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

$fn = fopen('Observation.xls', 'w');
$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
$tab_type = strip_tags($_GET['showtype']) == "undefined" ? 'me_pending' : strip_tags($_GET['showtype']);
$participantObj = SetupGeneric::useModule('participant');
$orgObj = SetupGeneric::useModule('organigram');
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'gov1';

$filter_date = $_GET['filter_date'];

if ($level == 1) {
    $is_admin = true;
}

$show_au_approve = true;

if ($tab_type == 'other_completed' || $tab_type == 'me_completed') {
    $is_admin = false;
    $show_au_approve = false;
} else if ($tab_type == 'other_pending' || $tab_type == 'other_completed') {
    $show_participant_name = true;
}

$show_done_date = true;

if ($tab_type == 'other_pending' && $level != 1) {
    $show_done_date = false;
}

$actTrackObj = new ActionTracker();


$actTrackObj->setActionTrackerInfo($action_tracker_module_name, $tab_type, $filter_date);
$resultset = $actTrackObj->getActionsForActionTracker();
?>
<table cellspacing='0' cellpadding='0' width='100%' border='1'>

    <tr style='border: 1px solid;background: #360036;color: #fff;font-weight:bold;font-family:arial,sans-serif;'>

       
        <td>Reference</td>
          <td>Problem</td>
        <td>Description</td>
        <td >Action</td>
        <td >Due Date</td>        
        <td >Done Date</td>
    </tr>
<?php
foreach ($resultset as $v) {
    ?>
        <tr style='border: 1px solid;'>


           
            <td><?php echo $v['reference']; ?></td>
             <td><?php echo compact_action_tracker_description($resultElement['problem']); ?></td>
            <td ><?php echo $v['actionDescription']; ?></td>
            <td ><?php echo $v['action']; ?></td>
            <td ><?php format_date($resultset['dueDate']) ?></td>
            <td ><?php format_date($resultset['doneDate']) ?></td>           
        </tr>
    <?php
}
?>
</table>
    <?php
    fclose($fn);
*/



require_once dirname(__FILE__) . '/../php_excel/Classes/PHPExcel.php';
// Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
// Set document properties
    $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
    
    
$is_admin = false;
$show_participant_name = false;

$tab_type = strip_tags($_GET['showtype']) == "" ? 'me_pending' : strip_tags($_GET['showtype']);
$tab_type = strip_tags($_GET['showtype']) == "undefined" ? 'me_pending' : strip_tags($_GET['showtype']);
$participantObj = SetupGeneric::useModule('participant');
$orgObj = SetupGeneric::useModule('organigram');
$USER_ID = getLoggedInUserId();
$level = getUserAccessLevel();
$action_tracker_module_name = 'gov1';

$filter_date = $_GET['filter_date'];

if ($level == 1) {
    $is_admin = true;
}

$show_au_approve = true;

if ($tab_type == 'other_completed' || $tab_type == 'me_completed') {
    $is_admin = false;
    $show_au_approve = false;
} else if ($tab_type == 'other_pending' || $tab_type == 'other_completed') {
    $show_participant_name = true;
}

$show_done_date = true;

if ($tab_type == 'other_pending' && $level != 1) {
    $show_done_date = false;
}

$actTrackObj = new ActionTracker();


$actTrackObj->setActionTrackerInfo($action_tracker_module_name, $tab_type, $filter_date);
$data = $actTrackObj->getActionsForActionTracker();
 
 
$headerStyle = array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '360036'),
            'border' => false,
        ),
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF'),
        )
    );
    $borderStyle = array('borders' =>
        array('outline' =>
            array('style' => PHPExcel_Style_Border::BORDER_THICK,
                'color' => array('argb' => '360036'),),),);
    $rowCount = 1; 
     
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, 'Reference')
            ->SetCellValue('B' . $rowCount, 'Problem')            
            ->SetCellValue('C' . $rowCount, 'Description')           
            ->SetCellValue('D' . $rowCount, 'Action')           
            ->SetCellValue('E' . $rowCount, 'Due Date')          
            ->SetCellValue('F' . $rowCount, 'Done Date');

    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($headerStyle);
    $borderColumn = (intval($column) - 1 );
    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($borderStyle);   
          
    $i = 2;         
    if ($data) {
        foreach ($data as $value) {             
            $objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $value['reference'])
                    ->setCellValue('B' . $i, compact_action_tracker_description($value['problem']))                   
                    ->setCellValue('C' . $i, $value['actionDescription'])                             
                    ->setCellValue('D' . $i, $value['action'])                   
                    ->setCellValue('E' . $i, format_datetime($value['dueDate']))                   
                    ->setCellValue('F' . $i, format_datetime($value['doneDate']));
              $i++;             
              
        }
    }


    $objPHPExcel->getActiveSheet()->setTitle('Simple');
    $objPHPExcel->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Observation.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); 
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); 
    header('Cache-Control: cache, must-revalidate');
    header('Pragma: public'); 
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;






//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
    ?>