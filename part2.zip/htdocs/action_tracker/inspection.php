<?php
/**
 $Id: inspection.php,v 3.17 Friday, October 01, 2010 6:05:40 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file accesses records for Inspection(CCP) - Assigned to me(pending) from the database.
 *
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Tuesday, September 21, 2010 6:33:47 PM>
*/

$is_admin = false;
$show_participant_name = false;

$type = $_GET['showtype'];
$type = $type == "" ? 'me_pending' : $type;

$level = 1;

if ( $level == 1 ) {
	$is_admin = true;
}

if($type == 'other_completed' || $type == 'me_completed') {
	$is_admin = false;
}

if ( $type == 'other_pending' || $type == 'other_completed' ) {
	$show_participant_name = true;
}

$reference_no	= "PF0920001";
$step			= "step1";
$hazards	 	= "hazard";
$actions		= "action";
$due_date		= "Jan 26 2010";

echo "<table class='display' id='module_records'>
	<thead>
		<tr>
			<th width='12%'>Reference #</th>
			<th width='10%'>Step</th>
			<th width='17%'>Hazards</th>
			<th width='17%'>Actions</th>
			<th width='14%'>Due Date</th>
			<th width='20%'>Done Date/Comment</th>";
			if ($is_admin) {
				echo "<th width='10%'>Approved</th>";
			}
		echo "</tr>
	</thead>

	<tbody>";
	for ($i=1;$i<=15;$i++) {
		echo "<tr>";
			echo "<td>".$reference_no."</td>";
			echo "<td>".$step."</td>";
			echo "<td>".$hazards."</td>";
			echo "<td>".$actions."</td>";
			echo "<td>".$due_date."</td>";
			echo "<td>
					<input type='text' name='done_date_{$i}' id='done_date_{$i}' size='20' class='datepicker' />
					<span><a href='javascript:void(0)'>Done</a></span>
				</td>";
			if ($is_admin) {
				echo "<td><input type='checkbox' name='approved_{$i}' id='approved_{$i}' value='{$i}' /></td>";
			}
		echo "</tr>";
	}
	echo "</tbody>

	<tfoot>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>";
			if ($is_admin) {
				echo "<td>&nbsp;</td>";
			}
		echo "</tr>
	</tfoot>
</table>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";

echo "<b>Note :</b> To view full Hazard/Action, click the corresponding box.";
?>