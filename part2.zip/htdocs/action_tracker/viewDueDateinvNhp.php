<?php
 /**
  $Id: assign_contributors.php,v 4.37 Thursday, January 27, 2011 6:02:23 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/viewDueDateinvNhp.js';

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$docObj = new Documents();
$Obj = new ActionTracker();



if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
	
	dump_array($_POST);
exit;
	$context_form 						= $_POST['context_form'];
	$document['doc_id'] 				= $_POST['doc_id'];
	$document['document_comment'] 		= $_POST['document_comment'];


	$docContObj = new DocumentContributor();

	if ( $context_form == 'contributor' ) {

		$docContObj->assignContributors($document['doc_id'],array('contributors'=>$assign_contributors,'due_date'=>$due_date,'comment'=>$document['document_comment']));

		$url = basename($_SERVER['PHP_SELF'])."?doc_id=".$document['doc_id']."&e=18";
	}/* else if ( $context_form == 'approval' ) {

		$docContObj->approveDocument($document['doc_id']);

		$url = basename($_SERVER['PHP_SELF'])."?js=1&e=1";
	}*/

	redirection($url);
}

$js 				= (int) $_GET['js'];
$e 					= (int) $_GET['e'];
$doc_id				= (int) $_GET['doc_id'];

if ($js) {

	$smarty->assign('js',$js);
	$smarty->assign('e',$e);

} else {

	$smarty->assign('doc_id',$doc_id);
	$smarty->assign('post_script_name','raise_alert.php');
}

$document_contributors 	= array();


$docclassObj 					= SetupGeneric::useModule('DocClassification');
$document_classification 		= $docclassObj->displayItems();
$optObj							= new Option();
$miscObj 						= new Misc();
$version_type 					= $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$document_types 				= $miscObj->getDocumentTypes();
$optObj							= null;
$miscObj 						= null;
$participantObj				 	= 		SetupGeneric::useModule('Participant');

$document_info 							= $docObj->getDocumentInformation($doc_id);
$document_contributors 					= $docObj->getDocumentContributors($doc_id);
$document_contributors_count			= count($document_contributors);
$document_contributors_replied			= 0;

if ( $document_contributors_count ) {

	/*
	[contributorID] => 9
	[cmsdocID] => 10
	[authParticipantID] => 10
	[date] => 0000-00-00 00:00:00
	[passed] => 0
	[comments] =>
	[docIssuerAuth] => 0
	[contributorAssign] => 0
	[documentID] =>
	[contribDueDate] => 0000-00-00
	*/

	$k = 0;

	//dump_array($document_contributors);

	foreach ( $document_contributors as $contributor_ele ) {


		$participant_id = $contributor_ele['authParticipantID'];
		$participantObj->setItemInfo(array('id'=>$participant_id));
		$partcipantData = $participantObj->displayItemById();

		$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];

		$document_contributors_simple[$k]['contributor_name'] 	= $participant_name == ' ' ? '-' : $participant_name;

		switch ($contributor_ele['passed']) {
			case 0: $document_contributors_simple[$k]['response'] = 'Waiting'; break;
			case 1: $document_contributors_simple[$k]['response'] = 'Approved'; break;
			case 2: $document_contributors_simple[$k]['response'] = 'Not Approved'; break;
		}

		$document_contributors_simple[$k]['response'] = $contributor_ele['passed'];

		if ($contributor_ele['passed']) {
			$document_contributors_replied++;
		}

		$document_contributors_simple[$k]['comments'] 			= ucfirst($contributor_ele['comments']);

		if ( $contributor_ele['documentID'] != 0 ) {
			$objFile = new Upload();
			$objFile->setFileInfo('contributors',array('id'=>$contributor_ele['documentID']));
			$file_detail = $objFile->getFileDetails();

			$document_contributors_simple[$k]['file_uploaded'] 	= "<a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=".$file_detail['sysFilename']."&un=".$file_detail['usrFilename']."&module=contributors','mywindow')\">".$file_detail['usrFilename']."</a>";
		} else {
			$document_contributors_simple[$k]['file_uploaded'] 	= '-';
		}

		$document_contributors_simple[$k]['contrib_due_date'] 	= format_date($contributor_ele['contribDueDate']);

		$k++;
	}
}

$document_info_simple['code'] 			= $document_info['fileReference'];
$document_info_simple['document']		= $document_info['documentID'];
$document_info_simple['name'] 			= ucfirst($document_info['title']);
$document_info_simple['description'] 	= ucfirst($document_info['description']);
$document_info_simple['type'] 			= $document_types[$document_info['documentType']];
$document_info_simple['initiated'] 		= format_date($document_info['dateInitiated']);
$document_info_simple['initiated_by'] 	= $document_info['initiatedByParticipant'];
$document_info_simple['version_type']	= ucfirst($version_type);
$document_info_simple['version'] 		= $document_info['versionNew'];
$document_info_simple['approved_date']	= $document_info[''];
$document_info_simple['approved_by'] 	= $document_info[''];
$document_info_simple['action_summary'] = ucfirst($document_info['actionSummary']);
$document_info_simple['pages'] 			= $document_info['pages'];

if ($document_classification) {

	foreach ( $document_classification as $document_class_ele => $document_class_val ) {

		if ( substr($document_class_ele,0,1) == $document_info['classification'] ) {
			$document_info_simple['classification'] = $document_class_val;
			break;
		}
	}
}
$action_id  = (int) $_GET['id'];
$type  =  $_GET['type'];
$module =  $_GET['module'];
$action_data = $Obj->getDetailsAction($action_id);
$due_date = format_date($action_data['dueDate']);

$who = ($action_data['who']);

 $today =  date("m/d/Y");
 
 $id =  getLoggedInUserId();

$participantObj->setItemInfo(array('id'=>$action_data['who']));
	
	$data = $participantObj->displayDoc();
//dump_array($data);
  $name = $data['forename'].' '.$data['surname'];
 
 $participantObj->setItemInfo(array('id'=>$action_data['whoAU']));
	
	$data_au = $participantObj->displayDoc();
//dump_array($data);

  $name_au = $data_au['forename'].' '.$data_au['surname'];
$smarty->assign('action_id',$action_id);
$smarty->assign('type',$type);
$smarty->assign('module',$module);

$smarty->assign('name_au',$name_au);
$smarty->assign('name',$name);
$smarty->assign('due_date',$due_date);
$smarty->assign('who_ID',$action_data['who']);
$smarty->assign('au_ID',$action_data['whoAU']);
$smarty->assign('row_data',$document_info_simple);
$smarty->assign('document_contributors',$document_contributors_simple);
$smarty->assign('document_contributors_count',$document_contributors_count);
$smarty->assign('document_contributors_replied',$document_contributors_replied);
$smarty->assign('SCRIPT_PATH',_SCRIPT_PATH);
$smarty->assign('today',$today);
$smarty->assign('id',$id);
$smarty->assign('name',$name);

if ( $document_info['status'] == 'A' ) {
	$smarty->assign('document_approved',1);
} else {
	$smarty->assign('document_approved',0);
}

$smarty->display('action_tracker/viewDueDateinvNhp.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';