<?php
/**
 $Id: smart_law_assign_me_pending_listing.php,v 3.07 Thursday, December 16, 2010 12:04:48 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Smart Law - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Saturday, September 25, 2010 11:14:27 AM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/smart_law.js';

$class_smart_law  = "selected_tab"; //current tab
$LAST_BREAD_CRUM  = "Smart Law"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->display('action_tracker/smart_law_assign_me_pending.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>