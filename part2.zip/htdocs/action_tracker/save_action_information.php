<?php

/**
  $Id: save_action_information.php,v 3.83 Monday, December 13, 2010 4:13:32 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * for testing purpose only
 *
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @since  Monday, August 16, 2010 11:24:04 AM>
 */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$actTrackObj = new ActionTracker();

$actionId = $_GET['action_id'];
$done_date = format_date_for_mysql(strip_tags($_GET['done_date']));
$comment = strip_tags($_GET['comment']);
$action_type = strip_tags($_GET['action_type']);
$check = $_GET['check'];




if ($check == 'all_done') {

	$a_id = explode(",", $actionId);

	foreach ($a_id as $val) {
		try {
			if ($action_type == 'save_date') {
				$actTrackObj->saveActionInformation($val, $done_date, $comment);
			} else if ($action_type == 'approve') {
				$actTrackObj->approveCompletedAction($val);
			} else if ($action_type == 'au_approve') {
				$actTrackObj->approveAUApprovedAction($val);
			}
		} catch (ErrorException $e) {
			echo $e->getMessage();
		}
	}

	echo 1;
} else {
//echo "sadasd";
//try {
	if ($action_type == 'save_date') {

		$action = new Action();
		$action->setActionDetails($actionId,array());
		$actionData = $action->viewAction();

		if(strpos($actionData['actionDescription'],'SOA:') !== FALSE) {
			//
			// Update Action Complete Date
			//
			$sql = sprintf("UPDATE %s.[actions] SET [doneDate]='%s', [doneDescription]='%s' WHERE ID=%d and [doneDescription] is NULL",
			_DB_OBJ_FULL,$done_date,$comment,$actionId);
			 
		$dbHand = DB::connect(_DB_TYPE);
			$stmt = $dbHand->prepare($sql);
			$stmt->execute();

			$count=$stmt->rowCount();

			if ($count == 1){	
			//
			// Now Send Action
			//
			require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/modules/SOA.class.php';
			$soaObj = new SOA();
			$emailData = $soaObj->getEmailData($actionData['record']);

			$soaObj->sendInitialEmail($actionId,$emailData,SOA::PARTICIPANT_EMAIL,SOA::SECONDARY_EMAIL_TEXT,SOA::AU_EMAIL_SUBJECT);
}
		} else {
		//echo "sdfsdfsdf";
			$actTrackObj->saveActionInformation($actionId, $done_date, $comment);
		}
	} else if ($action_type == 'approve') {
		$actTrackObj->approveCompletedAction($actionId);
	} else if ($action_type == 'au_approve') {
		$actTrackObj->approveAUApprovedAction($actionId);
	}

	echo 1;
//} catch ( ErrorException $e ) {
//	echo $e->getMessage();
//}
}
?>