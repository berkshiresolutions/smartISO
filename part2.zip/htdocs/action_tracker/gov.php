<?php
/**
 $Id: risk_assessment.php,v 3.18 Tuesday, February 01, 2011 2:39:48 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 * This file displays data for Risk - Assigned to me(pending).
 *
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Action tracker
 * @since  Monday, September 20, 2010 12:36:28 PM>
*/

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/gov.js';

if (isset($_GET['menu']) && (int)$_GET['menu'] == 2)
$class_viewatt = "selected_tab"    ;
else 
$class_viewat = "selected_tab"    ;
$LAST_BREAD_CRUM = "Governance Audit"; // for current breadcrum

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once("../includes/saveApplicationLog.inc.php");

$smarty->assign('level','admin');

$smarty->display('action_tracker/gov.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>