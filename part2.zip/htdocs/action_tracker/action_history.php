<?php

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
$actObj = new Action();
            $participantObj = SetupGeneric::useModule('Participant');
 $buObj = SetupGeneric::useModule('Organigram');
 $locObj = SetupGeneric::useModule('Locationgram');
 
$id = $_GET["alert_id"];
$actObj->setActionDetails($id, null);
$currentData = $actObj->viewAction();

$actData = $actObj->getHistoryData($id);

switch ($currentData["moduleElement"]) {

    case 'nhp';
        $nhpObj = new NhpMain();
        $nhpObj->setNhpInfo($currentData["record"], null);
        $nhpdata = $nhpObj->viewNhpById();
                  $participantObj->setItemInfo(array('id' => $nhpdata["whoID"]));
            $partcipantData = $participantObj->displayItemById();
            $owner = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
					
						$buObj->setItemInfo(array('id'=>$nhpdata["businessUnitID"]));
						$bu = $buObj->displayItemByIdForMSR();
	
			$locObj->setItemInfo(array('id'=>$nhpdata["locationID"]));
	$loc = $locObj->displaylocationByPid();
        $action_data_html = "<DIV style='font-size: 11px;'>";
        $action_data_html .= "NCR";
        $action_data_html .= "<table width='100%' cellpadding='2' style='font-size: 11px;'>";
        $action_data_html .= "<tr><TD>Reference</TD><TD>" . $nhpdata["reference"] . "</TD><TR>";
        $action_data_html .= "<TR><TD>Business Unit</TD><TD>" . $bu["buName"] . "</TD>";
        $action_data_html .= "<TD>Area</TD><TD>" . $loc['name']. "</TD></TR>";
        $action_data_html .= "<TR><TD>Owner</TD><TD>" . $owner . "</TD>";
        $action_data_html .= "<TD>Date<BR>Time</TD><TD>" . format_date($nhpdata["date"]) . "<BR>" . $nhpdata["time"] . "</TD></TR>";
        $action_data_html .= "<tr><TD>Problem</TD><TD>" . $nhpdata["problemDescription"] . "</TD></TR>";
        $action_data_html .= "</TABLE></DIV>";
        break;
}


$action_info_html = "<table width='100%' cellpadding='2' style='font-size: 11px;'>";
$action_info_html .= "<tr><TD colspan=10><HR></TD</TR>";
$action_info_html .= "<tr>";

$action_info_html .= "<td>Action Description</td>";

$action_info_html .= "<td>Assigned To</td>";
$action_info_html .= "<td>Action Log</td>";
$action_info_html .= "<td>Reject/Reassign</td>";
$action_info_html .= "<td>Done Description</td>";

$action_info_html .= "<td>Vfe</td>";
$action_info_html .= "<td>Vfe Description</td>";
$action_info_html .= "<td>Manager</td>";
$action_info_html .= "<td>Manager Description</td>";


$action_info_html .= "<td>Date Altered</td>";
$action_info_html .= "</tr>";

$action_info_html .= "<tr>";
                  $participantObj->setItemInfo(array('id' => $currentData['who']));
            $partcipantData = $participantObj->displayItemById();
            $who = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
						                  $participantObj->setItemInfo(array('id' => $currentData['addapprover']));
            $partcipantData = $participantObj->displayItemById();
            $approver = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
			if (trim($approver) == "")
				$approver = "See Verifier";
			                  $participantObj->setItemInfo(array('id' => $currentData['whoAU']));
            $partcipantData = $participantObj->displayItemById();
            $whoAU = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
$action_info_html .= "<td>" . $currentData['actionDescription'] . "</td>";
$action_info_html .= "<td>" . $who . "</td>";
$action_info_html .= "<td>" . $currentData['last_action'] . "</td>";
		
		$action_info_html .= "<td>" . $currentData['rejectreason'] . "</td>";

$action_info_html .= "<td>" . $currentData['doneDescription'] . "</td>";
$action_info_html .= "<td>" . $approver . "</td>";
$action_info_html .= "<td>" . $currentData['approve2comment'] . "</td>";
$action_info_html .= "<td>" . $whoAU . "</td>";
$action_info_html .= "<td>" . $currentData['approvecomment'] . "</td>";




$action_info_html .= "<td>" . format_datetime($currentData['timechanged']) . "</td>";
$action_info_html .= "</tr>";
if ($actData) {
    foreach ($actData as $ac) {

        $action_info_html .= "<tr>";
                  $participantObj->setItemInfo(array('id' => $ac['who']));
            $partcipantData = $participantObj->displayItemById();
            $who = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
			                  $participantObj->setItemInfo(array('id' => $ac['addapprover']));
            $partcipantData = $participantObj->displayItemById();
            $approver = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
			if (trim($approver) == "")
				$approver = "See Verifier";
			 $participantObj->setItemInfo(array('id' => $ac['whoAU']));
            $partcipantData = $participantObj->displayItemById();
            $whoAU = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
			
        $action_info_html .= "<td>" . $ac['actionDescription'] . "</td>";
        $action_info_html .= "<td>" . $who . "</td>";
        $action_info_html .= "<td>" . $ac['actiontaken'] . "</td>";
       
		$action_info_html .= "<td>" . $ac['rejectreason'] . "</td>";

        $action_info_html .= "<td>" . $ac['doneDescription'] . "</td>";
        $action_info_html .= "<td>" . $approver  . "</td>";
        $action_info_html .= "<td>" . $ac['approve2comment'] . "</td>";
        $action_info_html .= "<td>" . $whoAU . "</td>";
        $action_info_html .= "<td>" . $ac['approvecomment'] . "</td>";
		

        $action_info_html .= "<td>" . format_datetime($ac['timestamp']) . "</td>";
        $action_info_html .= "</tr>";
    }
}
$action_info_html .= "</table>";
echo $action_data_html . $action_info_html;
?>