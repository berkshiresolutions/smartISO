<?php
 /**
  $Id: ajax_authorize_document.php,v 3.44 Thursday, December 02, 2010 4:28:27 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionEmail.php';

$action_id 	= (int) $_GET['action_id'];
$date 	=       strip_tags($_GET['done_date']);
$who_id 	= (int) $_GET['who'];
$comment 	=  $_GET['comment'];
$module 	=  $_GET['module_ele'];
$atObj 		= new ActionTracker();
$atObj->approveAlert($action_id,$date,$comment);


echo 1;