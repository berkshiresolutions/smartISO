<?php
/**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2011 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <gurnam_84@hotmail.com>
 * @package Smartiso
 * @subpackage Equipment
 * @since  Friday, January 14, 2011 5:44:40 PM>
 */
$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];


/*
header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=msr_reviews.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

$fn = fopen('msr_reviews.xls', 'w');
//$objExport = new ExportData('nhpactionexport','csv');
//$objExport->downloadFile();

$bcp = new MsrReviewActionExport();
$data = $bcp->getListingforExport();
?>
<table cellspacing='0' cellpadding='0' width='100%' border='1'>

    <tr style='border: 1px solid;background: #360036;color: #fff;font-weight:bold;font-family:arial,sans-serif;'>

        <td >Business Unit</td>
        <td>Question</td>
        <td>Recommodation</td>
        <td >Action</td>
        <td >Due Date</td>
        <td > Assigned To</td>
        <td >Done Date</td>
    </tr>
<?php
foreach ($data as $v) {
    ?>
        <tr style='border: 1px solid;'>

            <td ><?php echo $v['bu']; ?></td>
            <td><?php echo $v['refrence']; ?></td>
            <td ><?php echo $v['action']; ?></td>
            <td ><?php echo $v['due']; ?></td>
            <td ><?php echo $v['assigned']; ?></td>
            <td ><?php echo $v['done']; ?></td>
        </tr>
    <?php
}
?>
</table>
    <?php
    fclose($fn);

*/



require_once dirname(__FILE__) . '/../php_excel/Classes/PHPExcel.php';
// Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
// Set document properties
    $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
    
    
$bcp = new MsrReviewActionExport();
$data = $bcp->getListingforExport();
 
$headerStyle = array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '360036'),
            'border' => false,
        ),
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF'),
        )
    );
    $borderStyle = array('borders' =>
        array('outline' =>
            array('style' => PHPExcel_Style_Border::BORDER_THICK,
                'color' => array('argb' => '360036'),),),);

    $rowCount = 1;
    $customTitle = array('Nature of Injury ');

    
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, 'Business Unit')
            ->SetCellValue('B' . $rowCount, 'Refrence')            
            ->SetCellValue('C' . $rowCount, 'Action')
            ->SetCellValue('D' . $rowCount, 'Due Date')
            ->SetCellValue('E' . $rowCount, 'Assigned To')
            ->SetCellValue('F' . $rowCount, 'Done Date');

    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($headerStyle);
    $borderColumn = (intval($column) - 1 );
    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($borderStyle);

    $i = 2;
    if ($data) {
        foreach ($data as $value) {
            $objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $value['bu'])
                    ->setCellValue('B' . $i, $value['refrence'])
                    ->setCellValue('C' . $i, $value['action'])
                    ->setCellValue('D' . $i, $value['due'])
                    ->setCellValue('E' . $i, $value['assigned'])
                    ->setCellValue('F' . $i, $value['done']);
              $i++;             
              
        }
    }
   


    $objPHPExcel->getActiveSheet()->setTitle('Simple');
    $objPHPExcel->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="msr_reviews.xls"');
    header('Cache-Control: max-age=0');
    header('Cache-Control: max-age=1');

    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); 
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); 
    header('Cache-Control: cache, must-revalidate');
    header('Pragma: public'); 
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;



//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
    ?>

