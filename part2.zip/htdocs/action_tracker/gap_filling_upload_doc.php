<?php
 /**
  $Id: gap_filling_upload_doc.php,v 3.34 Monday, September 20, 2010 10:12:40 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Friday, September 17, 2010 6:33:29 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

// load jquery validation script file
$_PAGE_VALIDATION_SCRIPT = 'action_tracker/gap_filling_upload_doc.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$file_reference 	= $_GET['doc_ref'];
$file_name 			= $_GET['doc_name'];
$doc_classification = array('Top Secret','Secret','Confidential','Restricted','Unclassified');
$business_unit 		= array('All Departments','Engineering','administrative','Finance');

//dump_array($_POST);
$smarty->assign('file_reference', $file_reference);
$smarty->assign('file_name', $file_name);
$smarty->assign('doc_classification', $doc_classification);
$smarty->assign('business_unit', $business_unit);
$smarty->display('action_tracker/gap_filling_upload_doc.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>