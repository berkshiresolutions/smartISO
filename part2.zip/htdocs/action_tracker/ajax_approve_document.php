<?php
 /**
  $Id: ajax_authorize_document.php,v 3.44 Thursday, December 02, 2010 4:28:27 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';
$document_id 	= (int) $_GET['document_id'];

$reply 	=  $_GET['reply'];

    $docObj 		= new Documents();
    $emailObj = new infoEmailHelper();
    $document_info=$docObj->getDocData($document_id);
        $contribList=$docObj->getDropContributors($document_id);

        $participantObj = SetupGeneric::useModule('Participant');
        
       $participantObj->setItemInfo(array('id' => getLoggedInUserId()));
       $partcipantData = $participantObj->displayItemById(); 
       $user_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        
       foreach ($contribList as $row){
       $participantObj->setItemInfo(array('id' => $row["authParticipantID"]));
       $partcipantData = $participantObj->displayItemById(); 
       $contributor_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];
       $message = "Contributor ". $contributor_name." has been dropped by ".$user_name ;
       $docObj->saveDocumentLog($document_id, $message, $reply);
       
       $who = array(
				'displayname' => ucwords($contributor_name),
				'email' => $partcipantData['emailAddress']
		);
  
       $subject = "smart-ISO Contributor Email: Your contribution is no longer required.";
       if (_CANDW ==1)
$alertStr="change";      
       else
$alertStr="alert";
$mergeData = array(
'twoColData'=>array(
'actionid'=>array('left'=>'<strong>File Reference:</strong>','right'=>$document_info['fileReference']),
			'assignedto'=>array('left'=>'<strong>Document Name:</strong>','right'=>$document_info['title']),
			'authorizing1'=>array('left'=>'<strong>Document Description:</strong>','right'=>$document_info['description'])

                    ),
'singleColData'=>array(
   'summary'=>'<p><BR>For the following reasons it was decided to publish the document before your contribution was made.<BR><BR>'.$reply.'<BR><BR>'
    . 'This has closed your action down BUT you can still review the document and if you have any points you wish to make please use the document '.$alertStr.' process.<BR><BR></p>')
					);

                $emailObj->appendInfo($mergeData);

				
                $emailObj->sendEmail($subject,$who,array(),array(),'me_completed','','grey');
                
       
       
       }
$docObj->updateDropContributors($document_id,$reply);

$docObj->authorizeDocument1($document_id,date("Y-m-d"),getLoggedInUserId());
$action = 'Uploaded';
$docObj->documentRecordHistory($document_id,$action);
$action = 'Authorized';
$docObj->documentRecordHistory($document_id,$action);
echo 1;