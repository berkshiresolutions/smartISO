<?php

/**
  $Id: assign_contributors.php,v 4.37 Thursday, January 27, 2011 6:02:23 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 * PHP version 5
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Documents
 * @since  Thursday, November 11, 2010 1:22:46 PM>
 */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/assign_contributors.js';


require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/infoEmail.php';
$docObj = new Documents();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // var_dump($_POST);exit();
    //echo $doc_id			= $_GET['doc_id'];

    $document['doc_id'] = $_POST['doc_id'];
    $document['alert_id'] = $_POST['alert_id'];
    if ($document['doc_id'] == '') {
        $document['doc_id'] = $_GET['doc_id'];
    }
$document['olddoc_id'] = $_POST['olddoc_id'];
    $docObj = new Documents();

    $emailObj = new infoEmailHelper();
    $docObj->setDocumentInfo($document);
    $document_info = $docObj->getDocumentInformation($document['doc_id']);
    $document_contributors = $docObj->getDocumentContributors($document['doc_id']);
    $alert_details = $docObj->getAlertDetails();

    if ($alert_details[0]["documentID"] > 0) {
        $objFile = new Upload();
        $objFile->setFileInfo('contributors', array('id' => $alert_details[0]['documentID']));
        $file_detail = $objFile->getFileDetails();

        $alertfile = "<a href='https://" . $_SERVER['HTTP_HOST'] . "/download.php?id=" . $alert_details[0]['documentID'] . "'>" . $file_detail['usrFilename'] . "</a>";
    } else {
        $alertfile = '-';
    }
        $oldfile = "<a href='https://" . $_SERVER['HTTP_HOST'] . "/download.php?id=" . $document['olddoc_id'] . "'>" . $document_info['title'] . "</a>";
   
   
    $i=0;
foreach($_POST['due_date'] as $row)
{
    $document['document_comment'] = $_POST['document_comment'][$i];
    $assign_contributors = $_POST['assign_contributors'][$i];
    $due_date = $_POST['due_date'][$i];
  

    $docContObj = new DocumentContributor();


    $alert_id=$docContObj->assignContributor($document['doc_id'], array('contributors' => $assign_contributors, 'due_date' => $due_date,'alert' => 1 ,'alertID'=>$document['alert_id'], 'comment' => $document['document_comment']));

if (_CANDW ==1)
$alert_text="Change Comment";
        else
            $alert_text="Alert Comment";
        
        $particpant_data_user = $docObj->displayItemMaininfoById($assign_contributors);
//dump_array($particpant_data_user['emailAddress']);

        $who = array(
            'displayname' => ucwords($particpant_data_user['forename'] . ' ' . $particpant_data_user['surname']),
            'email' => $particpant_data_user['emailAddress']
        );
        $subject = "smart-ISO Contributor Email: Document available for contribution.";

        $mergeData = array(
            'twoColData' => array(
                'actionid' => array('left' => '<strong>File Reference:</strong>', 'right' => $document_info['fileReference']),
                'assignedto' => array('left' => '<strong>Document Name:</strong>', 'right' => $document_info['title']),
                'authorizing1' => array('left' => '<strong>Document Description:</strong>', 'right' => $document_info['description']),
                'duedate' => array('left' => '<strong>Due Date:</strong>', 'right' => $_POST['due_date'][$i]),
				'files' => array('left' => '<strong>View Old Document:<br></strong><br>'. $oldfile , 'right' => '<strong>View New Document :<br></strong><br>'. $alertfile)
            ),
            'singleColData' => array(
                'summary' => '<BR><p><strong>Comment</strong><br>' . $_POST['document_comment'][$i] . '</p>',
                'summary1' => '<p><strong>'.$alert_text.'</strong><br>' . $alert_details["alertComment"] . '</p>',
                'url' => '<P>Please <a href= "https://' . $_SERVER['HTTP_HOST'] . '/action_tracker/contributor_listing.php?id='.$alert_id.' ">CLICK</a> Here to action the contribution</p>')
      
		);
 // http://alpha2/action_tracker/contribute1.php?contid=492&doc_id=163
        $emailObj->appendInfo($mergeData);

        $emailObj->sendEmail($subject, $who, array(), array(), 'me_completed', '', 'grey');


	$message =$who["displayname"]." has been sent the document for contribution." ;
	$docObj->saveDocumentLog($document['doc_id'],$message,$_POST['document_comment'][$i]);
      $i++;  
}


       $url = basename($_SERVER['PHP_SELF']) . "?doc_id=" . $document['doc_id'] . "&alert_id=".$_POST['alert_id']."&e=18";




    redirection($url);
}

$js = (int) $_GET['js'];
$e = (int) $_GET['e'];
$doc_id = (int) $_GET['doc_id'];
$alert_id = (int) $_GET['alert_id'];
if ($js) {

    $smarty->assign('js', $js);
    $smarty->assign('e', $e);
} else {

    $smarty->assign('doc_id', $doc_id);
    $smarty->assign('alert_id', $alert_id);
    $smarty->assign('post_script_name', 'raise_alert.php');
}

$document_contributors = array();


$docclassObj = SetupGeneric::useModule('DocClassification');
$document_classification = $docclassObj->displayItems();
$optObj = new Option();
$miscObj = new Misc();
$uploadObj = new Upload();
$version_type = $optObj->getOption('_SU_DOCCONTROL_VERSION_TYPE');
$document_types = $miscObj->getDocumentTypes();
$optObj = null;
$miscObj = null;
$participantObj = SetupGeneric::useModule('Participant');

$document_info = $docObj->getDocumentInformation($doc_id);

$document['alert_id'] = $_GET['alert_id'];

$docObj->setDocumentInfo($document);
$alert_details = $docObj->getAlertDetails();

$document_contributors = $docObj->getDocumentContributors($doc_id);
$document_contributors_count = count($document_contributors);
$document_contributors_replied = 0;

if ($document_contributors_count) {

    $k = 0;

    //dump_array($document_contributors);

    foreach ($document_contributors as $contributor_ele) {


        $participant_id = $contributor_ele['authParticipantID'];
        $participantObj->setItemInfo(array('id' => $participant_id));
        $partcipantData = $participantObj->displayItemById();

        $participant_name = $partcipantData['forename'] . ' ' . $partcipantData['surname'];

        $document_contributors_simple[$k]['contributor_name'] = $participant_name == ' ' ? '-' : $participant_name;

        switch ($contributor_ele['passed']) {
            case 0: $document_contributors_simple[$k]['response'] = 'Waiting';
                break;
            case 1: $document_contributors_simple[$k]['response'] = 'Approved';
                break;
            case 2: $document_contributors_simple[$k]['response'] = 'Not Approved';
                break;
        }

        $document_contributors_simple[$k]['response'] = $contributor_ele['passed'];

        if ($contributor_ele['passed']) {
            $document_contributors_replied++;
        }

        $document_contributors_simple[$k]['comments'] = ucfirst($contributor_ele['comments']);
        $document_contributors_simple[$k]['reply'] = ucfirst($contributor_ele['reply']);

        if ($contributor_ele['documentID'] != 0) {
            $objFile = new Upload();
            $objFile->setFileInfo('contributors', array('id' => $contributor_ele['documentID']));
            $file_detail = $objFile->getFileDetails();

            $document_contributors_simple[$k]['file_uploaded'] = "<a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=" . $file_detail['sysFilename'] . "&un=" . $file_detail['usrFilename'] . "&module=contributors','mywindow')\">" . $file_detail['usrFilename'] . "</a>";
        } else {
            $document_contributors_simple[$k]['file_uploaded'] = '-';
        }

        $document_contributors_simple[$k]['contrib_due_date'] = format_date($contributor_ele['contribDueDate']);

        $k++;
    }
}

$document_info_simple['code'] = $document_info['fileReference'];
$document_info_simple['document'] = $document_info['documentID'];
$document_info_simple['name'] = ucfirst($document_info['title']);
$document_info_simple['description'] = ucfirst($document_info['description']);
$document_info_simple['type'] = $document_types[$document_info['documentType']];
$document_info_simple['initiated'] = format_date($document_info['dateInitiated']);
$document_info_simple['initiated_by'] = $document_info['initiatedByParticipant'];
$document_info_simple['version_type'] = ucfirst($version_type);
$document_info_simple['version'] = $document_info['versionNew'];
$document_info_simple['approved_date'] = $document_info[''];
$document_info_simple['approved_by'] = $document_info[''];
$document_info_simple['action_summary'] = ucfirst($document_info['actionSummary']);
$document_info_simple['alertcomment'] = $alert_details[0]['alertComment'];
$uploadObj->setFileInfo('documents', array('id' => $alert_details[0]['documentID']));
$file_details = $uploadObj->getFileDetails();


if ($document_classification) {

    foreach ($document_classification as $document_class_ele => $document_class_val) {

        if (substr($document_class_ele, 0, 1) == $document_info['classification']) {
            $document_info_simple['classification'] = $document_class_val;
            break;
        }
    }
}

$smarty->assign('row_data', $document_info_simple);
$smarty->assign('alert_file', $file_details);
$smarty->assign('document_contributors', $document_contributors_simple);
$smarty->assign('document_contributors_count', $document_contributors_count);
$smarty->assign('document_contributors_replied', $document_contributors_replied);

$smarty->assign('SCRIPT_PATH', _SCRIPT_PATH);

if ($document_info['status'] == 'A') {
    $smarty->assign('document_approved', 1);
} else {
    $smarty->assign('document_approved', 0);
}

$smarty->display('action_tracker/assign_contribute_alert.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
