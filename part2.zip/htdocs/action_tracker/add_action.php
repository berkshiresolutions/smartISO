<?php
 /**
  $Id: replace_document.php,v 3.74 Thursday, January 20, 2011 4:14:14 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Documents
  * @since  Thursday, November 11, 2010 1:22:46 PM>
  */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = 'action_tracker/add_action.js';
$_PAGE_VALIDATION_SCRIPT2 = 'common_script.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/classes/newCore/modules/email/infoEmail.php';

$atObj 		= new ActionTracker();

$actObj 		= new Action();

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

$date   	=$_POST['when'];
$who	=  $_POST['who_hidden'];
$whoAU 	=           $_POST['manager_hidden'];
$whoAU2 	=           $_POST['whoAU2_hidden'];
$comment 	=  $_POST['reason_replace'];
$action =           $_POST['action'];
$record_id  =  $_POST['record_id'];
$url  =  $_POST['url'];

$actionData = array('description' => $action[0],
            'who' => $who[0],
            'whoAU' => $whoAU[0],
            'who2AU' => $whoAU2[0],
            'module_name' => 'NHP',
            'record' => $record_id,
            'status' => 0,
            'buname' => 0,
			'url' => $url,
            'element' =>0,
            'currentwho' => $who[0],
            'element' => "nhp",
            'due_date' => $date[0]);


              
             $actObj->setActionDetails(0, $actionData);
            $action_id = $actObj->addAction2015();




	$smarty->assign('js',1);
	$smarty->assign('e',2);
	
}

$id=$_GET["alert_id"];
$url=$_GET["url"];
$smarty->assign('id', $id);
$smarty->assign('url', $url);
$smarty->display('action_tracker/add_action.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';