<?php
 /**
  $Id: equipment_csv.php,v 3.02 Tuesday, January 18, 2011 6:34:04 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2011 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <gurnam_84@hotmail.com>
  * @package Smartiso
  * @subpackage Equipment
  * @since  Friday, January 14, 2011 5:44:40 PM>
  */

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$tab_type = $_GET['showtype'];


/*

header('Content-type: application/vnd.ms-excel');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=ncr.xls');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

$fn = fopen('ncr.xls','w');
//$objExport = new ExportData('nhpactionexport','csv');
//$objExport->downloadFile();

$bcp		=		new NhpActionExport();
$data = $bcp->getListingforExport();


?>
<table cellspacing='0' cellpadding='0' width='100%' border='1' >
	
	<tr style='border: 1px solid;background: #360036;color: #fff;font-weight:bold;font-family:arial,sans-serif;'>
	
	<td >Business Unit</td>
	<td>Reference #</td>
	<td >Action</td>
	<td >Due Date</td>
	<td > Assigned To</td>
	<td >Done Date</td>
	</tr>
	<?php 
	foreach($data as $v){
	?>
	<tr style='border: 1px solid;'>
	
	<td ><?php echo $v['bu']; ?></td>
	<td><?php echo $v['refrence']; ?></td>
	<td ><?php echo $v['action']; ?></td>
	<td ><?php echo $v['due']; ?></td>
	<td ><?php echo $v['assigned']; ?></td>
	<td ><?php echo $v['done']; ?></td>
	</tr>
	<?php 
	}
	?>
	</table>
	<?php

fclose($fn);
*/



require_once dirname(__FILE__) . '/../php_excel/Classes/PHPExcel.php';
// Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
// Set document properties
    $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
            ->setLastModifiedBy("Maarten Balliauw")
            ->setTitle("Office 2007 XLSX Test Document")
            ->setSubject("Office 2007 XLSX Test Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Test result file");
$bcp=new NhpActionExport();
$data = $bcp->getListingforExport();
 
$headerStyle = array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '360036'),
            'border' => false,
        ),
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF'),
        )
    );
 $styleArray = array(
        'font' => array(
            'bold' => true,
            'color' => array('rgb' => 'FFFFFF')
    ));
    $borderStyle = array('borders' =>
        array('outline' =>
            array('style' => PHPExcel_Style_Border::BORDER_THICK,
                'color' => array('argb' => '360036'),),),);

    $rowCount = 1;
    $customTitle = array('Nature of Injury ');
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, 'Business Unit')
            ->SetCellValue('B' . $rowCount, 'Reference')
             ->SetCellValue('C' . $rowCount, 'Problem')
             ->SetCellValue('D' . $rowCount, 'Owner')
             ->SetCellValue('E' . $rowCount, 'Log Date')
            ->SetCellValue('F' . $rowCount, 'Action')
            ->SetCellValue('G' . $rowCount, 'Due Date')
            ->SetCellValue('H' . $rowCount, 'Assigned To')
            ->SetCellValue('I' . $rowCount, 'Done Date');

    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($headerStyle);
    $borderColumn = (intval($column) - 1 );
    $objPHPExcel->getActiveSheet()->getStyle('A1:' . 'V1')->applyFromArray($borderStyle);

    $i = 2;
    if ($data) {
        foreach ($data as $value) {
            $objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $value['bu'])
                    ->setCellValue('B' . $i, $value['refrence'])
                     ->setCellValue('C' . $i, $value['problem'])
                     ->setCellValue('D' . $i, $value['owner'])
                     ->setCellValue('E' . $i, $value['date'])
                    ->setCellValue('F' . $i, $value['action'])
                    ->setCellValue('G' . $i, $value['due'])
                    ->setCellValue('H' . $i, $value['assigned'])
                    ->setCellValue('I' . $i, $value['done']);
              $i++;
        }
    }
      


 //   $objPHPExcel->getActiveSheet()->getColumnDimension('A:I')->setAutoSize(false);
$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth("12");
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth("15");



$objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($styleArray);

$objPHPExcel->getActiveSheet()->setAutoFilter('A1:I1');

// Rename worksheet
    $objPHPExcel->getActiveSheet()->setTitle('Simple');
// Set active sheet index to the first sheet, so Excel opens this as the first sheet
    $objPHPExcel->setActiveSheetIndex(0);
// Redirect output to a client�s web browser (Excel5)
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="ncr.xls"');
    header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
    header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
    header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
    header('Pragma: public'); // HTTP/1.0

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    exit;

//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';





//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>