<?php
 /**
  $Id: records.php,v 3.49 Tuesday, December 14, 2010 12:31:36 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, September 07, 2010 12:01:16 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once _MYINCLUDES."record_listing_page.inc.php";

$contractObj 		= new Contract();
$optObj 			= new Option();

$participantObj	 	= SetupGeneric::useModule('Participant');
$archive_session 	= (int) Session::getSessionField('ARCHIVE_RECORDS');
$archive_data 		= array('archive'=>$archive_session);

$records = $contractObj->getContracts($_GET['shortTermOrTender'] , $_GET['contractorId']);

$USER_ID = getLoggedInUserId();
//echo $USER_ADMIN_AUTHORISED_USER ;
?>

<input type='hidden' name='admin' id='admin' value='<?php echo $USER_ADMIN_AUTHORISED_USER?>'>
<input type='hidden' name='selected_radio' id='selected_radio' value='0'>
<input type='hidden' name='selected_user' id='selected_user' value='0'>
<input type='hidden' name='current_user' id='current_user' value='<?php echo $USER_ID?>'>
<table cellpadding="2" cellspacing="4" border="0" class="display" id="module_records">
	<thead>
		<tr style='color:#fff'>
			<th width='3%'>&nbsp;</th>
			<th width='10%'>Contract Ref</th>
			<th width='20%'>Goods/Service Contract Provision</th> 
			<th width='15%'>Business Unit</th>
			<th width='*'>Contract Manager</th>
			<th width='15%'>ST/T</th>
			<th width='5%'>End Date</th>
			<th width='15%'>Contractor</th>
		</tr>
	</thead>
	<tbody>
		<?php
		if ( count($records) ) {
			foreach ( $records as $value ) {
				$participant_id = $value['contractManagerID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();
				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
				$businessUnit = $contractObj->getBusinessUnit($value['buID']);
				$contractorName = '';
				$useApprovedContractor = $value['useApprovedContractor'];
				if ($useApprovedContractor) {
					$dbHand = DB::connect(_DB_TYPE);
					$sql = sprintf("SELECT * FROM %s.contractor WHERE ID = %d",_DB_OBJ_FULL,$useApprovedContractor);
					$pStatement = $dbHand->prepare($sql);
					$pStatement->execute();
					$resultSet = $pStatement->fetchAll(PDO::FETCH_ASSOC);
					$contractorName = $resultSet[0]['companyName'];
				}
				?>

				<tr  class='record_row' rel='<?php echo $value['ID'] ?>'>
					<td width='3%'><input type='radio' name='record_radio' id='record_radio<?php echo $value['ID']?>' rel='<?php echo $value['reference']?>' user='<?php echo $participant_id?>' class='choose_radio' value='<?php echo $value['ID']?>'></td>
					<td><?php echo $value['reference']?></td>
					<td><?php echo $value['contractName']?></td>
					<td><?php echo $businessUnit?></td>
					<td><?php echo $participant_name?></td>
					<td><?php echo ($value['shortTermOrTender'] ? 'Tender' : 'Quote'); ?></td>
					<td align='center'><?php echo format_date($value['endDate']) ?></td>
					<td><?php echo $contractorName ?></td>
				</tr>
			<?php }
		}
		?>
	</tbody>
	<tfoot>
		<tr>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
		</tr>
	</tfoot>
</table>