<?php
 /**
  $Id: PHP-1.php,v 3.01 Saturday, October 09, 2010 1:05:09 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is used to delete the records from listing of Contractors.
  *
  * Long description
  * Long description
  *
  * @author  Anil
  * @package Smartiso
  * @subpackage Contractors
  * @since  Saturday, October 09, 2010 1:05:09 PM>
  */
 // load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->deleteContractor();

?>