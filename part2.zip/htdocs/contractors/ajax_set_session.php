<?php
 /**
  $Id: ajax_set_session.php,v 3.11 Saturday, October 30, 2010 10:26:04 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage NHP
  * @since  Friday, September 17, 2010 5:08:56 PM>
  */

// hide page header
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$record_id = (int) $_GET['id'];

// to start a session
//Session::StartSession();
Session::saveSessionField('record_id',$record_id);

if ( $record_id >0) {
	Session::saveSessionField('action','edit');
} else {
	Session::saveSessionField('action','add');
}
?>