<?php
 /**
  $Id: reportR3.php,v 3.06 Wednesday, January 05, 2011 3:10:42 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage DSE
  * @since  Thursday, November 25, 2010 3:26:06 PM>
  */

$LAST_BREAD_CRUM = "Report R2";

$_PAGE_VALIDATION_SCRIPT = 'contractor/report.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$record_id	= (int) $_GET['id'];
$isShortTermOrTender =  (int) $_GET['isT'];
 $tender =  (int) $_GET['tender'];


$repObj = new Report('html');
/*if($isShortTermOrTender == 0)
	$repObj->setFilters(array('id'=>$record_id,'type'=>'R2S','heading'=>true));
else
	$repObj->setFilters(array('id'=>$record_id,'type'=>'R2T','heading'=>true));*/
$repObj->setFilters(array('id'=>$record_id,'type'=>'R2','tender'=>$tender,'heading'=>true));	
$repObj->generateReport('CONTRACTORR2');
$repObj->displayReport();

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>