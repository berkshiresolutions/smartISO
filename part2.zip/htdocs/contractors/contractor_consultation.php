<?php
 /**
  $Id: contractor_consultation.php,v 3.30 Tuesday, November 02, 2010 12:23:53 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the consultation section under contractor index.
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Friday, October 08, 2010 1:13:00 PM>
  */

$class_consultation = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Consultation"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,6,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	$data_array['contractor_id'] 						= $_POST['cid'];
	$data_array['consult_health_safety'] 					= $_POST['radio_health_safety_issues'];
	$data_array['consult_environmental'] 					= $_POST['radio_environmental_issues'];
	$data_array['consult_quality'] 						= $_POST['radio_quality_issues'];
	$data_array['consult_security'] 					= $_POST['radio_security_issues'];
	$data_array['formal_arrangements1'] 					= $_POST['health_safety_issues'];
	$data_array['formal_arrangements2'] 					= $_POST['environmental_issues'];
	$data_array['formal_arrangements3'] 					= $_POST['quality_issues'];
	$data_array['training_person1_1'] 					= $_POST['hseq_training_1'];
	$data_array['training_person1_2'] 					= $_POST['hseq_training_2'];
	$data_array['training_person1_3'] 					= $_POST['hseq_training_3'];
	$data_array['training_person1_4'] 					= $_POST['hseq_training_4'];
	$data_array['training_person2_1'] 					= $_POST['hseq_training_5'];
	$data_array['training_person2_2'] 					= $_POST['hseq_training_6'];
	$data_array['training_person2_3'] 					= $_POST['hseq_training_7'];
	$data_array['training_person2_4'] 					= $_POST['hseq_training_8'];
	$data_array['qualifications_person1'] 					= $_POST['hseq_qualifications_1'];
	$data_array['qualifications_person2'] 					= $_POST['hseq_qualifications_2'];
	$data_array['qualifications_person3'] 					= $_POST['hseq_qualifications_3'];
	$data_array['qualifications_person4'] 					= $_POST['hseq_qualifications_4'];
	$data_array['handbooks'] 						= $_POST['radio_health_safety_handbooks'];
	$data_array['handbooks_comment1'] 					= $_POST['health_safety_handbooks_1'];
	$data_array['handbooks_comment2'] 					= $_POST['health_safety_handbooks_2'];
	$data_array['handbooks_comment3'] 					= $_POST['health_safety_handbooks_3'];


	$section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,6,$data_array);
		$contractorObj->editContractor();

	} else {
		//do insert
		$contractorObj->setContractorInfo(0,6,$data_array);
		$contractorObj->addContractor();
	}
            $tab=max(6, $contractorObj->getTab($record_id));
   $contractorObj->setTab($tab,$record_id)  ;
	redirection("contractor_training.php?cid=".$record_id);
}
/* Current contractor record id */
$smarty->assign('cid', $cid);

$data = $contractorObj->viewContractor();
$tab=$contractorObj->getTab($cid);
$smarty->assign('tab',$tab);
    if ( is_array($data) ) {

	$edit_data['section_record_id'] 					= $data['ID'];
	$edit_data['radio_health_safety_issues'] 				= $data['consultHealthSafety'];
	$edit_data['radio_environmental_issues'] 				= $data['consultEnvironmental'];
	$edit_data['radio_quality_issues'] 					= $data['consultQuality'];
	$edit_data['radio_security_issues'] 					= $data['consultSecurity'];
        $edit_data['health_safety_issues'] 					= smartisoStripslashes($data['formalArrangements_1']);
	$edit_data['environmental_issues'] 					= smartisoStripslashes($data['formalArrangements_2']);
	$edit_data['quality_issues'] 						= smartisoStripslashes($data['formalArrangements_3']);
	$edit_data['hseq_training_1'] 						= smartisoStripslashes($data['trainingPerson_1_1']);
	$edit_data['hseq_training_2'] 						= smartisoStripslashes($data['trainingPerson_1_2']);
	$edit_data['hseq_training_3'] 						= smartisoStripslashes($data['trainingPerson_1_3']);
	$edit_data['hseq_training_4'] 						= smartisoStripslashes($data['trainingPerson_1_4']);
	$edit_data['hseq_training_5'] 						= smartisoStripslashes($data['trainingPerson_2_1']);
	$edit_data['hseq_training_6'] 						= smartisoStripslashes($data['trainingPerson_2_2']);
	$edit_data['hseq_training_7'] 						= smartisoStripslashes($data['trainingPerson_2_3']);
	$edit_data['hseq_training_8'] 						= smartisoStripslashes($data['trainingPerson_2_4']);
	$edit_data['hseq_qualifications_1'] 					= smartisoStripslashes($data['qualificationsPerson_1']);
	$edit_data['hseq_qualifications_2'] 					= smartisoStripslashes($data['qualificationsPerson_2']);
	$edit_data['hseq_qualifications_3'] 					= smartisoStripslashes($data['qualificationsPerson_3']);
	$edit_data['hseq_qualifications_4'] 					= smartisoStripslashes($data['qualificationsPerson_4']);
	$edit_data['radio_health_safety_handbooks'] 				= $data['handbooks'];
	$edit_data['health_safety_handbooks_1'] 				= smartisoStripslashes($data['handbooksComment_1']);
	$edit_data['health_safety_handbooks_2'] 				= smartisoStripslashes($data['handbooksComment_2']);
	$edit_data['health_safety_handbooks_3'] 				= smartisoStripslashes($data['handbooksComment_3']);

	$smarty->assign('edit_data',$edit_data);
} else {
	$consultation_with_employees['health_safety_issues']    = "";
	$consultation_with_employees['environmental_issues']    = "";
	$consultation_with_employees['quality_issues']          = "";
	$hseq_training                                          = "";
	$hseq_qualifications                                    = "";
	$hseq_training_2                                        = "";
	$health_safety_handbooks                                = "";
	$radio_health_safety_issues                             = "";
	$radio_environmental_issues                             = "";
	$radio_quality_issues                                   = "";
	$radio_health_safety_handbooks                          = "";
}

$smarty->assign('cid', $cid);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

$smarty->display($CURRENT_MODULE.'/contractor_consultation.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>