<?php
 /**
  $Id: index.php,v 3.61 Thursday, February 03, 2011 2:41:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Wednesday, September 29, 2010 2:17:35 PM>
  */



// load jquery validation script file

//$_PAGE_VALIDATION_SCRIPT 	= 'smart_bcp/report.js';
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


header('Content-type: application/vnd.ms-word');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=Report_R1.doc');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

require _MYCLASSES."report/contractorModReport.class.php";

$data_array['id']		= $_GET['id'];
$data_array['type']		= 'R1';

//$filters = array('type'=>'main','id'=>$_GET['id']);
$modObj = new contractorModReport($data_array);
$modData = $modObj->getData();		
		





$eqObj		 = new Upload();
$optionObj	 = new Option();

$eqObj->setFileInfo('company_logo',"");
$file_details = $eqObj->getFileDetailsByModule();
$company_logo = $file_details['sysFilename'];

//$fn = fopen('Report_R1.doc','w');
?>



	<table cellspacing='2' cellpadding='2' width='100%' border='1'>
	
	
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
			            <td><img src=<?php echo  "https://".$_SERVER['HTTP_HOST']."/pub/".$company_logo ?> ></td>
            <td colspan='4' style='color:white'>Report R1</td>
		</tr>
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
            <td colspan='4' style='color:white'>Contract Details</td>
		</tr>
	
	<tr style='border: 1px solid;'>
	<td>Reference</td>
	<td ><?php echo  $modData['details']['reference']; ?></td>
	<td>Goods/Service Contract Provision</td>
	<td ><?php echo  $modData['details']['contractName']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Location</td>
	<td ><?php echo  $modData['details']['location']; ?></td>
	<td>Business Unit</td>
	<td ><?php echo  $modData['details']['business']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Type</td>
	<td ><?php echo  $modData['details']['type']; ?></td>
	<td>Contract Manager</td>
	<td ><?php echo  $modData['details']['cm']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Manager Approver</td>
	<td ><?php echo  $modData['details']['ma']; ?></td>
	<td>Director Approver</td>
	<td ><?php echo  $modData['details']['da']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Contract Start Date</td>
	<td ><?php echo  $modData['details']['startDate']; ?></td>
	<td>Contract End Date</td>
	<td ><?php echo  $modData['details']['endDate']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Review Date</td>
	<td ><?php echo  $modData['details']['reviewDueDate']; ?></td>
	<td>Total Value</td>
	<td ><?php echo  $modData['details']['totalValue']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Details</td>
	<td ><?php echo  $modData['details']['detail']; ?></td>
	<td>Remarks</td>
	<td ><?php echo  $modData['details']['remarks']; ?></td>
	</tr>
	
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
            <td colspan='4' style='color:white'>Supplier Details</td>
		</tr>
	
	<tr style='border: 1px solid;'>
	<td>Reference</td>
	<td ><?php echo  $modData['cdetails']['reference']; ?></td>
	<td>Company Name</td>
	<td ><?php echo  $modData['cdetails']['companyName']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Contact Person</td>
	<td ><?php echo  $modData['cdetails']['contactPerson']; ?></td>
	<td>Address</td>
	<td ><?php echo  $modData['cdetails']['address']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Email</td>
	<td ><?php echo  $modData['cdetails']['emailAddress']; ?></td>
	<td>Location</td>
	<td ><?php echo  $modData['cdetails']['location']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Date</td>
	<td ><?php echo  $modData['cdetails']['date']; ?></td>
	<td>Business Unit</td>
	<td ><?php echo  $modData['cdetails']['business']; ?></td>
	</tr>
	<tr style='border: 1px solid;'>
	<td>Telephone</td>
	<td ><?php echo  $modData['cdetails']['telephoneNumber']; ?></td>
	<td>Fax</td>
	<td ><?php echo  $modData['cdetails']['fax']; ?></td>
	</tr>
	
	</table>


<?php

//fclose($fn);





//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>