<?php
 /**
  $Id: contractor_training.php,v 3.12 Wednesday, October 27, 2010 11:46:04 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the training section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Friday, October 08, 2010 5:04:50 PM>
  */

$class_training = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Training"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,7,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	//dump_array($_POST);exit();

	$data_array['contractor_id'] 							= $_POST['cid'];
	$data_array['managers_supervisors1'] 					= $_POST['managers_supervisors_1'];
	$data_array['managers_supervisors2'] 					= $_POST['managers_supervisors_2'];
	$data_array['managers_supervisors3'] 					= $_POST['managers_supervisors_3'];
	$data_array['managers_supervisors4'] 					= $_POST['managers_supervisors_4'];
	$data_array['operatives1'] 								= $_POST['operatives_1'];
	$data_array['operatives2'] 								= $_POST['operatives_2'];
	$data_array['operatives3'] 								= $_POST['operatives_3'];
	$data_array['operatives4'] 								= $_POST['operatives_4'];
	$data_array['competent_relating1'] 						= $_POST['type_of_work_1'];
	$data_array['competent_relating2'] 						= $_POST['type_of_work_2'];
	$data_array['competent_relating3'] 						= $_POST['type_of_work_3'];
	$data_array['competent_relating4'] 						= $_POST['type_of_work_4'];
	$data_array['formal_reviews1'] 							= $_POST['review_1'];
	$data_array['formal_reviews2'] 							= $_POST['review_2'];
	$data_array['formal_reviews3'] 							= $_POST['review_3'];
	$data_array['formal_reviews4'] 							= $_POST['review_4'];
        $data_array['audits'] 							= $_POST['radio_fire_risk_assessment'];
	$section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,7,$data_array);
		$contractorObj->editContractor();
	} else {
		//do insert
		$contractorObj->setContractorInfo(0,7,$data_array);
		$contractorObj->addContractor();
	}
    $tab=max(7, $contractorObj->getTab($record_id));
   $contractorObj->setTab($tab,$record_id)  ;
	redirection("contractor_maintenance.php?cid=".$record_id);
}

/* Current contractor record id */
$smarty->assign('cid', $cid);

$data = $contractorObj->viewContractor();

    if ( is_array($data) ) {

	$edit_data['section_record_id'] 							= $data['ID'];
	$edit_data['managers_supervisors_1'] 						= smartisoStripslashes($data['managersSupervisors_1']);
	$edit_data['managers_supervisors_2'] 						= smartisoStripslashes($data['managersSupervisors_2']);
	$edit_data['managers_supervisors_3'] 						= smartisoStripslashes($data['managersSupervisors_3']);
	$edit_data['managers_supervisors_4'] 						= smartisoStripslashes($data['managersSupervisors_4']);
	$edit_data['operatives_1'] 									= smartisoStripslashes($data['operatives_1']);
	$edit_data['operatives_2'] 									= smartisoStripslashes($data['operatives_2']);
	$edit_data['operatives_3'] 									= smartisoStripslashes($data['operatives_3']);
	$edit_data['operatives_4'] 									= smartisoStripslashes($data['operatives_4']);
	$edit_data['type_of_work_1'] 								= smartisoStripslashes($data['competentRelating_1']);
	$edit_data['type_of_work_2'] 								= smartisoStripslashes($data['competentRelating_2']);
	$edit_data['type_of_work_3'] 								= smartisoStripslashes($data['competentRelating_3']);
	$edit_data['type_of_work_4'] 								= smartisoStripslashes($data['competentRelating_4']);
	$edit_data['review_1'] 										= smartisoStripslashes($data['formalReviews_1']);
	$edit_data['review_2'] 										= smartisoStripslashes($data['formalReviews_2']);
	$edit_data['review_3'] 										= smartisoStripslashes($data['formalReviews_3']);
	$edit_data['review_4'] 										= smartisoStripslashes($data['formalReviews_4']);
 $edit_data['radio_fire_risk_assessment'] 							= $data['audits'];
	//dump_array($edit_data);
	$smarty->assign('edit_data', $edit_data);

} else {

	$training_managers_supervisors      = "";
	$operatives                         = "";
	$competency                         = "";
	$monitoring_audit_policy_review     = "";
}
$tab=$contractorObj->getTab($cid);
$smarty->assign('tab',$tab);
$smarty->assign('cid', $cid);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);
//$smarty->debugging=true;
$smarty->display($CURRENT_MODULE.'/contractor_training.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>