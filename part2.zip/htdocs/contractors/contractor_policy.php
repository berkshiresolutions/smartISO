<?php
 /**
  $Id: contractor_policy.php,v 3.35 Saturday, December 04, 2010 3:38:33 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the policy section under contractor index.
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Thursday, October 07, 2010 5:12:20 PM>
  */
$class_policy = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Policy"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,4,"");
$action = Session::getSessionField('action');


if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	$data_array['contractor_id'] 			= $_POST['cid'];
	$data_array['trade_association'] 		= $_POST['radio_member_assoc'];
	$data_array['trade_association_name1'] 		= $_POST['name_member_assoc_1'];
	$data_array['trade_association_name2'] 		= $_POST['name_member_assoc_2'];
	$data_array['trade_association_address1'] 	= $_POST['address_member_assoc_1'];
	$data_array['trade_association_address2'] 	= $_POST['address_member_assoc_2'];
	$data_array['trade_association_ref1'] 		= $_POST['ref_member_assoc_1'];
	$data_array['trade_association_ref2'] 		= $_POST['ref_member_assoc_2'];
	$data_array['iso9001'] 				= $_POST['radio_iso_9001'];
	$data_array['iso9001_reason'] 			= $_POST['iso_9001'];
	$data_array['iso14001'] 			= $_POST['radio_iso_14001'];
	$data_array['iso14001_reason'] 			= $_POST['iso_14001'];
	$data_array['iso18001'] 			= $_POST['radio_iso_18001'];
	$data_array['iso18001_reason'] 			= $_POST['iso_18001'];
        $data_array['iso22301'] 			= $_POST['radio_iso_22301'];
	$data_array['iso22301_reason'] 			= $_POST['iso_22301'];
        $data_array['iso27001'] 			= $_POST['radio_iso_27001'];
	$data_array['iso27001_reason'] 			= $_POST['iso_27001'];
	$data_array['iso45001'] 			= $_POST['radio_iso_45001'];
	$data_array['iso45001_reason'] 			= $_POST['iso_45001'];
	$data_array['continuous_improvement'] 		= $_POST['radio_continuous_improvement'];
	$data_array['health_safety_policy'] 		= $_POST['radio_health_policy'];
	$data_array['environmental_policy'] 		= $_POST['radio_environmental_policy'];
	$data_array['quality_policy'] 				= $_POST['radio_quality_policy'];
        $data_array['isPolicy'] 				= $_POST['radio_ims'];
	$data_array['work_instructions'] 			= $_POST['radio_hseq_rules'];



	 $section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,4,$data_array);
		$contractorObj->editContractor();
	} else {
           		//do insert
		$contractorObj->setContractorInfo(0,4,$data_array);
		$contractorObj->addContractor();
	}
      
            $tab=max(4, $contractorObj->getTab($record_id));
   $contractorObj->setTab($tab,$record_id)  ;
	redirection("contractor_risk_assessment.php?cid=".$record_id);
}
/* Current contractor record id */
$smarty->assign('cid', $cid);

$data = $contractorObj->viewContractor();

    if ( is_array($data) ) {

	$edit_data['section_record_id'] 		= $data['ID'];
	$edit_data['radio_member_assoc'] 		= $data['tradeAssociation'];
	$edit_data['name_member_assoc_1'] 		= smartisoStripslashes($data['tradeAssociationName_1']);
	$edit_data['name_member_assoc_2']		= smartisoStripslashes($data['tradeAssociationName_2']);
	$edit_data['address_member_assoc_1'] 		= smartisoStripslashes($data['tradeAssociationAddress_1']);
	$edit_data['address_member_assoc_2'] 		= smartisoStripslashes($data['tradeAssociationAddress_2']);
	$edit_data['ref_member_assoc_1'] 		= smartisoStripslashes($data['tradeAssociationMemberRef_1']);
	$edit_data['ref_member_assoc_2']		= smartisoStripslashes($data['tradeAssociationMemberRef_2']);
	$edit_data['radio_iso_9001'] 			= $data['iso9001'];
	$edit_data['iso_9001'] 				= smartisoStripslashes($data['iso9001Reason']);
	$edit_data['radio_iso_14001'] 			= $data['iso14001'];
	$edit_data['iso_14001'] 			= smartisoStripslashes($data['iso14001Reason']);
	$edit_data['radio_iso_18001'] 			= $data['iso18001'];
	$edit_data['iso_18001']				= smartisoStripslashes($data['iso18001Reason']);
	$edit_data['radio_iso_27001'] 			= $data['iso27001'];
	$edit_data['iso_27001']				= smartisoStripslashes($data['iso27001Reason']);
	$edit_data['radio_iso_22301'] 			= $data['iso22301'];
	$edit_data['iso_22301']				= smartisoStripslashes($data['iso22301Reason']);
	$edit_data['radio_iso_45001'] 			= $data['iso45001'];
	$edit_data['iso_45001']				= smartisoStripslashes($data['iso45001Reason']);
	$edit_data['radio_continuous_improvement'] 	= $data['continuousImprovement'];
	$edit_data['radio_health_policy'] 		= $data['healthSafetyPolicy'];
	$edit_data['radio_environmental_policy'] 	= $data['environmentalPolicy'];
	$edit_data['radio_quality_policy'] 		= $data['qualityPolicy'];
	$edit_data['radio_hseq_rules'] 			= $data['workInstructions'];
$edit_data['radio_ims'] 		= $data['isPolicy'];
	$smarty->assign('edit_data', $edit_data);

} else {

	$member_trade_association['name']             = "";
	$member_trade_association['address']          = "";
	$member_trade_association['membership_ref']   = "";

	$iso_ohsas['9001']                            = "";
	$iso_ohsas['14001']                           = "";
	$iso_ohsas['18001']                           = "";

	$radio_member_assoc                           = "";
	$radio_iso_9001                               = "";
	$radio_iso_14001                              = "";
	$radio_iso_18001                              = "";
	$radio_continuous_improvement                 = "";
	$radio_health_policy                          = "";
	$radio_environmental_policy                   = "";
	$radio_quality_policy                         = "";
	$radio_hseq_rules                             = "";

}
$tab=$contractorObj->getTab($cid);
$smarty->assign('tab',$tab);
$smarty->assign('cid', $cid);
$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);
//$smarty->debugging=true;
$smarty->display($CURRENT_MODULE.'/contractor_policy.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>