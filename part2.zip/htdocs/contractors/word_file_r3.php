<?php
 /**
  $Id: index.php,v 3.61 Thursday, February 03, 2011 2:41:43 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Action tracker
  * @since  Wednesday, September 29, 2010 2:17:35 PM>
  */



// load jquery validation script file

//$_PAGE_VALIDATION_SCRIPT 	= 'smart_bcp/report.js';
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
/*
header('Content-type: application/vnd.ms-word');
header('Content-Description: File Transfer');
header('Content-Disposition: attachment; filename=Report_R3.doc');
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Transfer-Encoding: binary');

*/		
		
require _MYCLASSES."report/contractorModReport.class.php";



$filters = array('type'=>'R3');
$modObj = new contractorModReport($filters);
$modData = $modObj->getData();
	
	//dump_array($modData);
	//exit;

$eqObj		 = new Upload();
$optionObj	 = new Option();

$eqObj->setFileInfo('company_logo',"");
$file_details = $eqObj->getFileDetailsByModule();
$company_logo = $file_details['sysFilename'];

//$fn = fopen('Report_R3.doc','w');
?>
<style>
@page Portrait {size:595.45pt 841.7pt; margin:1.0in 1.25in 1.0in 1.25in;mso-header-margin:.5in;mso-footer-margin:.5in;mso-paper-source:0;}
div.Portrait {page:Portrait;}
@page Landscape {size:841.7pt 595.45pt;mso-page-orientation:landscape;margin:1.25in 1.0in 1.25in 1.0in;mso-header-margin:.5in;mso-footer-margin:.5in;mso-paper-source:0;}
div.Landscape {page:Landscape;}
extend_repor_height{
    font-size:11px;
}
</style>
<DIV  class=Landscape>


	<table cellspacing='0' cellpadding='0' width='100%' border='1'>
	
	
	
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
            <td><img src=<?php echo  "http://".$_SERVER['HTTP_HOST']."/pub/".$company_logo ?> ></td>
            <td colspan='4' style='color:white'>Report R3</td>
		</tr>
	
	<tr class='heading' style='border: 1px solid black;background-color:#660066'>
	<td style='color:white'>Reference</td>
	<td style='color:white'>Contract</td>
	<td style='color:white'>Detail</td>
	<td style='color:white'>Contract Manager</td>
        <td style='color:white'>Company Name</td>
        <td style='color:white'>Review Due Date</td>

	</tr>
	
	<?php 
	foreach($modData as $k=>$v){ 
            if (!isset($v['reference']))
                continue;
            ?>
	<tr style='border: 1px solid;'>
	<td>
	

	<?php echo $v['reference'] ?>
	
	
	</td>
	<td>
	
	<?php echo $v['contractName'] ?>
	</td>
	<td>
	
	<?php echo $v['detail'] ?>
	</td>
	<td>
	<?php echo $v['whoID'] ?>
	</td>
	<td>
	<?php echo $v['companyName'] ?>
	</td>
        	<td>
	<?php echo $v['reviewDueDate'] ?>
	</td>
	</tr>
	
	<?php }

	

	
	?>
	
	
	</table>

</DIV>
<?php

//fclose($fn);





//require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>