<?php
 /**
  $Id: test_upload_next.php,v 3.04 Tuesday, October 26, 2010 10:04:39 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage
  * @since  Friday, October 22, 2010 6:26:50 PM>
  */

$_HIDE_HTTP_HEADER = true;

$modulename = 'contractor';

require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

//echo PHPSESSID;

$section = $_GET['section'];
$record_id = $_GET['id'];


$d = dir(realpath("../tmp"));

while (false !== ($entry = $d->read())) {
	if ( $entry != '.' && $entry != '..' ) {

		//$destination_filename = '../tmp/'.$section.'_'.$record_id.'_'.$modulename.'_'.$_FILES['Filedata']['name'];

		$pattern = "/^".$section.'_'.$record_id.'_'.$modulename."_/";
		preg_match($pattern, $entry, $matches);
		if($matches) {
		echo $entry."<br/>";
		}

		//echo $entry."\n";
	}
}
$d->close();