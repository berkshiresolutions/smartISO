<?php
 /**
  $Id: index.php,v 3.12 Wednesday, December 15, 2010 3:25:56 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, September 07, 2010 12:02:45 PM>
  */


// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/index.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


if (isset($_SESSION['Contract']['OnHold']) && is_bool($_SESSION['Contract']['OnHold'])) {
	unset($_SESSION['Contract']['OnHold']);
	unset($_SESSION['Contract']['OnHoldContractManager']);
	unset($_SESSION['Contract']['OnHoldContractManagerID']);
	unset($_SESSION['Contract']['OnHoldContractTender']);
	redirection('../contracts/index.php');
}

$archive_flag = (int) Session::getSessionField('ARCHIVE_RECORDS');
$user_level = (int) Session::getSessionField('SESS_USER_LEVEL');

$smarty->assign('archive_flag',$archive_flag);
$smarty->assign('user_level',$user_level);
$smarty->force_compile = true;
$smarty->display('contractors/show_contract.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>