<?php
 /**
  $Id: contractor_documents.php,v 3.49 Saturday, December 18, 2010 12:28:53 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the documents section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Friday, October 08, 2010 7:14:38 PM>
  */

$class_documents = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Documents"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic_upload.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();


$action = Session::getSessionField('action');
$participantObj 	= 	SetupGeneric::useModule('Participant');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {


	$data_array['contractor_id'] 								= $_POST['cid'];
	$data_array['contractors_questionnaire'] 					= (int) $_POST['radio_sub_contractors_form'];
	$data_array['continuous_improvement'] 						= (int) $_POST['radio_evidence_cont_improvement'];
	$data_array['health_safety_policy'] 						= (int) $_POST['radio_health_safety_policy'];
	$data_array['environmental_policy'] 						= (int) $_POST['radio_environmental_policy'];
	$data_array['quality_policy'] 								= (int) $_POST['radio_quality_policy'];
	$data_array['health_safety_procedures'] 					= (int) $_POST['radio_health_safety_procedures'];
	$data_array['environmental_procedures'] 					= (int) $_POST['radio_environmental_procedures'];
	$data_array['quality_procedures'] 							= (int) $_POST['radio_quality_procedures'];
	$data_array['examples_relevant_risk'] 						= (int) $_POST['radio_risk_assessments'];
	$data_array['examples_relevant_method'] 					= (int) $_POST['radio_method_statements'];
	$data_array['example_documentation'] 						= (int) $_POST['radio_consultation_employees'];
	$data_array['employee_health_safety'] 						= (int) $_POST['radio_health_safety_handbook'];
	$data_array['training_certificates'] 						= (int) $_POST['radio_training_certificates'];
	$data_array['work_equipment'] 								= (int) $_POST['radio_work_equipment_records'];
	$data_array['portable_appliance'] 							= (int) $_POST['radio_portable_appliance_records'];
	$data_array['employee_guidance_documentation'] 				= (int) $_POST['radio_employee_guidance'];
	$data_array['public_insurance'] 							= (int) $_POST['radio_public_liability_certificates'];
	$data_array['employers_insurance'] 							= (int) $_POST['radio_employers_liability_certificates'];
	$data_array['evidence_surveillance'] 						= (int) $_POST['radio_heath_surveillance'];
	$data_array['fire_assessment'] 								= (int) $_POST['radio_fire_risk_assessment'];
	$data_array['job_title'] 									= $_POST['job_title'];
	$data_array['docWhen'] 										= $_POST['when'];
	$data_array['who'] 											= $_POST['who_hidden'];

	//dump_array($_POST);
	$section_record_id = $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'] ;

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,10,$data_array);
		$contractorObj->editContractor();
		$e = 2;
	} else {
		//do insert
		$contractorObj->setContractorInfo(0,10,$data_array);
		$contractorObj->addContractor();
		$e = 1;
	}
    $tab=max(10, $contractorObj->getTab($record_id));
   $contractorObj->setTab($tab,$record_id)  ;

$save_finish 	 = (int) $_POST['save_finish'];

if ( $save_finish == 1 ) {
		$contractorObj->setContractorInfo($record_id,9,$data_array);
	$contractorObj->updateStatus();
}	



	redirection("index.php?e=$e");

}


$contractorObj->setContractorInfo($cid,10,"");
$data = $contractorObj->viewContractor();
//dump_array($data);exit;
    if ( is_array($data) ) {


	if ( $data['docWhen'] == '1900-01-01' || $data['docWhen'] == '' ) {
		$date = '';
	} else {
		$date = format_date($data['docWhen']);
	}

	$participantObj->setItemInfo(array(
						'id'=>$data['who']
						));
	$participant_details	= $participantObj->displayItemById();

	$edit_data['section_record_id'] 							= $data['ID'];
	$edit_data['radio_sub_contractors_form'] 					= $data['subContractorsQuestionnaire'];
	$edit_data['radio_evidence_cont_improvement']				= $data['continuousImprovement'];
	$edit_data['radio_health_safety_policy']					= $data['healthSafetyPolicy'];
	$edit_data['radio_environmental_policy'] 					= $data['environmentalPolicy'];
	$edit_data['radio_quality_policy'] 							= $data['qualityPolicy'];
	$edit_data['radio_health_safety_procedures'] 				= $data['healthSafetyProcedures'];
	$edit_data['radio_environmental_procedures'] 				= $data['environmentalProcedures'];
	$edit_data['radio_quality_procedures'] 						= $data['qualityProcedures'];
	$edit_data['radio_risk_assessments'] 						= $data['examplesRelevantRisk'];
	$edit_data['radio_method_statements'] 						= $data['examplesRelevantMethod'];
	$edit_data['radio_consultation_employees'] 					= $data['exampleDocumentation'];
	$edit_data['radio_health_safety_handbook'] 					= $data['employeeHealthSafety'];
	$edit_data['radio_training_certificates'] 					= $data['trainingCertificates'];
	$edit_data['radio_work_equipment_records'] 					= $data['workEquipment'];
	$edit_data['radio_portable_appliance_records'] 				= $data['portableAppliance'];
	$edit_data['radio_employee_guidance'] 						= $data['employeeGuidanceDocumentation'];
	$edit_data['radio_public_liability_certificates']			= $data['publicLiabilityInsurance'];
	$edit_data['radio_employers_liability_certificates'] 		= $data['employersLiabilityInsurance'];
	$edit_data['radio_heath_surveillance'] 						= $data['evidenceHealthSurveillance'];
	$edit_data['radio_fire_risk_assessment'] 					= $data['fireRiskAssessment'];
	$edit_data['job_title'] 									= smartisoStripslashes($data['jobTitle']);
	$edit_data['when'] 											= $date;
	$edit_data['who_display'] 									= trim($participant_details['forename'].' '.$participant_details['surname']);
	$edit_data['who']											= $data['who'];

	$smarty->assign('edit_data', $edit_data);

} else {

	$edit_data['radio_sub_contractors_form']					= "";
	$edit_data['radio_evidence_cont_improvement']				= "";
	$edit_data['radio_health_safety_policy']					= "";
	$edit_data['radio_environmental_policy']					= "";
	$edit_data['radio_quality_policy']							= "";
	$edit_data['radio_health_safety_procedures']				= "";
	$edit_data['radio_environmental_procedures']				= "";
	$edit_data['radio_quality_procedures']						= "";
	$edit_data['radio_risk_assessments']						= "";
	$edit_data['radio_method_statements']						= "";
	$edit_data['radio_consultation_employees']					= "";
	$edit_data['radio_health_safety_handbook']					= "";
	$edit_data['radio_training_certificates']					= "";
	$edit_data['radio_work_equipment_records']					= "";
	$edit_data['radio_portable_appliance_records']				= "";
	$edit_data['radio_employee_guidance']						= "";
	$edit_data['radio_public_liability_certificates']			= "";
	$edit_data['radio_employers_liability_certificates']		= "";
	$edit_data['radio_heath_surveillance']						= "";
	$edit_data['radio_fire_risk_assessment']					= "";
	$edit_data['job_title']										= "";
	$edit_data['who']											= "";
	$edit_data['when']											= "";
}

$jsdata .= "\n$('.ref_description_1_8').smartLightBox({heading: 'Refrence - 1.8',writeMode : false,width: '500',height: '200',description : 'State how you undertake the assessment & attach examples of any questionnaires you use.'});";
$jsdata .= "\n$('.ref_description_2_1').smartLightBox({heading: 'Refrence - 2.1',writeMode : false,width: '500',height: '200',description : 'Should there be a way to improve the project - design change, materials used, methods of work etc? Do you have a system for bringing such matters to our attention?'});";
$jsdata .= "\n$('.ref_description_3_1').smartLightBox({heading: 'Refrence - 3.1',writeMode : false,width: '500',height: '200',description : 'Do you have the following policies?<br/>Health & Safety Policy<br/>Environmental Policy<br/>Quality Policy'});";
$jsdata .= "\n$('.ref_description_3_2').smartLightBox({heading: 'Refrence - 3.2',writeMode : false,width: '500',height: '200',description : 'Do you have written HSE&Q procedures, work instructions or rules?'});";
$jsdata .= "\n$('.ref_description_3_3').smartLightBox({heading: 'Refrence - 3.3',writeMode : false,width: '500',height: '200',description : 'Have you carried out risk assessments to minimise the impact on personnel, equipment and the environment in developing procedures and work instructions?<br/>e&#46;g&#46; vibration, manual handling,working at heights, control of substances hazardous to health, lifting operations etc. If so, please attach examples relating to the type of work being bid for.'});";
$jsdata .= "\n$('.ref_description_3_4').smartLightBox({heading: 'Refrence - 3.4',writeMode : false,width: '500',height: '200',description : 'Do you carry out chemical risk assessments?'});";
$jsdata .= "\n$('.ref_description_4').smartLightBox({heading: 'Refrence - 4',writeMode : false,width: '500',height: '200',description : 'Do you formally consult with your employees on:'});";
$jsdata .= "\n$('.ref_description_5_4').smartLightBox({heading: 'Refrence - 5.4',writeMode : false,width: '500',height: '200',description : 'Have you issued current Health & Safety Handbooks or written instructions to your Employees?'});";
$jsdata .= "\n$('.ref_description_5_5').smartLightBox({heading: 'Refrence - 5.5',writeMode : false,width: '500',height: '200',description : 'Describe the Health & Safety Training given to Managers/Supervisors and Operatives in the last 3 years.'});";
$jsdata .= "\n$('.ref_description_8_1').smartLightBox({heading: 'Refrence - 8.1',writeMode : false,width: '500',height: '200',description : 'Do you have a system of routine inspection, testing and maintenance for the following equipment'});";
$jsdata .= "\n$('.ref_description_8_2').smartLightBox({heading: 'Refrence - 8.2',writeMode : false,width: '500',height: '200',description : 'Do you undertake portable appliance testing on all portable electric equipment?'});";
$jsdata .= "\n$('.ref_description_8_3').smartLightBox({heading: 'Refrence - 8.3',writeMode : false,width: '500',height: '200',description : 'Is there specified guidance on work equipment for employees that covers their use as well as inspection, testing & maintenance, including vibration  e&#46;g&#46; trigger time?'});";
$jsdata .= "\n$('.ref_description_11_1').smartLightBox({heading: 'Refrence - 11.1',writeMode : false,width: '500',height: '200',description : 'Insurance<br/>Provide your Employers Liability Insurance Details<br/>Provide your Public Liability Insurance Details'});";
$jsdata .= "\n$('.ref_description_12_1').smartLightBox({heading: 'Refrence - 12.1',writeMode : false,width: '500',height: '200',description : 'Where your business activities expose employees to hazards such as lead, asbestos, noise, vibration, chemical, dust etc. Do you have a health surveillance programme?'});";
$jsdata .= "\n$('.ref_description_14_1').smartLightBox({heading: 'Refrence - 14.1',writeMode : false,width: '500',height: '200',description : 'Do you complete, record and, where  applicable, review fire risk assessments for the workplace, including evacuation  procedures?'});";

$listdata .= "<script> (function($) { $(document).ready(function () {";
$listdata .= $jsdata;
$listdata .= "});})(jQuery);	</script>";

echo $listdata;
$tab=$contractorObj->getTab($cid);
$smarty->assign('tab',$tab);
$smarty->assign('cid', $cid);

$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);

$smarty->display($CURRENT_MODULE.'/contractor_documents.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>