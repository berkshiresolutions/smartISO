<?php
 /**
  $Id: add_edit_contractor.php,v 4.20 Thursday, February 10, 2011 4:04:41 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractors
  * @since  Tuesday, September 07, 2010 12:38:00 PM>
  */

$class_company_details = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Company Details"; // for current breadcrums


// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/add_edit_contractor.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$orgObj 			= SetupGeneric::useModule('Organigram');
$objRef 			= new UniqueReference();
$miscObj			= new Misc();

$cid  				= (int) $_GET['cid'];
$locObj 			= SetupGeneric::useModule('Locationgram');
$contractorObj 		= new Contractor();
$objParticipant 	= 		SetupGeneric::useModule('Participant');

$contractorObj->setContractorInfo($cid,1,"");
$action = Session::getSessionField('action');

Session::getSessionField('record_id');
$sql = sprintf("SELECT * FROM %s.participant_database", _DB_OBJ_FULL);
$dbHand = DB::connect(_DB_TYPE);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$participants = '';
$participansArr = array();
$participansDetailsArr = array();
while (($row = $pStatement->fetch(PDO::FETCH_ASSOC))) {
	$id = $row['participantID'];
	$name = $row['forename'];
	$surname = $row['surname'];
	if ($surname) $name .= ' ' . $surname;
	$participants .= '<option value="' . $id . '">' . $name . '</option>';
	$participansArr[$id] = $name;
	$participansDetailsArr[$id] = $name.' ('.$id.')';
}


if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {


	$date = $_POST['date'] != '' ? date('Y-m-d', strtotime($_POST['date'])) : '1900-01-01';

	$data_array['email'] 					= $_POST['email'];
	$data_array['company_name'] 			= $_POST['company_name'];
	$data_array['unique_reference'] 		= $_POST['unique_reference'];
	$data_array['location'] 				= $_POST['location'];
	$data_array['address'] 					= $_POST['address'];
	$data_array['contact_person'] 			= $_POST['contact_person'];
	$data_array['whenDate'] 				= $_POST['date'];
	$data_array['telephone_number'] 		= $_POST['telephone'];
	$data_array['fax'] 						= $_POST['fax'];
	$data_array['approvedbytender'] 		= (int) $_POST['approvedbytender'];
	$data_array['OJEU_Notice'] 		= (int) $_POST['OJEU_Notice'];
	$data_array['buID'] 					= $_POST['business_unit'];
	$data_array['trg'] 						= (int) $_POST['trg'];
//	$data_array['whoID'] 					= $_POST['contract_manager'];
	$record_id 								= (int) $_POST['cid'];

	$data_array['whoID'] 		= $_POST['contract_manage_hidden'];




 /*       if ($_POST['contract_manager']) {
		$cm = $_POST['contract_manager'];
		$sIndex = strrpos($cm, '(') + 1;
		$eIndex = strrpos($cm, ')');
		$data_array['whoID']	= substr($cm, $sIndex, $eIndex - $sIndex);
	}
*/
	if ( $record_id ) {
		$contractorObj->setContractorInfo($record_id,1,$data_array);
		$contractorObj->editContractor();
	} else {
		$data_array['unique_reference'] 		= $_POST['unique_reference'];
		$data_array['reference'] 				= $_POST['reference_number'];
		
		
		$contractorObj->setContractorInfo(0,1,$data_array);
		$contractorObj->addContractor();
		$miscObj->saveRecordAction(array('module'=>'CR','ref'=>$data_array['reference'],'action'=>'add')); // for tracking record actions
	 $record_id = $contractorObj->getCurrentRecordId();
	}



if($_POST['approvedbytender'] == 1 || $_POST['OJEU_Notice'] == 1){
  $contractorObj->setTab(0,$record_id)  ;
redirection("/contractors/index.php?e=6");
}
else{
    $tab=max(1, $contractorObj->getTab($record_id));
   $contractorObj->setTab($tab,$record_id)  ;
redirection("contractor_management.php?cid=".$record_id);

}
}

/* Current contractor record id */
$smarty->assign('cid', $cid);

echo "<script src='/includes/js/validations/email_check.js'></script>";
echo "<script src='/includes/js/validations/check_numeric.js'></script>";

$data = $contractorObj->viewContractor();

/* edit mode */
if ( $cid ) {

	$contractor_add['reference_number']			= $data['reference'];
	$contractor_add['company_name']			 	= smartisoStripslashes($data['companyName']);
	$contractor_add['address'] 					= smartisoStripslashes($data['address']);
	$contractor_add['telephone']				= $data['telephoneNumber'];
	$contractor_add['email'] 					= $data['emailAddress'];
	$contractor_add['location'] 				= $data['location'];
	$contractor_add['contact_person'] 			= smartisoStripslashes($data['contactPerson']);
	$contractor_add['date'] 					= format_date($data['date']);
	$contractor_add['fax'] 						= $data['fax'];
//	$contractor_add['TRG'] 						= $data['TRG'] == '1' ? 'checked' : '';
	$contractor_add['approvedbytender'] 		= $data['approve_by_tender'] == '1' ? 'checked' : '';
	$contractor_add['OJEU_Notice'] 		= $data['OJEU_Notice'] == '1' ? 'checked' : '';
	
	$selected               					= $data['buID'];
	$miscObj->saveRecordAction(array('module'=>'CT','ref'=>$data['reference'],'action'=>'edit')); // for tracking record actions
    
	$contractor_add['contract_manage'] = $data['whoID'];
$objParticipant->setItemInfo(array('id'=>$contractor_add['contract_manage']));
$participant_data = $objParticipant->displayItemById();
$contractor_add['contractManagerName'] = trim($participant_data['forename'].' '.$participant_data['surname']);

$tab=$contractorObj->getTab($cid);


} else {
$unique_reference 	        = $objRef->getUniqueNumber('CONTRACTOR');
	$contractor_add['reference_number'] = $unique_reference;
	$contractor_add['company_name'] = "";
	$contractor_add['address'] = "";
	$contractor_add['telephone'] = "";
	$contractor_add['email'] = "";
	$contractor_add['location'] = "";
	$contractor_add['contact_person'] = "";
	$contractor_add['date'] = date('m/d/Y');
	$contractor_add['fax'] = "";
	$contractor_add['unique_refrence']	= $unique_reference;
    $contractor_add['contractManager'] = "";
    $contractor_add['contractManagerName'] = "";
	$selected = 0;
        $tab=0;
}


$business_units = $orgObj->getBusinessUnits($selected);

$objParticipant->setItemInfo(array('id'=>$contractor_add['contractManager']));
$participant_data = $objParticipant->displayItemById();
$participant_name = $participant_data['forename'].' '.$participant_data['surname'];


$location_data = $locObj->getLocations($contractor_add['location']);

$smarty->assign('unique_refrence', $unique_refrence);
$smarty->assign('contractor_add', $contractor_add);
$smarty->assign('location', $location_data);
$smarty->assign('tender', $contractor_add['approvedbytender'] );

$smarty->assign('business_units',$business_units);
$smarty->assign('tab',$tab);

$session_action = Session::getSessionField('action');
if ( $cid )
    $smarty->assign('save_button_text',getSaveButtonText($session_action));
else
  $smarty->assign('save_button_text',getSaveButtonText('add'));
$smarty->assign('action',$session_action);


$smarty->display($CURRENT_MODULE.'/add_edit_contractor.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
