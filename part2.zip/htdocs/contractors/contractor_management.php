<?php
 /**
  $Id: contractor_management.php,v 4.03 Saturday, December 04, 2010 2:53:31 PM ehsindia Exp $
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * This file is for adding/editing the management section under contractor index.
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh
  * @package Smartiso
  * @subpackage Contractor
  * @since  Wednesday, October 06, 2010 6:39:34 PM>
  */

$class_management = "selected_tab"; // for current tab
$LAST_BREAD_CRUM = "Management"; // for current breadcrums

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/generic.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$cid = (int) $_GET['cid'];
$contractorObj = new Contractor();
$contractorObj->setContractorInfo($cid,2,"");
$action = Session::getSessionField('action');

if ( $_SERVER['REQUEST_METHOD'] == 'POST' )  {

	$data_array['contractor_id'] 				= $_POST['cid'];
	$data_array['responsible_health_name'] 			= $_POST['health_safety_name_1'];
	$data_array['responsible_health_position'] 		= $_POST['health_safety_position_1'];
	$data_array['responsible_environment_name']             = $_POST['environment_protection_name_1'];
	$data_array['responsible_environment_position']         = $_POST['environment_protection_position_1'];
	$data_array['responsible_quality_name'] 		= $_POST['quality_name_1'];
	$data_array['responsible_quality_position']             = $_POST['quality_position_1'];
        $data_array['responsible_security_name'] 		= $_POST['security_name_1'];
	$data_array['responsible_security_position']            = $_POST['security_position_1'];
	$data_array['competent_health_name'] 			= $_POST['health_safety_name_2'];
	$data_array['competent_health_position'] 		= $_POST['health_safety_position_2'];
	$data_array['competent_environment_name'] 		= $_POST['environment_protection_name_2'];
	$data_array['competent_environment_position']           = $_POST['environment_protection_position_2'];
	$data_array['competent_quality_name'] 			= $_POST['quality_name_2'];
	$data_array['competent_quality_position'] 		= $_POST['quality_position_2'];
        $data_array['competent_security_name'] 			= $_POST['security_name_2'];
	$data_array['competent_security_position'] 		= $_POST['security_position_2'];
	$data_array['employee_full_time'] 			= $_POST['full_time'];
	$data_array['employee_part_time'] 			= $_POST['part_time'];
	$data_array['self_employed_persons'] 			= $_POST['radio_self_employed_persons'];
	$data_array['self_employed_persons_count'] 		= $_POST['self_employed_persons'];
	$data_array['complete_details_name_1'] 			= $_POST['details_name_1'];
	$data_array['complete_details_name_2'] 			= $_POST['details_name_2'];
	$data_array['complete_details_name_3'] 			= $_POST['details_name_3'];
	$data_array['complete_details_name_4'] 			= $_POST['details_name_4'];
	$data_array['complete_details_name_5'] 			= $_POST['details_name_5'];
	$data_array['complete_details_name_6'] 			= $_POST['details_name_6'];
	$data_array['complete_details_name_7'] 			= $_POST['details_name_7'];
	$data_array['complete_details_name_8'] 			= $_POST['details_name_8'];
	$data_array['complete_details_trade_1']			= $_POST['details_trade_1'];
	$data_array['complete_details_trade_2'] 		= $_POST['details_trade_2'];
	$data_array['complete_details_trade_3'] 		= $_POST['details_trade_3'];
	$data_array['complete_details_trade_4'] 		= $_POST['details_trade_4'];
	$data_array['complete_details_trade_5'] 		= $_POST['details_trade_5'];
	$data_array['complete_details_trade_6'] 		= $_POST['details_trade_6'];
	$data_array['complete_details_trade_7'] 		= $_POST['details_trade_7'];
	$data_array['complete_details_trade_8'] 		= $_POST['details_trade_8'];



	$section_record_id = (int) $_POST['section_record_id'];
	$record_id = $data_array['contractor_id'];

	if ( $section_record_id ) {
		// do update
		$contractorObj->setContractorInfo($record_id,2,$data_array);
		$contractorObj->editContractor();
	} else {
		//do insert
		$contractorObj->setContractorInfo(0,2,$data_array);
		$contractorObj->addContractor();
	}

    $tab=max(2, $contractorObj->getTab($record_id));
   $contractorObj->setTab($tab,$record_id)  ;
	redirection("contractor_competency.php?cid=".$record_id);

}

/* Current contractor record id */
$smarty->assign('cid', $cid);

/* For edit mode*/


	$data = $contractorObj->viewContractor();
        if ( is_array($data) ) {
	//dump_array($data);
	$section_record_id 					= $data['ID'];
	$health_safety_name_1      	 		= smartisoStripslashes($data['responsibleHealthSafetyName']);
	$health_safety_position_1   		= smartisoStripslashes($data['responsibleHealthSafetyPosition']);
	$environment_protection_name_1 		= smartisoStripslashes($data['responsibleEnvironmentProtectionName']);
	$environment_protection_position_1 	= smartisoStripslashes($data['responsibleEnvironmentProtectionPosition']);
	$quality_name_1 			= smartisoStripslashes($data['responsibleQualityName']);
	$quality_position_1 			= smartisoStripslashes($data['responsibleQualityPosition']);
	$security_name_1 			= smartisoStripslashes($data['responsibleSecurityName']);
	$security_position_1 			= smartisoStripslashes($data['responsibleSecurityPosition']);
	$health_safety_name_2 			= smartisoStripslashes($data['competentHealthSafetyName']);
	$health_safety_position_2 		= smartisoStripslashes($data['competentHealthSafetyPosition']);
	$environment_protection_name_2 		= smartisoStripslashes($data['competentEnvironmentProtectionName']);
	$environment_protection_position_2 	= smartisoStripslashes($data['competentEnvironmentProtectionPosition']);
	$quality_name_2 			= smartisoStripslashes($data['competentQualityName']);
	$quality_position_2 			= smartisoStripslashes($data['competentQualityPosition']);
	$security_name_2 			= smartisoStripslashes($data['competentSecurityName']);
	$security_position_2 			= smartisoStripslashes($data['competentSecurityPosition']);
	     
        $full_time 							= $data['employeesFullTime'];
	$part_time 							= $data['employeesPartTime'];
	$radio_self_employed_persons 		= $data['engagingSelfEmployedPersons'];
	$self_employed_persons 				= $data['engagingSelfEmployedPersonsCount'];
	$details_name_1 					= smartisoStripslashes($data['completeDetailsName_1']);
	$details_name_2 					= smartisoStripslashes($data['completeDetailsName_2']);
	$details_name_3 					= smartisoStripslashes($data['completeDetailsName_3']);
	$details_name_4 					= smartisoStripslashes($data['completeDetailsName_4']);
	$details_name_5 					= smartisoStripslashes($data['completeDetailsName_5']);
	$details_name_6 					= smartisoStripslashes($data['completeDetailsName_6']);
	$details_name_7 					= smartisoStripslashes($data['completeDetailsName_7']);
	$details_name_8 					= smartisoStripslashes($data['completeDetailsName_8']);
	$details_trade_1 					= smartisoStripslashes($data['completeDetailsTrade_1']);
	$details_trade_2 					= smartisoStripslashes($data['completeDetailsTrade_2']);
	$details_trade_3 					= smartisoStripslashes($data['completeDetailsTrade_3']);
	$details_trade_4 					= smartisoStripslashes($data['completeDetailsTrade_4']);
	$details_trade_5 					= smartisoStripslashes($data['completeDetailsTrade_5']);
	$details_trade_6 					= smartisoStripslashes($data['completeDetailsTrade_6']);
	$details_trade_7 					= smartisoStripslashes($data['completeDetailsTrade_7']);
	$details_trade_8 					= smartisoStripslashes($data['completeDetailsTrade_8']);


	$smarty->assign('section_record_id',$section_record_id);
	$smarty->assign("health_safety_name_1", $health_safety_name_1);
	$smarty->assign("health_safety_position_1", $health_safety_position_1);
	$smarty->assign("environment_protection_name_1", $environment_protection_name_1);
	$smarty->assign("environment_protection_position_1", $environment_protection_position_1);
	$smarty->assign("quality_name_1", $quality_name_1);
	$smarty->assign("quality_position_1", $quality_position_1);
        $smarty->assign("security_name_1", $security_name_1);
	$smarty->assign("security_position_1", $security_position_1);
	$smarty->assign("health_safety_name_2", $health_safety_name_2);
	$smarty->assign("health_safety_position_2", $health_safety_position_2);
	$smarty->assign("environment_protection_name_2", $environment_protection_name_2);
	$smarty->assign("environment_protection_position_2", $environment_protection_position_2);
	$smarty->assign("quality_name_2", $quality_name_2);
	$smarty->assign("quality_position_2", $quality_position_2);
        $smarty->assign("security_name_2", $security_name_2);
	$smarty->assign("security_position_2", $security_position_2);
	$smarty->assign("full_time", $full_time);
	$smarty->assign("part_time", $part_time);
	$smarty->assign("radio_self_employed_persons", $radio_self_employed_persons);
	$smarty->assign("self_employed_persons", $self_employed_persons);
	$smarty->assign("details_name_1", $details_name_1);
	$smarty->assign("details_name_2", $details_name_2);
	$smarty->assign("details_name_3", $details_name_3);
	$smarty->assign("details_name_4", $details_name_4);
	$smarty->assign("details_name_5", $details_name_5);
	$smarty->assign("details_name_6", $details_name_6);
	$smarty->assign("details_name_7", $details_name_7);
	$smarty->assign("details_name_8", $details_name_8);
	$smarty->assign("details_trade_1", $details_trade_1);
	$smarty->assign("details_trade_2", $details_trade_2);
	$smarty->assign("details_trade_3", $details_trade_3);
	$smarty->assign("details_trade_4", $details_trade_4);
	$smarty->assign("details_trade_5", $details_trade_5);
	$smarty->assign("details_trade_6", $details_trade_6);
	$smarty->assign("details_trade_7", $details_trade_7);
	$smarty->assign("details_trade_8", $details_trade_8);
	$smarty->assign("no_of_employees_parttime", $no_of_employees_parttime);
	//$smarty->assign("self_employed_persons", $self_employed_persons);
	$smarty->assign("complete_details", $complete_details);
	//$smarty->assign("radio_self_employed_persons", $radio_self_employed_persons);

}
$tab=$contractorObj->getTab($cid);
$smarty->assign('tab',$tab);
$session_action = Session::getSessionField('action');
$smarty->assign('save_button_text',getSaveButtonText($session_action));
$smarty->assign('action',$session_action);
//$smarty->debugging=true;
$smarty->display($CURRENT_MODULE."/contractor_management.tpl");

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>