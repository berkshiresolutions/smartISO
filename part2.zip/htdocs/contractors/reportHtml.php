<?php
 /**
  $Id: reportR1.php,v 3.06 Wednesday, January 05, 2011 12:31:30 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage DSE
  * @since  Monday, November 22, 2010 1:27:24 PM>
  */

$_SHOW_GUEST_HTTP_HEADER = true;
$_SHOW_POP_REPORT_HEADER = true;
$_HIDE_HTTP_HEADER = true;


require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$record_id	= (int) $_GET['id'];

$type = $_GET['type'];
$tender =  (int) $_GET['tender'];
$level =  "#".str_replace("|","|#",$_GET['level']);

switch($type) {
	case 'R1' : $identifier = 'CONTRACTORR1'; break;
	case 'R2' : $identifier = 'CONTRACTORR2'; break;
	case 'R3' : $identifier = 'CONTRACTORR3'; break;
}

$repObj = new Report('html');
$repObj->setFilters(array('id'=>$record_id,'type'=>$_GET['type'],'tender'=>$tender,'level'=>$level,));
$repObj->generateReport($identifier);
$repObj->displayReport();

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
