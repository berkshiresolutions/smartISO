<?php
 /**
  $Id: ajax_participants_worksno.php,v 3.21 Saturday, November 20, 2010 1:03:32 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description ajax_participants_worksno.php
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$str = strip_tags($_GET['str']);
$eqObj = SetupGeneric::useModule('Participant');

$eqObj->setItemInfo(array(
						    'id' => 1,
							'works_number' => $str,
							));

$data = $eqObj->displayItemsByWorksNo();

$records = array();

if (is_array($data) && $data !='' ) {
	$i=0;
	foreach ($data as $value) {
		$participant_id = $value['participantID'];
		$records[$i]['id'] = $participant_id.'#!#'.$value['forename'].'#!#'.$value['surname'].'#!#'.$value['worksNumber'];
		$records[$i]['name'] = $value['worksNumber'].' - '.$value['forename'].' '.$value['surname'];
		$records[$i]['worksno'] = $value['worksNumber'];
		$i++;
	}
}

$resultset = array('records' => $records);

echo json_encode($resultset);
?>