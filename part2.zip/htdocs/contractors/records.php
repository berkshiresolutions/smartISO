<?php
 /**
  $Id: records.php,v 3.49 Tuesday, December 14, 2010 12:31:36 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Contractor
  * @since  Tuesday, September 07, 2010 12:01:16 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once _MYINCLUDES."record_listing_page.inc.php";

$contractorObj 		= new Contractor();
$optObj 			= new Option();

$participantObj	 	= SetupGeneric::useModule('Participant');
$archive_session 	= (int) Session::getSessionField('ARCHIVE_RECORDS');
$archive_data 		= array('archive'=>$archive_session);

	$lowerValue=$optObj->getOption('_SU_CONTRACTOR_FILTER1');	
	$upperValue=$optObj->getOption('_SU_CONTRACTOR_FILTER2');

//$contractorObj->setContractorInfo(0,1,$archive_data,40,60);
//$records = $contractorObj->viewAllContractors();

$isShortTermOrTender  = $_GET['isShortTermOrTender'];
$where = "";
if($isShortTermOrTender != "" and $isShortTermOrTender !="-1")
{
	$where = " and shortTermOrTender = '".$isShortTermOrTender."'  ";
}

$dbHand = DB::connect(_DB_TYPE);
$sql = sprintf("SELECT R.ID as ID, R.reference as reference,B.buName,B.buID,R.location as location,R.whoID as whoID,R.status as status,R.companyName as companyName,R.date as date, max(C.shortTermOrTender) as shortTermOrTenderts FROM %s.contractor R LEFT OUTER JOIN %s.contract C ON R.ID = C.useApprovedContractor left join %s.business_units B on R.buid=B.buID   where R.archive='".$archive_session."' ".$where." group by  R.ID , R.reference ,R.location ,R.whoID,R.companyName,R.date,R.status,B.buName,B.buID   ORDER BY ID desc",_DB_OBJ_FULL,_DB_OBJ_FULL,_DB_OBJ_FULL);
$pStatement = $dbHand->prepare($sql);
$pStatement->execute();
$records = $pStatement->fetchAll(PDO::FETCH_ASSOC);


// print "<pre>"; print_r($records);

$USER_ID = getLoggedInUserId();
$USER_LEVEL=getUserAccessLevel();

?>
<input type='hidden' name='selected_radio' id='selected_radio' value='0'>
<input type='hidden' name='selected_user' id='selected_user' value='0'>
<input type='hidden' name='current_user' id='current_user' value='<?php echo $USER_ID?>'>
<input type='hidden' name='low_value' id='low_value' value='<?php echo $lowerValue?>'>
<input type='hidden' name='high_value' id='high_value' value='<?php echo $upperValue?>'>
<input type='hidden' name='server' id='server' value='<?php echo $_SERVER["HTTP_HOST"]?>'>


<table cellpadding="2" cellspacing="4" border="0" class="display" id="module_records" >
	<thead>
		<tr style='color:#fff'>
			<th width='3%'>&nbsp;</th>
			<th width='20%'>Reference #</th>
			<th width='25%'>Company</th>
			
			<th width='20%'>Location</th>
                        <th width='*'>Business Unit</th>
			<th width='15%'>Approved date</th>
			<th width='10%'>Colour Code</th>
<th width='*'>&nbsp;</th>

		</tr>
	</thead>
	<tbody>
		<?php
		if ( count($records) ) {
			foreach ( $records as $value ) {
                   
				$locationObj				= 		SetupGeneric::useModule('Locationgram');
				$locationObj->setItemInfo(array('id'=>$value['location']));
				$location_data = "";
				$location = $locationObj->getFUllLocation();

				$participant_id = $value['whoID'];
				$participantObj->setItemInfo(array('id'=>$participant_id));
				$partcipantData = $participantObj->displayItemById();

				$participant_name = $partcipantData['forename'].' '.$partcipantData['surname'];
				$score_colour = $contractorObj->getColorCode($value['ID']);
				///$search_date = substr($value['date'],0,10);
				//echo $search_date;
				
/* bob				switch ($score_colour)
				{
				case '#ff0000' :
				$score_val=3;
				break;	
				case '#582C65' :        
				$score_val=1;
				break;			
				default :
				$score_val=2;
				break;	
				} */
				switch ($score_colour)
				{
				case '#2c6700' :
				$score_val=4;
				break;
				case '#ff0000' :
				$score_val=3;
				break;	
				case '#ff7e00' :        
				$score_val=2;
				break;	
				case '#00ff00' :        
				$score_val=1;
				break;
				case '#800080' :        
				$score_val=0;
				break;		
				default :
				$score_val=-1;
				break;	
				}
/*
				$countT = 0;
				$dbHand = DB::connect(_DB_TYPE);
				$sql = sprintf("SELECT count(*) as cnt FROM %s.contract WHERE useApprovedContractor = %d AND shortTermOrTender='%d' ",_DB_OBJ_FULL,$value['ID'] );
				$pStatement = $dbHand->prepare($sql);
				$pStatement->execute();
				$resultSetS = $pStatement->fetchAll(PDO::FETCH_ASSOC);
				$countT = $resultSet[0]['cnt'];
				//$search_date = substr($value['date'],0,10);
				
				if($countT=="")
					$countT = 0;
*/
				

				$status = (int) $value['status'];

				$change_bg_color = '';
				if ( $status == 1 ) {
					$change_bg_color = "style='background-color:green'";
				}
				?>
				<tr  class='record_row' rel='<?php echo $value['ID'] ?>'>
					<td width='3%' <?php echo $change_bg_color?>><input type='radio' name='record_radio' id='record_radio<?php echo $value['ID']?>' rel='<?php echo $value['reference']?>' admin="<?php echo $USER_LEVEL?>" user='<?php echo $participant_id?>' class='choose_radio' value='<?php echo $value['ID']?>'></td>
					<td><?php echo $value['reference']?></td>
					<td>
					
					<?php echo $value['companyName']?>
					
					</td>
					
					<td><?php echo $location?></td>
                                        <td><?php echo $value['buName']?></td>
					<td align='center' rel='<?php echo $value['ID'] ?>'><?php echo format_date($value['date']) ?></td>
					<td><div style='background-color: <?php echo $score_colour ?>;color: <?php echo $score_colour ?>;width:45px;height:15px;margin:auto'><?php echo $score_val ?></div></td>
<td><?php echo $value["buID"] ?></td>

				</tr>
			<?php }
		}
		?>
	</tbody>
	<tfoot>
		<tr>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			
			<th>&nbsp;</th>
		</tr>
	</tfoot>
</table>
