<?php



// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'contractor/contractor.js';

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


if (isset($_SESSION['Contract']['OnHold']) && is_bool($_SESSION['Contract']['OnHold'])) {
	unset($_SESSION['Contract']['OnHold']);
	unset($_SESSION['Contract']['OnHoldContractManager']);
	unset($_SESSION['Contract']['OnHoldContractManagerID']);
	unset($_SESSION['Contract']['OnHoldContractTender']);
	redirection('../contracts/index.php');
}

$archive_flag = (int) Session::getSessionField('ARCHIVE_RECORDS');
$user_level = (int) Session::getSessionField('SESS_USER_LEVEL');

$smarty->assign('shortTermOrTender',$_GET['type']);
$smarty->assign('contractorId',$_GET['id']);
$smarty->assign('archive_flag',$archive_flag);
$smarty->assign('user_level',$user_level);
$smarty->force_compile = true;
$smarty->display('contractors/contracts.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?> 