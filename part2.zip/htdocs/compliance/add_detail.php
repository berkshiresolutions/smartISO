<?php
/**
  $Id: manage_equipment_details_new.php,v 3.10 Friday, February 04, 2011 9:52:02 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Setup
 * @since  Tuesday, December 14, 2010 4:36:42 PM>
 */
$class_system_review1 = "selected_tab"; //selected tabs
$LAST_BREAD_CRUM = "Audit Detail";

$_PAGE_VALIDATION_SCRIPT = 'compliance/add_detail.js';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$compObj = new Compliance();
$objRef = new UniqueReference();

$start = (int) $_GET['start'];
$task = $_GET['task'];
$date = date("Y/m/d");
list($current_year, $current_month, $current_day) = explode("/", $date);


$current_date = array($current_month, $current_day, $current_year);

$today_date = implode("/", $current_date);




if ($_SERVER['REQUEST_METHOD'] == 'POST') {



$data["reference"]=$_POST["reference"];
$data["country"]=$_POST["country"];
$data["ttype"]=$_POST["ttype"];
$data["period"]=$_POST["period"];
$data["title"]=$_POST["title"];
$data["descript"]=$_POST["descript"];

$compObj->setComplianceInfo(0,$data);

    Session::saveSessionField('review_id', $rID);
 $id= $compObj->addCompliance();  
 
 
 $objModTracker = new ModuleTracker();
 $objModTracker->saveRecordLog1("compliance_master","COMP",$id,$data["reference"],'add');
 
 
 
    $compObj->buildQuestionList($id);
    $compObj->sendMail($id);

    redirection('index.php');

    exit;


}




$reference = $objRef->getUniqueNumber('CP');



$periodopt = "<option value=0 selected>-- Select --</option>";
$periodopt .= "<option value='1'  >January</option>";
$periodopt .= "<option value='2'  >Febuary</option>";
$periodopt .= "<option value='3'  >March</option>";  
$periodopt .= "<option value='4'  >April</option>";  
$periodopt .= "<option value='5'  >May</option>"; 
$periodopt .= "<option value='6'  >June</option>"; 
$periodopt .= "<option value='7'  >July</option>"; 
$periodopt .= "<option value='8'  >August</option>"; 
$periodopt .= "<option value='9'  >September</option>"; 
$periodopt .= "<option value='10'  >October</option>"; 
$periodopt .= "<option value='11'  >November</option>"; 
$periodopt .= "<option value='12'  >December</option>"; 
$periodopt .= "<option value='13'  >Bi - Annual</option>"; 
$periodopt .= "<option value='14'  >Tri - Annual</option>"; 


$countryData= $compObj->getCountry();

$countryopt = "<option value=0 selected>-- Select --</option>";

    foreach ($countryData as $key => $value) {
        $countryopt .= "<option value='" . $value['ID'] . "'  >" . $value['country'] . "</option>";

    }
 
    
$complianaceData=$compObj->getTypes();

$ttopt = "<option value=0 selected>-- Select --</option>";

    foreach ($complianaceData as $key => $value) {
        $ttopt .= "<option value='" . $value['ID'] . "'  >" . $value['template_type'] . "</option>";
   }
    
//$ttopt .= "<option value=1 selected>Compliance</option>";
//$ttopt .= "<option value=3>Compliance 2</option>";
$smarty->assign('periodopt', $periodopt);
//$smarty->assign('countryopt', $countryopt);
$smarty->assign('ttopt', $ttopt);
$smarty->assign('reference', $reference);
$smarty->assign('today_date', $today_date);
//$smarty->debugging=true;
$smarty->display('compliance/add_detail.tpl');
require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>



?>