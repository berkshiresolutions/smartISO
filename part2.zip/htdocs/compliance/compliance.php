<?php
 /**
  $Id: review.php,v 3.71 Friday, January 28, 2011 3:50:08 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  * PHP version 5
  *
  * Listing page for system reviews page
  *
  * This page will list opened and closes system reviews.
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage System Review
  * @since  Wednesday, September 15, 2010 12:01:17 PM>
  */

$LAST_BREAD_CRUM = 'Complinae'; //for last breadcrum
$class_soa = 'selected_tab'; //for selected tabs
// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'compliance/compliance.js';

/* Common header for application */
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$id = (int) $_GET['qid'];
$ID_question = (int) $_GET['ID'];
$review_id 		= Session::getSessionField('review_id');


/* Create Objects for Review and Review Question class. */
$compObj 		= new Compliance();

$results=$compObj->viewAllCompliance();

dump_array($results);

/* Class smarty template */
//$smarty->display($_CURRENT_MODULE.'/compliance.tpl');

/* Common footer for application */
require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>