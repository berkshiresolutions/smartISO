<?php

/**
  $Id: add_edit_nhp_details.php,v 3.12 Friday, January 28, 2011 3:05:33 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage NHP
 * @since  Saturday, September 11, 2010 5:48:29 PM>
 */
session_start();

$class_nhp_details = "selected_tab"; // for selected tab
$LAST_BREAD_CRUM = "Compliance Alert";

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'compliance/add_edit_problem_alert.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$orgObj = SetupGeneric::useModule('Organigram');
$locObj = SetupGeneric::useModule('Locationgram');
$participantObj = SetupGeneric::useModule('Participant');

$objCom = new ComplianceAlert();
//$miscObj = new Misc();
$path = $_SERVER['HTTP_HOST'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $data_array['unique_reference'] = $_POST['reference_number'];
    $data_array['location'] = $_POST['location'];
    $data_array['business_unit'] = $_POST['business_unit'];
    $data_array['date'] = $_POST['date'];
    $data_array['time'] = $_POST['time'];
    $data_array['issue'] = $_POST['issue1'];
    $data_array['companyref'] = $_POST['companyref'];
    $data_array['type1'] = (int)$_POST['type1'];
    $data_array['type2'] = (int)$_POST['type2'];
    $data_array['descp'] = str_replace("'", "`", $_POST['descp']);
    $data_array['violation'] = str_replace("'", "`", $_POST['violation']);
    $data_array['plan'] = str_replace("'", "`", $_POST['plan']);
    $data_array['who'] = $_POST['name_hidden'];

    // do insert

    $objCom->setComplianceInfo(0, $data_array);
    $record_id = $objCom->addComplianceAlert();


    $aid = $objCom->addAction($record_id);

    $objModTracker = new ModuleTracker();
    $objModTracker->setModuleTrackerInfo('CPLA', array(
        'rec_id' => $record_id,
        'action' => 'add'
    ));


    $objModTracker->saveRecordLog();
    $objModTracker = null;


    redirection("/");
}
$un= new  UniqueReference();
$unique_reference = $un->getUniqueNumber('CPA');
$today = date("m/d/Y");
$userid= getLoggedInUserId();


    $participantObj->setItemInfo(array('id' => $userid));
    $val = $participantObj->displayItemMaininfoById();
    $name = $val["forename"] . " " . $val["surname"];
    
$action = 'add';
$row_data['refrence_number'] = $unique_reference;

$business_unit = $orgObj->getBusinessUnits($row_data['business_unit_selected']);
$location_data = $locObj->getLocations($row_data['location_selected']);

$action = Session::getSessionField('task');
$smarty->assign('save_button_text', getSaveButtonText($action));
$smarty->assign('action', $action);
$smarty->assign('name', $name);
$smarty->assign('location', $location_data);
$smarty->assign('row_data', $row_data);

$smarty->display('compliance/add_edit_problem_alert.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>