<?php

/**
  $Id: add_edit_nhp_details.php,v 3.12 Friday, January 28, 2011 3:05:33 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage NHP
 * @since  Saturday, September 11, 2010 5:48:29 PM>
 */
$class_nhp_details = "selected_tab"; // for selected tab
$LAST_BREAD_CRUM = "Compliance Alert";

// load jquery page validation script file
$_PAGE_VALIDATION_SCRIPT = 'compliance/add_edit_view_alert.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$orgObj = SetupGeneric::useModule('Organigram');
$locObj = SetupGeneric::useModule('Locationgram');
$participantObj = SetupGeneric::useModule('Participant');

$objCom = new ComplianceAlert();
$commObj = new Compliance();
//$miscObj = new Misc();
$path = $_SERVER['HTTP_HOST'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id = $_POST['id'];
    $data_array['resolve_date'] = $_POST['resolve_date'] == "-" ? '' : format_date_for_mysql($_POST['resolve_date']);
    $data_array['cr_date'] = $_POST['cr_date'] == "-" ? '' : format_date_for_mysql($_POST['cr_date']);
    $data_array['r_date'] = $_POST['r_date'] == "-" ? '' : format_date_for_mysql($_POST['r_date']);
    $data_array['impact'] = $_POST['impact'];
    $data_array['likelihood'] = $_POST['likelihood'];
    $data_array['name'] = $_POST['name_hidden'];
    $data_array['current_name'] = $_POST['current_name_hidden'];
            $data_array['period'] = $_POST['period'];
 $data_array['final'] = 0;
    // do insert

    $objCom->setComplianceInfo($id, $data_array);
    $record_id = $objCom->updateComplianceAlert();


            $data_array['action'] = $_POST['action'];
            $data_array['period'] = $_POST['period'];
            $data_array['company'] = $_POST['companya'];
            $data_array['country'] = $_POST['countrya'];
            $data_array['atype'] = $_POST['atype'];
            $data_array['who'] = $_POST['who_hidden'];
            $data_array['whoAU'] = $_POST['manager_hidden'];
            $data_array['whoAU2'] = $_POST['whoAU2_hidden'];
            $data_array['when'] = $_POST['when'];
            $data_array['module'] = "Compliance" ;
            $data_array['actionID'] = $_POST['action_id'];
            $data_array['pfReq'] = $_POST['pfReq'];
            $data_array['docReq'] = $_POST['docReq'];
            $data_array['save_finish'] = (int) $_POST['final'];

            $objCom->setComplianceInfo($id, $data_array);
            $objCom->editActions();
   
            
          
            
    $objModTracker = new ModuleTracker();
    $objModTracker->saveRecordLog1("compliance_alert","CPLA",$id,$_POST['ref'],'update');

    $objModTracker = null;


    redirection("/compliance/indexalert.php");
}

$cpa_id = (int) $_GET['id'];

$data = $objCom->displayId($cpa_id);

$data["startdate"] = format_date($data["startdate"]);
$data["resolve_date"] = $data["resolve_date"] == '' ? "" : format_date($data["resolve_date"]);
$data["register_date"] = $data["register_date"] == '' ? "" : format_date($data["register_date"]);
$data["resolution_date"] = $data["resolution_date"] == '' ? "" : format_date($data["resolution_date"]);


$companies = $commObj->getCompanies($record_id);
$bus = $commObj->getCountries($record_id);
//$typeString = "<OPTION value='Process'>Process</option><OPTION value='Procedure'>Procedure</option><OPTION value='Update Template'>Update Template</option><OPTION value='Update Manual'>Update Manual</option><OPTION value='Training'>Training</option><OPTION value='Legislation'>Legislation</option><OPTION value='Other'>Other</option>";

$typeString = array('Process'=>'Process','Procedure'=>'Procedure','Update Template'=>'Update Template','Update Manual'=>'Update Manual','Training'=>'Training','Legislation'=>'Legislation','Other'=>'Other');
$periodStr = "<option value='0' >-- Select --</option><option value='1' >Monthly</option><option value='2' >Bi- Monthly</option><option value='3'>Quarterly</option><option value='4'  >Semi-Annually</option><option value='5' >Annually</option><option value='6' >Bi - Annually</option><option value='7' >Tri - Annually</option>";

if ($data["issue"] == 1) {
    $smarty->assign('issue1', 'checked');
    $smarty->assign('issue2', '');
} else {
    $smarty->assign('issue1', '');
    $smarty->assign('issue2', 'checked');
}
if ($data["type1"] == 1) {
    $smarty->assign('type1', 'checked');
} 
if ($data["type2"] == 1) {
    $smarty->assign('type2', 'checked');
}


$likely = array(
    1 => "Virtually Certain",
    2 => "Very Likely",
    3 => "Likely",
    4 => "Unlikely",
    5 => "Very Unlikely",
    6 => "Almost Impossible"
);

$smarty->assign('likely', $likely);
$impact = SetupGeneric::useModule('ImpactMeasure');
$impact->setItemInfo(array(
    'id' => $rec_id
));
$data_records = $impact->displayItems();
if (is_array($data_records)) {
    foreach ($data_records as $key => $value) {
        $impact_array[$value['ID']] = $value['name'];
    }
}


$i1 = $data["impact"];
$l1 = $data["likelihood"];
$total1 = ((6 - $l1) * (6 - $i1));



$actions = $objCom->getActions($cpa_id);


if (is_array($actions)) {
    foreach ($actions as $key => $value) {

        /* participant details */
        $participantObj->setItemInfo(array(
            'id' => $value['who']
        ));
        $participant_details = $participantObj->displayItemById();

        $participantObj->setItemInfo(array('id' => $value['whoAU']));
        $particpantAU_data = $participantObj->displayItemById();

        $participantObj->setItemInfo(array('id' => $value['addapprover']));
        $particpantAU2_data = $participantObj->displayItemById();

        $due_date = $value['dueDate'] == '' ? '' : format_date($value['dueDate']);

        $manager = $particpantAU_data['forename'] . ' ' . $particpantAU_data['surname'];
        $action['description'][] = smartisoStripslashes($value['actionDescription']);
        $action['who_display'][] = trim($participant_details['forename'] . ' ' . $participant_details['surname']);
        $action['whoAU_display'][] = $manager == " " ? "Manager" : trim($manager);
        $action['whoAU2_display'][] = trim($particpantAU2_data['forename'] . ' ' . $particpantAU2_data['surname']);
        $action['who'][] = $value['who'];
        $action['whoAU'][] = $value['whoAU'];
        $action['typeaction'][] = $value['moduleName'];
        $action['whoAU2'][] = $value['addapprover'];
        $action['when'][] = $due_date;
        $action['id'][] = $value['ID'];
        $action['status'][] = $value['status'];
        $action['company'][] = $value['company'];
        $action['region'][] = $value['region'];
        $action['alerttype'][] = $value['alerttype'];
        $action['period'][] = $value['period'];
		
    }
}



if ($total1 < 2) {
    $priority_color = "#800080"; //priority_color = "PURPLE";
    $riskvalue = "T";
} else if ($total1 < 6) {
    $priority_color = "#008000"; //priority_color = "GREEN";
    $riskvalue = "L";
} else if ($total1 < 12) {
    $priority_color = "#FFBF00"; //priority_color = "AMBER";
    $riskvalue = "M";
} else if ($total1 < 25) {
    $priority_color = "#FF0000"; //priority_color = "RED"; 
    $riskvalue = "H";
} else {
    $priority_color = "#FF0000"; //priority_color = "RED";  
    $riskvalue = "I";
}
if ($data['link']>0){
$dataT=$commObj->getAnswerCataById($data['link']);
$smarty->assign('dataT', $dataT);
}
$smarty->assign('periodStr', $periodStr);
$smarty->assign('bu_dropdown', $bus);
$smarty->assign('companies', $companies);
$smarty->assign('typeStr', $typeString);
$smarty->assign('periodStr', $periodStr);
$smarty->assign('colour', $priority_color);
$smarty->assign('riskvalue', $riskvalue);
$smarty->assign('impact_array', $impact_array);
$smarty->assign('data', $data);
$smarty->assign('actions', $action);
$smarty->assign('dataT', $dataT);
$smarty->assign('action_count', count($action));
//$smarty->debugging=true;
$smarty->display('compliance/add_edit_view_alert.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>