<?php
 /**
  $Id: delete_record.php,v 3.16 Monday, October 11, 2010 6:15:27 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Customer Complaint
  * @since  Monday, October 11, 2010 5:57:28 PM>
  */

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$record_id = $_GET['id'];

$objComp = new ComplianceAlert();
$objComp->setComplianceInfo($record_id,"");
$objComp->restoreRecord();
//redirection("index.php");
echo 1;
?>