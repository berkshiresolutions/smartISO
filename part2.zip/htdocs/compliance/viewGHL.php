<?php
 /**
  $Id: report.php,v 3.12 Wednesday, November 24, 2010 3:08:26 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * for customer-complaint report
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Saturday, November 20, 2010 10:51:04 AM>
  */


$_HIDE_HTTP_HEADER = false;
$_SHOW_GUEST_HTTP_HEADER = false;
$_PAGE_VALIDATION_SCRIPT2 = 'compliance/add_edit.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$compliance = new Compliance();
$objUpload		= new Upload();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$compliancedata=$_POST['data'];
	$when=$_POST['when'];
$check=$_POST['check'];
	$control=$_POST['control'];

foreach($_POST["id"] as $key=>$value){

    if ($check[$value] == 1){
                $data['file_upload']['name'] 			= $_FILES['file_upload']['name'][$value];
		$data['file_upload']['type'] 			= $_FILES['file_upload']['type'][$value];
		$data['file_upload']['tmp_name'] 		= $_FILES['file_upload']['tmp_name'][$value];
		$data['file_upload']['error'] 			= $_FILES['file_upload']['error'][$value];
		$data['file_upload']['size'] 			= $_FILES['file_upload']['size'][$value];
		$data['file_upload']['destination'] 	= 'compliance';

		if ( $data['file_upload']['size'] >0 ) {

			$objUpload->setFileInfo('compliance',$data['file_upload']);

			$objUpload->add_file();
			

			$fileid=$objUpload->getLastFileId();
		}
                else
		$fileid=0;	
        

$compliance->updateQuestion($value,$compliancedata[$value],$when[$value],$control[$value],$fileid);

		}
}          
if ($_POST['flag']==1){
    //todo
// $compliance->finish(); 
// $compliance->roaEmails();   
}
    redirection('index.php');
}

$id = $_GET['id']; 
$compliance->setComplianceInfo($id,'');
$dataStart = $compliance->getMasterbyID() ;

$data = $compliance->getQuestions($id) ;
$i=0;
$userid=getLoggedInUserId();
$USER_LEVEL=getUserAccessLevel();

         $optionObj = new Option();
    $red = $optionObj->getOption('_SU_EMAIL_REDMAIL');
    $yellow = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
    $green = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');
//var_dump($data);
foreach($data as $row){
		
//    if ($USER_LEVEL !=1 && $userid !== $row["who"])
  //      continue;
 $out[$row['period']][$row['Main_Heading']][$i]=$row; 
  $out[$row['period']][$row['Main_Heading']][$i]['when'] = format_date($row["whendate"])=='01/01/1970' ? '' : format_date($row["whendate"]); 
  $out[$row['period']][$row['Main_Heading']][$i]['check'] = (int) $row["who"] == 0 ? 0 : -1; 
  
  if (!$row['doneDate']){
          $str = (strtotime($row['dueDate'])) - strtotime(date("M d Y "));
        $dateinc = floor($str / 3600 / 24);


            $change_bg_color = "";
       if ($dateinc > $green) {
            $change_bg_color = "";
        } else if ($dateinc > $yellow) {
            $change_bg_color = "background-color:green;COLOR:WHITE";
        } else if ($dateinc > $red) {
            $change_bg_color = "background-color:#F4A460;COLOR:WHITE";
        } else {
            $change_bg_color = "background-color:red;COLOR:WHITE";
        }
   $out[$row['period']][$row['Main_Heading']][$i]['duedatestyle'] =$change_bg_color; 
    
   
  }
  
  
     $date = new DateTime(date("Y-m-d", strtotime("last day of previous month")));
     date_add($date, date_interval_create_from_date_string($row["dateoffset"] . ' days'));
       $out[$row['period']][$row['Main_Heading']][$i]['dateExe']=$date->format('Ymd');
     
         if (!$row['when']){
                 $str1 = (strtotime($date->format("M d Y "))) - strtotime(date("M d Y "));
        $dateinc1 = floor($str1 / 3600 / 24);


            $change_bg_color1 = "";
       if ($dateinc1 > $green) {
            $change_bg_color1 = "";
        } else if ($dateinc1 > $yellow) {
            $change_bg_color1 = "background-color:green;COLOR:WHITE";
        } else if ($dateinc1 > $red) {
            $change_bg_color1 = "background-color:#F4A460;COLOR:WHITE";
        } else {
            $change_bg_color1 = "background-color:red;COLOR:WHITE";
        }
        
          $out[$row['period']][$row['Main_Heading']][$i]['dateexestyle'] =$change_bg_color1; 
         }

		switch((int)$row["compliance"]){
			case 3: $change_bg_color2 = "background-color:green;"; break;
			case 2: $change_bg_color2 = "background-color:red;"; break;
			case 1: $change_bg_color2 = "background-color:purple;"; break;
			default:$change_bg_color2 = ""; break;
		}
		          $out[$row['period']][$row['Main_Heading']][$i]['statusstyle'] =$change_bg_color2;  
 
			$out[$row['period']][$row['Main_Heading']][$i]['comments'] = $compliance->getLastCommentsbyID($row["questID"]);
 
 $i++;
} 
$periodArr=array(0 =>'-',1 =>'Monthly',2 =>'Bi- Monthly',3=>'Quarterly',4 =>'Semi-Annually',5 => 'Annually',6 => 'Bi - Annually',7 => 'Tri - Annually');

$yn=array('Yes'=>'Yes','No'=>'No');
$monthly=array('January'=>'January','February'=>'Febraury');
$smarty->assign('hdrdata', $dataStart);
$smarty->assign('data', $out);
$smarty->assign('ref', $dataStart["reference"]);
$smarty->assign('refid', $id);
$smarty->assign('periodStr', $periodArr[(int)$dataStart["period"]]);
//$smarty->debugging=true;
$smarty->display('compliance/viewGHL.tpl');

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
