<?php

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$id = $_GET["id"];
$locObj = SetupGeneric::useModule('Locationgram');
$partObj = SetupGeneric::useModule('Participant');
$userid= getLoggedInUserId();
$ur = new UniqueReference();
$commObj = new Compliance();
$unique_reference = $ur->getUniqueNumber('CPA');
$location_data = $locObj->getLocations($row_data['location_selected']);

    $partObj->setItemInfo(array('id' => $userid));
    $val = $partObj->displayItemMaininfoById();
    $name = $val["forename"] . " " . $val["surname"];
    
$data=$commObj->getAnswerCataById($id);
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
//$document_version_info_html .= "<script type='text/javascript' src='//code.jquery.com/jquery-1.9.1.js'></script>";
//$document_version_info_html .= "<script type='text/javascript' src='//code.jquery.com/ui/1.9.2/jquery-ui.js'></script>";
//$document_version_info_html .= "<script type='text/javascript' src='//code.jquery.com/jquery-migrate-1.1.0.js'></script>";
//$document_version_info_html .= "<script src='../includes/js/jquery.functions2.js'></script>";
//$document_version_info_html .= "<script src='../includes/js/validations/generic_validations.js'></script>";
//$document_version_info_html .= "<script src='../includes/js/jquery.participant.js'></script>";
//$document_version_info_html .= "<script src='../includes/js/jquery.smartparticipant.js'></script>";
//$document_version_info_html .= "<script src='../includes/js/jquery.smartLightBox.js'></script>";

$document_version_info_html .= "<link href='/css/jQuery-clockpicker.min.css' rel='stylesheet' type='text/css' >";	
$document_version_info_html .= "<script type='text/javascript' src='/includes/js/jQuery-clockpicker.min.js'></script>";


$document_version_info_html .= "<div class='ehsForm' id='graph_container'>";
$document_version_info_html .= "<ul><li>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>Reference Number</label>";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value='".$unique_reference."'/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='location'>Location</label>";
$document_version_info_html .= "<select name='location' id='location' style='width:220px'>";
$document_version_info_html .= "<OPTION value='0'>Corporate</OPTION>";
$document_version_info_html .= $location_data;
$document_version_info_html .= "</select>";
$document_version_info_html .= "</p>";
$document_version_info_html .= " <p>";
$document_version_info_html .= "<label for='business_unit'>Business Unit</label>";
$document_version_info_html .= "<select name='business_unit' id='business_unit' style='width:220px'  class='bu mandatory'>";
$document_version_info_html .= "{$business_unit}";
$document_version_info_html .= "</select>";
$document_version_info_html .= "</p>";
$document_version_info_html .= " <p>";
$document_version_info_html .= "<label for='date'>Date / Time</label>";
$document_version_info_html .= " <input type='text' name='date' id='date'  class='datepicker2' value='' />";
$document_version_info_html .= "<input type='text' name='time' id='time' size=6 value='' readonly/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p>";
$document_version_info_html .= "<label style='height:20px'>Issue Category</label>";
$document_version_info_html .= "<input type='radio' name='issue1' id='issue1' value='1' />Compliance Breach";
$document_version_info_html .= "<BR>";
$document_version_info_html .= "<input type='radio' name='issue1' id='issue2' value='2'  />Compliance Concern";
$document_version_info_html .= " </p>";
$document_version_info_html .= " <p>";
$document_version_info_html .= "<label for='contact_description' >Description</label>";
$document_version_info_html .= "<textarea class='mandatory' name='descp' id='descp' cols='56' rows='2'>{$problem}</textarea>";
$document_version_info_html .= "</p>";
$document_version_info_html .= " <p>";
$document_version_info_html .= "<label for='contact_description' >Regulation/Policy Violation</label>";
$document_version_info_html .= "<textarea class='mandatory' name='violation' id='violation' cols='56' rows='2'>{$violation}</textarea>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p>";
$document_version_info_html .= "<label for='mitigate' >Mitigation Action Plan</label>";
$document_version_info_html .= "<textarea class='mandatory' name='plan' id='plan' cols='56' rows='2'>{$plan}</textarea>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "</li>";
$document_version_info_html .= "<LI>   ";
$document_version_info_html .= "<P class='h30'><label >Heading</label><span >".$data["Main_Heading"]."</span></P>";
$document_version_info_html .= "<P class='h30'><label >Description</label><span >".$data["Description"]."</span></P>";
$document_version_info_html .="<p class='h30'><label >Penalty</label>";
$document_version_info_html .= "<span >".$data["penalty"]."</span>";
$document_version_info_html .= "</P><p>";
$document_version_info_html .= "<label style='height:20px'>Issue Type</label>";
$document_version_info_html .= "<input type='checkbox' name='type1' id='type1' value='1' />Regulation/Legislation";
$document_version_info_html .= "<BR>";
$document_version_info_html .= "<input type='checkbox' name='type2' id='type2' value='1' />Internal Policy";
$document_version_info_html .= "<p class='h30'><label >Issue Owner</label>";
$document_version_info_html .= "<span >".$name."</span>";
//$document_version_info_html .= "<input type='text' class='participants' name='name' id='name' value='".$name."'/>";
$document_version_info_html .= "<input type='hidden' name='name_hidden' id='name_hidden' value='".$userid."'>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "</LI></ul></div> ";

echo $document_version_info_html;
?>