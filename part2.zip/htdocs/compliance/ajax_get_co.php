<?php
 /**
  $Id: ajax_participants.php,v 3.20 Tuesday, January 25, 2011 9:43:40 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;


$id=isset($_GET["id"]) ? $_GET["id"] : 0;
$region=isset($_GET["region"]) ? $_GET["region"] : 0;
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';


$compObj = new Compliance();
 $data1 = $compObj->getCompanies($id,$region);
$str="<OPTION value=0>-- Select --</OPTION>";
foreach($data1 as $key=>$value){
	$str.="<OPTION value=".$key.">".$value."</OPTION>";
}
	echo $str;

?>