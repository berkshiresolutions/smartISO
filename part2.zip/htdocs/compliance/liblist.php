<?php

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;

$_PAGE_VALIDATION_SCRIPT = '/compliance/liblist.js';


require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/classes/newCore/modules/email/actionvEmail.php';
$docObj = new Documents();

$id = $_GET["id"];
$files = explode(",",$_GET["files"]);
$locObj = SetupGeneric::useModule('Locationgram');
$partObj = SetupGeneric::useModule('Participant');
$userid= getLoggedInUserId();


$commObj = new CommMan();
$result=$commObj->getLibraryDocs();
foreach($result as $row){
	
	        $sel = "selected_new='false'";
        if (is_array($files) && in_array($row["fileID"], $files)) {
           $sel = "selected_new='true'";
        }
$library_data.="<OPTION value=".$row["fileID"]." ". $sel . ">".$row["usrFilename"]."</OPTION>";
}



$smarty->assign('id',$id);
$smarty->assign('library_data',$library_data);
$smarty->display('compliance/liblist.tpl');
?>