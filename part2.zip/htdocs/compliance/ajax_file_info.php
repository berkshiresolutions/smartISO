<?php
 /**
  $Id: ajax_participants.php,v 3.20 Tuesday, January 25, 2011 9:43:40 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;

$ids=$_GET["ids"];
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$objUpload = new Upload();

$files='';
if ($ids != ''){
    $filesArr=explode(",",$ids);
    foreach ($filesArr as $file){
$objUpload->setFileInfo('library', array('id' =>  $file));
$file_detail = $objUpload->getFileDetails();
$files .= "<label ><a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=" . $file_detail['sysFilename'] . "&un=" . $file_detail['usrFilename'] . "&module=library','mywindow')\">";
$files .= $file_detail['usrFilename'] . "</a></label><BR>";

    }
}
	echo $files;

?>