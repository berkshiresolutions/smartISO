<?php
/**
  $Id: manage_equipment_details_new.php,v 3.10 Friday, February 04, 2011 9:52:02 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Setup
 * @since  Tuesday, December 14, 2010 4:36:42 PM>
 */
$class_system_review1 = "selected_tab"; //selected tabs
$LAST_BREAD_CRUM = "Register Detail";

$_PAGE_VALIDATION_SCRIPT = 'compliance/add_register.js';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$compObj = new Compliance();
$objRef = new UniqueReference();

$start = (int) $_GET['start'];
$task = $_GET['task'];
$date = date("Y/m/d");
list($current_year, $current_month, $current_day) = explode("/", $date);


$current_date = array($current_month, $current_day, $current_year);

$today_date = implode("/", $current_date);




if ($_SERVER['REQUEST_METHOD'] == 'POST') {



$data["reference"]=$_POST["reference"];
$data["rmonth"]=$_POST["rmonth"];
$data["rfor"]=str_replace("'","`",$_POST["rfor"]);
$compObj->setComplianceInfo(0, $data);
$last_ID=$compObj->addComplianceregister();  
 


    redirection('build_register.php?id='.$last_ID);

    exit;


}




$reference = $objRef->getUniqueNumber('CPR');


$smarty->assign('reference', $reference);
$smarty->assign('today_date', $today_date);
//$smarty->debugging=true;
$smarty->display('compliance/add_register.tpl');
require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>



?>