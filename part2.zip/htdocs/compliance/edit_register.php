<?php
/**
  $Id: manage_equipment_details_new.php,v 3.10 Friday, February 04, 2011 9:52:02 AM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Gurnam Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @subpackage Setup
 * @since  Tuesday, December 14, 2010 4:36:42 PM>
 */
$class_system_review1 = "selected_tab"; //selected tabs
$LAST_BREAD_CRUM = "Register Detail";

$_PAGE_VALIDATION_SCRIPT = 'compliance/edit_register.js';
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$compObj = new Compliance();
$objRef = new UniqueReference();

$start = (int) $_GET['start'];

$date = date("Y/m/d");
list($current_year, $current_month, $current_day) = explode("/", $date);


$current_date = array($current_month, $current_day, $current_year);

$today_date = implode("/", $current_date);




if ($_SERVER['REQUEST_METHOD'] == 'POST') {



$data["reference"]=$_POST["reference"];
$data["rmonth"]=$_POST["rmonth"];
$data["rfor"]=str_replace("'","`",$_POST["rfor"]);
if ($_POST["task"] == 'copy'){
$compObj->setComplianceInfo(0, $data);
$lastID=$compObj->addComplianceregister(); 
$compObj->copyComplianceregister($lastID,$_POST["id"]); 
redirection('build_register.php?id='.$lastID);
} else {
$compObj->setComplianceInfo($_POST["id"], $data);
$compObj->editComplianceregister();  
    redirection('indexregister.php');
}



    exit;


}

$task = $_GET['task'];
$id = $_GET['id'];

if ($task == 'copy'){

$reference = $objRef->getUniqueNumber('CPR');
}
$data = $compObj->getReporthdr($id);

$data["ReportDate"]=format_date($data["ReportDate"]);
$smarty->assign('reference', $reference);
$smarty->assign('data', $data);
$smarty->assign('task', $task);
//$smarty->debugging=true;
$smarty->display('compliance/edit_register.tpl');
require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>



?>