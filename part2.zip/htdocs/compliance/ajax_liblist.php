<?php

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$id = $_GET["id"];
$locObj = SetupGeneric::useModule('Locationgram');
$partObj = SetupGeneric::useModule('Participant');
$userid= getLoggedInUserId();


$commObj = new CommMan();
$result=$commObj->getLibraryDocs();
foreach($result as $row){
$library_data.="<OPTION value=".$row["fileID"].">".$row["usrFilename"]."</OPTION>";
}
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$document_version_info_html .= "<link href='/css/jQuery-clockpicker.min.css' rel='stylesheet' type='text/css' >";	
$document_version_info_html .= "<script type='text/javascript' src='/includes/js/jQuery-clockpicker.min.js'></script>";


$document_version_info_html .= "<div class='ehsForm' id='graph_container'>";
$document_version_info_html .= "<ul><li>";

$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='location'>Library Files   </label>";
$document_version_info_html .= "<select name='location' id='location' style='width:220px'>";
$document_version_info_html .= $library_data;
$document_version_info_html .= "</select>";
$document_version_info_html .= "</p>";

$document_version_info_html .= "</LI></ul></div> ";

echo $document_version_info_html;
?>