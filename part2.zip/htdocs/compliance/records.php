<?php
 /**
  $Id: records.php,v 3.67 Thursday, December 02, 2010 6:15:09 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Customer complaint
  * @since  Saturday, September 11, 2010 5:42:36 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once _MYINCLUDES."record_listing_page.inc.php";

$objCompl = new Compliance();

$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');


if($archive_session==1){
$data3 = $objCompl->viewAllArchived();
}else{
$data3 = $objCompl->viewAll();
}

$total_records = count($data3);

$html = "";
$jsdata = "";
?>

<input type='hidden' name='selected_radio' id='selected_radio' value='0'>
<table cellpadding="2" cellspacing="4" border="0" class="display" id="module_records">
	<thead>
		<tr style='color:#fff'>
			<th width='3%'>&nbsp;</th>
			<th width='20%'>Reference #</th>
                        <th width='30%'>Title</th>
                        <th width='30%'>Template Type</th>
			<th width='20%'>Period</th>
			<th width='25%'>Description</th>
			
		</tr>
	</thead>
	<tbody>
		<?php
		for ($i=0;$i<$total_records;$i++) {
			if ( $data[$i]['time'] == "0000-00-00" ) {
				$date = format_date(date('m/d/Y'));
			} else {
				$date = format_date($data[$i]['time']);
			}
			$r = 	$data[$i]['reference'];
			if($data[$i]['document_c'] == 'CONFIDENTIAL'){
			$data[$i]['document_c'] = 'DAILY';
			}
		?>
		<tr >
			<td class='record_row' rel='<?php echo $data3[$i]['reviewID']?>'><input type='radio' name='record_radio' id='record_radio<?php echo $data3[$i]['reviewID']?>' class='choose_radio' value='<?php echo $data3[$i]['reviewID']?>'></td>
			<td class='record_row' rel='<?php echo $data3[$i]['reviewID']?>'><label for='record_radio<?php echo $i ?>'><?php echo $data3[$i]['reference'] ?></label></td>
			<td  class='record_row' rel='<?php echo $data3[$i]['reviewID']?>' align='left'><?php echo $data3[$i]['title']?></td>
                        <td  class='record_row' rel='<?php echo $data3[$i]['reviewID']?>' align='left'><?php echo $data3[$i]['template_type']?></td>
                        <td  class='record_row' rel='<?php echo $data3[$i]['reviewID']?>' align='left'><?php echo $data3[$i]['period']?></td>
			<?php
			$description = compact_ra_description($data3[$i]['description'],30);
			$description_full = javascript_safe_string($data3[$i]['description']);
			$jsdata .= "\n$('.record_row_desc".$r."').smartLightBox({heading:'Description', writeMode: false, width: '500', height : '200', description : '".$description_full."'});\n";
			echo "<td><a class='record_row_desc".$r."'>".$description."</a></td>";
			?>
				
		</tr>
		<?php

		} 
		$html .= "<script>(function($) { $(document).ready(function() { ";
		$html .= $jsdata;
		
		$html .= "});})(jQuery);</script>";
		echo $html;
		
		?>
	</tbody>
	<tfoot>
		<tr>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
			
		</tr>
	</tfoot>
</table>