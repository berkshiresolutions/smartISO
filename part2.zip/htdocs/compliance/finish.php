<?php

/**
  $Id: manage_smart_law.php,v 3.14 Monday, January 10, 2011 12:38:59 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * This file is used to manage smart law.
 *
 * Long description
 * Long description
 *
 * @author  Hemandeep Singh
 * @package Smartiso
 * @subpackage SmartLaw
 * @since  Wednesday, October 13, 2010 6:21:49 PM>
 */

$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = false;
$id=$_GET["id"];
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';
$objCompliance = new Compliance();
$objCompliance->finish($id);
redirection('index.php?e=6');
?>