<?php
 /**
  $Id: report.php,v 3.12 Wednesday, November 24, 2010 3:08:26 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * for customer-complaint report
  *
  * Long description
  * Long description
  *
  * @author  Davinder Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @since  Saturday, November 20, 2010 10:51:04 AM>
  */


$LAST_BREAD_CRUM = "Report R1";

$_PAGE_VALIDATION_SCRIPT = 'compliance/report.js';
require $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$record_id 			= (int) $_GET['cid'];
$period_id 			= (int) $_GET['period'];
$template_id 			= (int) $_GET['template'];

$repObj = new Report('html');

$repObj->setFilters(
					array(
						  'id'=>$record_id,
						  'type'=>'Compliance1',
                                            'period'=>$period_id,
                                            'template'=>$template_id,
						  'heading'=>true
						  )
					);

$repObj->generateReport('COMPLIANCE');
$repObj->displayReport();

require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>
