<?php
$_HIDE_HTTP_HEADER = false;
$_SHOW_GUEST_HTTP_HEADER = false;
$_PAGE_VALIDATION_SCRIPT2 = 'compliance/add_edit.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

?>
<style>
.grab { cursor: grab; }
.grabbed { box-shadow: 0 0 13px #000; }
.grabCursor, .grabCursor * { cursor: grabbing !important; }
</style>

<table>
<tr><th>...</th></tr>
<tr><td class="grab">&#9776;</td><td>...1</td></tr>
<tr><td class="grab">&#9776;</td><td>...2</td></tr>
<tr><td class="grab">&#9776;</td><td>...3</td></tr>
<tr><td class="grab">&#9776;</td><td>...4</td></tr>
</table>

<script>
    (function($) {
    $(document).ready(function () {
$(".grab").mousedown(function (e) {
    var tr = $(e.target).closest("TR"), si = tr.index(), sy = e.pageY, b = $(document.body), drag;
    if (si == 0) return;
    b.addClass("grabCursor").css("userSelect", "none");
    tr.addClass("grabbed");
    function move (e) {
        if (!drag && Math.abs(e.pageY - sy) < 10) return;
        drag = true;
        tr.siblings().each(function() {
            var s = $(this), i = s.index(), y = s.offset().top;
            if (i > 0 && e.pageY >= y && e.pageY < y + s.outerHeight()) {
                if (i < tr.index())
                    s.insertAfter(tr);
                else
                    s.insertBefore(tr);
                return false;
            }
        });
    }
    function up (e) {
        if (drag && si != tr.index()) {
            drag = false;
            alert("moved!");
        }
        $(document).unbind("mousemove", move).unbind("mouseup", up);
        b.removeClass("grabCursor").css("userSelect", "none");
        tr.removeClass("grabbed");
    }
    $(document).mousemove(move).mouseup(up);
});
});
});
</script>