<?php

/**
  $Id: set_oragnigram_date.php,v 3.36 Thursday, February 10, 2011 4:16:49 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Ogranigram msr date setup
 * @since  Monday, December 13, 2010 6:16:27 PM>
 */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;
$_PAGE_VALIDATION_SCRIPT2 = 'compliance/build_register.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';


$compObj = new Compliance();

$id = $_GET['id'];



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

$count=count($_POST["rmonth"]);
 $data["id"]   =$_POST["id"];
        $compObj->removeData($data["id"]);
        $i=1;
foreach ($_POST["rmonth"] as $key=>$value)
{
        $did   =(int)$_POST["did"][$i];
       
        $data["month"]   =$value;
        $data["concern"] =str_replace("'","`",$_POST["concern"][$key]);
        $data["status"]  =str_replace("'","`",$_POST["status"][$key]);
        $data["rupd"]    =$_POST["rupd"][$key];
        $data["order"]   =$i;

        $compObj->setComplianceInfo($did,$data);
        $compObj->saveData();
        $i++;
} 

    redirection("indexregister.php");
}


$id = $_GET['id'];
$data = $compObj->getReporthdr($id);
$datab = $compObj->getReportview($id);

$smarty->assign('id', $id);
$smarty->assign('data', $data);
$smarty->assign('datab', $datab);

//$smarty->debugging=true;
$smarty->display('compliance/build_register.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>