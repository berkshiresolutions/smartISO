<?php
 /**
  $Id: index.php,v 3.04 Saturday, November 27, 2010 4:05:12 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Gurnam Singh <simurgrai@gmail.com>
  * @package Smartiso
  * @subpackage Equipment
  * @since  Wednesday, October 13, 2010 10:52:09 AM>
  */

// load jquery page validation script file


$_PAGE_VALIDATION_SCRIPT = 'compliance/indexalert.js';

$class_bi = "selected_tab";
require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
Session::saveSessionField('ARCHIVE_RECORDS',0);
$archive_flag = (int) Session::getSessionField('ARCHIVE_RECORDS');

$user_level = Session::getSessionField('SESS_USER_LEVEL');

$userid= getLoggedInUserId();
$participantObj = SetupGeneric::useModule('participant');
$gcuuser = $participantObj->isGCUPerson($userid);

$smarty->assign('user_level',$user_level);
$smarty->assign('gcuuser',$gcuuser);
$smarty->assign('permissions',$PERMISSIONS);

$smarty->assign('archive_flag',$archive_flag);
//$smarty->debugging=true;
$smarty->display('compliance/indexalert.tpl');
require _MYPRIVATEINCLUDES.'applicationBottom.inc.php';
?>