<?php
 /**
  $Id: ajax_participants.php,v 3.20 Tuesday, January 25, 2011 9:43:40 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
$compObj = new ComplianceAlert();
$routingObj = new Routing();
    $id = $_GET['questionid'];
    $data_array['unique_reference'] = $_GET['unique_reference'];
    $data_array['location'] = $_GET['location'];
    $data_array['business_unit'] = $_GET['business_unit'];
    $data_array['date'] = $_GET['date'];
    $data_array['time'] = $_GET['time'];
    $data_array['issue'] = $_GET['issue1'];
    $data_array['type1'] = (int)$_GET['type1'];
    $data_array['type2'] = (int)$_GET['type2'];
    $data_array['descp'] = str_replace("'", "`", $_GET['descp']);
    $data_array['violation'] = str_replace("'", "`", $_GET['violation']);
    $data_array['plan'] = str_replace("'", "`", $_GET['plan']);
    $data_array['who'] = $_GET['who'];

    $emailer= $routingObj->getEmailer($_GET['who']);

    $data_array['who']=$emailer["participantID"];
    // do insert

    $compObj->setComplianceInfo(0, $data_array);
    $record_id = $compObj->addComplianceAlert();

    $aid = $compObj->addAction($record_id);
    $compObj->linktoTemplate($record_id,$id);
    $objModTracker = new ModuleTracker();
    $objModTracker->setModuleTrackerInfo('CPLA', array(
        'rec_id' => $record_id,
        'action' => 'add'
    ));


    $objModTracker->saveRecordLog();
    $objModTracker = null;


echo 1;
?>