<?php

/**
  $Id: report.php,v 3.12 Wednesday, November 24, 2010 3:08:26 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * for customer-complaint report
 *
 * Long description
 * Long description
 *
 * @author  Davinder Singh <simurgrai@gmail.com>
 * @package Smartiso
 * @since  Saturday, November 20, 2010 10:51:04 AM>
 */
$_HIDE_HTTP_HEADER = false;
$_SHOW_GUEST_HTTP_HEADER = false;
$_PAGE_VALIDATION_SCRIPT2 = 'compliance/add_edit2.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$compliance = new Compliance();
$objUpload = new Upload();
$objRoute = new Routing();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $compliancedata = $_POST['data'];
    $when = $_POST['when'];
    $check = $_POST['check'];
	$comp = $_POST['compliance'];
    $radyn = $_POST['radyn'];
    $control = $_POST['control'];
    $actionID= $_POST['actionID'];
    $idStr = '';
    foreach ($_POST["id"] as $key => $value) {
        $idStr .= $value . ",";
        if ($check[$value] == 1) {
            $data['file_upload']['name'] = $_FILES['file_upload']['name'][$value];
            $data['file_upload']['type'] = $_FILES['file_upload']['type'][$value];
            $data['file_upload']['tmp_name'] = $_FILES['file_upload']['tmp_name'][$value];
            $data['file_upload']['error'] = $_FILES['file_upload']['error'][$value];
            $data['file_upload']['size'] = $_FILES['file_upload']['size'][$value];
            $data['file_upload']['destination'] = 'compliance';

            if ($data['file_upload']['size'] > 0) {

                $objUpload->setFileInfo('compliance', $data['file_upload']);

                $objUpload->add_file();


                $fileid = $objUpload->getLastFileId();
            } else
                $fileid = 0;

if (isset($radyn[$value]))
            $compliance->updateQuestion($value, $radyn[$value], $when[$value], $comp[$value], $fileid);
else
            $compliance->updateQuestion($value, $compliancedata[$value], $when[$value], $comp[$value], $fileid);
            
        }
    }
   
    if ($_POST['flag'] == 1) {
        //todo
       $emailer=$compliance->finishSection1(substr($idStr, 0, -1));
       $compliance->roaEmails($emailer,$_POST['idI']);   
        $objModTracker = new ModuleTracker();
        $objModTracker->saveRecordLog1("compliance_master","COMP",$_POST['idI'],$_POST['ref'],'update');
    }
    redirection('index.php');
}

$id = $_GET['id'];
$compliance->setComplianceInfo($id, '');
$dataStart = $compliance->getMasterbyID();

$data = $compliance->getQuestions($id);
$i = 0;
$userid = getLoggedInUserId();
$USER_LEVEL = getUserAccessLevel();

$optionObj = new Option();
$red = $optionObj->getOption('_SU_EMAIL_REDMAIL');
$yellow = $optionObj->getOption('_SU_EMAIL_YELLOWMAIL');
$green = $optionObj->getOption('_SU_EMAIL_BLUEMAIL');

//$userid = 55; //testing
$counter = -1;
while (is_array($whoA) != $counter) {
    $counter = count($whoA);
    $whoA[] = $userid;
    $userStr = implode(",", $whoA);
    $whoA = $objRoute->getRoutes($userStr);
}
$whoA[] = $userid;

foreach ($data as $row) {

    if (!in_array($row["whoRequired"], $whoA))
        continue;

		$codeArr=explode("|",$row["code"]);
    $out[$row['period']][$row['Main_Heading']][$i] = $row;
    $out[$row['period']][$row['Main_Heading']][$i]['when'] = format_date($row["whendate"]) == '01/01/1970' ? '' : format_date($row["whendate"]);
   // $out[$row['period']][$row['Main_Heading']][$i]['check'] = (int) $row["stagedone"] == 0 ? 0 : -1;//originaal check
    $out[$row['period']][$row['Main_Heading']][$i]['check'] =  (int) $row["whoRequired"] == (int)$userid ? -1 : 0;
     $out[$row['period']][$row['Main_Heading']][$i]['check'] = (int) $row["datatype"] == 'H' ? 1 : $out[$row['period']][$row['Main_Heading']][$i]['check'];
    $out[$row['period']][$row['Main_Heading']][$i]['check'] = (int) $row["datatype"] == 'F' ? 1 : $out[$row['period']][$row['Main_Heading']][$i]['check'];

    $out[$row['period']][$row['Main_Heading']][$i]['lock'] = (int) $row["whoRequired"] == (int)$userid ? 0 : 1;
    
    if (!$row['doneDate']) {
        $str = (strtotime($row['dueDate'])) - strtotime(date("M d Y "));
        $dateinc = floor($str / 3600 / 24);


        $change_bg_color = "";
        if ($dateinc > $green) {
            $change_bg_color = "";
        } else if ($dateinc > $yellow) {
            $change_bg_color = "background-color:green;COLOR:WHITE";
        } else if ($dateinc > $red) {
            $change_bg_color = "background-color:#F4A460;COLOR:WHITE";
        } else {
            $change_bg_color = "background-color:red;COLOR:WHITE";
        }
        $out[$row['period']][$row['Main_Heading']][$i]['duedatestyle'] = $change_bg_color;
    }
    $date = new DateTime(date("Y-m-d", strtotime("last day of previous month")));
    date_add($date, date_interval_create_from_date_string($row["dateoffset"] . ' days'));
    $out[$row['period']][$row['Main_Heading']][$i]['dateExe'] = $date->format('Ymd');

    if (!$row['when']) {
        $str1 = (strtotime($date->format("M d Y "))) - strtotime(date("M d Y "));
        $dateinc1 = floor($str1 / 3600 / 24);


        $change_bg_color1 = "";
        if ($dateinc1 > $green) {
            $change_bg_color1 = "";
        } else if ($dateinc1 > $yellow) {
            $change_bg_color1 = "background-color:green;COLOR:WHITE";
        } else if ($dateinc1 > $red) {
            $change_bg_color1 = "background-color:#F4A460;COLOR:WHITE";
        } else {
            $change_bg_color1 = "background-color:red;COLOR:WHITE";
        }

        $out[$row['period']][$row['Main_Heading']][$i]['dateexestyle'] = $change_bg_color1;
    }
	
	switch((int)$row["compliance"]){
			case 3: $change_bg_color2 = "background-color:green;"; break;
			case 2: $change_bg_color2 = "background-color:red;"; break;
			case 1: $change_bg_color2 = "background-color:purple;"; break;
			default:$change_bg_color2 = ""; break;
		}
	$out[$row['period']][$row['Main_Heading']][$i]['statusstyle'] =$change_bg_color2;  
$compliance1=explode("|",$row["compliance_answer"]);

$out[$row['period']][$row['Main_Heading']][$i]['compliance1']=$compliance1[0];

if ($row["fileID"]>0){
$objUpload->setFileInfo('compliance', array('id' =>  $row["fileID"]));
$file_detail = $objUpload->getFileDetails();
$files = "<label ><a href='javascript:void(0)' onclick=\"window.open('/download_file.php?fn=" . $file_detail['sysFilename'] . "&un=" . $file_detail['usrFilename'] . "&module=compliance','mywindow')\">";
$files .= $file_detail['usrFilename'] . "</a></label>";
$out[$row['period']][$row['Main_Heading']][$i]['files']=$files;

}
    $i++;
}
$periodArr=array(0 =>'-',1 =>'Monthly',2 =>'Bi- Monthly',3=>'Quarterly',4 =>'Semi-Annually',5 => 'Annually',6 => 'Bi - Annually',7 => 'Tri - Annually');

$yn = array('Yes' => 'Yes', 'No' => 'No');
$monthly = array('January' => 'January', 'February' => 'Febraury');
$smarty->assign('hdrdata', $dataStart);
$smarty->assign('data', $out);
$smarty->assign('datacount', count($out));
$smarty->assign('ref', $dataStart["reference"]);
$smarty->assign('refid', $id);
$smarty->assign('periodStr', $periodArr[(int)$dataStart["period"]]);
//$smarty->debugging=true;
$smarty->display('compliance/add_edit2.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>
