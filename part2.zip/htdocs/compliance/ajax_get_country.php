<?php
 /**
  $Id: ajax_participants.php,v 3.20 Tuesday, January 25, 2011 9:43:40 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$ttype = $_GET['ttype'];
//echo $str;
$compObj = new Compliance();

$data = $compObj->getCountryData($ttype);


if (data)
{
    $i=0;
$records = array();
foreach ($data as $value) {
		$records[$i]['key']= $value['ID'];
		$records[$i++]['val'] = $value['Title'];

	}

}
 else {
 $records= array();   
}
$resultset = array('records' => $records);

echo json_encode($resultset);
?>