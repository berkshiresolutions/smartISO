<?php
 /**
  $Id: ajax_participants.php,v 3.20 Tuesday, January 25, 2011 9:43:40 AM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Ajax data check
  * @since  Saturday, October 09, 2010 6:51:48 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';

$id = $_GET['id'];
$comments=str_replace("'","`",$_GET['comment']);
//echo $str;
$compObj = new ComplianceAlert();

$data = $compObj->saveComments($id,$comments);



echo $data;
?>