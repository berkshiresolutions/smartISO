<?php
 /**
  $Id: records.php,v 3.67 Thursday, December 02, 2010 6:15:09 PM ehsindia Exp $  *
  *
  * smart-ISO, Smart Auditing Software Solutions
  * http://www.smart-iso.com
  * Copyright (c) 2010 smart-ISO
  * Released under the Smartiso License
  *
  *
  * Short description
  *
  * Long description
  * Long description
  *
  * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
  * @package Smartiso
  * @subpackage Customer complaint
  * @since  Saturday, September 11, 2010 5:42:36 PM>
  */
$_HIDE_HTTP_HEADER = true;

require_once $_SERVER['DOCUMENT_ROOT'].'/../includes/applicationTop.inc.php';
require_once _MYINCLUDES."record_listing_page.inc.php";

$objCompl = new Compliance();

$archive_session = (int) Session::getSessionField('ARCHIVE_RECORDS');


if($archive_session==1){
$data3 = $objCompl->viewRegisterAllArchived();
}else{
$data3 = $objCompl->viewRegisterAll();
}

$total_records = count($data3);

$html = "";
$jsdata = "";
?>

<input type='hidden' name='selected_radio' id='selected_radio' value='0'>
<table cellpadding="2" cellspacing="4" border="0" class="display" id="module_records">
	<thead>
		<tr style='color:#fff'>
			<th width='2%'>&nbsp;</th>
			<th width='5%'>Reference #</th>
                        <th width='70%'>Report for</th>
                         <th width='20%'>Report Date</th>

			
			
		</tr>
	</thead>
	<tbody>
		<?
		for ($i=0;$i<$total_records;$i++) {


		?>
		<tr >
			<td class='record_row'  rel='<?php echo $data3[$i]['ID']?>'><input type='radio' name='record_radio' id='record_radio<?php echo $data3[$i]['ID']?>' class='choose_radio' value='<?php echo $data3[$i]['ID']?>'></td>
			<td class='record_row' style='width:200px' rel='<?php echo $data3[$i]['ID']?>'><label for='record_radio<?=$i?>'><?php echo $data3[$i]['reference'] ?></label></td>

			<?php
			$description = compact_ra_description($data3[$i]['reportFor'],100);
			$description_full = javascript_safe_string($data3[$i]['reportFor']);
                        $date = new DateTime($data3[$i]['ReportDate']);
			echo "<td><a class='record_row_desc".$r."'>".$description_full ."</a></td>";
                        echo "<td>".$date->format('F Y') ."</td>";
			?>
				
		</tr>
		<?

		} 
		$html .= "<script>(function($) { $(document).ready(function() { ";
		$html .= $jsdata;
		
		$html .= "});})(jQuery);</script>";
		echo $html;
		
		?>
	</tbody>
	<tfoot>
		<tr>
			<th>&nbsp;</th>
			<th>&nbsp;</th>
                        <th>&nbsp;</th>


			
		</tr>
	</tfoot>
</table>