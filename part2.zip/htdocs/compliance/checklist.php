<?php

/**
  $Id: set_oragnigram_date.php,v 3.36 Thursday, February 10, 2011 4:16:49 PM ehsindia Exp $  *
 *
 * smart-ISO, Smart Auditing Software Solutions
 * http://www.smart-iso.com
 * Copyright (c) 2010 smart-ISO
 * Released under the Smartiso License
 *
 *
 * Short description
 *
 * Long description
 * Long description
 *
 * @author  Sanjeev Krishan <sanjeev24125@gmail.com>
 * @package Smartiso
 * @subpackage Ogranigram msr date setup
 * @since  Monday, December 13, 2010 6:16:27 PM>
 */
$_HIDE_HTTP_HEADER = true;
$_SHOW_GUEST_HTTP_HEADER = true;
$_PAGE_VALIDATION_SCRIPT2 = 'compliance/checklist.js';

require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$compliance = new Compliance();





if ($_SERVER['REQUEST_METHOD'] == 'POST') {

 $count=count($_POST["id"]);
 $sendemail=$_POST["sendemail"];
 for($x=0;$x<$count;$x++){
     
     $compliance->updateChecklist($_POST["id"][$x],$_POST["who_hidden"][$x],$_POST["who1_hidden"][$x]); 
 }
 
 if ( $sendemail == 1 ){
$data["reference"]=$_POST["reference"];
$data["country"]=$_POST["country"];
$data["ttype"]=$_POST["ttype"];
$data["period"]=$_POST["period"];
$compliance->setComplianceInfo(0,$data);
Session::saveSessionField('review_id', $rID);
 $id= $compliance->addCompliance();  
 
    $compliance->buildQuestionList($id);
    $compliance->sendMail($id);
 }
	
// $compliance->updateChecklist($id,$who);
    redirection('index.php');
}
$country = $_GET['country']; 
$period = $_GET['period']; 
$ttype = $_GET['ttype'];
$reference = $_GET['ref'];

$data = $compliance->getChecklist($period,$ttype,$country);

$smarty->assign('country', $country );
$smarty->assign('period', $period );
$smarty->assign('ttype', $ttype);
$smarty->assign('data', $data);

$smarty->assign('ref', $reference);
//$smarty->debugging=true;
$smarty->display('compliance/checklist.tpl');

require _MYPRIVATEINCLUDES . 'applicationBottom.inc.php';
?>