<?php

$_HIDE_HTTP_HEADER = true;

require $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$id = $_GET["id"];
$locObj = SetupGeneric::useModule('Locationgram');
$partObj = SetupGeneric::useModule('Participant');
$userid= getLoggedInUserId();
$ur = new UniqueReference();
$commObj = new Compliance();
$unique_reference = $ur->getUniqueNumber('CPA');
$location_data = $locObj->getLocations($row_data['location_selected']);

    $partObj->setItemInfo(array('id' => $userid));
    $val = $partObj->displayItemMaininfoById();
    $name = $val["forename"] . " " . $val["surname"];
    
$data=$commObj->getAnswerCataById($id);
$_HIDE_HTTP_HEADER = true;
$_HIDE_ACCESS_CONTROL = true;
require_once $_SERVER['DOCUMENT_ROOT'] . '/../includes/applicationTop.inc.php';

$document_version_info_html .= "<div class='ehsForm' id='graph_container'>";
$document_version_info_html .= "<ul><li>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>a  </label>";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>   ";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>b  </label>";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>   ";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>c  </label>";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>   ";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>d  </label>";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>   ";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>e  </label>";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>   ";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "<p class='h30'>";
$document_version_info_html .= "<label for='reference_number'>equation</label>              ";
$document_version_info_html .= "<input type='text' name='reference_number' id='reference_number' value=''/>";
$document_version_info_html .= "</p>";
$document_version_info_html .= "</LI></ul></div> ";

echo $document_version_info_html;
?>